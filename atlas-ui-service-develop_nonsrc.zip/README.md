# Split app installation using angular-ui-react-service

Prerequisites:
- git with SSH configured
- NPM version 6 or higher
- docker
- docker-compose

1. Clone both this repo and the React app
```
git clone git@github.com:worklandcom/atlas-ui-service.git
git clone git@github.com:worklandcom/atlas-ui-react-service.git
```

2. Go into the folder *atlas-ui-react-service* and run to launch static build on port 5000:
```
npm install
npm run serve:angular-built
```

3. Go into the folder *atlas-ui-service* and run:
```
cp atlas-ui-env.example atlas-ui.env
npm install
npm run build
```

4. Now you can start the containers. Run this command in *atlas-ui-service* folder:
```
docker-compose up -d
```

**Note:** if you have Python 3 installed, you may get a **gcloud** error here. Run the following:
```
export LD_LIBRARY_PATH=/usr/local/lib
docker-compose up -d
```

In order to see updates made on the react app, you need to go to *atlas-ui-react-service* and re-run `npm run serve:angular-built`. You can however see the changes on http://localhost:3000 as usual. *atlas-ui-service* (this one) can only read from react's build folder.


## ESLint

ESLint will make your life easier while programming by catching many kinds of errors. Details for installation and usage can be found at [https://github.com/worklandcom/miscellaneous/blob/master/Lintings/eslint.md](https://github.com/worklandcom/miscellaneous/blob/master/Lintings/eslint.md). The VSCode plugin of ESLint is preferred.
