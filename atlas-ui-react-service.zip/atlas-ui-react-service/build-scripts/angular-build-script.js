const rewire = require("rewire");
const defaults = rewire("react-scripts/scripts/build.js");
let config = defaults.__get__("config");
const { resolve } = require("path");

// custom entry
const entry = resolve(__dirname, "..", "src", "angular-entry.js");
config.entry = entry;

// single js file
config.output.filename = "static/js/index.js";
config.optimization.splitChunks = {
  cacheGroups: {
    default: false,
  },
};

config.output.library = "Workland";

config.optimization.runtimeChunk = false;

// single css file
const cssPlugin = config.plugins[5].options;
cssPlugin.filename = "static/css/styles.css";
delete cssPlugin.chunkFilename;
