const fs = require("fs");
const dotenv = require("dotenv");
const { resolve } = require("path");

const { existsSync, writeFileSync } = fs;

const environmentFilePath = existsSync(resolve(__dirname, "..", ".env"))
  ? resolve(__dirname, "..", ".env")
  : resolve(__dirname, "..", "example.env");

const keys = dotenv.parse(fs.readFileSync(environmentFilePath));

dotenv.config({ path: environmentFilePath });

const nodeExport = Object.keys(keys)
  .filter((k) => k !== "BROWSER")
  .map((key) => `export const ${key} = "${process.env[key]}";`)
  .join("\n");

const fileContent = `${nodeExport}\n`;

writeFileSync(resolve(__dirname, "..", "src", "config.js"), fileContent, {
  encoding: "utf8",
});

writeFileSync(resolve(__dirname, "..", "public", "config.mjs"), fileContent, {
  encoding: "utf8",
});
