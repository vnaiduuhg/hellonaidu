import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
import store from "global/store/store";

export const getBenefitsByAccount = async () => {
  const accountId = store.getState().user.data.user_account?.account_id ?? null;

  if (!accountId) {
    // TODO: redirect to login screen
    throw new Error("Not logged in for benefits api");
  }

  return getRestrictedApi(
    serviceNames.jobs,
    `benefit/account/${accountId}/benefits`,
    getToken(),
  );
};
