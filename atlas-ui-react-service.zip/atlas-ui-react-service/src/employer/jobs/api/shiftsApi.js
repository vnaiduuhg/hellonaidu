import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

// https://jobs-test.workland.ca/api/v1/timesheet/shifts
export const getShifts = async () =>
  getRestrictedApi(serviceNames.jobs, `timesheet/shifts`, getToken());
