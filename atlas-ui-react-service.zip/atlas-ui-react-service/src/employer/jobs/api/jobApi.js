import { getRestrictedApi, postRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

/*
  https://github.com/worklandcom/jobs-service/blob/test/src/Modules/Job/Http/Controllers/JobController.php

  params:
  [
    'ids' => 'array',
    'ids.*' => 'integer',
    'account_ids' => 'array',
    'account_ids.*' => 'integer',
    'excluding_account_ids' => 'array',
    'excluding_account_ids.*' => 'integer',
    'published_internal' => 'boolean',
    'published_external' => 'boolean',
    'published_outsourced' => 'boolean',
    'job_approved' => 'boolean',
    'search' => 'string',
    'company_name_search' => 'string',
    'locationSearch' => 'array',
    'locationSearch.*' => 'required|integer',
    'load_with' => 'array',
    'load_with.*' => 'string',
  ]
*/

/*
  returns: {
    current_page: 1
    data: (25) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
    first_page_url: "http://jobs-test.workland.ca/api/v1/job/current-account/jobs?page=1"
    from: 1
    last_page: 8
    last_page_url: "http://jobs-test.workland.ca/api/v1/job/current-account/jobs?page=8"
    next_page_url: "http://jobs-test.workland.ca/api/v1/job/current-account/jobs?page=2"
    path: "http://jobs-test.workland.ca/api/v1/job/current-account/jobs"
    per_page: "25"
    prev_page_url: null
    to: 25
    total: 179
  }
 */
// https://jobs-test.workland.ca/api/v1/job/current-account/jobs?page=1&pageSize=25&published_external=1
// Problem: response can be massive. it needs to be paginated
export const getJobsByAccount = async (params) =>
  // response is paginated
  await getRestrictedApi(
    serviceNames.jobs,
    "job/current-account/jobs",
    getToken(),
    params,
  );

export const getJobsByUser = async (params) =>
  // response is paginated
  await getRestrictedApi(
    serviceNames.jobs,
    "job/current-user/jobs",
    getToken(),
    params,
  );

export const getJobById = async (jobId) =>
  // response is paginated
  await getRestrictedApi(serviceNames.jobs, `job/${jobId}`, getToken());
