import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

/**
 * Read all Job Types and their translations
 */
export const getSalaries = async () =>
  getRestrictedApi(serviceNames.jobs, `salary`, getToken());
