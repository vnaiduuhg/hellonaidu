import { out } from "global/utils/useTranslation";

const tokenExpiredMsg = {
  title: out("Votre jeton est expirée!", "Your token has expired!"),
  text: out("Veuillez vous connecter à nouveau.", "Please log in again."),
};

export const getCalendarAccountsMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 404:
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "L'information de votre compte n'a pu être récupéré. Veuillez essayer de rafraîchir une page ou revenir plus tard.",
        "Your account information could not be retrieved. Please try refreshing a page or come back later.",
      );
  }

  return msg;
};

export const desyncCalendarAccountMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };
  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 404:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Ce compte n'existe pas et n'a donc pas pu être supprimé.",
        "This account does not exist and therefore could not be deleted.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Ce compte n'a pas pu être supprimé. Veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.",
        "This account could not be deleted. Please try again or contact support@workland.com for assistance.",
      );
  }
  return msg;
};

export const socialLoginRedirectMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };
  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    default:
      msg.title = out("La redirection a échouée!", "Redirection failed!");
      msg.text = out(
        "La redirection vers la page de connexion du fournisseur a échouée, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.",
        "The redirection to the provider's login page failed, please try again or contact support@workland.com for assistance.",
      );
  }
  return msg;
};

export const syncCalendarAccountMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };
  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Ce compte n'a pas pu être synchronisé. Veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.",
        "The account could not be synced. Please try again or contact support@workland.com for assistance.",
      );
  }
  return msg;
};

export const socialLoginCallbackMsgHandler = (code, provider) => {
  let msg = {
    title: "",
    text: "",
  };
  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    default:
      msg.title = out("La connexion a échouée!", "Connection failed!");
      msg.text = out(
        `Un problème est survenu et nous n'avons pu vous identifier avec votre compte ${provider}, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.`,
        `A problem occured and we couldn't identify you with your account ${provider}, please try again or contact support@workland.com for assistance.`,
      );
  }
  return msg;
};
