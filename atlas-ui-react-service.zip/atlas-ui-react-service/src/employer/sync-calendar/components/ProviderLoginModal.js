import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import MicrosoftLogo from "global/assets/images/partnerLogos/ms-symbollockup_mssymbol_19.png";
import GoogleSyncIcon from "global/assets/images/partnerLogos/icon-google.svg";
import { Button, Image, Modal } from "react-bootstrap";
import style from "../assets/CalendarSyncPage.module.css";

const ProviderLoginModal = ({ show, onHide, login, provider }) => {
  const { out } = useTranslation();
  return (
    <Modal show={show} onHide={onHide}>
      <form
        onSubmit={() => {
          login();
          onHide();
        }}
      >
        <Modal.Header>
          <Modal.Title className="h5">
            <Image
              className={`${style.inlineTextMSLogo} me-1`}
              src={provider === "google" ? GoogleSyncIcon : MicrosoftLogo}
            />
            &nbsp;
            <span>
              {provider === "google"
                ? out("Connexion Google", "Google Login")
                : out("Connexion Microsoft", "Microsoft Login")}
            </span>
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {out("Veuillez d'abord vous identifier avec", "Please sign in with")}
          &nbsp;
          <Image
            className={style.inlineTextMSLogo}
            src={provider === "google" ? GoogleSyncIcon : MicrosoftLogo}
          />
          &nbsp;
          <span>
            {provider === "google"
              ? out("Google", "Google first")
              : out("Microsoft", "Microsoft first")}
          </span>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" type="submit">
            {out("S'identifier", "Sign in")}
          </Button>

          <Button
            variant="alt-secondary"
            type="button"
            onClick={() => {
              onHide();
            }}
          >
            {out("Annuler", "Cancel")}
          </Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default ProviderLoginModal;
