import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import style from "../assets/CalendarSyncPage.module.css";
import { Button } from "react-bootstrap";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";

const MicrosoftSyncComponent = ({
  setShowProviderLoginModal,
  desyncAccount,
  calendarAccount,
  hasError404,
  error404Data,
}) => {
  const { out } = useTranslation();
  let errorMessage = error404Data?.data?.message;
  let pattern = /invalid_refresh_token, microsoft/;
  let invalidMicrosoftRefreshToken = pattern.test(errorMessage);
  return (
    <>
      <div>
        {calendarAccount.provider === "microsoft" && calendarAccount.email && (
          <div className="mb-3">
            <label className="fw-bold">
              {out("Courriel", "Email")}
              &nbsp;:
            </label>
            <span>&nbsp;{calendarAccount.email}</span>
          </div>
        )}
      </div>
      <div className="py-0 mb-3">
        {calendarAccount.provider !== "microsoft" &&
          !invalidMicrosoftRefreshToken && (
            <div className="text-end">
              <Button
                variant="secondary"
                onClick={() => {
                  setShowProviderLoginModal("microsoft");
                }}
              >
                {out("Synchroniser", "Synchronize")}
              </Button>
            </div>
          )}
        {hasError404 && invalidMicrosoftRefreshToken && (
          <AtlasAlert variant="error">
            {out(
              "Le jeton de votre compte a expiré suite à une période d'inactivité. Veuillez le supprimer et le resynchroniser.",
              "Your account token has expired due to a period of inactivity. Please delete it and resynchronize it.",
            )}
          </AtlasAlert>
        )}
        {((calendarAccount.provider === "microsoft" && calendarAccount.email) ||
          (hasError404 && invalidMicrosoftRefreshToken)) && (
          <div className="text-end">
            <Button
              variant="alt-danger"
              onClick={() => {
                desyncAccount();
              }}
            >
              {out("Supprimer", "Delete")}
            </Button>
          </div>
        )}
      </div>
    </>
  );
};

export default MicrosoftSyncComponent;
