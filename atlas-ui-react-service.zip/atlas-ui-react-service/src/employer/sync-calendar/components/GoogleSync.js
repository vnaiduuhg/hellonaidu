import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import GoogleSyncComponent from "./GoogleSyncComponent";
import GoogleSyncIcon from "global/assets/images/partnerLogos/icon-google.svg";
import style from "../assets/CalendarSyncPage.module.css";
import { Image } from "react-bootstrap";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";

const GoogleSync = ({
  calendarAccountIsError,
  errorStatusCode,
  calendarAccountError,
  isLoading,
  setShowProviderLoginModal,
  desyncAccount,
  calendarAccount,
  hasError404,
  error404Data,
}) => {
  const { out } = useTranslation();
  return (
    <div className="d-flex flex-column h-100">
      <div className={style.containerHeader}>
        <div className={style.titleContainer}>
          <div className={`${style.img} bg-white py-1 ms-3`}>
            <Image src={GoogleSyncIcon} alt="Google" />
          </div>
          <div className={style.title}>
            <h2>{out("Calendrier avec Google", "Google Calendar")}</h2>
          </div>
        </div>
      </div>
      <div
        className={`${style.componentContainer} flex-grow-1 d-flex flex-wrap`}
      >
        <div className="col-12 mt-2">
          <p className={`px-2 ${style.fs1Dot125}`}>
            {out(
              "La synchronisation du Calendrier de Google vous permet de synchroniser votre Calendrier avec votre Calendrier Atlas, d'où vous pouvez ajouter/modifier/supprimer des événements dans votre Calendrier. Vous pouvez gérer vos agendas en toute simplicité et planifier parfaitement les événements sans avoir à quitter ATLAS.",
              "Google Calendar sync allows you to synchronize your Google Calendar with your Atlas Calendar, from where you can add/edit/delete events in Google Calendar. You can manage your calendars with ease and schedule events perfectly without having to leave ATLAS.",
            )}
          </p>
        </div>
        <div className={`col-12 align-self-end pt-2 ${style.fs1Dot125}`}>
          {calendarAccount && !isLoading && !calendarAccountIsError && (
            <>
              <GoogleSyncComponent
                setShowProviderLoginModal={setShowProviderLoginModal}
                desyncAccount={() => {
                  desyncAccount();
                }}
                calendarAccount={calendarAccount}
                calendarAccountError={calendarAccountError}
                hasError404={hasError404}
                error404Data={error404Data}
              />
            </>
          )}
          {calendarAccountIsError && errorStatusCode === 500 && (
            <AtlasAlert variant="error">
              {out("Non disponible", "Not available")}
            </AtlasAlert>
          )}
          {isLoading && <ComponentLoader />}
        </div>
      </div>
    </div>
  );
};

export default GoogleSync;
