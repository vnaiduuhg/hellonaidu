import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { getCookie, setCookie, removeCookie } from "global/utils/cookies";
import { getUrlParam, routeTo } from "global/utils/utils";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";

import {
  getCurrentUserCalendarAccount,
  syncCalendarAccountByProvider,
  desyncCalendarAccountByProvider,
} from "global/apis/calendarApi";
import {
  getCalendarAccountsMsgHandler,
  desyncCalendarAccountMsgHandler,
  socialLoginRedirectMsgHandler,
  syncCalendarAccountMsgHandler,
  socialLoginCallbackMsgHandler,
} from "../utils/syncMsgHandler";

import {
  loginWithProviderAccount,
  getCallbackFromLoginWithProviderAccount,
} from "global/apis/userApi";

import GoogleSync from "../components/GoogleSync";
import MicrosoftSync from "../components/MicrosoftSync";
import ProviderLoginModal from "../components/ProviderLoginModal";
import { Col, Row } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";

const CalendarSyncPage = () => {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const [showProviderLoginModal, setShowProviderLoginModal] = useState(
    false,
    "",
  );
  const [providerName, setProviderName] = useState("");
  const [errorStatus, setErrorStatus] = useState(null);
  const [error404Data, setError404Data] = useState(null);
  const [hasError404, setHasError404] = useState(false);
  const capitalize = (s) => s && s[0].toUpperCase() + s.slice(1);

  const translatedTitle = out("Synchronisation du calendrier", "Sync Calendar");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  // get calendar synced accounts if any
  const {
    data: calendarAccount = null,
    isError: calendarAccountIsError,
    error: calendarAccountError,
    isFetching: calendarAccountIsFetching,
  } = useQuery("calendar-accounts", () => getCurrentUserCalendarAccount(), {
    ...REACT_QUERY_GETTER_OPTIONS,
    staleTime: 0,
    onSuccess: (response) => {
      const { user_account_id, id, provider, email } = response;
      setProviderName(provider);
    },
    onError: (error) => {
      setErrorStatus(error.status);
      let errorMessage = error.data?.message;
      let msPattern = /invalid_refresh_token, microsoft/;
      let invalidMicrosoftRefreshToken = msPattern.test(errorMessage);
      let googlePattern = /invalid_refresh_token, google/;
      let invalidGoogleRefreshToken = googlePattern.test(errorMessage);
      if (
        error.status === 404 ||
        (error.status === 401 &&
          (invalidMicrosoftRefreshToken || invalidGoogleRefreshToken))
      ) {
        //no synced accounts, user can choose provider and sync
        //or his token has expired and he needs to re-sync
        setError404Data(error);
        setHasError404(true);
        queryClient.setQueryData(["calendar-accounts"], []);
      } else {
        const msg = getCalendarAccountsMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 4000));
      }
    },
  });

  useEffect(() => {
    const codeUrlParam = getUrlParam("code");
    const stateUrlParam = getUrlParam("state");
    let data = {};
    if (codeUrlParam) {
      //callback after login
      dispatch(showLoadingBarWithoutMessage(200000));
      const provider = getCookie("provider");
      data = {
        provider,
        codeUrlParam,
        stateUrlParam,
      };
      socialLoginCallBack.mutate(data);
    } else {
      //user must sync google or ms by choosing a provider
      setProviderName("");
    }
    return () => {};
  }, [dispatch]);

  const syncCalendarAccount = useMutation(
    (data) => syncCalendarAccountByProvider(data),
    {
      onSuccess: (response) => {
        //display which account is synced; possibly add a link to Calendar page(?)
        setProviderName(response.provider);
        queryClient.invalidateQueries("calendar-accounts");
        routeTo("syncCalendar", { code: null });
      },
      onError: (error) => {
        const msg = syncCalendarAccountMsgHandler(error.status);
        setErrorStatus(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 4000));
        routeTo("syncCalendar", { code: null });
      },
    },
  );

  const desyncAccount = useMutation(() => desyncCalendarAccountByProvider(), {
    onSuccess: (response) => {
      //show button to sync account
      queryClient.invalidateQueries("calendar-accounts");
      removeCookie("provider");
      setProviderName("");
    },
    onError: (error) => {
      const msg = desyncCalendarAccountMsgHandler(error.status);
      setErrorStatus(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 4000));
    },
  });

  const socialLogin = useMutation((data) => loginWithProviderAccount(data), {
    onSuccess: (response) => {
      if (response.status === "success") {
        window.location = response.data.link;
      }
    },
    onError: (error) => {
      const msg = socialLoginRedirectMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  const socialLoginCallBack = useMutation(
    (data) => getCallbackFromLoginWithProviderAccount(data),
    {
      onSuccess: (response) => {
        let data = {};
        const callback = response.data;
        //depending on token, sync calendar account
        if (callback.microsoft_token) {
          const { refresh_token } = callback.microsoft_token;
          data = {
            provider: "microsoft",
            refresh_token: refresh_token,
          };
          syncCalendarAccount.mutate(data);
        }
        if (callback.google_token) {
          const { refresh_token } = callback.google_token;
          data = {
            provider: "google",
            refresh_token: refresh_token,
          };
          syncCalendarAccount.mutate(data);
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const provider = getCookie("provider") ? getCookie("provider") : "";
        const msg = socialLoginCallbackMsgHandler(
          error.status,
          capitalize(provider),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        routeTo("syncCalendar", { code: null });
      },
    },
  );

  return (
    <>
      <PageHeaderPanel
        iconClass="fa fa-refresh"
        title={out("Synchronisation du calendrier", "Sync Calendar")}
      />

      <Row className="mt-3">
        <Col xs={12} lg={6}>
          <MicrosoftSync
            calendarAccountIsError={calendarAccountIsError}
            calendarAccountError={calendarAccountError}
            errorStatusCode={errorStatus}
            hasError404={hasError404}
            error404Data={error404Data}
            isLoading={
              socialLoginCallBack.isLoading ||
              syncCalendarAccount.isLoading ||
              calendarAccountIsFetching
            }
            calendarAccount={calendarAccount}
            setShowProviderLoginModal={setShowProviderLoginModal}
            desyncAccount={() => {
              desyncAccount.mutate();
            }}
          />
        </Col>
        <Col xs={12} lg={6}>
          <GoogleSync
            calendarAccountIsError={calendarAccountIsError}
            calendarAccountError={calendarAccountError}
            errorStatusCode={errorStatus}
            hasError404={hasError404}
            error404Data={error404Data}
            isLoading={
              socialLoginCallBack.isLoading ||
              syncCalendarAccount.isLoading ||
              calendarAccountIsFetching
            }
            calendarAccount={calendarAccount}
            setShowProviderLoginModal={setShowProviderLoginModal}
            desyncAccount={() => {
              desyncAccount.mutate();
            }}
          />
        </Col>
      </Row>
      {/*modal*/}
      {showProviderLoginModal && (
        <ProviderLoginModal
          show={showProviderLoginModal}
          onHide={() => setShowProviderLoginModal(false)}
          login={() => {
            dispatch(showLoadingBarWithoutMessage(200000));
            socialLogin.mutate(showProviderLoginModal);
            setCookie("provider", showProviderLoginModal);
          }}
          provider={showProviderLoginModal}
        />
      )}
    </>
  );
};

export default CalendarSyncPage;
