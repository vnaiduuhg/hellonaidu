import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import ScolagoSettingsComponent from "../components/scolago/ScolagoSettingsComponent";
import { ComponentLoader } from "global/components/loaders/component-loader";
import {
  getScolagoAccountMsgHandler,
  syncScolagoAccountMsgHandler,
  unsyncScolagoAccountMsgHandler,
} from "../utils/scolagoMessagesHandler";
import {
  isScolagoAccountSynced,
  syncScolagoAccount,
  unsyncScolagoAccount,
} from "global/apis/scolagoApis";

const ScolagoSettingsPage = () => {
  const { out } = useTranslation();
  const [isAccountSynced, setIsAccountSynced] = useState(false);

  const permissions = useSelector((s) => s.user.permissions);
  const hasAccess = permissions.isSuperUser || permissions.isAdminRecruiter;
  const accountId = useSelector((s) => s.user.data.user_account.account_id);

  const [errorStatus, setErrorStatus] = useState(null);
  const queryClient = useQueryClient();
  const dispatch = useDispatch();

  const translatedTitle = out("Scolago paramètres", "Scolago Settings");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const {
    data: scolagoAccount = false,
    isError: scolagoAccountIsError,
    isFetching: scolagoAccountIsFetching,
  } = useQuery("scolago-account", () => isScolagoAccountSynced(accountId), {
    ...REACT_QUERY_GETTER_OPTIONS,
    staleTime: 0,
    onSuccess: (response) => {
      setIsAccountSynced(response);
    },
    onError: (error) => {
      if (error.status === 404) {
        queryClient.setQueryData(["scolago-account"], false);
        setIsAccountSynced(false);
      } else {
        const msg = getScolagoAccountMsgHandler(error.status, hasAccess);
        setErrorStatus(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 4000));
      }
    },
  });

  const syncAccount = useMutation((data) => syncScolagoAccount(data), {
    onSuccess: (response) => {
      queryClient.invalidateQueries("scolago-account");
      setIsAccountSynced(true);
    },
    onError: (error) => {
      const msg = syncScolagoAccountMsgHandler(error.status, error.data);
      setErrorStatus(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 4000));
    },
  });

  const unsyncAccount = useMutation(() => unsyncScolagoAccount(accountId), {
    onSuccess: (response) => {
      queryClient.invalidateQueries("scolago-accounts");
      setIsAccountSynced(false);
    },
    onError: (error) => {
      const msg = unsyncScolagoAccountMsgHandler(error.status);
      setErrorStatus(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 4000));
    },
  });

  return (
    <ScolagoSettingsComponent
      unsyncAccount={() => {
        unsyncAccount.mutate();
      }}
      syncAccount={(data) => {
        syncAccount.mutate(data);
      }}
      isAccountSynced={isAccountSynced}
    />
  );
};

export default ScolagoSettingsPage;
