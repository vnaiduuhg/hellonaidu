import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation } from "global/utils/useTranslation";
import DocusignAuthComponent from "../components/docusign/DocusignAuthComponent";
import {
  getDocusignAuthRedirectionApi,
  postDocusignAuthApi,
  deleteDocusignAccountApi,
} from "global/apis/eSigningApi";
import {
  docusignAuthRedirectionMsgHandler,
  saveDocusignAccountMsgHandler,
  deleteDocusignAccountMsgHandler,
} from "../utils/docusign-auth-msgs-handler";
import { useDocusignAccount } from "global/hooks/useDocusignAccount";
import { ComponentLoader } from "global/components/loaders/component-loader";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { getUrlParam, routeTo } from "global/utils/utils";

const DocusignAuthPage = () => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const history = useHistory();
  const [processData, setProcessData] = useState(false);

  useEffect(() => {
    const codeUrlParam = getUrlParam("code");
    if (codeUrlParam) {
      setProcessData(true);
      dispatch(showLoadingBarWithoutMessage(200000));
      saveDocusignAccount.mutate({ code: codeUrlParam });
    }
    return () => {};
  }, []);

  // gets docusign account information
  const {
    data: docusignAccount = null,
    isLoading: docusignAccountIsLoading,
    isFetched: docusignAccountIsFetched,
    isError: docusignAccountIsError,
    error: docusignAccountError,
  } = useDocusignAccount();

  // gets redirection to authenticate w/ docusign
  const getDocusignAuthRedirection = useMutation(
    () => getDocusignAuthRedirectionApi(),
    {
      onSuccess: (response) => {
        if (response.data) {
          window.location = response.data;
        } else {
          const msg = docusignAuthRedirectionMsgHandler(500, () =>
            history.replace("/"),
          );
          dispatch(showMessage("error", msg.title, msg.text, 8000));
        }
        setProcessData(false);
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        setProcessData(false);
        const msg = docusignAuthRedirectionMsgHandler(500, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // sync the docusign account on Atlas
  const saveDocusignAccount = useMutation((data) => postDocusignAuthApi(data), {
    onSuccess: (response) => {
      if (response.data) {
        queryClient.invalidateQueries("docusign-account");
        const msg = saveDocusignAccountMsgHandler(200, () =>
          history.replace("/"),
        );
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
      } else {
        const msg = saveDocusignAccountMsgHandler(500, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      }
      setProcessData(false);
      dispatch(statusMessagesSlice.actions.clearLoaders());
      routeTo("integrations-slug-slug", {
        a: "onboarding",
        b: "docusign",
        code: null,
      });
    },
    onError: (error) => {
      setProcessData(false);
      const msg = saveDocusignAccountMsgHandler(error.status, () =>
        history.replace("/"),
      );
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      routeTo("integrations-slug-slug", {
        a: "onboarding",
        b: "docusign",
        code: null,
      });
    },
  });

  const deleteDocusignAccount = useMutation(() => deleteDocusignAccountApi(), {
    onSuccess: () => {
      queryClient.invalidateQueries("docusign-account");
      setProcessData(false);
      const msg = deleteDocusignAccountMsgHandler(204, () =>
        history.replace("/"),
      );
      dispatch(showMessage("ok", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
    onError: (error) => {
      setProcessData(false);
      const msg = deleteDocusignAccountMsgHandler(error.status, () =>
        history.replace("/"),
      );
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  return (
    <div className="d-flex justify-content-center mt-5">
      {docusignAccountIsLoading ? (
        <ComponentLoader
          message={out(
            "Nous téléchargeons vos informations",
            "Loading your information",
          )}
        />
      ) : (
        <DocusignAuthComponent
          docusignAccount={
            docusignAccountIsFetched && docusignAccount?.data
              ? docusignAccount.data
              : null
          }
          docusignAccountIsError={docusignAccountIsError}
          authenticate={() => {
            setProcessData(true);
            dispatch(showLoadingBarWithoutMessage(200000));
            getDocusignAuthRedirection.mutate();
          }}
          disconnect={() => {
            setProcessData(true);
            dispatch(showLoadingBarWithoutMessage(200000));
            deleteDocusignAccount.mutate();
          }}
          processData={processData}
          docusignAccountError={docusignAccountError}
        />
      )}
    </div>
  );
};

export default DocusignAuthPage;
