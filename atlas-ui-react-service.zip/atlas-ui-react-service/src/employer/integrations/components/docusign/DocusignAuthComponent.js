import React, { useState, useEffect } from "react";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import { FaExclamationCircle } from "react-icons/fa";
import styles from "../../styles/Integration.module.scss";
import { Button } from "react-bootstrap";

const DocusignAuthComponent = ({
  docusignAccount,
  docusignAccountIsError,
  authenticate,
  disconnect,
  processData,
  docusignAccountError,
}) => {
  const { out } = useTranslation();
  const [inactiveAccount, setInactiveAccount] = useState(false);

  useEffect(() => {
    if (
      docusignAccountError?.data?.error &&
      docusignAccountError.data.error === "invalid_grant"
    ) {
      setInactiveAccount(true);
    }

    return () => {};
  }, [docusignAccountError]);

  return (
    <div className={styles.integrationGroup}>
      <div
        className={`${styles.descCard} ${styles.floatingCard} ${styles.docusign}`}
      >
        <h3 className="fw-bolder text-center">DocuSign</h3>
        <p className="fs-5 mb-0">
          {out(
            "La signature électronique la plus fiable et la plus utilisée. Plus de 200 millions d'utilisateurs ne peuvent pas se tromper. Le plus sûr et le plus sécurisé. Fonctionne avec de nombreuses applications. Facile à utiliser. N'importe où, sur n'importe quel appareil.",
            "The most trusted and widely used electronic signature. Over 200 million users can't be wrong. The safest and most secure. Works with many apps. Easy to use. Anywhere, on any device.",
          )}
        </p>
        <div className={styles.cardSeparator}></div>
        {(!docusignAccountIsError || inactiveAccount) && (
          <>
            <div className="d-flex justify-content-end fs-5">
              <label>{out("Statut", "Status")}:</label>&nbsp;
              {!docusignAccount && !inactiveAccount && (
                <span className="text-muted">N/A</span>
              )}
              {docusignAccount && !inactiveAccount && (
                <span className="text-success">{out("Actif", "Active")}</span>
              )}
              {inactiveAccount && (
                <span className="text-warning">
                  {out("Inactif", "Inactive")}
                </span>
              )}
            </div>
            {inactiveAccount && (
              <h5 className="text-center text-warning fs-5 fw-light">
                {out("Votre jeton est expiré", "Your token is expired")}
              </h5>
            )}
            {!docusignAccount && (
              <h4 className="text-center text-secondary-200 fs-5">
                {out(
                  "Pour utiliser DocuSign, vous devez vous authentifier",
                  "To use DocuSign, you must authenticate",
                )}
              </h4>
            )}
            {docusignAccount && (
              <h4 className="text-center text-secondary-200 fs-5">
                {out(
                  "Vous êtes connecté à DocuSign",
                  "You are logged in to DocuSign",
                )}
              </h4>
            )}
            <div className="d-flex justify-content-center">
              {(!docusignAccount || inactiveAccount) && (
                <Button
                  variant="secondary"
                  disabled={processData}
                  onClick={() => authenticate()}
                >
                  {out("S'authentifier", "Authenticate")}
                </Button>
              )}
              {docusignAccount && (
                <Button
                  variant="secondary"
                  disabled={processData}
                  onClick={() => disconnect()}
                >
                  {out("Se déconnecter", "Disconnect")}
                </Button>
              )}
            </div>
            {!docusignAccount && (
              <div className="mt-3">
                <AtlasAlert
                  variant="info"
                  icon={<FaExclamationCircle />}
                  className=""
                >
                  <span className="me-1">
                    {out(
                      "Si vous n'êtes pas un client Docusign existant et que vous souhaitez obtenir de l'aide pour activer cette nouvelle fonctionnalité, veuillez nous contacter via",
                      "If you are not an existing Docusign customer and would like assistance in activating this new feature, please contact support",
                    )}
                  </span>
                  <a
                    className="text-decoration-none me-1"
                    href="mailto:support@workland.com"
                  >
                    support@workland.com
                  </a>
                  <span>
                    {out(
                      "et notre équipe expérience client vous aidera avec ce processus.",
                      "and our client success team will assist you in the process.",
                    )}
                  </span>
                </AtlasAlert>
              </div>
            )}
          </>
        )}
        {docusignAccountIsError && !inactiveAccount && (
          <AtlasAlert variant="warning" className="">
            {out(
              "Les informations de votre compte n'ont pu être récupérées",
              "Account information could not be retrieved",
            )}
          </AtlasAlert>
        )}
      </div>
    </div>
  );
};

export default DocusignAuthComponent;
