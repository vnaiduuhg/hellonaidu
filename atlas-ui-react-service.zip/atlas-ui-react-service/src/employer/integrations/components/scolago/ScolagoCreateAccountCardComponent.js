import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../../styles/Integration.module.scss";
import { Button, FloatingLabel, Form } from "react-bootstrap";

const ScolagoCreateAccountCardComponent = ({
  clientId,
  secret,
  onClientIdChange,
  onSecretChange,
  addScolagoAccount,
  onCancel,
  isAccountSynced,
}) => {
  const { out } = useTranslation();
  const accountStatusText = isAccountSynced
    ? out("modifier", "updating")
    : out("créer", "creating");

  return (
    <div className={`${styles.managementCard} ${styles.floatingCard}`}>
      <div className={`${styles.message} text-center`}>
        {out(
          `Vous êtes en train de ${accountStatusText} votre compte.`,
          `You are ${accountStatusText} your account now.`,
        )}
      </div>
      <div>
        <FloatingLabel className="mb-3" label={out("Id client", "Client id")}>
          <Form.Control
            placeholder=" "
            type="text"
            value={clientId}
            onChange={(e) => {
              onClientIdChange(e.target.value);
            }}
          />
        </FloatingLabel>
        <FloatingLabel label={out("Secret", "Secret")}>
          <Form.Control
            placeholder=" "
            type="text"
            value={secret}
            onChange={(e) => {
              onSecretChange(e.target.value);
            }}
          />
        </FloatingLabel>
      </div>
      <div className={`${styles.managementBtnGroup}`}>
        <Button variant="secondary" className="btn-outline" onClick={onCancel}>
          {out("Annuler", "Cancel")}
        </Button>
        <Button
          variant="primary"
          disabled={!clientId || !secret}
          onClick={() => {
            addScolagoAccount({
              substitutus_api_secret: secret,
              substitutus_client_id: clientId,
            });
          }}
        >
          {out("Confirmer", "Confirm")}
        </Button>
      </div>
    </div>
  );
};

export default ScolagoCreateAccountCardComponent;
