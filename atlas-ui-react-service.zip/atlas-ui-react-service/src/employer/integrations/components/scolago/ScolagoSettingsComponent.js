import React, { useState } from "react";
import { useDispatch } from "react-redux";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../../styles/Integration.module.scss";
import { Button } from "react-bootstrap";
import { BiEdit, BiTrash } from "react-icons/bi";
import { ATLAS_UI_URL } from "config";
import ScolagoCreateAccountCardComponent from "./ScolagoCreateAccountCardComponent.js";
import ScolagoDeleteAccountModal from "./ScolagoDeleteAccountModal.js";

const ScolagoSettingsComponent = ({
  unsyncAccount,
  syncAccount,
  isAccountSynced,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const redirectToWorkflowModule = () => {
    window.location = `${ATLAS_UI_URL}workflow-module`;
  };
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [clientId, setClientId] = useState("");
  const [secret, setSecret] = useState("");

  const showForm = () => {
    setIsFormVisible(true);
  };
  const toggleForm = () => {
    setIsFormVisible(!isFormVisible);
  };
  const resetForm = () => {
    setIsFormVisible(false);
    setClientId("");
    setSecret("");
  };

  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);

  return (
    <>
      <div className={`${styles.integrationGroup} justify-content-center mt-5`}>
        <div className={`${styles.descCard} ${styles.floatingCard}`}>
          <div className={`${styles.managementBtnGroup}`}>
            {isAccountSynced && (
              <Button
                variant="danger"
                className="btn btn-frameless-icon"
                onClick={() => {
                  setShowDeleteAccountModal(true);
                }}
              >
                <BiTrash />
              </Button>
            )}
            {isAccountSynced && !isFormVisible && (
              <Button
                variant="secondary"
                className="btn btn-frameless-icon"
                onClick={toggleForm}
              >
                <BiEdit />
              </Button>
            )}
            {!isAccountSynced && !isFormVisible && (
              <Button variant="secondary" onClick={toggleForm}>
                {out("Synchroniser", "Sync")}
              </Button>
            )}
          </div>
          <div className="clearfix">
            <img
              src="https:\/\/scolago.com\/Content\/Images\/Logos\/Colored\/ScolagoWithTextAtRight.svg"
              alt="Scolago logo"
            />
          </div>
          <div className={`${styles.desc}`}>
            <p className="fs-5 mb-0">
              {out(
                "Le moyen simple et rapide de gérer vos absences et remplacements. Scolago est un service de réservation de remplaçants de la nouvelle génération : un outil de connexion sociale en mode libre-service adressé au domaine scolaire. Tant les membres du personnel scolaire que les remplaçants peuvent s'inscrire et utiliser notre service de base, offert gratuitement.",
                "The quick and easy way to manage your absences and replacements. Scolago is a next generation substitute reservation tool: A self-service social connection tool for the education sector. Both school staff and substitutes can register and use our base service, free of charge.",
              )}
            </p>
          </div>
          <div className={`${styles.cardSeparator}`}></div>
          <h4 className="text-center text-secondary-200 fs-5">
            {out(
              "Pour pouvoir utiliser Scolago, vous devez personnaliser votre flux de travail et inclure l'étape désignée.",
              "In order to use Scolago you must customize your workflow and include the designated stage.",
            )}
          </h4>
          <div className="d-flex justify-content-center">
            <Button variant="secondary" onClick={redirectToWorkflowModule}>
              {out("Personnaliser le flux de travail", "Customize workflow")}
            </Button>
          </div>
        </div>
        {isFormVisible && (
          <ScolagoCreateAccountCardComponent
            clientId={clientId}
            secret={secret}
            onClientIdChange={setClientId}
            onSecretChange={setSecret}
            addScolagoAccount={(data) => {
              syncAccount(data);
              toggleForm();
            }}
            onCancel={resetForm}
            isAccountSynced={isAccountSynced}
          />
        )}
      </div>
      {showDeleteAccountModal && (
        <ScolagoDeleteAccountModal
          show={showDeleteAccountModal}
          hide={() => setShowDeleteAccountModal(false)}
          deleteScolagoAccount={() => {
            unsyncAccount();
          }}
        />
      )}
    </>
  );
};

export default ScolagoSettingsComponent;
