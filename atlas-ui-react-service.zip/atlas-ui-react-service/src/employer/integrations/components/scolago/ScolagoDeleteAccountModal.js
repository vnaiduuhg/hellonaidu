import React from "react";
import { Button, Modal } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";

const ScolagoDeleteAccountModal = ({ show, hide, deleteScolagoAccount }) => {
  const { out } = useTranslation();
  return (
    <Modal show={show} onHide={hide}>
      <form
        onSubmit={() => {
          deleteScolagoAccount();
          hide();
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title>{out("Êtes-vous sûr?", "Are you sure?")}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <p>
            {out(
              "Le compte Scolago sera supprimé maintenant.",
              "Account Scolago will be deleted now.",
            )}
          </p>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" type="submit">
            {out("Supprimer", "Delete")}
          </Button>

          <Button variant="alt-secondary" type="reset" onClick={() => hide()}>
            {out("Annuler", "Cancel")}
          </Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default ScolagoDeleteAccountModal;
