import { Redirect, Route, Switch } from "react-router";
import DocusignAuthPage from "./pages/DocusignAuthPage";
import ScolagoSettingsPage from "./pages/ScolagoSettingsPage";
import { IntegrationsNavbar } from "./integrations-navbar/integrations-navbar";

export const Integrations = () => {
  return (
    <>
      <div className="page-wrapper-internal-page">
        <div className="sidebar-container">
          <IntegrationsNavbar />
        </div>

        <div className="content-container">
          <div className="px-4 py-3 h-100">
            <Switch>
              <Route path="/integrations" exact>
                <Redirect to="/integrations/replacement/scolago-settings" />
              </Route>

              <Route path="/integrations/replacement" exact>
                <Redirect to="/integrations/replacement/scolago-settings" />
              </Route>

              <Route
                path="/integrations/replacement/scolago-settings"
                component={ScolagoSettingsPage}
                exact
              />

              <Route path="/integrations/onboarding" exact>
                <Redirect to="/integrations/onboarding/docusign" />
              </Route>
              <Route
                path="/integrations/onboarding/docusign"
                component={DocusignAuthPage}
                exact
              />

              <Redirect to="/404" />
            </Switch>
          </div>
        </div>
      </div>
    </>
  );
};
