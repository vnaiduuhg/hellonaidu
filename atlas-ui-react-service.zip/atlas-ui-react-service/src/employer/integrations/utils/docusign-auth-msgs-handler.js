import { out } from "global/utils/useTranslation";
import { error401 } from "global/utils/_commonApiStatusMessages";

export const docusignAuthRedirectionMsgHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour créer un compte DocuSign",
        "You do not have the required permission to create a DocuSign account",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite et nous ne pouvons actuellement vous rediriger vers le portail de DocuSign, veuillez contacter support@workland.com si le problème persiste",
        "An error has occurred and we cannot currently redirect you to the DocuSign portal, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const saveDocusignAccountMsgHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Votre compte DocuSign a été activé avec succès!",
        "Your DocuSign account has been successfully activated!",
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour créer un compte DocuSign",
        "You do not have the required permission to create a DocuSign account",
      );
      break;
    /* @not sure it worth handling this case
		case 422:
      break; */
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite pendant la création du compte DocuSign, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred while creating DocuSign account, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const deleteDocusignAccountMsgHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Votre compte DocuSign a été désactivé avec succès!",
        "Your DocuSign account has been successfully deactivated!",
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour désactiver un compte DocuSign",
        "You do not have the required permission to deactivate a DocuSign account",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite pendant la désactivation du compte DocuSign, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred while deactivating DocuSign account, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};
