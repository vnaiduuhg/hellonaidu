import { out } from "global/utils/useTranslation";

const tokenExpiredMsg = {
  title: out("Votre jeton est expirée.", "Your token has expired."),
  text: out("Veuillez vous connecter à nouveau.", "Please log in again."),
};

const alertMessageTitle = out(
  "An error has occurred.",
  "Une erreur s'est produite.",
);

export const getScolagoAccountMsgHandler = (code, hasAccess) => {
  let msg = {
    title: alertMessageTitle,
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Terminé", "Done");
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 404:
      if (!hasAccess) {
        msg.text = out(
          "Le compte n'est pas synchronisé. Veuillez vous adresser à votre administrateur.",
          "The account is not synced. Please refer to your administrator.",
        );
      }
      break;
    default:
      msg.text = out(
        "Désolé, nous n'avons pas pu vérifier votre compte Scolago. Veuillez réessayer ou contacter notre équipe d'assistance à l'adresse support@workland.com pour plus d'aide.",
        "Sorry, we could not verify your Scolago account. Please try again or contact our support team at support@workland.com for further assistance.",
      );
  }

  return msg;
};

export const syncScolagoAccountMsgHandler = (code, message) => {
  let msg = {
    title: alertMessageTitle,
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Terminé", "Done");
      msg.text = out(
        "Le compte Scolago est modifié avec succès",
        "Scolago account is updated successfully",
      );
      break;
    case 201:
      msg.title = out("Terminé", "Done");
      msg.text = out(
        "Le compte Scolago est sauvegardé avec succès",
        "Scolago account is saved successfully",
      );
      break;
    case 401:
      if (message === "invalid_client") {
        msg.text = out(
          "Nous n'avons pas trouvé le compte. Veuillez vérifier vos données.",
          "We did not find the account. Please verify your data.",
        );
      } else {
        msg = tokenExpiredMsg;
      }
      break;
    default:
      msg.text = out(
        "Veuillez réessayer ou contacter notre équipe d'assistance à l'adresse support@workland.com pour plus d'aide.",
        "Please try again or contact our support team at support@workland.com for further assistance.",
      );
  }

  return msg;
};

export const unsyncScolagoAccountMsgHandler = (code) => {
  let msg = {
    title: alertMessageTitle,
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Terminé", "Done");
      msg.text = out("Compte supprimé", "Account deleted");
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 404:
      msg.text = out(
        "Désolé, nous n'avons pas trouvé le compte.",
        "Sorry, we did not find the account.",
      );
      break;
    default:
      msg.text = out(
        "Désolé, nous n'avons pas pu supprimer votre compte Scolago. Veuillez réessayer ou contacter notre équipe d'assistance à l'adresse support@workland.com pour plus d'aide.",
        "Sorry, we could not delete your Scolago account. Please try again or contact our support team at support@workland.com for further assistance.",
      );
  }

  return msg;
};
