export const integrationsRoutes = Object.freeze([
  {
    title: { en: "Replacement", fr: "Remplacement" },
    icon: "arrow-right-arrow-left",
    name: "integrations",
    path: "replacement/scolago-settings",
    children: [
      {
        title: { en: "Scolago", fr: "Scolago" },
        name: "replacement.scolago-settings",
        path: "replacement/scolago-settings",
      },
    ],
  },
  {
    title: { en: "Onboarding & Integration", fr: "Accueil & Integration" },
    icon: "pen-clip",
    name: "onboarding",
    path: "onboarding/docusign",
    children: [
      {
        title: { en: "DocuSign", fr: "DocuSign" },
        name: "onboarding.docusign",
        path: "onboarding/docusign",
      },
    ],
  },
]);
