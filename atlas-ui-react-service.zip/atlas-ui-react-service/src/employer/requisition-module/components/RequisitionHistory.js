import React from "react";
import { Card } from "react-bootstrap";
import { ComponentLoader } from "global/components/loaders/component-loader";
import RequisitionHistoryEntry from "./RequisitionHistoryEntries";
import { useTranslation } from "global/utils/useTranslation";

const RequisitionHistory = ({ data, isError, isLoading }) => {
  const { out } = useTranslation();

  let content;
  if (data) {
    content = data ? (
      <RequisitionHistoryEntry {...data} />
    ) : (
      <div className="text-center mt-4">
        {out("Aucun historique disponible.", "No history available.")}
      </div>
    );
  }

  return (
    <Card className="p-3 h-100">
      <Card.Title className="text-center">
        <h3>{out("Historique", "History")}</h3>
      </Card.Title>
      <Card.Body>
        {isLoading && (
          <ComponentLoader
            message={out(
              "Chargement de l'historique",
              "Loading requisition history",
            )}
          />
        )}
        {/* TODO: use styling from ng-app to mimic same errors the same way */}
        {isError && (
          <div className="center text-warning">
            {out("Une erreur s'est produite.", "An error occurred.")}
          </div>
        )}

        {data && content}
      </Card.Body>
    </Card>
  );
};

export default RequisitionHistory;
