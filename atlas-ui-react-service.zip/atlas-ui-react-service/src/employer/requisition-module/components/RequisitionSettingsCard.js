import React, { useRef, useEffect } from "react";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import RequisitionSettingsForm from "./RequisitionSettingsForm";
import { useTranslation } from "global/utils/useTranslation";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasSelect } from "global/components/select/atlas-select";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { FaRegTrashAlt } from "react-icons/fa";
import cx from "classnames";
import { Button } from "react-bootstrap";
import { FiEdit } from "react-icons/fi";
import { AtlasAlert } from "global/components/atlas-alert";
import style from "../assets/RequisitionSettingsUI.module.css";

const RequisitionSettingsCard = ({
  rolesList,
  title,
  saveItem,
  updateItem,
  deleteItem,
  editMode,
  setEditMode,
  deleteMode,
  setDeleteMode,
  saveMode,
  setSaveMode,
  refreshInputs,
  setRefreshInputs,
  showUpdateLoader,
  setUpdateLoader,
  showSaveLoader,
  setSaveLoader,
  list = [],
  data = null,
  isError = null,
  isLoading = null,
}) => {
  const dataRef = useRef();
  const { out } = useTranslation();

  useEffect(() => {
    dataRef.current = data;
  }, []);

  // @temp - need to wait the rendering before to unset the delete loader
  useEffect(() => {
    if (dataRef.current !== data) {
      dataRef.current = data;
      setDeleteMode(0);
    }
  });

  let content;
  if (data) {
    content = (
      <Col
        xs={12}
        as="section"
        className={style.requisition_settings__body__settings_view}
      >
        {/* Hiring manager departments & Hire types & Groups section */}
        {title !== "Requisition Reviewer" &&
          title !== "Évaluateur de réquisition" && (
            <Row>
              <Col xs={12} lg={6} className={`mb-4 ${style.left}`}>
                <RequisitionSettingsForm
                  setEditMode={setEditMode}
                  saveItem={saveItem}
                  refreshInputs={refreshInputs}
                  setRefreshInputs={setRefreshInputs}
                  title={title}
                  showLoader={showSaveLoader}
                  setShowLoader={setSaveLoader}
                />
              </Col>
              {/* item list subsection */}
              {data && data.length > 0 && (
                <Col xs={12} lg={6} className={style.settingItemsDisplay}>
                  <ul className={style.requisitionCard}>
                    {data.map((entry) => (
                      <li
                        className={`px-3 pt-4 pb-2 ${style.requisition_settings__body__content__card}`}
                        key={entry.id}
                      >
                        <h3>
                          {out(
                            entry.translations[1].name,
                            entry.translations[0].name,
                          )}
                        </h3>
                        <p
                          className={
                            style.requisition_settings__body__content__description
                          }
                        >
                          <i>
                            {out(
                              entry.translations[0].name,
                              entry.translations[1].name,
                            )}
                          </i>
                        </p>
                        {deleteMode > 0 && deleteMode === entry.id && (
                          <div className="position-absolute top-50 start-50 translate-middle">
                            <ComponentLoader
                              message={out(
                                "Veuillez patienter...",
                                "Please wait...",
                              )}
                            />
                          </div>
                        )}
                        <div
                          className={
                            style.requisition_settings__body__content__actions
                          }
                        >
                          {/* item edit subsection */}
                          {!editMode && editMode !== entry.id && (
                            <div>
                              <Button
                                variant="secondary"
                                size="lg"
                                className="btn-frameless-icon"
                                disabled={editMode === entry.id}
                                onClick={() => setEditMode(entry.id)}
                              >
                                <FiEdit />
                              </Button>
                              <Button
                                variant="danger"
                                size="lg"
                                className="btn-frameless-icon"
                                disabled={deleteMode === entry.id}
                                onClick={() => {
                                  setDeleteMode(entry.id);
                                  deleteItem(entry.id);
                                }}
                              >
                                <FaRegTrashAlt />
                              </Button>
                            </div>
                          )}
                          {editMode > 0 && editMode === entry.id && (
                            <Col xs={12} className={style.left}>
                              <RequisitionSettingsForm
                                setEditMode={setEditMode}
                                saveItem={updateItem}
                                initialEnTitle={entry.translations[0].name}
                                initialFrTitle={entry.translations[1].name}
                                itemId={entry.id}
                                showCancelBtn={true}
                                showLoader={showUpdateLoader}
                                setShowLoader={setUpdateLoader}
                              />
                            </Col>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </Col>
              )}
              {data.length < 1 && (
                <Col xs={12} lg={6}>
                  <h5 className={`text-center ${style.settingItemsNoData}`}>
                    {out("Vous n'avez pas encore créé de ", "You have no ")}
                    {title.toLowerCase()} {out("", " for the moment")}
                  </h5>
                </Col>
              )}
            </Row>
          )}
        {/* Reviewers section */}
        {(title === "Requisition Reviewer" ||
          title === "Évaluateur de réquisition") && (
          <Row>
            <Col xs={12} lg={6} className={style.left}>
              <div className={cx("mt-5", { "visually-hidden": !saveMode })}>
                <ComponentLoader
                  message={out("Veuillez patienter...", "Please wait...")}
                />
              </div>

              <div className={cx({ "visually-hidden": saveMode })}>
                <h2 className="mt-md-4 ps-1 mb-3 h4">
                  {out(
                    "Ajouter des évaluateurs de réquisition",
                    "Add requisition reviewers",
                  )}
                </h2>

                {list.length > 0 && (
                  <AtlasSelect
                    placeholder={out(
                      "Sélectionnez un évaluateur de réquisition",
                      "Select a requisition reviewer",
                    )}
                    value={0}
                    onChange={({ value }) => {
                      if (value && Number.isInteger(value)) {
                        saveItem(value);
                        setSaveMode(true);
                      } else {
                        // show error msg under input
                      }
                    }}
                    options={list
                      .map((member) =>
                        !data.find((item) => item.id === member.user.id)
                          ? {
                              value: member.user.id,
                              label: `${member.user.first_name} ${member.user.last_name}`,
                            }
                          : null,
                      )
                      .filter((e) => e !== null)}
                  />
                )}
              </div>
            </Col>
            {/* reviewers list subsection */}
            {data.length > 0 && (
              <Col xs={12} lg={6} className={style.settingItemsDisplay}>
                <ul className={style.requisitionCard}>
                  {data.map((item) => (
                    <li
                      className={`px-3 py-2 ${style.requisition_settings__body__content__card}`}
                      key={item.id}
                    >
                      <h3>
                        {item.first_name}&nbsp;
                        {item.last_name}
                      </h3>
                      <p
                        className={
                          style.requisition_settings__body__content__description
                        }
                      >
                        {rolesList.length > 0 &&
                          rolesList.map((role) => {
                            if (+role.id === +item.pivot.account_user.role_id) {
                              return (
                                <i key={role.id}>
                                  {out(
                                    role.translation.fr.name,
                                    role.translation.en.name,
                                  )}
                                </i>
                              );
                            } else {
                              return undefined;
                            }
                          })}
                      </p>
                      {deleteMode > 0 && deleteMode === item.id && (
                        <div className="position-absolute top-50 start-50 translate-middle">
                          <ComponentLoader
                            message={out(
                              "Veuillez patienter...",
                              "Please wait...",
                            )}
                          />
                        </div>
                      )}
                      <div
                        className={
                          style.requisition_settings__body__content__actions
                        }
                      >
                        <div>
                          <Button
                            variant="danger"
                            size="lg"
                            className="btn-frameless-icon"
                            disabled={deleteMode === item.id}
                            onClick={() => {
                              setDeleteMode(item.id);
                              deleteItem(item.id);
                            }}
                          >
                            <FaRegTrashAlt />
                          </Button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </Col>
            )}
            {data.length < 1 && (
              <Col xs={12} lg={6}>
                <h5 className={`text-center ${style.settingItemsNoData}`}>
                  {out("Vous n'avez pas de ", "You have no ")}
                  {title.toLowerCase()}{" "}
                  {out("pour l'instant", " for the moment")}
                </h5>
              </Col>
            )}
          </Row>
        )}
      </Col>
    );
  }

  return (
    <>
      {isLoading && (
        <NestedPageLoader
          message={out("Veuillez patienter...", "Please wait...")}
        />
      )}

      {isError && (
        <AtlasAlert variant="error" className="mt-5">
          {out(
            "Impossible de récupérer les données",
            "Could not retrieve data",
          )}
        </AtlasAlert>
      )}
      {data && content}
    </>
  );
};

export default RequisitionSettingsCard;
