import React, { useState } from "react";
import { batch } from "react-redux";
import { Button, Col, Modal, Row } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import SingleDatePicker from "global/components/form-hook/date-picker/SingleDatePicker";

const DateFilterModal = ({
  show,
  hide,
  startDate,
  endDate,
  today,
  setStartDate,
  setEndDate,
  setDateFilter,
  setPage,
}) => {
  const { out } = useTranslation();
  const [validationError, setValidationError] = useState(false);
  const validateDates = () => {
    if (startDate < endDate) {
      batch(() => {
        setPage(1);
        setDateFilter({
          beforeDate: endDate,
          afterDate: startDate,
        });
      });
      hide();
    } else {
      setValidationError(true);
    }
  };

  return (
    <Modal show={show} onHide={hide}>
      <Modal.Header closeButton>
        <Modal.Title>
          {out(
            "Rechercher des réquisitions par date",
            "Search requisitions by date",
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Row>
          <Col
            xs={12}
            sm={6}
            onFocus={() => {
              setValidationError(false);
            }}
          >
            <SingleDatePicker
              id="start-date"
              label={out("Date de début", "Start Date")}
              date={startDate}
              setDate={setStartDate}
            />
          </Col>
          <Col
            xs={12}
            sm={6}
            onFocus={() => {
              setValidationError(false);
            }}
          >
            <SingleDatePicker
              id="end-date"
              label={out("Date de fin", "End Date")}
              date={endDate}
              setDate={setEndDate}
            />
          </Col>
        </Row>
        {validationError && (
          <Row>
            <Col className="mt-2 fs-7 text-danger">
              *&nbsp;
              {out(
                "Veuillez sélectionner une date de début antérieure à la date de fin",
                "Please select a start date earlier than the end date",
              )}
            </Col>
          </Row>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="primary"
          type="submit"
          disabled={!startDate || !endDate}
          onClick={() => {
            validateDates();
          }}
        >
          {out("Rechercher", "Search")}
        </Button>
        <Button
          variant="alt-secondary"
          onClick={() => {
            setStartDate(null);
            setEndDate(today);
            batch(() => {
              setPage(1);
              setDateFilter({
                beforeDate: null,
                afterDate: null,
              });
            });

            hide();
          }}
        >
          {out("Annuler", "Cancel")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default DateFilterModal;
