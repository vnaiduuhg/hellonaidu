import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useParams } from "react-router";
import cx from "classnames";
import Button from "react-bootstrap/Button";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";
import { useTranslation } from "global/utils/useTranslation";
import { HorizontalSectionSeperator } from "global/components/HorizontalSectionSeperator";
import style from "../../pages/RequisitionWizardPages.module.css";
import styles from "./wizard-page.module.css";
import { Form } from "react-bootstrap";
import { FormHookSelect } from "global/components/form-hook/select/FormHookSelect";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { BsFillExclamationTriangleFill } from "react-icons/bs";

const ManpowerInfos = ({
  requisitionGroups: allRequisitionGroups,
  hireTypes: hireTypesAll,
  requisition,
}) => {
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const history = useHistory();
  const { id: paramId } = useParams();
  const [requisitionGroupNoLongerExists, setRequisitionGroupNoLongerExists] =
    useState(false);
  const [hireTypeNoLongerExists, setHireTypeNoLongerExists] = useState(false);
  const language = useSelector((state) => state.user.language);

  const langIndex = language === "en" ? 0 : 1;

  const {
    control,
    register,
    handleSubmit,
    watch,
    trigger,
    setValue,
    getValues,
    formState: { errors },
  } = useForm({
    defaultValues: {
      hiringType: "",
      ...requisition,

      requisition: {
        within_budget: "false",
        yearly_manpower_plan: "false",
        is_diversity_plan: "false",
        ...(requisition?.requisition ?? {}),
      },
    },
  });

  const title = out(
    requisitionWizardSteps[3].title.fr,
    requisitionWizardSteps[3].title.en,
  );
  useEffect(() => {
    document.title = title + " - Workland";
  }, [title]);

  const onSubmit = (data) => {
    dispatch(
      requisitionWizardSlice.actions.saveDataInStep({
        id: paramId,
        data: JSON.parse(JSON.stringify(data)),
        nextStepName: "additional",
      }),
    );

    history.push("additional");
  };

  const budgetApproved = watch("requisition.within_budget");
  const yearlyManpowerPlan = watch("requisition.yearly_manpower_plan");
  const hiringType = watch("hiringType");

  // react hook form caches validation response. force validation on language
  // change
  const initial = useRef(true);
  useEffect(() => {
    if (!initial.current) trigger();
    initial.current = false;
  }, [language, trigger]);

  const originalHireType = useRef(undefined);
  useEffect(() => {
    if (requisition?.hiringType) {
      originalHireType.current = requisition.hiringType;
    }

    if (
      originalHireType.current &&
      hireTypesAll &&
      !hireTypesAll.find((d) => d.name === originalHireType.current)
    ) {
      // no longer exists: deleted or renamed
      setValue("hiringType", undefined);
      setHireTypeNoLongerExists(true);
    }
  }, [requisition, hireTypesAll, setValue]);

  const originalRequisitionGroup = useRef(undefined);
  useEffect(() => {
    if (requisition?.requisitionGroups) {
      originalRequisitionGroup.current = requisition.requisitionGroups;
    }

    if (
      originalRequisitionGroup.current &&
      allRequisitionGroups &&
      !allRequisitionGroups.find(
        (d) => d.name === originalRequisitionGroup.current,
      )
    ) {
      // no longer exists: deleted or renamed
      setValue("requisitionGroups", undefined);
      setRequisitionGroupNoLongerExists(true);
    }
  }, [requisition, allRequisitionGroups, setValue]);

  return (
    <div id="manpowerInfos" className={styles.container}>
      <h2 className="visually-hidden">{title}</h2>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-1 user-select-none">
          <span className={styles.formText}>
            {out(
              "Ce poste fait-il partie du plan budgétaire annuel ?",
              "Is this position part of the yearly budget plan?",
            )}
            <span className={style.mandatory}>&nbsp;*</span>
          </span>

          <Form.Check type="radio" className="form-check-inline ms-3">
            <Form.Check.Input
              id="yearly_manpower_plan_true"
              type="radio"
              name="requisition.yearly_manpower_plan"
              value="true"
              {...register("requisition.yearly_manpower_plan")}
              checked={yearlyManpowerPlan === "true"}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="yearly_manpower_plan_true"
            >
              {out("Oui", "Yes")}
            </Form.Check.Label>
          </Form.Check>

          <Form.Check type="radio" className="form-check-inline">
            <Form.Check.Input
              id="yearly_manpower_plan_false"
              type="radio"
              value="false"
              name="requisition.yearly_manpower_plan"
              {...register("requisition.yearly_manpower_plan")}
              checked={yearlyManpowerPlan === "false"}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="yearly_manpower_plan_false"
            >
              {out("Non", "No")}
            </Form.Check.Label>
          </Form.Check>
        </div>

        <div className="mt-3">
          <label htmlFor="requisitionGroup" className={styles.formText}>
            {out("Groupe de réquisition", "Requisition group")}
            <span className={style.optional}>
              {out(" (optionnel)", " (optional)")}
            </span>
          </label>

          {allRequisitionGroups === null ? (
            <ComponentLoader
              message={out("Nous récupérons les groups", "Fetching groups")}
              wait={true}
            />
          ) : (
            <FormHookSelect
              control={control}
              id="requisitionGroups"
              name="requisitionGroups"
              defaultValue={getValues("requisitionGroups")}
              placeholder={out("Aucun groupe sélectionné", "No group selected")}
              options={allRequisitionGroups.map((r) => ({
                label: r.translations[langIndex].name,
                value: r.name,
              }))}
              setValue={setValue}
            />
          )}

          <div
            className="text-info mt-0 mb-2 px-0"
            hidden={!requisitionGroupNoLongerExists}
          >
            <div className="text-center">
              <div
                className={`ps-2 align-self-center fw-bold ${styles.smallerText}`}
              >
                <span className="h-100 fs-5 p-1 me-1">
                  <BsFillExclamationTriangleFill />
                </span>
                {out(
                  `Veuillez noter que le groupe de demande d'achat initial ne figure plus dans la liste des groupes disponibles.`,
                  `Please note that the original requisition group is no longer on the list of available groups.`,
                )}
              </div>
            </div>
          </div>

          {allRequisitionGroups?.length < 1 && (
            <div className="text-center">
              <h4 className={style.emptyList}>
                <i className="fa fa-exclamation-triangle" />
                &nbsp;
                {out(
                  "Aucun groupe de réquisition disponible",
                  "No requisition group available",
                )}
              </h4>
            </div>
          )}
        </div>

        <HorizontalSectionSeperator />

        <div className="mb-1 user-select-none">
          <span className={styles.formText}>
            {out("Le budget est-il approuvé ?", "Is the budget approved?")}
            <span className={style.mandatory}>&nbsp;*</span>
          </span>

          <Form.Check type="radio" className="form-check-inline ms-3">
            <Form.Check.Input
              type="radio"
              id="within_budget_true"
              name="requisition.within_budget"
              value="true"
              {...register("requisition.within_budget")}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="within_budget_true"
            >
              {out("Oui", "Yes")}
            </Form.Check.Label>
          </Form.Check>

          <Form.Check type="radio" className="form-check-inline">
            <Form.Check.Input
              type="radio"
              id="within_budget_false"
              name="requisition.within_budget"
              value="false"
              {...register("requisition.within_budget")}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="within_budget_false"
            >
              {out("Non", "No")}
            </Form.Check.Label>
          </Form.Check>
        </div>

        {budgetApproved === "false" && (
          <FormHookFloatingLabel
            type="textarea"
            style={{ height: "9.313rem" }}
            control={control}
            name="budgetApprovalReason"
            title={
              <>
                {out("Explication", "Explanation")}
                <span className={style.mandatory}>&nbsp;*</span>&nbsp;
                <small>({out("Budget", "Budget")})</small>
              </>
            }
            rules={{
              required:
                getValues("requisition.within_budget") === "false"
                  ? out("Explication est requise", "Explanation is required")
                  : false,
              minLength: {
                value: 5,
                message: out(
                  "Explication trop courte",
                  "Explanation too short",
                ),
              },
              maxLength: {
                value: 1000,
                message: out(
                  "Limite maximale de caractères atteinte",
                  "Maximum character limit reached",
                ),
              },
            }}
            mandatory={false}
            error={errors.budgetApprovalReason}
            id="budgetApprovalReason"
            maxLength="1000"
            className="w-100"
            aria-multiline="true"
          />
        )}

        <HorizontalSectionSeperator className="mt-2 mb-4 mx-1 border-0 border-bottom border-gray" />

        <div className="form-group">
          <label htmlFor="hire-type" className={styles.formText}>
            {out("Type d'embauche?", "Hire Type")}
            <span className={style.optional}>
              {out(" (optionnel)", " (optional)")}
            </span>
          </label>

          {hireTypesAll === null ? (
            <ComponentLoader
              message={out(
                "Nous récupérons les types d'embauche",
                "Fetching hire types",
              )}
              wait={true}
            />
          ) : (
            <FormHookSelect
              control={control}
              id="hire-type"
              name="hiringType"
              defaultValue={getValues("hiringType")}
              placeholder={out(
                "Aucun type d'emploi sélectionné",
                "No hire type selected",
              )}
              options={hireTypesAll.map((t) => ({
                label: t.translations[langIndex].name,
                value: t.name,
              }))}
              setValue={setValue}
            />
          )}
          {hireTypesAll?.length < 1 && (
            <div className={cx(["container-fluid", "text-center"])}>
              <h4 className={style.emptyList}>
                <i className="fa fa-exclamation-triangle"></i>&nbsp;
                {out(
                  "Aucun type d'embauche disponible",
                  "No hire type available",
                )}
              </h4>
            </div>
          )}
        </div>

        <div
          className="text-info mt-0 mb-2 px-0"
          hidden={!hireTypeNoLongerExists}
        >
          <div className="text-center">
            <div
              className={`ps-2 align-self-center fw-bold ${styles.smallerText}`}
            >
              <span className="h-100 fs-5 p-1 me-1">
                <BsFillExclamationTriangleFill />
              </span>
              {out(
                `Veuillez noter que le type d'embauche initial ne figure plus dans la liste des types d'embauche disponibles.`,
                `Please note that the original hire type is no longer on the list of available hire types.`,
              )}
            </div>
          </div>
        </div>

        {hiringType && hireTypesAll !== null && (
          <div className="inputField mt-3">
            <div className={errors.explanationHiringType && "text-warning"}>
              <FormHookFloatingLabel
                control={control}
                type="textarea"
                style={{ height: "9.313rem" }}
                name="explanationHiringType"
                title={
                  <>
                    {out("Explication", "Explanation")}
                    <span className={style.mandatory}>&nbsp;*</span>&nbsp;
                    <small>
                      {(() => {
                        const selectedHire = hireTypesAll.find(
                          (h) => h.name === hiringType,
                        );

                        return selectedHire?.translations[langIndex].name
                          ? `(${selectedHire?.translations[langIndex].name})`
                          : "";
                      })()}
                    </small>
                  </>
                }
                rules={{
                  required: out(
                    "Explication est requise",
                    "Explanation is required",
                  ),
                  minLength: {
                    value: 5,
                    message: out(
                      "Explication trop courte",
                      "Explanation too short",
                    ),
                  },
                  maxLength: {
                    value: 1000,
                    message: out(
                      "Limite maximale de caractères atteinte",
                      "Maximum character limit reached",
                    ),
                  },
                }}
                mandatory={false}
                error={errors.explanationHiringType}
                id="explanationHiringType"
                maxLength="1000"
                className="w-100"
                aria-multiline="true"
                aria-invalid="false"
              />
            </div>
          </div>
        )}

        <HorizontalSectionSeperator />

        <div className="mb-1 user-select-none">
          <span className={styles.formText}>
            {out(
              "Ce poste fait-il partie de votre plan de diversité?",
              "Is this position a part of your diversity plan?",
            )}
            <span className={style.mandatory}>&nbsp;*</span>
          </span>

          <Form.Check type="checkbox" className="form-check-inline ms-3">
            <Form.Check.Input
              type="radio"
              id="diversityPlan_true"
              name="diversityPlan"
              value="true"
              {...register("requisition.is_diversity_plan")}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="diversityPlan_true"
            >
              {out("Oui", "Yes")}
            </Form.Check.Label>
          </Form.Check>

          <Form.Check type="checkbox" className="form-check-inline">
            <Form.Check.Input
              id="diversityPlan_false"
              name="diversityPlan"
              type="radio"
              className="form-check-input"
              value="false"
              {...register("requisition.is_diversity_plan")}
            />
            <Form.Check.Label
              className={styles.formText}
              htmlFor="diversityPlan_false"
            >
              {out("Non", "No")}
            </Form.Check.Label>
          </Form.Check>
        </div>

        <div className="mt-3 d-flex justify-content-end">
          <Button type="submit" variant="secondary">
            {out("Suivant", "Next")}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ManpowerInfos;
