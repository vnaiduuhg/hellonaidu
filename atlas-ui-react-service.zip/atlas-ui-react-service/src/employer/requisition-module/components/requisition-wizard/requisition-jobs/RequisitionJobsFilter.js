import { useTranslation } from "global/utils/useTranslation";
import { SearchBar } from "global/components/search-bar/search-bar";
import { BsSearch } from "react-icons/bs";

const RequisitionJobsFilter = ({
  search,
  jobStatusFilter,
  setJobStatusFilter,
}) => {
  const { out } = useTranslation();

  return (
    <SearchBar
      id="jobs-search-bar"
      icon={<BsSearch className="text-secondary fs-5" />}
      label={out("Chercher les postes", "Search jobs")}
      onSearchChange={search}
      filters={[
        { label: out("Publié(s)", "Published"), value: "published" },
        { label: out("Privé(s)", "Private"), value: "private" },
        { label: out("Interne(s)", "Internal"), value: "internal" },
        { label: out("Sous-traité(s)", "Outsourced"), value: "outsourced" },
      ]}
      currentFilter={jobStatusFilter}
      onFilterChange={setJobStatusFilter}
    />
  );
};

export default RequisitionJobsFilter;
