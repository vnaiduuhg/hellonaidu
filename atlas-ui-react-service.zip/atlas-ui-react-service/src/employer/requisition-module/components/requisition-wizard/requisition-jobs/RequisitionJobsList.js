import React, { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Button from "react-bootstrap/Button";
import cx from "classnames";
import useAtlasQuery, {
  REACT_QUERY_GETTER_OPTIONS,
} from "global/utils/useAtlasQuery";
import { getJobsByAccount, getJobsByUser } from "employer/jobs/api/jobApi";
import { utcToTimezone } from "global/utils/dateTimeLanguageUtils";
import { createRequisitionTemplateFromJob } from "employer/requisition-module/store/requisitionWizardSlice";
import { queryClient } from "global/utils/queryClient";
import { useTranslation } from "global/utils/useTranslation";
import { useHistory } from "react-router";
import RequisitionJobsFilter from "./RequisitionJobsFilter";
import style from "../RequisitionWizard.module.css";
import { PaginationBar } from "global/components/pagination/pagination-bar";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { Alert } from "react-bootstrap";
import { FaExclamationTriangle } from "react-icons/fa";

const jobListOptions = {
  user: {
    fn: getJobsByUser,
    key: "user",
  },

  account: {
    fn: getJobsByAccount,
    key: "account",
  },
};

export const RequisitionJobsList = () => {
  const [currentJobPage, setCurrentJobPage] = useState(1);
  const [searchString, setSearchString] = useState("");
  const [jobStatusFilter, setJobStatusFilter] = useState("published");
  const { paginationItemsPerPage } = useSelector((state) => state.settings);

  const pageSize =
    paginationItemsPerPage.createRequisitionFromJob ??
    paginationItemsPerPage.default;

  // set this to account or user based on user
  const {
    language,
    data: {
      user_account: { user_id: userId, role_id: roleId, account_id: accountId },
    },
  } = useSelector((state) => state.user);
  const { out } = useTranslation();
  const history = useHistory();

  const dispatch = useDispatch();

  const permissions = useSelector((s) => s.user.permissions);

  const query =
    permissions.isRecruiter && !permissions.isAdminRecruiter
      ? jobListOptions.user
      : jobListOptions.account;

  const queryParams = {
    tags: {
      // bust cache when switching users & user changes roles promoted/demoted
      roleId,
      userId,
      accountId,
      by: query.key,
      page: currentJobPage,
      // pageSize: PAGE_SIZE,
      pageSize,
      has_requisition: false,
      search: searchString,
      published_external: jobStatusFilter === "published",
      published_internal: jobStatusFilter === "internal",
      published_outsourced: jobStatusFilter === "outsourced",
      load_with: { translations: true },
    },
    query: {
      page: currentJobPage,
      // pageSize: PAGE_SIZE,
      pageSize,
      has_requisition: 0,
      ...(!!searchString ? { search: searchString } : {}),
      published_external: +(jobStatusFilter === "published"),
      published_internal: +(jobStatusFilter === "internal"),
      published_outsourced: +(jobStatusFilter === "outsourced"),
      "load_with[]": ["translations"],
    },
  };

  const { data: jobs, isLoading } = useAtlasQuery(
    [`jobs:${query.key}`, { ...queryParams.tags }],
    () => query.fn({ ...queryParams.query }),
    null,
    {
      title: out("Erreur", "Error"),
      message: out(
        "Désolé, une erreur s'est produite lors de la récupération des postes. Veuillez contacter support@workland.com pour plus d'aide.",
        "Sorry, there was an error while fetching the list of jobs. Please contact our support team at support@workland.com for further assistance.",
      ),
      timeout: 5000,
    },
  );

  const maxPages = useRef(1);
  if (!isLoading) {
    maxPages.current = jobs?.last_page ?? 1;
  }

  // prefetch 2 ahead in both directions.
  if (!isLoading) {
    if (currentJobPage < maxPages.current) {
      queryClient.prefetchQuery(
        [
          `jobs:${query.key}`,
          { ...queryParams.tags, page: currentJobPage + 1 },
        ],
        () => query.fn({ ...queryParams.query, page: currentJobPage + 1 }),
        REACT_QUERY_GETTER_OPTIONS,
      );
    }
    if (currentJobPage + 1 < maxPages.current) {
      queryClient.prefetchQuery(
        [
          `jobs:${query.key}`,
          { ...queryParams.tags, page: currentJobPage + 2 },
        ],
        () => query.fn({ ...queryParams.query, page: currentJobPage + 2 }),
        REACT_QUERY_GETTER_OPTIONS,
      );
    }

    if (currentJobPage - 1 > 0) {
      queryClient.prefetchQuery(
        [
          `jobs:${query.key}`,
          { ...queryParams.tags, page: currentJobPage - 1 },
        ],
        () => query.fn({ ...queryParams.query, page: currentJobPage - 1 }),
        REACT_QUERY_GETTER_OPTIONS,
      );
    }
    if (currentJobPage - 2 > 0) {
      queryClient.prefetchQuery(
        [
          `jobs:${query.key}`,
          { ...queryParams.tags, page: currentJobPage - 2 },
        ],
        () => query.fn({ ...queryParams.query, page: currentJobPage - 2 }),
        REACT_QUERY_GETTER_OPTIONS,
      );
    }
  }

  return (
    <>
      <Row className="mt-2">
        <Col as="h2" className={cx("h4", style["form-label"])}>
          {out("Créer à partir d'un poste", "Create from Job")}
        </Col>
      </Row>

      <Row className="mt-2">
        <RequisitionJobsFilter
          search={setSearchString}
          jobStatusFilter={jobStatusFilter}
          setJobStatusFilter={(status) => {
            setCurrentJobPage(1);
            setJobStatusFilter(status);
          }}
        />
      </Row>

      <div className="mt-4" />

      {isLoading && (
        <div className="py-5">
          <ComponentLoader
            message={out(
              "Nous récupérons les postes",
              "Please wait while jobs are retrieved",
            )}
          />
        </div>
      )}
      {!isLoading && (
        <Row className="mt-3">
          <Col sm={2} className="d-none d-sm-block" />

          {jobs && jobs.data && jobs.data.length > 0 && (
            <>
              <Col xs={12} sm={7} className="fw-bold">
                {out("Poste", "Job")}
              </Col>
              <Col xs={12} sm={3} className="d-none d-sm-block fw-bold">
                {out("Créé le", "Created on")}
              </Col>
            </>
          )}

          <Col xs={12} className="border-bottom border-2 mb-3" />

          {jobs && jobs.data && jobs.data.length > 0 ? (
            jobs.data.map((job, i) => (
              <React.Fragment key={job.id}>
                <Col xs={3} sm={2}>
                  <div className="d-flex justify-content-center p-1 ">
                    <Button
                      variant="secondary"
                      onClick={() =>
                        dispatch(
                          createRequisitionTemplateFromJob(
                            job.id,
                            history.push,
                          ),
                        )
                      }
                    >
                      {out("Créer", "Create")}
                    </Button>
                  </div>
                </Col>
                <Col xs={9} sm={7} className="blueTitle p-sm-1">
                  {language === "en" ? (
                    <>
                      <strong>
                        {job.translations[0]?.title ??
                          out(
                            "Titre anglais n'est pas disponible",
                            "No English title available",
                          )}
                      </strong>
                      <br />
                      <span>
                        {job.translations[1]?.title ??
                          out(
                            "Titre français non disponible",
                            "French title not available",
                          )}
                      </span>
                    </>
                  ) : (
                    <>
                      <strong>
                        {job.translations[1]?.title ??
                          out(
                            "Titre français non disponible",
                            "French title not available",
                          )}
                      </strong>
                      <br />
                      <span>
                        {job.translations[0]?.title ??
                          out(
                            "Titre anglais n'est pas disponible",
                            "No English title available",
                          )}
                      </span>
                    </>
                  )}
                  <div className="d-sm-none mt-2">
                    {utcToTimezone(job.created_at)}
                  </div>
                </Col>
                <Col xs={7} sm={3} className="p-1 d-none d-sm-flex">
                  {utcToTimezone(job.created_at)}
                </Col>

                {i + 1 < jobs.data.length && (
                  <Col xs={12} className="border-1 border-bottom my-2" />
                )}
              </React.Fragment>
            ))
          ) : (
            <Col xs={12} className={`text-center ${style.jobsList}`}>
              <Alert
                variant="info"
                className="d-flex align-items-center justify-content-center"
              >
                <FaExclamationTriangle className="me-2" />
                <div>
                  {out("Aucun poste disponible", "No position available")}
                </div>
              </Alert>
            </Col>
          )}
        </Row>
      )}

      <PaginationBar
        className="mt-4 mb-5 px-2"
        paginationKey="createRequisitionFromJob"
        pages={maxPages.current}
        active={currentJobPage}
        onPageChange={(_, newPageNum) => {
          if (newPageNum) setCurrentJobPage(newPageNum);
        }}
        onDisplayPerPageChange={() => setCurrentJobPage(1)}
      />
    </>
  );
};
