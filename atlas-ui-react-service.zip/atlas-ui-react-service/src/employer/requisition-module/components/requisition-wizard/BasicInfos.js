import React, { useState, useEffect, useRef } from "react";
import { unstable_batchedUpdates } from "react-dom";
import { useSelector } from "react-redux";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import cx from "classnames";
import { Controller, useForm } from "react-hook-form";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import GoogleAutocomplete from "../../../../global/components/GoogleAutocomplete";
import { batch, useDispatch } from "react-redux";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";
import { useTranslation } from "global/utils/useTranslation";
import { useHistory, useParams } from "react-router";
import { getLocationsByKeyAndValues } from "global/apis/locationApi";
import { setFromattedAddress } from "global/utils/locationUtil";
import { showMessage } from "global/store/statusMessagesSlice";
import { emailValidation, nameValidation } from "./validations";
import style from "../../pages/RequisitionWizardPages.module.css";
import { FormSectionHeading } from "global/components/FormSectionHeading/FormSectionHeading";
import moduleStyle from "./RequisitionWizard.module.css";
import styles from "./wizard-page.module.css";
import { FormHookFloatingLabel } from "../../../../global/components/form-hook/regular/FormHookFloatingLabel";
import { AtlasSelect } from "global/components/select/atlas-select";
import { BiWorld } from "react-icons/bi";
import { IoCloseOutline } from "react-icons/io5";
import { BsFillExclamationTriangleFill } from "react-icons/bs";

const BasicInfos = ({
  requisition,
  requisitionReviewers,
  hiringManagerDepartments,
}) => {
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const history = useHistory();
  const { id: paramId } = useParams();
  const [editLocation, setEditLocation] = useState(false);
  const language = useSelector((state) => state.user.language);

  // manually handle locations error because it's a pain in the !#$ to use
  // this validator to work with the autocomplete component
  const [locationsError, setLocationsError] = useState("");
  const [unavailableReviewers, setUnavailableReviewers] = useState(0);
  const [
    hiringManagerDepartmentNoLongerExists,
    setHiringManagerDepartmentNoLongerExists,
  ] = useState(false);

  const {
    control,
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
    getValues,
    trigger,
  } = useForm({
    defaultValues: {
      locations: [],
      currency: "CAD",
      ...requisition,
      requisition: {
        reviewers: [],
        approval_required: false,
        ...(requisition?.requisition ?? {}),
      },
      formattedAddresses: { ...(requisition?.formattedAddresses ?? {}) },
    },
  });

  const onSubmit = (data) => {
    if (!getValues("locations")?.length) {
      setLocationsError(
        out("Lieux de travail est manquant", "Location is missing"),
      );
      return;
    }

    // save
    batch(() => {
      setLocationsError("");
      dispatch(
        requisitionWizardSlice.actions.saveDataInStep({
          id: paramId,
          data: JSON.parse(JSON.stringify(data)),
          nextStepName: "budget",
        }),
      );
    });

    history.push("budget");
  };

  const title = out(
    requisitionWizardSteps[1].title.fr,
    requisitionWizardSteps[1].title.en,
  );
  useEffect(() => {
    document.title = title + " - Workland";
  }, [title]);

  // react hook form caches validation response. force validation on language
  // change
  const initial = useRef(true);
  useEffect(() => {
    if (!initial.current) trigger();
    initial.current = false;
  }, [language, trigger]);

  const approval_required = watch("requisition.approval_required");
  const email = watch("requisition.reports_to_email");
  const selectedReviewers = watch("requisition.reviewers");

  // filter unavailable requisition reviewers from list of approving reviewers
  useEffect(() => {
    if (!requisitionReviewers) return;

    let i = 0;

    const newList = selectedReviewers.filter((r) => {
      if (requisitionReviewers.find((reviewers) => reviewers.id == r)) {
        return true;
      }

      i++;
      return false;
    });

    if (unavailableReviewers !== i && i > 0) {
      setUnavailableReviewers(i);
      setValue("requisition.reviewers", newList);
    }
  }, [requisitionReviewers]);

  // formattedAddressesHash only to dispaly the formatted address
  const formattedAddressesHash = watch("formattedAddresses");

  const handleSelectedLocation = ({ location, formattedAddress }) => {
    let tempLocations = getValues("locations");
    const tempFormattedAddressHash = getValues("formattedAddresses");

    if (!tempLocations.find((l) => l.location_id === location.id)) {
      tempLocations.push({ location_id: location.id });
    }
    if (formattedAddress !== null)
      tempFormattedAddressHash[location.id] = formattedAddress;

    unstable_batchedUpdates(() => {
      setLocationsError("");
      setValue("locations", tempLocations);
      setValue("formattedAddresses", tempFormattedAddressHash);
      setEditLocation(false);
    });
  };

  const deleteLocationHandler = (i) => {
    i = +i;
    let tempLocationsArray = getValues("locations");
    const tempFormattedAddressHash = getValues("formattedAddresses");

    tempLocationsArray = tempLocationsArray.filter(
      (loc) => loc.location_id !== i,
    );
    delete tempFormattedAddressHash[i];

    setValue("locations", tempLocationsArray, {
      shouldDirty: true,
      shouldValidate: true,
    });
    setValue("formattedAddresses", tempFormattedAddressHash);
  };

  useEffect(() => {
    if (
      requisition &&
      requisition.locations &&
      requisition.locations.length > 0
    ) {
      const tempFormattedAddressHash = {};
      const tempLocationsArray = [];
      const arrayOfLocation = requisition.locations.map((l) => l.location_id);

      getLocationsByKeyAndValues(arrayOfLocation)
        .then((response) => {
          if (Object.keys(response).length > 0) {
            arrayOfLocation.forEach((locationId) => {
              if (response[locationId]) {
                const formattedAddress = setFromattedAddress(
                  response[locationId],
                );
                if (formattedAddress)
                  tempFormattedAddressHash[locationId] = formattedAddress;
                tempLocationsArray.push({ location_id: locationId });
              }
            });
            unstable_batchedUpdates(() => {
              setLocationsError("");
              setValue("locations", tempLocationsArray);
              setValue("formattedAddresses", tempFormattedAddressHash);
            });
          }
        })
        .catch(() => {
          dispatch(
            showMessage(
              "error",
              out("Adresse non récupérée", "Address not retrieved"),
              out(
                "Un problème est survenu lors de la récupération de l'adresse, veuillez la saisir à nouveau",
                "There was a problem retrieving the address, please enter it again",
              ),
              7000,
            ),
          );
        });
    }
  }, []);

  const originalHiringManagerDepartment = useRef(undefined);
  useEffect(() => {
    if (requisition?.requisition?.hiring_manager_department) {
      originalHiringManagerDepartment.current =
        requisition.requisition.hiring_manager_department;
    }

    if (
      originalHiringManagerDepartment.current &&
      hiringManagerDepartments &&
      !hiringManagerDepartments.find(
        (d) => d.name === originalHiringManagerDepartment.current,
      )
    ) {
      // no longer exists: deleted or renamed
      setValue("requisition.hiring_manager_department", undefined);
      setHiringManagerDepartmentNoLongerExists(true);
    }
  }, [requisition, hiringManagerDepartments]);

  return (
    <div id="basic-infos" className={styles.container}>
      {/* add a screen reader-only title with h2 */}
      <h2 className="visually-hidden">{title}</h2>

      <form onSubmit={handleSubmit(onSubmit)}>
        <FormSectionHeading Component="h3" containerClasses="mb-3">
          {out("Informations sur le poste", "Position information")}
        </FormSectionHeading>

        <div
          className={cx("d-flex", {
            "flex-column": language === "en",
            "flex-column-reverse": language === "fr",
          })}
        >
          <div className="mb-3">
            <FormHookFloatingLabel
              control={control}
              name="translations.en.title"
              title={out(
                "Titre de la réquisition ( poste ) - anglais",
                "Requisition (Job) title - English",
              )}
              mandatory={language === "en"}
              rules={{
                required:
                  language === "en"
                    ? out(
                        "Veuillez fournir le titre",
                        "Please provide the title",
                      )
                    : false,
                minLength: {
                  value: 2,
                  message: out("Titre trop court", "Title too short"),
                },
                maxLength: {
                  value: 64,
                  message: out("Titre trop long", "Title too long"),
                },
              }}
              error={errors?.translations?.en?.title}
              showError={true}
            />
          </div>

          <div className="mb-3">
            <FormHookFloatingLabel
              control={control}
              name="translations.fr.title"
              title={out(
                "Titre de la réquisition ( poste ) - français",
                "Requisition (Job) title - French",
              )}
              mandatory={language === "fr"}
              rules={{
                required:
                  language === "fr"
                    ? out(
                        "Veuillez fournir le titre",
                        "Please provide the title",
                      )
                    : false,
                minLength: {
                  value: 2,
                  message: out("Titre trop court", "Title too short"),
                },
                maxLength: {
                  value: 64,
                  message: out("Titre trop grand", "Title too long"),
                },
              }}
              error={errors?.translations?.fr?.title}
            />
          </div>
        </div>

        <div className="mb-3">
          <FormHookFloatingLabel
            control={control}
            // type="number"
            id={styles.numberOfPositions}
            name="number_of_positions"
            title={out("Nombre de positions", "Number of positions")}
            mandatory={true}
            rules={{
              validate: {
                required: (v) =>
                  !!v ||
                  out(
                    "Le nombre de positions est requis",
                    "Number of positions is required",
                  ),
                min: (v) =>
                  parseInt(v) > 0 ||
                  out("1 est le minimum", "1 is the minimum"),

                max: (v) =>
                  parseInt(v) < 1000 ||
                  out("Le numero est trop grand", "The number's too large"),
                integer: (v) =>
                  parseFloat(v) === Math.round(v) ||
                  out("Doit être un nombre entier", "Must be a whole number"),
              },
            }}
            error={errors?.number_of_positions}
          />
        </div>

        {/* TODO: upgrade google locations component */}
        <div
          className={cx("form-group", {
            "text-warning": locationsError,
          })}
        >
          <label htmlFor="location" className={`mt-2 ms-1 ${styles.formText}`}>
            {out("Lieux de travail", "Job locations")}
            <span className={style.mandatory}>&nbsp;*</span>
          </label>
          <div className={style.autoCompleteWrapper}>
            {!editLocation && (
              <div className="input-group floating-input-group-prepend">
                <div className="input-group-text input-group-prepend text-secondary">
                  <BiWorld />
                </div>
                <div className="form-floating form-floating-group flex-grow-1">
                  <input
                    id="googleLocation"
                    className="form-control"
                    name="googleLocation"
                    onClick={() => setEditLocation(true)}
                    placeholder=" "
                  />

                  <label htmlFor="googleLocation">
                    {out(
                      "Veuillez entrer une adresse",
                      "Please enter an address",
                    )}
                  </label>
                </div>
              </div>
            )}
            {editLocation && (
              <GoogleAutocomplete
                autocompletCallback={handleSelectedLocation}
              />
            )}
          </div>

          {/* new */}
          {Object.entries(formattedAddressesHash).length > 0 &&
            Object.entries(formattedAddressesHash)
              .filter(([_, address]) => !!address)
              .map(([i, address]) => {
                return (
                  <span className={style.locationContainer}>
                    <div
                      key={i}
                      className={`${style.locationWrapper}`}
                      // name="location"
                      // id="location"
                    >
                      <div
                        role="button"
                        className={style.deleteLocation}
                        onClick={() => {
                          deleteLocationHandler(i);
                        }}
                      >
                        {/* <i className="fa fa-trash" aria-hidden="true" /> */}
                        {/* x */}
                        <IoCloseOutline />
                      </div>

                      <div className={style.address}>{address}</div>
                    </div>
                  </span>
                );
              })}

          {locationsError && (
            <span className="form-text text-warning text-center mb-5">
              {locationsError}
            </span>
          )}
        </div>

        <FormSectionHeading Component="h3" containerClasses="mt-4 mb-1">
          {out("Gestion", "Management")}
        </FormSectionHeading>

        <Form.Check
          type="checkbox"
          className={`mb-2 user-select-none ${styles.formText}`}
        >
          <Form.Check.Input
            type="checkbox"
            id="requires-approval"
            {...register("requisition.approval_required", {
              validate: {
                falsy: () =>
                  !(
                    !requisitionReviewers?.length &&
                    getValues("requisition.approval_required")
                  ) ||
                  out(
                    "Ne peut pas exiger d'approbation sans évaluateurs",
                    "Cannot require approval without reviewers.",
                  ),
              },
            })}
          />
          <Form.Check.Label htmlFor="requires-approval">
            {out(
              "Approbation de la réquisition requise",
              "Requisition approval required",
              // "Cette réquisition nécessite-t-elle une approbation ?",
              // "Does this requisition require approval?",
            )}
          </Form.Check.Label>

          {errors?.requisition?.approval_required && (
            <div className="form-text text-warning mb-3">
              {errors.requisition.approval_required.message}
            </div>
          )}
        </Form.Check>

        <div
          className={cx("form-group mb-4", {
            "d-none": !approval_required,

            "text-warning":
              errors?.requisition?.reviewers ||
              errors?.requisition?.approval_required,
          })}
        >
          <label htmlFor="reviewers" className={`ms-1 ${styles.formText}`}>
            {out("Évaluateurs", "Reviewers")}
            <span className={style.mandatory}>&nbsp;*</span>
          </label>

          <div>
            {requisitionReviewers?.length < 1 ? (
              <div
                className={`border border rounded d-flex justify-content-center align-items-center ${moduleStyle.infoBox}`}
              >
                <div className={`${style.emptyList} h4`}>
                  <i className="fa fa-exclamation-triangle"></i>&nbsp;
                  {out("Aucun réviseur disponible", "No reviewer available")}
                </div>
              </div>
            ) : (
              <Controller
                name="requisition.reviewers"
                control={control}
                rules={{
                  required:
                    getValues("requisition.approval_required") &&
                    out(
                      "Vous devez sélectionner au moins un évaluateur",
                      "You must select at least one reviewer",
                    ),
                }}
                render={({ field: { ref, ...rest } }) => (
                  <AtlasSelect
                    {...rest}
                    isMulti
                    isClearable
                    isLoading={requisitionReviewers === null}
                    closeMenuOnSelect={false}
                    loadingMessage={() =>
                      out(
                        "Nous récupérons les évaluateurs",
                        "Fetching reviewers...",
                      )
                    }
                    placeholder={
                      requisitionReviewers === null
                        ? out(
                            "Nous récupérons les évaluateurs",
                            "Fetching reviewers...",
                          )
                        : out(
                            "Sélectionnez un ou plusieurs évaluateurs",
                            "Select one or more reviewers",
                          )
                    }
                    value={(() => {
                      if (!requisitionReviewers) return [];

                      const map = new Map(
                        requisitionReviewers.map((r) => [
                          "" + r.id,
                          {
                            label: `${r.first_name} ${r.last_name}`,
                            selected: false,
                          },
                        ]),
                      );

                      selectedReviewers.forEach((r) =>
                        map.set(r, { ...map.get(r), selected: true }),
                      );

                      return [...map.entries()]
                        .filter((e) => e[1].selected)
                        .map((e) => ({
                          label: e[1].label,
                          value: e[0],
                        }));
                    })()}
                    options={
                      requisitionReviewers
                        ? requisitionReviewers.map((r) => ({
                            label: `${r.first_name} ${r.last_name}`,
                            value: "" + r.id,
                          }))
                        : []
                    }
                    onChange={(values) => {
                      setValue(
                        "requisition.reviewers",
                        values.map((v) => v.value),
                      );

                      if (errors?.requisition?.reviewers) {
                        trigger("requisition.reviewers");
                      }
                    }}
                  />
                )}
              />
            )}
          </div>

          {errors?.requisition?.reviewers && (
            <div className="form-text text-warning text-center">
              {errors.requisition.reviewers.message}
            </div>
          )}

          <div
            className="text-info mt-0 mb-2 px-0"
            hidden={!unavailableReviewers || errors?.requisition?.reviewers}
          >
            <div className="text-center">
              <div
                className={`ps-2 align-self-center fw-bold ${styles.smallerText}`}
              >
                <span className="h-100 fs-5 p-1 me-1">
                  <BsFillExclamationTriangleFill />
                </span>
                {out(
                  `Veuillez noter que ${
                    unavailableReviewers === 1 ? "l'un" : unavailableReviewers
                  } des évaluateurs initiaux ne ${
                    unavailableReviewers === 1 ? "figure" : "figurent"
                  } plus sur la liste des évaluateurs disponibles.`,
                  `Please note that ${unavailableReviewers} of the original reviewers ${
                    unavailableReviewers > 1 ? "are" : "is"
                  } no longer on the list of available reviewers`,
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <FormHookFloatingLabel
            type="text"
            control={control}
            name="requisition.hiring_manager_name"
            title={out(
              "Nom du responsable de la réquisition",
              "Hiring manager name",
            )}
            rules={nameValidation(true)}
            mandatory={true}
            error={errors?.requisition?.hiring_manager_name}
          />
        </div>

        <div
          className={cx("form-group", {
            "text-warning": errors?.requisition?.hiring_manager_department,
          })}
        >
          <label
            htmlFor="hiring-manager-department"
            className={`ms-1 ${styles.formText}`}
            id="hiring-manager-department-label"
          >
            {out(
              "Département du gestionnaire du poste",
              "Hiring Manager Department",
            )}
            <span className={style.mandatory}>&nbsp;*</span>
          </label>
          <Controller
            control={control}
            name="requisition.hiring_manager_department"
            rules={{
              required: out(
                "Vous devez sélectionner un département",
                "You must select a department",
              ),
            }}
            defaultValue={(hiringManagerDepartments ?? []).find((d) => ({
              value: d.name,
              label: out(
                d.translations[1]?.name ?? d.translations[0]?.name,
                d.translations[0]?.name ?? d.translations[1]?.name,
              ),
            }))}
            render={({ field: { ref, onChange, value, ...rest } }) => {
              return (
                <AtlasSelect
                  {...rest}
                  isLoading={hiringManagerDepartments === null}
                  id="hiring-manager-department"
                  aria-labelledby="hiring-manager-department-label"
                  aria-errormessage="hiring_manager_deptartment_error"
                  placeholder={out(
                    "Veuillez sélectionner un départment",
                    "Please select a department",
                  )}
                  options={(hiringManagerDepartments ?? []).map((d) => {
                    return {
                      value: d.name,
                      label: out(
                        d.translations[1]?.name ?? d.translations[0]?.name,
                        d.translations[0]?.name ?? d.translations[1]?.name,
                      ),
                    };
                  })}
                  loadingMessage={out(
                    "Nous récupérons les départements",
                    "Fetching depertments",
                  )}
                  value={
                    (hiringManagerDepartments ?? [])
                      .filter((d) => value === d.name)
                      .map((d) => ({
                        label: out(
                          d.translations[1]?.name ?? d.translations[0]?.name,
                          d.translations[0]?.name ?? d.translations[1]?.name,
                        ),
                        value: d.name,
                      }))[0]
                  }
                  onChange={(department) => onChange(department.value)}
                />
              );
            }}
          />
          {errors?.requisition?.hiring_manager_department && (
            <span
              id="hiring_manager_deptartment_error"
              className="form-text text-warning text-center mb-5"
            >
              {errors.requisition.hiring_manager_department.message}
            </span>
          )}

          <div
            className="text-info mt-0 mb-2 px-0"
            hidden={!hiringManagerDepartmentNoLongerExists}
          >
            <div className="text-center">
              <div
                className={`ps-2 align-self-center fw-bold ${styles.smallerText}`}
              >
                <span className="h-100 fs-5 p-1 me-1">
                  <BsFillExclamationTriangleFill />
                </span>
                {out(
                  `Veuillez noter que le département initial du responsable du recrutement ne figure plus sur la liste des départements disponibles.`,
                  `Please note that the original hiring manager department is no longer on the list of available departments.`,
                )}
              </div>
            </div>
          </div>

          {hiringManagerDepartments?.length < 1 && (
            <div className="text-center pt-3">
              <h4 className={style.emptyList}>
                <i className="fa fa-exclamation-triangle" />
                &nbsp;
                {out(
                  "Aucun département du gestionnaire du poste disponible",
                  "No hiring manager department available",
                )}
              </h4>
            </div>
          )}
        </div>

        <FormSectionHeading Component="h3" containerClasses="mt-3 mb-2">
          {out("Sous la responsabilité de", "Reporting to")}
        </FormSectionHeading>

        <div className="mb-3">
          <FormHookFloatingLabel
            control={control}
            type="text"
            name="requisition.reports_to_position"
            title={out("Titre", "Position")}
            rules={{
              required: out("Titre requis", "Position required"),
              minLength: {
                value: 1,
                message: out("Titre invalide", "Invalid position"),
              },
              maxLength: {
                value: 50,
                message: out("Titre invalide", "Invalid position"),
              },
            }}
            mandatory={true}
            error={errors?.requisition?.reports_to_position}
          />
        </div>

        <div
          className={cx({
            "mb-3": !email,
            "mb-2": !!email,
          })}
        >
          <FormHookFloatingLabel
            control={control}
            type="email"
            name="requisition.reports_to_email"
            title={out("Courriel", "Email")}
            rules={emailValidation(false)}
            mandatory={false}
            error={errors?.requisition?.reports_to_email}
          />
        </div>

        {email && (
          <div>
            <FormHookFloatingLabel
              control={control}
              type="text"
              name="requisition.reports_to_name"
              title={out("Nom", "Name")}
              rules={nameValidation(
                !!getValues("requisition.reports_to_email"),
              )}
              mandatory={true}
              error={errors?.requisition?.reports_to_name}
            />
          </div>
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Button type="submit" variant="secondary">
            {out("Suivant", "Next")}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default BasicInfos;
