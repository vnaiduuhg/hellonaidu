import React, { useEffect, useRef } from "react";
import { Controller, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useParams } from "react-router";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import cx from "classnames";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";
import { useTranslation } from "global/utils/useTranslation";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import SingleDatePicker from "global/components/form-hook/date-picker/SingleDatePicker";
import { IMaskInput } from "react-imask";
import moment from "moment";
import style from "../../pages/RequisitionWizardPages.module.css";
import moduleStyle from "./RequisitionWizard.module.css";
import styles from "./wizard-page.module.css";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { FormSectionHeading } from "global/components/FormSectionHeading/FormSectionHeading";
import { FormHookSelect } from "global/components/form-hook/select/FormHookSelect";
import { AtlasSelect } from "global/components/select/atlas-select";
import { ComponentLoader } from "global/components/loaders/component-loader";

const currencyOptions = {
  mask: Number,
  scale: 2,
  signed: false,
  thousandsSeparator: " ",
  padFractionalZeros: true,
  normalizeZeros: true,
  radix: ",",
  mapToRadix: [",", "."],
  min: 0,
  max: 21474836.47,
};

const durationNumberOptions = {
  mask: Number,
  scale: 2,
  signed: false,
  thousandsSeparator: " ",
  padFractionalZeros: false,
  normalizeZeros: false,
  radix: ",",
  mapToRadix: [",", "."],
  min: 0,
};

const BudgetInfos = ({ requisition, benefits, salaries, shifts }) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const { id: paramId } = useParams();
  const language = useSelector((state) => state.user.language);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setValue,
    getValues,
    trigger,
    control,
  } = useForm({
    defaultValues: {
      planned_salary_currency: "CAD",
      plannedSalary: "fixed",
      workShift: [],
      jobDurationUnit: "Months",

      ...requisition,

      startDate: requisition.startDate
        ? new Date(JSON.parse(requisition.startDate))
        : null,

      requisition: {
        planned_salary_min: "",
        planned_salary_max: "",
        planned_salary_currency: "CAD",
        grade: "",
        is_unionized: "false",
        ...(requisition?.requisition ?? {}),
      },
    },
  });
  const title = out(
    requisitionWizardSteps[2].title.fr,
    requisitionWizardSteps[2].title.en,
  );
  useEffect(() => {
    document.title = title + " - Workland";
  }, [title]);

  const onSubmit = (data) => {
    data.startDate = JSON.stringify(data.startDate);

    // save
    dispatch(
      requisitionWizardSlice.actions.saveDataInStep({
        id: paramId,
        data: JSON.parse(JSON.stringify(data)),
        nextStepName: "manpower",
      }),
    );

    history.push("manpower");
  };

  const jobType = watch("jobType");
  const workShift = watch("workShift");
  const selectedBenefits = watch("benefits");
  const plannedSalaryOption = watch("plannedSalary");
  const planned_salary_currency = watch("planned_salary_currency");
  const jobDurationUnit = watch("jobDurationUnit");
  const startDate = watch("startDate");
  const isUnionized = watch("requisition.is_unionized");

  // react hook form caches validation response. force validation on language
  // change
  const initial = useRef(true);
  // revalidate start date on change
  useEffect(() => {
    if (!initial.current) trigger("startDate");
  }, [startDate, trigger]);
  useEffect(() => {
    if (!initial.current) trigger();
    initial.current = false;
  }, [language, plannedSalaryOption, trigger]);

  useEffect(() => {
    register("startDate", {
      required: out("La date de début est requise", "Start date is required"),
      valueAsDate: true,
      validate: {
        min: (v) =>
          v >= moment().startOf("day") ||
          out(
            "La date ne peut pas être dans le passé",
            "Date may not be in the past",
          ),
      },
    });
  }, [language, register]);

  useEffect(() => {
    // hack to prevent users from accidentally modifying numbers when scrolling
    window.$("form").on("focus", "input[type=number]", function (e) {
      window.$(this).on("wheel.disableScroll", function (e) {
        e.preventDefault();
      });
    });
    window.$("form").on("blur", "input[type=number]", function (e) {
      window.$(this).off("wheel.disableScroll");
    });
  }, []);

  return (
    <div id="budgetInfos" className={styles.container}>
      <h2 className="visually-hidden">{title}</h2>

      <form onSubmit={handleSubmit(onSubmit)}>
        {/* removed in the new designs, leaving it just in case this was an oversight */}
        {/* <h2 className="h4 section-title pb-1 border-0 border-bottom border-gray">
          {out("Conditions de travail", "Working conditions")}
        </h2> */}

        <FormSectionHeading Component="h3" containerClasses="mb-2">
          {out("Salaire annuel planifié", "Planned Yearly Salary")}
        </FormSectionHeading>

        <div className="mb-2 user-select-none">
          <span className={styles.pointer}>
            <Form.Check type="checkbox" className="form-check-inline ms-1">
              <Form.Check.Input
                type="radio"
                id="fixed"
                value="fixed"
                name="plannedSalary"
                {...register("plannedSalary")}
              />
              <Form.Check.Label
                className={`${styles.formText} ${styles.pointer}`}
                htmlFor="fixed"
              >
                {out("Montant", "Fixed amount")}
              </Form.Check.Label>
            </Form.Check>
          </span>

          <Form.Check type="checkbox" className="form-check-inline ms-2">
            <Form.Check.Input
              type="radio"
              id="range"
              value="range"
              name="plannedSalary"
              {...register("plannedSalary")}
            />
            <Form.Check.Label
              className={`${styles.formText} ${styles.pointer}`}
              htmlFor="range"
            >
              {out("Intervalle", "Range")}
            </Form.Check.Label>
          </Form.Check>
        </div>

        {/* beginning of amount row */}
        <div id={styles.salaryRow} className="d-flex mb-2 gx-2">
          <div
            className={cx({
              [styles.minFixed]: plannedSalaryOption === "fixed",
              [styles.minRange]: plannedSalaryOption !== "fixed",
            })}
          >
            <div>
              <div className="input-group floating-input-group-prepend">
                <div className="input-group-text input-group-prepend text-secondary">
                  $
                </div>
                <div className="form-floating form-floating-group flex-grow-1">
                  <IMaskInput
                    {...currencyOptions}
                    type="text"
                    id="rangeMin"
                    className={cx("form-control", {
                      "is-invalid": errors?.requisition?.planned_salary_min,
                    })}
                    unmask={true}
                    value={"" + getValues("requisition.planned_salary_min")}
                    onAccept={(v) =>
                      setValue("requisition.planned_salary_min", +v)
                    }
                    placeholder=" "
                    {...register("requisition.planned_salary_min", {
                      valueAsNumber: true,
                      required: out("Valeur manquante", "Value missing"),
                      min: {
                        value: 0,
                        message: out("Valeur invalide", "Invalid value"),
                      },
                      max: {
                        value:
                          plannedSalaryOption === "range"
                            ? +getValues("requisition.planned_salary_max") ??
                              21474836.47
                            : 21474836.47,
                        message:
                          plannedSalaryOption === "range"
                            ? out(
                                "Doit être inférieur au maximum",
                                "Must be less than maximum",
                              )
                            : out("Valeur invalide", "Invalid value"),
                      },
                    })}
                  />

                  <label htmlFor="rangeMin">
                    {plannedSalaryOption === "fixed" ? (
                      <>
                        {out("Montant", "Amount")}
                        <span className={style.mandatory}>&nbsp;*</span>
                      </>
                    ) : (
                      <>
                        {out("Montant minimum", "Min Amount")}
                        <span className={style.mandatory}>&nbsp;*</span>
                      </>
                    )}
                  </label>
                </div>
              </div>
              <div
                className={cx("form-text text-warning", {
                  "d-none opacity-0":
                    !errors?.requisition?.planned_salary_min?.message,
                })}
              >
                {errors?.requisition?.planned_salary_min?.message}
              </div>
            </div>
          </div>

          <div
            className={cx({
              [styles.maxFixed]: plannedSalaryOption === "fixed",
              [styles.maxRange]: plannedSalaryOption !== "fixed",
            })}
            hidden={plannedSalaryOption === "fixed"}
          >
            <div className="input-group floating-input-group-prepend">
              <div className="input-group-text input-group-prepend text-secondary">
                $
              </div>
              <div className="form-floating form-floating-group flex-grow-1">
                <IMaskInput
                  {...currencyOptions}
                  type="text"
                  placeholder=" "
                  className={cx("form-control", {
                    "is-invalid": !!errors?.requisition?.planned_salary_max,
                  })}
                  id="rangeMax"
                  unmask={true}
                  value={"" + getValues("requisition.planned_salary_max")}
                  onAccept={(v) => {
                    setValue("requisition.planned_salary_max", +v);
                  }}
                  {...register("requisition.planned_salary_max", {
                    valueAsNumber: true,
                    required:
                      plannedSalaryOption === "range"
                        ? out("Valeur manquante", "Value missing")
                        : false,
                    min: {
                      value: +getValues("requisition.planned_salary_min") ?? 0,
                      message: out(
                        "Doit être plus grand que le minimum",
                        "Must be larger than minimum",
                      ),
                    },
                    max: {
                      value: 21474836.47,
                      message: out("Valeur", "Invalid value"),
                    },
                  })}
                  disabled={plannedSalaryOption === "fixed"}
                />
                <label htmlFor="inputGroup">
                  {out("Montant maximum", "Max Amount")}
                  <span className={style.mandatory}>&nbsp;*</span>
                </label>
              </div>
            </div>

            <div
              className={cx("form-text text-warning", {
                "d-none opacity-0":
                  !errors?.requisition?.planned_salary_max.message,
              })}
            >
              {errors?.requisition?.planned_salary_max.message}
            </div>
          </div>

          <div>
            <div
              className="btn-group w-100"
              role="group"
              aria-label={out("Sélectionnez la devise", "Currency")}
            >
              <input
                autoComplete="off"
                {...register("planned_salary_currency")}
                type="radio"
                name="planned_salary_currency"
                id="currencyCad"
                className="btn-check"
                value="CAD"
                checked={planned_salary_currency === "CAD"}
              />
              <label
                className="btn btn-outline-secondary btn-lg-float"
                htmlFor="currencyCad"
              >
                CAD
              </label>

              <input
                autoComplete="off"
                {...register("planned_salary_currency")}
                type="radio"
                name="planned_salary_currency"
                id="currencyUsd"
                className="btn-check"
                value="USD"
                checked={planned_salary_currency === "USD"}
              />
              <label
                className="btn btn-outline-secondary btn-lg-float"
                htmlFor="currencyUsd"
              >
                USD
              </label>
            </div>
          </div>
        </div>

        {/* end of amount row */}

        <div className="mb-3">
          <FormHookFloatingLabel
            control={control}
            type="text"
            name="requisition.grade"
            title={out("Niveau de rémunération", "Grade")}
            mandatory={false}
          />
        </div>

        {/* TODO: create new react-select loader design */}
        <div
          className={cx("form-group mb-4", {
            "text-warning": errors?.jobType,
          })}
        >
          <label htmlFor="job-type" className={`ms-1 ${styles.formText}`}>
            {out("Type d'emploi", "Job type")}
            <span className={style.mandatory}>&nbsp;*</span>
          </label>
          {salaries === null ? (
            <ComponentLoader
              message={out(
                "Nous récupérons les types d'emploi",
                "Fetching job types",
              )}
              wait={true}
            />
          ) : (
            <FormHookSelect
              control={control}
              id="job-type"
              name="jobType"
              setValue={setValue}
              defaultValue={jobType}
              placeholder={out(
                "Veuillez sélectionner un type d'emploi",
                "Please select a job type",
              )}
              rules={{
                required: out(
                  "Veuillez sélectionner un type d'emploi",
                  "Please select a job type",
                ),
              }}
              options={salaries.map((s) => ({
                label: out(s.translations[1].name, s.translations[0].name),
                value: s.name,
              }))}
            />
          )}
          {errors?.jobType && (
            <span className="form-text text-warning text-center mb-5">
              {errors.jobType.message}
            </span>
          )}
          {salaries?.length < 1 && (
            <div className="text-center">
              <h4 className={style.emptyList}>
                <i className="fa fa-exclamation-triangle"></i>&nbsp;
                {out("Aucun type d'emploi disponible", "No job type available")}
              </h4>
            </div>
          )}
        </div>

        <Row className="mt-3">
          <Col
            xs={12}
            sm={12}
            md={12}
            xl={4}
            className={cx("mb-2", { "text-warning": errors.startDate })}
          >
            <Controller
              control={control}
              name="startDate"
              render={() => (
                <SingleDatePicker
                  id="startDate"
                  control={control}
                  label={
                    <>
                      <span>{out("Date de début", "Start Date")}</span>
                      <span className={style.mandatory}>&nbsp;*</span>
                    </>
                  }
                  date={startDate ?? null}
                  setDate={(v) => setValue("startDate", v)}
                  error={errors?.startDate}
                  helperText={errors?.startDate?.message}
                  mask={language === "en" ? "____-__-__" : "__/__/____"}
                />
              )}
            />

            {errors?.startDate && (
              <div className="form-text text-warning text-center">
                {errors.startDate.message}
              </div>
            )}
          </Col>

          {jobType !== "Permanent" && (
            <>
              <Col
                className="startDateContainer mb-2"
                xs={12}
                sm={6}
                md={6}
                xl={4}
              >
                <FormHookFloatingLabel
                  control={control}
                  type="number"
                  title={out("Durée de l'emploi", "Job duration")}
                  step={1}
                  name="job-duration"
                  id="job-duration"
                  className="form-control"
                  rules={{
                    validate: {
                      required: (v) =>
                        !!v ||
                        out(
                          "La durée du travail est requise",
                          "Job duration is required",
                        ),

                      min: (v) =>
                        parseInt(v) > 0 ||
                        out(
                          "Veuillez définir une durée valide",
                          "Please set a valid duration",
                        ),

                      max: (v) =>
                        parseInt(v) < 100 ||
                        out(
                          "Veuillez définir une durée valide",
                          "Please set a valid duration",
                        ),
                    },
                  }}
                  mandatory={true}
                  error={
                    typeof errors["job-duration"]
                      ? errors["job-duration"]
                      : null
                  }
                />
              </Col>

              <Col
                xs={12}
                sm={6}
                md={6}
                xl={4}
                className="jobDurationContainer"
              >
                <div
                  className="btn-group w-100"
                  role="group"
                  aria-label={out(
                    "Unité de durée du travail",
                    "Job duration unit",
                  )}
                >
                  <input
                    {...register("jobDurationUnit")}
                    type="radio"
                    name="jobDurationUnit"
                    id="jobDurationUnit_months"
                    className="btn-check"
                    value="Months"
                    checked={jobDurationUnit === "Months"}
                  />
                  <label
                    className="btn btn-outline-secondary btn-lg-float"
                    htmlFor="jobDurationUnit_months"
                  >
                    {out("Mois", "Months")}
                  </label>

                  <input
                    {...register("jobDurationUnit")}
                    type="radio"
                    name="jobDurationUnit"
                    id="jobDurationUnit_years"
                    className="btn-check"
                    value="Years"
                    checked={jobDurationUnit === "Years"}
                  />
                  <label
                    className="btn btn-outline-secondary btn-lg-float"
                    htmlFor="jobDurationUnit_years"
                  >
                    {out("Années", "Years")}
                  </label>
                </div>
              </Col>
            </>
          )}
        </Row>

        <FormSectionHeading Component="h3" containerClasses="mt-3 mb-2">
          {out("Quarts de travail", "Work shifts")}
        </FormSectionHeading>

        <Row>
          <Col xs={12} sm={4} md={3} lg={4}>
            <Controller
              control={control}
              name="hoursPerWeek"
              // TODO: validate as number
              rules={{
                valueAsNumber: true,
                required: out(
                  "Les heures de travail sont requises",
                  "Work hours is required",
                ),
                min: {
                  value: 0,
                  message: out("Valeur invalide", "Invalid value"),
                },
                max: {
                  value: 999.99,
                  message: out("Valeur invalide", "Invalid value"),
                },
              }}
              render={({ field }) => (
                <div className="form-floating">
                  <IMaskInput
                    {...field}
                    {...durationNumberOptions}
                    type="text"
                    name="hours-per-week"
                    id="hours-per-week"
                    className="form-control"
                    unmask={true}
                    placeholder=" "
                    value={"" + getValues("hoursPerWeek")}
                    onAccept={(v) => setValue("hoursPerWeek", +v)}
                  />
                  <label htmlFor="floatingInput">
                    {!!errors?.hoursPerWeek
                      ? errors.hoursPerWeek.message
                      : out("Heures par semaine", "Hours per week")}
                  </label>
                </div>
              )}
            />

            {errors?.hoursPerWeek && (
              <span className="form-text text-warning mb-5">
                {errors.hoursPerWeek.message}
              </span>
            )}
          </Col>

          <Col xs={12} sm={8} md={9} lg={8}>
            {shifts?.length < 1 ? (
              <div className="border border rounded h-100 d-flex justify-content-center align-items-center">
                <div className={`${style.emptyList} h4`}>
                  <i className="fa fa-exclamation-triangle"></i>&nbsp;
                  {out(
                    "Aucun quart de travail disponible",
                    "No work shift available",
                  )}
                </div>
              </div>
            ) : (
              <AtlasSelect
                isMulti
                isClearable
                isLoading={shifts === null}
                closeMenuOnSelect={false}
                loadingMessage={() =>
                  out(
                    "Nous récupérons les quarts de travail",
                    "Fetching work shifts...",
                  )
                }
                placeholder={
                  shifts === null
                    ? out(
                        "Nous récupérons les quarts de travail",
                        "Fetching work shifts...",
                      )
                    : out("Quarts de travail", "Work shifts")
                }
                value={(() => {
                  if (!shifts) return [];

                  const map = new Map(
                    shifts.map((s) => [
                      s.name,
                      {
                        label: out(
                          s.translations[1].name,
                          s.translations[0].name,
                        ),
                        selected: false,
                      },
                    ]),
                  );

                  (workShift ?? []).forEach((w) =>
                    map.set(w, { ...map.get(w), selected: true }),
                  );

                  return [...map.entries()]
                    .filter((e) => e[1].selected)
                    .map((e) => ({
                      label: e[1].label,
                      value: e[0],
                    }));
                })()}
                options={
                  shifts
                    ? shifts.map((s) => ({
                        label: out(
                          s.translations[1].name,
                          s.translations[0].name,
                        ),
                        value: s.name,
                      }))
                    : []
                }
                onChange={(values) =>
                  setValue(
                    "workShift",
                    values.map((v) => v.value),
                  )
                }
              />
            )}
          </Col>
        </Row>

        <FormSectionHeading Component="h3" containerClasses="mt-3 mb-2">
          {out("Avantages", "Benefits")}
        </FormSectionHeading>

        <div>
          {benefits?.length < 1 ? (
            <div
              className={`border border rounded d-flex justify-content-center align-items-center ${moduleStyle.infoBox}`}
            >
              <div className={`${style.emptyList} h4`}>
                <i className="fa fa-exclamation-triangle"></i>&nbsp;
                {out("Aucun avantage disponible", "No benefit available")}
              </div>
            </div>
          ) : (
            <AtlasSelect
              isMulti
              isClearable
              isLoading={benefits === null}
              closeMenuOnSelect={false}
              loadingMessage={() =>
                out(
                  "Nous récupérons la liste des avantages",
                  "Fetching list of benefits...",
                )
              }
              placeholder={
                benefits === null
                  ? out(
                      "Nous récupérons la liste des avantages",
                      "Fetching list of benefits...",
                    )
                  : out("Avantages", "Benefits")
              }
              value={(() => {
                if (!benefits) return [];

                const map = new Map(
                  benefits.map((s) => [
                    s.content,
                    {
                      label: out(
                        s.translations[1].content,
                        s.translations[0].content,
                      ),
                      selected: false,
                    },
                  ]),
                );

                (selectedBenefits ?? []).forEach((b) =>
                  map.set(b, { ...map.get(b), selected: true }),
                );

                return [...map.entries()]
                  .filter((e) => e[1].selected)
                  .map((e) => ({
                    label: e[1].label,
                    value: e[0],
                  }));
              })()}
              options={
                benefits
                  ? benefits.map((s) => ({
                      label: out(
                        s.translations[1].content,
                        s.translations[0].content,
                      ),
                      value: s.content,
                    }))
                  : []
              }
              onChange={(values) =>
                setValue(
                  "benefits",
                  values.map((v) => v.value),
                )
              }
            />
          )}
        </div>

        <hr />

        <div className="mb-1 user-select-none">
          <span className={styles.formText}>
            {out(
              "Ce poste fait-il partie du syndicat?",
              "Is this position part of the union?",
            )}
            <span className={style.mandatory}>&nbsp;*</span>
          </span>

          <Form.Check type="radio" className="form-check-inline ms-3">
            <Form.Check.Input
              type="radio"
              id="is_unionized_true"
              name="requisition.is_unionized"
              value="true"
              {...register("requisition.is_unionized")}
              checked={isUnionized === "true"}
            />
            <Form.Check.Label
              className={`${styles.formText} ${styles.pointer}`}
              htmlFor="is_unionized_true"
            >
              {out("Oui", "Yes")}
            </Form.Check.Label>
          </Form.Check>

          <Form.Check type="radio" className="form-check-inline">
            <Form.Check.Input
              type="radio"
              id="is_unionized_false"
              name="requisition.is_unionized"
              value="false"
              {...register("requisition.is_unionized")}
              checked={isUnionized === "false"}
            />
            <Form.Check.Label
              className={`${styles.formText} ${styles.pointer}`}
              htmlFor="is_unionized_false"
            >
              {out("Non", "No")}
            </Form.Check.Label>
          </Form.Check>
        </div>

        <div
          className={cx("mt-3", styles.hiddenField, {
            [styles.visible]: isUnionized === "true",
          })}
        >
          <FormHookFloatingLabel
            control={control}
            type="text"
            id="union_description"
            name="union_description"
            title={out("Nom du syndicat", "Union name")}
            mandatory={true}
            rules={{
              required:
                isUnionized === "true"
                  ? out("Nom manquant", "Name missing")
                  : false,
              minLength: { value: 1, message: out("", "") },
              maxLength: { value: 256, message: out("", "") },
            }}
            error={errors?.union_description}
          />
        </div>

        <div className="mt-3 d-flex justify-content-end">
          <Button type="submit" variant="secondary">
            {out("Suivant", "Next")}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default BudgetInfos;
