import React, { useState, useEffect } from "react";
import { useParams } from "react-router";
import { batch, useDispatch, useSelector } from "react-redux";
import { useQueryClient } from "react-query";
import Button from "react-bootstrap/Button";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import { useTranslation } from "global/utils/useTranslation";
import AfterSubmitModal from "./AfterSubmitModal";
import RequisitionPreview from "../RequisitionPreview";
import { convertRequisitionDataToPostData } from "employer/requisition-module/utils/convertRequisitionDataToPostData";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";
import {
  createRequisition,
  submitRequisition,
  updateRequisition,
} from "employer/requisition-module/api/requisitionApi";
import { useHistory } from "react-router-dom";

const PreviewAndSubmit = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { out } = useTranslation();
  const language = useSelector((state) => state.user.language);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const { id: paramId } = useParams();
  const queryClient = useQueryClient();
  const [submissionInProgress, setSubmissionInProgress] = useState(false);
  const { requisitionsInProgress } = useSelector(
    (state) => state.requisitionWizard,
  );

  const initialReviewerList = queryClient.getQueriesData(
    "requisition-reviewers:by-account",
  )[0][1];

  const requisition = requisitionsInProgress[paramId];

  const mode = paramId
    ? requisitionsInProgress[paramId]?.mode ?? "create"
    : "create";

  const title = out(
    requisitionWizardSteps[5].title.fr,
    requisitionWizardSteps[5].title.en,
  );
  useEffect(() => {
    document.title = title + " - Workland";
  }, [title]);

  const createOrCloneRequisition = async (data, status) => {
    // draft
    data.requisition.status_id = 3;
    const response = await createRequisition(data);

    const requisitionId = response.id;

    if (status !== 3) {
      data.requisition.status_id = status;
      await submitRequisition({ status_id: status }, requisitionId);
    }
  };

  const editRequisition = async (data, status) => {
    // draft
    data.requisition.status_id = 3;
    await updateRequisition(data.id, data);

    // update to submitted or approved (when review is not required)
    if (status !== 3) {
      data.requisition.status_id = status;
      await submitRequisition({ status_id: status }, data.id);
    }
  };

  const dataCache = {
    requisitionReviewers: initialReviewerList,
    hireTypes: queryClient.getQueriesData(
      "requisition-hire-types:by-account",
    )[0][1],
    requisitionGroups: queryClient.getQueriesData(
      "requisition-groups:by-account",
    )[0][1],
    salaries: queryClient.getQueriesData("salaries")[0][1],
    hiringManagerDepartments: queryClient.getQueriesData(
      "hiring-manager-departments:by-account",
    )[0][1],
    benefits: queryClient.getQueriesData("benefits:by-account")[0][1],
    shifts: queryClient.getQueriesData("shifts")[0][1],
  };

  const submit = async (draft = false) => {
    try {
      batch(() => {
        setSubmissionInProgress(true);
        dispatch(showLoadingBarWithoutMessage(200000));
      });

      const post = convertRequisitionDataToPostData(
        requisition,
        language,
        dataCache,
      );
      const status = draft ? 3 : post.requisition.approval_required ? 1 : 5;

      switch (mode) {
        case "edit":
          // TODO: move from requisition wizard slice
          await editRequisition(post, status);
          break;
        case "create":
        case "clone":
          await createOrCloneRequisition(post, status);
          break;
      }

      batch(() => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("requisitions");
        setSubmissionInProgress(false);
        setShowSubmitModal(true);
      });
    } catch (e) {
      batch(() => {
        setSubmissionInProgress(false);
        dispatch(statusMessagesSlice.actions.clearLoaders());

        let errorTitle;
        let errorMessage;
        switch (e.response.status) {
          // authentication error
          case 401:
          case 403:
            errorTitle = out(`Erreur`, `Error`);
            errorMessage = out(
              `Vous n'avez pas accès à ces données.`,
              `Access Denied`,
            );
            break;

          // does not exist
          case 404:
            errorTitle = out("Erreur", "Error");
            errorMessage = out(
              `Réquisition introuvable`,
              `Requisition not found`,
            );
            break;

          // 422/500 and any other unhandlable-errors
          default:
            let v1;
            let v2;

            switch (mode) {
              case "edit":
                v1 = out("modification", "edit");
                v2 = out("modification", "editting");
                break;
              case "clone":
                v1 = out("clonage", "clone");
                v2 = out("clonage", "cloning");
                break;
              case "create":
                v1 = out("création", "create");
                v2 = out("création", "creating");
                break;
            }

            errorTitle = out(
              `Échec de la ${v1}`,
              `Failed to ${v1} requisition`,
            );
            errorMessage = out(
              `Une erreur s'est produite lors de la ${v2} de réquisition. Veuillez contacter support@workland.com pour plus d'aide.`,
              `There was an error ${v2} the requisition. Please contact our support team at support@workland.com for further assistance.`,
            );
        }

        dispatch(
          // TODO: french message needs to be rewritten
          showMessage("error", errorTitle, errorMessage, 5700),
        );
      });
    }
  };

  if (!requisition) {
    window.location.replace("/404");
    return null;
  }

  const temp = requisition
    ? convertRequisitionDataToPostData(requisition, language, dataCache)
    : null;

  const previewData = temp
    ? {
        ...temp,
        job: { ...temp },
        ...temp.requisition,
      }
    : null;

  const props = {
    data: previewData,
    formattedLocations: Object.values(requisition.formattedAddresses),
    initialReviewerList,
    showTitle: true,
    isError: null,
    isLoading: null,
  };

  let submitLabel;
  switch (mode) {
    case "create":
    case "clone":
      submitLabel = out("Créer", "Create");
      break;
    case "edit":
      submitLabel = out("Modifier", "Update");
      break;
  }

  return (
    <form onSubmit={() => submit(true)}>
      <h1 className="h4 border-0 border-bottom border-gray pt-4 pb-2 visually-hidden">
        {title}
      </h1>

      <RequisitionPreview {...props} />

      <div className="d-flex flex-row-reverse mt-3">
        <Button
          type="button"
          variant="primary"
          className="ms-3"
          disabled={submissionInProgress}
          onClick={() => submit(false)}
        >
          {submitLabel}
        </Button>

        <Button
          type="submit"
          variant="alt-primary"
          disabled={submissionInProgress}
          onClick={() => submit(true)}
        >
          {out("Enregistrer comme brouillon", "Save as Draft")}
        </Button>
      </div>

      <AfterSubmitModal
        show={showSubmitModal}
        onHide={() => {
          setShowSubmitModal(false);

          // Force leaving the create requisition page when cancelling out of modal
          history.replace("/planning");
        }}
        mode={mode}
      />
    </form>
  );
};

export default PreviewAndSubmit;
