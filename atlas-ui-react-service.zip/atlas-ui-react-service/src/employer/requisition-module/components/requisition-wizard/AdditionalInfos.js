import React, { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import Button from "react-bootstrap/Button";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";
import { useDispatch, useSelector } from "react-redux";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { useTranslation } from "global/utils/useTranslation";
import { useHistory, useParams } from "react-router";
import moduleStyle from "./RequisitionWizard.module.css";
import style from "../../pages/RequisitionWizardPages.module.css";
import AntidoteButton from "global/components/AntidoteButton";
import { useAntidote } from "global/hooks/useAntidote";
import { Col } from "react-bootstrap";
import { FormSectionHeading } from "global/components/FormSectionHeading/FormSectionHeading";
import styles from "./wizard-page.module.css";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";

const AdditionalInfos = ({ requisition, skills }) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const { id: paramId } = useParams();
  const language = useSelector((state) => state.user.language);

  const antidoteActive = useAntidote({ id: "A" });

  let uniqueSkills = [...(requisition?.skills ?? [])];
  [...(skills ?? [])].forEach((s) => {
    if (uniqueSkills.findIndex((t) => t.name === s.name) === -1)
      uniqueSkills.push(s);
  });

  const allSkills = uniqueSkills.map((s) => ({
    ...s,
    selected: s.selected ?? false,
    is_asset: s.is_asset ?? false,
  }));

  const {
    control,
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    trigger,
  } = useForm({
    defaultValues: {
      skills: [...allSkills],
      ...requisition,
    },
  });

  useEffect(() => {
    setValue("skills", allSkills);
  }, [skills]);

  const skillsWatch = watch("skills");

  const title = out(
    requisitionWizardSteps[4].title.fr,
    requisitionWizardSteps[4].title.en,
  );
  useEffect(() => {
    document.title = title + " - Workland";
  }, [title]);

  const onSubmit = (data) => {
    // save
    dispatch(
      requisitionWizardSlice.actions.saveDataInStep({
        id: paramId,
        data: JSON.parse(JSON.stringify(data)),
        nextStepName: "preview",
      }),
    );

    history.push("preview");
  };

  // react hook form caches validation response. force validation on language
  // change
  const initial = useRef(true);
  useEffect(() => {
    if (!initial.current) trigger();
    initial.current = false;
  }, [language, trigger]);

  return (
    <div id={style.additionalInfos} className={styles.container}>
      {/* add a screen reader-only title with h2 */}
      <h2 className="visually-hidden">{title}</h2>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="m-0">
          <div className="p-0 text-start mb-3">
            <label className={styles.formText}>
              {out(
                "Description du poste - anglais",
                "Job description - English",
              )}{" "}
              <span className={style.optional}>
                {out(" (optionnel)", " (optional)")}
              </span>
            </label>

            <CKEditor
              id="jobEnglish"
              className="form-control"
              editor={ClassicEditor}
              data={getValues("translations.en.description")}
              onChange={(_, editor) => {
                setValue("translations.en.description", editor.getData());
              }}
            />
          </div>
        </div>

        <div className="m-0">
          <div className="p-0 text-start mb-2">
            <label className={styles.formText}>
              {out(
                "Description du poste - français",
                "Job description - French",
              )}{" "}
              <span className={style.optional}>
                {out(" (optionnel)", " (optional)")}
              </span>
            </label>

            <CKEditor
              id="jobFrench"
              className="form-control"
              editor={ClassicEditor}
              data={getValues("translations.fr.description")}
              onChange={(_, editor) =>
                setValue("translations.fr.description", editor.getData())
              }
            />
          </div>
        </div>

        <FormSectionHeading Component="h3" containerClasses="mt-3 mb-2">
          {out("Compétences ", "Skills")}
          <span className="text-muted fs-6">
            {out(" (optionnel)", " (optional)")}
          </span>
        </FormSectionHeading>

        <div
          className={`p-0 m-0 mb-4 ${moduleStyle["psychometric-test-card"]}`}
        >
          <div className={moduleStyle["product-header"]}>
            <div className={moduleStyle["product-body"]}>
              {(skillsWatch ?? []).map((s, i) => (
                <div className={moduleStyle["product-body-style-wrapper"]}>
                  <div
                    className={moduleStyle["product-body-style"]}
                    key={s.name}
                  >
                    <label
                      className={`${moduleStyle.control} ${moduleStyle["control--checkbox"]} mb-0`}
                    >
                      <p className={moduleStyle["title-style"]}>
                        {out(s.translations[0].name, s.translations[1].name)}
                      </p>
                      <input
                        id={`skill-${skillsWatch[i].name.toLowerCase()}`}
                        type="checkbox"
                        aria-checked={skillsWatch[i].selected}
                        aria-invalid="false"
                        value="true"
                        {...register(`skills.${i}.selected`)}
                      />
                      <div className={moduleStyle["control__indicator"]} />
                    </label>{" "}
                    <label
                      hidden={!skillsWatch[i].selected}
                      className={moduleStyle["text-checkbox"]}
                    >
                      <input
                        type="checkbox"
                        className="d-none"
                        aria-checked={skillsWatch[i].is_asset === "true"}
                        aria-invalid={!skillsWatch[i].selected}
                        value="true"
                        {...register(`skills.${i}.is_asset`)}
                      />
                      <p
                        className={`${moduleStyle.badge} ${
                          skillsWatch[i].is_asset === "true"
                            ? moduleStyle["asset-badge"]
                            : moduleStyle["required-badge"]
                        }`}
                      >
                        {skillsWatch[i].is_asset === "true"
                          ? out("atout", "asset")
                          : out("requis", "required")}
                      </p>
                    </label>
                    <label
                      htmlFor={`skill-${skillsWatch[i].name.toLowerCase()}`}
                      className={moduleStyle["title-description"]}
                    >
                      |&nbsp;&nbsp;
                      {out(
                        s.translations[0].definition,
                        s.translations[1].definition,
                      )}
                    </label>
                  </div>
                </div>
              ))}
              {skills === null && <ComponentLoader />}
              {skills?.length < 1 && (
                <div className="text-center">
                  <h4 className={style.emptyList}>
                    <i className="fa fa-exclamation-triangle" />
                    &nbsp;
                    {out("Aucune compétence disponible", "No skills available")}
                  </h4>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="m-0">
          <FormHookFloatingLabel
            control={control}
            type="textarea"
            name="additionalTerms"
            style={{ height: "10rem" }}
            title={
              <>
                {out("Conditions supplémentaires", "Additional terms")}
                <span className={style.optional}>
                  {out(" (optionnel)", " (optional)")}
                </span>
              </>
            }
            mandatory={false}
            id="additionalTerms"
            data-antidoteapi_jsconnect_groupe_id="A"
            maxLength="1000"
            className="w-100"
            aria-multiline="true"
            aria-invalid="false"
            height="9.313rem"
          />
        </div>

        {/* kept until antidote confirmed to work with new changes */}
        {/* <div className="inputField m-0">
            <div className="p-0 text-start">
              <label htmlFor="terms" className={style["form-label"]}>
                {out("Conditions supplémentaires", "Additional terms")}
                <span className={style.optional}>
                  {out(" (optionnel)", " (optional)")}
                </span>
              </label>
            </div>
            <textarea
              data-antidoteapi_jsconnect_groupe_id="A"
              maxLength="1000"
              className="input w-100"
              aria-multiline="true"
              aria-invalid="false"
              {...register("additionalTerms")}
            />
          </div> */}

        {antidoteActive && (
          <Col xs={12} className="no-padding d-inline-flex">
            <AntidoteButton id="A" data-antidoteapi_jsconnect_lanceoutil="C" />
          </Col>
        )}

        <div className="mt-3 d-flex justify-content-end">
          <Button type="submit" variant="secondary">
            {out("Suivant", "Next")}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default AdditionalInfos;
