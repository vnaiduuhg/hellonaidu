import AdditionalInfos from "./AdditionalInfos";
import BasicInfos from "./BasicInfos";
import BudgetInfos from "./BudgetInfos";
import DefineJob from "./DefineJob";
import ManpowerInfos from "./ManpowerInfos";
import PreviewAndSubmit from "./PreviewAndSubmit";

export const requisitionWizardSteps = Object.freeze([
  {
    title: { en: "Define Job", fr: "Définir l'emploi" },
    name: "create",
    component: DefineJob,
  },
  {
    title: { en: "Basic Information", fr: "Informations de base" },
    name: "info",
    component: BasicInfos,
  },
  {
    title: { en: "Budget Information", fr: "Information budgétaire" },
    name: "budget",
    component: BudgetInfos,
  },
  {
    title: {
      en: "Manpower Plan Information",
      fr: "Information sur le plan de main-d'œuvre",
    },
    name: "manpower",
    component: ManpowerInfos,
  },
  {
    title: { en: "Additional Information", fr: "Information supplémentaire" },
    name: "additional",
    component: AdditionalInfos,
  },
  {
    title: { en: "Preview & Submit", fr: "Aperçu et publication" },
    name: "preview",
    component: PreviewAndSubmit,
  },
]);
