import { out } from "global/utils/useTranslation";

export const nameValidation = (required) => ({
  ...(required ? { required: out("Nom requis", "Name required") } : {}),
  minLength: { value: 2, message: out("Nom incorrect", "Invalid name") },
  maxLength: { value: 50, message: out("Nom incorrect", "Invalid name") },
});

export const emailValidation = (required) => ({
  ...(required ? { required: out("Courriel requis", "Email required") } : {}),
  pattern: {
    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
    message: out("Courriel invalide", "Invalid email address"),
  },
});
