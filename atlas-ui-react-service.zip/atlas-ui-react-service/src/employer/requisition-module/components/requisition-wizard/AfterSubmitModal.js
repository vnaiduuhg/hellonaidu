import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useHistory } from "react-router-dom";
import { useTranslation } from "global/utils/useTranslation";
import { useDispatch } from "react-redux";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";

const actionMessages = {
  create: {
    fr: "créée",
    en: "created",
  },
  edit: {
    fr: "modifiée",
    en: "modified",
  },
  clone: {
    fr: "clonifiée",
    en: "cloned",
  },
};

const AfterSubmitModal = ({ show, onHide, mode }) => {
  const { out } = useTranslation();
  const history = useHistory();
  const dispatch = useDispatch();

  const action = actionMessages[mode];

  return (
    <Modal show={show} onHide={onHide} backdrop="static" centered size="lg">
      <Modal.Header className="" closeButton>
        <h5 className="modal-title">
          {out(
            `Réquisition ${action.fr} avec succès!`,
            `Requisition ${action.en} successfully!`,
          )}
        </h5>
      </Modal.Header>
      <Modal.Body>
        <div className="text-start fw-bold">
          {out(
            "Que voulez-vous faire ensuite?",
            "What would you like to do next?",
          )}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button
          variant="secondary"
          onClick={() => {
            dispatch(
              requisitionWizardSlice.actions.switchCurrentRequisition({
                id: null,
              }),
            );
            history.replace("/planning");
          }}
        >
          {out(
            "Retour au tableau de bord de planification",
            "Back to planning dashboard",
          )}
        </Button>
        <Button
          variant="alt-secondary"
          onClick={() => {
            dispatch(
              requisitionWizardSlice.actions.switchCurrentRequisition({
                id: null,
              }),
            );
            history.replace("/requisition/create");
          }}
        >
          {out("Démarrer une nouvelle réquisition", "Create new requisition")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AfterSubmitModal;
