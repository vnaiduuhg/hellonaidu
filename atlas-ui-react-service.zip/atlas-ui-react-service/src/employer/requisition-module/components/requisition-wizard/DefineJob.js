import React, { useEffect } from "react";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import { useDispatch, useSelector } from "react-redux";
import { Button, Col, Row } from "react-bootstrap";
import requisitionWizardSlice from "employer/requisition-module/store/requisitionWizardSlice";
import { useTranslation } from "global/utils/useTranslation";
import { useHistory } from "react-router";
import { RequisitionJobsList } from "./requisition-jobs/RequisitionJobsList";
import styles from "./RequisitionWizard.module.css";

const DefineJob = () => {
  const { mode } = useSelector((state) => state.requisitionWizard);
  const dispatch = useDispatch();
  const history = useHistory();
  const { out } = useTranslation();

  useEffect(() => {
    if (mode !== "create") {
      dispatch(requisitionWizardSlice.actions.resetCurrentRequisition());
    }
  }, [mode]);

  const translatedTitle = out(
    "Démarrer une réquisition - Workland",
    "Create Requisition - Workland",
  );
  useEffect(() => {
    document.title = translatedTitle;
  }, [translatedTitle]);

  const createNewRequisitionWizard = () => {
    const id = "" + (Date.now() % 1000);
    dispatch(requisitionWizardSlice.actions.createNew({ id }));

    history.push(`/requisition/create/${id}/info`);
  };

  return (
    <div>
      <h1 className={`${styles.pageTitle} h4 pt-3 pb-2 visually-hidden`}>
        {out(
          requisitionWizardSteps.find(({ name }) => name === "create").title.fr,
          requisitionWizardSteps.find(({ name }) => name === "create").title.en,
        )}
      </h1>

      <Row className="m-0 my-md-5">
        <Col
          xs={12}
          md={6}
          as={Button}
          size="lg"
          id="create-requisition"
          className="offset-md-3"
          onClick={createNewRequisitionWizard}
        >
          {out("Démarrer une nouvelle réquisition", "Start New")}
        </Col>
      </Row>

      <Row className="mt-4">
        <Col className={styles.sectionSeparator} />
      </Row>

      <RequisitionJobsList />
    </div>
  );
};

export default DefineJob;
