import { useLayoutEffect } from "react";
import { useHistory, useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { showMessage } from "global/store/statusMessagesSlice";
import { requisitionWizardSteps } from "./requisitionWizardSteps";
import { useTranslation } from "global/utils/useTranslation";
import cx from "classnames";

const RequisitionSidebar = () => {
  const history = useHistory();
  let { operation, step, id: paramId } = useParams();
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const wiz = useSelector((state) => state.requisitionWizard);
  const { id: lastId, requisitionsInProgress } = wiz;

  const routeSteps = !["clone", "edit"].includes(operation)
    ? [...requisitionWizardSteps]
    : requisitionWizardSteps.slice(1);

  let currentStep = step
    ? routeSteps.findIndex((s) => s.name === step.toLowerCase())
    : 0;

  if (currentStep === 0 && !operation) {
    operation = requisitionsInProgress[lastId]?.mode ?? "create";
  } else {
    operation = ["create", "clone", "edit"].includes(operation)
      ? operation
      : "create";
  }

  // currently selected id should be provided by the url. but there
  // is one condition where it is not provided: /requisition/create
  // retrieve the last used and set it so it's navigable
  let currentId = lastId;

  let completedSteps = requisitionsInProgress[currentId]?.completed ?? 0;

  let title;
  switch (operation) {
    case "edit":
      title = out("Modifier une réquisition", "Update Requisition");
      completedSteps -= 1;
      break;
    case "clone":
      title = out("Cloner une réquisition", "Clone Requisition");
      completedSteps -= 1;
      break;
    default:
      title = out("Démarrer une réquisition", "Create Requisition");
  }

  // ids with prefix clone- & job- should have it removed for their
  // respective routes
  // const routeId = (currentId ?? "").split("-").reverse()[0];
  const routeId = currentId;

  const switchStep = (index, name) => {
    let path;
    if (operation === "create" && index === 0) {
      path = "/requisition/create";
    } else {
      path = `/requisition/${operation}/${routeId}/${name}`;
    }

    if (index >= completedSteps) {
      dispatch(
        showMessage(
          "error",
          out("Interdit", "Not Allowed"),
          out(
            "S'il vous plaît remplir la page actuelle pour continuer",
            "Please fill out the current page to proceed",
          ),
          3200,
        ),
      );
      // TODO: remove once done
      // dispatch(requisitionWizardSlice.actions.setStep(index));
      // history.push(path);
    } else {
      history.push(path);
    }
  };

  useLayoutEffect(() => {
    window.addEventListener("resize", window.design.sidebar.handleResize);
    window.design.sidebar.initDropdowns();

    return () =>
      window.removeEventListener("resize", window.design.sidebar.handleResize);
  }, []);

  // TODO: pick the correct translation for the navigation titles
  return (
    <nav
      className={`sidebar sidebar-small ${window.design.sidebar.getSidebarStateForScreenSize()}`}
      aria-labelledby="sidebar-title"
      ref={() => window.design.sidebar.rcInit("create-requisition")}
    >
      {/*background arc */}
      <div id="arc" />

      {/* optional title */}
      <div id="sidebar-title">{title}</div>

      <button
        className="sidebar-collapse-button"
        onClick={() => window.design.sidebar.toggleSidebar()}
      />

      <div className="sidebar-navigation-viewport">
        <ul className="sidebar-navigation">
          {routeSteps.map((s, i) => {
            const timelineDone = completedSteps > i;
            const currentStage = i === currentStep;

            return (
              <li
                className="sidebar-navigation-item ng-init"
                key={s.name}
                onClick={() => switchStep(i, s.name)}
              >
                <a
                  role="button"
                  href="#"
                  className={cx("sidebar-nav-link", {
                    active: currentStage,
                    incomplete: !timelineDone && !currentStage,
                  })}
                >
                  <span
                    className={cx("icon", {
                      completed: timelineDone,
                    })}
                  >
                    <span hidden={timelineDone}>{i + 1}</span>
                    <i className="fa fa-check" hidden={!timelineDone} />
                  </span>
                  <span className="text">{out(s.title.fr, s.title.en)}</span>
                </a>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};

export default RequisitionSidebar;
