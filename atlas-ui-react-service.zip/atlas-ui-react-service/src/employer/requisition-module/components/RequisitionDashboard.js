import React, { useState, useRef, useEffect, useCallback } from "react";
import { useQuery } from "react-query";
import { batch, useSelector } from "react-redux";
import moment from "moment";
import DateFilterModal from "employer/requisition-module/components/DateFilterModal";
import StatusFilterModal from "./StatusFilterModal";
import GroupFilterModal from "./GroupFilterModal";
import RequisitionActiveFilters from "./requisition-active-filters";
import ActionButton from "global/components/action-button/action-button";
import { datetimeToUTC } from "global/utils/dateTimeLanguageUtils";
import { getRequisitionGroupsByAccount } from "../api/requisitionGroupApi";
import { searchRequisitions } from "../api/requisitionApi";
import { getRequisitionsStatusList } from "../api/RequisitionStatusApi";
import useAtlasQuery from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import { GradientHeaderWrapper } from "global/components/gradient-header/gradient-header-wrapper";
import { GradientHeaderStatsWidget } from "global/components/gradient-header/gradient-header-stats-widget";
import { GradientHeaderIconWidget } from "global/components/gradient-header/gradient-header-icon-widget";
import { SearchBar } from "global/components/search-bar/search-bar";
import {
  BsCashStack,
  BsCheckSquare,
  BsFunnel,
  BsFunnelFill,
  BsGrid,
  BsList,
  BsSearch,
  BsSquare,
} from "react-icons/bs";
import { Cliffhanger } from "global/components/cliffhanger/cliffhanger";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { RequisitionList } from "./RequisitionList";
import { PaginationBar } from "global/components/pagination/pagination-bar";
import { AtlasAlert } from "global/components/atlas-alert";
import { Dropdown } from "react-bootstrap";
import { requisitionStats } from "../utils/dashboardUtils";
import { getLocallyFormattedNumber } from "global/utils/numberFormatUtils";
import styles from "../assets/requisition-dashboard.module.scss";
import debounce from "global/utils/debounce";
import { useRequisitionReviewers } from "../hooks/useRequisitionReviewers";
import { AnimateHeight } from "global/utils/animate-height";
import { IoRadioButtonOff, IoRadioButtonOn } from "react-icons/io5";

const RequisitionDashboardNew = ({ createRequisition }) => {
  const { out } = useTranslation();
  const user = useSelector((state) => state.user.data);
  const [showArchived, setShowArchived] = useState(false);
  const [showMyRequisitions, setShowMyRequisitions] = useState(false);
  const [roleFilter, setRoleFilter] = useState(null);
  const [jobTitleFitler, setJobTitleFilter] = useState("");
  const [groupsFilter, setGroupsFilter] = useState("");
  const [showGroups, setShowGroups] = useState(false);
  const [statusesFilter, setStatusesFilter] = useState([]);
  const [showStatus, setShowStatus] = useState(false);
  const [showDatePickerModal, setShowDatePickerModal] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(datetimeToUTC(moment(), "flatTime"));
  const [dateFilter, setDateFilter] = useState({});
  const [requisitionPage, setRequisitionPage] = useState(1); // for changing pages
  const [layout, setLayout] = useState("list");

  const pageSize = useSelector(
    (state) =>
      state.settings.paginationItemsPerPage.requisitionDashboard ??
      state.settings.paginationItemsPerPage.default,
  );

  const { data: groupsList } = useAtlasQuery("requisition-groups", () =>
    getRequisitionGroupsByAccount(user.user_account.account_id),
  );

  const { data: statusList = [] } = useQuery(
    "requisition-statuses",
    getRequisitionsStatusList,
    {
      refetchOnWindowFocus: false,
    },
  );

  const { isUserAReviewer, reviewersList } = useRequisitionReviewers();

  // initialize
  useEffect(() => {
    if (isUserAReviewer !== null) {
      if (isUserAReviewer) {
        setRoleFilter("reviewer");
      } else {
        setRoleFilter("creator");
      }
    }
  }, [isUserAReviewer]);

  // Use all the filters set as state to build the search request from the
  // backend. This will async load make the request and store it in requisitions
  // array and cache it.
  let {
    data: requisitions,
    isError: isErrorRequisition,
    isLoading: isLoadingRequisition,
  } = useAtlasQuery(
    [
      "requisitions",
      {
        dateFilter,
        jobTitleFitler,
        groupsFilter,
        statusesFilter,
        showArchived,
        roleFilter: showMyRequisitions ? roleFilter : "",
        page: requisitionPage,
        pageSize,
      },
    ],
    // build search api query builder using above filter states
    () => {
      const backendFilters = {
        ...(dateFilter.beforeDate
          ? { before_date: dateFilter.beforeDate }
          : {}),
        ...(dateFilter.afterDate ? { after_date: dateFilter.afterDate } : {}),
        ...(jobTitleFitler ? { job_title: jobTitleFitler } : {}),
        ...(groupsFilter ? { group_name: groupsFilter } : {}),
        ...(statusesFilter.length ? { status_ids: statusesFilter } : []),
        ...(showMyRequisitions ? { role: roleFilter } : {}),
        ...(showArchived !== null ? { archived: showArchived } : {}),
        page: requisitionPage,
        pageSize,
      };

      return searchRequisitions(backendFilters);
    },
  );

  const maxPages = useRef(1);
  if (!isLoadingRequisition) {
    maxPages.current = requisitions?.last_page ?? 1;
  }

  let content;

  if (isLoadingRequisition) {
    content = (
      <NestedPageLoader
        message={out(
          "Nous récupérons les réquisitions",
          "Fetching requisitions",
        )}
      />
    );
  } else if (isErrorRequisition) {
    content = (
      <AtlasAlert variant="error" className="my-5">
        {out(
          "Un problème est survenu lors du chargement des réquisitions. Veuillez réessayer ou contacter support@workland.com si le problème persiste.",
          "There was a problem loading the requisitions. Please try again or contact support@workland.com if the problem persists.",
        )}
      </AtlasAlert>
    );
  } else {
    // Done loading: show Requisition Tab
    content =
      requisitions?.data && requisitions?.data?.length ? (
        <RequisitionList
          requisitions={requisitions.data}
          layout={layout}
          statusList={statusList}
          reviewersList={reviewersList}
          user={user}
        />
      ) : (
        <AtlasAlert variant="info" className="my-5">
          {/* @todo add date filter when available */}
          {statusesFilter.length ||
          jobTitleFitler ||
          groupsFilter ||
          showArchived
            ? out(
                "Aucune réquisition trouvée avec les filtres activés",
                "No requisition found with the filters enabled",
              )
            : out(
                "Vous n'avez pas de réquisition pour le moment",
                "You have no requisition for the moment",
              )}
        </AtlasAlert>
      );
  }

  const stats =
    !isLoadingRequisition && !isErrorRequisition
      ? requisitionStats(requisitions.data)
      : null;

  const debouncedSearch = useCallback(
    debounce((s) => {
      if (s.length > 2 || s.length === 0) setJobTitleFilter(s);
    }, 500),
    [],
  );

  return (
    <>
      <div className="page-wrapper-internal-page">
        <div className="content-container">
          <div className="d-flex flex-column h-100">
            {/* new structure */}
            <GradientHeaderWrapper
              left={[
                <GradientHeaderStatsWidget
                  key="total-pending"
                  content={
                    !isLoadingRequisition && Number.isInteger(stats?.pendingSum)
                      ? stats.pendingSum
                      : "-"
                  }
                  label={out("Total en attente", "Total Pending")}
                  isLoading={isLoadingRequisition}
                />,
                <GradientHeaderStatsWidget
                  key="total-approved"
                  content={
                    !isLoadingRequisition &&
                    Number.isInteger(stats?.approvedSum)
                      ? stats.approvedSum
                      : "-"
                  }
                  label={out("Total Approuvées", "Total Approved")}
                  isLoading={isLoadingRequisition}
                />,
              ]}
              right={[
                <GradientHeaderIconWidget
                  key="salary-per-year"
                  content={
                    stats
                      ? `\$${getLocallyFormattedNumber(
                          (stats?.salaryMinSum ?? 0) / 100,
                        )} - \$${getLocallyFormattedNumber(
                          (stats?.salaryMaxSum ?? 0) / 100,
                        )}`
                      : "-"
                  }
                  label={out("Salaire/an", "Salary/year")}
                  icon={<BsCashStack size="2rem" className="text-secondary" />}
                  isLoading={isLoadingRequisition}
                  className={styles.salaryStatsWidget}
                />,
              ]}
            />
            <Cliffhanger>
              <SearchBar
                id="requisition-search"
                icon={<BsSearch className="text-secondary fs-5" />}
                label={out(
                  "Rechercher des réquisitions",
                  "Search requisitions",
                )}
                searchString={jobTitleFitler}
                onSearchChange={debouncedSearch}
                filterType="checkbox"
                filters={[
                  {
                    value: "date",
                    label: "Date",
                    onClick: () => {
                      if (!!dateFilter?.beforeDate || !!dateFilter?.afterDate) {
                      }
                      setShowDatePickerModal((currentlyShown) => {
                        if (currentlyShown) {
                          return false;
                        } else {
                          return true;
                        }
                      });
                    },
                    checked:
                      !!dateFilter?.beforeDate || !!dateFilter?.afterDate,
                  },
                  {
                    value: "status",
                    label: out("Statut", "Status"),
                    onClick: () => {
                      setShowStatus(true);
                    },
                    checked: statusesFilter.length > 0,
                  },
                  {
                    value: "group",
                    label: out("Groupe", "Group"),
                    onClick: () => {
                      setShowGroups(true);
                    },
                    checked: !!groupsFilter,
                  },
                ]}
                currentFilter={null}
                removeOutline={true}
              />
            </Cliffhanger>

            <div className="d-flex py-3 px-5">
              <div className="d-flex align-items-center">
                <Dropdown
                  className="user-select-none"
                  drop="end"
                  autoClose="outside"
                >
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    {showArchived ||
                    showMyRequisitions ||
                    (statusesFilter.length === 1 && statusesFilter[0] === 1) ? (
                      <BsFunnelFill className="text-secondary fs-5" />
                    ) : (
                      <BsFunnel className="text-secondary fs-5" />
                    )}

                    <span className="pe-1 ms-2 me-1 fw-bold text-secondary">
                      {out("Filtres", "Filters")}
                    </span>
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Header className="py-1 pb-0">
                      {out("Propriété", "Ownership")}
                    </Dropdown.Header>

                    {/* FIXME: Find better icons and background colour effects */}

                    <Dropdown.Item
                      onClick={() => {
                        batch(() => {
                          setRequisitionPage(1);
                          setRoleFilter("");
                          setShowMyRequisitions(false);
                        });
                      }}
                    >
                      <span className="me-1">
                        {!showMyRequisitions ? (
                          <IoRadioButtonOn className="fs-5 text-secondary" />
                        ) : (
                          <IoRadioButtonOff className="fs-5 text-secondary" />
                        )}
                      </span>
                      {out("Toutes les réquisitions", "All Requisitions")}
                    </Dropdown.Item>
                    <Dropdown.Item
                      onClick={() => {
                        batch(() => {
                          setRequisitionPage(1);
                          setShowMyRequisitions(true);
                          setRoleFilter("reviewer");
                        });
                      }}
                    >
                      <span className="me-1">
                        {showMyRequisitions ? (
                          <IoRadioButtonOn className="fs-5 text-secondary" />
                        ) : (
                          <IoRadioButtonOff className="fs-5 text-secondary" />
                        )}
                      </span>
                      {out("Mes réquisitions", "My Requisitions")}
                    </Dropdown.Item>

                    <Dropdown.Divider />

                    <AnimateHeight
                      variants={{
                        open: { height: "auto" },
                        collapsed: { height: 0 },
                      }}
                      isVisible={showMyRequisitions}
                    >
                      <div>
                        <Dropdown.Header className="py-1 pb-0">
                          {out("Rôle", "Role")}
                        </Dropdown.Header>

                        <Dropdown.Item
                          onClick={() => {
                            batch(() => {
                              setShowMyRequisitions(true);
                              setRoleFilter("reviewer");
                            });
                          }}
                        >
                          <span className="me-1">
                            {roleFilter === "reviewer" ? (
                              <IoRadioButtonOn className="fs-5 text-secondary" />
                            ) : (
                              <IoRadioButtonOff className="fs-5 text-secondary" />
                            )}
                          </span>
                          {out("Évaluateur", "Reviewer")}
                        </Dropdown.Item>

                        <Dropdown.Item
                          onClick={() => {
                            batch(() => {
                              setShowMyRequisitions(true);
                              setRoleFilter("creator");
                            });
                          }}
                        >
                          <span className="me-1">
                            {roleFilter === "creator" ? (
                              <IoRadioButtonOn className="fs-5 text-secondary" />
                            ) : (
                              <IoRadioButtonOff className="fs-5 text-secondary" />
                            )}
                          </span>
                          {out("Créateur", "Creator")}
                        </Dropdown.Item>

                        <Dropdown.Divider />
                      </div>
                    </AnimateHeight>

                    <Dropdown.Header className="py-1 pb-0">
                      {out("Statut", "Status")}
                    </Dropdown.Header>
                    <Dropdown.Item
                      onClick={() =>
                        batch(() => {
                          setRequisitionPage(1);
                          setShowArchived(!showArchived);
                        })
                      }
                    >
                      <span className="me-2">
                        {showArchived ? (
                          <BsCheckSquare className="text-secondary" />
                        ) : (
                          <BsSquare className="text-secondary" />
                        )}
                      </span>
                      {out("Archivé", "Archived")}
                    </Dropdown.Item>
                    <Dropdown.Item
                      onClick={() => {
                        // if only submitted status is set, unset that,
                        // otherwise leave statuses alone
                        if (
                          statusesFilter.length === 1 &&
                          statusesFilter[0] === 1
                        ) {
                          setStatusesFilter([]);
                        } else {
                          setStatusesFilter([1]);
                        }

                        setRequisitionPage(1);
                      }}
                    >
                      <span className="rounded me-2">
                        {statusesFilter.length === 1 &&
                        statusesFilter[0] === 1 ? (
                          <BsCheckSquare className="text-secondary" />
                        ) : (
                          <BsSquare className="text-secondary" />
                        )}
                      </span>
                      {out("En attente d'approbation", "Awaiting approval")}
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>

              <div className="flex-grow-1 mx-2 mt-1">
                <RequisitionActiveFilters
                  jobTitle={jobTitleFitler}
                  statusesFilter={statusesFilter}
                  groupsFilter={groupsFilter}
                  statusList={statusList}
                  dateFilter={dateFilter}
                  today={datetimeToUTC(moment(), "flatTime")}
                  setJobTitleFilter={setJobTitleFilter}
                  setStatusesFilter={setStatusesFilter}
                  setGroupsFilter={setGroupsFilter}
                  setStartDate={setStartDate}
                  setEndDate={setEndDate}
                  setDateFilter={setDateFilter}
                  showMyRequisitions={showMyRequisitions}
                  showArchived={showArchived}
                  setShowArchived={setShowArchived}
                  setRoleFilter={setRoleFilter}
                  setRequisitionPage={setRequisitionPage}
                />
              </div>

              <div className="ms-auto d-none d-xl-block">
                {/* start of button group */}
                {/* TODO: New fature: load selected display option from settings slice */}
                <div
                  className="btn-group"
                  role="group"
                  title={out(
                    "Modifier la mise en page",
                    "Switch requisition layout",
                  )}
                  aria-label={out(
                    "Modifier la mise en page",
                    "Switch requisition layout",
                  )}
                >
                  <input
                    id="layout-grid"
                    type="radio"
                    className="btn-check"
                    autoComplete="off"
                    value="grid"
                    checked={layout === "grid"}
                    onChange={({ currentTarget: { value } }) =>
                      setLayout(value)
                    }
                  />
                  <label
                    className="btn btn-outline-secondary"
                    htmlFor="layout-grid"
                  >
                    <BsGrid />
                  </label>

                  <input
                    id="layout-list"
                    type="radio"
                    className="btn-check"
                    autoComplete="off"
                    value="list"
                    checked={layout === "list"}
                    onChange={({ currentTarget: { value } }) =>
                      setLayout(value)
                    }
                  />
                  <label
                    className="btn btn-outline-secondary"
                    htmlFor="layout-list"
                  >
                    <BsList />
                  </label>
                </div>
                {/* end of button group */}
              </div>
            </div>

            {/* start cards section */}
            <section className="py-0 px-5 flex-fill">{content}</section>
            {/* end cards section */}

            <PaginationBar
              // prevent the pages display from hiding the action button
              className="mb-5 pt-1 pb-5 px-5"
              active={requisitionPage}
              pages={maxPages.current}
              onPageChange={(_, newPageNum) =>
                newPageNum && setRequisitionPage(newPageNum)
              }
              onDisplayPerPageChange={() => setRequisitionPage(1)}
              paginationKey="requisitionDashboard"
            />

            {/* end of new struture */}
          </div>
        </div>
      </div>

      <div className="w-100 py-3" />
      <ActionButton click={createRequisition} />

      {/* Modals section */}
      <DateFilterModal
        show={showDatePickerModal}
        hide={() => setShowDatePickerModal(false)}
        startDate={startDate}
        endDate={endDate}
        today={datetimeToUTC(moment(), "flatTime")}
        setStartDate={setStartDate}
        setEndDate={setEndDate}
        setDateFilter={(e) => setDateFilter(e)}
        setPage={setRequisitionPage}
      />

      <StatusFilterModal
        show={showStatus}
        statusList={statusList}
        statusesFilter={statusesFilter}
        setStatusesFilter={setStatusesFilter}
        setShowStatus={setShowStatus}
        setPage={setRequisitionPage}
      />

      <GroupFilterModal
        show={showGroups}
        itemList={groupsList}
        selectedItem={groupsFilter}
        setItemFilter={setGroupsFilter}
        setShowModal={setShowGroups}
        setPage={setRequisitionPage}
      />
    </>
  );
};

export default RequisitionDashboardNew;
