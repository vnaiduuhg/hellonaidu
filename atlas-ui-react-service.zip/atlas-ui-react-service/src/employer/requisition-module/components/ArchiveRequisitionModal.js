import React from "react";
import { useMutation, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { Button, Modal } from "react-bootstrap";
import { deleteRequisition } from "../api/requisitionApi";
import { archivesDeleteMsgHandler } from "../utils/archiveMsgHandler";
import { useTranslation } from "global/utils/useTranslation";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";

const ArchiveRequisitionModal = ({ show, hide, requisition }) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  const reviewersPostMutation = useMutation((id) => deleteRequisition(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("requisitions");
      const msg = archivesDeleteMsgHandler(204);
      dispatch(showMessage("ok", msg.title, msg.text, 5000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
    onError: (error) => {
      const msg = archivesDeleteMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 5000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  return (
    <Modal show={show} onHide={hide}>
      <Modal.Header closeButton>
        <Modal.Title>{out("Êtes-vous sûr?", "Are you sure?")}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <p>
          {out(
            "Une fois archivée, la réquisition ne sera accessible qu'en mode lecture",
            "Once archived, the requisition will only be accessible in read mode",
          )}
        </p>

        <hr />

        <p>
          {out("Archiver la requisition: ", "Archive requisition: ")}
          &nbsp;
          <b>
            {out(
              requisition.job.translations[1].title,
              requisition.job.translations[0].title,
            )}
          </b>
        </p>
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="primary"
          type="submit"
          onClick={() => {
            reviewersPostMutation.mutate(requisition.id);
            dispatch(showLoadingBarWithoutMessage(200000));
            hide();
          }}
        >
          {out("Archiver", "Archive")}
        </Button>

        <Button variant="alt-secondary" type="reset" onClick={() => hide()}>
          {out("Annuler", "Cancel")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ArchiveRequisitionModal;
