import React, { useCallback } from "react";
import { useTranslation } from "global/utils/useTranslation";
import moment from "moment";
import "moment/locale/fr";
import styles from "./RequisitionHistoryEntries.module.scss";

const RequisitionHistoryEntry = (props) => {
  const { out } = useTranslation();
  moment.locale(out("fr", "en"));

  const getTitle = useCallback((actionType) => {
    switch (actionType) {
      case "create: requisition":
        return out("Réquisition créée", "Created");
      case "delete: requisition":
        return out("Réquisition archivée", "Archived");
      default:
        return out("Mise à jour", "Updated");
    }
  });

  const historyTranslation = useCallback((actionType) => {
    // The 'update' action has several fields, so it must use concatenation
    let msg = "";

    if (typeof actionType === "string") {
      if (actionType.includes("status")) {
        msg += out("statut, ", "status, ");
      }
      if (actionType.includes("fr.group_name")) {
        msg += out("groupe de réquisition FR, ", "requisition group FR, ");
      }
      if (actionType.includes("en.group_name")) {
        msg += out("groupe de réquisition EN, ", "requisition group EN, ");
      }
      if (actionType.includes("grade")) {
        msg += out("classe, ", "grade, ");
      }
      if (actionType.includes("number_of_positions")) {
        msg += out("nombre de positions, ", "number of positions, ");
      }
      if (actionType.includes("locations")) {
        msg += out("emplacements, ", "locations, ");
      }
      if (actionType.includes("types")) {
        msg += out("type de poste, ", "job type, ");
      }
      if (actionType.includes("skills")) {
        msg += out("compétences, ", "skills, ");
      }
      if (actionType.includes("reports_to_name")) {
        msg += out("personne responsable, ", "person responsible, ");
      }
      if (actionType.includes("approval_required")) {
        msg += out("approbation requise, ", "approval required, ");
      }
      if (actionType.includes("within_budget")) {
        msg += out("état budgétaire, ", "budget status, ");
      }
      if (
        actionType.includes("hiring_manager_name") ||
        actionType.includes("hiring_manager_department")
      ) {
        msg += out("gestionnaire d'embauche, ", "hiring manager, ");
      }
      if (actionType.includes("planned_salary")) {
        msg += out("salaire, ", "salary, ");
      }
      // if (actionType.includes("job")) {
      //   msg += out("poste, ", "job, ");
      // }
      if (
        actionType.includes(",reviewers") ||
        actionType.includes("reviewers,")
      ) {
        msg += out("examinateurs, ", "reviewers, ");
      }
      if (actionType.includes("number_of_reviewers")) {
        msg += out("nombre d'examinateurs, ", "number of reviewers, ");
      }
      if (actionType.includes("revision_comments")) {
        msg += out("commentaires de révision, ", "revision comments, ");
      }
      if (actionType.includes("fr.hire_type")) {
        msg += out("type d'embauche FR, ", "hire type FR, ");
      }
      if (actionType.includes("en.hire_type")) {
        msg += out("type d'embauche EN, ", "hire type EN, ");
      }
      if (actionType.includes("fr.hire_reason")) {
        msg += out("raison pour l'embauche FR, ", "hire reason FR, ");
      }
      if (actionType.includes("en.hire_reason")) {
        msg += out("raison pour l'embauche EN, ", "hire reason EN, ");
      }
      if (actionType.includes("is_unionized")) {
        msg += out("syndiqué, ", "unionized, ");
      }
      if (actionType.includes("fr.additional_terms")) {
        msg += out("conditions supplémentaires FR, ", "additional terms FR, ");
      }
      if (actionType.includes("en.additional_terms")) {
        msg += out("conditions supplémentaires EN, ", "additional terms EN, ");
      }
      if (actionType.includes("is_diversity_plan")) {
        msg += out("plan de diversité, ", "diversity plan, ");
      }
      if (actionType.includes("fr.rejection_reason")) {
        msg += out("motif de rejet FR, ", "rejection reason FR, ");
      }
      if (actionType.includes("en.rejection_reason")) {
        msg += out("motif de rejet EN, ", "rejection reason EN, ");
      }
      if (actionType.includes("fr.budget_explanation")) {
        msg += out("explication budgétaire FR, ", "budget explanation FR, ");
      }
      if (actionType.includes("en.budget_explanation")) {
        msg += out("explication budgétaire EN, ", "budget explanation EN, ");
      }
      if (actionType.includes("yearly_manpower_plan")) {
        msg += out("plan annuel de main-d'oeuvre, ", "yearly manpower plan, ");
      }
    }

    return msg.charAt(0).toUpperCase() + msg.trim().slice(1, -1);
  });

  return props.hits.map(({ _source: entry }, i) => {
    const utc_date = moment.tz(entry.date, "UTC");
    const local_date = moment.utc(utc_date).local();

    return (
      <div
        key={i}
        className={`d-flex ${!!(i + 1 < props.hits.length) && "mb-4"}`}
      >
        <div
          className={`me-3 ${styles.node} ${
            !!(i + 1 < props.hits.length) && styles.vector
          }`}
        >
          <div className={styles.iconOuter}>
            <div className={styles.iconInner} />
          </div>
        </div>
        <div className="flex-fill pb-3">
          <h6 className="">{getTitle(entry.action_type)}</h6>

          <div className="text-start mt-2">
            {historyTranslation(entry.action_type)}
          </div>

          <div className="mt-2">
            {out("Par ", "By ")}
            <span className="text-secondary-200">
              {entry.name} - {local_date.format("ll")} -{" "}
              {local_date.format("HH:mm")}
            </span>
          </div>
        </div>
      </div>
    );
  });
};
export default RequisitionHistoryEntry;
