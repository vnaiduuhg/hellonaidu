import React from "react";
import { batch } from "react-redux";
import style from "../assets/FiltersModal.module.scss";
import { useTranslation } from "global/utils/useTranslation";

const RequisitionActiveFilters = ({
  jobTitle,
  statusesFilter,
  groupsFilter,
  statusList,
  dateFilter,
  today,
  setJobTitleFilter,
  setStatusesFilter,
  setGroupsFilter,
  setStartDate,
  setEndDate,
  setDateFilter,
  showMyRequisitions,
  showArchived,
  setShowArchived,
  setRoleFilter,
  setRequisitionPage,
}) => {
  const { out } = useTranslation();

  return (
    <div className={style.activeFilter}>
      {statusesFilter.length > 0 && (
        <div className={style.filter}>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setStatusesFilter([]);
                if (!showMyRequisitions) setRoleFilter("");
              });
            }}
          >
            {/* FIXME: switch to the one from locations */}
            <i className="fa fa-times" />
          </span>
          <span className={`${style.activeFilterTitle}`}>
            {out("Statut", "Status")}:
          </span>
          {statusesFilter.map((id, i) => {
            return (
              <span className={style.activeFilterSpan} key={id}>
                {statusList.map((s) => {
                  if (s.id === id) {
                    return (
                      <span key={s.id}>
                        {out(s.translations[1].name, s.translations[0].name)}
                      </span>
                    );
                  }
                })}
                {i + 1 < statusesFilter.length && <span>, </span>}
              </span>
            );
          })}
        </div>
      )}

      {jobTitle && (
        <div className={style.filter}>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setJobTitleFilter("");
              });
            }}
          >
            <i className="fa fa-times" />
          </span>
          <span className={style.activeFilterTitle}>
            {out("Rechercher", "Search")}:
          </span>
          <span className={style.activeFilterSpan}>{jobTitle}</span>
        </div>
      )}
      {showArchived && (
        <div className={style.filter}>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setShowArchived(!showArchived);
              });
            }}
          >
            <i className="fa fa-times" />
          </span>
          <span className={style.activeFilterTitle}>
            {out("Archivé", "Archived")}
          </span>
        </div>
      )}

      {groupsFilter && (
        <div className={style.filter}>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setGroupsFilter("");
              });

              // FIXME: group filter should not be set like this, it needs
              // be be a derived prop
              // setGroupFilterActive(false);
            }}
          >
            <i className="fa fa-times"></i>
          </span>
          <span className={style.activeFilterTitle}>
            {out("Groupe", "Group")}:
          </span>
          <span className={style.activeFilterSpan}>{groupsFilter}</span>
        </div>
      )}

      {dateFilter.beforeDate && dateFilter.afterDate && (
        <div className={style.filter}>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              setStartDate(null);
              setEndDate(today);
              batch(() => {
                setRequisitionPage(1);
                setDateFilter({
                  beforeDate: null,
                  afterDate: null,
                });
              });
            }}
          >
            <i className="fa fa-times" />
          </span>
          <span className={style.activeFilterTitle}>
            {out("Dates", "Dates")}:
          </span>
          <span className={style.activeFilterSpan}>
            {out("du ", "from")}&nbsp;
            {dateFilter.afterDate}&nbsp;
            {out("au ", "to")}&nbsp;
            {dateFilter.beforeDate}
          </span>
        </div>
      )}
    </div>
  );
};

export default RequisitionActiveFilters;
