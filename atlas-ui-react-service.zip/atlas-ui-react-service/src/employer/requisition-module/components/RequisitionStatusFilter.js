import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasSelect } from "global/components/select/atlas-select";

const RequisitionStatusFilter = ({ statusList, statuses, setStatus }) => {
  const { out } = useTranslation();

  const options = (statusList ?? []).map((s) => ({
    value: s.id,
    label: out(s.translations[1].name, s.translations[0].name),
  }));

  const values = (statuses ?? [])
    .map((s) => statusList.find((l) => +l.id === +s))
    .map((s) => ({
      value: s.id,
      label: out(s.translations[1].name, s.translations[0].name),
    }));

  return (
    <AtlasSelect
      isMulti={true}
      options={options}
      value={values}
      placeholder={out(
        "Sélectionnez un ou plusieurs statuts",
        "Select one or more statuses",
      )}
      onChange={(selected) =>
        setStatus([...selected.map((v) => +v.value)].sort())
      }
    />
  );
};

export default RequisitionStatusFilter;
