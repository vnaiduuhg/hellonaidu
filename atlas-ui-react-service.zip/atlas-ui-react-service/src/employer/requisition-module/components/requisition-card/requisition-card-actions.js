import React, { useState, useEffect } from "react";
import { useHistory } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useMutation, useQueryClient } from "react-query";
import { updateRequisitionReviewerStatus } from "../../api/requisitionApi";
import {
  cloneRequisition,
  updateRequisition,
} from "employer/requisition-module/store/requisitionWizardSlice";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";
import { reviewersStatusPatchMsgHandler } from "../../utils/reviewersMsgHandler";
import { useTranslation } from "global/utils/useTranslation";
import ArchiveRequisitionModal from "../ArchiveRequisitionModal";
import ActionsStatusModal from "../ActionsStatusModal";
import { ATLAS_UI_URL } from "config";
import styles from "./requisition-card.module.scss";
import { Dropdown } from "react-bootstrap";
import { FaEllipsisV } from "react-icons/fa";

const DropdownActionItem = ({ icon, label, onClick }) => (
  <Dropdown.Item href="#" onClick={onClick}>
    <i className={`${icon} me-2`} />
    {label}
  </Dropdown.Item>
);

export const RequisitionCardActions = ({
  requisition,
  statusList,
  reviewersList,
}) => {
  const { out } = useTranslation();
  const queryClient = useQueryClient();
  const history = useHistory();
  const dispatch = useDispatch();
  const [showModalStatus, setShowModalStatus] = useState(false);
  const [statusEditMode, setStatusEditMode] = useState(false);
  const [readMode, setReadMode] = useState(null);
  const { isAdmin } = useSelector((s) => s.user.permissions);
  const user = useSelector((state) => state.user.data);
  const currentLanguage = useSelector((state) => state.user.language);
  const [showArchiveRequisitionModal, setShowArchiveRequisitionModal] =
    useState(false);

  const updateReviewerStatus = useMutation(
    (data) => updateRequisitionReviewerStatus(requisition.id, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("requisitions");
        dispatch(statusMessagesSlice.actions.clearLoaders());
        const msg = reviewersStatusPatchMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 8000));
      },
      onError: (error) => {
        const msg = reviewersStatusPatchMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  const publishJob = () => {
    sessionStorage.setItem("jobId", requisition.job_id);
    window.location = `${ATLAS_UI_URL}/update-job`;
  };

  const cloneRequisitionRedirect = () => {
    dispatch(cloneRequisition(requisition.id, history.push));
  };

  const editRequisitionRedirect = () => {
    dispatch(updateRequisition(requisition.id, history.push));
  };

  const saveStatus = (e) => {
    const data = {
      status_id: e.status.id,
      status_name: e.status.name,
    };
    if (e.status.name === "Rejected") {
      data.rejection_reason = {};
      data.rejection_reason.translations = [
        {
          locale: currentLanguage,
          rejection_reason: e.text,
        },
      ];
    }
    if (e.status.name === "Changes Requested") {
      data.revision_comments = {};
      data.revision_comments.translations = [
        {
          locale: currentLanguage,
          comment: e.text,
        },
      ];
    }
    updateReviewerStatus.mutate(data);
    dispatch(showLoadingBarWithoutMessage(200000));
  };

  return (
    <>
      <Dropdown drop="start" className="mt-2">
        <Dropdown.Toggle
          variant="dropdown"
          // variant="secondary"
          className={styles.dropdownButton}
        >
          <i className="fa-solid fa-ellipsis-vertical fs-3 text-primary-300 p-1" />
          {/* <FaEllipsisV className="fs-3 text-primary-300" /> */}
        </Dropdown.Toggle>

        <Dropdown.Menu x>
          {([5, 6].includes(requisition.status_id) ||
            !requisition.approval_required) &&
            !requisition.deleted_at && (
              <DropdownActionItem
                icon="fa fa-eye"
                label={out("Publier", "Publish")}
                onClick={publishJob}
              />
            )}
          {!requisition.deleted_at && (
            <DropdownActionItem
              icon="fa fa-clone"
              label={out("Dupliquer", "Clone")}
              onClick={cloneRequisitionRedirect}
            />
          )}
          {(isAdmin || +requisition.creator_user_id === +user.user_id) &&
            [1, 2, 3].includes(requisition.status_id) &&
            !requisition.deleted_at && (
              <DropdownActionItem
                icon="fa fa-pencil-square-o"
                variant="secondary"
                label={out("Modifier", "Edit")}
                onClick={editRequisitionRedirect}
              />
            )}
          {(isAdmin || +requisition.creator_user_id === +user.user_id) &&
            !requisition.deleted_at && (
              <DropdownActionItem
                icon="fa fa-trash"
                variant="danger"
                label={out("Archiver", "Archive")}
                onClick={() => {
                  setShowArchiveRequisitionModal(true);
                }}
              />
            )}
          {(isAdmin ||
            requisition.reviewers.findIndex((reviewer) => {
              return +reviewer.id === +user.user_id;
            }) > -1) &&
            !requisition.deleted_at &&
            requisition.status.name !== "Rejected" && (
              <DropdownActionItem
                icon="fa fa-pencil-square-o"
                label={out("Statut", "Status")}
                onClick={() => {
                  setStatusEditMode(true);
                  setShowModalStatus(true);
                }}
              />
            )}
          {requisition.revision_comments.length > 0 && (
            <DropdownActionItem
              icon="fa fa-eye"
              label={out("Commentaires", "Comments")}
              onClick={() => {
                setReadMode("revision-comment");
                setShowModalStatus(true);
              }}
            />
          )}
          {requisition.translations.find((translation) => {
            return translation.rejection_reason;
          }) && (
            <DropdownActionItem
              icon="fa fa-eye"
              label={out("Motif de rejet", "Rejection reason")}
              onClick={() => {
                setReadMode("rejection-reason");
                setShowModalStatus(true);
              }}
            />
          )}
        </Dropdown.Menu>
      </Dropdown>
      {showModalStatus && (
        <ActionsStatusModal
          requisition={requisition}
          currentLanguage={currentLanguage}
          statusList={statusList}
          reviewersList={reviewersList}
          saveStatus={saveStatus}
          showModal={setShowModalStatus}
          editMode={statusEditMode}
          setEditMode={setStatusEditMode}
          readMode={readMode}
          setReadMode={setReadMode}
        />
      )}

      <ArchiveRequisitionModal
        show={showArchiveRequisitionModal}
        hide={() => setShowArchiveRequisitionModal(false)}
        requisition={requisition}
      />
    </>
  );
};
