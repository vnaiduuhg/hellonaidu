import { useTranslation } from "global/utils/useTranslation";
import { useHistory } from "react-router-dom";
import { getLocallyFormattedNumber } from "global/utils/numberFormatUtils";
import { getTimeFormat } from "global/utils/dateTimeLanguageUtils";
import cx from "classnames";
import styles from "./requisition-card.module.scss";
import { OverlayTrigger, Popover } from "react-bootstrap";
import { RequisitionCardActions } from "./requisition-card-actions";

// This is the card w/ 2 sections: left white, right gradient

export const RequisitionCard = ({ requisition, statusList, reviewersList }) => {
  const { out } = useTranslation();
  const history = useHistory();

  const createdAt = getTimeFormat(requisition.created_at, "LL");

  const startDate =
    requisition.job?.types?.length &&
    requisition.job.types[0].durations?.length &&
    requisition.job.types[0].durations[0].start_date
      ? getTimeFormat(requisition.job.types[0].durations[0].start_date, "LL")
      : null;

  return (
    <div className={`empJobCardContainer ${styles.requisitionCardContainer}`}>
      <div
        // FIXME: make this accessible w/o effecting looks downstream
        onClick={() => history.push(`/requisition/view/${requisition.id}`)}
        className="empJobCard"
        role="button"
      >
        {/* left */}
        <div className="empJobCardLeft">
          <div
            className={`empJobCardLeftContainer ${styles.requisitionLeftContainer}`}
          >
            <div className="empJobCardLeftTop">
              <div className="empJobCardLeftTopLeft">
                <div className="empJobCardTitle">
                  <h3>
                    {out(
                      requisition.job.translations[1].title
                        ? requisition.job.translations[1].title
                        : "Titre français indisponible",
                      requisition.job.translations[0].title
                        ? requisition.job.translations[0].title
                        : "No English title available",
                    )}
                  </h3>
                </div>
              </div>
            </div>

            <div className="empJobCardLeftBottom">
              <div className={styles.miniCardText}>
                <div>
                  <span className={styles.title}>
                    {out("Titre anglais", "French title")}:
                  </span>
                  {out(
                    requisition.job.translations[0].title
                      ? requisition.job.translations[0].title
                      : "Titre anglais indisponible",
                    requisition.job.translations[1].title
                      ? requisition.job.translations[1].title
                      : "No French title available",
                  )}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Département", "Department")}:
                  </span>
                  {out(
                    requisition.translations[1].hiring_manager_department,
                    requisition.translations[0].hiring_manager_department,
                  )}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Gestionnaire d'embauche", "Hiring Manager")}:
                  </span>
                  {requisition.hiring_manager_name}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Salaire", "Salary")}:
                  </span>
                  $
                  {requisition.planned_salary_max !==
                  requisition.planned_salary_min
                    ? getLocallyFormattedNumber(
                        requisition.planned_salary_min / 100,
                      ) +
                      " / " +
                      "$" +
                      getLocallyFormattedNumber(
                        requisition.planned_salary_max / 100,
                      )
                    : getLocallyFormattedNumber(
                        requisition.planned_salary_max / 100,
                      )}{" "}
                  {requisition.planned_salary_currency}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Date de début", "Plan Date")}:
                  </span>
                  {startDate
                    ? out(startDate.fr, startDate.en)
                    : out("Pas de date de début", "No start date available")}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Créé le", "Created")}
                  </span>
                  {out(createdAt.fr, createdAt.en)}
                </div>
              </div>
            </div>

            <div className={styles.requisitionLarge}>
              <div>
                <div>
                  <span className={styles.cardTitle}>
                    {out(
                      requisition.job.translations[1].title
                        ? requisition.job.translations[1].title
                        : "Titre français indisponible",
                      requisition.job.translations[0].title
                        ? requisition.job.translations[0].title
                        : "No English title available",
                    )}
                  </span>
                </div>

                <div className="fst-italic mb-3">
                  {out(
                    requisition.job.translations[0].title
                      ? requisition.job.translations[0].title
                      : "Titre anglais indisponible",
                    requisition.job.translations[1].title
                      ? requisition.job.translations[1].title
                      : "No French title available",
                  )}
                </div>

                <div className="mb-1">
                  <span className={styles.title}>
                    {out("Département", "Department")}:
                  </span>
                  {out(
                    requisition.translations[1].hiring_manager_department,
                    requisition.translations[0].hiring_manager_department,
                  )}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Gestionnaire d'embauche", "Hiring Manager")}:
                  </span>
                  {requisition.hiring_manager_name}
                </div>
              </div>

              <div>
                <div className="mb-1">
                  <span className={styles.title}>
                    {out("Salaire", "Salary")}:
                  </span>
                  $
                  {requisition.planned_salary_max !==
                  requisition.planned_salary_min
                    ? getLocallyFormattedNumber(
                        requisition.planned_salary_min / 100,
                      ) +
                      " / " +
                      "$" +
                      getLocallyFormattedNumber(
                        requisition.planned_salary_max / 100,
                      )
                    : getLocallyFormattedNumber(
                        requisition.planned_salary_max / 100,
                      )}{" "}
                  {requisition.planned_salary_currency}
                </div>

                <div>
                  <span className={styles.title}>
                    {out("Date de début", "Plan Date")}:
                  </span>
                  {startDate
                    ? out(startDate.fr, startDate.en)
                    : out("Pas de date de début", "No start date available")}
                </div>

                <div
                  className={`position-absolute bottom-0 end-0 ${styles.grayText}`}
                >
                  {out(`Créé le ${createdAt.fr}`, `Created ${createdAt.en}`)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* right */}
        <div className="empJobCardRight">
          <div className={styles.status}>
            <span id={styles.statusLabel} className="fw-bold">
              {/* Status: */}
            </span>{" "}
            <span id={styles.statusValue}>
              {out(
                requisition.status.translations[1].name,
                requisition.status.translations[0].name,
              )}
            </span>
          </div>

          <div className={styles.statuses}>
            <div className="fw-bold">
              {requisition.reviewers.length}{" "}
              {out("Évaluateur(s)", "Reviewer(s)")}
            </div>
            <div className={styles.colon}>:&nbsp;</div>

            {!!requisition?.reviewers?.length ? (
              <OverlayTrigger
                placement="auto"
                delay={{ show: 250, hide: 400 }}
                overlay={
                  <Popover>
                    <Popover.Body className={`fs-6`}>
                      {(requisition?.reviewers ?? []).map((reviewer) => (
                        <div key={reviewer.id} className="my-1">
                          {reviewer.pivot.review_feedback_status_id ? (
                            statusList.map((status) => {
                              if (
                                +status.id ===
                                +reviewer.pivot.review_feedback_status_id
                              ) {
                                return (
                                  <span
                                    className="badge bg-primary"
                                    key={status.id}
                                  >
                                    &nbsp;
                                    {out(
                                      status.translations[1].name,
                                      status.translations[0].name,
                                    )}
                                  </span>
                                );
                              }
                            })
                          ) : (
                            <span className="me-2 badge bg-primary">
                              &nbsp;N/A
                            </span>
                          )}
                          {reviewer.first_name + " " + reviewer.last_name}
                        </div>
                      ))}
                    </Popover.Body>
                  </Popover>
                }
              >
                <u
                  className={cx(`fw-normal`, {
                    "text-white": !!requisition.reviewers.length,
                    [styles.disabledLink]: !requisition.reviewers.length,
                  })}
                >
                  {out(
                    "Afficher les statuts des évaluateurs",
                    "View Reviewers' Statuses",
                  )}
                </u>
              </OverlayTrigger>
            ) : (
              <u
                className={cx(`fw-normal`, {
                  "text-white": !!requisition.reviewers.length,
                  [styles.disabledLink]: !requisition.reviewers.length,
                })}
              >
                {out(
                  "Afficher les statuts des évaluateurs",
                  "View Reviewers' Statuses",
                )}
              </u>
            )}
          </div>
        </div>
      </div>

      {/* dropdown menu button */}
      <div className="empJobCardLeftTopRight">
        <RequisitionCardActions
          requisition={requisition}
          statusList={statusList}
          reviewersList={reviewersList}
        />
      </div>
    </div>
  );
};
