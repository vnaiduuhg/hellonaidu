import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import {
  Container,
  Nav,
  Navbar,
  OverlayTrigger,
  Tooltip,
} from "react-bootstrap";

const RequisitionSettingsNavbar = ({
  hMDCount,
  hireTypesCount,
  groupsCount,
  reviewersCount,
  tabActive,
  setTabActive,
}) => {
  const { out } = useTranslation();
  const tabs = [
    {
      label: "hiringManagerDepartments",
      fr: "Département du gestionnaire du poste",
      en: "Hiring Manager Department",
      count: hMDCount,
    },
    {
      label: "hiretypes",
      fr: "Type d'embauche",
      en: "Requisition Hire Type",
      count: hireTypesCount,
    },
    {
      label: "groups",
      fr: "Groupe de réquisition",
      en: "Requisition Group",
      count: groupsCount,
    },
    {
      label: "reviewersList",
      fr: "Évaluateur de réquisition",
      en: "Requisition Reviewer",
      count: reviewersCount,
    },
  ];

  return (
    <Navbar
      expand="md"
      className="nav-tabs user-select-none mt-2 mt-md-3 py-0 px-md-3"
    >
      <Container fluid className="p-0 m-0">
        <div className="bg-white w-100 d-md-none">
          <Navbar.Toggle
            label={out("Toggle navigation", "Toggle navigation")}
            aria-controls="requisition-settings-nav"
            className="m-3 my-2"
          />
        </div>

        <Navbar.Collapse id="requisition-settings-nav" className="p-0">
          <Nav variant="tabs" fill className="w-100 fw-500 border-0">
            {tabs.map((tab) => (
              <Nav.Item
                key={tabs.label}
                className="nav-item pointer"
                onClick={() => setTabActive(tab.label)}
              >
                <div
                  className={`nav-link p-3 py-2 py-md-3 ${
                    tabActive === tab.label && "active"
                  }`}
                >
                  <div className="fs-5 fw-400 d-flex">
                    <div className="flex-fill text-start">
                      {out(tab.fr, tab.en)}
                    </div>

                    <div className="me-2">
                      {tab.count > 0 && (
                        <OverlayTrigger
                          key={`${tabs.label}-badge-tooltip`}
                          placement="left"
                          overlay={
                            <Tooltip>
                              {out("Total", "Total")}:&nbsp;{tab.count}
                            </Tooltip>
                          }
                        >
                          <span className="badge rounded-pill bg-secondary fs-small px-3">
                            {tab.count}

                            <span className="visually-hidden">
                              {out("Total", "Total")}:&nbsp;{tab.count}
                            </span>
                          </span>
                        </OverlayTrigger>
                      )}
                    </div>
                  </div>
                </div>
              </Nav.Item>
            ))}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default RequisitionSettingsNavbar;
