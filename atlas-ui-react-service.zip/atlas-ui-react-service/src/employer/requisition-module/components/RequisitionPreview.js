import React from "react";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { Card, Image } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import { getLocallyFormattedNumber } from "global/utils/numberFormatUtils";
import { PageLoader } from "global/components/loaders/page-loader";

import {
  BsCashStack,
  BsFillPersonLinesFill,
  BsFillPieChartFill,
} from "react-icons/bs";
import jdhdPositionImage from "global/assets/images/jdhd_position.png";

const RequisitionPreview = ({
  data = null,
  formattedLocations = null,
  initialReviewerList = [],
  showTitle = false,
  isError = null,
  isLoading = null,
}) => {
  const { out } = useTranslation();

  const content = !data ? null : (
    <>
      {showTitle && (
        <div className="visually-hidden">
          <Row className="mb-3">
            <Col as="h1" className="text-primary h3 fw-bold">
              {out(
                data.job.translations[1].title,
                data.job.translations[0].title,
              )}
            </Col>
          </Row>
        </div>
      )}
      <Row className="g-2 h-100">
        <Col xs={12} md={6} className="mb-2 mb-md-0">
          <Card className="h-100">
            <Card.Body>
              <h1 className="h3">
                <BsFillPersonLinesFill className="text-info me-2" />
                {out("Informations de base", "Basic Information")}
              </h1>

              <div className="ms-3">
                {data.status && (
                  <p>
                    {out("Statut: ", "Status: ")}
                    <span className="text-secondary-200">
                      {out(
                        data.status.translations[1].name,
                        data.status.translations[0].name,
                      )}
                    </span>
                  </p>
                )}
                <p>
                  <Image src={jdhdPositionImage} alt="positions icon" />{" "}
                  <span className="text-secondary-200">
                    {data.job.number_of_positions
                      ? data.job.number_of_positions
                      : "0"}
                  </span>{" "}
                  {out("poste(s) disponible(s)", "position(s) available")}
                  <br />
                  <span className="fa fa-map-marker me-1" aria-hidden="true" />
                  {out("Lieux de travail: ", "Job locations: ")}
                  {formattedLocations ? (
                    formattedLocations.map((location) => (
                      <span key={location}>
                        <span className="text-secondary-200">{location}</span>
                        <br />
                      </span>
                    ))
                  ) : (
                    <span className="text-secondary-200">
                      {out("Aucune", "None")}
                    </span>
                  )}
                </p>
                <p>
                  {out("Approbation requise: ", "Approval required: ")}
                  <span className="text-secondary-200">
                    {data.approval_required
                      ? out("Oui", "Yes")
                      : out("Non", "No")}
                  </span>
                  <br />
                  {out("Gestionnaire d'embauche: ", "Hiring manager: ")}
                  <span className="text-secondary-200">
                    {data.hiring_manager_name}{" "}
                    {data.hiring_manager_department
                      ? `(${out(
                          data.translations[1].hiring_manager_department,
                          data.translations[0].hiring_manager_department,
                        )})`
                      : ""}
                  </span>
                  <br />
                  {out("Sous la responsabilité de: ", "Reporting to: ")}
                  <span className="text-secondary-200">
                    {data.reports_to_name}{" "}
                    {data.reports_to_position
                      ? `(${data.reports_to_position})`
                      : ""}{" "}
                    {data.reports_to_email ? ` - ${data.reports_to_email}` : ""}
                  </span>
                  <br />
                </p>
                {data.reviewers && data.reviewers.length > 0 && (
                  <>
                    {out("Évaluateurs: ", "Reviewers: ")} <br />
                    {data.reviewers.map((entry, i) => {
                      if (entry.id) {
                        return (
                          <div key={entry.id} className="m-0 ms-3">
                            {`${i + 1}. `}
                            <span className="text-secondary-200">
                              {`${entry.first_name} ${entry.last_name}`}
                            </span>
                          </div>
                        );
                      } else {
                        return initialReviewerList.map((reviewer) => {
                          if (+reviewer.id === +entry.reviewer_user_id)
                            return (
                              <div key={reviewer.id} className="m-0 ms-3">
                                {`${i + 1}. `}
                                <span className="text-secondary-200">
                                  {`${reviewer.first_name} ${reviewer.last_name}`}
                                </span>
                              </div>
                            );
                        });
                      }
                    })}
                  </>
                )}
              </div>

              <h3 className="mt-4">
                <BsFillPieChartFill className="text-info me-2" />
                {out("Plan de main-d'œuvre", "Manpower Plan")}
              </h3>

              <div className="ms-3">
                <p>
                  {out(
                    "Le budget est-il approuvé ? ",
                    "Is the budget approved? ",
                  )}
                  <span className="text-secondary-200">
                    {data.within_budget ? out("Oui", "Yes") : out("Non", "No")}
                  </span>
                  <br />

                  {out(
                    "Ce poste fait-il partie du plan budgétaire annuel ? ",
                    "Is this position part of the yearly budget plan? ",
                  )}
                  <span className="text-secondary-200">
                    {data.yearly_manpower_plan
                      ? out("Oui", "Yes")
                      : out("Non", "No")}
                  </span>
                  <br />

                  {data.translations &&
                    out(
                      data.translations[1].budget_explanation,
                      data.translations[0].budget_explanation,
                    ) && (
                      <span>
                        {out(
                          "Explication budgétaire: ",
                          "Budget explanation: ",
                        )}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].budget_explanation,
                            data.translations[0].budget_explanation,
                          )}
                        </span>
                        <br />
                      </span>
                    )}

                  {data.translations &&
                    out(
                      data.translations[1].group_name,
                      data.translations[0].group_name,
                    ) && (
                      <span>
                        {out("Groupe de réquisition: ", "Requisition group: ")}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].group_name,
                            data.translations[0].group_name,
                          )}
                        </span>
                        <br />
                      </span>
                    )}

                  {data.translations &&
                    out(
                      data.translations[1].rejection_reason,
                      data.translations[0].rejection_reason,
                    ) && (
                      <span>
                        {out("Motif de rejet: ", "Rejection reason: ")}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].rejection_reason,
                            data.translations[0].rejection_reason,
                          )}
                        </span>
                        <br />
                      </span>
                    )}

                  {out("Type d'embauche: ", "Hire Type: ")}
                  {data.translations &&
                  out(
                    data.translations[1].hire_type,
                    data.translations[0].hire_type,
                  ) ? (
                    <span>
                      <span className="text-secondary-200">
                        {out(
                          data.translations[1].hire_type,
                          data.translations[0].hire_type,
                        )}
                      </span>
                      <br />
                    </span>
                  ) : (
                    <span>
                      <span className="text-secondary-200">
                        {out("Aucun", "None")}
                      </span>
                      <br />
                    </span>
                  )}

                  {data.translations &&
                    out(
                      data.translations[1].hire_reason,
                      data.translations[0].hire_reason,
                    ) && (
                      <span>
                        {out("Raison pour l'embauche: ", "Hire Reason: ")}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].hire_reason,
                            data.translations[0].hire_reason,
                          )}
                        </span>
                        <br />
                      </span>
                    )}
                  {out(
                    "Ce poste fait-il partie de votre plan de diversité ? ",
                    "Is this position a part of your diversity plan? ",
                  )}
                  <span className="text-secondary-200">
                    {data.is_diversity_plan
                      ? out("Oui", "Yes")
                      : out("Non", "No")}
                  </span>
                </p>
              </div>

              <h3 className="mt-4">
                <BsCashStack className="text-info me-2" />
                {out("Budget ", "Budget ")}({data.planned_salary_currency})
              </h3>

              <div className="ms-3">
                <p>
                  {data.planned_salary_min && out("Salaire: ", " Salary: ")}
                  {data.planned_salary_min && (
                    <span className="text-secondary-200">
                      $
                      {getLocallyFormattedNumber(data.planned_salary_min / 100)}{" "}
                      {data.planned_salary_max &&
                      data.planned_salary_max > data.planned_salary_min
                        ? ` - $${getLocallyFormattedNumber(
                            data.planned_salary_max / 100,
                          )}`
                        : ""}
                    </span>
                  )}
                  {data.planned_salary_min && <br />}
                  {out("Niveau de rémunération: ", "Grade: ")}
                  <span className="text-secondary-200">
                    {data.grade ? data.grade : out("Aucune", "None")}
                  </span>
                  <br />

                  {data.translations &&
                    out(
                      data.translations[1].planned_salary_type,
                      data.translations[0].planned_salary_type,
                    ) && (
                      <span>
                        {out("Type d'emploi: ", "Job type: ")}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].planned_salary_type,
                            data.translations[0].planned_salary_type,
                          )}
                        </span>
                        <br />
                      </span>
                    )}
                  {/* {out("Durée de l'emploi: ", "Job duration: ")}
            <span className="text-secondary-200">
              hardcoded Months/Years/Hours
            </span>
            <br /> */}
                  {/* {out("Créé: ", "Created: ")}
            <span className="text-secondary-200">
              {data.created_at &&
                moment(data.created_at).utc().format("ll")}
            </span>
            <br /> */}
                  {/* {out("Quarts de travail: ", "Work shifts: ")}
            <span className="text-highlight">hardcoded Day | On call</span>
            <br />
            {out("Avantages: ", "Benefits: ")}
            <span className="text-secondary-200">
              hardcoded group insurance, coffee, bonus
            </span>
            <br /> */}
                  {out("Syndiqué: ", "Unionized: ")}
                  <span className="text-secondary-200">
                    {data.is_unionized ? out("Oui", "Yes") : out("Non", "No")}
                  </span>
                  <br />
                  {data.translations &&
                    out(
                      data.translations[1].union_description,
                      data.translations[0].union_description,
                    ) && (
                      <span>
                        {out(
                          "Description du syndicat: ",
                          "Union description: ",
                        )}
                        <span className="text-secondary-200">
                          {out(
                            data.translations[1].union_description,
                            data.translations[0].union_description,
                          )}
                        </span>
                        <br />
                      </span>
                    )}
                </p>
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={6} className="mb-2 mb-md-0">
          <Card className="h-100">
            <Card.Body>
              {/* <div className="shadow-card"> */}
              {/* {(data.job.skills || data.job.work_hours) && ( */}
              {data.job.skills && data.job.skills.length > 0 && (
                <div className="mb-4">
                  <h3>{out("Détails du poste", "Job Details")}</h3>
                  <div className="ms-3">
                    {data.job.skills && (
                      <p>
                        {out("Compétences ", "Skills")}: <br />
                        {data.job.skills.map((skill) => (
                          <div className="ms-3">
                            <span className="text-secondary-200">
                              {out(
                                skill.translations[1].name,
                                skill.translations[0].name,
                              )}{" "}
                              |{" "}
                              {out(
                                skill.translations[1].definition,
                                skill.translations[0].definition,
                              )}
                            </span>
                          </div>
                        ))}
                      </p>
                    )}

                    {/* {data.job.work_hours && (
                  <p>
                    {out("Compétences ", "Skills")}: <br />
                    {data.job.work_hours.map((work, i) => {
                      return (
                        <p style={{ margin: 0 }}>
                          <span className="text-secondary-200">
                            {`${work.min_hours} - ${work.max_hours}`}
                          </span>
                        </p>
                      );
                    })}
                  </p>
                )} */}
                  </div>
                </div>
              )}

              <h3>{out("Description du poste", "Job Description")}</h3>
              {out(
                data.job.translations[1].description,
                data.job.translations[0].description,
              ) ? (
                <p
                  dangerouslySetInnerHTML={{
                    __html: out(
                      data.job.translations[1].description,
                      data.job.translations[0].description,
                    ),
                  }}
                />
              ) : (
                <span className="text-secondary-200">
                  {out("Aucune.", "None.")}
                </span>
              )}

              {data.translations &&
                out(
                  data.translations[1].additional_terms,
                  data.translations[0].additional_terms,
                ) && (
                  <span>
                    <h3>
                      {out("Conditions supplémentaires", "Additional terms")}
                    </h3>
                    <span className="text-secondary-200">
                      {out(
                        data.translations[1].additional_terms,
                        data.translations[0].additional_terms,
                      )}
                    </span>
                    <br />
                  </span>
                )}
              {/* </div> */}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  );

  return (
    <Col xs={12} id="requisitionPreview" className="h-100">
      {isLoading && (
        <PageLoader message={out("Veuillez patienter...", "Please wait...")} />
      )}

      {/* TODO: use styling from ng-app to mimic same errors the same way */}
      {isError && (
        <h1 className="text-center text-error mt-5 h3">
          {out("Impossible de récupérer les données", "Cannot retrieve data")}
        </h1>
      )}
      {data && content}
    </Col>
  );
};

export default RequisitionPreview;
