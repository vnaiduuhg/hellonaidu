import React, { useState, useEffect } from "react";
import { useTranslation } from "global/utils/useTranslation";
import { getTimeFormat } from "global/utils/dateTimeLanguageUtils";
import { isAccountSynced } from "../../sync/utils/syncUtils";
import { useEmailAccount } from "../../sync/hooks/useEmailAccount";
import { AtlasAlert } from "global/components/atlas-alert";
import { AtlasSelect } from "global/components/select/atlas-select";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { Button, FloatingLabel, Form, Modal } from "react-bootstrap";
import style from "../assets/FiltersModal.module.scss";

const ActionsStatusModal = ({
  requisition,
  currentLanguage,
  statusList,
  reviewersList,
  saveStatus,
  showModal,
  editMode,
  setEditMode,
  readMode,
  setReadMode,
}) => {
  const { out } = useTranslation();
  const [localTextString, setLocalTextString] = useState("");
  const [selectedStatus, setSelectedStatus] = useState(null);
  const [showTextInput, setShowTextInput] = useState(false);
  const { syncedAccounts, isFetched: emailAccountsFetched } = useEmailAccount();
  const [hasAutomatedAccountSync, setHasAutomatedAccountSync] = useState(null);

  useEffect(() => {
    if (emailAccountsFetched) {
      setHasAutomatedAccountSync(
        !!isAccountSynced(syncedAccounts, "automated"),
      );
    }
  }, [emailAccountsFetched]);

  return (
    <Modal show onHide={() => showModal(false)}>
      <Modal.Header closeButton>
        <Modal.Title>
          {readMode &&
            readMode === "rejection-reason" &&
            out("Motif du rejet", "Rejection reason")}

          {readMode &&
            readMode === "revision-comment" &&
            out("Commentaires de révision", "Revision comments")}

          {editMode && out("Modifier le statut", "Update status")}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {emailAccountsFetched && (
          <>
            {editMode &&
              typeof hasAutomatedAccountSync === "boolean" &&
              !hasAutomatedAccountSync && (
                <AtlasAlert variant="info">
                  <div className="ms-2">
                    {out(
                      "Afin d'informer le créateur de la demande du nouveau statut, vous devez synchroniser votre courriel automatisé avec Email Engine, AWS ou Nylas, ainsi que le définir par défaut.",
                      "In order to notify the requisition creator about the new status, you must synchronize your automated email with Email Engine, AWS or Nylas, as well as set it as default.",
                    )}
                  </div>
                </AtlasAlert>
              )}
            {editMode && (
              <>
                <div>
                  <label htmlFor="status-list">
                    {out("Status", "Status")}:
                  </label>
                  <AtlasSelect
                    id="status-list"
                    isLoading={!statusList}
                    // TODO: loading message
                    // loadingMessage={}

                    placeholder={out(
                      "Sélectionnez un statut",
                      "Select a status",
                    )}
                    options={statusList
                      .filter(
                        (status) =>
                          !["Draft", "Submitted"].includes(status.name),
                      )
                      .map((status) => ({
                        value: status.name,
                        label: out(
                          status.translations[1].name,
                          status.translations[0].name,
                        ),
                      }))}
                    onChange={(newStatus) => {
                      if (
                        [
                          "Rejected",
                          "Changes Requested",
                          "Approved",
                          "Approved and locked",
                        ].includes(newStatus.value)
                      ) {
                        setSelectedStatus(
                          statusList.find(
                            (status) => status.name === newStatus.value,
                          ),
                        );
                        if (newStatus.value === "Rejected") {
                          setLocalTextString(
                            requisition.translations[0].rejection_reason
                              ? requisition.translations[0].rejection_reason
                              : requisition.translations[1].rejection_reason
                              ? requisition.translations[1].rejection_reason
                              : "",
                          );
                          setShowTextInput(true);
                        } else if (newStatus.value === "Changes Requested") {
                          setShowTextInput(true);
                        } else {
                          setLocalTextString(null);
                        }
                      } else {
                        // validation error under input
                      }
                    }}
                  />
                </div>
                <div>
                  {showTextInput &&
                    ["Rejected", "Changes Requested"].includes(
                      selectedStatus.name,
                    ) && (
                      <FloatingLabel
                        controlId="reason"
                        label={
                          selectedStatus.name === "Rejected"
                            ? out(
                                "Veuillez ajouter le motif du rejet",
                                "Please add a rejection reason",
                              )
                            : out(
                                "Veuillez ajouter un commentaire",
                                "Please add a comment",
                              )
                        }
                      >
                        <Form.Control
                          as="textarea"
                          maxLength="255"
                          placeholder=" "
                          className={`${style.actionBtnTextArea} mt-2`}
                          value={localTextString}
                          onChange={({ currentTarget: { value } }) =>
                            setLocalTextString(value)
                          }
                        />
                      </FloatingLabel>
                    )}
                </div>
              </>
            )}
            {readMode && (
              <div className="px-3">
                {readMode === "rejection-reason" && (
                  <div>
                    {((currentLanguage === requisition.translations[0].locale &&
                      !requisition.translations[0].rejection_reason) ||
                      (currentLanguage === requisition.translations[1].locale &&
                        !requisition.translations[1].rejection_reason)) && (
                      <span className={`${style.languageMsg}`}>
                        {out(
                          "Non disponible en français",
                          "Not available in english",
                        )}
                      </span>
                    )}
                    <p className={`${style.text}`}>
                      <span>
                        {requisition.translations[1].rejection_reason}
                      </span>
                      {requisition.translations[1].rejection_reason && <br />}
                      <span>
                        {requisition.translations[0].rejection_reason}
                      </span>
                    </p>
                  </div>
                )}
                {readMode === "revision-comment" && (
                  <div>
                    {requisition.revision_comments.map((comment, i) => {
                      const createdAt = getTimeFormat(comment.created_at, "LL");
                      return (
                        <div className="mt-3" key={i}>
                          {currentLanguage !==
                            comment.translations[0].locale && (
                            <span className={`${style.languageMsg}`}>
                              {out(
                                "Non disponible en français",
                                "Not available in english",
                              )}
                            </span>
                          )}
                          <p className={`${style.text}`}>
                            <span>{comment.translations[0].comment}</span>
                          </p>
                          <div className={`${style.byReviewer}`}>
                            {reviewersList.map((reviewer) => {
                              return +reviewer.id ===
                                +comment.reviewer_user_id ? (
                                <span className="fs-7" key={reviewer.id}>
                                  {out("Par", "By")}&nbsp;
                                  {reviewer.first_name +
                                    " " +
                                    reviewer.last_name}
                                </span>
                              ) : null;
                            })}
                            <span>{out(createdAt.fr, createdAt.en)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </>
        )}
        {!emailAccountsFetched && (
          <ComponentLoader
            message={out("Veuillez patienter...", "Please wait...")}
          />
        )}
      </Modal.Body>

      <Modal.Footer>
        {editMode && (
          <>
            <Button
              variant="primary"
              disabled={
                !selectedStatus ||
                (["Rejected", "Changes Requested"].includes(selectedStatus.name)
                  ? !localTextString
                  : localTextString)
              }
              onClick={() => {
                saveStatus({
                  status: selectedStatus,
                  text: localTextString,
                });
                setEditMode(false);
                showModal(false);
              }}
            >
              {out("Sauvegarder", "Save")}
            </Button>

            <Button
              variant="alt-secondary"
              onClick={() => {
                setSelectedStatus(null);
                setLocalTextString("");
                setEditMode(false);
                showModal(false);
              }}
            >
              {out("Annuler", "Cancel")}
            </Button>
          </>
        )}
        {readMode && (
          <Button
            variant="secondary"
            onClick={() => {
              showModal(false);
              setReadMode(null);
            }}
          >
            {out("Fermer", "Close")}
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  );
};

export default ActionsStatusModal;
