import React, { useState, useEffect } from "react";
import { useTranslation } from "global/utils/useTranslation";
import Button from "react-bootstrap/Button";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { FloatingLabel, Form } from "react-bootstrap";
import cx from "classnames";
import style from "../assets/RequisitionSettingsUI.module.css";

const RequisitionSettingsForm = ({
  setEditMode,
  saveItem,
  title = null,
  initialEnTitle = "",
  initialFrTitle = "",
  refreshInputs = false,
  setRefreshInputs,
  itemId = 0,
  showCancelBtn = false,
  showLoader,
  setShowLoader,
}) => {
  const [titleEnglish, setTitleEnglish] = useState("");
  const [titleFrench, setTitleFrench] = useState("");
  const titleEnglishInputClickHandler = (event) => {
    setTitleEnglish(event.target.value);
  };
  const titleFrenchInputClickHandler = (event) => {
    setTitleFrench(event.target.value);
  };
  const { out } = useTranslation();

  const formSubmissionHandler = (event) => {
    event.preventDefault();
    if (titleEnglish.trim() && titleFrench.trim()) {
      setShowLoader(true);
      saveItem({
        id: itemId ?? null,
        translations: [
          {
            locale: "en",
            name: titleEnglish,
          },
          {
            locale: "fr",
            name: titleFrench,
          },
        ],
      });
    } else {
      // show error msg under input: this field is required
    }
  };

  useEffect(() => {
    if (initialFrTitle || initialEnTitle) {
      setTitleEnglish(initialEnTitle);
      setTitleFrench(initialFrTitle);
    }
  }, []);

  useEffect(() => {
    if (refreshInputs) {
      setTitleEnglish("");
      setTitleFrench("");
      setRefreshInputs(false);
    }
  });

  return (
    <>
      <div className={cx("mt-5", { "visually-hidden": !showLoader })}>
        <ComponentLoader
          message={out("Veuillez patienter...", "Please wait...")}
        />
      </div>
      {!showLoader && (
        <form
          onSubmit={formSubmissionHandler}
          className={cx({ "visually-hidden": showLoader })}
        >
          {title && (
            <div>
              <h2 className="mt-md-4 ps-1 mb-3 h4">
                {out("Ajouter un ", "Add a ")} {title.toLowerCase()}
              </h2>
            </div>
          )}
          <div className={style.form_group}>
            <FloatingLabel
              label={out("Titre anglais", "English title")}
              className="mb-2"
            >
              <Form.Control
                name="titleEnglish"
                value={titleEnglish}
                onChange={titleEnglishInputClickHandler}
                placeholder=" "
              />
            </FloatingLabel>

            <FloatingLabel
              label={out("Titre français", "French title")}
              className="mb-3"
            >
              <Form.Control
                name="titleFrench"
                value={titleFrench}
                onChange={titleFrenchInputClickHandler}
                placeholder=" "
              />
            </FloatingLabel>
          </div>
          <div className="d-flex flex-row-reverse">
            <Button
              type="submit"
              variant="primary"
              disabled={!titleEnglish || !titleFrench}
              className="ms-3"
            >
              {out("Sauvegarder", "Save")}
            </Button>
            {showCancelBtn && (
              <Button
                variant="alt-secondary"
                onClick={() => setEditMode(false)}
              >
                {out("Annuler", "Cancel")}
              </Button>
            )}
          </div>
        </form>
      )}
    </>
  );
};

export default RequisitionSettingsForm;
