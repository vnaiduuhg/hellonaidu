import React from "react";
import { batch } from "react-redux";
import { Button, Modal } from "react-bootstrap";
import RequisitionGroupFilter from "./RequisitionGroupFilter";
import { useTranslation } from "global/utils/useTranslation";

const GroupFilterModal = ({
  show,
  setShowModal,
  itemList,
  selectedItem,
  setItemFilter,
  setPage,
}) => {
  const { out } = useTranslation();

  return (
    <Modal show={show} onHide={() => setShowModal(false)}>
      <Modal.Header closeButton>
        <Modal.Title>
          {out("Veuillez choisir un groupe", "Please select a group")}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <RequisitionGroupFilter
          groupsList={itemList}
          selectedItem={selectedItem}
          setGroupsFilter={setItemFilter}
          setShowModal={setShowModal}
          setPage={setPage}
        />
      </Modal.Body>

      <Modal.Footer className="px-2">
        <Button
          type="reset"
          variant="secondary"
          onClick={() => {
            batch(() => {
              setPage(1);
              setItemFilter("");
            });

            setShowModal(false);
          }}
        >
          {out("Effacer", "Clear")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default GroupFilterModal;
