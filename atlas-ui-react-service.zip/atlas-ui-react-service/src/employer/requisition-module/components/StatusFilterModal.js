import React, { useState } from "react";
import { batch } from "react-redux";
import RequisitionStatusFilter from "./RequisitionStatusFilter";
import { useTranslation } from "global/utils/useTranslation";
import { Button, Modal } from "react-bootstrap";

const StatusFilterModal = ({
  show,
  statusList,
  statusesFilter,
  setShowStatus,
  setStatusesFilter,
  setPage,
}) => {
  const { out } = useTranslation();
  const [localStatus, setLocalStatus] = useState([...statusesFilter]);

  return (
    <Modal
      show={show}
      onShow={() => setLocalStatus([...statusesFilter])}
      onHide={() => setShowStatus(false)}
      size="lg"
    >
      <Modal.Header closeButton>
        <Modal.Title>
          {out(
            "Veuillez sélectionner un ou plusieurs statuts",
            "Select one or more statuses",
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <RequisitionStatusFilter
          statusList={statusList}
          statuses={localStatus}
          setStatus={setLocalStatus}
        />
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="secondary"
          type="submit"
          disabled={!localStatus.length}
          onClick={() => {
            batch(() => {
              setPage(1);
              setStatusesFilter([...localStatus]);
            });
            setShowStatus(false);
          }}
        >
          {out("Sauvegarder", "Save")}
        </Button>

        <Button
          variant="alt-secondary"
          type="reset"
          onClick={() => {
            setStatusesFilter([]);
            batch(() => {
              setPage(1);
              setStatusesFilter([]);
            });
            setShowStatus(false);
          }}
        >
          {out("Effacer et fermer", "Clear and close")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default StatusFilterModal;
