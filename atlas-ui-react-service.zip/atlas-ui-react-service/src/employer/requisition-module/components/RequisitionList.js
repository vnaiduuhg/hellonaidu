import { RequisitionCard } from "./requisition-card/requisition-card";
import cx from "classnames";

export const RequisitionList = ({
  requisitions,
  layout,
  statusList,
  reviewersList,
}) => {
  return (
    <div
      className={cx("empJobCardLayoutMobile", {
        empJobCardLayout: layout === "grid",
      })}
      aria-hidden="false"
    >
      {requisitions.map((r) => (
        <RequisitionCard
          key={r.id}
          requisition={r}
          statusList={statusList}
          reviewersList={reviewersList}
        />
      ))}
    </div>
  );
};
