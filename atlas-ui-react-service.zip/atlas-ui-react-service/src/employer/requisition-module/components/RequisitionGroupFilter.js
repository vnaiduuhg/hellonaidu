import React from "react";
import { batch } from "react-redux";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasSelect } from "global/components/select/atlas-select";

const RequisitionGroupFilters = ({
  groupsList,
  selectedItem,
  setGroupsFilter,
  setShowModal,
  setPage,
}) => {
  const { out } = useTranslation();

  const options = (groupsList ?? []).map((g) => ({
    value: g.id,
    label: out(g.translations[1].name, g.translations[0].name),
  }));

  const selectedIndex = selectedItem
    ? groupsList.findIndex((g) => g.name === selectedItem) ?? ""
    : "";

  const value =
    selectedIndex !== ""
      ? {
          value: groupsList[selectedIndex]?.id,
          label: out(
            groupsList[selectedIndex].translations[1].name,
            groupsList[selectedIndex].translations[0].name,
          ),
        }
      : "";

  return (
    <AtlasSelect
      options={options}
      value={value}
      placeholder={out("Veuillez choisir un groupe", "Please select a group")}
      onChange={({ value }) => {
        batch(() => {
          setPage(1);
          setGroupsFilter(
            groupsList[groupsList.findIndex((g) => g.id === value)].name,
          );
        });

        // wait a bit before closing the modal
        setTimeout(() => setShowModal(false), 300);
      }}
    />
  );
};

export default RequisitionGroupFilters;
