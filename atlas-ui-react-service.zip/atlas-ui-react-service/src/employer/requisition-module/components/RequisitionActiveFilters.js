import React from "react";
import { batch } from "react-redux";
import style from "../assets/FiltersModal.module.scss";
import { useTranslation } from "global/utils/useTranslation";

const RequisitionActiveFilters = ({
  jobTitle,
  statusesFilter,
  groupsFilter,
  statusList,
  dateFilter,
  today,
  setJobTitleFilter,
  setStatuses,
  setStatusesFilter,
  setGroupsFilter,
  setGroupFilterActive,
  setStartDate,
  setEndDate,
  setDateFilter,
  showMyRequisitions,
  setRoleFilter,
  setRequisitionPage,
}) => {
  const { out } = useTranslation();

  return (
    <div className={style.activeFilter}>
      {statusesFilter.length > 0 && (
        <>
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              setStatuses([]);
              batch(() => {
                setRequisitionPage(1);
                setStatusesFilter([]);
                if (!showMyRequisitions) setRoleFilter("");
              });
            }}
          >
            <i className="fa fa-times"></i>
          </span>
          <span className={style.activeFilterTitle}>
            {out("Statut ", "Status")}: &nbsp;
          </span>
          {statusesFilter.map((id, i) => {
            return (
              <span className={style.activeFilterSpan} key={id}>
                {statusList.map((s) => {
                  if (s.id === id) {
                    return (
                      <span key={s.id}>
                        {out(s.translations[1].name, s.translations[0].name)}
                      </span>
                    );
                  }
                })}
                {i + 1 < statusesFilter.length && <span>, </span>}
              </span>
            );
          })}
        </>
      )}
      {jobTitle && (
        <>
          &nbsp;&nbsp;
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setJobTitleFilter("");
              });
            }}
          >
            <i className="fa fa-times"></i>
          </span>
          <span className={style.activeFilterTitle}>
            {out("Rechercher ", "Search")}: &nbsp;
          </span>
          <span className={style.activeFilterSpan}>{jobTitle}</span>
        </>
      )}
      {groupsFilter && (
        <>
          &nbsp;&nbsp;
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              batch(() => {
                setRequisitionPage(1);
                setGroupsFilter("");
              });
              setGroupFilterActive(false);
            }}
          >
            <i className="fa fa-times"></i>
          </span>
          <span className={style.activeFilterTitle}>
            {out("Groupe ", "Group")}:&nbsp;
          </span>
          <span className={style.activeFilterSpan}>{groupsFilter}</span>
        </>
      )}
      {dateFilter.beforeDate && dateFilter.afterDate && (
        <>
          &nbsp;&nbsp;
          <span
            className={style.activeFilterDelete}
            onClick={() => {
              setStartDate(null);
              setEndDate(today);
              batch(() => {
                setRequisitionPage(1);
                setDateFilter({
                  beforeDate: null,
                  afterDate: null,
                });
              });
            }}
          >
            <i className="fa fa-times"></i>
          </span>
          <span className={style.activeFilterTitle}>
            {out("Dates ", "Dates")}:&nbsp;
          </span>
          <span className={style.activeFilterSpan}>
            {out("du ", "from")}&nbsp;
            {dateFilter.afterDate}&nbsp;
            {out("au ", "to")}&nbsp;
            {dateFilter.beforeDate}
          </span>
        </>
      )}
    </div>
  );
};

export default RequisitionActiveFilters;
