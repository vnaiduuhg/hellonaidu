import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import RequisitionDashboardPage from "./pages/RequisitionDashboardPage";
import RequisitionSettingsPage from "./pages/RequisitionSettingsPage";
import RequisitionWizardPages from "./pages/RequisitionWizardPages";
import RequisitionViewPage from "./pages/RequisitionViewPage";

const RequisitionRoutes = () => {
  return (
    <Switch>
      <Route path="/planning" exact={true}>
        <RequisitionDashboardPage />
      </Route>
      <Route path="/planning-settings">
        <RequisitionSettingsPage />
      </Route>
      <Route path="/requisition" exact={true}>
        <RequisitionWizardPages />
      </Route>

      <Route
        path={[
          "/requisition/create",
          "/requisition/:operation(edit|clone|create)/:id/:step(info|budget|manpower|additional|preview)",
        ]}
        exact={true}
      >
        <RequisitionWizardPages />
      </Route>
      <Route path="/requisition/view/:requisitionId" exact={true}>
        <RequisitionViewPage />
      </Route>

      <Route>
        {/* 404: redirect to create */}
        <Redirect to="/requisition/create" />
      </Route>
    </Switch>
  );
};

export default RequisitionRoutes;
