import { out } from "global/utils/useTranslation";

export const groupsPostMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out("Groupe ajouté avec succès!", "Group added successfully!");
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour créer un groupe",
        "You do not have the required permission to create a group",
      );
      break;
    // could glide into default from here
    case 422:
      if ("translations" in promise.data) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer que tous les champs requis sont remplis",
          "Please make sure that all reqired fields are filled",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le groupe n'a pu être sauvegardé",
        "The group could not be saved",
      );
  }

  return msg;
};

export const groupsPutMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Groupe modifié avec succès!",
        "Group modified successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier un groupe",
        "You do not have the required permission to modify a group",
      );
      break;
    // could glide into default from here
    case 422:
      if ("translations" in promise.data) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer que tous les champs requis sont remplis",
          "Please make sure that all reqired fields are filled",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le groupe n'a pu être modifié",
        "The group could not be modified",
      );
  }

  return msg;
};

export const groupsDeleteMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Groupe supprimé avec succès!",
        "Group removed successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer un groupe",
        "You do not have the required permission to remove a group",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le groupe sélectionné n'a pu être supprimé",
        "The selected group could not be removed",
      );
  }

  return msg;
};
