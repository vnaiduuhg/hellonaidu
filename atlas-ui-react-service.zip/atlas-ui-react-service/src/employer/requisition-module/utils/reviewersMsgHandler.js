import { out } from "global/utils/useTranslation";

export const reviewersPostMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Évaluateur ajouté avec succès!",
        "Reviewer added successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour ajouter un évaluateur",
        "You do not have the required permission to add a reviewer",
      );
      break;
    // could glide into default from here
    case 422:
      if (promise.result && promise.result === "Not a member of this account") {
        msg.title = out("Accès refusé!", "Access denied!");
        msg.text = out(
          "Vous n'avez pas l'autorisation requise pour ajouter un évaluateur",
          "You do not have the required permission to add a reviewer",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "L'évaluateur sélectionné n'a pu être sauvegardé",
        "The selected reviewer could not be saved",
      );
  }

  return msg;
};

export const reviewersDeleteMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Évaluateur supprimé avec succès!",
        "Reviewer removed successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer un évaluateur",
        "You do not have the required permission to remove a reviewer",
      );
      break;
    // could glide into default from here
    case 422:
      if (
        promise.data &&
        promise.data ===
          "The given reviewer is a unique reviewer of one or more requisitions"
      ) {
        msg.title = out(
          "Cet évaluateur ne peut être supprimé",
          "This reviewer cannot be removed",
        );
        msg.text = out(
          "Il est l'unique évaluateur pour au moins une réquisitions, vous devez le remplacer afin de le supprimer",
          "He is the sole reviewer for at least one requisition, you need to replace him in order to remove him",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "L'évaluateur sélectionné n'a pu être supprimé",
        "The selected reviewer could not be removed",
      );
  }

  return msg;
};

export const reviewersStatusPatchMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Status modifié avec succès!",
        "Status modified successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier un statut",
        "You do not have the required permission to modify a status",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le statut n'a pu être modifié",
        "The status could not be modified",
      );
  }

  return msg;
};
