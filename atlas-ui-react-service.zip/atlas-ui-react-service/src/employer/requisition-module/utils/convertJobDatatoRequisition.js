export const convertJobDatatoRequisition = (job) => {
  const p = {
    translations: {},
  };

  if (job.requisition?.id) {
    p.id = job.requisition.id;
  }

  // {
  //   "id": "1630984672467",
  //   "storage": "local",

  //   "translations": {
  //     "en": { "title": "English Title" },
  //     "fr": { "title": "Titre" }
  //   },
  job.translations.forEach((t) => {
    p.translations[t.locale] = {
      title: t.title,
      description: t.description ?? "",
    };
  });

  //   "number_of_positions": "3",
  p.number_of_positions = "" + job.number_of_positions;

  //   "requisition": {
  //     "planned_salary_min": "3",
  //     "planned_salary_max": "34335",
  //     "grade": "Some Grade",
  //     "approval_required": "true",
  //     "hiring_manager_name": "Le Manager",
  //     "reports_to_position": "Anyone",
  //     "reports_to_email": "ad@gmail.com",
  //     "reviewers": [
  //       "{\"reviewer_user_id\":58389,\"is_mandatory\":true}",
  //       "{\"reviewer_user_id\":102581,\"is_mandatory\":true}"
  //     ],
  //     "reports_to_name": "Ad Me"
  //   },
  p.requisition = { ...(job.requisition ?? {}) };
  if (p.requisition.reviewers) {
    p.requisition.reviewers = p.requisition.reviewers.map((r) => "" + r.id);
  }

  p.plannedSalary =
    p.requisition.planned_salary_max &&
    p.requisition.planned_salary_max !== p.requisition.planned_salary_min
      ? "range"
      : "fixed";

  // convert requisition entries to stringified boolean for react-hook-form
  [
    "within_budget",
    "yearly_manpower_plan",
    "is_unionized",
    "is_diversity_plan",
  ].forEach((key) => {
    if (typeof p.requisition[key] === "number") {
      p.requisition[key] = `${p.requisition[key] === 1}`;
    }
  });

  p.requisition.approval_required = p.requisition?.approval_required === 1;

  // convert requisition entries to stringified number for react-hook-form
  ["number_of_reviewers"].forEach((key) => {
    if (typeof p.requisition[key] === "number") {
      p.requisition[key] = `${+p.requisition[key]}`;
    }
  });

  ["planned_salary_min", "planned_salary_max"].forEach((key) => {
    if (typeof p.requisition[key] === "number") {
      p.requisition[key] = `${p.requisition[key] / 100}`;
    }
  });

  // TODO: use the name instead (like in job.requisition) in ui

  //   "location": {
  //     "id": 514,
  //     "google_place_id": "ChIJWcHxI2YZyUwRQajP766z8M8",
  //     "suite_number": null,
  //     "street_number": "1025",
  //     "postal_code": "H2S 1Y4",
  //     "latitude": 45.53608,
  //     "longitude": -73.59904399999999,
  //     "street": "Rue de Bellechasse",
  //     "city": "Montréal",
  //     "region": "Communauté-Urbaine-de-Montréal",
  //     "province": "Québec",
  //     "country": "Canada",
  //     "translations": [
  //       {
  //         "id": 998,
  //         "locale": "en",
  //         "street": "Rue de Bellechasse",
  //         "city": "Montréal",
  //         "region": "Communauté-Urbaine-de-Montréal",
  //         "province": "Québec",
  //         "country": "Canada"
  //       },
  //       {
  //         "id": 999,
  //         "locale": "fr",
  //         "street": "Rue de Bellechasse",
  //         "city": "Montréal",
  //         "region": "Communauté-Urbaine-de-Montréal",
  //         "province": "Québec",
  //         "country": "Canada"
  //       }
  //     ]
  //   },
  if (job.locations?.length) p.locations = job.locations;

  //   "formattedAddress": "1025 Rue de Bellechasse, Montréal, QC H2S 1Y4, Canada",
  if (job.formattedAddress) {
    p.formattedAddresses = job.formattedAddress;
  } else {
    p.formattedAddresses = {};
  }

  //   "plannedSalary": "range",

  // TODO: check if this is what is being sent
  //   "jobType": "Permanent",
  //   "job-duration": "335",
  //   "jobDurationUnit": "Years",
  // 'types.*.durations.*.amount' => 'required_with:types.*.durations.*.translations|integer|min:0',
  if (
    job.types &&
    job.types?.length &&
    job.types[0].durations?.length &&
    job.types[0]?.durations[0]?.amount
  ) {
    p["job-duration"] = isNaN(job.types[0].durations[0].amount)
      ? ""
      : +job.types[0].durations[0].amount;

    // job duration type isnt always loading from BE (caused by french only?)
    // find it in any language available
    p.jobDurationUnit = job.types[0].durations[0].type;
    if (
      !job.types[0].durations[0].type &&
      job.types[0].durations[0].translations.length
    ) {
      p.jobDurationUnit = job.types[0].durations[0]?.translations.find(
        (v) => v.type,
      ).type;
    }
  }

  //   "hoursPerWeek": "25",
  if (
    job.types &&
    job.types?.length &&
    job.types[0].work_hours?.length &&
    job.types[0]?.work_hours[0]?.min_hours
  ) {
    p.hoursPerWeek = job.types[0]?.work_hours[0]?.min_hours;
  }

  // Note: Salary removed and this is no longer necessary
  //   "salaryType": "Hourly",
  //   "salaryOffered": "range",
  //   "salaryOfferedMin": "353",
  //   "salaryOfferedMax": "335535",
  if (
    job.types &&
    job.types[0] &&
    job.types[0].salaries &&
    job.types[0].salaries[0]
  ) {
    const s = job.types[0].salaries[0];
    p.salaryType = s.type;
    p.salaryOffered = s.min_amount === s.max_amount ? "fixed" : "range";
    p.salaryOfferedMin = s.min_amount;
    p.salaryOfferedMax = s.max_amount;
  }

  //   "workShift": ["day", "varies"],
  if (job.types && job.types[0] && job.types[0].shifts) {
    p.workShift = job.types[0].shifts.map((s) => s.name);
  }

  // start date
  if (
    job.types &&
    job.types[0] &&
    job.types[0].durations?.length &&
    job.types[0].durations[0].start_date
  ) {
    p.startDate = JSON.stringify(
      new Date(job.types[0].durations[0].start_date),
    );
  }

  //   "benefits": [
  //     "{\"id\":8,\"account_id\":649,\"icon_name\":\"default.png\",\"content\":\"Group insurance\",\"translations\":[{\"id\":15,\"content\":\"Group insurance\",\"locale\":\"en\"},{\"id\":16,\"content\":\"Assurance collective\",\"locale\":\"fr\"}]}",
  //     "{\"id\":50,\"account_id\":649,\"icon_name\":\"breakfast.png\",\"content\":\"Coffee\",\"translations\":[{\"id\":99,\"content\":\"Coffee\",\"locale\":\"en\"},{\"id\":100,\"content\":\"Café\",\"locale\":\"fr\"}]}",
  //     "{\"id\":120,\"account_id\":649,\"icon_name\":\"default.png\",\"content\":\"Workshops\",\"translations\":[{\"id\":239,\"content\":\"Workshops\",\"locale\":\"en\"},{\"id\":240,\"content\":\"Ateliers\",\"locale\":\"fr\"}]}"
  //   ],
  if (job.benefits) {
    // p.benefits = job.benefits.map((b) => JSON.stringify(b));
    // p.benefits = [...job.benefits];
    p.benefits = job.benefits.map((b) => b.content);
  }

  //   "budgetApproved": "false",
  p.budgetApproved = job.requisition?.within_budget === 1 ? "true" : "false";

  //   "budgetApprovalReason": "Nobody wants to",
  p.budgetApprovalReason = job.requisition?.budget_explanation;

  //   "hiringType": "-",
  p.hiringType = job.requisition?.hire_type;

  //   "explanationHiringType": "Yolo",
  p.explanationHiringType = job.requisition?.hire_reason ?? "";

  //   "diversityPlan": "true",
  p.diversityPlan = job.requisition?.is_diversity_plan === 1;

  //   "jobDescriptionEnglish": "Something great's about to happen",
  // p.jobDescriptionEnglish = job?.translations[0]?.description ?? "";

  //   "jobDescriptionFrench": "Oui",
  // p.jobDescriptionFrench = job?.translations[1]?.description ?? "";

  //   "skills": [
  //     {
  //       "selected": "true",
  //       "is_asset": false,
  //       "id": 2,
  //       "account_id": 649,
  //       "name": "Bilingue",
  //       "definition": "Français et anglais",
  //       "translations": [
  //         {
  //           "id": 3,
  //           "name": "Bilingue",
  //           "definition": "Français et anglais",
  //           "locale": "en"
  //         },
  //         {
  //           "id": 4,
  //           "name": "Bilingue",
  //           "definition": "Français et anglais",
  //           "locale": "fr"
  //         }
  //       ]
  //     },
  if (job.skills && job.skills.length) {
    p.skills = job.skills.map((s) => ({
      name: s.name,
      selected: "true",
      is_asset: s.is_asset === 1 ? "true" : "false",
      translations: [...s.translations],
    }));
    // p.skills = job.skills.map(s => ({
    //   selected:
    // }))
  }

  //   "additionalTerms": "Nightvision"
  p.additionalTerms = job.additional_terms ?? "";

  // }

  // FROM REQUISITION OBJECT ITSELF. OVERRIDE FRO THIS OBJECT IF DATA WAS DERIVED
  // FROM JOB (JOB TYPES OBJECT)

  const selectedLocale = job.requisition?.locale ?? "fr";

  // locale index
  const iL = selectedLocale === "en" ? 0 : 1;

  // job.requisition.translations[iL];

  // "hire_type": "1",
  if (job.requisition?.translations?.length) {
    p.hiringType = job.requisition?.translations[iL]?.hire_type ?? "";

    // "hire_reason": "",
    p.explanationHiringType =
      job.requisition?.translations[iL]?.hire_reason ?? "";

    // "group_name": "Development",
    p.requisitionGroups = job.requisition?.translations[iL]?.group_name ?? "";

    p.union_description =
      job.requisition?.translations[iL]?.union_description ?? "";

    // "planned_salary_type": "Replacement",
    p.jobType = job.requisition?.translations[iL]?.planned_salary_type ?? "";

    // "budget_explanation": null,
    p.budgetApprovalReason =
      job.requisition?.translations[iL]?.budget_explanation ?? "";

    // "additional_terms": "",
    p.additionalTerms =
      job.requisition?.translations[iL]?.additional_terms ?? "";

    // "rejection_reason": null,
    p.rejection_reason =
      job.requisition?.translations[iL]?.rejection_reason ?? "";

    // "hiring_manager_department": "IT département",
    p.requisition.hiring_manager_department =
      job.requisition?.translations[iL]?.hiring_manager_department ?? "";
  }

  return p;
};
