import { datetimeToUTC } from "global/utils/dateTimeLanguageUtils";

export const convertRequisitionDataToPostData = (data, locale, cache) => {
  const p = {
    requisition: {
      // 'requisition.job_id' => 'sometimes|integer',
      ...(data.requisition?.job_id ? { job_id: data.requisition.job_id } : {}),
      translations: [],
    },

    translations: [],
  };

  p.id = data.id ?? null;

  // 'translations' => 'array|min:1',
  // 'translations.*.locale' => 'required|string|in:en,fr',
  // 'translations.*.title' => 'required|string',
  // 'translations.*.description' => 'string',
  if (data.translations) {
    p.translations = Object.entries(data.translations).map(
      ([locale, { title, description }]) => ({ locale, title, description }),
    );
  }

  if (typeof data.requisition !== "object") {
    throw new Error("This form is missing vital 'requisition' object");
  }

  // // 'requisition.approval_required' => 'required|boolean',
  p.requisition.approval_required = data.requisition.approval_required;

  // // 'requisition.number_of_reviewers' => 'integer',
  p.requisition.number_of_reviewers = data.requisition.approval_required
    ? data.requisition.reviewers.length
    : 0;

  // 'number_of_positions' => 'required|integer'
  p.number_of_positions = parseInt(data.number_of_positions);

  // 'requisition.grade' => 'string',
  if (data.requisition.grade) {
    p.requisition.grade = data.requisition.grade;
  }

  // 'requisition.within_budget' => 'boolean',
  if (data.requisition.within_budget) {
    p.requisition.within_budget = data.requisition.within_budget === "true";
  }

  // 'requisition.is_unionized' => 'boolean',
  if (typeof data.requisition.is_unionized !== "undefined") {
    p.requisition.is_unionized = data.requisition.is_unionized === "true";
  }

  // 'requisition.yearly_manpower_plan' => 'boolean',
  if (typeof data.requisition.yearly_manpower_plan !== "undefined") {
    p.requisition.yearly_manpower_plan =
      data.requisition.yearly_manpower_plan === "true";
  }

  // 'requisition.is_diversity_plan' => 'boolean',
  if (typeof data.requisition.is_diversity_plan !== "undefined") {
    p.requisition.is_diversity_plan =
      data.requisition.is_diversity_plan === "true";
  }

  // 'requisition.reports_to_position' => 'string',
  if (typeof data.requisition.reports_to_position === "string") {
    p.requisition.reports_to_position = data.requisition.reports_to_position;
  }

  // 'requisition.reports_to_email' => 'sometimes|string',
  if (typeof data.requisition.reports_to_email === "string") {
    p.requisition.reports_to_email = data.requisition.reports_to_email;
  }

  // 'requisition.reports_to_name' => 'required_with:requisition.reports_to_email|string',
  if (typeof data.requisition.reports_to_name === "string") {
    p.requisition.reports_to_name = data.requisition.reports_to_name;
  }

  // 'requisition.hiring_manager_name' => 'string',
  if (typeof data.requisition.hiring_manager_name === "string") {
    p.requisition.hiring_manager_name = data.requisition.hiring_manager_name;
  }

  // 'requisition.planned_salary_min' => 'integer',
  if (!!data.requisition.planned_salary_min) {
    p.requisition.planned_salary_min = Math.round(
      data.requisition.planned_salary_min * 100,
    );
  }

  // 'requisition.planned_salary_max' => 'integer',
  if (!!data.requisition.planned_salary_min && data.plannedSalary === "range") {
    p.requisition.planned_salary_max = Math.round(
      data.requisition.planned_salary_max * 100,
    );
  } else {
    p.requisition.planned_salary_max = p.requisition.planned_salary_min;
  }

  // 'requisition.planned_salary_currency' => 'string',
  if (typeof data.planned_salary_currency === "string") {
    p.requisition.planned_salary_currency = data.planned_salary_currency;
  }
  // if (typeof data.requisition.planned_salary_currency === "string") {
  //   p.requisition.planned_salary_currency =
  //     data.requisition.planned_salary_currency;
  // }

  // 'requisition.status_id' => 'required|integer',
  // TODO: submit action should set requisition.status_id
  // p.requisition.status_id = 1;

  // 'locations' => 'required_without:job_id|array',
  // 'locations.*.location_id' => 'required|integer',
  if (data.locations) {
    // TODO: add more locations by adding more Google Autocomplete comps
    // p.locations = [{ location_id: data.location.id }];
    // p.locations = data.locations.map((l) => ({ id: l.id }));
    p.locations = data.locations;
  }

  // 'requisition.reviewers' => 'required_if:requisition.approval_required,==,true|array|min:1',
  // 'requisition.reviewers.*.reviewer_user_id' => 'integer|required',
  // 'requisition.reviewers.*.is_mandatory' => 'boolean|required',
  // 'requisition.reviewers.*.review_feedback_status' => 'integer',
  if (
    p.requisition.approval_required &&
    // data.requisition.reviewers &&
    data.requisition?.reviewers?.length
  ) {
    const ids = new Set(data.requisition.reviewers.map((r) => +r));

    p.requisition.reviewers = Object.values(cache.requisitionReviewers)
      // .filter((r) => ids.has(r.user_id))
      .filter((r) => ids.has(r.id))
      .map((r) => ({ reviewer_user_id: r.id, is_mandatory: true }));
  } else {
    p.requisition.reviewers = [];
  }

  // 'requisition.translations' => 'array',
  const requisitionTranslations = { en: {}, fr: {} };
  const otherLocale = locale === "en" ? "fr" : "en";

  // 'requisition.translations.*.hire_type' => 'string',
  // TODO: check if the value should be other than id
  if (!!data.hiringType) {
    // translation.hire_type = data.hiringType;
    const hiringTypeTranslations = cache.hireTypes.find(
      (h) => h.name === data.hiringType,
    )?.translations;
    if (hiringTypeTranslations) {
      requisitionTranslations.en.hire_type = hiringTypeTranslations[0].name;
      requisitionTranslations.fr.hire_type = hiringTypeTranslations[1].name;
    } else {
      requisitionTranslations.en.hire_type =
        requisitionTranslations.fr.hire_type = "";
    }
  }

  // 'requisition.translations.*.hire_reason' => 'string',
  if (!!data.explanationHiringType) {
    requisitionTranslations[locale].hire_reason = data.explanationHiringType;
    // requisitionTranslations[otherLocale].hire_reason = "";
    requisitionTranslations[otherLocale].hire_reason =
      data.explanationHiringType;
  }

  // 'requisition.translations.*.budget_explanation' => 'required_if:requisition.within_budget,false|string',
  if (!!data.budgetApprovalReason) {
    requisitionTranslations[locale].budget_explanation =
      data.budgetApprovalReason;
    // requisitionTranslations[otherLocale].budget_explanation = "";
    requisitionTranslations[otherLocale].budget_explanation =
      data.budgetApprovalReason;
  }

  // 'requisition.translations.*.additional_terms' => 'string',
  if (!!data.additionalTerms) {
    requisitionTranslations[locale].additional_terms = data.additionalTerms;
    // requisitionTranslations[otherLocale].additional_terms = "";
    requisitionTranslations[otherLocale].additional_terms =
      data.additionalTerms;
  }

  // 'requisition.translations.*.group_name' => 'string',
  if (!!data.requisitionGroups) {
    const requisitionGroupTranslations = cache.requisitionGroups.find(
      (g) => g.name === data.requisitionGroups,
    )?.translations;

    // crash prevention when groups get deleted
    if (requisitionGroupTranslations) {
      requisitionTranslations.en.group_name =
        requisitionGroupTranslations[0].name;
      requisitionTranslations.fr.group_name =
        requisitionGroupTranslations[1].name;
    } else {
      requisitionTranslations.en.group_name =
        requisitionTranslations.fr.group_name = "";
    }
  }

  // 'requisition.translations.*.group_name' => 'string',
  if (!!data.union_description) {
    requisitionTranslations[locale].union_description =
      data.union_description ?? "";
    requisitionTranslations[otherLocale].union_description =
      data.union_description ?? "";
  }

  // TODO: verify if this is the actual key : change to salary type
  // 'requisition.translations.*.planned_salary_type' => 'string',
  // translation.planned_salary_type = data.requisition.planned_salary_currency;

  const salaryTypeTranslations = cache.salaries.find(
    (s) => s.name === data.jobType,
  )?.translations;

  if (salaryTypeTranslations) {
    requisitionTranslations.en.planned_salary_type =
      salaryTypeTranslations[0].name;
    requisitionTranslations.fr.planned_salary_type =
      salaryTypeTranslations[1].name;
  } else {
    requisitionTranslations.en.planned_salary_type =
      requisitionTranslations.fr.planned_salary_type = "";
  }

  // 'requisition.translations.*.hiring_manager_department' => 'string',
  if (data.requisition.hiring_manager_department) {
    const hiringDepartmentTranslations = cache.hiringManagerDepartments.find(
      (d) => d.name === data.requisition.hiring_manager_department,
    )?.translations;

    if (hiringDepartmentTranslations) {
      requisitionTranslations.en.hiring_manager_department =
        hiringDepartmentTranslations[0].name;
      requisitionTranslations.fr.hiring_manager_department =
        hiringDepartmentTranslations[1].name;
    } else {
      requisitionTranslations.en.hiring_manager_department =
        requisitionTranslations.fr.hiring_manager_department = "";
    }
  }

  p.requisition.translations = [
    { ...requisitionTranslations["en"], locale: "en" },
    { ...requisitionTranslations["fr"], locale: "fr" },
  ];

  // 'requisition.translations.*.locale' => 'required|string|in:en,fr',
  // translation.locale = locale;

  // FIXME: both translations? how do you enter the other language
  // p.requisition.translations = [
  //   translation,
  //   {
  //     ...translation,

  //     locale: locale === "en" ? "fr" : "en",
  //   },
  // ];

  // 'benefits' => 'array',
  // 'benefits.*.icon_name' => 'string',
  // 'benefits.*.translations' => 'required|array',
  // 'benefits.*.translations.*.locale' => 'required|string',
  // 'benefits.*.translations.*.content' => 'required|string',
  if (data.benefits && data.benefits.length) {
    const selectedBenefits = new Set(data.benefits);
    p.benefits = cache.benefits
      .filter((b) => selectedBenefits.has(b.content))
      .map((b) => ({
        icon_name: b.icon_name,
        translations: b.translations,
      }));
  }

  // 'skills' => 'array',
  // 'skills.*.is_asset' => 'boolean',
  // 'skills.*.translations' => 'required|array',
  // 'skills.*.translations.*.locale' => 'required|string',
  // 'skills.*.translations.*.name' => 'nullable|string',
  // 'skills.*.translations.*.definition' => 'nullable|string',
  if (data.skills && data.skills.length) {
    p.skills = data.skills
      .filter((s) => s.selected === "true")
      .map((s) => ({
        is_asset: s.is_asset === "true",
        translations: s.translations.map((t) => ({
          name: t.name,
          locale: t.locale,
          definition: t.definition,
        })),
      }));
  }

  // TODO: find out what these groups are

  // 'groups' => 'array',
  // 'groups.*.translations' => 'required|array',
  // 'groups.*.translations.*.locale' => 'required|string',
  // 'groups.*.translations.*.name' => 'required|string',

  const duration = {};
  // 'types.*.durations' => 'array',
  // 'types.*.durations.*.amount' => 'required_with:types.*.durations.*.translations|integer|min:0',
  // 'types.*.durations.*.start_date' => 'date|nullable',
  // 'types.*.durations.*.translations' => 'required_with:types.*.durations.*.amount|array',
  // 'types.*.durations.*.translations.*.locale' => 'required|string',
  // 'types.*.durations.*.translations.*.type' => 'required|string',
  if (!!data["job-duration"]) {
    duration.amount = data["job-duration"];
    duration.translations = [{ locale, type: data.jobDurationUnit }];
  }
  if (data["startDate"]) {
    duration.start_date = datetimeToUTC(
      new Date(JSON.parse(data.startDate)),
      "flatTime",
    );
  }

  const salary = {};
  // 'types.*.salaries' => 'array',
  // 'types.*.salaries.*.min_amount' => 'required|integer|min:0',
  // 'types.*.salaries.*.max_amount' => 'required|integer|min:0',
  // 'types.*.salaries.*.currency' => 'required|string|max:3',
  // 'types.*.salaries.*.negotiable' => 'boolean',
  // 'types.*.salaries.*.translations' => 'required|array',
  // 'types.*.salaries.*.translations.*.locale' => 'required|string',
  // 'types.*.salaries.*.translations.*.type' => 'required|string',
  salary.min_amount = data.salaryOfferedMin * 100;
  salary.max_amount = data.salaryOfferedMax * 100;
  salary.currency = data.currency;
  // TODO: remove setting negotiable to false here and let the BE set it to
  // false if not set
  salary.negotiable = false;
  salary.translations = [{ locale, type: data.salaryType }];

  // 'types.*.shifts' => 'array',
  // 'types.*.shifts.*.translations' => 'required|array',
  // 'types.*.shifts.*.translations.*.locale' => 'required|string',
  // 'types.*.shifts.*.translations.*.name' => 'required|string',
  let shifts;
  if (!!data.workShift?.length) {
    const names = new Set(data.workShift);
    shifts = cache.shifts
      .filter((s) => names.has(s.name))
      .map((s) => ({ translations: s.translations }));
  }

  // const work_hours = {};
  // 'types.*.work_hours' => 'array',
  // 'types.*.work_hours.*.min_hours' => 'required|numeric|between:0.00,999.99',
  // 'types.*.work_hours.*.max_hours' => 'required|numeric|between:0.00,999.99',
  const work_hours = [
    {
      min_hours: parseFloat(data.hoursPerWeek),
      max_hours: parseFloat(data.hoursPerWeek),
    },
  ];

  // 'types.*.translations' => 'required|array',
  // 'types.*.translations.*.locale' => 'required|string',
  // 'types.*.translations.*.name' => 'required|string',
  // const translations = Object.entries(data.translations).map((e) => ({
  //   locale: e[0],
  //   name: e[1].title,
  // }));

  // job type (salary api)
  const translations = cache.salaries.find(
    (s) => s.name === data.jobType,
  ).translations;

  p.types = [
    {
      durations: [duration],
      // salaries: [salary],
      shifts,
      work_hours,
      translations,
    },
  ];

  return p;
};
