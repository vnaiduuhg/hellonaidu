import { out } from "global/utils/useTranslation";

export const hMDPostMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Département du gestionnaire du poste ajouté avec succès!",
        "Hiring manager department added successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour créer un Département du gestionnaire du poste",
        "You do not have the required permission to create a hiring manager department",
      );
      break;
    // could glide into default from here
    case 422:
      if ("translations" in promise.data) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer que tous les champs requis sont remplis",
          "Please make sure that all reqired fields are filled",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le Département du gestionnaire du poste n'a pu être sauvegardé",
        "The hiring manager department could not be saved",
      );
  }

  return msg;
};

export const hMDPutMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Département du gestionnaire du poste modifié avec succès!",
        "Hiring manager department modified successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier un Département du gestionnaire du poste",
        "You do not have the required permission to modify a hiring manager department",
      );
      break;
    // could glide into default from here
    case 422:
      if ("translations" in promise.data) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer que tous les champs requis sont remplis",
          "Please make sure that all reqired fields are filled",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le Département du gestionnaire du poste n'a pu être modifié",
        "The hiring manager department could not be modified",
      );
  }

  return msg;
};

export const hMDDeleteMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Département du gestionnaire du poste supprimé avec succès!",
        "Hiring manager department removed successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer un Département du gestionnaire du poste",
        "You do not have the required permission to remove a hiring manager department",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le Département du gestionnaire du poste sélectionné n'a pu être supprimé",
        "The selected hiring manager department could not be removed",
      );
  }

  return msg;
};
