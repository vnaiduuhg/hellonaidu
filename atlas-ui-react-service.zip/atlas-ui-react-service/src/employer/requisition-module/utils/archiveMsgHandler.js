import { out } from "global/utils/useTranslation";

export const archivesDeleteMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Demande archivée avec succès!",
        "Requisition archived successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour archiver cette demande",
        "You do not have the required permission to archive this requisition",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La demande n'a pu être archivée",
        "The requisition could not be archived",
      );
  }

  return msg;
};
