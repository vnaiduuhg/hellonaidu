export const requisitionStats = (requisitions) => ({
  pendingSum: requisitions.filter((item) => item.status.name === "Submitted")
    .length,
  approvedSum: requisitions.filter((item) =>
    item.status.name.match(/^Approved/),
  ).length,
  salaryMaxSum: requisitions.reduce((itemA, itemB) => {
    return itemA + itemB.planned_salary_max;
  }, 0),
  salaryMinSum: requisitions.reduce((itemA, itemB) => {
    return itemA + itemB.planned_salary_min;
  }, 0),
});
