import { getRequisitionReviewerByAccountPromise } from "employer/requisition-module/api/requisitionReviewerApi";
import { useSelector } from "react-redux";
import useAtlasQuery from "global/utils/useAtlasQuery";

const getReviewers = async (userId, accountId) => {
  try {
    const response = await getRequisitionReviewerByAccountPromise(accountId);

    if (!response.length) throw new Error("no reviewers");

    const isUserAReviewer = !!response.find(
      (reviewer) => +reviewer.id === +userId,
    );

    return { isUserAReviewer, reviewersList: response };
  } catch (e) {
    // TODO: throw error. Not done now because that was not in the original code.
    return { isUserAReviewer: null, reviewersList: [] };
  }
};

export const useRequisitionReviewers = () => {
  const user = useSelector((state) => state.user.data);

  const { data, isLoading, isError, error } = useAtlasQuery(
    "requisition-reviewers",
    () => getReviewers(+user?.user_id, +user?.user_account?.account_id),
    { enabled: !!user },
  );

  return {
    isUserAReviewer: data?.isUserAReviewer ?? null,
    reviewersList: data?.reviewersList ?? [],
    status: {
      isLoading,
      isError,
      error: isError ? error : null,
    },
  };
};
