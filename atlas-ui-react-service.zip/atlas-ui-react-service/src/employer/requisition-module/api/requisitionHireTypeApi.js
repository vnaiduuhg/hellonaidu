import {
  deleteRestrictedApi,
  getRestrictedApi,
  putRestrictedApi,
  postRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getAllRequisitionHireTypes = async () => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    "requisition/hire-types",
    getToken(),
  );

  return response;
};

export const getRequisitionHireTypeById = async (id) => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/hire-types/${id}`,
    getToken(),
  );

  return response;
};

export const getRequisitionHireTypesByAccount = async (accountId) => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/accounts/${accountId}/hire-types`,
    getToken(),
  );

  return response;
};

export const updateRequisitionHireType = async (id, data) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.jobs,
      `requisition/hire-types`,
      getToken(),
      id,
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const removeRequisitionHireType = async (id) => {
  try {
    const response = await deleteRestrictedApi(
      serviceNames.jobs,
      `requisition/hire-types/${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createRequisitionHireType = async (data) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.jobs,
      `requisition/hire-types`,
      getToken(),
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
