import {
  deleteRestrictedApi,
  getRestrictedApi,
  putRestrictedApi,
  postRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getAllHiringManagerDepartments = async () => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    "requisition/hiring-manager-departments",
    getToken(),
  );

  return response;
};

export const getHiringManagerDepartmentById = async (id) => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/hiring-manager-departments/${id}`,
    getToken(),
  );

  return response;
};

export const getHiringManagerDepartmentByAccount = async (accountId) => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/accounts/${accountId}/hiring-manager-departments`,
    getToken(),
  );

  return response;
};

export const updateHiringManagerDepartment = async (id, data) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.jobs,
      `requisition/hiring-manager-departments`,
      getToken(),
      id,
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const removeHiringManagerDepartment = async (id) => {
  try {
    const response = await deleteRestrictedApi(
      serviceNames.jobs,
      `requisition/hiring-manager-departments/${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createHiringManagerDepartment = async (data) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.jobs,
      `requisition/hiring-manager-departments`,
      getToken(),
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
