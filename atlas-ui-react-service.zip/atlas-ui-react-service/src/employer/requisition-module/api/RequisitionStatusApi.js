import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getRequisitionsStatusList = async () => {
  const reponse = await getRestrictedApi(
    serviceNames.jobs,
    "requisition/status",
    getToken(),
  );

  return reponse;
};
