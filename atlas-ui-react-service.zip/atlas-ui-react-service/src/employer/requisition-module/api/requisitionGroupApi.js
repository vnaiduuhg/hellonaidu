import {
  deleteRestrictedApi,
  getRestrictedApi,
  putRestrictedApi,
  postRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getAllRequisitionGroups = async () => {
  const reponse = await getRestrictedApi(
    serviceNames.jobs,
    "requisition/groups",
    getToken(),
  );

  return reponse;
};

export const getRequisitionGroupById = async (id) => {
  const response = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/groups/${id}`,
    getToken(),
  );

  return response;
};

export const getRequisitionGroupsByAccount = async (accountId) => {
  const reponse = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/accounts/${accountId}/groups`,
    getToken(),
  );

  return reponse;
};

export const updateRequisitionGroup = async (id, data) => {
  try {
    const reponse = await putRestrictedApi(
      serviceNames.jobs,
      `requisition/groups`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const removeRequisitionGroup = async (id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.jobs,
      `requisition/groups/${id}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createRequisitionGroup = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.jobs,
      `requisition/groups`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
