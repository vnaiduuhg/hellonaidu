import {
  deleteRestrictedApi,
  getRestrictedApi,
  patchRestrictedApi,
  postRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getRequisitionReviewerById = async (id) => {
  const reponse = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/reviewer/${id}`,
    getToken(),
  );

  return reponse;
};

export const getRequisitionReviewerByAccount = async (accountId) => {
  const reponse = await getRestrictedApi(
    serviceNames.jobs,
    `requisition/accounts/${accountId}/reviewers`,
    getToken(),
  );

  return reponse;
};

// @temp - need the promise
export const getRequisitionReviewerByAccountPromise = async (accountId) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.jobs,
      `requisition/accounts/${accountId}/reviewers`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateRequisitionReviewer = async (data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.jobs,
      `requisition/reviewers`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const removeRequisitionReviewer = async (id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.jobs,
      `requisition/reviewers/${id}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createRequisitionReviewer = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.jobs,
      `requisition/reviewers`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
