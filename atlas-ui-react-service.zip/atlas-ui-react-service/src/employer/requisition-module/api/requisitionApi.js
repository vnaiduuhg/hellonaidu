import {
  getRestrictedApi,
  patchRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const searchRequisitions = async (filter = null) =>
  postRestrictedApi(
    serviceNames.jobs,
    "requisition/search",
    getToken(),
    filter,
  );

export const updateRequisition = async (id, requisitionData) =>
  putRestrictedApi(
    serviceNames.jobs,
    "requisition",
    getToken(),
    id,
    requisitionData,
  );

export const updateRequisitionReviewerStatus = async (id, data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.jobs,
      `requisition/${id}/reviewers-status`,
      getToken(),
      null,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createRequisition = async (requisitionData) =>
  postRestrictedApi(
    serviceNames.jobs,
    "requisition",
    getToken(),
    requisitionData,
  );

export const submitRequisition = async (data, id) =>
  patchRestrictedApi(
    serviceNames.jobs,
    `requisition/${id}/submit-requisition`,
    getToken(),
    null,
    data,
  );

export const getRequisition = async (requisitionId) =>
  getRestrictedApi(
    serviceNames.jobs,
    `requisition/${requisitionId}`,
    getToken(),
  );

export const getRequisitionHistory = async (requisitionId) =>
  getRestrictedApi(
    serviceNames.indexing,
    `indexing/history/requisition/${requisitionId}`,
    getToken(),
  );

export const deleteRequisition = async (id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.jobs,
      `requisition/${id}`,
      getToken(),
      null,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
