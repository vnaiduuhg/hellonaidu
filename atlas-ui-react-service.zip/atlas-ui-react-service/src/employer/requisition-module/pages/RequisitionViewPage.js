import React, { useState, useEffect, useCallback } from "react";
import { useParams, useHistory } from "react-router-dom";
import { useQuery } from "react-query";
import { useDispatch } from "react-redux";
import { useTranslation } from "global/utils/useTranslation";
import { useSelector } from "react-redux";
import RequisitionPreview from "../components/RequisitionPreview.js";
import RequisitionHistory from "employer/requisition-module/components/RequisitionHistory.js";
import useAtlasQuery from "global/utils/useAtlasQuery";
import { getRequisition, getRequisitionHistory } from "../api/requisitionApi";
import RequisitionActions from "../components/RequisitionActions";
import { getRequisitionsStatusList } from "../api/RequisitionStatusApi";
import { getRequisitionReviewerByAccountPromise } from "../api/requisitionReviewerApi";
import { getLocationsByKeyAndValues } from "global/apis/locationApi";
import { showMessage } from "global/store/statusMessagesSlice";
import { setFromattedAddress } from "global/utils/locationUtil";
import { Button, Col, Container, Row } from "react-bootstrap";
import { AiOutlineDoubleLeft } from "react-icons/ai";
import { PageLoader } from "global/components/loaders/page-loader.js";

const RequisitionViewPage = () => {
  const dispatch = useDispatch();
  const { requisitionId } = useParams();
  const { out } = useTranslation();
  let history = useHistory();

  const [reviewersList, setReviewersList] = useState([]);
  // const [isReviewer, setIsReviewer] = useState(null);
  const [formattedLocations, setFormattedLocations] = useState(null);
  const user = useSelector((state) => state.user.data);
  const currentLanguage = useSelector((state) => state.user.language);

  const goBack = useCallback(() => history.push("/planning"));

  // @temp - can't handle response with useQuery and need to perform an action after data is fetched
  useEffect(() => {
    getRequisitionReviewerByAccountPromise(user.user_account.account_id)
      .then((response) => {
        if (response.length > 0) {
          setReviewersList(response);
        } else {
          // handle error case if no list
        }
      })
      .catch(() => {
        // handle error case if no list
      });
  }, [user.user_account.account_id]);

  const {
    data: requisition,
    isError: requisitionIsError,
    isLoading: requisitionIsLoading,
  } = useAtlasQuery(["requisitions", { id: requisitionId }], () =>
    getRequisition(requisitionId),
  );

  let translatedTitle = document.title;
  if (requisition) {
    translatedTitle = out(
      requisition.job.translations[1].title,
      requisition.job.translations[0].title,
    );
    translatedTitle = `${translatedTitle} - Workland`;
  }
  useEffect(() => {
    document.title = translatedTitle;
  }, [translatedTitle]);

  const {
    data: requisitionHistory,
    isError: requisitionHistoryIsError,
    isLoading: requisitionHistoryIsLoading,
  } = useAtlasQuery(
    ["get-requisition-history-by-id", { id: requisitionId }],
    () => getRequisitionHistory(requisitionId),
  );

  const { data: statusList = [] } = useQuery(
    "requisition-statuses",
    getRequisitionsStatusList,
    {
      refetchOnWindowFocus: false,
    },
  );

  useEffect(() => {
    if (
      requisition &&
      requisition.job.locations &&
      requisition.job.locations.length > 0 &&
      formattedLocations === null
    ) {
      const tempFormattedAddressArray = [];
      const arrayOfLocation = requisition.job.locations.map(
        (l) => l.location_id,
      );
      getLocationsByKeyAndValues(arrayOfLocation)
        .then((response) => {
          if (Object.keys(response).length > 0) {
            arrayOfLocation.forEach((locationId) => {
              if (response[locationId]) {
                const formattedAddress = setFromattedAddress(
                  response[locationId],
                );
                if (formattedAddress)
                  tempFormattedAddressArray.push(formattedAddress);
              }
            });
            setFormattedLocations(tempFormattedAddressArray);
          }
        })
        .catch(() => {
          dispatch(
            showMessage(
              "error",
              out("Adresse non récupérée", "Address not retrieved"),
              out(
                "Un problème est survenu lors de la récupération de l'adresse, veuillez la saisir à nouveau",
                "There was a problem retrieving the address, please enter it again",
              ),
              7000,
            ),
          );
        });
    }
  }, [dispatch, formattedLocations, out, requisition]);

  let content;
  if (requisition) {
    content = (
      <>
        <Row className="mt-2 mb-3">
          <Col xs={12} lg={5} className="d-flex align-items-center">
            <Button
              variant="tertiary"
              className="p-1 px-2 me-3"
              onClick={goBack}
              title={out("Retourner", "Go back")}
            >
              <AiOutlineDoubleLeft />
            </Button>

            <h1 className="h5 d-inline-block m-0">
              {requisition &&
                out(
                  requisition.job.translations[1].title,
                  requisition.job.translations[0].title,
                )}
            </h1>
          </Col>

          <Col
            xs={12}
            lg={7}
            className="d-flex justify-content-center justify-content-lg-end"
          >
            <RequisitionActions
              requisition={requisition}
              statusList={statusList}
              reviewersList={reviewersList}
              user={user}
              currentLanguage={currentLanguage}
            />
          </Col>
        </Row>

        <Row className="g-2">
          <Col xs={12} xxl={8}>
            <RequisitionPreview
              data={requisition}
              formattedLocations={formattedLocations}
              showTitle={false}
              isError={requisitionIsError}
              isLoading={requisitionIsLoading}
            />
          </Col>

          <Col xs={12} xxl={4}>
            <RequisitionHistory
              data={requisitionHistory}
              isError={requisitionHistoryIsError}
              isLoading={requisitionHistoryIsLoading}
            />
          </Col>
        </Row>
      </>
    );
  }

  return (
    <Container fluid>
      {requisitionIsLoading && (
        <PageLoader
          message={out("Chargement des données", "Loading requisition data")}
        />
      )}
      {requisitionIsError && (
        <div className="text-center text-warning fs-4 mt-5">
          {out("Impossible de récupérer les données", "Cannot retrieve data")}
        </div>
      )}
      {requisition && content}
    </Container>
  );
};

export default RequisitionViewPage;
