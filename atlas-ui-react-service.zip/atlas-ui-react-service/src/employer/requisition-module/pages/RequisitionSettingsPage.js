import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";

import { showMessage } from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import RequisitionSettingsCard from "../components//RequisitionSettingsCard";
import RequisitionSettingsNavbar from "../components/RequisitionSettingsNavbar";
import {
  getHiringManagerDepartmentByAccount,
  createHiringManagerDepartment,
  updateHiringManagerDepartment,
  removeHiringManagerDepartment,
} from "../api/hiringManagerDepartmentApi";
import {
  getRequisitionHireTypesByAccount,
  createRequisitionHireType,
  updateRequisitionHireType,
  removeRequisitionHireType,
} from "../api/requisitionHireTypeApi";
import {
  getRequisitionGroupsByAccount,
  createRequisitionGroup,
  updateRequisitionGroup,
  removeRequisitionGroup,
} from "../api/requisitionGroupApi";
import {
  getRequisitionReviewerByAccount,
  createRequisitionReviewer,
  removeRequisitionReviewer,
} from "../api/requisitionReviewerApi";
import { getAccountProfile } from "global/apis/userApi"; // @temp
import { getRoles } from "global/apis/authorizationApi";
import {
  hMDPostMsgHandler,
  hMDPutMsgHandler,
  hMDDeleteMsgHandler,
} from "../utils/hiringManagerDepartmentsMsgHandler";
import {
  hireTypesPostMsgHandler,
  hireTypesPutMsgHandler,
  hireTypesDeleteMsgHandler,
} from "../utils/hireTypesMsgHandler";
import {
  groupsPostMsgHandler,
  groupsPutMsgHandler,
  groupsDeleteMsgHandler,
} from "../utils/groupsMsgHandler";
import {
  reviewersPostMsgHandler,
  reviewersDeleteMsgHandler,
} from "../utils/reviewersMsgHandler";
import style from "../assets/RequisitionSettingsUI.module.css";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";
import { Container } from "react-bootstrap";

const STALE_TIME = 10000 * 60; // 10 minutes

const RequisitionSettingsPage = () => {
  const user = useSelector((state) => state.user.data);
  const [accountMembersList, setAccountMembersList] = useState([]);
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(0);
  const [deleteMode, setDeleteMode] = useState(0);
  const [saveMode, setSaveMode] = useState(false);
  const [refreshInputs, setRefreshInputs] = useState(false);
  const [showUpdateLoader, setUpdateLoader] = useState(false);
  const [showHMDSaveLoader, setShowHMDSaveLoader] = useState(false);
  const [showHireTypesSaveLoader, setShowHireTypesSaveLoader] = useState(false);
  const [showGroupsSaveLoader, setShowGroupsSaveLoader] = useState(false);
  const [tabActive, setTabActive] = useState("hiringManagerDepartments");

  const dispatch = useDispatch();
  const { out } = useTranslation();

  const translatedTitle = `${out(
    "Options de planification",
    "Planning Settings",
  )} - Workland`;

  useEffect(() => {
    document.title = translatedTitle;
  }, [translatedTitle]);

  /* @todo
  - check with the team: if a reviewer can't be remove when attached to a requisition
    what about if he is attached only to old and inactive requisiions ?
  - handle validation error msgs under inputs
  */

  // @temp - should be done on state - userSlice
  useEffect(() => {
    getAccountProfile().then((response) => {
      if (response.status === "success") {
        setAccountMembersList(response.data.account_user);
      }
    });
  }, []);

  /* get queries */
  const { data: rolesList = [] } = useQuery("roles", () => getRoles());

  const {
    data: hiringManagerDepartments,
    isError: hiringManagerDepartmentIsError,
    isLoading: hiringManagerDepartmentIsLoading,
    isFetched: hiringManagerDepartmentIsFetched,
  } = useQuery(
    "hiring-manager-departments:by-account",
    () => getHiringManagerDepartmentByAccount(user.user_account.account_id),
    { staleTime: STALE_TIME },
  );

  const {
    data: hireTypes,
    isError: hireTypesIsError,
    isLoading: hireTypesIsLoading,
    isFetched: hireTypesIsFetched,
  } = useQuery(
    "requisition-hire-types:by-account",
    () => getRequisitionHireTypesByAccount(user.user_account.account_id),
    { staleTime: STALE_TIME },
  );

  const {
    data: requisitionGroups,
    isError: requisitionGroupsIsError,
    isLoading: requisitionGroupsIsLoading,
    isFetched: requisitionGroupsIsFetched,
  } = useQuery(
    "requisition-groups:by-account",
    () => getRequisitionGroupsByAccount(user.user_account.account_id),
    { staleTime: STALE_TIME },
  );

  const {
    data: requisitionReviewers,
    isError: requisitionReviewersIsError,
    isLoading: requisitionReviewersIsLoading,
    isFetched: requisitionReviewersIsFetched,
  } = useQuery(
    "requisition-reviewers:by-account",
    () => getRequisitionReviewerByAccount(user.user_account.account_id),
    { staleTime: STALE_TIME },
  );

  /* post queries */
  const HMDPostMutation = useMutation(
    (data) =>
      createHiringManagerDepartment({ translations: data.translations }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("hiring-manager-departments:by-account");
        if (hiringManagerDepartmentIsFetched) {
          setRefreshInputs(true);
          const msg = hMDPostMsgHandler(201, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setShowHMDSaveLoader(false);
        }
      },
      onError: (error) => {
        const msg = hMDPostMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setShowHMDSaveLoader(false);
      },
    },
  );

  const hireTypesPostMutation = useMutation(
    (data) => createRequisitionHireType({ translations: data.translations }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-hire-types:by-account");
        if (hireTypesIsFetched) {
          setRefreshInputs(true);
          const msg = hireTypesPostMsgHandler(201, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setShowHireTypesSaveLoader(false);
        }
      },
      onError: (error) => {
        const msg = hireTypesPostMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setShowHireTypesSaveLoader(false);
      },
    },
  );

  const groupsPostMutation = useMutation(
    (data) => createRequisitionGroup({ translations: data.translations }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-groups:by-account");
        if (requisitionGroupsIsFetched) {
          setRefreshInputs(true);
          const msg = groupsPostMsgHandler(201, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setShowGroupsSaveLoader(false);
        }
      },
      onError: (error) => {
        const msg = groupsPostMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setShowGroupsSaveLoader(false);
      },
    },
  );

  const reviewersPostMutation = useMutation(
    (data) => createRequisitionReviewer({ user_id: data }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-reviewers:by-account");
        if (requisitionReviewersIsFetched) {
          const msg = reviewersPostMsgHandler(201, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setSaveMode(false);
        }
      },
      onError: (error) => {
        const msg = reviewersPostMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setSaveMode(false);
      },
    },
  );

  /* put queries */
  const HMDPuttMutation = useMutation(
    (data) =>
      updateHiringManagerDepartment(data.id, {
        translations: data.translations,
      }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("hiring-manager-departments:by-account");
        if (hiringManagerDepartmentIsFetched) {
          const msg = hMDPutMsgHandler(200, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setEditMode(0);
          setUpdateLoader(false);
        }
      },
      onError: (error) => {
        const msg = hMDPutMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setUpdateLoader(false);
      },
    },
  );

  const hireTypesPutMutation = useMutation(
    (data) =>
      updateRequisitionHireType(data.id, { translations: data.translations }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-hire-types:by-account");
        if (hireTypesIsFetched) {
          const msg = hireTypesPutMsgHandler(200, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setEditMode(0);
          setUpdateLoader(false);
        }
      },
      onError: (error) => {
        const msg = hireTypesPutMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setUpdateLoader(false);
      },
    },
  );

  const groupsPutMutation = useMutation(
    (data) =>
      updateRequisitionGroup(data.id, { translations: data.translations }),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-groups:by-account");
        if (requisitionGroupsIsFetched) {
          const msg = groupsPutMsgHandler(200, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          setEditMode(0);
          setUpdateLoader(false);
        }
      },
      onError: (error) => {
        const msg = groupsPutMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setUpdateLoader(false);
      },
    },
  );

  /* delete queries */
  const hMDDeleteMutation = useMutation(
    (id) => removeHiringManagerDepartment(id),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("hiring-manager-departments:by-account");
        if (hiringManagerDepartmentIsFetched) {
          const msg = hMDDeleteMsgHandler(204);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          // setDeleteMode(0);
        }
      },
      onError: (error) => {
        const msg = hMDDeleteMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setDeleteMode(0);
      },
    },
  );

  const hireTypesDeleteMutation = useMutation(
    (id) => removeRequisitionHireType(id),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("requisition-hire-types:by-account");
        if (hireTypesIsFetched) {
          const msg = hireTypesDeleteMsgHandler(204);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          // setDeleteMode(0);
        }
      },
      onError: (error) => {
        const msg = hireTypesDeleteMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setDeleteMode(0);
      },
    },
  );

  const groupsDeleteMutation = useMutation((id) => removeRequisitionGroup(id), {
    onSuccess: () => {
      queryClient.invalidateQueries("requisition-groups:by-account");
      if (requisitionGroupsIsFetched) {
        const msg = groupsDeleteMsgHandler(204);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        // setDeleteMode(0);
      }
    },
    onError: (error) => {
      const msg = groupsDeleteMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      setDeleteMode(0);
    },
  });

  const reviewersDeleteMutation = useMutation(
    (id) => removeRequisitionReviewer(id),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("requisition-reviewers:by-account");
        if (requisitionReviewersIsFetched) {
          const msg = reviewersDeleteMsgHandler(204, response);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          // setDeleteMode(0);
        }
      },
      onError: (error) => {
        const msg = reviewersDeleteMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setDeleteMode(0);
      },
    },
  );

  return (
    <div className="page-wrapper-internal-page">
      <div className="content-container">
        <div className="d-flex flex-column h-100">
          <PageHeaderPanel
            iconClass="fa-solid fa-building-user"
            title={out("Options de planification", "Planning Settings")}
          />

          {/* tabs */}
          <RequisitionSettingsNavbar
            hMDCount={
              hiringManagerDepartments && hiringManagerDepartments.length
                ? hiringManagerDepartments.length
                : null
            }
            hireTypesCount={
              hireTypes && hireTypes.length ? hireTypes.length : null
            }
            groupsCount={
              requisitionGroups && requisitionGroups.length
                ? requisitionGroups.length
                : null
            }
            reviewersCount={
              requisitionReviewers && requisitionReviewers.length
                ? requisitionReviewers.length
                : null
            }
            tabActive={tabActive}
            setTabActive={setTabActive}
          />
          <Container
            className={`${style.requisition_settings_dashboard} flex-fill`}
          >
            {/* body */}

            {tabActive === "hiringManagerDepartments" && (
              <RequisitionSettingsCard
                title={out("Département", "Hiring Manager Department")}
                saveItem={HMDPostMutation.mutate}
                updateItem={HMDPuttMutation.mutate}
                deleteItem={hMDDeleteMutation.mutate}
                setEditMode={setEditMode}
                editMode={editMode}
                deleteMode={deleteMode}
                setDeleteMode={setDeleteMode}
                refreshInputs={refreshInputs}
                setRefreshInputs={setRefreshInputs}
                showUpdateLoader={showUpdateLoader}
                setUpdateLoader={setUpdateLoader}
                showSaveLoader={showHMDSaveLoader}
                setSaveLoader={setShowHMDSaveLoader}
                data={hiringManagerDepartments}
                isError={hiringManagerDepartmentIsError}
                isLoading={hiringManagerDepartmentIsLoading}
              />
            )}
            {tabActive === "hiretypes" && (
              <RequisitionSettingsCard
                title={out("Type d'embauche", "Hire Type")}
                saveItem={hireTypesPostMutation.mutate}
                updateItem={hireTypesPutMutation.mutate}
                deleteItem={hireTypesDeleteMutation.mutate}
                setEditMode={setEditMode}
                editMode={editMode}
                deleteMode={deleteMode}
                setDeleteMode={setDeleteMode}
                refreshInputs={refreshInputs}
                setRefreshInputs={setRefreshInputs}
                showUpdateLoader={showUpdateLoader}
                setUpdateLoader={setUpdateLoader}
                showSaveLoader={showHireTypesSaveLoader}
                setSaveLoader={setShowHireTypesSaveLoader}
                data={hireTypes}
                isError={hireTypesIsError}
                isLoading={hireTypesIsLoading}
              />
            )}
            {tabActive === "groups" && (
              <RequisitionSettingsCard
                title={out("Groupe de réquisition", "Requisition Group")}
                saveItem={groupsPostMutation.mutate}
                updateItem={groupsPutMutation.mutate}
                deleteItem={groupsDeleteMutation.mutate}
                setEditMode={setEditMode}
                editMode={editMode}
                deleteMode={deleteMode}
                setDeleteMode={setDeleteMode}
                refreshInputs={refreshInputs}
                setRefreshInputs={setRefreshInputs}
                showUpdateLoader={showUpdateLoader}
                setUpdateLoader={setUpdateLoader}
                showSaveLoader={showGroupsSaveLoader}
                setSaveLoader={setShowGroupsSaveLoader}
                data={requisitionGroups}
                isError={requisitionGroupsIsError}
                isLoading={requisitionGroupsIsLoading}
              />
            )}
            {tabActive === "reviewersList" && (
              <RequisitionSettingsCard
                rolesList={rolesList}
                title={out("Évaluateur de réquisition", "Requisition Reviewer")}
                saveItem={reviewersPostMutation.mutate}
                deleteItem={reviewersDeleteMutation.mutate}
                deleteMode={deleteMode}
                setDeleteMode={setDeleteMode}
                saveMode={saveMode}
                setSaveMode={setSaveMode}
                list={accountMembersList}
                data={requisitionReviewers}
                isError={requisitionReviewersIsError}
                isLoading={requisitionReviewersIsLoading}
              />
            )}
          </Container>
        </div>
      </div>
    </div>
  );
};

export default RequisitionSettingsPage;
