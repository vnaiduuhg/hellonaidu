import { useHistory, useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import requisitionWizardSlice from "../store/requisitionWizardSlice";

export const RequisitionWizardPage = ({ id, requisition, children }) => {
  const history = useHistory();
  const params = useParams();
  const dispatch = useDispatch();

  const { id: currentId } = useSelector((state) => state.requisitionWizard);

  if (!id || !requisition) {
    history.push("/requisition/create");
  }

  // if the user changes id manually, switch the current requisition to keep the
  // sidebar in-sync should user to go /create route where the current id
  // is not recorded in url
  if (params.id !== currentId) {
    dispatch(
      requisitionWizardSlice.actions.switchCurrentRequisition({
        id: params.id,
      }),
    );
  }

  return children;
};
