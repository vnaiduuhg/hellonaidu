import { useTranslation } from "global/utils/useTranslation";
import React, { useCallback, useEffect } from "react";
import { useHistory } from "react-router-dom";
import RequisitionDashboard from "../components/RequisitionDashboard";

const RequisitionDashboardPage = () => {
  const history = useHistory();

  const { out } = useTranslation();
  const translatedTitle = out("Planification", "Planning");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const createRequisition = useCallback(
    () => history.push("/requisition/create"),
    [history],
  );

  return <RequisitionDashboard createRequisition={createRequisition} />;
};

export default RequisitionDashboardPage;
