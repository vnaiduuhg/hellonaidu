import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import RequisitionNavbar from "../components/requisition-wizard/RequisitionSidebar";
import { getHiringManagerDepartmentByAccount } from "../api/hiringManagerDepartmentApi";
import { getRequisitionGroupsByAccount } from "../api/requisitionGroupApi";
import { getRequisitionReviewerByAccount } from "../api/requisitionReviewerApi";
import { getRequisitionHireTypesByAccount } from "../api/requisitionHireTypeApi";
import useAtlasQuery from "global/utils/useAtlasQuery";
import { requisitionWizardSteps } from "../components/requisition-wizard/requisitionWizardSteps";
import { getBenefitsByAccount } from "employer/jobs/api/benefitApi";
import { getSkillsByAccount } from "employer/jobs/api/skillsApi";
import { getSalaries } from "employer/jobs/api/salaryApi";
import { getShifts } from "employer/jobs/api/shiftsApi";
import { Route, Switch } from "react-router";
import DefineJob from "../components/requisition-wizard/DefineJob";
import { RequisitionWizardPage } from "./RequisitionWizardPage";

import styles from "./RequisitionWizardPages.module.css";

const RequisitionWizardPages = () => {
  const user = useSelector((state) => state.user.data);
  const { version, id, requisitionsInProgress } = useSelector(
    (state) => state.requisitionWizard,
  );

  useEffect(() => {
    // listen to fwd/back btn
    const confirmRefreshWhenFormDirty = (event) => {
      const e = event || window.event;
      // Cancel the event
      e.preventDefault();

      if (e) {
        e.returnValue = ""; // Legacy method for cross browser support
      }

      return ""; // Legacy method for cross browser support
    };

    window.addEventListener("beforeunload", confirmRefreshWhenFormDirty);

    return () =>
      window.removeEventListener("beforeunload", confirmRefreshWhenFormDirty);
  }, []);

  const { data: hiringManagerDepartments = null } = useAtlasQuery(
    "hiring-manager-departments:by-account",
    () => getHiringManagerDepartmentByAccount(user.user_account.account_id),
  );

  const { data: requisitionGroups = null } = useAtlasQuery(
    "requisition-groups:by-account",
    () => getRequisitionGroupsByAccount(user.user_account.account_id),
  );

  const { data: requisitionReviewers = null } = useAtlasQuery(
    "requisition-reviewers:by-account",
    () => getRequisitionReviewerByAccount(user.user_account.account_id),
  );

  const { data: hireTypes = null } = useAtlasQuery(
    "requisition-hire-types:by-account",
    () => getRequisitionHireTypesByAccount(user.user_account.account_id),
  );

  const { data: benefits = null } = useAtlasQuery(
    "benefits:by-account",
    getBenefitsByAccount,
  );

  const { data: skills = null } = useAtlasQuery(
    "skills:by-account",
    getSkillsByAccount,
  );

  const { data: salaries = null } = useAtlasQuery("salaries", getSalaries);

  const { data: shifts = null } = useAtlasQuery("shifts", getShifts);

  const requisition = requisitionsInProgress[id];

  const pageProps = {
    version,
    id,

    requisition,

    requisitionGroups,
    hiringManagerDepartments,
    requisitionReviewers,
    hireTypes,
    benefits,
    skills,
    salaries,
    shifts,
  };

  const wizardPages = requisitionWizardSteps.map(
    (step, i) =>
      i > 0 && (
        <Route
          path={`/requisition/:operation(edit|clone|create)/:id/${step.name}`}
          key={`/requisition/:operation(edit|clone|create)/:id/${step.name}`}
          exact
        >
          <RequisitionWizardPage id={id} requisition={requisition}>
            <step.component {...pageProps} />
          </RequisitionWizardPage>
        </Route>
      ),
  );

  return (
    <div className="page-wrapper-internal-page">
      <div className="sidebar-container">
        <RequisitionNavbar />
      </div>

      <div className="content-container" id={styles.content}>
        <div className="p-0 ms-4 mt-3 me-3">
          <Switch>
            <Route path={`/requisition/create`} exact>
              <DefineJob />
            </Route>

            {wizardPages}
          </Switch>
        </div>
      </div>
    </div>
  );
};

export default RequisitionWizardPages;
