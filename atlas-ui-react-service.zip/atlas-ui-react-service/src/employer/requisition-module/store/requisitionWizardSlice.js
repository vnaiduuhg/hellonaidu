import { createSlice } from "@reduxjs/toolkit";
import { getRequisition } from "employer/requisition-module/api/requisitionApi";
import { getJobById } from "employer/jobs/api/jobApi";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";
import { out } from "global/utils/useTranslation";
import { convertJobDatatoRequisition } from "../utils/convertJobDatatoRequisition";
import { requisitionWizardSteps } from "../components/requisition-wizard/requisitionWizardSteps";
import store from "global/store/store";
// import _starterReq from "./_starter-req";

const requisitionWizardSlice = createSlice({
  name: "requisitionWizard",

  initialState: {
    requisitionsInProgress: {},

    // current requisition (in progress)
    id: null,

    /** mode: create | update | clone */
    mode: null,

    /**
     * does the id refer to requisition_id or local id:
     * local (unsaved) |  server (saved)
     */
    storage: null,

    step: 0,
    completed: 0,
  },

  reducers: {
    resetCurrentRequisition(state) {
      return {
        ...state,
        id: null,
        mode: "create",
        step: 0,
        completed: 0,
      };
    },

    switchCurrentRequisition(state, { payload: { id } }) {
      return {
        ...state,
        id,
      };
    },

    createNew(state, { payload: { id } }) {
      return {
        ...state,
        id,
        mode: "create",
        storage: "local",
        step: 1,
        completed: 1,

        requisitionsInProgress: {
          ...state.requisitionsInProgress,
          [id]: {
            id,
            storage: "local",
            mode: "create",
            step: 1,
            completed: 1,
            created: Date.now(),
            lastUpdated: Date.now(),

            // TODO: remove before pushing
            // ..._starterReq,
          },
        },
      };
    },

    createFromExisting(
      state,
      {
        payload: {
          from,
          requisition,
          id,
          storage,
          mode = "create",

          // TODO: set by the validator to furthest page validated.
          // set setp to the same value (-1) as well or show preview
          // if all valid
          completed = 2,
        },
      },
    ) {
      return {
        ...state,
        id,
        mode,
        storage,
        step: 1,
        completed,

        requisitionsInProgress: {
          ...state.requisitionsInProgress,
          [id]: {
            id,
            from,
            mode,
            completed,
            created: Date.now(),
            lastUpdated: Date.now(),

            ...requisition,
          },
        },
      };
    },

    saveDataInStep(state, { payload }) {
      const { id, data, nextStepName } = payload;

      const stepIndex = requisitionWizardSteps.findIndex(
        (s) => s.name === nextStepName,
      );
      // furthest validated step
      // const completed =
      //   state.completed < stepIndex ? stepIndex : state.completed;

      const completed =
        state.requisitionsInProgress[id].completed < stepIndex
          ? stepIndex
          : state.requisitionsInProgress[id].completed;

      // return state;

      const newState = {
        ...state,
        completed,

        requisitionsInProgress: {
          ...state.requisitionsInProgress,
          [state.id]: {
            ...state.requisitionsInProgress[state.id],
            ...data,
            completed,
            lastUpdated: Date.now(),
          },
        },
      };

      return newState;
    },

    deleteOldRequisitions(state, { payload: { timestamp, dry = false } }) {
      const cleansedList = Object.keys(state.requisitionsInProgress).reduce(
        (total, key) => {
          const lastUpdate = state.requisitionsInProgress[key].lastUpdated ?? 0;

          if (new Date(timestamp) < new Date(lastUpdate)) {
            total = { ...total, [key]: state.requisitionsInProgress[key] };
          }

          return total;
        },
        {},
      );

      return {
        ...state,
        requisitionsInProgress: cleansedList,
      };
    },
  },

  extraReducers: {},
});

export default requisitionWizardSlice;

export const createRequisitionTemplateFromJob = (jobId, redirect) => {
  return async (dispatch, getState) => {
    const token = getState().user.token;

    if (!token && process.env.NODE_ENV === "production") {
      // page should handle showing components that are restricted
      return Promise.reject("unauthenticated");
    }

    try {
      dispatch(showLoadingBarWithoutMessage(200000));

      const job = await getJobById(jobId);

      job.requisition = job.requisition ?? { id: null };
      const originalRequisitionId = job?.requisition?.id ?? null;
      const requisition = convertJobDatatoRequisition(job);
      requisition.requisition.job_id = job.id;

      dispatch(statusMessagesSlice.actions.clearLoaders());
      const id = "job." + job.id;

      dispatch(
        requisitionWizardSlice.actions.createFromExisting({
          id,
          from: "job",
          originalRequisitionId,
          requisition,
          storage: "local",
          mode: "create",
          step: 0,
          completed: 1,
        }),
      );
      redirect(`/requisition/create/${id}/info`);
    } catch (e) {
      dispatch(statusMessagesSlice.actions.clearLoaders());

      // TODO: replace with proper error messages (default to messages
      // returned from backend if it contains any)
      dispatch(
        showMessage(
          "error",
          out("", "Failed to Load"),
          out("", "Failed to load job. Please check your connection."),
          3200,
        ),
      );
    }
  };
};

// TODO: once converter is fully functional
export const cloneRequisition = (requisitionId, redirectTo) => {
  return async (dispatch, getState) => {
    const token = getState().user.token;

    if (!token && process.env.NODE_ENV === "production") {
      // page should handle showing components that are restricted
      return Promise.reject("unauthenticated");
    }

    try {
      dispatch(showLoadingBarWithoutMessage(200000));

      // Might need route optimizations to load all required fields in one
      // request.
      const requisitionResponse = await getRequisition(requisitionId);

      const job = {
        ...requisitionResponse.job,
        requisition: { ...requisitionResponse },
      };

      delete job.requisition.job;

      delete job.id;
      delete job.requisition.id;
      delete job.requisition.req_code;
      delete job.requisition.account_id;
      delete job.requisition.creator_user_id;
      delete job.requisition.status;
      delete job.requisition.status_id;
      delete job.requisition.created_at;
      delete job.requisition.updated_at;
      delete job.requisition.deleted_at;

      // TODO: find out if you have to delete title as well when cloning

      const requisition = convertJobDatatoRequisition(job);

      // for convenience modify job titles
      if (requisition.translations?.en?.title)
        requisition.translations.en.title = `Copy of ${requisition.translations.en.title.trim()}`;

      if (requisition.translations?.fr?.title)
        requisition.translations.fr.title = `Copie de ${requisition.translations.fr.title.trim()}`;

      dispatch(statusMessagesSlice.actions.clearLoaders());
      const id = `c.${requisitionId}`;
      dispatch(
        requisitionWizardSlice.actions.createFromExisting({
          id,
          storage: "local",
          mode: "clone",
          originalRequisitionId: requisitionId,
          from: "requisition",
          step: 0,
          completed: 0,

          requisition,
        }),
      );

      redirectTo(`/requisition/clone/${id}/info`);
    } catch (e) {
      console.error(e);
      dispatch(statusMessagesSlice.actions.clearLoaders());

      // TODO: replace with proper error messages (default to messages
      // returned from backend if it contains any)
      dispatch(
        showMessage(
          "error",
          out("Error", "Error"),
          out(
            "Désolé, une erreur s'est produite lors d'enregistrement du requisition. Veuillez contacter support@workland.com pour plus d'aide.",
            "Sorry, there was an error while saving the requisition. Please contact our support team at support@workland.com for further assistance.",
          ),
          3200,
        ),
      );
    }
  };
};

// TODO: once converter is fully functional
export const updateRequisition = (requisitionId, redirectTo) => {
  return async (dispatch, getState) => {
    const token = getState().user.token;

    if (!token && process.env.NODE_ENV === "production") {
      // page should handle showing components that are restricted
      return Promise.reject("unauthenticated");
    }

    try {
      dispatch(showLoadingBarWithoutMessage(30000));

      // Might need route optimizations to load all required fields in one
      // request.
      const requisitionResponse = await getRequisition(requisitionId);

      const job = {
        ...requisitionResponse.job,
        requisition: { ...requisitionResponse },
      };

      delete job.requisition.job;

      const requisition = convertJobDatatoRequisition(job);

      dispatch(statusMessagesSlice.actions.clearLoaders());
      dispatch(
        requisitionWizardSlice.actions.createFromExisting({
          from: "requisition",
          requisition,
          id: requisitionId,
          storage: "live",
          mode: "edit",
          step: 0,
          completed: 0,
        }),
      );

      redirectTo(`/requisition/edit/${requisitionId}/info`);
    } catch (e) {
      console.error(e);
      dispatch(statusMessagesSlice.actions.clearLoaders());

      // TODO: replace with proper error messages (default to messages
      // returned from backend if it contains any)
      dispatch(
        showMessage(
          "error",
          out("Erreur", "Error"),
          out(
            "Désolé, une erreur s'est produite lors d'enregistrement du requisition. Veuillez contacter support@workland.com pour plus d'aide.",
            "Sorry, there was an error while saving the requisition. Please contact our support team at support@workland.com for further assistance.",
          ),
          3200,
        ),
      );
    }
  };
};

// clear outdated requisitions from storage
setTimeout(() => {
  store.dispatch(
    requisitionWizardSlice.actions.deleteOldRequisitions({
      timestamp: Date.now() - 7 * 24 * 3600 * 1000,
      dry: true,
    }),
  );
}, 10000);
