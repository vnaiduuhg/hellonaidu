import React, { useState, useEffect, useRef } from "react";
import { useTranslation } from "global/utils/useTranslation";
import { RECRUITER } from "global/constants/accountsConstants";
import { Button } from "react-bootstrap";
import { AtlasSelect } from "global/components/select/atlas-select";
import { sanitize } from "dompurify";
import { languages } from "global/constants/languages";
import { AtlasAlert } from "global/components/atlas-alert";
import style from "../assets/NotificationModal.module.css";

const Notification = ({
  user,
  template,
  isEmailEnabled,
  templatesList,
  updateTemplate,
  updateTemplateStatus,
  templateListHasError,
  editNotificationSettingsHasError,
}) => {
  const { out } = useTranslation();
  const templateSelected = useRef();
  const [displayedTemplate, setDisplayedTemplate] = useState();
  const [isEmailEnabledFilter, setIsEmailEnabledFilter] =
    useState(isEmailEnabled);

  useEffect(() => {
    if (templateSelected?.current) templateSelected.current.value = 0;
    setIsEmailEnabledFilter(isEmailEnabled);
    if (template && template.id) {
      setDisplayedTemplate(template);
    }
  }, [template, isEmailEnabled, editNotificationSettingsHasError]);

  return (
    <div className="fs-mini-header">
      <div className="ps-3 pb-2 fs-5">
        {out("Message automatisé envoyé par", "Automated message sent by")}:
      </div>
      <div className={style.notificationHeader}>
        <div className={`${style.switchDiv} form-check form-switch`}>
          <input
            type="checkbox"
            checked={isEmailEnabledFilter === 1}
            disabled={user.user_account.role_id === 20}
            className="form-check-input me-2"
            onChange={({ target: { checked } }) => {
              const value = +checked;
              setIsEmailEnabledFilter(value);
              updateTemplateStatus(value);
            }}
          />

          <label className="form-check-label">
            {out("Courriel", "Email")}

            {isEmailEnabledFilter === 0 && (
              <span className="ms-3 text-muted">
                {out("désactivé", "disabled")}
              </span>
            )}
          </label>
        </div>
      </div>

      <div className={style.notificationActionContainer}>
        {!templateListHasError && user.user_account.role_id !== RECRUITER && (
          <>
            <div>
              <AtlasSelect
                className="w-100"
                onChange={({ value }) => {
                  if (Number.isInteger(+value)) {
                    const newTemplate = templatesList.find(
                      (item) => +item.id === +value,
                    );
                    if (newTemplate) setDisplayedTemplate(newTemplate);
                  } else {
                    setDisplayedTemplate(template);
                  }
                }}
                value={
                  displayedTemplate
                    ? {
                        value: displayedTemplate.id,
                        label: (() => {
                          const template = templatesList.find(
                            (item) => +item.id === +displayedTemplate.id,
                          );

                          if (!template) return null;

                          return out(
                            template.translations[1].name +
                              (!template.account_id
                                ? " (Workland défaut)"
                                : ""),
                            template.translations[0].name +
                              (!template.account_id
                                ? " (Workland default)"
                                : ""),
                          );
                        })(),
                      }
                    : null
                }
                placeholder={out(
                  "Veuillez sélectionner un modèle",
                  "Please select a template",
                )}
                options={templatesList.map((template) => ({
                  value: template.id,
                  label: out(
                    template.translations[1].name +
                      (!template.account_id ? " (Workland défaut)" : ""),
                    template.translations[0].name +
                      (!template.account_id ? " (Workland default)" : ""),
                  ),
                }))}
              />
            </div>

            <div>
              <Button
                variant="secondary"
                disabled={
                  !displayedTemplate || +displayedTemplate.id === +template.id
                }
                onClick={() => updateTemplate(displayedTemplate.id)}
              >
                {out("Modifier le modèle", "Update template")}
              </Button>
            </div>
          </>
        )}
        {templateListHasError && (
          <AtlasAlert variant="error">
            {out(
              "La liste des messages automatisés n'est actuellement pas disponible",
              "The automated messages list is currently unavailable",
            )}
          </AtlasAlert>
        )}
      </div>

      <div className="mx-2 d-flex flex-column flex-lg-row">
        {displayedTemplate &&
          displayedTemplate.translations.map(
            ({ id, locale, subject, body }) => (
              <div
                key={id}
                className="d-flex flex-column overflow-auto mx-2 w-100 w-lg-50 mb-4 mb-md-2"
              >
                <div>{out(languages[locale].fr, languages[locale].en)}:</div>
                <div
                  className={`rounded overflow-auto p-3 flex-fill ${style.border}`}
                >
                  <div>
                    <div>
                      <div className="text-highlight">
                        {out("Sujet:", "Subject")}:
                      </div>
                      <div>{sanitize(subject)}</div>
                    </div>
                  </div>
                  <hr />
                  <div
                    dangerouslySetInnerHTML={{
                      __html: sanitize(body),
                    }}
                  ></div>
                </div>
              </div>
            ),
          )}
      </div>
    </div>
  );
};

export default Notification;
