import React from "react";
import Notification from "./Notification";
import { useTranslation } from "global/utils/useTranslation";
import { Button, Modal } from "react-bootstrap";
import style from "../assets/NotificationModal.module.css";

const NotificationModal = ({
  user,
  event,
  eTemplatesList,
  eTemplateListHasError,
  setNotificationSettingsModalOpen,
  createNotificationSettings,
  updateNotificationSettings,
  editNotificationSettingsHasError,
  notificationSettingOn,
  setNotificationSettingOn,
  // smsTemplatesList,
  // smsTemplateListHasError,
}) => {
  const { out } = useTranslation();

  const setNotificationSettingsPayload = (type, value) => {
    const data = {
      notification_id: event.notification_id,
      account_type: event.account_type,
      email_provider: event.email_provider,
    };

    if (type.match(/email/g)) {
      if (type.match(/template/g)) {
        data.email_template_id = value;
        data.is_email_enabled = Number.isInteger(event.is_email_enabled)
          ? event.is_email_enabled
          : 1;
      } else {
        data.is_email_enabled = value;
        data.email_template_id = event.email_template_id;
      }
      data.is_sms_enabled = Number.isInteger(event.is_sms_enabled)
        ? event.is_sms_enabled
        : 0;
      if (data.is_sms_enabled > 0) data.sms_template_id = event.sms_template_id;
    } else if (type.match(/sms/g)) {
      if (type.match(/template/g)) {
        data.sms_template_id = value;
        data.is_sms_enabled = Number.isInteger(event.is_sms_enabled)
          ? event.is_sms_enabled
          : 1;
      } else {
        data.is_sms_enabled = value;
        data.sms_template_id = event.sms_template_id;
      }
      data.is_email_enabled = Number.isInteger(event.is_email_enabled)
        ? event.is_email_enabled
        : 0;
      if (data.is_email_enabled > 0)
        data.email_template_id = event.email_template_id;
    }

    return data;
  };

  return (
    <Modal show onHide={() => setNotificationSettingsModalOpen(0)} size="xl">
      <Modal.Header closeButton>
        <Modal.Title>
          {out(
            event.notification.translations[1].name,
            event.notification.translations[0].name,
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {event.email_template && (
          <Notification
            user={user}
            // notification={event.notification}
            template={event.email_template}
            isEmailEnabled={event.is_email_enabled}
            templatesList={eTemplatesList}
            templateListHasError={eTemplateListHasError}
            updateTemplate={(id) => {
              if (!notificationSettingOn) {
                setNotificationSettingOn(true);
                setNotificationSettingsModalOpen(event.notification_id);
                const data = setNotificationSettingsPayload(
                  "email-template",
                  id,
                );
                if (!event.account_id) {
                  createNotificationSettings(data);
                } else {
                  updateNotificationSettings({ id: event.id, data: data });
                }
              }
            }}
            updateTemplateStatus={(value) => {
              if (!notificationSettingOn) {
                setNotificationSettingOn(true);
                setNotificationSettingsModalOpen(event.notification_id);
                const data = setNotificationSettingsPayload(
                  "email-status",
                  value,
                );
                if (!event.account_id) {
                  createNotificationSettings(data);
                } else {
                  updateNotificationSettings({ id: event.id, data: data });
                }
              }
            }}
            editNotificationSettingsHasError={editNotificationSettingsHasError}
          />
        )}
        {/* @std by when sms will be available
            {event.sms_template &&
              <Notification
                notification={event.notification}
                template={event.sms_template}
                isEnabled={event.is_sms_enabled}
                templatesList={smsTemplatesList}
                templateListHasError={smsTemplateListHasError}
                updateTemplate={(id) => {
                  setNotificationSettingsModalOpen(event.notification_id);
                  const data = setNotificationSettingsPayload("sms-template", id);
                  if (!event.account_id) {
                    createNotificationSettings(data);
                  } else {
                    updateNotificationSettings({id: event.id, data: data});
                  }
                }}
              />
            } */}
      </Modal.Body>

      <Modal.Footer className="mx-4">
        <Button
          variant="alt-secondary"
          onClick={() => setNotificationSettingsModalOpen(0)}
        >
          {out("Fermer", "Close")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default NotificationModal;
