import React from "react";
import NotificationModal from "./NotificationModal";
import { useTranslation } from "global/utils/useTranslation";
import style from ".././assets/AutomatedMessagesPage.module.css";
import { Col } from "react-bootstrap";

const EventNotificationsCard = ({
  user,
  event,
  eTemplatesList,
  eTemplateListHasError,
  notificationSettingsModalOpen,
  setNotificationSettingsModalOpen,
  createNotificationSettings,
  updateNotificationSettings,
  editNotificationSettingsHasError,
  notificationSettingOn,
  setNotificationSettingOn,
  // smsTemplatesList,
  // smsTemplateListHasError,
}) => {
  const { out } = useTranslation();

  return (
    <>
      <Col xs={12} md={6}>
        <div
          className={`${style.eventNotificationsCard} ${
            !event.is_email_enabled && !event.is_sms_enabled
              ? style.allNotificationsDisabled
              : ""
          }`}
        >
          <div className={style.cardEventDiv}>
            <h3
              className={`${
                !event.is_sms_enabled && !event.is_email_enabled
                  ? "text-muted"
                  : ""
              }`}
            >
              {out(
                event.notification.translations[1].name,
                event.notification.translations[0].name,
              )}
            </h3>

            <button
              className="btn btn-frameless-icon btn-secondary"
              onClick={() => {
                setNotificationSettingsModalOpen(event.notification_id);
              }}
            >
              <i className="fa fa-edit" aria-hidden="true" />
            </button>
          </div>
          <div
            className={`${style.statusDiv} ${
              !event.is_email_enabled ? style.notificationDisabled : ""
            }`}
          >
            {!!event.is_email_enabled && (
              <span className={style.iconEnabled}>
                <i className="fa fa-check" />
              </span>
            )}
            {out("Message courriel", "Email message")}
          </div>
          {/* @std by when sms will be implemented
            <span
              className={`${
                !event.is_sms_enabled ? style.notificationDisabled : ""
              }`}
            >
              {out("Message text", "Sms message")}
            </span>
          */}
        </div>
      </Col>
      {+notificationSettingsModalOpen === +event.notification_id && (
        <NotificationModal
          user={user}
          event={event}
          eTemplatesList={eTemplatesList}
          eTemplateListHasError={eTemplateListHasError}
          notificationSettingsModalOpen={notificationSettingsModalOpen}
          setNotificationSettingsModalOpen={setNotificationSettingsModalOpen}
          notificationSettingOn={notificationSettingOn}
          setNotificationSettingOn={setNotificationSettingOn}
          createNotificationSettings={createNotificationSettings}
          updateNotificationSettings={updateNotificationSettings}
          editNotificationSettingsHasError={editNotificationSettingsHasError}
          // smsTemplatesList={smsTemplatesList}
          // smsTemplateListHasError={smsTemplateListHasError}
        />
      )}
    </>
  );
};

export default EventNotificationsCard;
