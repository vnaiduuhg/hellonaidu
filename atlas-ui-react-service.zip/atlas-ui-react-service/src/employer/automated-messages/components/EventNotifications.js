import React from "react";
import EventNotificationsCard from "./EventNotificationsCard";
import { useTranslation } from "global/utils/useTranslation";
import style from ".././assets/AutomatedMessagesPage.module.css";
import { Row } from "react-bootstrap";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

const EventNotifications = ({
  user,
  events,
  isLoading,
  hasError,
  eTemplatesList,
  eTemplatesListIsLoading,
  eTemplateListHasError,
  notificationSettingsModalOpen,
  setNotificationSettingsModalOpen,
  createNotificationSettings,
  updateNotificationSettings,
  editNotificationSettingsHasError,
  notificationSettingOn,
  setNotificationSettingOn,
  // smsTemplatesList,
  // smsTemplatesListIsLoading,
  // smsTemplateListHasError,
}) => {
  const { out } = useTranslation();

  // isLoading = true;

  return (
    <div className="pt-4">
      <Row className="gy-4 gx-5">
        {!isLoading &&
          !eTemplatesListIsLoading &&
          events.length > 0 &&
          events.map((event) => {
            return (
              <EventNotificationsCard
                key={event.id}
                user={user}
                event={event}
                eTemplatesList={eTemplatesList}
                eTemplateListHasError={eTemplateListHasError}
                notificationSettingsModalOpen={notificationSettingsModalOpen}
                notificationSettingOn={notificationSettingOn}
                setNotificationSettingOn={setNotificationSettingOn}
                setNotificationSettingsModalOpen={
                  setNotificationSettingsModalOpen
                }
                createNotificationSettings={createNotificationSettings}
                updateNotificationSettings={updateNotificationSettings}
                editNotificationSettingsHasError={
                  editNotificationSettingsHasError
                }
                // smsTemplatesList={smsTemplatesList}
                // smsTemplateListHasError={smsTemplateListHasError}
              />
            );
          })}
      </Row>

      {(isLoading || eTemplatesListIsLoading) && (
        <div className={style.eventNotificationsLoader}>
          <NestedPageLoader
            message={out(
              "Nous téléchargeons vos messages automatisés ",
              "Loading your automated messages",
            )}
          />
        </div>
      )}

      {!isLoading &&
        !eTemplatesListIsLoading &&
        (hasError || events.length < 1) && (
          <AtlasAlert variant="error">
            {out(
              "La liste des messages automatisés n'est actuellement pas disponible",
              "The automated messages list is currently unavailable",
            )}
          </AtlasAlert>
        )}
    </div>
  );
};

export default EventNotifications;
