import React from "react";
import { Route, Switch } from "react-router-dom";
import AutomatedMessagesPage from "./AutomatedMessagesPage";

const AutomatedMessagesRoutes = () => (
  <Switch>
    <Route path="/automated-messages" exact={true}>
      <AutomatedMessagesPage />
    </Route>
  </Switch>
);

export default AutomatedMessagesRoutes;
