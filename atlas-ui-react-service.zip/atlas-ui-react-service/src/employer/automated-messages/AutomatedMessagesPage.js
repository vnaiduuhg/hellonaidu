import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import EventNotifications from "./components/EventNotifications";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import {
  getEventNotificationsMsgHandler,
  createOrUpdateNSMsgHandler,
} from "./utils/AutoMessagesMsgHandler";
import {
  getEventNotificationsList,
  getTemplatesList,
  createNotificationSettingsApi,
  updateNotificationSettingsApi,
} from "./apis/AutomatedMsgApis";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";
import { Container } from "react-bootstrap";
import { PaginationBar } from "global/components/pagination/pagination-bar";
import { useTranslation } from "global/utils/useTranslation";

const PAGE_SIZE_OPTIONS = [10, 20, 30, 40, 50, 75, 100];
const DEFAULT_PAGE_SIZE = 10;

const AutomatedMessagesPage = () => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const user = useSelector((state) => state.user.data);
  const [currentPage, setCurrentPage] = useState(1);
  const maxPages = useRef(1);
  const [notificationSettingsModalOpen, setNotificationSettingsModalOpen] =
    useState(0);
  const [notificationSettingOn, setNotificationSettingOn] = useState(false);
  const { paginationItemsPerPage } = useSelector((state) => state.settings);

  const translatedTitle = out("Messages automatisés", "Automated messages");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const currentPageSize =
    paginationItemsPerPage?.automatedMessages ?? DEFAULT_PAGE_SIZE;

  // Gets event-notifications list
  const {
    data: eventNotifications,
    isError: eventNotificationsError,
    isLoading: eventNotificationsIsLoading,
  } = useQuery(
    ["notification-settings", { page: currentPage, pageSize: currentPageSize }],
    (e) =>
      getEventNotificationsList(
        user.user_account.account_id,
        `?page=${e.queryKey[1].page}&page_size=${e.queryKey[1].pageSize}&sort_by=notification_id`,
      ),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
      onSuccess: (response) => {
        maxPages.current = response?.last_page ?? 1;
        setNotificationSettingOn(false);
      },
      onError: (e) => {
        const msg = getEventNotificationsMsgHandler(
          e.response?.status ? e.response.status : 500,
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setNotificationSettingOn(false);
      },
    },
  );

  // Gets templates list
  const {
    data: eTemplatesList = [],
    isError: eTemplatesListError,
    isLoading: eTemplatesListIsLoading,
  } = useQuery(
    "email-templates",
    () => getTemplatesList(user.user_account.account_id, "?with_defaults=1"),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
      onSuccess: () => {},
      onError: () => {},
    },
  );

  // Create notification-settings
  const createNotificationSettings = useMutation(
    (data) => createNotificationSettingsApi(data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("notification-settings");
        const msg = createOrUpdateNSMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        queryClient.invalidateQueries("notification-settings");
        const msg = createOrUpdateNSMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Update notification-settings
  const updateNotificationSettings = useMutation(
    (data) => updateNotificationSettingsApi(data.id, data.data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("notification-settings");
        const msg = createOrUpdateNSMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        queryClient.invalidateQueries("notification-settings");
        const msg = createOrUpdateNSMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  useEffect(() => {
    queryClient.invalidateQueries("notification-settings");
  }, [queryClient]);

  return (
    <div>
      <PageHeaderPanel
        title={out("Messages automatisés", "Automated messages")}
        subtitle={out(
          "Ici vous pouvez personnaliser vos messages automatisés en configurant des notifications pour les événements",
          "Here you can personalise your automated messages by setting up notifications for events",
        )}
        // TODO: switch to Bootstrap bell icon (not compatible w/ header panel)
        iconClass="fa fa-bell"
      />

      <Container>
        <EventNotifications
          user={user}
          events={eventNotifications?.data ?? []}
          isLoading={eventNotificationsIsLoading}
          hasError={eventNotificationsError}
          eTemplatesList={eTemplatesList}
          eTemplatesListIsLoading={eTemplatesListIsLoading}
          eTemplateListHasError={eTemplatesListError}
          notificationSettingsModalOpen={notificationSettingsModalOpen}
          setNotificationSettingsModalOpen={setNotificationSettingsModalOpen}
          notificationSettingOn={notificationSettingOn}
          setNotificationSettingOn={setNotificationSettingOn}
          createNotificationSettings={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            createNotificationSettings.mutate(e);
          }}
          updateNotificationSettings={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            updateNotificationSettings.mutate(e);
          }}
          editNotificationSettingsHasError={
            updateNotificationSettings.isError ||
            createNotificationSettings.isError
          }
          // smsTemplatesList={smsTemplatesList}
          // smsTemplatesListIsLoading={smsTemplatesListIsLoading}
          // smsTemplateListHasError={smsTemplateListHasError}
        />

        <PaginationBar
          className="mt-4 pe-1"
          active={currentPage}
          pages={maxPages.current}
          paginationKey="automatedMessages"
          onPageChange={(_, newPageNum) => {
            if (newPageNum) {
              setCurrentPage(newPageNum);
              queryClient.invalidateQueries("notification-settings");
            }
          }}
          onDisplayPerPageChange={() => setCurrentPage(1)}
          pageSizeOptions={PAGE_SIZE_OPTIONS}
        />
      </Container>
    </div>
  );
};

export default AutomatedMessagesPage;
