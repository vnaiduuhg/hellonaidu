import {
  getRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getEventNotificationsList = async (accountId, urlParams = "") => {
  const reponse = await getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/notification-settings${urlParams}`,
    getToken(),
  );

  return reponse;
};

export const getTemplatesList = async (accountId, urlParams = "") => {
  const reponse = await getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/email-templates${urlParams}`,
    getToken(),
  );

  return reponse;
};

export const createNotificationSettingsApi = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `notification-settings`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateNotificationSettingsApi = async (id, data) => {
  try {
    const reponse = await putRestrictedApi(
      serviceNames.messaging,
      `notification-settings`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
