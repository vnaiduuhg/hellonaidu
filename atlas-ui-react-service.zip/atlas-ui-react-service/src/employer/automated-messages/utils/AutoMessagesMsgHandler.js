import { out } from "global/utils/useTranslation";

const tokenExpiredMsg = {
  title: out("Votre session est expirée!", "Your session has expired!"),
  text: out("Veuillez vous connecter à nouveau", "Please login again"),
};

export const getEventNotificationsMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour consulter les messages automatisés",
        "You do not have the required permission to consult automated messages",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Les messages automatisés n'ont pu être récupérés",
        "Automated messages could not be retrieved",
      );
  }

  return msg;
};

export const createOrUpdateNSMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "La notification a été mise à jour avec succès!",
        "The notification has beed updated successfully!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour mettre à jour les notifications",
        "You do not have the required permission to update notifications",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La mise à jour de la notification a échouée, veuillez contacter support@workland.com si le problème persiste",
        "Notification update has failed, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};
