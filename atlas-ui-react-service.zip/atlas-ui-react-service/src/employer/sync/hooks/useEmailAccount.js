import { useEffect, useState } from "react";
import { SyncProvider } from "../utils/providers/SyncProvider";
import { useSyncedAccounts } from "./useSyncedAccounts";

// can be regular or automated email accounts. returns default provider or the
// one specified in argument
// FIXME: shouldn't be provider, it should be account provider & id or something
// to that effect for overridng default
// type can be regular or automated
export const useEmailAccount = (type, accountOveride) => {
  const [account, setAccount] = useState(undefined);
  const syncedAccounts = useSyncedAccounts();
  const { isFetched, isError, accounts, getDefault } = syncedAccounts;

  useEffect(() => {
    if (isFetched && !isError) {
      let accountToUse = null;

      if (accountOveride) {
        if (
          typeof accountOveride !== "object" ||
          !(accountOveride instanceof SyncProvider)
        ) {
          throw new Error(`Invalid account "${accountToUse}" for accounts`);
        }

        if (type !== accountOveride.type) {
          throw new Error(
            `Invalid account to use on this type "${type}." Account type is "${accountOveride.type}"`,
          );
        }

        accountToUse = accountOveride;
      } else {
        // find the default

        accountToUse = getDefault(type);

        // if no account is found, then there is no account synced for this type
        if (!accountToUse) {
          // this returns isFetched as true, but isError as false and accounts as null

          // This condition should only be true if there are no accounts synced
          setAccount(null);

          return;
        }
      }

      setAccount(accountToUse);
    }
  }, [accountOveride, accounts, getDefault, isError, isFetched, type]);

  return {
    ...syncedAccounts,
    isFetched: typeof account !== "undefined",
    isLoading: typeof account === "undefined",
    account,
  };
};
