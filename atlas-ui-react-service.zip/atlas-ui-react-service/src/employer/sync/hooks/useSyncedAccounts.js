import { useCallback, useEffect, useMemo } from "react";
import { Redirect } from "react-router-dom";
import { useQuery } from "react-query";
import { getCurrentUserEmailAccounts } from "global/apis/messagingApi";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { providersMap } from "../utils/providers/providersMap";

// all this is conjecture. Once synced and all the providers are done, the real
// overrarching design will reveal itself.

// this hook only exists to unify accounts and the selected preference
// and save it to a redux store
export const useSyncedAccounts = () => {
  const query = useQuery(
    "synced-accounts",
    getCurrentUserEmailAccounts,
    REACT_QUERY_GETTER_OPTIONS,
  );

  const { data: response, isError, error } = query;

  // TODO: remove this when no longer needed.
  useEffect(() => {
    if (isError && error.status === 401) {
      // Temporary angular consistent way of redirecting to login
      window.location = "/";
      return <Redirect to="/" />;
    }
  }, [isError, error]);

  const accounts = useMemo(() => {
    const instances = new Set();

    Object.keys(response ?? {}).forEach((typeKey) => {
      Object.keys(response[typeKey]).forEach((providerKey) => {
        if (!providersMap.has(providerKey)) {
          throw new Error(`Provider "${providerKey}" not supported`);
        }

        response[typeKey][providerKey].forEach((account) => {
          instances.add(new (providersMap.get(providerKey))(account, typeKey));
        });
      });
    });

    return instances;
  }, [response]);

  const accountTypes = useMemo(() => {
    return Object.keys(response ?? []);
  }, [response]);

  const getDefault = useCallback(
    (type) => {
      return (
        [...accounts.values()].find((i) => i.type === type && !!i.isDefault) ??
        null
      );
    },
    [accounts],
  );

  return {
    ...query,

    syncedAccounts: response,

    // instances of accounts. they have their provider specific features and
    // export a common interface between all providers
    accounts,

    accountTypes,

    getDefault,
  };
};
