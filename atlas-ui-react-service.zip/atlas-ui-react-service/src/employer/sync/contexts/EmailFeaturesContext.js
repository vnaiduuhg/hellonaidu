import { AtlasAlert } from "global/components/atlas-alert";
import { Unsynced } from "global/components/Unsynced/unsynced";
import { useTranslation } from "global/utils/useTranslation";
import { createContext } from "react";
import { Button } from "react-bootstrap";
import { Redirect, useHistory } from "react-router-dom";
import { EmailAccountsNotLoadedError } from "../errors/EmailAccountsNotLoadedError";
import { useEmailAccount } from "../hooks/useEmailAccount";
import { providersMap } from "../utils/providers/providersMap";

// initialize context w/ all possible keys but features not yet loaded
export const EmailFeaturesContext = createContext(
  [
    ...new Set(
      [...providersMap.keys()]
        .map((provider) => Object.keys(providersMap.get(provider)))
        .flat(),
    ).values(),
  ].reduce(
    (obj, key) => ({
      ...obj,
      [key]: () => {
        throw new EmailAccountsNotLoadedError();
      },
    }),
    {},
  ),
);

export const EmailFeaturesProvider = ({
  type,
  account: accountToUse,
  children,
}) => {
  const { account, isFetched, isError, error } = useEmailAccount(
    type,
    accountToUse,
  );
  const history = useHistory();
  const { out } = useTranslation();

  if (isError) {
    if (error.status === 401) {
      window.location = "/";
      return <Redirect to="/" />;
    } else if (error.status === 500 || !account) {
      return (
        <AtlasAlert variant="warning" className="mt-3">
          {out(
            "Les comptes de courriel sont temporairement indisponibles.",
            "Email accounts are temporarily unavailable.",
          )}
        </AtlasAlert>
      );
    }
  }

  if (isFetched && !isError && (!account || !account.isEnabled)) {
    return !!account && !account.isEnabled ? (
      <>
        <AtlasAlert variant="warning">
          {out(
            `${account.displayName} est synchronisé mais n'est pas actuellement en fonction. Veuillez vous assurer d'avoir un courriel régulier synchronisé, actif et défini par défaut.`,
            `${account.displayName} is synced but not currently running. Please make sure you have a regular email synced, active and set as default.`,
          )}
        </AtlasAlert>

        <div className="text-center">
          <Button
            variant="secondary"
            size="lg"
            // id={styles.syncButton}
            onClick={() => history.push("/sync")}
          >
            {out("Synchroniser", "Sync Email")}
          </Button>
        </div>
      </>
    ) : (
      <Unsynced />
    );
  }

  return (
    <EmailFeaturesContext.Provider value={{ account }}>
      {children}
    </EmailFeaturesContext.Provider>
  );
};
