import React, { useState, useEffect } from "react";
import Tooltip from "@material-ui/core/Tooltip";
import { setNylasAccountStatus } from "../utils/syncUtils";
import { useTranslation } from "global/utils/useTranslation";
import MicrosoftLogo from "global/assets/images/partnerLogos/ms-symbollockup_mssymbol_19.png";
import style from "../assets/SyncPage.module.css";
import { Button, Image } from "react-bootstrap";
import { AiFillInfoCircle } from "react-icons/ai";
import { FaSpinner } from "react-icons/fa";
import { BiEdit } from "react-icons/bi";
import { AtlasAlert } from "global/components/atlas-alert";
import cx from "classnames";

const NylasComponent = ({
  label,
  emailType,
  hasWriteAccess,
  account,
  reactivateAccountLoader,
  setReactivateAccountLoader,
  setShowModal,
  setShowNameModal,
  setShowMicrosoftLoginModal,
  setShowSyncMSNylasEmailModal,
  disableAccount,
  enableAccount,
  deleteAccount,
  parsedMSToken,
  refreshToken,
  isDefaultEmailAccountsHandler,
}) => {
  const { out } = useTranslation();
  const [accountTranslations, setAccountTranslations] = useState(account);

  useEffect(() => {
    if (account) {
      setAccountTranslations(setNylasAccountStatus(account));
    }
    if (
      reactivateAccountLoader === emailType &&
      account.sync_state !== "stopped"
    ) {
      setReactivateAccountLoader(null);
    }
  }, [account]);

  return (
    <>
      <div className="p-2">
        <label className={style.syncLabel}>{label}:</label>&nbsp;&nbsp;
        {Object.keys(account).length > 0 ? (
          <span>{account.email}</span>
        ) : (
          <span className="text-warning">
            {out("Non fourni", "Not provided")}
          </span>
        )}
        <br />
        <span className="d-flex align-items-center">
          <label className={style.syncLabel}>{out("Nom", "Name")}:</label>
          &nbsp;&nbsp;
          {account?.name ? (
            <span>{account.name}</span>
          ) : (
            <span className="text-warning">
              {out("Non fourni", "Not provided")}
            </span>
          )}
          {hasWriteAccess && account?.name && (
            <Button
              variant="secondary"
              size="sm"
              className="btn-frameless-icon ms-1 fs-6"
              title={out("Modifier", "Update")}
              onClick={() => setShowNameModal(`nylas-${emailType}`)}
            >
              <BiEdit className="fs-4" />
            </Button>
          )}
        </span>
        <label className={style.syncLabel}>{out("Statut", "Status")}:</label>
        &nbsp;&nbsp;
        {Object.keys(account).length > 0 && accountTranslations ? (
          <span
            className={cx("text-secondary-200", {
              "text-warning": ![
                "running",
                "initializing",
                "downloading",
              ].includes(account.sync_state),
            })}
          >
            {out(accountTranslations.fr, accountTranslations.en)}
          </span>
        ) : (
          <span className="text-warning">
            {out("Aucun courriel synchronisé", "No email synchronized")}
          </span>
        )}
        &nbsp;
        {Object.keys(account).length > 0 &&
          [
            "partial",
            "invalid-credentials",
            "exception",
            "sync-error",
          ].includes(account.sync_state) && (
            <Tooltip
              placement="top-start"
              title={
                <div className="text-center p-1 h6">
                  {account.sync_state === "partial"
                    ? out(
                        "Le statut partiel devrait être temporaire, actualisez la page après quelques minutes. Si ce statut persiste, veuillez supprimer votre compte et le synchroniser à nouveau",
                        "The partial status should be temporary, refresh the page after a few minutes. If it persists please delete your account and sync it again",
                      )
                    : out(
                        "Une erreur s'est produite lors du processus de synchronisation, veuillez supprimer et synchroniser votre courriel à nouveau. Si le problème persiste, contactez support@workland.com pour obtenir de l'aide",
                        "An error occurred during the sync process, please delete and sync your email again. If the problem persists, contact support@workland.com for assistance",
                      )}
                </div>
              }
            >
              <span>
                <AiFillInfoCircle className="text-secondary fs-4 mb-1 me-1" />
              </span>
            </Tooltip>
          )}
        {account.is_default > 0 && (
          <span className={`${style.blueBadge} ms-2 px-2`}>
            {out("Défaut", "Default")}
          </span>
        )}
        <AtlasAlert
          className={cx({
            "d-none": !(
              reactivateAccountLoader === emailType &&
              account.sync_state === "stopped"
            ),
          })}
          icon={<FaSpinner className={cx("me-2 fa-pulse fs-2")} />}
        >
          {out("Mise à jour du status...", "Updating status...")}
        </AtlasAlert>
      </div>
      {hasWriteAccess && (
        <div className=" d-flex flex-row-reverse flex-wrap py-0 px-3 mb-3 mt-3">
          {Object.keys(account).length < 1 && (
            <>
              <Button
                variant="secondary"
                className="ms-3 mb-1"
                onClick={() => {
                  localStorage.setItem("redirect_to", "sync");
                  localStorage.setItem("sync_email_type", emailType);
                  localStorage.setItem("sync_type", "nylas-regular");
                  setShowModal(true);
                }}
              >
                {out("Synchroniser", "Synchronize")}
              </Button>
              <Button
                variant="secondary"
                className="ms-3 mb-1"
                onClick={() => {
                  localStorage.setItem("redirect_to", "sync");
                  localStorage.setItem("sync_email_type", emailType);
                  localStorage.setItem("sync_type", "microsoft");
                  if (parsedMSToken) {
                    if (parsedMSToken.exp < new Date().getTime() / 1000 - 15) {
                      refreshToken({
                        provider: "microsoft",
                        data: {
                          refresh_token: parsedMSToken.refresh_token,
                          scope:
                            "https://graph.microsoft.com/.default offline_access",
                        },
                      });
                    } else {
                      setShowSyncMSNylasEmailModal(true);
                    }
                  } else {
                    setShowMicrosoftLoginModal(true);
                  }
                }}
              >
                {out(
                  "Synchroniser avec Microsoft",
                  "Synchronize with Microsoft",
                )}

                <Image
                  src={MicrosoftLogo}
                  className={`${style.btnMSLogo} ms-2`}
                />
              </Button>
            </>
          )}
          {Object.keys(account).length > 0 && (
            <>
              <Button
                variant="alt-danger"
                className="ms-3 mb-1"
                onClick={() => {
                  deleteAccount({
                    nylas_account_id: account.id,
                    account_type: emailType,
                  });
                }}
              >
                {out("Supprimer le compte", "Delete account")}
              </Button>
              {account.sync_state !== "stopped" && (
                <Button
                  variant="alt-warning"
                  className="ms-3 mb-1"
                  onClick={() => {
                    disableAccount({
                      nylas_account_id: account.id,
                      account_type: emailType,
                    });
                  }}
                >
                  {out("Désactiver", "Deactivate")}
                </Button>
              )}
              {account.sync_state === "stopped" && (
                <Tooltip
                  placement="top-start"
                  title={
                    <div className="text-center p-1 h6">
                      {out(
                        "Veuillez noter que le délai pour réactiver votre compte peut prendre un certain temps, si votre compte n'est toujours pas réactivé après une minute, veuillez rafraîchir la page",
                        "Please note that it may take some time to reactivate your account, if your account is still not reactivated after one minute, please refresh the page",
                      )}
                    </div>
                  }
                >
                  <Button
                    variant="secondary"
                    className="ms-3 mb-1 d-flex align-items-center"
                    disabled={reactivateAccountLoader}
                    onClick={() => {
                      setReactivateAccountLoader(emailType);
                      enableAccount({
                        nylas_account_id: account.id,
                        account_type: emailType,
                      });
                    }}
                  >
                    <AiFillInfoCircle className="fs-4" />

                    <div className="ms-2">
                      {out("Réactiver", "Reactivate")}&nbsp;
                    </div>
                  </Button>
                </Tooltip>
              )}
              {!account.is_default && (
                <Button
                  variant="alt-success"
                  className="ms-3 mb-1"
                  onClick={() => {
                    isDefaultEmailAccountsHandler({
                      type: emailType,
                      payload: {
                        nylas_account_id: account.id,
                      },
                    });
                  }}
                >
                  {out("Définir par défault", "Set as default")}
                </Button>
              )}
            </>
          )}
        </div>
      )}
    </>
  );
};

export default NylasComponent;
