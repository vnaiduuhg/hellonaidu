import React from "react";
import NylasComponent from "./NylasComponent";
import { useTranslation } from "global/utils/useTranslation";
import NylasIcon from "global/assets/images/partnerLogos/nylas.png";
import style from "../assets/SyncPage.module.css";
import { AtlasAlert } from "global/components/atlas-alert";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { RECRUITER } from "global/constants/accountsConstants";
import { Image } from "react-bootstrap";

const Nylas = ({
  user,
  accounts,
  hasError,
  isLoading,
  syncCallbackLoading,
  reactivateAccountLoader,
  setReactivateAccountLoader,
  setShowModal,
  setShowNameModal,
  setShowMicrosoftLoginModal,
  setShowSyncMSNylasEmailModal,
  disableAccount,
  enableAccount,
  deleteAccount,
  parsedMSToken,
  refreshToken,
  isDefaultEmailAccountsHandler,
}) => {
  const { out } = useTranslation();

  return (
    <div className="d-flex flex-column h-100">
      <div className={style.containerHeader}>
        <div className={style.titleContainer}>
          <div className={`${style.nylasIcon} ${style.img} py-1 ms-3`}>
            <Image src={NylasIcon} alt="Nylas" />
          </div>
          <div className={style.title}>
            <h2>{out("Courriel avec Nylas", "Nylas Email Service")}</h2>
          </div>
        </div>
      </div>
      <div className={`${style.componentContainer} flex-grow-1`}>
        <div className="mt-2">
          <p className={`px-2 ${style.fs1Dot125}`}>
            {out(
              "Nylas est un service web qui se synchronise avec votre compte courriel personnel, vous permettant d'envoyer des courriels et de synchroniser votre calendrier depuis le système Workland ATLAS.",
              "Nylas is a web service which synchronizes with your personal email account, allowing you to send email and synchronize your calendar from within the Workland ATLAS system.",
            )}
          </p>
        </div>
        <div className={`pt-2 ${style.fs1Dot125}`}>
          {!isLoading && !hasError && !syncCallbackLoading && (
            <>
              <NylasComponent
                label={out("Courriel régulier", "Regular email")}
                emailType="regular"
                hasWriteAccess={true}
                account={accounts.regular}
                reactivateAccountLoader={reactivateAccountLoader}
                setReactivateAccountLoader={setReactivateAccountLoader}
                setShowModal={setShowModal}
                setShowNameModal={setShowNameModal}
                setShowMicrosoftLoginModal={setShowMicrosoftLoginModal}
                setShowSyncMSNylasEmailModal={setShowSyncMSNylasEmailModal}
                disableAccount={disableAccount}
                enableAccount={enableAccount}
                deleteAccount={deleteAccount}
                parsedMSToken={parsedMSToken}
                refreshToken={refreshToken}
                isDefaultEmailAccountsHandler={isDefaultEmailAccountsHandler}
              />
              <NylasComponent
                label={out("Courriel automatique", "Automated email")}
                emailType="automated"
                hasWriteAccess={user.user_account.role_id !== RECRUITER}
                account={accounts.automated}
                reactivateAccountLoader={reactivateAccountLoader}
                setReactivateAccountLoader={setReactivateAccountLoader}
                setShowModal={setShowModal}
                setShowNameModal={setShowNameModal}
                setShowMicrosoftLoginModal={setShowMicrosoftLoginModal}
                setShowSyncMSNylasEmailModal={setShowSyncMSNylasEmailModal}
                disableAccount={disableAccount}
                enableAccount={enableAccount}
                deleteAccount={deleteAccount}
                parsedMSToken={parsedMSToken}
                refreshToken={refreshToken}
                isDefaultEmailAccountsHandler={isDefaultEmailAccountsHandler}
              />
            </>
          )}
          {!isLoading && hasError && (
            <AtlasAlert variant="error">
              {out("Non disponible", "Not available")}
            </AtlasAlert>
          )}
          {isLoading && !syncCallbackLoading && (
            <ComponentLoader
              message={out(
                "Nous téléchargeons vos informations",
                "Loading your information",
              )}
            />
          )}
          {syncCallbackLoading && (
            <ComponentLoader
              message={out(
                "Synchronisation en cours",
                "Synchronization in progress",
              )}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Nylas;
