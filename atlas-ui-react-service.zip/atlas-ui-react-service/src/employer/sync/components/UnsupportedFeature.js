import { useTranslation } from "global/utils/useTranslation";
import { AtlasAlert } from "global/components/atlas-alert";

export const UnsupportedFeature = (provider = null) => {
  const { out } = useTranslation();

  return (
    <AtlasAlert variant="secondary" className="mt-3">
      {out(
        `Cette fonctionnalité n'est pas disponible à partir du fournisseur actuellement synchronisé${
          provider ? " (" + provider + ")" : ""
        }. Veuillez synchroniser votre courriel régulier avec un autre fournisseur si vous souhaitez utiliser cette fonction.`,
        `This feature is not available from the currently synced Provider${
          provider ? " (" + provider + ")" : ""
        }. Please sync your regular email with a another provider if you wish to use this feature.`,
      )}
    </AtlasAlert>
  );
};
