import React, { useState, useEffect } from "react";
import { microsoftNoBusinessMsgHandler } from ".././utils/syncMsgHandler";
import { useTranslation } from "global/utils/useTranslation";
import Tooltip from "@material-ui/core/Tooltip";
import MicrosoftLogo from "global/assets/images/partnerLogos/ms-symbollockup_mssymbol_19.png";
import style from "../assets/SyncPage.module.css";
import { Button, FloatingLabel, Form, Image, Modal } from "react-bootstrap";
import { AtlasAlert } from "global/components/atlas-alert";
import {
  AiFillInfoCircle,
  AiFillMinusCircle,
  AiFillPlusCircle,
} from "react-icons/ai";
import { FaPlus, FaMinus } from "react-icons/fa";
import { BsFillExclamationTriangleFill } from "react-icons/bs";

const SyncEmailModal = ({
  show,
  onHide,
  syncEmail,
  syncType,
  emailType,
  parsedMSToken = null,
  parsedAccessToken = null,
  loginToMS = null,
  showMismatchEmailMsg = false,
  setShowMismatchEmailMsg = null,
}) => {
  const { out } = useTranslation();
  const [emailValue, setEmailValue] = useState("");
  const [emailValidated, setEmailValidated] = useState(false);
  const [nameValue, setNameValue] = useState("");
  const [nameValidated, setNameValidated] = useState(false);
  const [aliasValue, setAliasValue] = useState("");
  const [aliasValidated, setAliasValidated] = useState(false);
  const [msNoBusinessAccountMsg, setMsNoBusinessAccountMsg] = useState(null);
  const [showEEInfo, setShowEEInfo] = useState(false);
  const [showAliasField, setShowAliasField] = useState(false);
  const regExp = /^[^@]+@{1}([^@]+\.)+\w{2,}$/g;

  useEffect(() => {
    if (syncType === "Nylas-Microsoft") {
      if (parsedAccessToken?.unique_name) {
        setEmailValue(parsedAccessToken.unique_name);
        setEmailValidated(regExp.test(parsedAccessToken.unique_name));
      }
      if (!parsedAccessToken) {
        setMsNoBusinessAccountMsg(microsoftNoBusinessMsgHandler());
      }
    }
  }, []);

  return (
    <Modal
      size="lg"
      show={show}
      onHide={() => {
        if (setShowMismatchEmailMsg) setShowMismatchEmailMsg(false);

        onHide();
      }}
    >
      <Modal.Header>
        <Modal.Title className="fs-5">
          {out(
            `Synchronisation du courriel ${
              emailType === "regular" ? "regulier" : "automatisé"
            } avec `,
            `Synchronizing ${emailType} email with `,
          )}{" "}
          <span>
            {syncType === "EmailEngine"
              ? "Email Engine"
              : syncType === "Aws"
              ? "AWS"
              : "Nylas"}
          </span>
          {syncType === "EmailEngine" && (
            <>
              <Tooltip
                placement="right-start"
                title={
                  <div className="text-center fs-6 p-1">
                    {out("Plus d'info", "More info")}
                  </div>
                }
              >
                <Button
                  variant="secondary"
                  size="md"
                  className="btn-frameless-icon ms-1 fs-4"
                  onClick={() => {
                    setShowEEInfo(!showEEInfo);
                  }}
                >
                  {showEEInfo && <AiFillMinusCircle className="fs-4" />}
                  {!showEEInfo && <AiFillPlusCircle className="fs-4" />}
                </Button>
              </Tooltip>
            </>
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {showEEInfo && (
          <AtlasAlert variant="info" className="my-3" icon={null}>
            <label className={`d-flex align-items-center mb-3`}>
              {out("Information pour utiliser", "Information to use")}
              &nbsp;
              <span className={style.standardIMAPBtn}>Standard IMAP</span>
            </label>
            <div className="">
              {out(
                "Si votre compte de messagerie est un iCloud/Gmail/Gsuite ou si l'authentification à 2 facteurs est activée, vous devrez sans doute saisir le mot de passe d'application au lieu du mot de passe de connexion.",
                "If your email account is an iCloud/Gmail/Gsuite or has 2 factor authentication enabled, you may have to enter your app password instead of login password.",
              )}
            </div>
          </AtlasAlert>
        )}
        {!msNoBusinessAccountMsg && (
          <div className={`${style.fs1Dot125} fw-bold mb-2`}>
            {showMismatchEmailMsg &&
              out(
                "Nylas requiert la synchronisation de l'adresse courriel associée au protocole de transfert de courrier simple (smtp). Cette adresse courriel peut différer de celle avec laquelle vous êtes connecté.",
                "Nylas requires synchronization of the email address associated with Simple Mail Transfer Protocol (smtp). This email address may differ from the one you are logged in with.",
              )}
            {!showMismatchEmailMsg &&
              out(
                "Veuillez entrer l'adresse courriel que vous souhaitez synchroniser",
                "Please enter the email address you wish to synchronize",
              )}
          </div>
        )}
        {!!msNoBusinessAccountMsg && (
          <>
            <h5 className={`text-center modal-title`}>
              <i className="fa fa-exclamation-triangle text-danger"></i>
              &nbsp;
              {out(
                "Connexion avec un compte Microsoft non autorisé",
                "Unauthorized Microsoft account for synchronization",
              )}
            </h5>
            <div className="fs-6 fw-bold mb-2 text-warning">
              {msNoBusinessAccountMsg && msNoBusinessAccountMsg.text}
            </div>
          </>
        )}

        {!msNoBusinessAccountMsg && (
          <>
            {syncType === "Aws" && (
              <AtlasAlert variant="warning">
                <div className="ms-3 fw-normal">
                  {out(
                    "Veuillez noter que la synchronisation ne sera effective que lorsque vous aurez autorisé AWS à utiliser votre adresse courriel. Après la synchronisation, vérifiez votre boîte de réception, vous devriez avoir reçu une demande de vérification d'adresse courriel de la part d'Amazon Web Services.",
                    "Please note that the synchronization will not take effect until you have authorized AWS to use your email address. After syncing, check your inbox, you should have received an email address verification request from Amazon Web Services.",
                  )}
                </div>
              </AtlasAlert>
            )}
            <div className="d-flex flex-row-reverse position-relative">
              <Tooltip
                placement="left"
                title={
                  <div className="text-center p-1 h6">
                    {out(
                      "Ce nom sera utilisé dans le champ expéditeur du courriel",
                      "This name will be used in the sender field of the email",
                    )}
                  </div>
                }
              >
                <span className={`position-absolute ${style.nameFieldInfo} `}>
                  <AiFillInfoCircle
                    className={`text-secondary mb-1 me-1 fs-4`}
                  />
                </span>
              </Tooltip>
            </div>
            <FloatingLabel className="mb-3" label={out("Nom", "Name")}>
              <Form.Control
                type="text"
                value={nameValue}
                onChange={(e) => {
                  setNameValue(e.target.value);
                  setNameValidated(e.target.value.length > 1);
                }}
                placeholder=" "
              />
            </FloatingLabel>
            <FloatingLabel label={out("Courriel", "Email")}>
              <Form.Control
                type="email"
                placeholder=" "
                value={emailValue}
                onChange={(e) => {
                  setEmailValue(e.target.value);
                  setEmailValidated(regExp.test(e.target.value));
                }}
              />
            </FloatingLabel>
            {syncType === "EmailEngine" && !showAliasField && (
              <div className="d-flex align-items-center justify-content-end mt-3">
                <span>{out("Utiliser un alias", "Use an alias")}</span>
                <Button
                  variant="secondary"
                  className="btn-sm ms-2"
                  onClick={() => {
                    setShowAliasField(true);
                  }}
                >
                  <FaPlus />
                </Button>
              </div>
            )}
            {showAliasField && (
              <div className="d-flex my-3">
                <div className="flex-fill position-relative">
                  <Tooltip
                    placement="left"
                    title={
                      <div className="text-center p-1 h6 ms-2">
                        {out(
                          "L'utilisation d'une adresse courielle alias garantira que vos destinataires verront ce courriel dans le champ de. Veuillez vous assurer que cet alias est configuré et fonctionne avec votre fournisseur de messagerie avant de le définir ici.",
                          "Using an alias email address will ensure that your recipients will see that email in the From field. Please ensure this alias is configured and working with your email provider before setting it here.",
                        )}
                      </div>
                    }
                  >
                    <span
                      className={`position-absolute ${style.aliasFieldInfo}`}
                    >
                      <BsFillExclamationTriangleFill className="text-warning mb-1 me-1 fs-4" />
                    </span>
                  </Tooltip>
                  <FloatingLabel label={out("Courriel alias", "Email alias")}>
                    <Form.Control
                      type="email"
                      placeholder=" "
                      value={aliasValue}
                      onChange={(e) => {
                        setAliasValue(e.target.value);
                        setAliasValidated(regExp.test(e.target.value));
                      }}
                    />
                  </FloatingLabel>
                </div>
                <div className="d-flex align-items-center">
                  <Button
                    variant="secondary"
                    className="btn-sm ms-2"
                    onClick={() => {
                      setAliasValue("");
                      setAliasValidated(false);
                      setShowAliasField(false);
                    }}
                  >
                    <FaMinus />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </Modal.Body>

      <Modal.Footer>
        {!msNoBusinessAccountMsg && (
          <Button
            variant="primary"
            disabled={
              !emailValidated ||
              !nameValidated ||
              (aliasValue && !aliasValidated)
            }
            onClick={() => {
              if (syncType !== "Aws") {
                localStorage.setItem("name_to_sync", nameValue);
                if (syncType !== "EmailEngine")
                  localStorage.setItem("email_to_sync", emailValue);
              }
              const payload = {
                name: nameValue,
                email: emailValue,
              };
              if (syncType !== "EmailEngine") payload.emailType = emailType;
              if (syncType === "Nylas-Microsoft") {
                payload.account_type = emailType;
                payload.microsoft_refresh_token = parsedMSToken.refresh_token;
              }
              if (aliasValue) localStorage.setItem("email_alias", aliasValue);
              syncEmail(payload);
              if (setShowMismatchEmailMsg) setShowMismatchEmailMsg(false);
              onHide();
            }}
          >
            {out("Synchroniser", "Synchronize")}
          </Button>
        )}

        {syncType === "Nylas-Microsoft" && msNoBusinessAccountMsg && (
          <Button
            onClick={() => {
              localStorage.setItem("redirect_to", "sync");
              loginToMS();
              onHide();
            }}
          >
            {out("S'identifier avec Microsoft", "Login with Microsoft")}
            &nbsp;&nbsp;
            <Image
              className={style.btnMSLogo}
              src={MicrosoftLogo}
              alt="Microsoft"
            />
          </Button>
        )}

        <Button
          variant="alt-secondary"
          onClick={() => {
            localStorage.removeItem("sync_email_type");
            localStorage.removeItem("sync_type");
            localStorage.removeItem("redirect_to");

            if (setShowMismatchEmailMsg) setShowMismatchEmailMsg(false);

            onHide();
          }}
        >
          {out("Annuler", "Cancel")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default SyncEmailModal;
