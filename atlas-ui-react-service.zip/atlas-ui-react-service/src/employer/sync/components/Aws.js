import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import { setAwsAccountStatus } from "../utils/syncUtils";
import AWSComponent from "./AWSComponent";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import AwsIcon from "global/assets/images/partnerLogos/aws.png";
import style from "../assets/SyncPage.module.css";
import { Image } from "react-bootstrap";
import { RECRUITER } from "global/constants/accountsConstants";

const Aws = ({
  user,
  accounts,
  hasError,
  isLoading,
  setShowModal,
  setShowNameModal,
  desyncEmail,
  isDefaultEmailAccountsHandler,
}) => {
  const { out } = useTranslation();

  if (accounts?.regular?.length > 0) {
    accounts.regular[0].statusTranslations = setAwsAccountStatus(
      accounts.regular[0],
    );
  }

  if (accounts?.automated?.length > 0) {
    accounts.automated[0].statusTranslations = setAwsAccountStatus(
      accounts.automated[0],
    );
  }

  return (
    <div className="d-flex flex-column h-100">
      <div className={style.containerHeader}>
        <div className={style.titleContainer}>
          <div className={`${style.img} bg-white py-1 ms-3`}>
            <Image src={AwsIcon} alt="AWS" />
          </div>
          <div className={style.title}>
            <h2>
              {out(
                "Courriel avec Amazon Web Services (AWS)",
                "Amazon Web Services (AWS)",
              )}
            </h2>
          </div>
        </div>
      </div>
      <div className={`${style.componentContainer} flex-grow-1`}>
        <div className="mt-2">
          <p className={`px-2 ${style.fs1Dot125}`}>
            {out(
              "AWS est un service rapide et fiable qui permet aux utilisateurs d'envoyer des courriels à partir d'adresses IP partagées avec d'autres clients. Remarque: Une configuration est nécessaire pour vérifier les courriels synchronisés ainsi que d'autres mesures de sécurité telles que (DMARK, SPF etc.).",
              "AWS is a fast, reliable service that allows users to send emails from IP addresses that are shared with other customers. Note: A setup is required to verify synced emails along with other security measures such as (DMARK, SPF etc.).",
            )}
          </p>
        </div>

        <div className={`pt-2 ${style.fs1Dot125}`}>
          {!isLoading && !hasError && accounts && (
            <>
              <AWSComponent
                account={accounts.regular}
                emailType="regular"
                hasWriteAccess={true}
                setShowModal={setShowModal}
                setShowNameModal={setShowNameModal}
                desyncEmail={desyncEmail}
                isDefaultEmailAccountsHandler={isDefaultEmailAccountsHandler}
              />
              <AWSComponent
                account={accounts.automated}
                emailType="automated"
                hasWriteAccess={user.user_account.role_id !== RECRUITER}
                setShowModal={setShowModal}
                setShowNameModal={setShowNameModal}
                desyncEmail={desyncEmail}
                isDefaultEmailAccountsHandler={isDefaultEmailAccountsHandler}
              />
            </>
          )}
          {!isLoading && hasError && (
            <AtlasAlert variant="error">
              {out("Non disponible", "Not available")}
            </AtlasAlert>
          )}
          {isLoading && (
            <ComponentLoader
              message={out(
                "Nous téléchargeons vos informations",
                "Loading your informations",
              )}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Aws;
