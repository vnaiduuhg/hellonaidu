import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import MicrosoftLogo from "global/assets/images/partnerLogos/ms-symbollockup_mssymbol_19.png";
import { Button, Image, Modal } from "react-bootstrap";
import style from "../assets/SyncPage.module.css";

const MicrosoftLoginModal = ({ show, onHide, login }) => {
  const { out } = useTranslation();

  return (
    <Modal show={show} onHide={onHide}>
      <form
        onSubmit={() => {
          localStorage.setItem("redirect_to", "sync");
          login();

          onHide();
        }}
      >
        <Modal.Header>
          <Modal.Title className="h5">
            <Image
              className={`${style.inlineTextMSLogo} me-1`}
              src={MicrosoftLogo}
            />
            &nbsp;
            {out("Connexion Microsoft", "Microsoft Login")}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {out("Veuillez d'abord vous identifier avec", "Please sign in with")}
          &nbsp;
          <Image className={style.inlineTextMSLogo} src={MicrosoftLogo} />
          &nbsp;
          {out("Microsoft", "Microsoft first")}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" type="submit">
            {out("S'identifier", "Sign in")}
          </Button>

          <Button
            variant="alt-secondary"
            type="button"
            onClick={() => {
              localStorage.removeItem("sync_email_type");
              localStorage.removeItem("sync_type");
              localStorage.removeItem("redirect_to");
              onHide();
            }}
          >
            {out("Annuler", "Cancel")}
          </Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default MicrosoftLoginModal;
