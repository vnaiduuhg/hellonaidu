import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import Tooltip from "@material-ui/core/Tooltip";
import style from "../assets/SyncPage.module.css";
import { Button } from "react-bootstrap";
import { AiFillInfoCircle } from "react-icons/ai";
import { BiEdit } from "react-icons/bi";
import cx from "classnames";

const AWSComponent = ({
  account,
  emailType,
  hasWriteAccess,
  setShowModal,
  setShowNameModal,
  desyncEmail,
  isDefaultEmailAccountsHandler,
}) => {
  const { out } = useTranslation();
  return (
    <>
      <div className="p-2">
        <label className={style.syncLabel}>
          {emailType === "regular"
            ? out("Courriel régulier", "Regular email")
            : out("Courriel automatique", "Automated email")}
          &nbsp;:
        </label>
        &nbsp;&nbsp;
        {account.length > 0 && account[0].email ? (
          <span>{account[0].email}</span>
        ) : (
          <span className="text-warning">
            {out("Non fourni", "Not provided")}
          </span>
        )}
        <br />
        <span className="d-flex align-items-center">
          <label className={style.syncLabel}>{out("Nom", "Name")}:</label>
          &nbsp;&nbsp;
          {account.length > 0 && account[0].name ? (
            <span>{account[0].name}</span>
          ) : (
            <span className="text-warning">
              {out("Non fourni", "Not provided")}
            </span>
          )}
          {hasWriteAccess && account.length > 0 && account[0].name && (
            <Button
              variant="secondary"
              size="sm"
              className="btn-frameless-icon ms-1 fs-6"
              title={out("Modifier", "Update")}
              onClick={() => {
                setShowNameModal(`aws-${emailType}`);
              }}
            >
              <BiEdit className="fs-4" />
            </Button>
          )}
        </span>
        <label className={style.syncLabel}>{out("Statut", "Status")}:</label>
        &nbsp;&nbsp;
        <span className="text-secondary-200">
          {account.length > 0 && account[0].email ? (
            <span
              className={cx({
                "text-warning": account[0].verification_status !== "Success",
              })}
            >
              {out(
                account[0].statusTranslations.fr,
                account[0].statusTranslations.en,
              )}
            </span>
          ) : (
            <span className="text-warning">
              {out("Aucun courriel synchronisé", "No email synchronized")}
            </span>
          )}
        </span>
        &nbsp;
        {account.length > 0 && account[0].verification_status !== "Success" && (
          <Tooltip
            placement="top-start"
            title={
              <div className="text-center p-1 h6">
                {account[0].verification_status === "Pending"
                  ? out(
                      "AWS effectue une vérification de votre adresse courriel avant d'activer votre compte, veuillez vérifier votre boîte de réception afin de vous authentifier",
                      "AWS verifies your email address before activating your account, please check your inbox to authenticate",
                    )
                  : out(
                      "AWS n’a pu verifier votre adresse courriel. Si le problème persiste, veuillez supprimer votre compte et le synchroniser à nouveau",
                      "AWS could not verify your email address. If the problem persists, please delete your account and sync it again",
                    )}
              </div>
            }
          >
            <span>
              <AiFillInfoCircle className="text-secondary mb-1 me-1 fs-4" />
            </span>
          </Tooltip>
        )}
        {account.length > 0 && account[0].is_default > 0 && (
          <span className={`${style.blueBadge} ms-2 px-2`}>
            {out("Défaut", "Default")}
          </span>
        )}
      </div>
      {hasWriteAccess && (
        <div className="d-flex flex-row-reverse py-0 px-3 mb-3">
          {account.length < 1 && (
            <Button
              variant="secondary"
              className="ms-3 mb-1"
              onClick={() => {
                setShowModal(emailType);
              }}
            >
              {out("Synchroniser", "Synchronize")}
            </Button>
          )}
          {account.length > 0 && (
            <>
              <Button
                variant="alt-danger"
                className="ms-3 mb-1"
                onClick={() => {
                  desyncEmail({ emailType: emailType, id: account[0].id });
                }}
              >
                {out("Supprimer", "Delete")}
              </Button>
              {!account[0].is_default && (
                <Button
                  variant="alt-success"
                  className="ms-3 mb-1"
                  onClick={() => {
                    isDefaultEmailAccountsHandler({
                      type: emailType,
                      payload: {
                        aws_email_identity_id: account[0].id,
                      },
                    });
                  }}
                >
                  {out("Définir par défault", "Set as default")}
                </Button>
              )}
            </>
          )}
        </div>
      )}
    </>
  );
};

export default AWSComponent;
