import React, { useState, useEffect } from "react";
import Tooltip from "@material-ui/core/Tooltip";
import { useTranslation } from "global/utils/useTranslation";
import { setEmailType } from "../utils/syncUtils";
import { Button, FloatingLabel, Form, Modal } from "react-bootstrap";
import style from "../assets/SyncPage.module.css";
import { AiFillInfoCircle } from "react-icons/ai";

const UpdateNameModal = ({ show, onHide, emailType, account, updateName }) => {
  const { out } = useTranslation();
  const [nameInitialValue] = useState(account.name);
  const [nameValue, setNameValue] = useState("");
  const [nameValidated, setNameValidated] = useState(false);
  const [identicalNameValues, setIdenticalNameValues] = useState(false);
  const [emailTypeLabel, setEmailTypeLabel] = useState("");

  useEffect(() => {
    const emailTypeTranslations = setEmailType(emailType);
    setEmailTypeLabel(emailTypeTranslations);
    setNameValue(nameInitialValue);
  }, []);

  return (
    <Modal show={show} onHide={onHide}>
      <form
        onSubmit={() => {
          updateName({
            name: nameValue,
            id: account.id,
          });

          onHide();
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title className="h5">
            {out(
              `Modifier le nom de votre ${out(
                emailTypeLabel.fr,
                emailTypeLabel.en,
              )}`,
              `Modify your ${out(emailTypeLabel.fr, emailTypeLabel.en)}'s name`,
            )}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <div className="d-flex position-relative mb-1 ms-1">
            <div>
              <span className="fw-bold">{out("Courriel", "Email")}: </span>
              <span className="text-secondary-200">{account.email}</span>
            </div>

            <div
              className={`ms-auto position-absolute ${style.updateNameFieldInfo}`}
            >
              <Tooltip
                placement="left"
                title={
                  <div className="text-center p-1 h6">
                    {out(
                      "Ce nom sera utilisé dans le champ expéditeur du courriel",
                      "This name will be used in the sender field of the email",
                    )}
                  </div>
                }
              >
                <span>
                  <AiFillInfoCircle className="text-secondary mb-1 me-1 fs-4" />
                </span>
              </Tooltip>
            </div>
          </div>

          <FloatingLabel label={out("Nom", "Name")}>
            <Form.Control
              placeholder=" "
              type="text"
              value={nameValue}
              onChange={(e) => {
                setNameValue(e.target.value);
                setNameValidated(
                  e.target.value.length > 1 &&
                    e.target.value !== nameInitialValue,
                );
                setIdenticalNameValues(
                  e.target.value === nameInitialValue ?? false,
                );
              }}
            />
          </FloatingLabel>

          {identicalNameValues && (
            <div className="text-warning ms-1 mt-1">
              *&nbsp;
              {out(
                "Le nouveau nom est identique à celui existant",
                "The new name is the same as the existing one",
              )}
            </div>
          )}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" type="submit" disabled={!nameValidated}>
            {out("Ok", "Ok")}
          </Button>

          <Button variant="alt-secondary" type="button" onClick={onHide}>
            {out("Annuler", "Cancel")}
          </Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default UpdateNameModal;
