import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { getCookie, setCookie } from "global/utils/cookies";
import { getUrlParam, routeTo } from "global/utils/utils";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { parseJwt } from "global/utils/authUtils";
import {
  getEmailAuthorization,
  postNylasEmailSync,
  disableNylasEmailSync,
  enableNylasEmailSync,
  deleteNylasEmailSync,
  updateNylasAutomatedEmailName,
  updateNylasRegularEmailName,
  syncNylasEmailWithMicrosoft,
} from "../apis/nylasApis";
import {
  postAwsEmailSync,
  deleteAwsEmailSync,
  updateAwsSyncedEmailName,
} from "../apis/awsApis";
import {
  getEmailEngineEmailAuthorization,
  postEmailEngineEmailSync,
  updateEmailEngineEmailName,
  deleteEmailEngineEmailSync,
} from "../apis/EmailEngineApis";
import {
  loginWithMicrosoftAccount,
  refreshMicrosoftToken,
} from "global/apis/userApi";
import {
  getCurrentUserEmailAccounts,
  setDefaultEmailAccountsApi,
} from "global/apis/messagingApi";
import {
  getSyncedEmailAccountsMsgHandler,
  syncEmailMsgHandler,
  microsoftSyncEmailMsgHandler,
  disableNylasEmailMsgHandler,
  enableNylasEmailMsgHandler,
  desyncEmailMsgHandler,
  deleteAwsEmailMsgHandler,
  updateEmailNameMsgHandler,
  setDefaultEmailAccountsMsgHandler,
  syncEmailEngineMsgHandler,
  updateEmailEngineMsgHandler,
} from "../utils/syncMsgHandler";
import {
  microsoftLoginRedirectMsgHandler,
  microsoftLoginCallbackMsgHandler,
  microsoftTokenRefreshMsgHandler,
} from "global/utils/userAccountsMsgHandler";
import { setSelectedEmailAccount } from "../utils/syncUtils";
import Nylas from "../components/Nylas";
import Aws from "../components/Aws";
import EmailEngine from "../components/EmailEngine";
import SyncEmailModal from "../components/SyncEmailModal";
import UpdateNameModal from "../components/UpdateNameModal";
import MicrosoftLoginModal from "../components/MicrosoftLoginModal";
import { RECRUITER } from "global/constants/accountsConstants";
import { Col, Row } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";

const SyncPage = () => {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const user = useSelector((state) => state.user.data);
  const [showSyncEmailEngineModal, setShowSyncEmailEngineModal] = useState("");
  const [showSyncNylasEmailModal, setShowSyncNylasEmailModal] = useState(false);
  const [showSyncMSNylasEmailModal, setShowSyncMSNylasEmailModal] =
    useState(false);
  const [showSyncAwsEmailModal, setShowSyncAwsEmailModal] = useState(""); // in: regular|automated
  const [showUpdateNameModal, setShowUpdateNameModal] = useState(""); // in: aws-regular|aws-automated|nylas-regular|nylas-automated
  const [showMicrosoftLoginModal, setShowMicrosoftLoginModal] = useState(false);
  const [syncCallbackLoading, setSyncCallbackLoading] = useState("");
  const [reactivateAccountLoader, setReactivateAccountLoader] = useState(null);
  const [intervalId, setIntervalId] = useState(null);
  const [parsedMSToken, setParsedMSToken] = useState(null);
  const [parsedAccessToken, setParsedAccessToken] = useState(null);
  const [showMismatchEmailMsg, setShowMismatchEmailMsg] = useState(false);
  const { out } = useTranslation();

  const translatedTitle = out("Synchronisation courriel", "Sync Email Client");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  useEffect(() => {
    const codeUrlParam = getUrlParam("code");
    const accountUrlParam = getUrlParam("account");
    const syncType = localStorage.getItem("sync_type");
    const emailType = localStorage.getItem("sync_email_type");
    const microsoftToken = getCookie("microsoftToken");

    let parsedMSTkn = null;
    let parsedAccessTkn = null;
    if (microsoftToken) {
      parsedMSTkn = JSON.parse(microsoftToken);
      setParsedMSToken(parsedMSTkn);
      if (parsedMSTkn.access_token.split(".").length > 1) {
        parsedAccessTkn = parseJwt(parsedMSTkn.access_token);
        setParsedAccessToken(parsedAccessTkn);
      }
    }
    if (syncType && syncType === "microsoft") {
      if (parsedMSTkn && parsedMSTkn.refresh_token) {
        if (parsedMSTkn.exp < new Date().getTime() / 1000 - 15) {
          refresMSToken.mutate({
            provider: "microsoft",
            data: {
              refresh_token: parsedMSTkn.refresh_token,
              scope: "https://graph.microsoft.com/.default offline_access",
            },
          });
        } else {
          setShowSyncMSNylasEmailModal(true);
        }
      } else {
        const msg = microsoftLoginCallbackMsgHandler(500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        localStorage.removeItem("sync_type");
        localStorage.removeItem("sync_email_type");
      }
    } else if (codeUrlParam) {
      dispatch(showLoadingBarWithoutMessage(200000));
      setSyncCallbackLoading(emailType);
      const data = {
        authorization_code: codeUrlParam,
        email: localStorage.getItem("email_to_sync"),
        name: localStorage.getItem("name_to_sync"),
        account_type: emailType,
      };
      syncNylasEmail.mutate(data);
    } else if (
      emailType === "regular" ||
      (emailType === "automated" && user.user_account.role_id !== RECRUITER)
    ) {
      if (accountUrlParam) {
        dispatch(showLoadingBarWithoutMessage(200000));
        const data = {
          account_type: emailType,
          email_engine_account_id: accountUrlParam,
        };
        const emailAlias = localStorage.getItem("email_alias");
        if (emailAlias) data.email = emailAlias;
        syncEmailEngineEmail.mutate(data);
      } else if (syncType !== "email-engine") {
        setShowSyncNylasEmailModal(true);
      }
    }

    localStorage.removeItem("redirect_to");

    return () => {
      if (intervalId) window.clearInterval(intervalId);
      localStorage.removeItem("sync_type");
      localStorage.removeItem("sync_email_type");
      localStorage.removeItem("email_to_sync");
      localStorage.removeItem("name_to_sync");
      localStorage.removeItem("redirect_to");
      localStorage.removeItem("email_alias");
    };
  }, [dispatch]);

  // @temp - this refetch feature should be also about mutating statuses and needs more thinking
  const refetchSyncedAccounts = () => {
    let i = 0;
    const fetchDataInterval = setInterval(() => {
      queryClient.invalidateQueries("synced-accounts");
      i++;
      if (i > 3) clearInterval(fetchDataInterval);
    }, 1500);
  };

  // Gets all synced email accounts
  const {
    data: emailAccounts,
    isError: emailAccountsIsError,
    isLoading: emailAccountsIsLoading,
  } = useQuery("synced-accounts", () => getCurrentUserEmailAccounts(), {
    staleTime: REACT_QUERY_GETTER_OPTIONS.staleTime,
    retry: REACT_QUERY_GETTER_OPTIONS.retry,
    refetchOnWindowFocus: REACT_QUERY_GETTER_OPTIONS.refetchOnWindowFocus,
    onSuccess: () => {
      if (syncCallbackLoading) setSyncCallbackLoading("");
    },
    onError: (error) => {
      const msg = getSyncedEmailAccountsMsgHandler(
        error.response?.status ? error.response.status : 500,
      );
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      if (syncCallbackLoading) setSyncCallbackLoading("");
    },
  });

  // Authorize email before to sync with Nylas
  const authorizeEmail = useMutation(
    (data) => getEmailAuthorization(data.email),
    {
      onSuccess: (response) => {
        if (response.url) {
          dispatch(statusMessagesSlice.actions.clearLoaders());
          window.location = response.url;
        } else {
          const msg = syncEmailMsgHandler(0);
          dispatch(showMessage("error", msg.title, msg.text, 8000));
          dispatch(statusMessagesSlice.actions.clearLoaders());
        }
      },
      onError: (error) => {
        const msg = syncEmailMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Sync email with Nylas
  const syncNylasEmail = useMutation((data) => postNylasEmailSync(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("synced-accounts");
      const msg = syncEmailMsgHandler(200);
      dispatch(showMessage("ok", msg.title, msg.text, 5000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      localStorage.removeItem("sync_email_type");
      localStorage.removeItem("sync_type");
      localStorage.removeItem("email_to_sync");
      localStorage.removeItem("name_to_sync");
      routeTo("sync", { code: null });
    },
    onError: (error) => {
      const msg = syncEmailMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      localStorage.removeItem("sync_email_type");
      localStorage.removeItem("sync_type");
      localStorage.removeItem("email_to_sync");
      localStorage.removeItem("name_to_sync");

      routeTo("sync", { code: null });
    },
  });

  // Disable Nylas email
  const disableNylasAccount = useMutation(
    (data) => disableNylasEmailSync(data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = disableNylasEmailMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = disableNylasEmailMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Enable Nylas email
  const enableNylasAccount = useMutation((data) => enableNylasEmailSync(data), {
    onSuccess: () => {
      let i = 0;
      const intervalID = setInterval(() => {
        queryClient.invalidateQueries("synced-accounts");
        if (i < 1) {
          const msg = enableNylasEmailMsgHandler(200);
          dispatch(showMessage("ok", msg.title, msg.text, 10000));
          dispatch(statusMessagesSlice.actions.clearLoaders());
        }

        if (++i === 8) {
          setReactivateAccountLoader(null);
          window.clearInterval(intervalID);
          setIntervalId(null);
        }
      }, 8000);
      setIntervalId(intervalID);
    },
    onError: (error) => {
      const msg = enableNylasEmailMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  // Delete Nylas email
  const deleteNylasAccount = useMutation((data) => deleteNylasEmailSync(data), {
    onSuccess: () => {
      queryClient.invalidateQueries("synced-accounts");
      const msg = desyncEmailMsgHandler(200);
      dispatch(showMessage("ok", msg.title, msg.text, 5000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
    onError: (error) => {
      const msg = desyncEmailMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  // Update Nylas regular email's name
  const updateRegularNylasEmailName = useMutation(
    (data) => updateNylasRegularEmailName(data.id, { name: data.name }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = updateEmailNameMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = updateEmailNameMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Update Nylas automated email's name
  const updateAutomatedNylasEmailName = useMutation(
    (data) => updateNylasAutomatedEmailName(data.id, { name: data.name }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = updateEmailNameMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = updateEmailNameMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Login with Microsoft
  const loginWithMSAccount = useMutation(() => loginWithMicrosoftAccount(), {
    onSuccess: (response) => {
      if (response.data?.link) {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        window.location = response.data.link;
      } else {
        const msg = microsoftLoginRedirectMsgHandler(500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      }
    },
    onError: (error) => {
      const msg = microsoftLoginRedirectMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
  });

  // Refresh Microsoft token
  const refresMSToken = useMutation(
    (data) => refreshMicrosoftToken(data.provider, data.data),
    {
      onSuccess: (response) => {
        if (response?.data) {
          const { access_token, exp, refresh_token, scope } = response.data;
          const microsoftToken = {
            access_token: access_token,
            exp: exp,
            refresh_token: refresh_token,
            scope: scope,
          };
          if (parsedMSToken?.microsoft_organization_account_ids) {
            microsoftToken.microsoft_organization_account_ids =
              parsedMSToken.microsoft_organization_account_ids;
          }
          setParsedMSToken(microsoftToken);
          const stringyfiedToken = JSON.stringify(microsoftToken);
          setCookie("microsoftToken", stringyfiedToken);
          setShowSyncMSNylasEmailModal(true);
        } else {
          const msg = microsoftTokenRefreshMsgHandler(500);
          dispatch(showMessage("error", msg.title, msg.text, 8000));
          localStorage.removeItem("sync_type");
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = microsoftTokenRefreshMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        localStorage.removeItem("sync_type");
      },
    },
  );

  // Sync Nylas email with Microsoft
  const syncNylasEmailWithMS = useMutation(
    (data) => syncNylasEmailWithMicrosoft(data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = microsoftSyncEmailMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        localStorage.removeItem("sync_type");
        localStorage.removeItem("sync_email_type");
      },
      onError: (error) => {
        if (
          error.status === 400 &&
          error.data?.message &&
          error.data.message ===
            "The refresh_token you provided doesn't match the email_address passed in this request."
        ) {
          setShowMismatchEmailMsg(true);
          setShowSyncMSNylasEmailModal(true);
        } else {
          const msg = microsoftSyncEmailMsgHandler(
            error.status,
            error.data?.message ? error.data.message : null,
          );
          dispatch(showMessage("error", msg.title, msg.text, 10000));
          localStorage.removeItem("sync_type");
          localStorage.removeItem("sync_email_type");
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Sync email with Aws
  const syncAwsEmail = useMutation(
    (data) =>
      postAwsEmailSync(data.emailType, {
        email: data.email,
        name: data.name,
      }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = syncEmailMsgHandler(201);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = syncEmailMsgHandler(error.status, error.data ?? null);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Desync Aws email
  const desyncAwsEmail = useMutation(
    (data) => deleteAwsEmailSync(data.emailType, data.id),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = deleteAwsEmailMsgHandler(204);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = deleteAwsEmailMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Update AWS email's name
  const updateAwsEmailName = useMutation(
    (data) =>
      updateAwsSyncedEmailName(data.emailType, data.id, { name: data.name }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = updateEmailNameMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = updateEmailNameMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Authorize email before to sync with Email Engine
  const authorizeEmailEngineEmail = useMutation(
    (data) => getEmailEngineEmailAuthorization(data),
    {
      onSuccess: (response) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        if (response.url) {
          window.location = response.url;
        } else {
          const msg = syncEmailEngineMsgHandler(500);
          dispatch(showMessage("error", msg.title, msg.text, 8000));
        }
      },
      onError: (error) => {
        const msg = syncEmailEngineMsgHandler(error.status ?? 500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Sync email with Email Engine
  const syncEmailEngineEmail = useMutation(
    (data) => postEmailEngineEmailSync(data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        refetchSyncedAccounts();
        const msg = syncEmailEngineMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        localStorage.removeItem("sync_email_type");
        localStorage.removeItem("name_to_sync");
        localStorage.removeItem("sync_type");
        localStorage.removeItem("email_alias");
        routeTo("sync", { code: null });
      },
      onError: (error) => {
        const msg = syncEmailEngineMsgHandler(error.status ?? 500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        localStorage.removeItem("sync_email_type");
        localStorage.removeItem("name_to_sync");
        localStorage.removeItem("sync_type");
        localStorage.removeItem("email_alias");
        routeTo("sync", { code: null });
      },
    },
  );

  // Update Email Engine name
  const updateEmailEngineName = useMutation(
    (data) => updateEmailEngineEmailName(data.emailType, data.id, data.payload),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = updateEmailEngineMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = updateEmailEngineMsgHandler(
          error.status ?? 500,
          error.data,
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // Desync Email Engine email
  const desyncEmailEngineEmail = useMutation(
    (data) => deleteEmailEngineEmailSync(data.id, data.payload),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = desyncEmailMsgHandler(200);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = desyncEmailMsgHandler(error.status ?? 500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // sets a default regular or automated email
  const setDefaultEmailAccounts = useMutation(
    (data) =>
      setDefaultEmailAccountsApi(
        data.type,
        data.payload,
        user.user_account?.account_id ?? null,
      ),
    {
      onSuccess: (response) => {
        queryClient.invalidateQueries("synced-accounts");
        const msg = setDefaultEmailAccountsMsgHandler(
          200,
          response.email_type,
          response.data.email,
        );
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = setDefaultEmailAccountsMsgHandler(error.status ?? 500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  return (
    <>
      <PageHeaderPanel
        iconClass="fa fa-refresh"
        title={out("Synchronisation courriel", "Sync Email Client")}
      />

      <Row className="mt-3">
        <Col xs={12} lg={6}>
          <EmailEngine
            user={user}
            accounts={{
              regular: emailAccounts?.regular?.email_engine?.length
                ? emailAccounts.regular.email_engine
                : [],
              automated: emailAccounts?.automated?.email_engine?.length
                ? emailAccounts.automated.email_engine
                : [],
            }}
            hasError={emailAccountsIsError}
            isLoading={emailAccountsIsLoading}
            setShowModal={setShowSyncEmailEngineModal}
            setShowNameModal={setShowUpdateNameModal}
            desyncEmail={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              desyncEmailEngineEmail.mutate(e);
            }}
            isDefaultEmailAccountsHandler={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              setDefaultEmailAccounts.mutate(e);
            }}
          />
        </Col>
        <Col xs={12} lg={6}>
          <Aws
            user={user}
            accounts={{
              regular: emailAccounts?.regular?.aws?.length
                ? emailAccounts.regular.aws
                : [],
              automated: emailAccounts?.automated?.aws?.length
                ? emailAccounts.automated.aws
                : [],
            }}
            hasError={emailAccountsIsError}
            isLoading={emailAccountsIsLoading}
            setShowModal={setShowSyncAwsEmailModal}
            setShowNameModal={setShowUpdateNameModal}
            desyncEmail={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              desyncAwsEmail.mutate(e);
            }}
            isDefaultEmailAccountsHandler={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              setDefaultEmailAccounts.mutate(e);
            }}
          />
        </Col>
      </Row>
      <Row>
        <Col xs={12} lg={6}>
          <Nylas
            user={user}
            accounts={{
              regular: emailAccounts?.regular?.nylas?.length
                ? emailAccounts.regular.nylas[0]
                : [],
              automated: emailAccounts?.automated?.nylas?.length
                ? emailAccounts.automated.nylas[0]
                : [],
            }}
            hasError={emailAccountsIsError}
            isLoading={emailAccountsIsLoading}
            syncCallbackLoading={syncCallbackLoading}
            reactivateAccountLoader={reactivateAccountLoader}
            setReactivateAccountLoader={setReactivateAccountLoader}
            setShowModal={setShowSyncNylasEmailModal}
            setShowNameModal={setShowUpdateNameModal}
            setShowMicrosoftLoginModal={setShowMicrosoftLoginModal}
            setShowSyncMSNylasEmailModal={setShowSyncMSNylasEmailModal}
            disableAccount={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              disableNylasAccount.mutate(e);
            }}
            enableAccount={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              enableNylasAccount.mutate(e);
            }}
            deleteAccount={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              deleteNylasAccount.mutate(e);
            }}
            parsedMSToken={parsedMSToken}
            refreshToken={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              refresMSToken.mutate(e);
            }}
            isDefaultEmailAccountsHandler={(e) => {
              dispatch(showLoadingBarWithoutMessage(200000));
              setDefaultEmailAccounts.mutate(e);
            }}
          />
        </Col>
      </Row>
      {/* modals */}
      {showSyncMSNylasEmailModal && (
        <SyncEmailModal
          show={showSyncMSNylasEmailModal}
          onHide={() => setShowSyncMSNylasEmailModal(false)}
          syncEmail={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            syncNylasEmailWithMS.mutate(e);
          }}
          syncType="Nylas-Microsoft"
          emailType={localStorage.getItem("sync_email_type")}
          parsedMSToken={parsedMSToken}
          parsedAccessToken={parsedAccessToken}
          loginToMS={() => {
            dispatch(showLoadingBarWithoutMessage(200000));
            loginWithMSAccount.mutate();
          }}
          showMismatchEmailMsg={showMismatchEmailMsg}
          setShowMismatchEmailMsg={setShowMismatchEmailMsg}
        />
      )}
      {showSyncNylasEmailModal && (
        <SyncEmailModal
          show={showSyncNylasEmailModal}
          onHide={() => setShowSyncNylasEmailModal(false)}
          syncEmail={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            authorizeEmail.mutate(e);
          }}
          setShowSyncEmailModal={setShowSyncNylasEmailModal}
          syncType="Nylas"
          emailType={localStorage.getItem("sync_email_type")}
        />
      )}
      {showSyncAwsEmailModal && (
        <SyncEmailModal
          show={showSyncAwsEmailModal}
          onHide={() => setShowSyncAwsEmailModal("")}
          syncEmail={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            syncAwsEmail.mutate(e);
          }}
          syncType="Aws"
          emailType={showSyncAwsEmailModal}
        />
      )}
      {showSyncEmailEngineModal && (
        <SyncEmailModal
          show={showSyncEmailEngineModal}
          onHide={() => setShowSyncEmailEngineModal("")}
          syncEmail={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            authorizeEmailEngineEmail.mutate(e);
          }}
          syncType="EmailEngine"
          emailType={showSyncEmailEngineModal}
        />
      )}
      {showUpdateNameModal && (
        <UpdateNameModal
          show={showUpdateNameModal}
          onHide={() => setShowUpdateNameModal("")}
          emailType={showUpdateNameModal}
          account={
            setSelectedEmailAccount(emailAccounts, showUpdateNameModal)[0]
          }
          updateName={(e) => {
            dispatch(showLoadingBarWithoutMessage(200000));
            if (showUpdateNameModal.match(/email-engine/g)) {
              updateEmailEngineName.mutate({
                emailType: showUpdateNameModal.replace(
                  /(email-engine-)(.*)/g,
                  `$2`,
                ),
                id: e.id,
                payload: { name: e.name },
              });
            } else if (showUpdateNameModal.match(/aws/g)) {
              updateAwsEmailName.mutate({
                emailType: showUpdateNameModal.replace(/(aws-)(.*)/g, `$2`),
                id: e.id,
                name: e.name,
              });
            } else if (showUpdateNameModal === "nylas-regular") {
              updateRegularNylasEmailName.mutate(e);
            } else if (showUpdateNameModal === "nylas-automated") {
              updateAutomatedNylasEmailName.mutate(e);
            }
          }}
        />
      )}
      {showMicrosoftLoginModal && (
        <MicrosoftLoginModal
          show={showMicrosoftLoginModal}
          onHide={() => setShowMicrosoftLoginModal(false)}
          login={() => {
            dispatch(showLoadingBarWithoutMessage(200000));
            loginWithMSAccount.mutate();
          }}
        />
      )}
    </>
  );
};

export default SyncPage;
