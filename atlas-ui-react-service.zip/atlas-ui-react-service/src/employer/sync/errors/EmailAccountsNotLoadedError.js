export class EmailAccountsNotLoadedError extends Error {
  constructor(message = "Email accounts not loaded") {
    super(message);

    this.message = message;
    this.name = "EmailAccountsNotLoadedError";
  }
}
