export class UndeterminedFolderError extends Error {
  constructor(message = "Unknown folder") {
    super(message);

    this.message = message;
    this.name = "UndeterminedFolderError";
  }
}
