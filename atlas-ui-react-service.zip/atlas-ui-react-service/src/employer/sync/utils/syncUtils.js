export const setNylasAccountStatus = (account) => {
  const msg = {};
  switch (account.sync_state) {
    case "running":
      msg.fr = "Actif";
      msg.en = "Active";
      break;
    case "initializing":
      msg.fr = "Actif";
      msg.en = "Active";
      break;
    case "downloading":
      msg.fr = "Actif";
      msg.en = "Active";
      break;
    case "partial":
      msg.fr = "Partiellement actif";
      msg.en = "Partially active";
      break;
    case "stopped":
      msg.fr = "Inactif";
      msg.en = "Inactive";
      break;
    case "invalid-credentials":
      msg.fr = "Informations d'identification invalide";
      msg.en = "Invalid credentials";
      break;
    case "exception":
      msg.fr = "Échec de la synchronisation";
      msg.en = "Synchronization failed";
      break;
    case "sync-error":
      msg.fr = "Échec de la synchronisation";
      msg.en = "Synchronization failed";
      break;
    default:
      msg.fr = "N/A";
      msg.en = "N/A";
  }
  return msg;
};

export const setAwsAccountStatus = (account) => {
  const msg = {};
  switch (account.verification_status) {
    case "Success":
      msg.fr = "Actif";
      msg.en = "Active";
      break;
    case "Pending":
      msg.fr = "En attente d'activation";
      msg.en = "Awaiting activation";
      break;
    case "Failed":
      msg.fr = "Échec de l'activation";
      msg.en = "Activation failed";
      break;
    case "TemporaryFailure":
      msg.fr = "Non disponible";
      msg.en = "Not available";
      break;
    default:
      msg.fr = "N/A";
      msg.en = "N/A";
  }
  return msg;
};

export const setEmailEngineAccountStatus = (account) => {
  const msg = {};
  switch (account.sync_state) {
    case "init":
    case "syncing":
    case "connecting":
      msg.fr = "Partiellement actif";
      msg.en = "Partially active";
      break;
    case "connected":
      msg.fr = "Actif";
      msg.en = "Active";
      break;
    case "authenticationError":
    case "connectError":
      msg.fr = "Échec de la synchronisation";
      msg.en = "Synchronization failed";
      break;
    case "unset":
    case "disconnected":
      msg.fr = "Non disponible";
      msg.en = "Not available";
      break;
    default:
      msg.fr = "N/A";
      msg.en = "N/A";
  }
  return msg;
};

export const setEmailType = (emailType) => {
  const msg = {};
  switch (emailType) {
    case "aws":
      msg.fr = "courriel de masse";
      msg.en = "mass/bulk email";
      break;
    case "nylas-regular":
      msg.fr = "courriel régulier";
      msg.en = "regular email";
      break;
    case "nylas-automated":
      msg.fr = "courriel automatisé";
      msg.en = "automated email";
      break;
    default:
      msg.fr = "courriel";
      msg.en = "email";
  }

  return msg;
};

// @unused it seems
/* export const isSynced = (syncState) =>
  ["running", "initializing", "downloading", "partial"].includes(syncState); */

export const setSelectedEmailAccount = (emailAccounts, key) => {
  const emailAccountsOnject = {
    "email-engine-regular": emailAccounts.regular.email_engine,
    "email-engine-automated": emailAccounts.automated.email_engine,
    "aws-regular": emailAccounts.regular.aws,
    "aws-automated": emailAccounts.automated.aws,
    "nylas-regular": emailAccounts.regular.nylas,
    "nylas-automated": emailAccounts.automated.nylas,
  };

  return emailAccountsOnject[key];
};

export const isAccountSynced = (syncedAccounts, type) => {
  return Object.values(syncedAccounts[type]).find((account) => {
    return type === "automated"
      ? account.length > 0 &&
          account[0].is_default > 0 &&
          ["running", "connected", "Success"].includes(
            account[0].sync_state ?? account[0].verification_status,
          )
      : account.length > 0 &&
          ["running", "connected", "Success"].includes(
            account[0].sync_state ?? account[0].verification_status,
          );
  });
};
