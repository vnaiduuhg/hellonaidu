import { composeEmailApi } from "employer/email/compose/api/composeEmailApi";
import {
  getFolders,
  getMessage,
  getMessagesInFolder,
} from "employer/email/inbox/apis/inboxApi";
import { Attachment } from "employer/email/compose/utils/attachment";
import { SyncProvider } from "./SyncProvider";
import { FolderNotAvailableFromSource } from "employer/email/inbox/errors/FolderNotAvailableFromSource";
import { UndeterminedFolderError } from "employer/sync/errors/UndeterminedFolderError";
import { QueryClient } from "react-query";

// use specialUse field to determine the folder path to map to for api calls
const folderNamesMap = new Map([
  ["inbox", "\\Inbox"],
  ["sent", "\\Sent"],
  ["trash", "\\Trash"],
  ["spam", "\\Junk"],
]);

export class EmailEngineProvider extends SyncProvider {
  MAXIMUM_FILE_SIZE = 1024 * 1024 * 5; // 5MB
  MAXIMUM_TOTAL_FILE_SIZE = 1024 * 1024 * 25; // 25MB

  _routeName = "email-engine";
  _cachedFolders = null;
  _cachedMappings = null;

  queryClient = null;

  constructor(account, type) {
    super(account, type, "email_engine");

    // inbox routes don't exist for  automated messages. remove this and add the
    // logic for providing this feature when needed
    if (this.type === "automated") {
      delete this.getMessagesInFolder;
      delete this.getMessage;
    }

    this.queryClient = new QueryClient();
  }

  get displayName() {
    return "EmailEngine";
  }

  get hasCustomizableSettings() {
    return true;
  }

  _cacheFoldersAndMappings = async () => {
    if (!this._cachedFolders || !this._cachedMappings) {
      let foldersResponse = await this.queryClient.getQueryData("folders");

      if (!foldersResponse) {
        const response = await getFolders(this._routeName);
        await this.queryClient.setQueryData("folders", response);
      }

      foldersResponse = await this.queryClient.getQueriesData("folders")[0][1];

      this._cachedFolders = foldersResponse.mailboxes;
      this._cachedMappings = foldersResponse.folder_mappings;
    }
  };

  getDefaultFolderPath = (folderKey, folders) => {
    return (
      folders.find((f) => {
        return f.specialUse === folderNamesMap.get(folderKey);
      })?.path ?? null
    );
  };

  // used to override path for a folder if a user has customized it in Email
  // settings
  getMappedFolderPath = (folderKey, mappings) => {
    const folderNamesMap = new Map(
      mappings.map((m) => [m.folder_name, m.folder_path]),
    );

    return folderNamesMap.get(folderKey);
  };

  get isEnabled() {
    /* https://api.emailengine.app/#section/Authentication
      status enums: 
        "init" "syncing" "connecting" "connected" "authenticationError" 
        "connectError" "unset" "disconnected"
    */

    return this.account.sync_state === "connected";
  }

  getMessagesInFolder = async ({ folder, limit, offset }) => {
    let messages = [];

    if (this.type === "regular") {
      try {
        let folderPath;

        // update folders from query cache if exists
        await this._cacheFoldersAndMappings();

        // get custom location
        folderPath = this.getMappedFolderPath(folder, this._cachedMappings);

        // if no cutom location, use default location
        if (!folderPath) {
          folderPath = this.getDefaultFolderPath(folder, this._cachedFolders);
        }

        // if neither custom nor default location are set, figure out whether
        // to alert user to go to settings and set their custom folder or
        // to tell them that that the inbox feature is not available from their
        // provider (eg: AWS)
        if (!folderPath) {
          if (this._cachedMappings.find((f) => f.folder_name === folder)) {
            throw new FolderNotAvailableFromSource();
          } else {
            throw new UndeterminedFolderError();
          }
        }

        const response = await getMessagesInFolder({
          provider: this._routeName,
          folder: folderPath,
          limit,
          offset,
        });

        if (!response.messages) {
          throw new Error("No messages found");
        }

        // not all fields are converted. Only the ones used currently by the
        // email module.
        messages = response.messages.map((message) => ({
          ...message,

          from: [
            message.from.name
              ? message.from
              : { ...message.from, name: message.from.address },
          ],
          body: null,
          snippet: null,
          unread: message.unseen,
          date: Math.floor(new Date(message.date) / 1000),
          thread_id: message.threadId,
        }));
      } catch (e) {
        throw e;
      }
    } else {
      throw new Error("viewing from automated accounts is not implemented");
    }

    return messages;
  };

  getMessage = async (messageId) => {
    try {
      const response = await getMessage(this._routeName, messageId);

      // Note: Only fields used by message view are converted. Convert more if
      // needed. Because the email view was based on Nylas, attachments were
      // never shown nor made downloadable. When this feature is added, that
      // should be unified
      const converted = {
        ...response,

        body: response.text?.html ?? response.text?.plain ?? "",
        from: [
          {
            name: response.from.name ?? "",
            email: response.from.address,
          },
        ],
        date: new Date(response.date).getTime() / 1000,
      };

      return converted;
    } catch (e) {
      throw e;
    }
  };

  sendEmail = async (params) => {
    const {
      to,
      cc,
      bcc,
      subject,
      body,
      attachments = [],
      threadId,
      messageId,
    } = params;

    const prefix = "messages[0]";
    const payload = new FormData();

    ["to", "cc", "bcc"].forEach((key) => {
      const field = params[key];

      field.forEach((recipientField, i) => {
        Object.keys(recipientField).forEach((fieldKey) => {
          payload.append(
            `${prefix}[${key}][${i}][${fieldKey}]`,
            recipientField[fieldKey],
          );
        });
      });
    });

    payload.append(`${prefix}[subject]`, subject);
    payload.append(`${prefix}[body]`, body);

    if (attachments?.length > 0) {
      attachments.forEach((attachment, i) => {
        if (attachment instanceof Attachment) {
          payload.append(
            `${prefix}[attachments][${i}][file]`,
            attachment.content,
            attachment.name,
          );
        } else {
          payload.append(
            `${prefix}[attachments][${i}][minio_file_path]`,
            attachment.minio_file_path,
          );
          payload.append(
            `${prefix}[attachments][${i}][minio_file_name]`,
            attachment.name,
          );
        }
      });
    }

    payload.append("email_engine_account_id", this.id);

    return await composeEmailApi(this._routeName, payload);
  };
}
