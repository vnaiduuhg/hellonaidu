import { AwsProvider } from "./AwsProvider";
import { EmailEngineProvider } from "./EmailEngineProvider";
import { NylasProvider } from "./NylasProvider";

export const providersMap = new Map([
  ["aws", AwsProvider],
  ["nylas", NylasProvider],
  ["email_engine", EmailEngineProvider],
]);
