import { UnsupportedFeature } from "employer/sync/components/UnsupportedFeature";

export class SyncProvider {
  constructor(account, type, provider) {
    this.account = account;
    this.type = type;
    this.provider = provider;
  }

  get id() {
    return this.account.id;
  }

  get email() {
    return this.account.email;
  }

  get isDefault() {
    return !!this.account.is_default;
  }

  get hasCustomizableSettings() {
    return false;
  }

  UnsupportedFeature = () => UnsupportedFeature(this.displayName ?? null);

  isAttachmentWithinSizeLimit = (size) => {
    return size <= this.MAXIMUM_FILE_SIZE;
  };

  areAllAttachmentsWithinSizeLimit = (total) => {
    return total <= this.MAXIMUM_TOTAL_FILE_SIZE;
  };
}

// Probably wont need these abstractions, but if further commonalities are found,
// they can be implemented in the base classes instead.

// export class CalendarSyncProviderAbstract extends SyncProviderAbstract {}

// export class EmailSyncProviderAbstract extends SyncProviderAbstract {}
