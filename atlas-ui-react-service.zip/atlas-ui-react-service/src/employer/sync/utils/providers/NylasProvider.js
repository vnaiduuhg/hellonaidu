import { composeEmailApi } from "employer/email/compose/api/composeEmailApi";
import { Attachment } from "employer/email/compose/utils/attachment";
import { uploadAttachment } from "employer/email/email-attachment/api/attachmentApi";
import {
  getMessage,
  getMessagesInFolder,
} from "employer/email/inbox/apis/inboxApi";
import { SyncProvider } from "./SyncProvider";

export class NylasProvider extends SyncProvider {
  MAXIMUM_FILE_SIZE = 1024 * 1024 * 5; // 5MB
  MAXIMUM_TOTAL_FILE_SIZE = 1024 * 1024 * 25; // 25MB

  _routeName = "nylas";

  constructor(account, type) {
    super(account, type, "nylas");

    // inbox routes don't exist for  automated messages. remove this and add the
    // logic for providing this feature when needed
    if (this.type === "automated") {
      delete this.getMessagesInFolder;
      delete this.getMessage;
    }
  }

  get displayName() {
    return "Nylas";
  }

  get isEnabled() {
    return this.account.sync_state === "running";
  }

  // API calls

  // inbox messages
  getMessagesInFolder = ({ folder, limit, offset }) => {
    if (this.type === "regular") {
      return getMessagesInFolder({
        provider: this.provider,
        folder,
        limit,
        offset,
      });
    } else {
      throw new Error("viewing from automated accounts is not implemented");
    }
  };

  // view message
  getMessage = (messageId) => {
    return getMessage(this.provider, messageId);
  };

  // compose
  sendEmail = async ({
    to,
    cc,
    bcc,
    subject,
    body,
    attachments,
    threadId,
    messageId,
  }) => {
    try {
      // upload attachments to nylas and get ids back
      let fileIds = [];

      if (attachments?.length) {
        try {
          fileIds = await Promise.all(
            attachments.map(async (attachment) => {
              let uploadPayload;
              if (attachment instanceof Attachment) {
                uploadPayload = new FormData();

                uploadPayload.append(
                  "file",
                  attachment.content,
                  attachment.name,
                );

                uploadPayload.append("nylas_account_id", this.id);
              } else {
                uploadPayload = {
                  minio_file_name: attachment.name,
                  minio_file_path: attachment.minio_file_path,
                  nylas_account_id: this.id,
                };
              }

              return (
                await uploadAttachment(this.provider, uploadPayload, true)
              )[0].id;
            }),
          );
        } catch (error) {
          throw error;
        }
      }

      const payload = {
        messages: [
          {
            to,
            cc: cc.filter((x) => !!x),
            bcc,
            subject,
            body,
            file_ids: fileIds,
          },
        ],
        nylas_account_id: this.id,
      };

      return composeEmailApi(this.provider, payload);
    } catch (error) {
      throw error;
    }
  };
}
