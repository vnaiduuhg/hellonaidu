import { composeEmailApi } from "employer/email/compose/api/composeEmailApi";
import { Attachment } from "employer/email/compose/utils/attachment";
import { SyncProvider } from "./SyncProvider";

export class AwsProvider extends SyncProvider {
  MAXIMUM_FILE_SIZE = 1024 * 1024 * 5; // 5MB
  MAXIMUM_TOTAL_FILE_SIZE = 1024 * 1024 * 10; // 10MB

  _routeName = "aws";

  constructor(account, type) {
    super(account, type, "aws");
  }

  get displayName() {
    return "AWS";
  }

  get isEnabled() {
    return this.account.verification_status === "Success";
  }

  sendEmail = async (params) => {
    const {
      to,
      cc,
      bcc,
      subject,
      body,
      attachments = [],
      threadId,
      messageId,
    } = params;

    const prefix = "messages[0]";
    const payload = new FormData();

    ["to", "cc", "bcc"].forEach((key) => {
      const field = params[key];

      field.forEach((recipientField, i) => {
        Object.keys(recipientField).forEach((fieldKey) => {
          payload.append(
            `${prefix}[${key}][${i}][${fieldKey}]`,
            recipientField[fieldKey],
          );
        });
      });
    });

    payload.append(`${prefix}[subject]`, subject);
    payload.append(`${prefix}[body]`, body);

    if (attachments?.length > 0) {
      attachments.forEach((attachment, i) => {
        if (attachment instanceof Attachment) {
          payload.append(
            `${prefix}[attachments][${i}][file]`,
            attachment.content,
            attachment.name,
          );
        } else {
          payload.append(
            `${prefix}[attachments][${i}][minio_file_path]`,
            attachment.minio_file_path,
          );
          payload.append(
            `${prefix}[attachments][${i}][minio_file_name]`,
            attachment.name,
          );
        }
      });
    }

    payload.append("aws_email_identity_id", this.id);

    return composeEmailApi(this.provider, payload);
  };
}
