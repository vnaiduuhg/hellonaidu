import { out } from "global/utils/useTranslation";
import { setEmailType } from "./syncUtils";

const tokenExpiredMsg = {
  title: out("Votre session est expirée!", "Your session has expired!"),
  text: out("Veuillez vous connecter à nouveau", "Please login again"),
};

export const getSyncedEmailAccountsMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour consulter les information des comptes Email Engine, AWS et Nylas",
        "You do not have the required permission to consult Email Engine, AWS and Nylas accounts information",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Les informations des comptes Email Engine, AWS et Nylas n'ont pu être récupérées",
        "Email Engine, AWS and Nylas accounts information could not be retrieved",
      );
  }

  return msg;
};

export const syncEmailMsgHandler = (code, data = null) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été synchronisé avec succès!",
        "The email has been successfully synced!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise",
        "You do not have the required permission",
      );
      break;
    case 422:
      if (
        data?.email?.length > 0 &&
        data.email[0] === "The email has already been taken."
      ) {
        msg.title = out("Courriel déjà utilisé!", "Email already taken!");
        msg.text = out(
          "Vous ne pouvez synchroniser deux fois la même adresse courielle avec AWS",
          "You cannot sync the same email address twice with AWS",
        );
        break;
      }
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de synchronization, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred in the synchronization process, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const microsoftSyncEmailMsgHandler = (code, message = null) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été synchronisé avec succès avec votre compte Microsoft!",
        "The email has been successfully synced with your Microsoft account!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise",
        "You do not have the required permission",
      );
      break;
    case 400:
      if (message && message === "Invalid or revoked refresh token") {
        msg.title = out(
          "Échec de la synchronisation!",
          "Synchronization failed!",
        );
        msg.text = out(
          "Assurez-vous d'abord de synchroniser avec un compte Microsoft professionnel ou scolaire, ou contacter support@workland.com si le problème persiste",
          "Make sure first to sync with a business or school Microsoft account, or contact support@workland.com if the issue persists",
        );
        break;
      }
      const regExp =
        /The Office365 refresh token you provided doesn't have the necessary scopes to sync the Nylas scopes you passed/g;
      if (message && regExp.test(message)) {
        msg.title = out(
          "Échec de l'authentification!",
          "Authentication failed!",
        );
        msg.text = out(
          "Ce compte Microsoft Office365 ne dispose pas des autorisations nécessaires pour être synchronisé avec Nylas, veuillez contacter l'administrateur du compte Microsoft Office365 ou support@workland.com pour obtenir de l'aide",
          "This Microsoft Office365 account does not have the necessary permissions to sync with Nylas, please contact the Microsoft Office365 account administrator or support@workland.com for assistance",
        );
        break;
      }
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de synchronization de votre compte Microsoft, veuillez contacter support@workland.com si le problème persiste",
        "There was an error in the process of syncing your Microsoft account, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const disableNylasEmailMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été désactivé avec succès!",
        "The email has been successfully deactivated!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour désactiver ce courriel",
        "You do not have the required permission to deactivate this email",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de désactivation, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred in the deactivation process, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const enableNylasEmailMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été résactivé avec succès! Veuillez noter que le délai pour réactiver votre compte peut prendre un certain temps, si votre compte n'est toujours pas réactivé après une minute, veuillez rafraîchir la page",
        "The email has been successfully reactivated! Please note that it may take some time to reactivate your account, if your account is still not reactivated after one minute, please refresh the page",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour résactiver ce courriel",
        "You do not have the required permission to reactivate this email",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de résactivation, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred in the reactivation process, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const desyncEmailMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "La synchronisation du courriel a été supprimée avec succès!",
        "Email synchronization has been deleted successfully",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour désynchroniser de ce courriel",
        "You do not have the required permission to desynchronize this email",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de suppression de la synchronisation, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred in the synchronization deletion process, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const deleteAwsEmailMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été désynchronisé avec succès!",
        "The email has been successfully desynchronized!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour désynchroniser ce courriel",
        "You do not have the required permission to desynchronize this email",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le courriel n'a pu être désynchronisé",
        "The email could not be desynchronised",
      );
  }

  return msg;
};

export const updateEmailNameMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le nom a été modifié avec succès!",
        "The name has been successfully updated!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier le nom du courriel",
        "You do not have the required permission to update email's name",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le nom du courriel n'a pu être modifié",
        "The email name could not be updated",
      );
  }

  return msg;
};

export const microsoftNoBusinessMsgHandler = () => {
  return {
    title: out("Attention!", "Warning!"),
    text: out(
      "Nous détectons une connexion avec un compte Microsoft non autorisé pour la synchronisation avec Nylas, veuillez vous assurer de vous connecter avec un compte Microsoft professionnel ou scolaire",
      "We detect a connection with an unauthorized Microsoft account for synchronization with Nylas, please make sure to sign in with a business or school Microsoft account",
    ),
  };
};

export const setDefaultEmailAccountsMsgHandler = (code, emailType, email) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");

      msg.text =
        emailType === "regular"
          ? out(
              `${email} a été défini comme courriel régulier par défaut`,
              `${email} has been set as default regular email`,
            )
          : out(
              `${email} a été défini comme courriel automatique par défaut`,
              `${email} has been set as default automated email`,
            );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour définir ce courriel par défaut",
        "You do not have the required permission to set this email as default",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le courriel n'a pu être défini par défaut",
        "The email could not be set as default",
      );
  }

  return msg;
};

export const syncEmailEngineMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le courriel a été synchronisé avec succès!",
        "The email has been successfully synced!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise",
        "You do not have the required permission",
      );
      break;
    case 422:
      msg.title = out("Erreur!", "Erreur!");
      msg.text = out(
        "Il manque des informations pour terminer la synchronisation, veuillez recommencer en veillant à remplir tous les champs requis. Contacter support@workland.com si le problème persiste",
        "Information is missing in order to complete the synchronization, please start over, making sure to fill in all the required fields. Contact support@workland.com if the problem persists",
      );
      break;
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite dans le processus de synchronization, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred in the synchronization process, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};

export const updateEmailEngineMsgHandler = (code, data = null) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Le nom a été modifié avec succès!",
        "The name has been modifed successfully!",
      );
      break;
    case 401:
      msg = tokenExpiredMsg;
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise",
        "You do not have the required permission",
      );
      break;
    case 422:
      if (data?.name && data.name[0] === "The name field is required.") {
        msg.title = out("Erreur!", "Erreur!");
        msg.text = out("Le nom est manquant", "Name is missing");
        break;
      }
    default:
      msg.title = out("Attention!", "Warning!");
      msg.text = out(
        "Une erreur s'est produite et le nom n'a pu être modifié, veuillez contacter support@workland.com si le problème persiste",
        "An error occurred and the name could not be modified, please contact support@workland.com if the problem persists",
      );
  }

  return msg;
};
