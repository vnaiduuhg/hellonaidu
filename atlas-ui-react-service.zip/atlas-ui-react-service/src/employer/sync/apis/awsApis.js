import {
  getRestrictedApi,
  postRestrictedApi,
  deleteRestrictedApi,
  patchRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getAwsAccount = async (accountId) => {
  const reponse = await getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/aws-automated-email-identities`,
    getToken(),
  );

  return reponse;
};

export const postAwsEmailSync = async (type, data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `aws/${type}-email-identities`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteAwsEmailSync = async (type, id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.messaging,
      `aws/${type}-email-identities/${id}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateAwsSyncedEmailName = async (type, id, data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.messaging,
      `aws/${type}-email-identities`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
