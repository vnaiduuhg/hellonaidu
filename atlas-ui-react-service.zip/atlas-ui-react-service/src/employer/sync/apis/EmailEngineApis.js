import {
  getRestrictedApi,
  postRestrictedApi,
  patchRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getEmailEngineEmailAuthorization = async (params) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.messaging,
      `email-engine/authorization-url`,
      getToken(),
      params,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const postEmailEngineEmailSync = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `email-engine/sync-account`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateEmailEngineEmailName = async (type, id, data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.messaging,
      `email-engine/${type}-accounts`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteEmailEngineEmailSync = async (id, data) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.messaging,
      `email-engine/accounts/${id}`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
