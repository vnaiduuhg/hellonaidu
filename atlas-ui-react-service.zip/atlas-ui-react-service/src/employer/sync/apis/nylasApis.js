import {
  getRestrictedApi,
  postRestrictedApi,
  patchRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getNylasAccounts = async () => {
  const reponse = await getRestrictedApi(
    serviceNames.messaging,
    "nylas/accounts",
    getToken(),
  );

  return reponse;
};

export const getEmailAuthorization = async (email) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.messaging,
      `nylas/authorize?email=${email}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const postNylasEmailSync = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `nylas/sync-account`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const disableNylasEmailSync = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `nylas/disable`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const enableNylasEmailSync = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `nylas/reactivate`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteNylasEmailSync = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `nylas/delete`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateNylasAutomatedEmailName = async (id, data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.messaging,
      `nylas/automated-accounts`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateNylasRegularEmailName = async (id, data) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.messaging,
      `nylas/regular-accounts`,
      getToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const syncNylasEmailWithMicrosoft = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `nylas/sync-account-oauth`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
