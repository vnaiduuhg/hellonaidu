import { memo } from "react";
import { DocumentViewer } from "global/components/DocumentViewer/DocumentViewer";

export const JobDocumentViewer = memo(({ document, onLoad }) => (
  <DocumentViewer
    path={document.url}
    fileName={document.file_name}
    onLoad={onLoad}
  />
));
