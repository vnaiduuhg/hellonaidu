import { Card } from "react-bootstrap";
import { JobDocumentReusableEditor } from "./JobDocumentReusableEditor";
import styles from "../styles/UploadDocumentsJob.module.scss";

export const JobDocumentCreatorContainer = ({ job, onUpload }) => (
  <Card className={styles.creatorContainer}>
    <Card.Body>
      <JobDocumentReusableEditor
        mode="create"
        job={job}
        onSubmit={onUpload}
        document={null}
      />
    </Card.Body>
  </Card>
);
