import { ComponentLoader } from "global/components/loaders/component-loader";
import { useTranslation } from "global/utils/useTranslation";
import { useJobDocuments } from "../hooks/useJobDocuments";
import { useMemo } from "react";
import { AtlasSelect } from "global/components/select/atlas-select";

export const JobDocumentsSelector = ({ jobId, value, onChange, ...rest }) => {
  const { documents, isFetched } = useJobDocuments({ jobId });

  const { out } = useTranslation();

  const translations = useMemo(() => {
    if (!documents) return new Map();

    const map = new Map();
    documents.forEach((d) => {
      d.translations.forEach((t) => {
        map.set(`${d.id}:${t.locale}`, t.title);
      });
    });

    return map;
  }, [documents]);

  if (!isFetched) {
    return <ComponentLoader />;
  }

  const options = (documents ?? []).map((document) => {
    return {
      value: document.id,
      label: out(
        translations.get(`${document.id}:fr`) ??
          `[EN] ${translations.get(`${document.id}:en`)}`,
        translations.get(`${document.id}:en`) ??
          `[FR] ${translations.get(`${document.id}:fr`)}`,
      ),
    };
  });

  if (isFetched && !documents?.length) {
    return null;
  }

  return (
    <AtlasSelect
      placeholder={out("Sélectionnez un document", "Select a document")}
      options={options}
      isClearable={true}
      value={options.find((o) => o.value === value) ?? null}
      onChange={(attachment) => {
        if (attachment) {
          onChange(attachment.value);
        } else {
          onChange(null);
        }
      }}
      {...rest}
    />
  );
};
