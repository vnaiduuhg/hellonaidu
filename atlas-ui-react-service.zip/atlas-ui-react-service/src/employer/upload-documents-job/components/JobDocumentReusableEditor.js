import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import PropTypes from "prop-types";
import { useSelector } from "react-redux";
import cx from "classnames";
import { Button, FloatingLabel, Form } from "react-bootstrap";
import { BiUpload } from "react-icons/bi";
import { IoCloseOutline } from "react-icons/io5";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../styles/UploadDocumentsJob.module.scss";

export const JobDocumentReusableEditor = ({
  mode, // "create" or "update"
  job,
  onSubmit,
  document = null,
}) => {
  const $fileInput = useRef(null);
  const [file, setFile] = useState("");
  const [titleFr, setTitleFr] = useState("");
  const [titleEn, setTitleEn] = useState("");
  const [isFrenchEnabled, setIsFrenchEnabled] = useState(!!titleFr);
  const [isEnglishEnabled, setIsEnglishEnabled] = useState(!!titleEn);
  const [visibleInternally, setVisibleInternally] = useState(false);
  const [visibleExternally, setVisibleExternally] = useState(false);

  const { language } = useSelector((state) => state.user);
  const { out } = useTranslation();

  useEffect(() => {
    const defaultTitle = new Map(
      (document?.translations ?? []).map((translation) => [
        translation.locale,
        translation.title,
      ]),
    );

    setTitleFr(defaultTitle.get("fr") ?? "");
    setTitleEn(defaultTitle.get("en") ?? "");

    setIsFrenchEnabled(
      mode === "create" ? language === "fr" : !!defaultTitle.get("fr"),
    );
    setIsEnglishEnabled(
      mode === "create" ? language === "en" : !!defaultTitle.get("en"),
    );

    if (!document) {
      setVisibleInternally(!!job?.published_internal);
      setVisibleExternally(!!job?.published_external);
    } else {
      setVisibleInternally(!!document?.is_visible_to_internal_candidates);
      setVisibleExternally(!!document?.is_visible_to_external_candidates);
    }
    setFile("");
  }, [document, job, language, mode]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!passValidation) {
      return;
    }

    onSubmit({
      documentId: mode === "update" ? document.id : null,
      titleEn: isEnglishEnabled ? titleEn.trim() : null,
      titleFr: isFrenchEnabled ? titleFr.trim() : null,
      visibleInternally,
      visibleExternally,
      file: mode === "create" ? file : null,
    });

    // reset after submission
    if (mode === "create") {
      setTitleEn("");
      setTitleFr("");
      setVisibleInternally(!!job?.published_internal);
      setVisibleExternally(!!job?.published_external);
      setFile("");
    }
  };

  const clearFile = useCallback(() => setFile(""), []);

  const passValidation = useMemo(() => {
    if (isEnglishEnabled && !titleEn.trim()) return false;
    if (isFrenchEnabled && !titleFr.trim()) return false;

    if (mode === "create" && !file) return false;

    return true;
  }, [isEnglishEnabled, isFrenchEnabled, mode, titleEn, titleFr, file]);

  const changesMade = useMemo(() => {
    if (document) {
      const defaultTitle = new Map(
        (document?.translations ?? []).map((translation) => [
          translation.locale,
          translation.title,
        ]),
      );

      if (defaultTitle.get("fr") !== titleFr.trim()) return true;
      if (defaultTitle.get("en") !== titleEn.trim()) return true;
      if (!!document?.is_visible_to_internal_candidates !== visibleInternally)
        return true;
      if (!!document?.is_visible_to_external_candidates !== visibleExternally)
        return true;

      if (
        (isFrenchEnabled && !defaultTitle.get("fr")) ||
        (!isFrenchEnabled && defaultTitle.get("fr"))
      )
        return true;
      if (
        (isEnglishEnabled && !defaultTitle.get("en")) ||
        (!isEnglishEnabled && defaultTitle.get("en"))
      )
        return true;
    }

    return false;
  }, [
    document,
    titleFr,
    titleEn,
    visibleInternally,
    visibleExternally,
    isFrenchEnabled,
    isEnglishEnabled,
  ]);

  // console.log({ changesMade, passValidation });

  return (
    <>
      <form onSubmit={handleSubmit}>
        <label className={styles.toggleBubbles}>
          <div className="form-check form-switch">
            <input
              type="checkbox"
              role="switch"
              className="form-check-input"
              id="blah"
              checked={isFrenchEnabled && isEnglishEnabled}
              onChange={({ target: { checked } }) => {
                if (checked) {
                  setIsFrenchEnabled(true);
                  setIsEnglishEnabled(true);
                } else {
                  if (language === "fr") {
                    setIsEnglishEnabled(false);
                  } else {
                    setIsFrenchEnabled(false);
                  }
                }
              }}
            />

            <span className="form-check-label pointer">
              {isFrenchEnabled && isEnglishEnabled
                ? out("Document bilingue", "Bilingual document")
                : out("Document en français", "Engilsh document")}
            </span>
          </div>
        </label>

        <div
          className={cx("d-flex flex-column my-2", {
            "flex-column-reverse ": language === "en",
          })}
        >
          {(language === "fr" || (language === "en" && isFrenchEnabled)) && (
            <FloatingLabel
              label={out("Titre", "Title (French)")}
              className="mb-2"
            >
              <Form.Control
                type="text"
                placeholder=" "
                value={titleFr}
                onChange={({ target: { value } }) => setTitleFr(value)}
              />
            </FloatingLabel>
          )}
          {(language === "en" || (language === "fr" && isEnglishEnabled)) && (
            <FloatingLabel
              label={out("Titre en anglais", "Title")}
              className="mb-2"
            >
              <Form.Control
                type="text"
                placeholder=" "
                value={titleEn}
                onChange={({ target: { value } }) => setTitleEn(value)}
              />
            </FloatingLabel>
          )}
        </div>

        {mode === "create" && (
          <div className="d-flex my-3">
            <div>
              {/* button */}
              <Button
                size="lg-float"
                variant="secondary"
                onClick={() => $fileInput.current.click()}
              >
                <BiUpload />
              </Button>
            </div>
            <div className="flex-grow-1 px-3">
              {/* attachment */}
              <div className="fw-bold">
                {out("Fichier joint : ", "Attached file: ")}
              </div>
              <div className="d-flex">
                {file ? (
                  <div className={styles.bubblesContainer}>
                    <div className={styles.bubble}>
                      <button
                        className={styles.closeBubble}
                        onClick={clearFile}
                      >
                        <IoCloseOutline />
                      </button>
                      {/* TODO: handle multiline filename */}
                      <div className={styles.bubbleContent}>{file.name}</div>
                    </div>
                  </div>
                ) : (
                  <div className="py-1 text-muted">
                    <em>
                      [ {out("Aucun fichier joint", "No files attached")} ]
                    </em>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="my-3">
          <div className="fw-bold">
            {out("Visibilité du document : ", "Document visibility: ")}
          </div>
          <div className="d-flex flex-wrap px-3 user-select-none">
            <div className="flex-grow-1">
              <Form.Check type="checkbox" className="me-3 my-1">
                <Form.Check.Input
                  id={`${document?.id ?? ""}-attach-internal`}
                  type="checkbox"
                  checked={visibleInternally}
                  onChange={({ target: { checked } }) =>
                    setVisibleInternally(checked)
                  }
                />
                <Form.Check.Label
                  htmlFor={`${document?.id ?? ""}-attach-internal`}
                >
                  {out("Affichage interne", "Internal posting")}
                </Form.Check.Label>
              </Form.Check>
            </div>
            <div className=" flex-grow-1">
              <Form.Check type="checkbox" className="my-1">
                <Form.Check.Input
                  id={`${document?.id ?? ""}-attach-external`}
                  type="checkbox"
                  checked={visibleExternally}
                  onChange={({ target: { checked } }) =>
                    setVisibleExternally(checked)
                  }
                />
                <Form.Check.Label
                  htmlFor={`${document?.id ?? ""}-attach-external`}
                >
                  {out("Affichage externe", "External posting")}
                </Form.Check.Label>
              </Form.Check>
            </div>
          </div>
        </div>

        {/* add new document */}
        {/* upload new pdf */}
        <Button
          variant="primary"
          size="lg"
          // className="w-100"
          disabled={!passValidation || (mode === "update" && !changesMade)}
          type="submit"
        >
          {mode === "create"
            ? out("Joindre le document", "Attach Document")
            : out("Mise à jour des changements", "Update changes")}
        </Button>
        <input
          ref={$fileInput}
          type="file"
          accept="application/pdf"
          onChange={({ target: { files } }) => {
            if (files?.length) {
              setFile(files[0]);
            } else {
              setFile("");
            }
          }}
          value=""
          multiple={false}
          hidden
        />
      </form>
    </>
  );
};

JobDocumentReusableEditor.prototype = {
  mode: PropTypes.oneOf(["create", "update"]).isRequired,
  id: PropTypes.string.isRequired,
  job: PropTypes.object.isRequired,
  onSubmit: PropTypes.func.isRequired,
  document: PropTypes.object,
};
