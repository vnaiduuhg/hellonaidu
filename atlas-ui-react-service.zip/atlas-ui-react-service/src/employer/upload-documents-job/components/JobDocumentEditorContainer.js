import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Button, Card, Modal, OverlayTrigger, Tooltip } from "react-bootstrap";
import { BiEdit, BiTrash } from "react-icons/bi";
import { AiFillInfoCircle } from "react-icons/ai";
import cx from "classnames";
import { useTranslation } from "global/utils/useTranslation";
import { JobDocumentReusableEditor } from "./JobDocumentReusableEditor";
import styles from "../styles/UploadDocumentsJob.module.scss";

export const JobDocumentEditorContainer = ({
  job,
  document,
  onEdit,
  onDelete,
}) => {
  const [promptDelete, setPromptDelete] = useState(false);
  const [mode, setMode] = useState("view");

  const { language } = useSelector((state) => state.user);
  const { out } = useTranslation();

  const title = new Map(
    (document?.translations ?? []).map((translation) => [
      translation.locale,
      translation.title,
    ]),
  );

  const handleDelete = useCallback(() => {
    setPromptDelete(true);
  }, []);

  const handleEdit = useCallback(() => {
    setMode((current) => (current === "edit" ? "view" : "edit"));
  }, []);

  // switch to view mode when document changes from the dropdown
  useEffect(() => setMode("view"), [document]);

  return (
    <div>
      <Card className={styles.editorContainer}>
        <Card.Body>
          <div id={styles.editorNavigationPanel}>
            <Button
              variant="secondary"
              className={cx("btn-frameless-icon mx-1 fs-5", {
                [styles.editMode]: mode === "edit",
              })}
              title={out("Modifier", "Update")}
              onClick={handleEdit}
            >
              <BiEdit />
            </Button>

            <Button
              variant="danger"
              className="btn-frameless-icon ms-1 fs-5"
              title={out("Supprimer", "Delete")}
              onClick={handleDelete}
            >
              <BiTrash />
            </Button>
          </div>

          {/* start view mode */}
          <div
            className={cx({
              "d-none": mode === "edit",
            })}
          >
            <div
              className={cx("d-flex flex-column", {
                "flex-column-reverse": language === "en",
              })}
            >
              {title.has("fr") && (
                <div>
                  <span className="fw-bold">
                    {out("Titre : ", "Title (French): ")}
                  </span>
                  <span>{title.get("fr")}</span>
                </div>
              )}
              {title.has("en") && (
                <div>
                  <span className="fw-bold">
                    {out("Titre en anglais : ", "Title: ")}
                  </span>
                  <span>{title.get("en")}</span>
                </div>
              )}
            </div>
            <hr />
            <div>
              <span className="fw-bold">
                {out("Nom de fichier : ", "Filname: ")}
              </span>
              <span>{document?.file_name}</span>

              {/* info */}
              <OverlayTrigger
                delay={{ show: 100, hide: 250 }}
                overlay={
                  <Tooltip className="fs-6">
                    <div className="p-2">
                      {out(
                        "Malheureusement, il n'est pas possible de modifier le fichier joint. Si vous souhaitez remplacer le document, veuillez supprimer le présent document et en téléverser un nouveau.",
                        "Unfortunately, it is not possible to change the attached file. If you wish to replace the it, please delete this document and upload a new one in its place.",
                      )}
                    </div>
                  </Tooltip>
                }
              >
                <span className="p-1">
                  <AiFillInfoCircle className="text-secondary mb-1 mx-1 fs-5" />
                </span>
              </OverlayTrigger>
            </div>
            <hr />
            <div>
              <span className="fw-bold">
                {out(
                  "Visible à l'affichage interne : ",
                  "Visible to internal posting: ",
                )}
              </span>
              <span>
                {document?.is_visible_to_internal_candidates ? "Yes" : "No"}
              </span>
            </div>
            <div>
              <span className="fw-bold">
                {out(
                  "Visible à l'affichage externe : ",
                  "Visible to external posting: ",
                )}
              </span>
              <span>
                {document?.is_visible_to_external_candidates ? "Yes" : "No"}
              </span>
            </div>
          </div>
          {/* end view mode */}

          {/* start editor mode */}
          <div
            className={cx({
              "d-none": mode === "view",
            })}
          >
            <JobDocumentReusableEditor
              mode="update"
              job={job}
              document={document}
              onSubmit={async (...rest) => {
                await onEdit(...rest);
                setMode("view");
              }}
              resetAfterSubmit={false}
            />
          </div>
          {/* end edit mode */}
        </Card.Body>
      </Card>

      <Modal
        show={promptDelete}
        onHide={() => {
          setPromptDelete(false);
        }}
        backdrop="static"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {out("Confirmer la suppression", "Confirm delete")}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
            {out(
              "Êtes-vous sûr de vouloir supprimer ce document ? Cette action ne peut être annulée.",
              "Are you sure you want to delete this document? This action cannot be undone.",
            )}
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="danger"
            onClick={() => {
              onDelete(document.id);
              setPromptDelete(false);
            }}
          >
            {out("Confirmer", "Confirm")}
          </Button>
          <Button
            variant="outline-secondary"
            onClick={() => setPromptDelete(false)}
          >
            {out("Annuler", "Cancel")}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};
