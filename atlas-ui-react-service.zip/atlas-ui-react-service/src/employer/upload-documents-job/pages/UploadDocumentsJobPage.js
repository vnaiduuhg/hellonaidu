import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Accordion, Alert, Card } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import { JobDocumentCreatorContainer } from "../components/JobDocumentCreatorContainer";
import { JobHeader } from "global/components/JobHeader/JobHeader";
import styles from "../styles/UploadDocumentsJob.module.scss";
import { JobDocumentsSelector } from "../components/JobDocumentsSelector";
import { JobDocumentEditorContainer } from "../components/JobDocumentEditorContainer";
import { useJobDocuments } from "../hooks/useJobDocuments";
import { JobDocumentViewer } from "../components/JobDocumentViewer";
import { useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import statusMessagesSlice, {
  showMessage,
} from "global/store/statusMessagesSlice";
import cx from "classnames";
import {
  attachDocumentUploadErrorMessageHandler,
  listDocumentUploadsErrorMessageHandler,
} from "../utils/documentUploadErrorMessageHandler";
import { uploadJobDescriptionDocument } from "../api/jobDescriptionDocumentsApi";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";
import { FaInfoCircle } from "react-icons/fa";

const UploadDocumentsJobPage = () => {
  const [currentlyPreviewingDocumentId, setCurrentlyPreviewingDocumentId] =
    useState(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  const { jobId } = useParams();
  const { out } = useTranslation();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    window.document.title = out(
      "Document de description de poste - Workland",
      "Job Description Document - Workland",
    );

    return () => {
      // clear loader in case it's running when leaving the page
      dispatch(statusMessagesSlice.actions.clearLoaders());
    };
  }, [dispatch, out]);

  const { job, documents, editDocument, deleteDocument, isFetched, isError } =
    useJobDocuments({
      jobId,
      onError: (error) => {
        const msg = listDocumentUploadsErrorMessageHandler(
          error?.response?.status,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      },
      onSuccess: (job) => {
        // select the first document by default if there are any
        if (job && job.description_documents?.length) {
          setCurrentlyPreviewingDocumentId(job.description_documents[0].id);
        }
      },
    });

  const currentlyPreviewingDocument = useMemo(
    () =>
      documents?.find(
        (document) => document.id === currentlyPreviewingDocumentId,
      ) ?? null,
    [documents, currentlyPreviewingDocumentId],
  );

  const attachNewDocument = useCallback(
    async ({
      file,
      titleEn,
      titleFr,
      visibleInternally,
      visibleExternally,
    }) => {
      dispatch(
        showMessage(
          "loading",
          out("Televersement...", "Uploading..."),
          null,
          60000,
        ),
      );

      const payload = new FormData();
      payload.append("upload_type", "file");
      payload.append(
        "file",
        new Blob([file], { type: "application/pdf" }),
        file.name,
      );
      payload.append("is_visible_to_external_candidates", +visibleExternally);
      payload.append("is_visible_to_internal_candidates", +visibleInternally);

      if (titleFr) {
        payload.append("translations[0][locale]", "fr");
        payload.append("translations[0][title]", titleFr);
      }
      if (titleEn) {
        payload.append("translations[1][locale]", "en");
        payload.append("translations[1][title]", titleEn);
      }

      try {
        const response = await uploadJobDescriptionDocument(jobId, payload);

        await queryClient.invalidateQueries("jobs");
        setCurrentlyPreviewingDocumentId(response.id);

        // add a timeout so it doesn't stutter when all animations are running at the same time
        setTimeout(() => {
          dispatch(
            showMessage(
              "ok",
              out("Succes", "Success"),
              out(
                "Le document a été televersé.",
                "The document has been uploaded.",
              ),
              5000,
            ),
          );
        }, 250);
      } catch (error) {
        const msg = attachDocumentUploadErrorMessageHandler(
          error?.response?.status,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      } finally {
        dispatch(statusMessagesSlice.actions.clearLoaders());
      }
    },
    [dispatch, jobId, out, queryClient, history],
  );

  return (
    <div>
      <JobHeader jobId={jobId} job={job} />

      <div className={`mt-3 py-0 px-3 ${styles.rightPanelsContainer}`}>
        <div className="row">
          {/* order this first on mobile, to the right (end) for large screens */}
          <div className="col-12 col-md-4 order-md-last">
            {/* editor */}

            <div className="mb-3" hidden={isFetched && !documents?.length}>
              {/* picker */}
              <Card>
                <Card.Header id={styles.showAttachedDocumentsPanelHeader}>
                  {out(
                    "Afficher les documents joints",
                    "Show attached documents",
                  )}
                </Card.Header>
                <Card.Body>
                  <JobDocumentsSelector
                    jobId={jobId}
                    value={currentlyPreviewingDocumentId}
                    onChange={(id) => {
                      setIsPreviewLoading(!!id);
                      setCurrentlyPreviewingDocumentId(id);
                    }}
                  />
                </Card.Body>
              </Card>
            </div>

            <div className="mb-3">
              <Accordion activeKey={currentlyPreviewingDocumentId}>
                <Accordion.Item eventKey={null}>
                  <Accordion.Header
                    className={styles.sectionHeader}
                    onClick={() => {
                      if (currentlyPreviewingDocumentId) {
                        setCurrentlyPreviewingDocumentId(null);
                      }
                    }}
                  >
                    {out("Joindre un document", "Attach a Document")}
                  </Accordion.Header>
                  <Accordion.Body>
                    <JobDocumentCreatorContainer
                      job={job}
                      onUpload={attachNewDocument}
                    />
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </div>

            <Accordion
              className={cx({
                [styles.hideEditor]: !currentlyPreviewingDocumentId,
                [styles.showEditor]: !!currentlyPreviewingDocumentId,
              })}
              // use string "1" or "0" as key so it stays open as long as documents
              // are swtiched but closes when none are shown (null)
              activeKey={"" + +!!currentlyPreviewingDocumentId}
            >
              <Accordion.Item eventKey={"" + +!!currentlyPreviewingDocumentId}>
                <Accordion.Header
                  className={styles.sectionHeader}
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentlyPreviewingDocumentId(null);
                  }}
                >
                  {out("Modifier le document", "Update Document")}
                </Accordion.Header>
                <Accordion.Body>
                  {/* update document */}
                  {jobId && currentlyPreviewingDocumentId && (
                    <JobDocumentEditorContainer
                      job={job}
                      document={currentlyPreviewingDocument}
                      onEdit={async (...rest) => {
                        await editDocument(...rest);
                        setCurrentlyPreviewingDocumentId(
                          currentlyPreviewingDocumentId,
                        );
                      }}
                      onDelete={async (...rest) => {
                        const idOfDocToDelete = currentlyPreviewingDocumentId;
                        await deleteDocument(...rest);

                        const remainingDocs = documents.filter(
                          (doc) => doc.id !== idOfDocToDelete,
                        );

                        if (remainingDocs?.length) {
                          setCurrentlyPreviewingDocumentId(remainingDocs[0].id);
                        } else {
                          setCurrentlyPreviewingDocumentId(null);
                        }
                      }}
                    />
                  )}
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </div>

          <div className="col-12 col-md-8 order-md-first">
            <div className="mb-2">
              <PageHeaderPanel
                title={out(
                  "Téléverser des documents",
                  "Upload Documents to Job",
                )}
                subtitle={out(
                  "Vous pouvez y téléverser un ou plusieurs documents pour l'emploi et définir leur visibilité pour les candidats.",
                  "Here you can upload one or more documents to the job and set their visibility to candidates.",
                )}
                iconClass="bi bi-file-earmark-richtext"
              />
            </div>

            {(isPreviewLoading || !isFetched) && <NestedPageLoader wait />}

            {isFetched && !isError && !documents?.length && (
              <Alert variant="info">
                <h5>
                  <FaInfoCircle className="me-2" />
                  {out(
                    "Ce poste n'a pas de documents joints",
                    "This job has no attached documents",
                  )}
                </h5>
                {out(
                  "Vous pouvez utiliser le panneau latéral pour ajouter un ou plusieurs documents qui seront visibles par les candidats potentiels sur la page de description du poste.",
                  "You can use the panel on the side to add one or more documents that will be visible on the job description page to potential candidates.",
                )}
              </Alert>
            )}

            {!isError && currentlyPreviewingDocument ? (
              <JobDocumentViewer
                document={currentlyPreviewingDocument}
                onLoad={() => setIsPreviewLoading(false)}
              />
            ) : null}

            {isFetched &&
            !isError &&
            documents?.length &&
            !currentlyPreviewingDocument ? (
              <Alert variant="info">
                <h5>
                  <FaInfoCircle className="me-2" />
                  {out("Aucun document sélectionné", "No document selected")}
                </h5>
                {out(
                  `Vous pouvez utiliser la liste déroulante sur le côté pour afficher et modifier les documents qui ont déjà été téléversés pour cette description de poste. Pour en téléverser un nouveau, utilisez le panneau "Joindre un document".`,
                  'You can use the dropdown on the side to view & make changes to documents that are already uploaded to this job description. In order to upload a new one, use the "Attach a Document" panel.',
                )}
              </Alert>
            ) : null}

            {isError ? (
              <AtlasAlert variant="danger">
                <h3 className="text-center">
                  {out("Une erreur est survenue", "An error occured")}
                </h3>
              </AtlasAlert>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadDocumentsJobPage;
