import { out } from "global/utils/useTranslation";
import { error401 } from "global/utils/_commonApiStatusMessages";

export const listDocumentUploadsErrorMessageHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour téléverser un document.",
        "You do not have the required permission to upload a document.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La liste du document n'a pas pu être récupérée, veuillez réessayer. Si le problème persiste, SVP contactez support@workland.com.",
        "The document's list could not be retrieved, please try again. If the problem persists, please contact support@workland.com.",
      );
  }

  return msg;
};

export const editDocumentUploadErrorMessageHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier un document.",
        "You do not have the required permission to modify a document.",
      );
      break;
    case 404:
      msg.title = out("Non trouvé!", "Not found!");
      msg.text = out(
        "Ce document n'existe plus. Veuillez rafraîchir la page pour voir les documents joints à cette description de poste.",
        "This document no longer exists. Please refresh the page to see the documents attached to this job description.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le document n'a pas pu être modifié, veuillez réessayer. Si le problème persiste, SVP contactez support@workland.com.",
        "The document could not be modified, please try again. If the problem persists, please contact support@workland.com.",
      );
  }

  return msg;
};

export const deleteDocumentUploadErrorMessageHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer un document.",
        "You do not have the required permission to delete a document.",
      );
      break;
    case 404:
      msg.title = out("Non trouvé!", "Not found!");
      msg.text = out(
        "Ce document n'existe plus. Veuillez rafraîchir la page pour voir les documents joints à cette description de poste.",
        "This document no longer exists. Please refresh the page to see the documents attached to this job description.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le document n'a pas pu être supprimé, veuillez réessayer. Si le problème persiste, SVP contactez support@workland.com.",
        "The document could not be deleted, please try again. If the problem persists, please contact support@workland.com.",
      );
  }

  return msg;
};

export const attachDocumentUploadErrorMessageHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour joindre un document.",
        "You do not have the required permission to attach a document.",
      );
      break;
    case 404:
      msg.title = out("Non trouvé!", "Not found!");
      msg.text = out(
        "Ce document n'existe plus. Veuillez rafraîchir la page pour voir les documents joints à cette description de poste.",
        "This document no longer exists. Please refresh the page to see the documents attached to this job description.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le document n'a pas pu être joint, veuillez réessayer. Si le problème persiste, SVP contactez support@workland.com.",
        "The document could not be attached, please try again. If the problem persists, please contact support@workland.com.",
      );
  }

  return msg;
};
