import React from "react";
import { Route, Switch } from "react-router-dom";
import UploadDocumentsJobPage from "./pages/UploadDocumentsJobPage";

const UploadDocumentsJobRoutes = () => (
  <Switch>
    <Route exact path="/job/:jobId/upload-documents">
      <UploadDocumentsJobPage />
    </Route>
  </Switch>
);

export default UploadDocumentsJobRoutes;
