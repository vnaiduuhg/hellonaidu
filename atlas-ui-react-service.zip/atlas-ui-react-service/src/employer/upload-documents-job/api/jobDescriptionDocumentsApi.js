import {
  deleteRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
} from "global/utils/apiUtils";
import { getToken } from "global/utils/getToken";
import { serviceNames } from "global/utils/serviceNames";

export const uploadJobDescriptionDocument = async (jobId, payload) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.jobs,
      `job/${jobId}/description-documents`,
      getToken(),
      payload,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const editJobDescriptionDocument = async (
  jobId,
  documentId,
  payload,
) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.jobs,
      `job/${jobId}/description-documents`,
      getToken(),
      documentId,
      payload,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteJobDescriptionDocument = async (jobId, documentId) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.jobs,
      `job/${jobId}/description-documents/${documentId}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
