import { useMemo } from "react";
import { useMutation, useQuery } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { getJobsByAccount, getJobsByUser } from "employer/jobs/api/jobApi";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import statusMessagesSlice, {
  showMessage,
} from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import {
  deleteJobDescriptionDocument,
  editJobDescriptionDocument,
} from "../api/jobDescriptionDocumentsApi";
import { queryClient } from "global/utils/queryClient";
import { editDocumentUploadErrorMessageHandler } from "../utils/documentUploadErrorMessageHandler";
import { useHistory } from "react-router-dom";

export const useJobDocuments = ({
  jobId,
  options = REACT_QUERY_GETTER_OPTIONS,
  onError = () => {},
  onSuccess = () => {},
}) => {
  const { isRecruiter, isAdminRecruiter } = useSelector(
    (state) => state.user.permissions,
  );

  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();

  const { data: jobs, ...rest } = useQuery(
    [
      "jobs",
      {
        id: jobId,
        load_width: ["locations", "description_documents"],
        isRecruiter,
        isAdminRecruiter,
      },
    ],
    () =>
      (isRecruiter && !isAdminRecruiter ? getJobsByUser : getJobsByAccount)({
        "ids[]": +jobId,
        "load_with[]": ["locations", "description_documents"],
      }),
    {
      onError,
      onSuccess: (data) => onSuccess(data?.[0] ?? null),

      ...options,
    },
  );

  const { mutateAsync: editDocument } = useMutation({
    mutationFn: async (data) => {
      const {
        documentId,
        titleEn,
        titleFr,
        visibleInternally,
        visibleExternally,
      } = data;

      dispatch(
        showMessage(
          "loading",
          out("Mise à jour...", "Updating..."),
          null,
          60000,
        ),
      );

      const payload = {
        is_visible_to_external_candidates: +visibleExternally,
        is_visible_to_internal_candidates: +visibleInternally,
        translations: [
          !!titleFr && { locale: "fr", title: titleFr },
          !!titleEn && { locale: "en", title: titleEn },
        ].filter((t) => !!t),
      };

      try {
        const response = await editJobDescriptionDocument(
          jobId,
          documentId,
          payload,
        );

        queryClient.setQueryData(
          [
            "jobs",
            {
              id: jobId,
              load_width: ["locations", "description_documents"],
              isRecruiter,
              isAdminRecruiter,
            },
          ],
          (oldData) => {
            const newData = [...oldData];
            newData[0].description_documents =
              newData[0].description_documents.map((doc) =>
                doc.id !== documentId ? doc : response,
              );
            return newData;
          },
        );
      } catch (error) {
        const msg = editDocumentUploadErrorMessageHandler(
          error?.response?.status,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      } finally {
        dispatch(statusMessagesSlice.actions.clearLoaders());
      }
    },
  });

  const { mutateAsync: deleteDocument } = useMutation({
    mutationFn: async (documentId) => {
      dispatch(
        showMessage(
          "loading",
          out("Suppression...", "Deleting..."),
          null,
          60000,
        ),
      );

      try {
        await deleteJobDescriptionDocument(jobId, documentId);

        dispatch(
          showMessage(
            "ok",
            out("Succes", "Success"),
            out(
              "Le document a été supprimé.",
              "The document has been deleted.",
            ),
            5000,
          ),
        );

        queryClient.setQueryData(
          [
            "jobs",
            {
              id: jobId,
              load_width: ["locations", "description_documents"],
              isRecruiter,
              isAdminRecruiter,
            },
          ],
          (oldData) => {
            const newData = [...oldData];
            newData[0].description_documents =
              newData[0].description_documents.filter(
                (doc) => doc.id !== documentId,
              );
            return newData;
          },
        );
      } catch (error) {
        const msg = deleteJobDescriptionDocument(error?.response?.status, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      } finally {
        dispatch(statusMessagesSlice.actions.clearLoaders());
      }
    },
  });

  const documents = useMemo(
    () => jobs?.[0]?.description_documents ?? null,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [jobs, jobs?.[0]?.description_documents],
  );

  return {
    job: jobs?.[0] ?? null,
    documents,

    // api calls
    editDocument,
    deleteDocument,

    ...rest,
  };
};
