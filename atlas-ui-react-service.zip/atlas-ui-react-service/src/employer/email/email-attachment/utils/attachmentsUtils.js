export const getIcon = (type) => {
  if (!type) return <i className="fa fa-file" aria-hidden="true" />;
  if (type.includes("image/")) {
    return <i className="fa fa-image" aria-hidden="true" />;
  } else if (type.includes("audio/")) {
    return <i className="fa fa-file-audio-o" aria-hidden="true" />;
  } else if (type.includes("/pdf")) {
    return <i className="fa fa-file-pdf-o" aria-hidden="true" />;
  } else if (type.includes("/ics")) {
    return <i className="fa fa-calendar" aria-hidden="true" />;
  } else if (type.includes("text/")) {
    return <i className="fa fa-file-text-o" aria-hidden="true" />;
  } else if (type.includes("/zip") || type.includes("/rar")) {
    return <i className="fa fa-file-archive-o" aria-hidden="true" />;
  } else if (type.includes("/doc") || type.includes("/docx")) {
    return <i className="fa fa-file-word-o" aria-hidden="true" />;
  } else if (type.includes("/xls") || type.includes("/xlsx")) {
    return <i className="fa fa-file-excel-o" aria-hidden="true" />;
  } else if (type.includes("/ppt") || type.includes("/pptx")) {
    return <i className="fa fa-file-powerpoint-o" aria-hidden="true" />;
  } else {
    return <i className="fa fa-file" aria-hidden="true" />;
  }
};
