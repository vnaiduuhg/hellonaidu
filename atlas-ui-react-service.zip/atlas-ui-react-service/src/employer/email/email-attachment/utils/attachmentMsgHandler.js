import { error401 } from "global/utils/_commonApiStatusMessages";

export const uploadAttachmentMessage = (code, data, login) => {
  switch (code) {
    case 400:
      const msg = {
        title: {
          fr: "Échec du téléchargement",
          en: "Upload fail",
        },
      };
      if (data && data === "virus_detected_in_file") {
        msg.message = {
          fr: "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier.",
          en: "Sorry! This file is invalid, please upload a new file.",
        };
      } else {
        msg.message = {
          fr: "Une erreur est survenue avec les documents ajoutés, veuillez réessayer.",
          en: "An error has occurred with the documents added, please try again.",
        };
      }
      return msg;
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour télécharger des fichiers.",
          en: "You do not have the required permission to upload files.",
        },
      };

    case 404:
      return {
        title: {
          fr: "Non trouvé!",
          en: "Not Found!",
        },
        message: {
          fr: "Impossible de trouver le compte pour télécharger la pièce jointe.",
          en: "Could not find the account to upload attachment.",
        },
      };

    case 413:
      return {
        title: {
          fr: "Échec du téléchargement",
          en: "Upload fail",
        },
        message: {
          fr: "Désolé ! Vous pouvez envoyer seulement 25 Mo au total.",
          en: "Sorry! You can send only 25 MBs in total.",
        },
      };

    case 422:
      return {
        title: {
          fr: "Échec du téléchargement",
          en: "Upload fail",
        },
        message: {
          fr: "Le format ou la taille du fichier n'est pas valide.",
          en: "File format or size is not valid.",
        },
      };

    default:
      return {
        title: {
          fr: "Échec du téléchargement",
          en: "Upload fail",
        },
        message: {
          fr: "Une erreur est survenue avec les documents ajoutés, veuillez réessayer.",
          en: "An error has occurred with the documents added, please try again.",
        },
      };
  }
};
