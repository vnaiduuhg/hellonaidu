import { useTranslation } from "global/utils/useTranslation";
import { downloadAttachment, deleteAttachment } from "../api/attachmentApi";
import { useDispatch, useSelector } from "react-redux";
import { showMessage } from "global/store/statusMessagesSlice";
import { getIcon } from "../utils/attachmentsUtils";
import Tooltip from "react-bootstrap/Tooltip";
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import styles from "../assets/Attachment.module.css";
import { useMemo } from "react";
import { getUserFriendlyFileSize } from "global/utils/getUserFriendlyFileSize";
import cx from "classnames";

export const Attachment = ({
  attachment,
  attachments,
  setAttachments,
  emailAccount,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const { language } = useSelector((state) => state.user);

  const deleteHandler = async () => {
    // const attachmentsBackupInOriginalOrder = [...attachments];
    setAttachments(attachments.filter((a) => a.id !== attachment.id));

    // try {
    //   await emailAccount.deleteAttachment();
    // } catch (error) {
    //   if (error.status === 404) {
    //     dispatch(
    //       showMessage(
    //         "error",
    //         out("Désolé!", "Sorry!"),
    //         out("Fichier introuvable.", "File not found"),
    //         8000,
    //       ),
    //     );
    //   } else if (error.status === 500) {
    //     setAttachments(attachmentsBackupInOriginalOrder);

    //     dispatch(
    //       showMessage(
    //         "error",
    //         out("Désolé!", "Sorry!"),
    //         out("Une erreur s'est produite!", "An error has occurred!"),
    //         8000,
    //       ),
    //     );
    //   }
    // }

    // deleteAttachment(file.id, nylas_account_id).catch((error) => {
    //   if (error.status === 404) {
    //     dispatch(
    //       showMessage(
    //         "error",
    //         out("Désolé!", "Sorry!"),
    //         out("Fichier introuvable.", "File not found"),
    //         8000,
    //       ),
    //     );
    //   } else if (error.status === 500) {
    //     dispatch(
    //       showMessage(
    //         "error",
    //         out("Désolé!", "Sorry!"),
    //         out("Une erreur s'est produite!", "An error has occurred!"),
    //         8000,
    //       ),
    //     );
    //   }
    // });
  };

  // TODO: redo download when feature is introduced
  // Will not download. Cannot just make an XHR request to download a file.
  // More involved than this. https://developer.mozilla.org/en-US/docs/Web/API/Blob
  const downloadHandler = () => {
    downloadAttachment(attachment.id).catch((error) => {
      if (error.status === 404) {
        dispatch(
          showMessage(
            "error",
            out("Désolé!", "Sorry!"),
            out("Fichier introuvable.", "File not found"),
            8000,
          ),
        );
      } else if (error.status === 500) {
        dispatch(
          showMessage(
            "error",
            out("Désolé!", "Sorry!"),
            out("Une erreur s'est produite!", "An error has occurred!"),
            8000,
          ),
        );
      }
    });
  };

  const renderTooltip = (props) => (
    <Tooltip {...props}>
      <span className={`text-center ${styles.tooltip}`}>
        {out("enlever le fichier", "remove file")}
      </span>
    </Tooltip>
  );

  const size = useMemo(() => attachment.size, [attachment]);

  const displaySize = useMemo(
    () => getUserFriendlyFileSize(size, language),
    [size, language],
  );

  return (
    <div
      className={cx(`mb-3 p-2 border`, {
        "border-warning text-warning":
          !emailAccount.isAttachmentWithinSizeLimit(size),
      })}
    >
      <span
      // removed due to wrong implementation and out of scope for features
      // onClick={downloadHandler}
      >
        {getIcon(attachment.type, attachment)}
        &nbsp;&nbsp;
        {`${attachment.name} - [${displaySize}]` ??
          out("Sans titre", "Untitled")}
      </span>
      <OverlayTrigger placement="left" overlay={renderTooltip}>
        <span
          onClick={deleteHandler}
          className={cx("float-end pointer", {
            "text-secondary": emailAccount.isAttachmentWithinSizeLimit(size),
            "text-warning": !emailAccount.isAttachmentWithinSizeLimit(size),
          })}
        >
          [X]
        </span>
      </OverlayTrigger>
    </div>
  );
};
