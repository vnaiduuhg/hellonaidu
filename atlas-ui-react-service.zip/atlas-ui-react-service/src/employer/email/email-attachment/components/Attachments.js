import React, { useMemo } from "react";
import cx from "classnames";
import { Attachment } from "./Attachment";
import { useTranslation } from "global/utils/useTranslation";
import { UploadProgressBar } from "./UploadProgressBar";
import { getUserFriendlyFileSize } from "global/utils/getUserFriendlyFileSize";
import { AtlasAlert } from "global/components/atlas-alert";
import { AnimatePresence, motion } from "framer-motion";
import { useSelector } from "react-redux";

export const Attachments = ({
  uploading,
  attachments,
  setAttachments,
  emailAccount,
}) => {
  const { out } = useTranslation();
  const { language } = useSelector((state) => state.user);

  const totalSize = useMemo(
    () => attachments.reduce((total, attachment) => total + attachment.size, 0),
    [attachments],
  );

  const displaySize = useMemo(
    () => getUserFriendlyFileSize(totalSize, language),
    [totalSize, language],
  );

  const isEachAttachmentWithinSizeLimit = useMemo(() => {
    return attachments.every((attachment) =>
      emailAccount.isAttachmentWithinSizeLimit(attachment.size),
    );
  }, [attachments, emailAccount]);

  return (
    <div
      hidden={!attachments?.length && !uploading?.length}
      key="attachments-container"
      className="mt-5"
    >
      <AnimatePresence>
        {!emailAccount.areAllAttachmentsWithinSizeLimit(totalSize) && (
          <motion.div
            initial={{ scaleY: 0, opacity: 0 }}
            animate={{ scaleY: 1.0, opacity: 1 }}
            exit={{ scaleY: 0, opacity: 0 }}
          >
            <AtlasAlert variant="warning">
              {out(
                `La taille totale de vos pièces jointes est trop volumineuse. Le fournisseur que vous utilisez (${
                  emailAccount.displayName
                }) a une limite de ${getUserFriendlyFileSize(
                  emailAccount.MAXIMUM_TOTAL_FILE_SIZE,
                  language,
                  0,
                )}.`,
                `The total size of your attachments is too large. The provider you're using (${
                  emailAccount.displayName
                }) has a limit of ${getUserFriendlyFileSize(
                  emailAccount.MAXIMUM_TOTAL_FILE_SIZE,
                  language,
                  0,
                )}.`,
              )}
            </AtlasAlert>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {!isEachAttachmentWithinSizeLimit && (
          <motion.div
            initial={{ scaleY: 0, opacity: 0 }}
            animate={{ scaleY: 1.0, opacity: 1 }}
            exit={{ scaleY: 0, opacity: 0 }}
          >
            <AtlasAlert variant="warning">
              {out(
                "L'une des pièces jointes que vous essayez d'envoyer est trop volumineuse. Les fichiers sont limités à 5MB chacun.",
                "One of the attachments you are trying to send is too large. Files are restricted to 5MB each.",
              )}
            </AtlasAlert>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-3 mb-2 d-flex w-100">
        <div className="fw-bold w-100">
          {out("Fichiers joints", "Attached files")}:
        </div>

        <div className="text-nowrap">
          <span className="fw-bold">{out("Totale", "Total")}:</span>{" "}
          <span
            className={cx([
              "fw-normal pe-1",
              emailAccount.areAllAttachmentsWithinSizeLimit(totalSize)
                ? "text-secondary"
                : "text-warning",
            ])}
          >
            {displaySize}
          </span>
        </div>
      </div>

      <div>
        {uploading
          .map((uploadId) => (
            <UploadProgressBar key={uploadId} uploadId={uploadId} />
          ))
          .reverse()}
      </div>

      <div>
        {attachments
          .map((attachment) => (
            <Attachment
              key={attachment.id}
              attachment={attachment}
              attachments={attachments}
              setAttachments={setAttachments}
              emailAccount={emailAccount}
            />
          ))
          .reverse()}
      </div>
    </div>
  );
};
