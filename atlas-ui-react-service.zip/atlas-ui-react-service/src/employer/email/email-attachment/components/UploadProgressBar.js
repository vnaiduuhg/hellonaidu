import { useTranslation } from "global/utils/useTranslation";
import { useLayoutEffect, useRef, useState } from "react";
import ProgressBar from "react-bootstrap/ProgressBar";
import styles from "../assets/Attachment.module.css";

export const UploadProgressBar = ({ uploadId }) => {
  const [progress, setProgress] = useState(0);
  const { out } = useTranslation();

  const interval = useRef(null);

  useLayoutEffect(() => {
    if (interval.current) return;

    interval.current = setInterval(() => {
      setProgress((state) => {
        if (progress >= 100) {
          clearInterval(interval.current);
          interval.current = null;
          return 100;
        } else {
          return state + 0.3;
        }
      });
    }, 1000 / 60);

    return () => {
      if (interval.current) {
        clearInterval(interval.current);
        interval.current = null;
      }
    };
  }, [interval]);

  return (
    <ProgressBar
      now={progress}
      min={0}
      max={100}
      id={uploadId}
      className={`my-3 ${styles.progressBar}`}
      label={`${uploadId}: ${out(
        "téléversement en cours ...",
        "uploading...",
      )}`}
    />
  );
};
