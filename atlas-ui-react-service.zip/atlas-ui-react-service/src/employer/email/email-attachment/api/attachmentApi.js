import {
  getRestrictedApi,
  postRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const uploadAttachment = async (
  provider,
  payload,
  overrideLoopProtection = false,
) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails/attachments`,
      getToken(),
      payload,
      overrideLoopProtection,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getAttachments = async (provider) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/attachments`,
    getToken(),
  );

export const viewAttachmentMetaData = async (provider, id) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/attachments/${id}`,
    getToken(),
  );

export const downloadAttachment = async (provider, id) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/attachments/${id}/download`,
    getToken(),
  );

// NYLAS ONlY -> unify when implementing the others
export const deleteAttachment = async (id, nylas_account_id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.messaging,
      `nylas/regular-emails/attachments/${id}`,
      getToken(),
      { nylas_account_id },
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
