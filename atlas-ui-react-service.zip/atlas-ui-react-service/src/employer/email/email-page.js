import { Redirect, Route, Switch } from "react-router";
import { CategoryPage } from "./category/pages/CategoryPage";
import { MessagePage } from "./inbox/pages/MessagePage";
import { SignaturePage } from "./signature/pages/SignaturePage";
import { EditSignaturePage } from "./signature/pages/EditSignaturePage";
import { CreateSignaturePage } from "./signature/pages/CreateSignaturePage";
import { ComposeEmailPage } from "./compose/pages/ComposeEmailPage";
import CreateEmailTemplatePage from "./template/pages/CreateEmailTemplatePage";
import EditEmailTemplatePage from "./template/pages/EditEmailTemplatePage";
import ViewEmailTemplatesPage from "./template/pages/ViewEmailTemplatesPage";
import { PaginatedRoute } from "global/components/PaginatedRoute";
import styles from "./email-page.module.scss";
import { EmailNavbar } from "./email-navbar/email-navbar";
import { InboxPage } from "./inbox/pages/InboxPage";
import { EmailSettingsPage } from "./email-settings/EmailSettingsPage";

export const EmailPages = () => {
  return (
    <div className="page-wrapper-internal-page">
      <div className="sidebar-container">
        <EmailNavbar />
      </div>

      <div className="content-container" id={styles.content}>
        <div className="px-4 py-3 h-100">
          {/* content */}
          <Switch>
            <Route path="/emails" exact>
              <Redirect to="/emails/inbox" />
            </Route>

            <Route path="/emails/category" component={CategoryPage} exact />

            <Route
              path="/emails/signature/create"
              component={CreateSignaturePage}
              exact
            />
            <Route
              path="/emails/signature/:signatureId"
              component={EditSignaturePage}
              exact
            />
            <Route path="/emails/signature" component={SignaturePage} exact />

            <Route
              path="/emails/template"
              component={ViewEmailTemplatesPage}
              exact
            />
            <Route
              path="/emails/template/create"
              component={CreateEmailTemplatePage}
              exact
            />
            <Route
              path="/emails/template/:templateId/edit"
              component={EditEmailTemplatePage}
              exact
            />

            <Route
              path="/emails/message/:messageId"
              component={MessagePage}
              exact
            />

            <Route path="/emails/compose" component={ComposeEmailPage} exact />

            {/* email routes - folders */}
            <PaginatedRoute path="/emails/inbox" exact>
              <InboxPage folder="inbox" />
            </PaginatedRoute>

            <PaginatedRoute path="/emails/spam" exact>
              <InboxPage folder="spam" />
            </PaginatedRoute>

            <PaginatedRoute path="/emails/trash" exact>
              <InboxPage folder="trash" />
            </PaginatedRoute>

            <PaginatedRoute path="/emails/sent" exact>
              <InboxPage folder="sent" />
            </PaginatedRoute>

            <Route
              path="/emails/settings"
              component={EmailSettingsPage}
              exact
            />

            <Redirect to="/404" />
          </Switch>
        </div>
      </div>
    </div>
  );
};
