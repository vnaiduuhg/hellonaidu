import { error401 } from "global/utils/_commonApiStatusMessages";

export const getFilesMsgHandler = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour consulter les fichiers du classeur Atlas",
          en: "You do not have the required permission to view Atlas drive files",
        },
      };
    default:
      return {
        title: {
          fr: "Une erreur s'est produite!",
          en: "An error has occured!",
        },
        message: {
          fr: "Impossible de récupérer les fichiers du classeur Atlas",
          en: "Could not retrieved Atlas drive files",
        },
      };
  }
};

export const getFoldersMsgHandler = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour consulter les répertoires du classeur Atlas",
          en: "You do not have the required permission to view Atlas drive directories",
        },
      };
    default:
      return {
        title: {
          fr: "Une erreur s'est produite!",
          en: "An error has occured!",
        },
        message: {
          fr: "Impossible de récupérer les répertoires du classeur Atlas",
          en: "Could not retrieved Atlas drive directories",
        },
      };
  }
};
