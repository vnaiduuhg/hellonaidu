const SINGLE_EMAIL_VALIDATION = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;

export const emailListValidation = (emailAddresses) =>
  !emailAddresses
    .trim()
    .split(",")
    .map((emailAddress) => emailAddress.trim())
    .filter((emailAddress) => !!emailAddress)
    .some((emailAddress) => !SINGLE_EMAIL_VALIDATION.test(emailAddress));

export const getTypeOfFile = (name) => {
  const noExtention = "file";
  const ext = name.split(".").pop();
  if (
    [
      "pdf",
      "docx",
      "doc",
      "odt",
      "txt",
      "png",
      "jpg",
      "jpeg",
      "gif",
      "xlsx",
      "xls",
      "pptx",
      "ppt",
    ].includes(ext)
  ) {
    return `icon-${ext}.svg`;
  }
  return `icon-${noExtention}.svg`;
};
