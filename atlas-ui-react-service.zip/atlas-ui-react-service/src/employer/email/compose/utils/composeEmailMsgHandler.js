import { out } from "global/utils/useTranslation";

export const composeEmailMessageHandler = (code, data) => {
  const msg = {
    title: "",
    text: "",
  };
  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Courriel envoyé avec succès!",
        "Email sent successfully!",
      );
      break;
    case 400:
      if (data?.message === "virus_detected_in_file") {
        msg.title = out("Désolé!", "Sorry!");
        msg.text = out(
          "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier",
          "Sorry! This file is invalid, please upload a new file",
        );
      } else {
        msg.title = out("Une erreur s'est produite!", "An error has occurred!");
        msg.text = out(
          "Désolé, une erreur s'est produite lors de l'envoi du courriel.",
          "Sorry, there was an error while sending the email.",
        );
      }
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 413:
      msg.title = out("Fichiers trop volumineux", "Files are too large");
      msg.msg = out(
        "La taille combinée de vos pièces jointes est trop volumineuse. Veuillez réduire la taille et réessayer.",
        "The combined file size of your attachments is too large. Please reduce the size and try again.",
      );

      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      msg.text = out(
        "Veuillez vous assurer que tous les champs obligatoires sont remplis.",
        "Please make sure that all required fields are filled.",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Désolé, une erreur s'est produite lors de l'envoi du courriel.",
        "Sorry, there was an error while sending the email.",
      );
  }
  return msg;
};
