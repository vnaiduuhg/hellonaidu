let id = 1;

export class Attachment {
  constructor({ name, size, type, content }) {
    this.id = "file:" + id++;
    this.name = name;
    this.size = size;
    this.type = type;

    this.content = content;
  }
}

export class MinioAttachment {
  constructor({ name, size, type, minio_file_path }) {
    this.id = "minio:" + id++;
    this.name = name;
    this.size = size;
    this.type = type;

    this.minio_file_path = minio_file_path;
  }
}
