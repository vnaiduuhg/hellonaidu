import { useEffect } from "react";
import { useTranslation } from "global/utils/useTranslation";
import { emailRoutes } from "employer/email/email-navbar/email-routes";
import { ComposeEmail } from "../components/ComposeEmail";
import { useQueryParams } from "global/hooks/useQueryParams";
import { useEmailAccount } from "employer/sync/hooks/useEmailAccount";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { useDispatch } from "react-redux";
import statusMessagesSlice from "global/store/statusMessagesSlice";
import { DEFAULT_ACCOUNT_TYPE } from "employer/email/inbox/utils/constants";
import { EmailFeaturesProvider } from "employer/sync/contexts/EmailFeaturesContext";

// Temporarily keep this component here. When account switch functionality gets
// added, this will be done insidee the <ComposeEmail /> component because
// it needs to rely on itself to feed the account
const Compose = () => {
  const { out } = useTranslation();
  const query = useQueryParams();

  const {
    account: emailAccount,
    isLoading,
    isFetched,
    isError,
  } = useEmailAccount(DEFAULT_ACCOUNT_TYPE);

  if (isLoading) {
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;
  }

  if (isFetched && !isError && emailAccount && !emailAccount.sendEmail) {
    // This provider doesn't support sending emails

    return (
      <div className="py-2 px-3">
        <emailAccount.UnsupportedFeature />
      </div>
    );
  }

  return (
    <ComposeEmail
      emailAccount={emailAccount}
      subject={query.get("subject") ?? ""}
      body={query.get("body") ?? ""}
    />
  );
};

export const ComposeEmailPage = () => {
  const { out } = useTranslation();
  const dispatch = useDispatch();

  const title = out(emailRoutes[0].title.fr, emailRoutes[0].title.en);

  useEffect(() => {
    document.title = title + " - Workland";

    return () => {
      dispatch(statusMessagesSlice.actions.clearLoaders());
    };
  }, [title, dispatch]);

  return (
    <EmailFeaturesProvider type={DEFAULT_ACCOUNT_TYPE}>
      <Compose />
    </EmailFeaturesProvider>
  );
};
