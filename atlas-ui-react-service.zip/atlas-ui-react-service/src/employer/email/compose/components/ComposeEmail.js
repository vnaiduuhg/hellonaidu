import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router";
import { useForm } from "react-hook-form";
import { CKEditor } from "ckeditor4-react";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { AtlasDriveModal } from "./AtlasDriveModal";
import { Attachments } from "employer/email/email-attachment/components/Attachments";
import { composeEmailMessageHandler } from "../utils/composeEmailMsgHandler";
import { emailListValidation } from "../utils/emailComposeUtils";
import { SignatureModal } from "./SignatureModal";
import { getUserSignatures } from "employer/email/signature/api/signatureApi";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { viewSignaturesMsgHandler } from "employer/email/signature/utils/signatureMessageHandler";
import { useTranslation } from "global/utils/useTranslation";
import { CKEDITOR4_PROPS } from "global/constants/CKEDITOR4_PROPS";
import { Alert, Button, Col, Row } from "react-bootstrap";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { BsPencilFill } from "react-icons/bs";
import { HiDatabase } from "react-icons/hi";
import { FaUpload } from "react-icons/fa";
import { Attachment } from "../utils/attachment";

export const ComposeEmail = ({
  emailAccount,

  // optional params for autofilling subject & message used by jobs share feature
  subject,
  body,

  // not implemented yet
  receiverDetails = [],
}) => {
  const userId = useSelector((s) => s.user.data.user_id);
  const language = useSelector((s) => s.user.language);
  const [alertBoxVisible, setAlertBoxVisible] = useState(true);
  const [showAtlasDriveModal, setShowAtlasDriveModal] = useState(false);
  const [attachSignatureModal, setAttachSignatureModal] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [progressBars, setProgressBars] = useState([]);
  const [isSending, setIsSending] = useState(false);
  const $fileUpload = useRef(null);
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const history = useHistory();
  const { out } = useTranslation();

  const { data: signatures } = useQuery(
    ["user-signatures", { id: userId }],
    () => getUserSignatures(userId),
    {
      ...REACT_QUERY_GETTER_OPTIONS,

      onError(e) {
        const msg = viewSignaturesMsgHandler(
          e.response?.code ?? 500,
          // callback to redirect to login. replaceable w/
          () => history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  const handleSend = () => {
    // not all providers have inbox functionality. redirect to compose page
    // if they don't
    setIsSending(false);

    if (emailAccount.getMessagesInFolder) {
      history.replace("/emails/sent");
    } else {
      // Not functional yet
      // for providers that don't have folder functionality
      // console.log("clear");
      // setAttachments([]);
      // setProgressBars([]);
      // setValue("message", "");
      // setValue("emailAddresses", "");
      // setValue("subject", "");
    }
  };

  const sendEmail = useMutation(
    async (payload) => {
      setIsSending(true);
      dispatch(showLoadingBarWithoutMessage(200000));

      return await emailAccount.sendEmail(payload);
    },
    {
      onSuccess: (response, payload) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());

        // invalidate all folders if you're also sending this message to yourself
        if (
          payload.to.some(
            (recipient) =>
              recipient.email.toLowerCase() ===
              emailAccount.email.toLowerCase(),
          ) ||
          payload.bcc.some(
            (recipient) =>
              recipient.email.toLowerCase() ===
              emailAccount.email.toLowerCase(),
          )
        ) {
          queryClient.invalidateQueries("messages");
        } else {
          queryClient.invalidateQueries([
            "messages",
            { folder: "sent", provider: emailAccount.provider },
          ]);
        }
        const msg = composeEmailMessageHandler(200, response);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));

        handleSend();
      },
      onError: (error) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        const msg = composeEmailMessageHandler(error.status, error?.response);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      },
    },
  );

  const messageEditor = useRef(null);
  const {
    control,
    register,
    handleSubmit,
    watch,
    formState: { errors },
    setValue,
    getValues,
    trigger,
  } = useForm({
    defaultValues: {
      subject,
      message: body,
    },
  });

  const message = watch("message");

  const initial = useRef(true);
  useEffect(() => {
    register("message", { required: true });
  }, [language, register]);
  useEffect(() => {
    if (!initial.current) trigger("message");
  }, [message, trigger]);
  useEffect(() => {
    if (!initial.current) trigger();
    initial.current = false;
  }, [language, trigger]);

  const onSubmit = useCallback(
    ({ message, subject, emailAddresses }) => {
      const [to, ...bcc] = emailAddresses
        .split(",")
        .map((e) => e.trim())
        .filter((e) => !!e)
        .map((e) => ({ name: e.trim(), email: e.trim() }));

      sendEmail.mutate({
        to: [to],
        cc: [],
        bcc,
        subject,
        body: message,

        attachments: (attachments.length && attachments) || null,
      });
    },
    [attachments, sendEmail],
  );

  const addFileAttachment = useCallback(
    (e) => {
      e.preventDefault();
      e.stopPropagation();

      // TODO: add the old validation back in

      const files = !!e.target?.files?.length ? [...e.target.files] : null;

      if (!files) {
        // check if cancel was clicked, if not, something unexpected happened
        if (!e.target.value) {
          return;
        }

        dispatch(
          showMessage(
            "error",
            out("Terminé!", "Done!"),
            out(
              "Une erreur est survenue avec les documents ajoutés , veuillez réessayer",
              "An error has occurred with the documents added, please try again",
            ),
            8000,
          ),
        );

        return;
      }

      // const reader = new FileReader();
      // let doubleCheck = [];

      files.forEach((file) => {
        const attachment = new Attachment({
          id: "" + Date.now(),
          name: file.name,
          size: file.size,
          type: file.type,
          content: new Blob([file], { type: file.type }),
        });

        // reader.readAsArrayBuffer(attachment.content);

        setAttachments((attachments) => {
          // make sure not to send duplicate emails (filename AND content)

          const alreadyAttached = attachments.find((existingAttachment) => {
            // Only check if it's a duplicate of a regular attachment, not for
            // minio attachments. Minio attachments are checked when they're
            // added from Atlas Drive
            if (!(existingAttachment instanceof Attachment)) {
              return false;
            }

            // quick check using meta data to rule out the number of files
            // to check
            return (
              existingAttachment.content.size === attachment.content.size &&
              existingAttachment.name === attachment.name &&
              existingAttachment.content.type === attachment.content.type
            );

            // TODO: Have not checked the actual content. Implement if time allows
            // use array buffer streams. Might need to use Worker to avoid blocking
            // and emit events to compose page. Initiate the check all at once
            // at the end and remove the attachment from the list after the fact
          });

          if (alreadyAttached) {
            setTimeout(() => {
              dispatch(
                showMessage(
                  "error",
                  out("Ignoré", "Skipped"),
                  out(
                    "Ce fichier a déjà été ajouté",
                    "This file has already been added",
                  ),
                  3500,
                ),
              );
            });

            return attachments;
          }

          return [...attachments, attachment];
        });
      });

      e.target.value = "";
    },
    [dispatch, out],
  );

  const isEachAttachmentWithinSizeLimit = useMemo(() => {
    return attachments.every((attachment) =>
      emailAccount.isAttachmentWithinSizeLimit(attachment.size),
    );
  }, [attachments, emailAccount]);

  const areAllAttachmentsWithinSizeLimit = useMemo(() => {
    const totalSize = attachments.reduce(
      (total, attachment) => total + attachment.size,
      0,
    );
    return emailAccount.areAllAttachmentsWithinSizeLimit(totalSize);
  }, [attachments, emailAccount]);

  return (
    <div className="p-2 pt-3 h-100">
      <h1 className="h4 visually-hidden">
        {out("Écrire un courriel", "Compose email")}
      </h1>

      <form name="sendEmail" onSubmit={handleSubmit(onSubmit)}>
        <div>
          <div className="text-start">
            <Alert
              variant="info"
              dismissible
              hidden={!!receiverDetails?.length || !alertBoxVisible}
              onClose={() => setAlertBoxVisible(false)}
            >
              <strong>
                {out(
                  "Ajouter les destinataires en Cci : ",
                  "Add Bcc recipients: ",
                )}
              </strong>
              {out(
                "Vous pouvez saisir plusieurs destinataires en séparant leurs adresses électroniques par une virgule",
                "You can enter multiple recipients separating their email addresses by comma.",
              )}
            </Alert>

            <div
              className="text-danger text-end"
              hidden={
                !(
                  errors?.emailAddresses &&
                  errors?.emailAddresses?.type === "required"
                )
              }
            >
              *{out("Champs obligatoires", "Required")}
            </div>
            <div
              className="text-danger text-end"
              hidden={
                !(
                  errors.emailAddresses &&
                  errors?.emailAddresses?.type === "addresses"
                )
              }
            >
              {out("Adresse de courriel invalide", "Invalid email address")}
            </div>

            <FormHookFloatingLabel
              control={control}
              name="emailAddresses"
              title={out("Courriel", "Email")}
              className="email-subject mb-3"
              // Note: not yet implemented
              hidden={!!receiverDetails?.length}
              error={!!errors?.emailAddresses}
              showError={false}
              rules={{
                required: {
                  value: true,
                  message: { fr: "Champs obligatoires", en: "Required" },
                },
                validate: {
                  addresses: (value) => emailListValidation(value),
                },
              }}
            />

            {!!receiverDetails?.length &&
              receiverDetails.map((receiver) => (
                <div className="fs-7">
                  <span>{receiver.email} </span>
                  <i>({receiver.name})</i>
                </div>
              ))}
          </div>

          <div>
            <div className="text-danger text-end" hidden={!errors?.subject}>
              *{out("Champ obligatoire", "Required")}
            </div>

            <FormHookFloatingLabel
              control={control}
              name="subject"
              title={out("Sujet", "Subject")}
              aria-label={out("Objet de l'e-mail", "Email Subject")}
              className="email-subject mb-3"
              // Note: not yet implemented
              error={!!errors?.subject}
              showError={false}
              rules={{ required: true }}
            />
          </div>

          <div className="d-flex">
            <label className="flex-fill">{out("Message", "Message")}:</label>
            <div className="text-danger text-end" hidden={!errors.message}>
              *{out("Champs obligatoires", "Required")}
            </div>
          </div>

          <CKEditor
            {...CKEDITOR4_PROPS}
            initData={getValues("message")}
            onChange={({ editor }) => setValue("message", editor.getData())}
            onInstanceReady={({ editor }) => (messageEditor.current = editor)}
          />

          <Row className="g-0 pt-3">
            <Col xs={12} md={6}>
              <span className="me-4">
                {out("Pièce jointe", "Attach file")}:
              </span>
              <a
                href="#"
                className="text-secondary-300 me-3"
                onClick={(e) => {
                  e.preventDefault();
                  $fileUpload.current.click();
                }}
              >
                <FaUpload className="me-2" aria-hidden="true" />
                {out("Téléverser", "Upload")}
              </a>
              <input
                className="d-none"
                type="file"
                ref={$fileUpload}
                onChange={addFileAttachment}
              />
              <span className="me-4">{out("ou", "or")}</span>
              <a
                href="#"
                className="text-secondary-300"
                onClick={(e) => {
                  e.preventDefault();
                  setShowAtlasDriveModal(true);
                }}
              >
                <HiDatabase className="me-1" />
                &nbsp;{out("Atlas Classeur", "Atlas Drive")}
              </a>
            </Col>

            <Col xs={12} md={6}>
              <div className="d-flex mt-4 mt-md-0">
                <div className="text-secondary-300 flex-fill text-end me-5">
                  {!!signatures?.length && (
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        setAttachSignatureModal(true);
                      }}
                    >
                      <BsPencilFill className="me-2 fs-7" />
                      {out("Joindre la signature", "Attach signature")}
                    </a>
                  )}
                </div>

                <div>
                  <Button
                    type="submit"
                    variant="primary"
                    disabled={
                      isSending ||
                      !(
                        isEachAttachmentWithinSizeLimit &&
                        areAllAttachmentsWithinSizeLimit
                      )
                    }
                  >
                    {out("Envoyer", "Send")}
                  </Button>
                </div>
              </div>
            </Col>
          </Row>

          {attachSignatureModal && (
            <SignatureModal
              show={attachSignatureModal}
              closeModal={() => setAttachSignatureModal(false)}
              message={message}
              signatures={signatures}
              editor={messageEditor.current}
              setMessage={(val, resetEditor = true) => {
                if (resetEditor) messageEditor.current.setData(val);
                setValue("message", val);
              }}
            />
          )}
          {showAtlasDriveModal && (
            <AtlasDriveModal
              showModal={showAtlasDriveModal}
              hide={() => setShowAtlasDriveModal(false)}
              attachments={attachments}
              setAttachments={setAttachments}
              // progressBars={progressBars}
              // setProgressBars={setProgressBars} // not used
            />
          )}

          <Attachments
            uploading={progressBars}
            attachments={attachments}
            setAttachments={setAttachments}
            mode="upload"
            emailAccount={emailAccount}
          />
        </div>
      </form>
    </div>
  );
};
