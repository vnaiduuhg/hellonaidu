import React from "react";
import { useState, useRef } from "react";
import { useQuery, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router";
import { showMessage } from "global/store/statusMessagesSlice";
import { getDirectories, getFiles } from "../api/atlasDriveApi";
import { useTranslation } from "global/utils/useTranslation";
import { getTypeOfFile } from "../utils/emailComposeUtils";
import {
  getFilesMsgHandler,
  getFoldersMsgHandler,
} from "../utils/atlasDriveMsgsHandler";
import { basename } from "path";
import atlasDriveStyle from "../assets/AtlasDriveModal.module.css";
import { Button, Col, Modal, Row } from "react-bootstrap";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import { MinioAttachment } from "employer/email/compose/utils/attachment.js";

const mapPath = require.context("global/assets/file-icons", false, /\.svg$/);
const icons = Object.fromEntries(
  mapPath.keys().map((path) => [basename(path), mapPath(path).default]),
);
const STALE_TIME = 10000 * 60;

export const AtlasDriveModal = ({
  showModal,
  hide,
  attachments,
  setAttachments,
  // progressBars,
  // setProgressBars,
  singleFileSelect = false,
  attachFile,
  children,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const history = useHistory();
  const directoryTracker = useRef([{ id: 1, name: "home" }]);
  const [directoryId, setDirectoryId] = useState(1);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectedFileIds, setSelectedFileIds] = useState([]);
  const [filesLoading, setFilesLoading] = useState(false);
  const [directoriesLoading, setDirectoriesLoading] = useState(false);

  const {
    data: directories,
    isLoading: isDirectoriesLoading,
    isError: isDirectoriesError,
  } = useQuery(
    ["atlas-drive-directories", { id: directoryId }],
    () =>
      getDirectories(directoryId).then(
        (response) => response?.data?.result ?? [],
      ),
    {
      staleTime: STALE_TIME,
      refetchOnWindowFocus: false,
      onSuccess() {
        setDirectoriesLoading(false);
      },
      onError(e) {
        setDirectoriesLoading(false);
        const msg = getFoldersMsgHandler(e.status ?? 500, () =>
          history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  const {
    data: files,
    isLoading: isFilesLoading,
    isError: isFilesError,
  } = useQuery(
    ["atlas-drive-files", { id: directoryId }],
    () =>
      getFiles(directoryId).then((response) => {
        return response?.data?.result
          ? !Array.isArray(response.data.result)
            ? Object.values(response.data.result)
            : response.data.result
          : [];
      }),
    {
      staleTime: STALE_TIME,
      refetchOnWindowFocus: false,
      onSuccess() {
        setFilesLoading(false);
      },
      onError(e) {
        setFilesLoading(false);
        const msg = getFilesMsgHandler(e.status ?? 500, () =>
          history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
        return [];
      },
    },
  );

  const attachFiles = async (atlasFiles) => {
    // do not duplicate atlas drive attachments
    atlasFiles = atlasFiles.filter(
      (f) => !attachments.find((a) => a.atlasFileId === f.id),
    );

    if (!!atlasFiles.length) {
      atlasFiles.forEach((atlasFile) => {
        const attachment = new MinioAttachment({
          name: atlasFile.file_name,
          size: atlasFile.size,
          type: atlasFile["content-type"],
          minio_file_path: `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`,
        });

        setAttachments((a) => {
          const alreadyAttached = a.find((f) => {
            // Only need to check if Minio attachments are unique
            if (!(f instanceof MinioAttachment)) {
              return false;
            }

            return (
              f.minio_file_path === attachment.minio_file_path &&
              f.size === attachment.size &&
              f.name === attachment.name
            );
          });

          if (alreadyAttached) {
            setTimeout(() => {
              dispatch(
                showMessage(
                  "error",
                  out("Ignoré", "Skipped"),
                  out(
                    "Ce fichier a déjà été ajouté",
                    "This file has already been added",
                  ),
                  3500,
                ),
              );
            });

            return a;
          }

          return [...a, attachment];
        });
      });

      setSelectedFiles([]);
      setSelectedFileIds([]);
    }
  };

  return (
    <Modal show={showModal} onHide={hide} size="xl">
      <Modal.Header>
        <Modal.Title>{out("Mon classeur", "My drive")}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Row>
          <div>
            {+directoryId !== 1 && (
              <li style={{ display: "inline" }}>
                <button
                  type="button"
                  className={`${atlasDriveStyle.backButton}`}
                  onClick={() => {
                    directoryTracker.current.length -= 1;
                    setDirectoryId(
                      directoryTracker.current[
                        directoryTracker.current.length - 1
                      ].id,
                    );
                    setFilesLoading(true);
                    setDirectoriesLoading(true);
                    queryClient.invalidateQueries("atlas-drive-directories");
                    queryClient.invalidateQueries("atlas-drive-files");
                  }}
                >
                  {out("Retourner", "Back")}
                </button>
                &nbsp;&nbsp;|&nbsp;&nbsp;
              </li>
            )}
            <i className={"fa fa-home"} aria-hidden="true" />
            {directoryTracker.current &&
              directoryTracker.current.map((dir, index) => (
                <li key={dir.id} style={{ display: "inline" }}>
                  <button
                    type="button"
                    className={
                      +dir.id === +directoryId ? atlasDriveStyle.activeDir : ""
                    }
                    style={{ background: "none", border: "none" }}
                    onClick={() => {
                      directoryTracker.current.length = index + 1;
                      setDirectoryId(+dir.id);
                      setFilesLoading(true);
                      setDirectoriesLoading(true);
                      queryClient.invalidateQueries("atlas-drive-directories");
                      queryClient.invalidateQueries("atlas-drive-files");
                    }}
                  >
                    <span>{dir.name}</span>
                  </button>
                  {index < directoryTracker.current.length - 1 && (
                    <i
                      className={`fa fa-chevron-right`}
                      aria-hidden="true"
                      style={{ fontSize: "12px", padding: "0px 5px" }}
                    />
                  )}
                </li>
              ))}
          </div>
        </Row>
        {/* end of breadcrumbs */}

        {/* content */}
        <Row className={atlasDriveStyle.filesAndDirContainer}>
          {isFilesLoading ||
          isDirectoriesLoading ||
          filesLoading ||
          directoriesLoading ? (
            <div
              className={`d-flex flex-column ${atlasDriveStyle.modalSpinnerDiv}`}
            >
              <ComponentLoader message={out("Chargement...", "Loading...")} />

              <h2 className="text-center">
                {out("ATLAS Classeur", "ATLAS Drive")}
              </h2>

              <h5 className="text-center">
                {out(
                  "Télécharger . Gérer . Partager",
                  "Upload . Manage . Share",
                )}
              </h5>
            </div>
          ) : (
            <Row>
              {/* merge dirs and files */}
              {directories?.length > 0 &&
                directories.map((dir) => (
                  <Col
                    xs={6}
                    md={3}
                    lg={2}
                    xl={2}
                    key={dir.id}
                    className={`${atlasDriveStyle.directory}`}
                  >
                    <button
                      type="button"
                      style={{ border: "none", background: "none" }}
                      onClick={() => {
                        setDirectoryId(+dir.id);
                        directoryTracker.current.push({
                          id: dir.id,
                          name: dir.name,
                        });
                        setFilesLoading(true);
                        setDirectoriesLoading(true);
                        queryClient.invalidateQueries(
                          "atlas-drive-directories",
                        );
                        queryClient.invalidateQueries("atlas-drive-files");
                      }}
                    >
                      <img
                        src={icons["icon-folder.svg"]}
                        width="50"
                        alt="folder icon"
                      />
                      <br />
                      <span className="text-break">{dir.name}</span>
                    </button>
                  </Col>
                ))}

              {files?.length > 0 &&
                files.map(
                  (file) =>
                    file.file_version?.length > 0 &&
                    file.file_version.map((file_version) => (
                      <Col
                        key={file_version.id}
                        xs={6}
                        md={3}
                        lg={2}
                        xl={2}
                        className={`${atlasDriveStyle.directory}`}
                      >
                        <div className="position-relative">
                          <button
                            type="button"
                            style={{ border: "none", background: "none" }}
                            onClick={() => {
                              if (selectedFileIds.includes(file_version.id)) {
                                setSelectedFiles((s) =>
                                  s.filter(
                                    (clickedFile) =>
                                      clickedFile !== file_version,
                                  ),
                                );
                                setSelectedFileIds((s) =>
                                  s.filter((id) => id !== file_version.id),
                                );
                              } else {
                                setSelectedFiles((s) => [...s, file_version]);
                                setSelectedFileIds((sIds) => [
                                  ...sIds,
                                  file_version.id,
                                ]);
                              }
                            }}
                          >
                            <div className={atlasDriveStyle.docImageContainer}>
                              {selectedFileIds.includes(file_version.id) && (
                                <img
                                  className={atlasDriveStyle.docImageCheckmark}
                                  src="https://img.icons8.com/flat_round/20/000000/checkmark.png"
                                  alt="checkmark icon"
                                />
                              )}
                              <img
                                src={
                                  icons[getTypeOfFile(file_version.file_name)]
                                }
                                width="50"
                                alt="file icon"
                              />
                            </div>
                            <br />
                            <span className="text-break">
                              {file_version.file_name.substring(0, 20)}
                            </span>
                          </button>
                        </div>
                      </Col>
                    )),
                )}
            </Row>
          )}
        </Row>

        {!isFilesLoading &&
          !isDirectoriesLoading &&
          !filesLoading &&
          !directoriesLoading && (
            <>
              {Array.isArray(files) && !files?.length && (
                <AtlasAlert variant="info">
                  {out(
                    "Vous n'avez aucun fichier disponible",
                    "You have no files available",
                  )}
                  {+directoryId !== 1 && (
                    <span>
                      &nbsp;
                      {out("dans ce dossier", "under this folder")}
                    </span>
                  )}
                </AtlasAlert>
              )}
              {isFilesError && (
                <AtlasAlert variant="info">
                  {out(
                    "Les fichiers sont actuellement indisponibles",
                    "Files are currently unavailable",
                  )}
                  {+directoryId !== 1 && (
                    <span>
                      &nbsp;
                      {out("sous ce dossier", "under this folder")}
                    </span>
                  )}
                </AtlasAlert>
              )}

              {isDirectoriesError && (
                <AtlasAlert variant="info">
                  {out(
                    "Les répertoires sont actuellement indisponibles",
                    "Directories are currently unavailable",
                  )}
                  {+directoryId !== 1 && (
                    <span>
                      &nbsp;
                      {out("dans ce dossier", "under this folder")}
                    </span>
                  )}
                </AtlasAlert>
              )}
            </>
          )}
      </Modal.Body>

      <Modal.Footer>
        {children && (
          <Col xs={12} md={6}>
            <div className="pe-2 pb-3">{children}</div>
          </Col>
        )}
        <Col xs={12}>
          <div className="d-flex flex-column px-2 pb-1">
            <div className="d-flex justify-content-end">
              <Button variant="alt-secondary" onClick={hide}>
                {out("Annuler", "Cancel")}
              </Button>
              <Button
                variant="secondary"
                className="ms-3"
                disabled={
                  singleFileSelect
                    ? selectedFiles.length !== 1
                    : !selectedFiles.length
                }
                onClick={() => {
                  if (singleFileSelect) {
                    attachFile(selectedFiles[0]);
                  } else {
                    attachFiles(selectedFiles);
                    hide();
                  }
                }}
              >
                {out("Ajouter les fichiers", "Add files")}
              </Button>
            </div>
            {singleFileSelect && selectedFiles.length > 1 && (
              <div className="form-text text-warning align-self-end">
                {out(
                  "Veuilez sélectionner un seul document",
                  "Please select only one document",
                )}
              </div>
            )}
          </div>
        </Col>
      </Modal.Footer>
    </Modal>
  );
};
