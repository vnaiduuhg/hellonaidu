import { useState, useEffect, useRef } from "react";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import { useTranslation } from "global/utils/useTranslation";
import { Modal } from "react-bootstrap";

export const SignatureModal = ({
  show = false,
  message = "",
  setMessage = () => {
    throw new Error("Missing callback for updating message");
  },
  closeModal = () => {
    throw new Error("Missing callback to close signature modal");
  },
  editor,
  signatures,
}) => {
  const { out } = useTranslation();
  const modal = useRef(null);
  const [signaturesList, setSignaturesList] = useState([]);

  useEffect(() => {
    if (show && modal.current) {
      modal.current.focus();
    }
  }, [modal.current, show]);

  useEffect(() => {
    const tempList = [...signatures];
    tempList.map((s) => {
      s.translations.map((t) => {
        const signatureEl = editor.document.getById(`signature-${t.id}`);
        const hasText = !!(
          signatureEl && signatureEl.$.innerText.trim().length > 0
        );
        t.checked = hasText;
        // if signature is empty we remove it from the editor body and from the message
        if (signatureEl && !hasText) {
          signatureEl.remove(false);
          const divId = new RegExp(`signature-${t.id}`);
          if (divId.test(message)) {
            const newMsg = message.replace(
              `<div id="signature-${t.id}">&nbsp;</div>`,
              "",
            );
            setMessage(newMsg);
          }
        }
      });
    });
    setSignaturesList(tempList);
  }, [signatures]);

  return (
    <Modal show={modal} onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>
          {out("Veuillez choisir votre signature", "Choose your signature")}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {!!signaturesList.length &&
          signaturesList.map((signature) =>
            signature.translations.map((t) => (
              <div
                className="mb-2"
                key={`signature-${signature.id}-${t.locale}`}
              >
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={t.checked}
                      onChange={(e) => {
                        // set only in message instead and let 'checked' use the calculated value
                        if (e.target.checked) {
                          setMessage(
                            (message.length ? message : "<p>&nbsp;</p>") +
                              `<div id="signature-${t.id}">${t.body}</div>`,
                            true,
                          );
                        } else {
                          const $el = editor.document.getById(
                            `signature-${t.id}`,
                          );
                          if ($el) {
                            $el.remove();
                            setMessage(editor.getData(), false);
                          }
                        }
                        closeModal();
                      }}
                      name={t.name}
                    />
                  }
                  label={`${t.name} (${t.locale})`}
                />
              </div>
            )),
          )}
      </Modal.Body>
    </Modal>
  );
};
