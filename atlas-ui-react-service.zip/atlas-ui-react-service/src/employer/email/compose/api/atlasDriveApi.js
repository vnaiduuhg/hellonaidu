import { getRestrictedApi, postRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getDirectories = async (id) => {
  try {
    const response = await getRestrictedApi(
      serviceNames.toolkit,
      `document-manager/directories?filter_by_parent_id=${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getFiles = async (id) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.toolkit,
      `document-manager/files/file_type_data?filter_by_dm_directory_id=${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
