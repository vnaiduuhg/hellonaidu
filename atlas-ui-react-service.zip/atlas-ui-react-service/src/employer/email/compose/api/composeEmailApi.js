import { postRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const composeEmailApi = async (provider, payload) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails${provider === "nylas" ? "/send-email" : ""}`,
      getToken(),
      payload,
      null,
      true,
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
