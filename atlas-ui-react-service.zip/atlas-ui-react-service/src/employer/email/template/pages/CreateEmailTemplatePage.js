import { useEffect } from "react";
import { useHistory } from "react-router";
import { useQuery, useQueryClient } from "react-query";
import { createEmailTemplate } from "../api/emailTemplatesApi";
import { authLevelApiOptions } from "global/apis/utils/authLevelApiOptions";
import { loadCategoriesErrorMessage } from "../utils/categoriesApiStatusMessages";
import TemplateEditor from "../components/TemplateEditor";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

const CreateEmailTemplatePage = () => {
  const { out } = useTranslation();
  const history = useHistory();
  const queryClient = useQueryClient();
  const title = out("Modèles de messages", "Email Templates");
  const categoriesQuery = {
    key: authLevelApiOptions.account.key,
    query: authLevelApiOptions.account.categoryApi,
  };

  useEffect(() => {
    document.title = `${title} - Workland`;
  }, [title]);

  const {
    data: allCategories = null,
    isLoading: allCategoriesLoading,
    isError: allCategoriesError,
  } = useQuery(
    ["categories", { by: "account", id: categoriesQuery.key }],
    () => categoriesQuery.query(),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError: (error) => {
        const msg = loadCategoriesErrorMessage(
          error?.response?.status ?? 0,
          () => history.replace("/"),
        );
      },
    },
  );

  if (allCategoriesLoading) {
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;
  }

  return (
    <TemplateEditor
      mode="create"
      allCategories={allCategories}
      allCategoriesError={allCategoriesError}
      save={async (payload) => {
        await createEmailTemplate(payload);
        queryClient.invalidateQueries("templates");
      }}
      goBack={() => history.push("/emails/template")}
    />
  );
};

export default CreateEmailTemplatePage;
