import { useCallback, useEffect } from "react";
import { useQuery, useQueryClient } from "react-query";
import { Redirect, useHistory, useParams } from "react-router";
import { useDispatch } from "react-redux";
import { authLevelApiOptions } from "global/apis/utils/authLevelApiOptions";
import {
  getEmailTemplatesById,
  updateEmailTemplate,
} from "../api/emailTemplatesApi";
import TemplateEditor from "../components/TemplateEditor";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import { singleTemplateErrorMessage } from "../utils/templatesApiStatusMessages";
import { loadCategoriesErrorMessage } from "../utils/categoriesApiStatusMessages";
import { showMessage } from "global/store/statusMessagesSlice";
import ViewTemplateError from "../components/ViewTemplateError";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

// use editor/creator component and prefill w/ both data & id

const EditEmailTemplatePage = () => {
  const { templateId = null } = useParams();
  const { out } = useTranslation();
  const history = useHistory();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const title = out("Modèles de messages", "Email Templates");
  const categoriesQuery = {
    key: authLevelApiOptions.account.key,
    query: authLevelApiOptions.account.categoryApi,
  };

  const save = useCallback(async (payload) => {
    await updateEmailTemplate(templateId, payload);
    queryClient.invalidateQueries("templates");
    queryClient.invalidateQueries(["template", { id: templateId }]);
  });

  useEffect(() => {
    document.title = `${title} - Workland`;
  }, [title]);

  const {
    data: template,
    isLoading: templateIsLoading,
    isError: templateError,
  } = useQuery(
    ["template", { id: templateId }],
    () =>
      getEmailTemplatesById(templateId).then((response) => ({
        ...Object.fromEntries(
          ["account_id", "id", "name", "subject", "body", "categories"].map(
            (key) => [key, response[key]],
          ),
        ),
        en: { ...response.translations[0] },
        fr: { ...response.translations[1] },
      })),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError: (error) => {
        const msg = singleTemplateErrorMessage(
          error?.response?.status ?? -1,
          () => history.replace("/"),
        );

        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  const {
    data: allCategories = null,
    isLoading: allCategoriesLoading,
    isError: allCategoriesError,
  } = useQuery(
    ["categories", { by: "account", id: categoriesQuery.key }],
    () => categoriesQuery.query(),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError: (error) => {
        const msg = loadCategoriesErrorMessage(
          error?.response?.status ?? 0,
          () => history.replace("/"),
        );
      },
    },
  );

  if (!templateId) {
    return <Redirect to="/emails/template" />;
  } else if (templateError) {
    return <ViewTemplateError />;
  } else if (templateIsLoading || allCategoriesLoading) {
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;
  }

  return (
    <TemplateEditor
      mode="edit"
      template={template}
      allCategories={allCategories}
      allCategoriesError={allCategoriesError}
      save={save}
      goBack={() => history.push("/emails/template")}
    />
  );
};

export default EditEmailTemplatePage;
