import React, { useState, useEffect, useCallback } from "react";
import { useHistory } from "react-router-dom";
import { useQuery } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { showMessage } from "global/store/statusMessagesSlice";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import EmailTemplatesList from "../components/EmailTemplatesList";
import { authLevelApiOptions } from "global/apis/utils/authLevelApiOptions";
import { loadTemplatesErrorMessage } from "../utils/templatesApiStatusMessages";
import { loadCategoriesErrorMessage } from "../utils/categoriesApiStatusMessages";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import ActionButton from "global/components/action-button/action-button";

const ViewEmailTemplatesPage = () => {
  const { out } = useTranslation();
  const { language, data: userData } = useSelector((s) => s.user);
  const dispatch = useDispatch();
  const history = useHistory();
  const title = out("Modèles de messages", "Email Templates");
  const [categoriesWithDefault, setCategoriesWithDefault] = useState();
  const [templatesWithDefault, setTemplatesWithDefault] = useState();
  const templateQuery = {
    key: authLevelApiOptions.account.key,
    query: authLevelApiOptions.account.emailTemplateApi,
  };
  const categoryQuery = {
    key: authLevelApiOptions.account.key,
    query: authLevelApiOptions.account.categoryApi,
  };

  useEffect(() => {
    document.title = `${title} - Workland`;
  }, [title]);

  const createNewTemplate = useCallback(
    () => history.push("/emails/template/create"),
    [],
  );

  // get templates
  // TODO: load by permissions
  let {
    data: templates,
    isLoading: templatesIsLoading,
    isFetched: templatesIsFetched,
    isError: templatesError,
  } = useQuery(
    [
      "templates",
      {
        key: templateQuery.key,
        language,
        sort: "name",
        withDefaults: true,
      },
    ],
    () =>
      templateQuery.query({
        locale: language,
        sort: "name",
        withDefaults: true,
      }),

    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError(error) {
        const msg = loadTemplatesErrorMessage(
          error?.response?.status ?? -1,
          () => history.replace("/"),
        );

        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  let {
    data: categories,
    isLoading: categoriesIsLoading,
    isFetched: categoriesIsFetched,
    isError: categoriesError,
  } = useQuery(
    [
      "categories",
      {
        key: categoryQuery.key,
      },
    ],
    () => categoryQuery.query(),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError(error) {
        const msg = loadCategoriesErrorMessage(
          error?.response?.status ?? -1,
          () => history.replace("/"),
        );
      },
    },
  );

  useEffect(() => {
    if (categoriesIsFetched) {
      const tempCategoriesList = [...categories];
      tempCategoriesList.push({
        account_id: null,
        id: 0,
        name: "default",
        translations: [
          {
            category_id: -1,
            locale: "en",
            name: "Default templates",
          },
          {
            category_id: -2,
            locale: "fr",
            name: "Modèles par défaut",
          },
        ],
      });
      setCategoriesWithDefault(tempCategoriesList);
    }
  }, [categories, categoriesIsFetched]);

  useEffect(() => {
    if (templatesIsFetched) {
      const tempTemplatesList = [...templates];
      tempTemplatesList.map((t) => {
        if (!t.account_id) {
          t.categories.push({
            account_id: null,
            id: 0,
            name: "default",
            translations: [
              {
                category_id: -1,
                locale: "en",
                name: "Default",
              },
              {
                category_id: -2,
                locale: "fr",
                name: "Défaut",
              },
            ],
          });
        }
      });
      setTemplatesWithDefault(tempTemplatesList);
    }
  }, [templates, templatesIsFetched]);

  return (
    <div className="p-2 pt-3 h-100">
      <div className="text-start visually-hidden">
        {out("Modèles de courrier électronique", "Email Templates")}
      </div>

      {(templatesIsLoading || categoriesIsLoading) && (
        <NestedPageLoader
          message={out(
            "Loading Email-Templates...",
            "Chargement de modèles de courrier électronique...",
          )}
        />
      )}

      {/* show loader while data is being loaded */}

      {/* show error  */}
      {templatesError && (
        <AtlasAlert variant="error">
          {out(
            "Il y a eu un problème pour récupérer les modèles",
            "There was a problem retrieving the templates",
          )}
        </AtlasAlert>
      )}

      {!templatesError && <ActionButton click={createNewTemplate} />}

      {/* show no templates message */}
      {!templatesIsLoading &&
        !categoriesIsLoading &&
        !templatesError &&
        !!categoriesWithDefault?.length &&
        (!!templatesWithDefault?.length ? (
          <EmailTemplatesList
            user={userData}
            templates={templatesWithDefault}
            categories={categoriesWithDefault}
            categoriesError={categoriesError}
          />
        ) : (
          <AtlasAlert>
            {out("Aucun modèle disponible", "No templates available")}
          </AtlasAlert>
        ))}
    </div>
  );
};

export default ViewEmailTemplatesPage;
