import { getRestrictedApi } from "global/utils/apiUtils";
import { getToken } from "global/utils/getToken";
import { serviceNames } from "global/utils/serviceNames";

export const getAllVariables = async () =>
  getRestrictedApi(serviceNames.variables, "variables", getToken());

export const getVariablesCategories = async () => {
  return getRestrictedApi(
    serviceNames.variables,
    "variables/categories",
    getToken(),
  );
};
