import {
  deleteRestrictedApi,
  getRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getEmailTemplatesById = async (id) => {
  return getRestrictedApi(
    serviceNames.messaging,
    `email-templates/${id}`,
    getToken(),
  );
};

export const createEmailTemplate = async (payload) =>
  postRestrictedApi(
    serviceNames.messaging,
    "email-templates",
    getToken(),
    payload,
  );

export const updateEmailTemplate = async (id, payload) =>
  putRestrictedApi(
    serviceNames.messaging,
    "email-templates",
    getToken(),
    id,
    payload,
  );

export const deleteEmailTemplate = async (id) =>
  deleteRestrictedApi(
    serviceNames.messaging,
    `email-templates/${id}`,
    getToken(),
    null,
  );
