import { useState } from "react";
import { useHistory } from "react-router-dom";
import { useQueryClient } from "react-query";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import { useTranslation } from "global/utils/useTranslation";
import { deleteEmailTemplate } from "../api/emailTemplatesApi";
import { useDispatch } from "react-redux";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { deleteTemplatesMsgHandler } from "../utils/templatesApiStatusMessages";
import { AccordionSummary, Accordion } from "global/assets/globalStyles";
import { Button } from "react-bootstrap";
import { BsChevronRight } from "react-icons/bs";
import { AtlasAlert } from "global/components/atlas-alert";
import { BiEdit, BiTrash } from "react-icons/bi";
import { sanitize } from "dompurify";
import { RECRUITER } from "global/constants/accountsConstants";
import styles from "../assets/EmailTemplates.module.scss";

const EmailTemplatesList = ({
  user,
  templates,
  categories,
  categoriesError,
}) => {
  const [expanded, setExpanded] = useState(false);
  const { out } = useTranslation();
  const queryClient = useQueryClient();
  const history = useHistory();
  const dispatch = useDispatch();
  const [activeCategories, setActiveCategories] = useState([]);

  const handleChange = (panel) => (_, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const templateHasSelectedCategory = (template) => {
    return template.categories.find((cat) =>
      activeCategories.find((activeCat) => +activeCat === +cat.id),
    );
  };

  const deleteTemplate = (id) => {
    deleteEmailTemplate(id).then(
      () => {
        const msg = deleteTemplatesMsgHandler(204);
        dispatch(
          showMessage(
            "ok",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            5000,
          ),
        );
        queryClient.invalidateQueries("templates");
        queryClient.invalidateQueries(["template", { id: id }]);
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      (error) => {
        // TODO: once in-place status message is implemented, use this to update that status message instead
        const msg = deleteTemplatesMsgHandler(
          error?.response?.status ?? -1,
          () => history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    );
  };

  const templatesList = templates
    .map(
      (t) =>
        ((activeCategories.length > 0 &&
          t.categories.length > 0 &&
          templateHasSelectedCategory(t)) ||
          (!activeCategories.length && t.account_id)) && (
          <Accordion
            expanded={expanded === t.id}
            onChange={handleChange(t.id)}
            key={t.id}
          >
            <AccordionSummary
              id={`${t.id}d-header`}
              aria-controls={`${t.id}d-content`}
              expandIcon={<BsChevronRight className={styles.iconColor} />}
            >
              <Typography>
                <div className="d-flex">
                  <div className="flex-fill">
                    {out(t.translations[1].name, t.translations[0].name)}
                  </div>
                  <div className="ms-auto min-w-max-content align-self-center">
                    {activeCategories.length > 1 &&
                      [...new Set(t.categories.map((c) => c.id))]
                        .map((id) => t.categories.find((c) => c.id === id))
                        .map((c) =>
                          activeCategories.find((item) => +item === c.id) ? (
                            <span key={c.id}>
                              {out(
                                c.translations[1].name,
                                c.translations[0].name,
                              )}
                            </span>
                          ) : null,
                        )}
                  </div>
                </div>
              </Typography>
            </AccordionSummary>

            <AccordionDetails>
              <div className="p-1">
                <div className="d-flex">
                  <div className="flex-fill pt-1">
                    <span className="me-2 text-secondary-100 fw-label">
                      {out("Sujet", "Subject")}:
                    </span>
                    {out(t.translations[1].subject, t.translations[0].subject)}
                  </div>
                  <div className="ms-auto min-w-max-content">
                    {t?.account_id &&
                      (+user.user_account.role_id !== RECRUITER ||
                        (+user.user_account.role_id === RECRUITER &&
                          t.users.find((u) => +u.id === +user.user_id))) && (
                        <div className="d-flex flex-row-reverse">
                          <Button
                            variant="danger"
                            className="btn-frameless-icon ms-1 fs-5"
                            title={out("Supprimer", "Delete")}
                            onClick={() => {
                              dispatch(showLoadingBarWithoutMessage(200000));
                              deleteTemplate(t.id);
                            }}
                          >
                            <BiTrash />
                          </Button>

                          <Button
                            variant="secondary"
                            className="btn-frameless-icon mx-1 fs-5"
                            title={out("Modifier", "Update")}
                            onClick={() =>
                              history.push(`/emails/template/${t.id}/edit`)
                            }
                          >
                            <BiEdit />
                          </Button>
                        </div>
                      )}
                  </div>
                </div>
                <hr className="my-2" />
                <div className="me-2 text-secondary-100 fw-label">
                  {out("Corps", "Body")}:
                </div>
                <div
                  className={`overflow-auto ${styles.message}`}
                  dangerouslySetInnerHTML={{
                    __html: sanitize(
                      out(t.translations[1].body, t.translations[0].body),
                    ),
                  }}
                />
              </div>
            </AccordionDetails>
          </Accordion>
        ),
    )
    .filter((t) => !!t);

  return (
    <div>
      {categoriesError && (
        <AtlasAlert variant="error">
          {out(
            "Les catégories ne sont pas disponibles",
            "Categories are not available",
          )}
        </AtlasAlert>
      )}

      {categories?.length > 0 && (
        <div className="p-0">
          <div className={styles.categoryFilters}>
            {categories.map((c) => (
              <label className={styles.filter} key={c.id}>
                <input
                  type="checkbox"
                  name="templateCategory"
                  value={c.id}
                  onChange={(e) => {
                    const categoriesArray = [...activeCategories];
                    if (e.target.checked) {
                      categoriesArray.push(e.target.value);
                      setActiveCategories(categoriesArray);
                    } else {
                      const newCategoriesArray = categoriesArray.filter(
                        (c) => +c !== +e.target.value,
                      );
                      setActiveCategories(newCategoriesArray);
                    }
                  }}
                />
                <div className={styles.filterText}>
                  {out(c.translations[1].name, c.translations[0].name)}
                </div>
              </label>
            ))}
          </div>
        </div>
      )}

      {!!templates.length &&
      !!templatesList.length &&
      templatesList.find((item) => item !== false) ? (
        <div>
          <div>{templatesList}</div>
        </div>
      ) : activeCategories.length ? (
        <AtlasAlert variant="info">
          {out(
            `Aucun modèle de courrier électronique pour ${
              activeCategories.length === 1
                ? "cette catégorie"
                : "ces catégories"
            }`,
            `No templates for ${
              activeCategories.length === 1
                ? "this category"
                : "these categories"
            }`,
          )}
        </AtlasAlert>
      ) : (
        <div>
          <AtlasAlert variant="info">
            {out(
              `Vous n'avez pas de modèles personnalisés pour le moment.`,
              `You have no custom templates at the moment.`,
            )}
          </AtlasAlert>

          <div className="text-center">
            <Button
              variant="secondary"
              size="lg"
              onClick={() => history.push("/emails/template/create")}
            >
              {out("Créer un modèle", "Create Template")}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailTemplatesList;
