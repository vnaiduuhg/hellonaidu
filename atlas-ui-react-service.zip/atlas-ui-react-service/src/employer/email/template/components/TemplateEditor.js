import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { CKEditor } from "ckeditor4-react";
import { useQuery } from "react-query";
import { Prompt, useHistory } from "react-router";
import { useTranslation } from "global/utils/useTranslation";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { getAllVariables, getVariablesCategories } from "../api/variablesApi";
import TemplateVariablesModal from "./TemplateVariablesModal";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";
import {
  createTemplatesErrorMessage,
  editTemplatesErrorMessage,
} from "../utils/templatesApiStatusMessages";
import { loadVariablesErrorMessage } from "../utils/variablesApiStatusMessages";
import AntidoteButton from "global/components/AntidoteButton";
import { useAntidote } from "global/hooks/useAntidote";
import { CKEDITOR4_PROPS } from "global/constants/CKEDITOR4_PROPS";
import { Button } from "react-bootstrap";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { AtlasSelect } from "global/components/select/atlas-select";
import { AtlasAlert } from "global/components/atlas-alert";
import cx from "classnames";
import { ImSpinner } from "react-icons/im";
import styles from "../assets/EmailTemplates.module.scss";

const injectVariableIntoCkEditor = (ckEditor) => (useVar) => {
  if (!ckEditor) {
    return;
  }

  const focused = !!ckEditor?.getSelection()?.getRanges()[0];

  // if ckeditor not selected, append variable to the end the way
  // it's done on the ng-app (double new lines then append variable)
  if (!focused) {
    return ckEditor.setData(`${ckEditor.getData() ?? ""}\n\n{{${useVar}}}`);
  }

  // if editor is selected, put the variable in the cursor.
  // if there is text already selected, replace that text with variable
  ckEditor.insertText(` {{${useVar}}} `);
};

const defaultTemplate = {
  categories: [],
  en: { name: "", subject: "", body: "", locale: "en" },
  fr: { name: "", subject: "", body: "", locale: "fr" },
};

// Note for future-proofing:
// Ckeditor sections should be factored out and made into language specific
// Editors. The container should provide the wrapper form to coordinate these
// editors and provide them with CRUD functionality
/* example:
  <TemplateEditors>
    * add languages *
    ....
    <TemplateEditor language="en" ... />
    <TemplateEditor language="es" ... />
    ...
  </TemplateEditors>
*/

const TemplateEditor = ({
  mode,
  template = defaultTemplate,
  allCategories,
  allCategoriesError,
  save = async () => {
    throw new Error("Missing save callback");
  },
  goBack = async () => {
    throw new Error("Missing goBack callback");
  },
}) => {
  const { out } = useTranslation();
  const ckEditors = useRef({ en: null, fr: null });
  const history = useHistory();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  const [showVariables, setShowVariables] = useState(null);
  const [disablePrompt, setDisablePrompt] = useState(false);
  const [activecategory, setActivecategory] = useState(0);
  const [categoriesOptions, setCategoriesOptions] = useState([]);
  const [defaultCatOptions, setDefaultCatOptions] = useState([]);

  const {
    data: variablesCategories,
    isLoading: variablesCategoriesIsLoading,
    isError: variablesCategoriesError,
  } = useQuery("variables-categories", getVariablesCategories, {
    ...REACT_QUERY_GETTER_OPTIONS,
  });

  const {
    data: variables,
    isLoading: variablesIsLoading,
    isFetched: variablesFetched,
    isError: variablesError,
  } = useQuery("variables", getAllVariables, {
    ...REACT_QUERY_GETTER_OPTIONS,
    onError: (error) => {
      const msg = loadVariablesErrorMessage(error?.response?.status ?? 0, () =>
        history.replace("/"),
      );

      dispatch(
        showMessage(
          "error",
          out(msg.title.fr, msg.title.en),
          out(msg.message.fr, msg.message.en),
          8000,
        ),
      );
    },
  });

  const {
    control,
    register,
    handleSubmit,
    setValue,
    formState: { errors, isDirty },
  } = useForm({
    defaultValues: {
      template: {
        ...template,
        categories: (template.categories ?? []).map((c) => c.id),
      },
    },
  });

  const antidoteActive = useAntidote({ id: "A" });

  useEffect(() => {
    if (!!allCategories?.length) {
      const cOptions = [];
      allCategories.forEach((c) => {
        cOptions.push({
          value: c.id,
          label: out(c.translations[1].name, c.translations[0].name),
        });
      });
      setCategoriesOptions(cOptions);
    } else {
      setCategoriesOptions([]);
    }
  }, [allCategories]);

  useEffect(() => {
    if (!!template?.categories.length) {
      setDefaultCatOptions([]);
      const dCOptions = [];
      template.categories.forEach((tC) => {
        dCOptions.push({
          value: tC.id,
          label: out(tC.translations[1].name, tC.translations[0].name),
        });
      });
      setDefaultCatOptions(dCOptions);
    }
  }, [template]);

  useEffect(() => {
    // Register validation for CKeditors
    register("template.en.body", { required: true });
    register("template.fr.body", { required: true });
  }, [register]);

  const submitHandler = async ({ template }) => {
    try {
      const payload = {
        ...Object.fromEntries(
          ["account_id", "id", "name", "subject", "body"].map((key) => [
            key,
            template[key],
          ]),
        ),
        category_ids: template.categories,
        translations: [template.en, template.fr],
      };

      dispatch(showLoadingBarWithoutMessage(30000));
      await save(payload);

      dispatch(
        showMessage(
          "ok",
          out("Success", "Success"),
          out(
            `Votre modèle a été ${
              mode === "edit" ? "mis à jour" : "créé"
            } avec succès.`,
            `Your email template has been ${
              mode === "edit" ? "updated" : "created"
            } successfully.`,
          ),
          3000,
        ),
      );
      dispatch(statusMessagesSlice.actions.clearLoaders());

      setDisablePrompt(true);
      goBack();
    } catch (error) {
      dispatch(statusMessagesSlice.actions.clearLoaders());

      let msg;
      if (mode === "edit") {
        msg = editTemplatesErrorMessage(error?.response?.status ?? 0, () =>
          history.push("/"),
        );
      } else {
        // save
        msg = createTemplatesErrorMessage(error?.response?.status ?? 0, () =>
          history.replace("/"),
        );
      }

      dispatch(
        showMessage(
          "error",
          out(msg.title.fr, msg.title.en),
          out(msg.message.fr, msg.message.en),
          8000,
        ),
      );
    }
  };

  const handleChange = (e) => {
    const newCatIdsArray = e.map((cat) => cat.value);
    setValue("template.categories", newCatIdsArray);
  };

  return (
    <div className="m-0 p-2 pt-3">
      <Prompt
        message={out(
          "Les changements ne sont pas sauvegardés. Êtes-vous sûr de vouloir partir ?",
          "Changes are not save. Are you sure you wish to leave?",
        )}
        when={isDirty && !disablePrompt}
      />

      <form onSubmit={handleSubmit(submitHandler)}>
        <div className="visually-hidden">
          {out(
            `${
              mode === "create" ? "Créer" : "Modifier"
            } un modèle de courrier électronique`,
            `${mode === "create" ? "Create" : "Modify"} Email Template`,
          )}
        </div>

        {/* categories */}
        {!allCategoriesError && !!categoriesOptions?.length && (
          <div className="mb-4">
            <div id={styles.categorySelectLabel}>
              <label htmlFor="categories">{out("Catégorie", "Category")}</label>
            </div>

            <AtlasSelect
              id="categories"
              placeholder={out(
                "Veuillez sélectionner une catégorie",
                "Please select a category",
              )}
              isMulti
              isClearable
              name="categories"
              defaultValue={defaultCatOptions}
              options={categoriesOptions}
              onChange={handleChange}
            />

            {errors?.categories && (
              <div className="text-danger text-end fs-7">
                * {out("Champs obligatoires", "Required")}&nbsp;
              </div>
            )}
          </div>
        )}
        {allCategoriesError && (
          <AtlasAlert variant="error">
            {out(
              "Les catégories ne sont pas disponible",
              "Categories are not available",
            )}
          </AtlasAlert>
        )}
        {/* /categories */}

        {/* English */}
        <div className="d-block d-lg-flex">
          {/* title: english */}
          <div className="mx-1 w-100">
            <h4 className={`h5 text-center ${styles.groupTitle}`}>
              {out("Version Anglaise", "English version")}
            </h4>

            <div>
              {!!errors?.template?.en?.name && (
                <div className="text-end text-danger fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}

              <FormHookFloatingLabel
                control={control}
                name="template.en.name"
                title={out(
                  "Titre interne du modèle",
                  "Template internal title",
                )}
                rules={{ required: true }}
                mandatory={true}
                className="mb-3"
              />
            </div>

            {/* subject: english */}
            <div>
              {!!errors?.template?.en?.subject && (
                <div className="text-danger text-end fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}

              <FormHookFloatingLabel
                control={control}
                name="template.en.subject"
                title={out("Sujet du courriel", "Email Subject")}
                rules={{ required: true }}
                mandatory={true}
                className="mb-3"
              />
            </div>

            {/* CKeditor: english */}
            <div className="d-flex">
              <label className="flex-fill" htmlFor="editor-en">
                {out("Message", "Message")}:
              </label>

              {!!errors?.template?.en?.body && (
                <div className="text-danger text-end fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}
            </div>

            <CKEditor
              {...CKEDITOR4_PROPS}
              id="editor-en"
              initData={template.en.body}
              onInstanceReady={({ editor }) => (ckEditors.current.en = editor)}
              onChange={({ editor }) =>
                setValue("template.en.body", editor.getData(), {
                  shouldDirty: true,
                })
              }
            />

            <br />
            <Button
              type="button"
              variant="secondary"
              onClick={() => setShowVariables("en")}
              disabled={!variablesFetched}
            >
              <ImSpinner
                className={cx("me-2 fa-pulse", {
                  "d-none": variablesFetched,
                })}
              />
              {out(
                "Insérer des variables (Anglais)",
                "Inject Variables (English)",
              )}
            </Button>
          </div>

          <div className={styles.templatesSpacer}></div>

          {/* french */}
          <div className="mx-1 w-100">
            <h4 className={`h5 text-center ${styles.groupTitle}`}>
              {out("Version Française", "French version")}
            </h4>

            <div>
              {!!errors?.template?.fr?.name && (
                <div className="text-end text-danger fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}
              <FormHookFloatingLabel
                control={control}
                name="template.fr.name"
                title={out(
                  "Titre interne du modèle",
                  "Template internal title",
                )}
                rules={{ required: true }}
                mandatory={true}
                className="mb-3"
              />
            </div>

            {/* subject: french */}
            <div>
              {!!errors?.template?.fr?.subject && (
                <div className="text-danger text-end fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}
              <FormHookFloatingLabel
                control={control}
                name="template.fr.subject"
                title={out("Sujet du courriel", "Email Subject")}
                rules={{ required: true }}
                mandatory={true}
                className="mb-3"
              />
            </div>

            {/* CKeditor: french */}
            <div className="d-flex">
              <label className="flex-fill" htmlFor="editor-fr">
                {out("Message", "Message")}:
              </label>

              {!!errors?.template?.fr?.body && (
                <div className="text-danger text-end fs-7">
                  * {out("Champs obligatoires", "Required")}
                </div>
              )}
            </div>

            <CKEditor
              {...CKEDITOR4_PROPS}
              id="editor-fr"
              initData={template.fr.body}
              onInstanceReady={({ editor }) => (ckEditors.current.fr = editor)}
              onChange={({ editor }) =>
                setValue("template.fr.body", editor.getData(), {
                  shouldDirty: true,
                })
              }
            />

            <br />
            <Button
              type="button"
              variant="secondary"
              onClick={() => setShowVariables("fr")}
              disabled={!variablesFetched}
            >
              <ImSpinner
                className={cx("me-2 fa-pulse", {
                  "d-none": variablesFetched,
                })}
              />
              {out(
                "Insérer des variables (Français)",
                "Inject Variables (French)",
              )}
            </Button>
          </div>
        </div>

        {/*Antidote*/}
        {antidoteActive && (
          <div className={styles.pl30}>
            <br />
            <br />
            <AntidoteButton id="A" data-antidoteapi_jsconnect_lanceoutil="C" />
          </div>
        )}
        {/*Antidote end*/}

        {/* Save & Cancel buttons */}
        <div className="mt-5 d-flex flex-row-reverse justify-content-center">
          <Button variant="primary" type="submit">
            {out("Sauvegarder", "Save")}
          </Button>

          {mode === "edit" && (
            <Button variant="secondary" className="me-4" onClick={goBack}>
              {out("Annuler", "Cancel")}
            </Button>
          )}
        </div>
      </form>

      <TemplateVariablesModal
        show={showVariables === "en" || showVariables === "fr"}
        hide={() => setShowVariables(false)}
        user={user}
        language={showVariables}
        variables={variables}
        variablesCategories={variablesCategories}
        activecategory={activecategory}
        setActivecategory={setActivecategory}
        variablesIsLoading={variablesIsLoading}
        variablesCategoriesIsLoading={variablesCategoriesIsLoading}
        variablesError={variablesError}
        variablesCategoriesError={variablesCategoriesError}
        inject={(templateVariable) => {
          setShowVariables(null);
          ckEditors.current[showVariables].focus();
          // better experience when the user sees the variable being entered
          setTimeout(
            () =>
              injectVariableIntoCkEditor(
                ckEditors.current[showVariables] ?? null,
              )(templateVariable),
            16 * 7,
          );
        }}
      />
    </div>
  );
};

export default TemplateEditor;
