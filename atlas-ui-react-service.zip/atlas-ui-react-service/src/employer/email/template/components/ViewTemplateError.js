import { useTranslation } from "global/utils/useTranslation";
import { AtlasAlert } from "global/components/atlas-alert";

const ViewTemplateError = () => {
  const { out } = useTranslation();

  return (
    <AtlasAlert variant="danger">
      {out(
        "Il y a eu un problème pour récupérer le modèle",
        "There was a problem retrieving the template",
      )}
    </AtlasAlert>
  );
};

export default ViewTemplateError;
