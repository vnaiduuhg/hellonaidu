import { useTranslation } from "global/utils/useTranslation";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import styles from "../assets/EmailTemplate.module.scss";
import { Button, Modal } from "react-bootstrap";
import { AtlasSelect } from "global/components/select/atlas-select";

const TemplateVariablesModal = ({
  show,
  hide,
  language,
  variables,
  variablesCategories,
  activecategory,
  setActivecategory,
  variablesIsLoading,
  variablesCategoriesIsLoading,
  variablesError,
  variablesCategoriesError,
  inject,
}) => {
  const { out } = useTranslation();

  return (
    <Modal show={show} onHide={hide}>
      <Modal.Header closeButton>
        <Modal.Title>
          <span>{language === "fr" ? "FR" : "EN"}</span> Variables
          {/* @std by
            <Tooltip
              placement="top-start"
              title={
                <h5 className={`text-center ${styles.tooltip}`}>
                  {out(
                    "Veuillez choisir la catégorie correspondant au modèle que vous souhaitez créer, et utilisez les variables selon vos besoins",
                    "Please choose the category corresponding to the model you want to create, and use the variables according to your needs",
                  )}
                </h5>
              }
            >
              <i className="fa fa-info-circle"></i>
            </Tooltip> 
          */}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {!variablesIsLoading &&
          !variablesCategoriesIsLoading &&
          !variablesError &&
          !variablesCategoriesError && (
            <>
              <div>
                <div>
                  {out(
                    "Veuillez choisir la catégorie correspondant au modèle que vous souhaitez créer, et utilisez les variables selon vos besoins.",
                    "Please choose the category corresponding to the model you want to create, and use the variables according to your needs.",
                  )}
                </div>

                <AtlasSelect
                  placeholder={out(
                    "Veuillez choisir une catégorie",
                    "Please choose a category",
                  )}
                  className="my-3"
                  options={(variablesCategories ?? []).map((c) => ({
                    label: out(c.translations[1].name, c.translations[0].name),
                    value: c.id,
                  }))}
                  value={(variablesCategories ?? [])
                    .map((c) => ({
                      label: out(
                        c.translations[1].name,
                        c.translations[0].name,
                      ),
                      value: c.id,
                    }))
                    .find((c) => c.id === activecategory)}
                  onChange={(category) =>
                    setActivecategory(category?.value ?? null)
                  }
                />
              </div>

              <div className={`text-start ${styles.variablesContainer}`}>
                <div className="text-secondary-100 fw-label">
                  {out("Liste des variables", "Variables list")}
                </div>
                <hr className="mt-0 mb-3 border border-secondary" />
                <div>
                  {variables?.length > 0 &&
                    variables.map((currentVar) =>
                      activecategory > 0 &&
                      currentVar.categories.length > 0 &&
                      currentVar.categories.find((c) => {
                        return +c.id === +activecategory;
                      }) ? (
                        <div
                          key={currentVar.id}
                          className="d-flex align-items-center mb-2 ms-3"
                        >
                          <div className="">
                            <Button
                              variant="secondary"
                              size="sm"
                              className="me-2 fs-6"
                              onClick={() =>
                                inject(
                                  language === "fr"
                                    ? currentVar.indexed_translations.fr.name
                                    : currentVar.indexed_translations.en.name,
                                )
                              }
                            >
                              {out("Utiliser", "Use")}
                            </Button>
                          </div>
                          <div className="fw-500 fs-6 p-1">
                            {out(
                              currentVar.indexed_translations.fr.description,
                              currentVar.indexed_translations.en.description,
                            )}
                          </div>
                        </div>
                      ) : null,
                    )}
                </div>
              </div>
            </>
          )}

        {(variablesIsLoading || variablesCategoriesIsLoading) && (
          <div className="mt-5">
            <NestedPageLoader
              message={out(
                "Nous téléchargeons les variables",
                "Loading variables",
              )}
            />
          </div>
        )}

        {(variablesError || variablesCategoriesError) &&
          !variablesIsLoading &&
          !variablesCategoriesIsLoading && (
            <AtlasAlert variant="error">
              {out(
                "Un problème nous empêche d'afficher les variables, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
                "There was an issue preventing us from displaying the variables, please try again or contact support@workland.com for assistance",
              )}
            </AtlasAlert>
          )}
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="secondary"
          onClick={() => {
            setActivecategory(0);
            hide();
          }}
        >
          {out("Fermer", "Close")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default TemplateVariablesModal;
