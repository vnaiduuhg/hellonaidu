import {
  error401,
  error500orUnknown,
} from "global/utils/_commonApiStatusMessages";

const error404 = {
  title: {
    fr: "Non trouvé!",
    en: "Not Found!",
  },
  message: {
    fr: "Ce modèle n'existe pas.",
    en: "This template does not exist.",
  },
};

export const loadTemplatesErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour afficher les modèles.",
          en: "You do not have the required permission to view templates.",
        },
      };

    default:
      return { ...error500orUnknown };
  }
};

export const singleTemplateErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour afficher ce modèle.",
          en: "You do not have the required permission to view this template.",
        },
      };

    case 404:
      return error404;

    default:
      return { ...error500orUnknown };
  }
};

export const createTemplatesErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour créer un modèle.",
          en: "You do not have the required permission to create a template.",
        },
      };

    default:
      return { ...error500orUnknown };
  }
};

export const editTemplatesErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation de modifier ce modèle.",
          en: "You do not have the required permission to modify this template.",
        },
      };

    case 404:
      return error404;

    default:
      return { ...error500orUnknown };
  }
};

export const deleteTemplatesMsgHandler = (code, login) => {
  switch (code) {
    case 204:
      return {
        title: {
          fr: "Supprimé!",
          en: "Deleted!",
        },
        message: {
          fr: "Votre modèle de courrier électronique a été supprimé avec succès.",
          en: "Your email template has been deleted successfully.",
        },
      };
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour supprimer ce modèle.",
          en: "You do not have the required permission to delete this template.",
        },
      };

    case 404:
      return error404;

    default:
      return { ...error500orUnknown };
  }
};
