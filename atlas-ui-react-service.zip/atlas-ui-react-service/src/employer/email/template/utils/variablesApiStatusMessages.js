import {
  error401,
  error500orUnknown,
} from "../../../../global/utils/_commonApiStatusMessages";

export const loadVariablesErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 1200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour afficher la liste des variables.",
          en: "You do not have the required permission to view the list of variables.",
        },
      };

    default:
      return { ...error500orUnknown };
  }
};
