import {
  error401,
  error500orUnknown,
} from "global/utils/_commonApiStatusMessages";

// Not to be confused with the categories error messages in the email category
// module. It uses a different interface

export const loadCategoriesErrorMessage = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 1200);
      return { ...error401 };

    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour afficher les catégories.",
          en: "You do not have the required permission to view categories.",
        },
      };

    default:
      return { ...error500orUnknown };
  }
};
