// This exception is thrown when a provider cannot reliably tell which folder
// this refers to. Email Engine cannot tell which folder is the spam folder.
export class FolderNotAvailableFromSource extends Error {
  constructor(message = "Folder not available from this source") {
    super(message);

    this.message = message;
    this.name = "FolderNotAvailableFromSource";
  }
}
