import {
  error401,
  error500orUnknown,
  redirectToLogin,
} from "global/utils/_commonApiStatusMessages";

const error404 = {
  title: {
    fr: "Non trouvé!",
    en: "Not Found!",
  },
  message: {
    fr: "Ce message n'existe pas.",
    en: "This message does not exist.",
  },
};

const errors = {
  // when message with that given id doesn't exist, backend emits 400 error
  // saying that message doens't exist...which is essentially a 404 error
  // to the user
  400: error404,

  401: error401,

  404: error404,
};

export const emailMessageErrorHandler = (code) => {
  if (code === 401) redirectToLogin();

  return errors[code] ?? error500orUnknown;
};
