import {
  error401,
  error500orUnknown,
  redirectToLogin,
} from "global/utils/_commonApiStatusMessages";

const errors = {
  401: error401,

  403: {
    title: {
      fr: "Accès refusé!",
      en: "Access denied!",
    },
    message: {
      fr: "Vous n'avez pas l'autorisation requise pour consulter ces messages.",
      en: "You do not have the required permission to view these messages",
    },
  },
};

export const inboxErrorHandler = (code) => {
  if (code === 401) redirectToLogin();

  return errors[code] ?? error500orUnknown;
};
