import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getMessagesInFolder = async ({
  provider,
  folder,
  limit,
  offset,
}) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/messages`,
    getToken(),
    { in: encodeURIComponent(folder), limit, offset },
  );

export const getMessage = async (provider, messageId) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/messages/${
      provider === "email-engine" ? "read/" : ""
    }${messageId}`,
    getToken(),
  );

// This api only is used for email engine. Test when any other's make use of it
export const getFolders = async (provider) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `${provider}/regular-emails/folders`,
    getToken(),
  );
