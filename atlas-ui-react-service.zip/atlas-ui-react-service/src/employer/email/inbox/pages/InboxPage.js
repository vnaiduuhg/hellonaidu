import { useEffect, useState } from "react";
import { APP_ENV } from "config";
import { useEmailAccount } from "employer/sync/hooks/useEmailAccount";
import { EmailFeaturesProvider } from "employer/sync/contexts/EmailFeaturesContext";
import { useTranslation } from "global/utils/useTranslation";
import { DebugSelectEmailAccount } from "../component/DebugSelectEmailAccount";
import { Inbox } from "../component/Inbox";
import { DEFAULT_ACCOUNT_TYPE } from "../utils/constants";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

const folderTitles = {
  inbox: { fr: "Boîte de réception", en: "Inbox" },
  sent: { fr: "Envoyée", en: "Sent" },
  trash: { fr: "Corbeille", en: "Trash" },
  spam: { fr: "Pourriels", en: "Spam" },
};

export const InboxPage = ({ folder, page }) => {
  const { out } = useTranslation();
  const [accountType, setAccountType] = useState(DEFAULT_ACCOUNT_TYPE);
  const { account, isFetched, isError } = useEmailAccount(accountType);

  const title = out(
    folderTitles[folder]?.fr ?? folder[0].toUpperCase() + folder.slice(1),
    folderTitles[folder]?.en ?? folder[0].toUpperCase() + folder.slice(1),
  );

  useEffect(() => (document.title = `${title} - Workland`), [title]);

  const [selectedAccount, setSelectedAccount] = useState(
    isFetched && !isError && account,
  );

  useEffect(() => {
    setSelectedAccount(account);
  }, [isFetched, isError, account]);

  if (!isFetched) {
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;
  }

  return (
    <div className="h-100 p-3">
      {/* TODO: remove before prod. keep for now to make debugging faster */}
      {(APP_ENV === "local" || APP_ENV === "test") && (
        <DebugSelectEmailAccount
          account={selectedAccount}
          accountType={accountType}
          onAccountChange={(v) => setSelectedAccount(v)}
          onAccountTypeChange={(v) => setAccountType(v)}
        />
      )}

      {accountType && selectedAccount && (
        <EmailFeaturesProvider type={accountType} account={selectedAccount}>
          <Inbox folder={folder} page={page} />
        </EmailFeaturesProvider>
      )}
    </div>
  );
};
