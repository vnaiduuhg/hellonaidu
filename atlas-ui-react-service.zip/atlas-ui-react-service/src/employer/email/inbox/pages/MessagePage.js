import { useParams } from "react-router";
import { Message } from "../component/Message";
import { DEFAULT_ACCOUNT_TYPE } from "../utils/constants";
import { useEmailAccount } from "employer/sync/hooks/useEmailAccount";
import { EmailFeaturesProvider } from "employer/sync/contexts/EmailFeaturesContext";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { useTranslation } from "global/utils/useTranslation";

export const MessagePage = () => {
  const { messageId } = useParams();
  const { isLoading } = useEmailAccount(DEFAULT_ACCOUNT_TYPE);
  const { out } = useTranslation();

  // Returning earlier to align with the other page loader. Error and content
  // need the padding, loader does not.

  if (isLoading)
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;

  // TODO: to view provider specific emails, need to pass account as param

  return (
    <EmailFeaturesProvider
      type={DEFAULT_ACCOUNT_TYPE}
      // providerAccountId={"nylas::59"}
    >
      <Message messageId={messageId} />
    </EmailFeaturesProvider>
  );
};
