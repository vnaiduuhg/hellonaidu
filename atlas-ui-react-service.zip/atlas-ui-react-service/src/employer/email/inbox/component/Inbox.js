import { useCallback, useContext } from "react";
import { Button, Col } from "react-bootstrap";
import { Link, useHistory } from "react-router-dom";
import { useQuery } from "react-query";
import { useDispatch } from "react-redux";
import { EmailFeaturesContext } from "employer/sync/contexts/EmailFeaturesContext";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { showMessage } from "global/store/statusMessagesSlice";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import { inboxErrorHandler } from "../errors/inboxErrorHandler";
import { InboxMessages } from "./InboxMessages";
import { queryClient } from "global/utils/queryClient";
import { AiFillLeftCircle, AiFillRightCircle } from "react-icons/ai";
import { FolderNotAvailableFromSource } from "../errors/FolderNotAvailableFromSource";
import { getFolders } from "../../inbox/apis/inboxApi";
import { UndeterminedFolderError } from "employer/sync/errors/UndeterminedFolderError";

const DEFAULT_MESSAGES_PER_PAGE = 10;

export const Inbox = ({ folder, page, limit = DEFAULT_MESSAGES_PER_PAGE }) => {
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const history = useHistory();
  const { account: emailAccount } = useContext(EmailFeaturesContext);

  const offset = limit * (page - 1);

  const onLoadFolderError = useCallback(
    (error) => {
      const errorMessage = inboxErrorHandler(error?.response?.status ?? 500);

      dispatch(
        showMessage(
          "error",
          out(errorMessage.title.fr, errorMessage.title.en),
          out(errorMessage.message.fr, errorMessage.message.en),
          8000,
        ),
      );
    },
    [dispatch, out],
  );

  const {
    data: emails,
    isError,
    error,
    isLoading,
  } = useQuery(
    // TODO: because of new changes, provider alone is not enough, need to
    // distinguish by email address and provider. Account type is also needed.
    // Alternatively, safe based on email address instead, but that means payload
    // must be converted to exactness. If a key is available one payload that is
    // has no equivalent in other providers, this option is a no go.
    [
      "messages",
      {
        provider: emailAccount?.provider,
        // account: features?.account?.id,
        email: emailAccount?.email,
        folder,
        limit,
        offset,
      },
    ],
    () => emailAccount.getMessagesInFolder({ folder, limit, offset }),
    {
      ...REACT_QUERY_GETTER_OPTIONS,

      onError(error) {
        if (
          (typeof error === "object" &&
            error instanceof FolderNotAvailableFromSource) ||
          UndeterminedFolderError
        ) {
          // no need to show popup status message. show a message indicating
          // that the folder cannot be viewed by the provider
        } else {
          onLoadFolderError(error);
        }
      },

      enabled: !!emailAccount && !!emailAccount.getMessagesInFolder,
    },
  );

  // contains both list of folders and the overriding mappings
  const { data: foldersResponse } = useQuery(
    ["folders", { provider: emailAccount?._routeName }],
    () => getFolders(emailAccount?._routeName),
    {
      enabled: !!emailAccount,
    },
  );

  // pre-fetch next page
  if (!isLoading && !isError && emails?.length === limit) {
    queryClient.prefetchQuery(
      [
        "messages",
        {
          provider: emailAccount?.provider,
          // account: features?.account?.id,
          email: emailAccount?.email,
          folder,
          limit,
          offset: limit * page,
        },
      ],
      () =>
        emailAccount.getMessagesInFolder({
          folder,
          limit,
          offset: limit * page,
        }),
      {
        ...REACT_QUERY_GETTER_OPTIONS,
        enabled: !!emailAccount && !!emailAccount.getMessagesInFolder,
      },
    );
  }

  if (isLoading)
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;

  if (isError)
    if (
      typeof error === "object" &&
      error instanceof FolderNotAvailableFromSource
    ) {
      return (
        <AtlasAlert variant="info" className="mt-3">
          {out(
            "Ce dossier n'est pas disponible pour ce fournisseur.",
            "This folder is not available from this provider.",
          )}
        </AtlasAlert>
      );
    } else if (
      typeof error === "object" &&
      error instanceof UndeterminedFolderError
    ) {
      return (
        <div className="d-flex flex-column text-center p-2 py-5">
          <AtlasAlert variant="info">
            {out(
              `Il semble que votre fournisseur de messagerie utilise un nom personnalisé pour ce dossier. Veuillez vous rendre dans les Paramètres et sélectionner manuellement le nom correct.`,
              `It looks like your Email provider is using a custom name for this folder. Please go to Settings and select the correct one manually.`,
            )}
          </AtlasAlert>

          <br />

          <div>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => history.push("/emails/settings")}
            >
              <i className="fa fa-gear me-2" />
              {out("Paramètres", "Settings")}
            </Button>
          </div>
        </div>
      );
    } else {
      return (
        <AtlasAlert variant="error" className="mt-3">
          {out("Échec du chargement des messages", "Could not load messages.")}
        </AtlasAlert>
      );
    }

  const previousPagePath = !!(page - 2)
    ? `?page=${page - 1}`
    : `/emails/${folder}`;

  return (
    <div>
      {!!emailAccount && !emailAccount.getMessagesInFolder ? (
        <emailAccount.UnsupportedFeature />
      ) : null}
      {foldersResponse && emails && (
        <>
          {emails.length > 0 ? (
            <InboxMessages folder={folder} messages={emails} />
          ) : (
            <AtlasAlert variant="info" className="mt-3">
              {out(
                "Aucun message dans ce dossier",
                "No messages in this folder",
              )}
            </AtlasAlert>
          )}
          {/* page controls */}
          {!isLoading && !isError && (
            <Col xs={12} className="mt-5 d-flex">
              <Link
                to={previousPagePath}
                hidden={page === 1}
                className="ms-2 fs-5"
              >
                <AiFillLeftCircle />
                &nbsp;
                {out("Page précédente", "Previous Page")}
              </Link>
              <Link
                to={`?page=${page + 1}`}
                hidden={emails?.length < limit}
                className="ms-auto me-2 fs-5"
              >
                {out("Page suivante", "Next Page")}&nbsp;
                <AiFillRightCircle />
              </Link>
            </Col>
          )}
        </>
      )}
    </div>
  );
};
