import { useHistory } from "react-router";
import cx from "classnames";
import { useTranslation } from "global/utils/useTranslation";
import { getTimeFormat } from "global/utils/dateTimeLanguageUtils";
import { Card, Col, Row } from "react-bootstrap";
import { IoMailOpenOutline } from "react-icons/io5";
import { IoMdMail } from "react-icons/io";
import DOMPurify from "dompurify";
import styles from "./InboxMessages.module.scss";
import { useMemo } from "react";

export const InboxMessages = ({ messages, folder }) => {
  const { out } = useTranslation();
  const history = useHistory();

  // combined to field when the to field is empty
  const combinedToField = useMemo(() => {
    return messages.map((message) => {
      return {
        ...message,
        to: [
          ...(message.to ?? []),
          ...(message.cc ?? []),
          ...(message.bcc ?? []),
        ],
      };
    });
  }, [messages]);

  return combinedToField.map((message) => {
    const sender =
      folder !== "sent"
        ? // as sender
          message.from.length === 1
          ? !!message.from?.[0]?.name
            ? message.from?.[0]?.name
            : message.from?.[0]?.email
          : `${
              !!message.from?.[0].name
                ? message.from?.[0].name
                : message.from?.[0].email
            } , ${
              !!message.from?.[1]?.name
                ? message.from?.[1]?.name
                : message.from?.[1]?.email
            }, ...`
        : // as receiver
        message.to
        ? message.to.length === 1
          ? // single recipient
            !!message.to?.[0]?.name
            ? message.to?.[0]?.name
            : message.to?.[0]?.email
          : // multiple recepients
            `${
              !!message.to[0]?.name ? message.to[0]?.name : message.to[0]?.email
            } , ${
              !!message.to[1]?.name ? message.to[1]?.name : message.to[1]?.email
            }, ...`
        : "";

    const date = getTimeFormat(message.date * 1000, "LL");
    const time = getTimeFormat(message.date * 1000, "LT");

    return (
      <Card
        as="button"
        onClick={() => history.push(`/emails/message/${message.id}`)}
        key={message.id}
        className={`${styles.message} pointer mb-3 w-100`}
      >
        <Card.Body className="p-1 w-100">
          <Row className="gy-3">
            <Col
              xs={6}
              md={3}
              xl={3}
              className={cx(
                "text-start order-1 order-md-1 text-secondary-200 d-flex align-items-center overflow-hidden",
                {
                  "fw-normal": !message.unread,
                  "fw-bold": message.unread,
                },
              )}
            >
              <div className="d-flex flex-column justify-content-center h-100 w-100">
                <div className={styles.ellipsisContainer}>
                  <span className="me-1 fs-5">
                    {message.unread ? <IoMdMail /> : <IoMailOpenOutline />}
                  </span>
                  {folder === "sent" && out("à : ", "To: ")}
                  {sender}
                </div>
              </div>
            </Col>

            <Col
              xs={12}
              md={6}
              xl={7}
              className={cx("text-start order-3 order-md-2", {
                "fw-normal": !message.unread,
                "fw-bold": message.unread,
              })}
            >
              <div className="d-flex flex-column justify-content-center h-100">
                <div
                  className={`text-secondary-200 pe-3 mb-2 mb-md-0 ${styles.ellipsisContainer}`}
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(message.subject),
                  }}
                />

                {/* show message snippet if provider returns it as part of their payload*/}
                {!!message.snippet && (
                  <div
                    className={`text-start pe-3 ${styles.ellipsisContainer}`}
                    dangerouslySetInnerHTML={{
                      __html: DOMPurify.sanitize(message.snippet),
                    }}
                  />
                )}
              </div>
            </Col>

            <Col
              xs={6}
              md={3}
              xl={2}
              className="text-soft-dark order-2 order-md-3 d-flex align-items-center justify-content-end"
            >
              <div className="text-end">
                <span className="text-nowrap ">{out(date.fr, date.en)}</span>{" "}
                <span className="text-nowrap ">{out(time.fr, time.en)}</span>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    );
  });
};
