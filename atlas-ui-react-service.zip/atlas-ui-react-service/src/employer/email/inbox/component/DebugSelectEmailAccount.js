import ReactSelect from "react-select";
import { useSyncedAccounts } from "employer/sync/hooks/useSyncedAccounts";
import { useMemo } from "react";

const getReactSelectAccountOption = (account) => ({
  value: account,
  label: (
    <span>
      <b>{account.email}</b> | <em>{account.provider}</em>
    </span>
  ),
});

export const DebugSelectEmailAccount = ({
  account,
  accountType,
  onAccountChange,
  onAccountTypeChange,
}) => {
  if (!accountType) throw new Error("accountType is required");

  const { accounts, accountTypes, isFetched } = useSyncedAccounts();

  const typeOptions = accountTypes.map((t) => ({ value: t, label: t }));

  const accountOptions = useMemo(() => {
    return !!accounts
      ? [...accounts]
          .filter((a) => a.type === accountType)
          .map((a) => getReactSelectAccountOption(a))
      : null;
  }, [accountType, accounts]);

  return (
    <div>
      <div className="p-3 border border-info rounded ">
        <div className="p-2">
          Email account selector for <strong>debug-only</strong>. Will be
          removed before going live. Logic for selecting account on this page is
          on Sync page (setting to default). Turning this into a feature is
          possible w/ minimal changes for regular emails.
        </div>

        <div className="d-flex">
          <ReactSelect
            className="pe-2 w-50"
            isLoading={!isFetched}
            loadingMessage={() => "Loading..."}
            options={typeOptions}
            value={
              isFetched ? { value: accountType, label: accountType } : null
            }
            onChange={(accountType) => {
              onAccountTypeChange(accountType.value);
              onAccountChange(null);
            }}
          />

          <ReactSelect
            className="w-100"
            isLoading={!isFetched}
            options={accountOptions}
            value={account ? getReactSelectAccountOption(account) : null}
            onChange={(account) => onAccountChange(account.value)}
          />
        </div>
      </div>
      <div className="py-1" />
    </div>
  );
};
