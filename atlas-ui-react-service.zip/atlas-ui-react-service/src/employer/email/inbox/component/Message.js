import { useContext, useEffect, useMemo } from "react";
import { useHistory } from "react-router";
import { useDispatch } from "react-redux";
import { useQuery } from "react-query";
import { sanitize } from "dompurify";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { useTranslation } from "global/utils/useTranslation";
import { getTimeFormat } from "global/utils/dateTimeLanguageUtils";
import { Button } from "react-bootstrap";
import { AiOutlineDoubleLeft } from "react-icons/ai";
import styles from "global/styles/styled-elements.module.scss";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import { emailMessageErrorHandler } from "../errors/emailMessageErrorHandler";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { showMessage } from "global/store/statusMessagesSlice";
import { EmailFeaturesContext } from "employer/sync/contexts/EmailFeaturesContext";

export const Message = ({ messageId }) => {
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const history = useHistory();
  const { account: emailAccount } = useContext(EmailFeaturesContext);

  const {
    data: message,
    isLoading,
    isError,
  } = useQuery(
    ["message", { account: emailAccount?.email, id: messageId }],
    () => emailAccount?.getMessage(messageId),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      enabled: !!emailAccount && !!emailAccount?.getMessage,

      onError(error) {
        const errorMessage = emailMessageErrorHandler(
          error?.response?.status ?? 500,
        );

        dispatch(
          showMessage(
            "error",
            out(errorMessage.title.fr, errorMessage.title.en),
            out(errorMessage.message.fr, errorMessage.message.en),
            8000,
          ),
        );
      },
    },
  );

  useEffect(() => {
    document.title = `${
      message?.subject
        ? sanitize(message.subject)
        : out("Chargement du message...", "Message loading...")
    } - Workland`;
  }, [message?.subject, out]);

  const createdAtTime = useMemo(
    () => (message ? getTimeFormat(message.date * 1000, "LLL") : null),
    [message],
  );

  if (isLoading)
    return <NestedPageLoader message={out("Chargement...", "Loading...")} />;

  return (
    <div className="p-2 pt-3">
      {!!emailAccount && !emailAccount.getMessage ? (
        <emailAccount.UnsupportedFeature />
      ) : null}
      {isError && (
        <AtlasAlert variant="error" className="mt-3">
          {out(
            "Échec de la réception du message électronique",
            "Failed to get email message",
          )}
        </AtlasAlert>
      )}
      {message && (
        <Row className="text-start">
          <Col xs={12} className="text-start mb-4">
            <div className="d-flex">
              <Button
                variant="tertiary"
                className="me-2"
                onClick={history.goBack}
              >
                <AiOutlineDoubleLeft />
              </Button>

              <div className="align-self-center">
                {/* TODO: switch to folder name */}
                <span className="h5">{out("Retourner", "Go back")}</span>
              </div>
            </div>
          </Col>

          <Col xs={12}>
            <h2 className="h3">{sanitize(message.subject)}</h2>
          </Col>

          <Col xs={12} md={8}>
            {/* TODO: find the correct icon, this is slightly different */}
            {/* <FaUserCircle className="me-2" aria-hidden="true" /> */}

            {/* using original in the meantime */}
            <i className="fa fa-user-circle-o me-2" aria-hidden="true" />
            {message.from[0].name}
            <span> {message.from[0].email}</span>
          </Col>
          <Col xs={12} md={4} className="text-end">
            {out(createdAtTime.fr, createdAtTime.en)}
          </Col>

          <Col xs={12}>
            <hr className={`${styles.lineBreak} my-3`} />
          </Col>
          <Col
            xs={12}
            dangerouslySetInnerHTML={{ __html: sanitize(message.body) }}
          />
        </Row>
      )}
    </div>
  );
};
