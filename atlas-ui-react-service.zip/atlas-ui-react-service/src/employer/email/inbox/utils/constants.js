export const DEFAULT_ACCOUNT_TYPE = "regular";
