import {
  deleteRestrictedApi,
  getRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
import store from "global/store/store";

export const getAllSignatures = async () =>
  await getRestrictedApi(
    serviceNames.messaging,
    "email-signatures",
    getToken(),
  );

export const getUserSignatures = async (
  userId = store.getState().user.data.user_id,
) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `users/${userId}/email-signatures`,
    getToken(),
  );

export const getSignature = async (signatureId) =>
  await getRestrictedApi(
    serviceNames.messaging,
    `email-signatures/${signatureId}`,
    getToken(),
  );

export const editSignature = async (id, data) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.messaging,
      `email-signatures`,
      getToken(),
      id,
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteSignature = async (id) => {
  try {
    const response = await deleteRestrictedApi(
      serviceNames.messaging,
      `email-signatures/${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const createSignature = async (data) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.messaging,
      `email-signatures`,
      getToken(),
      data,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
