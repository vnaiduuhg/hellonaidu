import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "react-query";
import { useState, useEffect, useRef } from "react";
import { useHistory, useParams } from "react-router";
import { useTranslation } from "global/utils/useTranslation";
import { CKEditor } from "ckeditor4-react";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { ResetSignatureModal } from "./ResetSignatureModal";
import { updateSignatureMsgHandler } from "../utils/signatureMessageHandler";
import { editSignature } from "../api/signatureApi";
import { CKEDITOR4_PROPS } from "global/constants/CKEDITOR4_PROPS";
import { useUserLocation } from "global/hooks/useUserLocation";
import {
  Button,
  FloatingLabel,
  Form,
  OverlayTrigger,
  Tooltip,
} from "react-bootstrap";
import { AiFillInfoCircle } from "react-icons/ai";
import { PreviewSignatureModal } from "./PreviewSignatureModal";
import styles from "../assets/SignaturePage.module.scss";

const EditSignature = ({ signature }) => {
  const {
    data: { user_id: userId },
  } = useSelector((s) => s.user);
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const history = useHistory();
  const params = useParams();
  const ckEditors = useRef({ en: null, fr: null });
  const signatureId = params.signatureId;
  const [selectResetLocale, setSelectResetLocale] = useState();
  const [showResetModal, setShowResetModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const {
    isLoading: isUserLocationLoading,
    isError: isUserLocationError,
    error,
  } = useUserLocation(userId);

  const { register, handleSubmit, setValue, getValues } = useForm({
    defaultValues: {
      translation: {
        signature_french: signature.translations[1].body,
        signature_english: signature.translations[0].body,
      },
      name: {
        french: signature.translations[1].name,
        english: signature.translations[0].name,
      },
      is_shared_with_account: !!(signature.is_shared_with_account ?? 0),
    },
  });
  const translatedTitle = out("Editer la signature", "Edit Signature");
  const handleCancel = () => history.replace("/emails/signature");

  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const updateSignature = useMutation(
    (data) => editSignature(signatureId, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(["user-signatures", { id: userId }]);
        const msg = updateSignatureMsgHandler(200);
        dispatch(
          showMessage(
            "ok",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            5000,
          ),
        );
        dispatch(statusMessagesSlice.actions.clearLoaders());
        history.replace("/emails/signature");
      },
      onError: (error) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        const msg = updateSignatureMsgHandler(error?.status ?? 500, () =>
          history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  const onSubmit = (data) => {
    const payload = {
      translations: [
        {
          name: data.name.english,
          body: data.translation.signature_english,
          locale: "en",
        },
        {
          name: data.name.french,
          body: data.translation.signature_french,
          locale: "fr",
        },
      ],
      is_shared_with_account: data.is_shared_with_account ? 1 : 0,
    };

    dispatch(showLoadingBarWithoutMessage(200000));
    updateSignature.mutate(payload);
  };

  return (
    <div>
      <div className="mt-5 border-bottom visually-hidden">
        <h1 className="h4 text-body">
          {out("Personnalisez votre signature :", "Customize your signature:")}
        </h1>
      </div>
      <div className="mt-4">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="d-block d-lg-flex">
            <div className="mx-1 w-100">
              <p className="text-center fs-5 fw-500 text-secondary-100">
                {out("Signature anglaise", "English Signature")}
              </p>
              <FloatingLabel
                label={
                  <>
                    {out("Nom", "Name")}
                    <span className={styles.mandatory}> *</span>
                  </>
                }
              >
                <Form.Control
                  className="mb-2"
                  type="text"
                  defaultValue={signature.translations[0].name}
                  {...register("name.english")}
                  placeholder=" "
                  // placeholder={out("Entrez votre nom", "Enter Your Name")}
                  maxLength={100}
                />
              </FloatingLabel>

              <div className="py-1">Message:</div>

              <div className="m-0">
                <CKEditor
                  {...CKEDITOR4_PROPS}
                  initData={signature.translations[0].body}
                  onInstanceReady={({ editor }) => {
                    ckEditors.current.en = editor;
                  }}
                  onChange={({ editor }) => {
                    setValue("translation.signature_english", editor.getData());
                  }}
                />
              </div>
              <div className="mt-2 d-flex justify-content-between">
                <Button
                  variant="secondary"
                  onClick={() => {
                    setShowPreviewModal(
                      getValues("translation.signature_english"),
                    );
                  }}
                >
                  {out("Prévisualiser", "Preview")}
                </Button>

                <Button
                  variant="alt-secondary"
                  disabled={isUserLocationLoading || isUserLocationError}
                  onClick={() => {
                    setShowResetModal(true);
                    setSelectResetLocale("en");
                  }}
                >
                  {out("Réinitialiser", "Reset")}
                </Button>
              </div>
            </div>

            <div className={styles.templatesSpacer} />

            <div className="mx-1 w-100">
              <p className="text-center fs-5 fw-500 text-secondary-100">
                {out("Signature française", "French Signature")}
              </p>

              <FloatingLabel
                label={
                  <>
                    {out("Nom", "Name")}{" "}
                    <span className={styles.mandatory}>*</span>
                  </>
                }
              >
                <Form.Control
                  className="mb-2"
                  type="text"
                  defaultValue={signature.translations[1].name}
                  {...register("name.french")}
                  placeholder=" "
                  // placeholder={out("Entrez votre nom", "Enter Your Name")}
                  maxLength={100}
                />
              </FloatingLabel>

              <div className="py-1">Message:</div>

              <div className="m-0">
                <CKEditor
                  {...CKEDITOR4_PROPS}
                  initData={signature.translations[1].body}
                  onInstanceReady={({ editor }) => {
                    ckEditors.current.fr = editor;
                  }}
                  onChange={({ editor }) => {
                    setValue("translation.signature_french", editor.getData());
                  }}
                />
              </div>
              <div className="mt-2 d-flex justify-content-between">
                <Button
                  variant="secondary"
                  onClick={() => {
                    setShowPreviewModal(
                      getValues("translation.signature_english"),
                    );
                  }}
                >
                  {out("Prévisualiser", "Preview")}
                </Button>

                <Button
                  variant="alt-secondary"
                  disabled={isUserLocationLoading || isUserLocationError}
                  onClick={() => {
                    setShowResetModal(true);
                    setSelectResetLocale("fr");
                  }}
                >
                  {out("Réinitialiser", "Reset")}
                </Button>
              </div>
            </div>
          </div>

          <div className="mx-1 mt-4">
            <Form.Check id="shared-signature">
              <Form.Check.Input
                type="checkbox"
                {...register("is_shared_with_account")}
              />
              <Form.Check.Label>
                {out("Partager la signature", "Shared signature")}
                <OverlayTrigger
                  placement="top"
                  overlay={
                    <Tooltip>
                      {out(
                        "Cliquez sur la coche pour partager cette signature avec tous les membres de votre organisation.",
                        "Click on the checkmark to share this signature with all members of your organisation. ",
                      )}
                    </Tooltip>
                  }
                >
                  <span>
                    <AiFillInfoCircle className="ms-1 text-info fs-5" />
                  </span>
                </OverlayTrigger>
              </Form.Check.Label>
            </Form.Check>
          </div>

          <div className="d-flex flex-row-reverse mt-3 mx-1">
            <Button variant="primary" type="submit" className="ms-3">
              {out("Sauvegarder", "Save")}
            </Button>

            <Button variant="alt-secondary" onClick={handleCancel}>
              {out("Annuler", "Cancel")}
            </Button>
          </div>
        </form>

        {showResetModal && (
          <ResetSignatureModal
            show={showResetModal}
            modalTitle={out(
              `Réinitialiser la signature ${
                selectResetLocale === "fr" ? "française " : "anglaise"
              } par défaut`,
              `Reset ${
                selectResetLocale === "fr" ? "french " : "english"
              } signature to default`,
            )}
            setShowResetModal={(e) => setShowResetModal(e)}
            selectedLocale={selectResetLocale}
            setEnglishSignature={(signature) => {
              setValue("translation.signature_english", signature);
              ckEditors.current?.en?.setData(signature);
            }}
            setFrenchSignature={(signature) => {
              setValue("translation.signature_french", signature);
              ckEditors.current?.fr?.setData(signature);
            }}
          />
        )}
      </div>

      {!!showPreviewModal && (
        <PreviewSignatureModal
          show={!!showPreviewModal}
          onHide={() => setShowPreviewModal(false)}
          // language specific signaure is set in showPreviewModal
          signature={showPreviewModal}
        />
      )}
    </div>
  );
};
export default EditSignature;
