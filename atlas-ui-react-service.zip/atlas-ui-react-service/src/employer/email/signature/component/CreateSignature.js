import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";
import { useMutation } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { useQueryClient } from "react-query";
import { useHistory } from "react-router";
import { CKEditor } from "ckeditor4-react";
import statusMessagesSlice, {
  showLoadingBarWithoutMessage,
  showMessage,
} from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import { createSignature } from "../api/signatureApi";
import { createSignatureMsgHandler } from "../utils/signatureMessageHandler";
import { CKEDITOR4_PROPS } from "global/constants/CKEDITOR4_PROPS";
import {
  Button,
  FloatingLabel,
  Form,
  OverlayTrigger,
  Tooltip,
} from "react-bootstrap";
import { AiFillInfoCircle } from "react-icons/ai";
import styles from "../assets/SignaturePage.module.scss";
import { PreviewSignatureModal } from "./PreviewSignatureModal";

export const CreateSignature = ({ defaultSignature }) => {
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const queryClient = useQueryClient();
  const history = useHistory();
  const { out } = useTranslation();
  const {
    data: { user_id: userId },
  } = useSelector((s) => s.user);
  const dispatch = useDispatch();

  const translatedTitle = out("Créer Signature", "Create Signature");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = useForm({
    defaultValues: {
      signature_english: defaultSignature,
      signature_french: defaultSignature,
      name_english: "",
      name_french: "",
      is_shared_with_account: false,
    },
  });

  const createNewSignature = useMutation(
    (payload) => {
      dispatch(showLoadingBarWithoutMessage(200000));
      return createSignature(payload);
    },
    {
      onMutate: async (newSignature) => {
        await queryClient.cancelQueries(["user-signatures", { id: userId }]);

        const previousSignatures = queryClient.getQueryData([
          "user-signatures",
          { id: userId },
        ]);

        const tempSignature = {
          account_id: null,
          ...newSignature.translations[0],
          ...newSignature,
        };

        delete tempSignature.locale;

        try {
          queryClient.setQueryData(
            ["user-signatures", { id: userId }],
            (previous = []) => [...previous, tempSignature],
          );
        } catch (e) {
          // in case of an error allow the cache to reset itself when request
          // settles
          queryClient.setQueryData(
            ["user-signatures", { id: userId }],
            () => [],
          );
        }

        return { previousSignatures };
      },

      onSuccess: async (response) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.setQueryData(
          ["user-signatures", { id: userId }],
          (previous) =>
            previous.map((p) =>
              typeof p.id !== "undefined" ? p : { ...response },
            ),
        );

        const msg = createSignatureMsgHandler(201);
        dispatch(
          showMessage(
            "ok",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            5000,
          ),
        );

        history.push("/emails/signature");
      },

      onError: (error, _, context) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.setQueryData(
          ["user-signatures", { id: userId }],
          context.previousSignatures,
        );

        const msg = createSignatureMsgHandler(error?.status ?? -1, () =>
          history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  useEffect(() => {
    setValue("signature_english", defaultSignature);
    setValue("signature_french", defaultSignature);
  }, [defaultSignature]);

  const onSubmit = ({
    name_english,
    name_french,
    signature_english,
    signature_french,
    is_shared_with_account,
  }) => {
    createNewSignature.mutate({
      translations: [
        {
          name: name_english,
          body: signature_english,
          locale: "en",
        },
        {
          name: name_french,
          body: signature_french,
          locale: "fr",
        },
      ],
      is_shared_with_account: is_shared_with_account ? 1 : 0,
    });
  };

  return (
    <div>
      <div className="mt-5 border-bottom visually-hidden">
        <h1 className="h4 text-body">
          {out("Créez votre signature", "Create your signature")}
        </h1>
      </div>

      <div className="mt-4">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="d-block d-lg-flex">
            <div className="mx-1 w-100">
              <p className="text-center fs-5 fw-500 text-secondary-100">
                {out("Signature anglaise", "English Signature")}
              </p>
              <div className="mb-2">
                <div>
                  <FloatingLabel
                    className="w-100"
                    label={
                      <>
                        {out("Nom", "Name")}
                        <span className={styles.mandatory}> *</span>
                      </>
                    }
                  >
                    <Form.Control
                      type="text"
                      id="name"
                      // placeholder={out("Entrez votre nom", "Enter Your Name")}
                      placeholder=" "
                      maxLength={100}
                      {...register("name_english", { required: true })}
                    />
                  </FloatingLabel>

                  <div className="text-warning text-end fs-7">
                    {errors?.name_english && (
                      <div>{out("Champ obligatoire", "Required")}</div>
                    )}
                  </div>
                </div>
              </div>

              <div className="py-1">Message:</div>

              <div className="m-0">
                <CKEditor
                  {...CKEDITOR4_PROPS}
                  name="my-ckeditor-english"
                  initData={getValues("signature_english")}
                  onChange={({ editor }) => {
                    setValue("signature_english", editor.getData());
                  }}
                />
              </div>
              <Button
                variant="secondary"
                className="mt-3 mb-2"
                onClick={() => {
                  setShowPreviewModal(getValues("signature_english"));
                }}
              >
                {out("Prévisualiser", "Preview")}
              </Button>
            </div>

            <div className={styles.templatesSpacer} />

            <div className="mx-1 w-100">
              <p className="text-center fs-5 fw-500 text-secondary-100">
                {out("Signature française", "French Signature")}
              </p>

              <div className="mb-2">
                <div>
                  <FloatingLabel
                    className="w-100"
                    label={
                      <>
                        {out("Nom", "Name")}
                        <span className={styles.mandatory}> *</span>
                      </>
                    }
                  >
                    <Form.Control
                      type="text"
                      id="name"
                      // placeholder={out("Entrez votre nom", "Enter Your Name")}
                      placeholder=" "
                      maxLength={100}
                      {...register("name_french", { required: true })}
                    />
                  </FloatingLabel>

                  <div className="text-warning text-end fs-7">
                    {errors?.name_french && (
                      <div>{out("Champ obligatoire", "Required")}</div>
                    )}
                  </div>
                </div>
              </div>

              <div className="py-1">Message:</div>

              <div className="m-0">
                <CKEditor
                  {...CKEDITOR4_PROPS}
                  name="my-ckeditor-french"
                  initData={getValues("signature_french")}
                  onChange={({ editor }) => {
                    setValue("signature_french", editor.getData());
                  }}
                />
              </div>
              <Button
                variant="secondary"
                className="mt-3 mb-2"
                onClick={() => {
                  setShowPreviewModal(getValues("signature_french"));
                }}
              >
                {out("Prévisualiser", "Preview")}
              </Button>
            </div>
          </div>

          <div className="mx-1 mt-3">
            <Form.Check id="shared-signature">
              <Form.Check.Input
                type="checkbox"
                {...register("is_shared_with_account")}
              />
              <Form.Check.Label>
                {out("Partager la signature", "Shared signature")}
                <OverlayTrigger
                  placement="top"
                  overlay={
                    <Tooltip>
                      {out(
                        "Cliquez sur la coche pour partager cette signature avec tous les membres de votre organisation.",
                        "Click on the checkmark to share this signature with all members of your organisation. ",
                      )}
                    </Tooltip>
                  }
                >
                  <span>
                    <AiFillInfoCircle className="ms-1 text-info fs-5" />
                  </span>
                </OverlayTrigger>
              </Form.Check.Label>
            </Form.Check>
          </div>

          <div className="d-flex flex-row-reverse mt-3 mx-1">
            <Button variant="primary" type="submit" className="ms-3">
              {out("Sauvegarder", "Save")}
            </Button>

            <Button variant="alt-secondary" as={Link} to={`/emails/signature`}>
              {out("Annuler", "Cancel")}
            </Button>
          </div>
        </form>
      </div>

      {!!showPreviewModal && (
        <PreviewSignatureModal
          show={!!showPreviewModal}
          onHide={() => setShowPreviewModal(false)}
          // language specific signaure is set in showPreviewModal
          signature={showPreviewModal}
        />
      )}
    </div>
  );
};
