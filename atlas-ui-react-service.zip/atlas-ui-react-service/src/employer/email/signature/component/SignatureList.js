import { useTranslation } from "global/utils/useTranslation";
import { useDispatch } from "react-redux";
import { showMessage } from "global/store/statusMessagesSlice";
import { useMutation, useQueryClient } from "react-query";
import { deleteSignature } from "../api/signatureApi";
import { deleteSignatureMsgHandler } from "../utils/signatureMessageHandler";
import { useHistory } from "react-router";
import { useCallback, useState } from "react";
import store from "global/store/store";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { Button, Card, OverlayTrigger, Tooltip } from "react-bootstrap";
import { BiEdit, BiTrash } from "react-icons/bi";
import cx from "classnames";
import styles from "../assets/SignaturePage.module.scss";
import { FaShareSquare } from "react-icons/fa";

const SignatureList = (props) => {
  const { out } = useTranslation();
  const { id, translations, is_shared_with_account } = props.signature;
  const [showDeleteLoader, setShowDeleteLoader] = useState(false);
  const history = useHistory();
  const queryClient = useQueryClient();
  const userId = store.getState().user.data.user_id ?? null;

  const dispatch = useDispatch();
  let frBody, enBody, frName, enName;

  const deleteSignatureById = useMutation((id) => deleteSignature(id), {
    onSuccess: async () => {
      await queryClient.invalidateQueries(["user-signatures", { id: userId }]);

      const msg = deleteSignatureMsgHandler(204);
      dispatch(
        showMessage(
          "ok",
          out(msg.title.fr, msg.title.en),
          out(msg.message.fr, msg.message.en),
          5000,
        ),
      );
      setShowDeleteLoader(false);
      history.replace("/emails/signature");
    },
    onError: (error) => {
      setShowDeleteLoader(false);
      const msg = deleteSignatureMsgHandler(error?.status ?? 500, () =>
        history.replace("/"),
      );
      dispatch(
        showMessage(
          "error",
          out(msg.title.fr, msg.title.en),
          out(msg.message.fr, msg.message.en),
          8000,
        ),
      );
    },
  });

  translations.filter((translation) => {
    if (translation.locale === "fr") {
      frBody = translation.body;
      frName = translation.name;
    } else {
      enBody = translation.body;
      enName = translation.name;
    }
  });

  const addOnClickListner = useCallback(
    () => history.push(`/emails/signature/${id}`),
    [history, id],
  );

  const onDeleteHandler = () => {
    setShowDeleteLoader(true);
    deleteSignatureById.mutate(id);
  };

  return (
    <Card className={`${styles.card} mb-4 bg-white`}>
      {!!is_shared_with_account && (
        <div className="position-absolute bottom-0 start-0 mb-3 ms-3">
          <OverlayTrigger
            placement="right"
            overlay={
              <Tooltip>
                {out(
                  "Cette signature est partagée avec les membres de votre organisation.",
                  "This signature is shared with members of your organisation.",
                )}
              </Tooltip>
            }
          >
            <span
              className={`border border-1 rounded p-1 me-2 ${styles.sharedIcon}`}
            >
              <FaShareSquare className="mx-2" />
            </span>
          </OverlayTrigger>
        </div>
      )}
      <Card.Header className="border-0 bg-white p-4 pb-0 d-flex">
        <Card.Title className="flex-fill">{out(frName, enName)}</Card.Title>

        <div
          className={cx("ms-auto min-w-max-content", {
            invisible: showDeleteLoader,
          })}
        >
          <Button
            variant="secondary"
            className="btn-frameless-icon mx-1 fs-5"
            title={out("Modifier", "Update")}
            onClick={addOnClickListner}
          >
            <BiEdit />
          </Button>

          <Button
            variant="danger"
            className="btn-frameless-icon ms-1 fs-5"
            title={out("Supprimer", "Delete")}
            onClick={onDeleteHandler}
          >
            <BiTrash />
          </Button>
        </div>
      </Card.Header>

      {showDeleteLoader ? (
        <Card.Body className="py-5 my-4">
          <ComponentLoader
            message={out("Suppression de la signature", "Deleting signature")}
          />
        </Card.Body>
      ) : (
        <Card.Body>
          <div
            className="d-flex justify-content-center"
            dangerouslySetInnerHTML={{
              __html: out(
                frBody ? frBody : `Cette signature est en anglais`,
                enBody ? enBody : `This Signature is in French`,
              ),
            }}
          />
        </Card.Body>
      )}
    </Card>
  );
};
export default SignatureList;
