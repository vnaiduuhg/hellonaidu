import { Modal } from "react-bootstrap";
import DOMPurify from "dompurify";
import styles from "../assets/SignaturePage.module.scss";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import { useLayoutEffect, useRef, useState } from "react";

export const PreviewSignatureModal = ({ show, onHide, signature }) => {
  const { out } = useTranslation();
  const $signature = useRef(null);
  const [signatureWidth, setSignatureWidth] = useState(null);

  useLayoutEffect(() => {
    if ($signature.current && $signature.current.clientWidth) {
      setSignatureWidth($signature.current.clientWidth);
    }
  }, []);

  return (
    <Modal show={show} onHide={onHide} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          {out("Prévisualisation Signature", "Preview Signature")}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {signatureWidth && signatureWidth > 600 && (
          <AtlasAlert variant="warning">
            {out(
              `
              Il semble que votre signature soit plus large que la largeur
              recommandée de 600px. Cela peut entraîner une distorsion de votre
              signature sur les appareils mobiles. Veuillez envisager de réduire
              la largeur de votre signature en ajoutant de nouvelles lignes ou
              en réduisant la taille des images s'il y en a.
            `,
              `
              It looks like your signature is wider than the recommended width of
              600px. This may cause your signature to look distorted on mobile
              devices. Please consider reducing the width of your signature by
              adding new lines or reducing image sizes.
          `,
            )}
          </AtlasAlert>
        )}
        <div className="ms-1">{out("Prévisualisation :", "Preview:")}</div>
        <div className="d-flex justify-content-center p-2 py-2">
          <div
            className={`border border-secondary border-2 ${styles.overflowAuto}`}
          >
            <div
              className={styles.maxContentWidth}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(signature),
              }}
              ref={$signature}
            />
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
};
