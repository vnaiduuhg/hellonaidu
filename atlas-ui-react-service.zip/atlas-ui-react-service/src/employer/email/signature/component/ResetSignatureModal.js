import { useTranslation } from "global/utils/useTranslation";
import { useDispatch, useSelector } from "react-redux";
import {
  generateDefaultSignature,
  missingLocationWarning,
} from "../utils/generateDefaultSignature";
import { showMessage } from "global/store/statusMessagesSlice";
import { Button, Modal } from "react-bootstrap";

export const ResetSignatureModal = ({
  show,
  modalTitle,
  setShowResetModal,
  selectedLocale,
  setEnglishSignature,
  setFrenchSignature,
}) => {
  const { out } = useTranslation();
  const {
    accountUser,
    profilePage,
    location,
    data: { user_id: userId },
  } = useSelector((s) => s.user);
  const dispatch = useDispatch();
  const signatureBody = generateDefaultSignature(
    accountUser.find((a) => a.user_id === userId),
    profilePage,
    location,
  );

  const onResetSignatureHandler = () => {
    if (!location) {
      const warning = missingLocationWarning;
      dispatch(
        showMessage(
          warning.status,
          out(warning.title.fr, warning.title.en),
          out(warning.message.fr, warning.message.en),
          warning.timeout,
        ),
      );
    }

    if (selectedLocale === "en") {
      setEnglishSignature(signatureBody);
    } else {
      setFrenchSignature(signatureBody);
    }

    setShowResetModal("");
  };

  return (
    <Modal show={show} onHide={() => setShowResetModal(false)} centered>
      <Modal.Header closeButton>
        <Modal.Title>{modalTitle}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {out(
          `Vous perdrez votre signature personnalisée, êtes-vous sûr de vouloir réinitialiser?`,
          `You will lose your customized signature, are you sure you want to reset?`,
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="secondary"
          className="mx-2"
          onClick={onResetSignatureHandler}
        >
          {out("OUI", "YES")}
        </Button>
        <Button
          variant="alt-secondary"
          onClick={() => setShowResetModal(false)}
        >
          {out("ANNULER", "CANCEL")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};
