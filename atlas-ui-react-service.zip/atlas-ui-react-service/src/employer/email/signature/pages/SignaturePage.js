import { useEffect } from "react";
import { getUserSignatures } from "../api/signatureApi";
import { Redirect, useHistory } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useQuery } from "react-query";
import statusMessagesSlice, {
  showMessage,
} from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import { viewSignaturesMsgHandler } from "../utils/signatureMessageHandler";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import SignatureList from "../component/SignatureList";
import ActionButton from "global/components/action-button/action-button";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

export const SignaturePage = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const userId = useSelector((s) => s.user.data.user_id ?? null);
  const { out } = useTranslation();

  const {
    data: signatures,
    isError,
    isLoading,
    error,
  } = useQuery(
    ["user-signatures", { id: userId }],
    () => getUserSignatures(userId),
    {
      ...REACT_QUERY_GETTER_OPTIONS,

      onError(error) {
        const msg = viewSignaturesMsgHandler(
          error?.response?.status ?? 500,
          () => history.replace("/"),
        );
        dispatch(
          showMessage(
            "error",
            out(msg.title.fr, msg.title.en),
            out(msg.message.fr, msg.message.en),
            8000,
          ),
        );
      },
    },
  );

  useEffect(() => {
    document.title = `Signature - Workland`;

    return () => {
      // clear loader in case page is exitted before loading is finished
      dispatch(statusMessagesSlice.actions.clearLoaders());
    };
  }, [dispatch]);

  const createNewSignature = () => history.push("/emails/signature/create");

  let content;
  if (isError) {
    content = (
      <AtlasAlert variant="danger">
        {out(
          "Les signatures n'ont pu être récupérées",
          "Signatures could not be retrieved",
        )}
      </AtlasAlert>
    );
  } else if (isLoading) {
    content = (
      <NestedPageLoader
        message={out("Récupérer vos signatures", "Fetching Your Signatures")}
      />
    );
  } else {
    if (signatures.length) {
      content = (
        <div className="p-2 pt-3">
          <h1 className="h3 mb-4 visually-hidden">
            {out("Signature", "Signature")}
          </h1>

          <ActionButton click={createNewSignature} />

          {signatures.map((s) => (
            <SignatureList
              key={s.id}
              createSignature={createNewSignature}
              signature={s}
            />
          ))}
        </div>
      );
    } else {
      content = <Redirect to="/emails/signature/create" />;
    }
  }

  return content;
};
