import { useEffect, useRef, useState } from "react";
import { Redirect, useParams, useHistory } from "react-router";
import { useDispatch } from "react-redux";
import { getSignature } from "../api/signatureApi";
import EditSignature from "../component/EditSignature";
import { updateSignatureMsgHandler } from "../utils/signatureMessageHandler";
import { showMessage } from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";

export const EditSignaturePage = () => {
  const dispatch = useDispatch();
  const { out } = useTranslation();
  const history = useHistory();
  const [signature, setSignature] = useState(null);
  const [signatureError, setSignatureError] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const signatureId = +useParams().signatureId;
  const validSignature = useRef(true);

  if (
    isNaN(signatureId) ||
    Math.round(signatureId) !== signatureId ||
    signatureId < 1
  ) {
    validSignature.current = false;
  }

  useEffect(() => {
    if (validSignature.current) {
      getSignature(signatureId)
        .then((response) => {
          setSignature(response);
          setIsLoading(false);
        })
        .catch((error) => {
          if (
            error.response?.status &&
            [401, 403, 404, 500].includes(error.response.status)
          ) {
            const msg = updateSignatureMsgHandler(error.response.status, () =>
              history.replace("/"),
            );
            dispatch(
              showMessage(
                "error",
                out(msg.title.fr, msg.title.en),
                out(msg.message.fr, msg.message.en),
                6000,
              ),
            );
          }
          setSignatureError(true);
          setIsLoading(false);
        });
    }
  }, []);

  if (!validSignature.current) {
    return <Redirect to="/emails/signature" />;
  }

  return (
    <>
      {!!signature && !signatureError && (
        <EditSignature signature={signature} />
      )}
      {isLoading && (
        <NestedPageLoader
          message={out("Nous téléchargeons la signature", "Loading signature")}
        />
      )}
      {signatureError && (
        <AtlasAlert variant="danger">
          {out(
            "La signature n'a pu être récupérée",
            "The signature could not be retrieved",
          )}
        </AtlasAlert>
      )}
    </>
  );
};
