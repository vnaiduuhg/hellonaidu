import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CreateSignature } from "../component/CreateSignature";
import { useTranslation } from "global/utils/useTranslation";
import { useUserLocation } from "global/hooks/useUserLocation";
import { showMessage } from "global/store/statusMessagesSlice";
import {
  generateDefaultSignature,
  missingLocationWarning,
} from "../utils/generateDefaultSignature";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

export const CreateSignaturePage = () => {
  const { out } = useTranslation();
  const {
    data: { user_id: userId },
    location,
    accountUser,
    profilePage,
  } = useSelector((s) => s.user);
  const dispatch = useDispatch();

  const translatedTitle = out("Créer Signature", "Create Signature");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  const { isLoading } = useUserLocation(userId);

  // Error should not prevent users from creating a signature. It should just
  // not provide that data (eg: don't create address)
  useEffect(() => {
    if (!isLoading && !location) {
      const warning = missingLocationWarning;
      dispatch(
        showMessage(
          warning.status,
          out(warning.title.fr, warning.title.en),
          out(warning.message.fr, warning.message.en),
          warning.timeout,
        ),
      );
    }
  }, [isLoading, location]);

  return isLoading ? (
    <NestedPageLoader
      message={out("Veuillez patienter...", "Please wait...")}
    />
  ) : (
    <CreateSignature
      defaultSignature={generateDefaultSignature(
        accountUser.find((a) => a.user_id === userId),
        profilePage,
        location,
      )}
    />
  );
};
