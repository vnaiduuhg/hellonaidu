import { ATLAS_UI_URL, MINIO_URL } from "config";
import { out } from "global/utils/useTranslation";

const picPhone = `${ATLAS_UI_URL}shared-components/icons/new-social-icon/phone.png`;
const picAt = `${ATLAS_UI_URL}shared-components/icons/new-social-icon/at.png`;
const picMobile = `${ATLAS_UI_URL}shared-components/icons/new-social-icon/mobile.png`;
const picLocation = `${ATLAS_UI_URL}shared-components/icons/new-social-icon/pin.png`;

export const generateDefaultSignature = (
  accountInfo,
  profileInfo,
  location,
) => {
  const logoImage =
    profileInfo && profileInfo[0].alternate_logo_2
      ? profileInfo[0].alternate_logo_2
      : profileInfo[0].logo;
  const logo = `${MINIO_URL}media/Profile/Logos/${logoImage}`;

  const email = accountInfo.user.email;
  const name = accountInfo.user.first_name + " " + accountInfo.user.last_name;

  const phone =
    (accountInfo.user.phone ?? "(###) ###-####") +
    (accountInfo?.contact?.phone_extension
      ? ` ext.: ${accountInfo.contact.phone_extension}`
      : "");

  const title = "";
  const company = profileInfo?.length
    ? (profileInfo[0]?.name ?? "").toLowerCase().replace(/\s+/g, "")
    : "";
  const socialIcon = `${ATLAS_UI_URL}shared-components/icons/new-social-icon/`;

  let address = "";

  if (location?.street_number && location?.street) {
    address = location.street_number + " " + location.street;
  }
  if (location?.city) {
    address += address != "" ? `, ${location.city}` : location.city;
  }
  if (location?.province) {
    address += address != "" ? `, ${location.province}` : location.province;
  }
  if (location?.country) {
    address += address != "" ? `, ${location.country}` : location.country;
  }
  if (location?.postal_code) {
    address +=
      address != "" ? ` ${location.postal_code}` : location.postal_code;
  }

  if (address === "") address = out("< addresse >", "< address >");

  // source: https://github.com/worklandcom/atlas-ui-service/blob/master/src/employer-profile/emails/email-signature/email-signature.directive.js
  const body =
    '<table cellpadding="0" cellspacing="0">' +
    "<tbody>" +
    "<tr>" +
    '<td style="width:140px; padding:0; text-align:center; vertical-align:middle;" valign="middle" width="140">' +
    `<img alt="logo" border="0" style="max-width:100px; max-height:100px; padding:2px;" class="img img-fluid" src="${logo}"></img>` +
    "</td>" +
    '<td style="border-bottom:2px solid; border-bottom-color:#005a87; padding:0; vertical-align:top;" valign="top">' +
    '<table cellpadding="0" cellspacing="0">' +
    "<tbody>" +
    "<tr>" +
    '<td style="color:#005a87; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; vertical-align:top;" valign="top">' +
    `<strong><span style="font-family:Verdana, sans-serif; color:#005a87; font-size:14pt; font-style:italic;">${name}</span></strong><br>` +
    `<span style="font-family:Verdana, sans-serif; color:#005a87; font-size:10pt;">${title}</span>` +
    "</td>" +
    "</tr>" +
    "<tr>" +
    '<td style="font-family:Verdana, sans-serif; color:#444444; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; line-height:18px; vertical-align:top;" valign="top">' +
    `<img src="${picAt}" alt="email" />: <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${email}<br></span>` +
    `<img src="${picPhone}" alt="phone" />: <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${phone}
    <span style="font-family:Verdana, sans-serif; font-size:10pt;"> | </span>` +
    "</span>" +
    `<img src="${picMobile}" alt="cell" />: <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${phone}</span>` +
    "</td>" +
    "</tr>" +
    "<tr>" +
    '<td style="font-family:Verdana, sans-serif; color:#444444; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; line-height:18px; vertical-align:top;" valign="top">' +
    `<img src="${picLocation}" alt="location" />: <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${address}</span>` +
    "</td>" +
    "</tr>" +
    "</tbody>" +
    "</table>" +
    "</td>" +
    "</tr>" +
    "<tr>" +
    '<td style="font-family:Verdana, sans-serif; width:140px; padding-top:6px; padding-left:0; padding-right:0; text-align:center; vertical-align:middle;" valign="middle" width="140">' +
    `<span><a href="https://www.facebook.com" target="_blank" rel="noopener"><img border="0" width="16" alt="facebook icon" style="border:0; height:16px; width:16px" src="${socialIcon}facebook.png"></a>&nbsp;</span>` +
    `<span><a href="https://twitter.com/" target="_blank" rel="noopener"><img border="0" width="16" alt="twitter icon" style="border:0; height:16px; width:16px" src="${socialIcon}twitter.png"></a>&nbsp;</span>` +
    `<span><a href="https://www.youtube.com" target="_blank" rel="noopener"><img border="0" width="16" alt="youtube icon" style="border:0; height:16px; width:16px" src="${socialIcon}youtube.png"></a>&nbsp;</span>` +
    `<span><a href="https://www.linkedin.com" target="_blank" rel="noopener"><img border="0" width="16" alt="linkedin icon" style="border:0; height:16px; width:16px" src="${socialIcon}linkedin.png"></a>&nbsp;</span>` +
    "</td>" +
    '<td style="padding-top:6px; padding-bottom:0; padding-left:0; padding-right:0; vertical-align:middle;" valign="middle">' +
    `<a href="http://www.${company}.com" target="_blank" rel="noopener" style=" text-decoration:none;">` +
    '<span style="color:#005a87; font-family:Verdana, sans-serif; font-size:10pt">' +
    `<span style="color:#005a87; font-family:Verdana, sans-serif; font-size:10pt">www.${company}.com</span>` +
    "</span>" +
    "</a>" +
    "</td>" +
    "</tr>" +
    "</tbody>" +
    "</table>";

  return body;
};

export const missingLocationWarning = {
  status: "warning",
  title: { fr: "Signature", en: "Signature" },
  message: {
    fr: "Nous n'avons pas pu remplir automatiquement l'adresse de votre entreprise. Afin de rectifier cela, vous pouvez soit l'ajouter manuellement dans la signature ci-dessous, soit l'ajouter d'abord dans la page de profil de votre entreprise.",
    en: "We could not automatically fill in your company address. In order to rectify this, you can either add it manually in the signature below or add it in your company profile page first.",
  },
  timeout: 8000,
};
