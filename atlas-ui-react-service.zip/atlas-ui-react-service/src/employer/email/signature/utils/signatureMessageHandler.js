import {
  error401,
  error500orUnknown,
} from "global/utils/_commonApiStatusMessages";

const error404 = {
  title: {
    fr: "Non trouvé!",
    en: "Not Found!",
  },
  message: {
    fr: "Impossible de trouver la signature",
    en: "Could not find signature",
  },
};

export const createSignatureMsgHandler = (errorCode, login = null) => {
  switch (errorCode) {
    case 201:
      return {
        title: {
          fr: "Succès!",
          en: "Success!",
        },
        message: {
          fr: "La signature a été créée avec succès!",
          en: "The signature has been created successfully!",
        },
      };
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Permission refusée!",
          en: "Permission denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour créer une signature",
          en: "You do not have the required permission to create a signature",
        },
      };
    case 422:
      return {
        title: {
          fr: "Attention!",
          en: "Attention!",
        },
        message: {
          fr: "Veuillez vous assurer que tous les champs obligatoires sont remplis",
          en: "Please make sure that all required fields are filled",
        },
      };
    default:
      return { ...error500orUnknown };
  }
};

export const viewSignaturesMsgHandler = (errorCode, login) => {
  switch (errorCode) {
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Accès refusé!",
          en: "Access denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour afficher les signatures",
          en: "You do not have the required permission to view signatures",
        },
      };
    case 404:
      return {
        title: {
          fr: "Non trouvé!",
          en: "Not Found!",
        },
        message: {
          fr: "Aucune signature trouvée",
          en: "No signature found",
        },
      };
    default:
      return { ...error500orUnknown };
  }
};

export const deleteSignatureMsgHandler = (errorCode, login = null) => {
  switch (errorCode) {
    case 204:
      return {
        title: {
          fr: "Succès!",
          en: "Success!",
        },
        message: {
          fr: "La signature a été supprimée avec succès!",
          en: "The signature has been deleted successfully!",
        },
      };
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Permission refusée!",
          en: "Permission denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation requise pour supprimer cette signature",
          en: "You do not have the required permission to delete this signature.",
        },
      };
    case 404:
      return error404;
    default:
      return { ...error500orUnknown };
  }
};

export const updateSignatureMsgHandler = (errorCode, login = null) => {
  switch (errorCode) {
    case 200:
      return {
        title: {
          fr: "Succès!",
          en: "Success!",
        },
        message: {
          fr: "La signature a été mise à jour avec succès!",
          en: "The signature has been updated successfully!",
        },
      };
    case 401:
      setTimeout(login, 2200);
      return { ...error401 };
    case 403:
      return {
        title: {
          fr: "Permission refusée!",
          en: "Permission denied!",
        },
        message: {
          fr: "Vous n'avez pas l'autorisation pour modifier cette signature",
          en: "You do not have the required permission to modify this signature",
        },
      };
    case 404:
      return error404;
    case 422:
      return {
        title: {
          fr: "Attention!",
          en: "Attention!",
        },
        message: {
          fr: "Veuillez vous assurer que tous les champs obligatoires sont remplis",
          en: "Please make sure that all required fields are filled",
        },
      };
    default:
      return { ...error500orUnknown };
  }
};
