import { useState } from "react";
import Col from "react-bootstrap/Col";
import CategoryInput from "../components/CategoryInput";
import CategoryList from "../components/CategoryList";
import { useDispatch, useSelector } from "react-redux";
import statusMessagesSlice, {
  showMessage,
} from "global/store/statusMessagesSlice";
import { useQueryClient, useMutation } from "react-query";
import useAtlasQuery from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import {
  createCategory,
  updateCategory,
  deleteCategory,
} from "../api/categoryApi";
import {
  getCategoriesByUser,
  getCategoriesByAccount,
} from "global/apis/messagingApi";
import {
  categoryGetMsgHandler,
  categoryPostMsgHandler,
  categoryPutMsgHandler,
  categoryDeleteMsgHandler,
} from "../utils/categoryMsgHandler";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

export const CategoryPage = () => {
  const { out } = useTranslation();
  const queryClient = useQueryClient();
  const userData = useSelector((s) => s.user.data);
  const [showLoader, setShowLoader] = useState(false);

  const dispatch = useDispatch();

  let getCategoriesQuery = {};
  if (
    [100, 50, 40, 30].includes(userData.user_account?.role_id ?? 0) &&
    !!userData.user_account.account?.id
  ) {
    getCategoriesQuery.query = () =>
      getCategoriesByAccount(userData.user_account.account.id);
    getCategoriesQuery.key = {
      by: "account",
      id: userData.user_account.account.id,
    };
  } else {
    getCategoriesQuery.query = () => getCategoriesByUser(userData.user_id);
    getCategoriesQuery.key = { by: "user", id: userData.user_id };
  }

  const { data, isLoading, isFetched, isError } = useAtlasQuery(
    ["categories", getCategoriesQuery.key],
    getCategoriesQuery.query,
    {
      onError: (error) => {
        const msg = categoryGetMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
      },
    },
  );

  const categoryPostMutation = useMutation(
    (data) => createCategory({ translations: data.translations }),
    {
      onSuccess: (response) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("categories");

        const msg = categoryPostMsgHandler(201, response);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        setShowLoader(false);
      },
      onError: (error) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());

        const msg = categoryPostMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setShowLoader(false);
      },
    },
  );

  const categoryPutMutation = useMutation(
    (data) =>
      updateCategory(data.id, {
        translations: data.translations,
      }),
    {
      onSuccess: (response) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("categories");

        const msg = categoryPutMsgHandler(200, response);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        setShowLoader(false);
      },
      onError: (error) => {
        dispatch(statusMessagesSlice.actions.clearLoaders());

        const msg = categoryPutMsgHandler(error.status, error);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setShowLoader(false);
      },
    },
  );

  const categoryDeleteMutation = useMutation((id) => deleteCategory(id), {
    onSuccess: () => {
      dispatch(statusMessagesSlice.actions.clearLoaders());
      queryClient.invalidateQueries("categories");

      if (isFetched) {
        const msg = categoryDeleteMsgHandler(204);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        setShowLoader(false);
      }
    },
    onError: (error) => {
      dispatch(statusMessagesSlice.actions.clearLoaders());

      const msg = categoryDeleteMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      setShowLoader(false);
    },
  });

  let content;
  if (isLoading) {
    content = <NestedPageLoader />;
  } else if (isError) {
    content = (
      <AtlasAlert variant="error">
        {out(
          "Les catégories n'ont pas pu être récupérées",
          "The categories could not be retrieved",
        )}
      </AtlasAlert>
    );
  } else if (data?.length < 1) {
    content = (
      <AtlasAlert variant="info">
        {out(
          "Vous n'avez actuellement aucune catégorie",
          "You currently have no categories",
        )}
      </AtlasAlert>
    );
  } else if (isFetched) {
    content = (
      <CategoryList
        categories={data}
        updateCategory={categoryPutMutation.mutate}
        deleteCategory={categoryDeleteMutation.mutate}
        showLoader={showLoader}
        setShowLoader={setShowLoader}
      />
    );
  }

  return (
    <div className="p-2 pt-3">
      <CategoryInput
        createCategory={categoryPostMutation.mutate}
        showLoader={showLoader}
        setShowLoader={setShowLoader}
      />

      <hr className="my-4" />

      {content}
    </div>
  );
};
