import { out } from "global/utils/useTranslation";

export const categoryPostMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "La catégorie a été ajoutée avec succès!",
        "The category has been added successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise",
        "You do not have the required permission",
      );
      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      msg.text = out(
        "Veuillez vous assurer que tous les champs requis sont remplis",
        "Please make sure that all reqired fields are filled",
      );
      break;

    case 404:
    case 500:
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La catégorie n'a pu être sauvegardée",
        "The category could not be saved",
      );
  }
  return msg;
};

export const categoryGetMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;

    case 404:
    case 500:
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Les catégories n'ont pas pu être récupérées",
        "The categories could not be retrieved",
      );
  }
  return msg;
};

export const categoryPutMsgHandler = (code, promise) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "La catégorie a été modifiée avec succès!",
        "The category has been modified successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier une catégorie",
        "You do not have the required permission to modify a category",
      );
      break;
    case 422:
      if ("translations" in promise.data) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer que tous les champs requis sont remplis",
          "Please make sure that all required fields are filled",
        );
        break;
      }
    case 404:
    case 500:
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La catégorie n'a pu être modifiée",
        "The category could not be modified",
      );
  }

  return msg;
};

export const categoryDeleteMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "La catégorie a été supprimée avec succès!",
        "The category has been removed successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer une catégorie",
        "You do not have the required permission to remove a category",
      );
      break;
    case 404:
    case 500:
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "La catégorie sélectionnée n'a pu être supprimé",
        "The selected category could not be removed",
      );
  }

  return msg;
};
