import { useState } from "react";
import { Category } from "./Category";
import { EditCategory } from "./EditCategory";

const CategoryList = ({
  categories,
  updateCategory,
  deleteCategory,
  showLoader,
  setShowLoader,
}) => {
  const [editMode, setEditMode] = useState(
    categories.reduce(
      (old, c) => ({
        ...old,
        [c.id]: false,
      }),
      {},
    ),
  );

  return (
    <div>
      {categories.map((category) => (
        <div key={category.id}>
          {editMode[category.id] ? (
            <EditCategory
              updateCategory={updateCategory}
              deleteCategory={deleteCategory}
              category={category}
              showLoader={showLoader}
              setShowLoader={setShowLoader}
              switchToDisplayMode={() => {
                setEditMode({
                  ...editMode,
                  [category.id]: false,
                });
              }}
            />
          ) : (
            <Category
              category={category}
              deleteCategory={deleteCategory}
              switchToEditMode={() => {
                setEditMode({
                  ...editMode,
                  [category.id]: true,
                });
              }}
            />
          )}
        </div>
      ))}
    </div>
  );
};

export default CategoryList;
