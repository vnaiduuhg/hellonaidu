import { useDispatch, useSelector } from "react-redux";
import Card from "react-bootstrap/Card";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../assets/CategoryUI.module.scss";
import { showLoadingBarWithoutMessage } from "global/store/statusMessagesSlice";
import { Button, Col, Row } from "react-bootstrap";
import { BiEdit, BiTrash } from "react-icons/bi";

export const Category = ({ category, deleteCategory, switchToEditMode }) => {
  const titleEnglish = category.translations[0].name;
  const titleFrench = category.translations[1].name;
  const language = useSelector((s) => s.user.language);
  const dispatch = useDispatch();

  const { out } = useTranslation();

  const en = (
    <Col xs={6} md={5}>
      <span className="default-text-label">
        {out("Anglais: ", "English: ")}
      </span>
      <span className="text-secondary-200"> {titleEnglish}</span>
    </Col>
  );

  const fr = (
    <Col xs={6} md={5}>
      <span className="default-text-label">
        {out("Français: ", "French: ")}
      </span>
      <span className="text-secondary-200"> {titleFrench}</span>
    </Col>
  );

  return (
    <Card className={`${styles.categoryContainer} mb-3 w-100`} body>
      <Row className="gy-2">
        {language === "en" ? (
          <>
            {en}
            {fr}
          </>
        ) : (
          <>
            {fr}
            {en}
          </>
        )}

        <Col xs={12} md={2} className="text-end">
          <Button
            variant="secondary"
            className="btn-frameless-icon mx-1 fs-5"
            title={out("Modifier", "Update")}
            onClick={switchToEditMode}
          >
            <BiEdit />
          </Button>

          <Button
            variant="danger"
            className="btn-frameless-icon ms-1 fs-5"
            title={out("Supprimer", "Delete")}
            onClick={() => {
              dispatch(showLoadingBarWithoutMessage(200000));
              deleteCategory(category.id);
            }}
          >
            <BiTrash />
          </Button>
        </Col>
      </Row>
    </Card>
  );
};
