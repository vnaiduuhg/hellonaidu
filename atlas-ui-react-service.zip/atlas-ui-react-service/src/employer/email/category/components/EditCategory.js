import React, { useState, useEffect } from "react";
import Button from "react-bootstrap/Button";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";
import { useTranslation } from "global/utils/useTranslation";
import { useDispatch, useSelector } from "react-redux";
import { showLoadingBarWithoutMessage } from "global/store/statusMessagesSlice";
import ActionItemButton from "global/components/action-item-button/action-item-button";
import { FloatingLabel, Form } from "react-bootstrap";
import styles from "../assets/CategoryUI.module.scss";

export const EditCategory = ({
  category,
  updateCategory,
  deleteCategory,
  switchToDisplayMode,
}) => {
  const iniitialTitleEnglish = category.translations[0].name;
  const iniitialTitleFrench = category.translations[1].name;
  const [titleEnglish, setTitleEnglish] = useState("");
  const [titleFrench, setTitleFrench] = useState("");
  const language = useSelector((s) => s.user.language);
  const { out } = useTranslation();
  const categoryId = category.id;
  const dispatch = useDispatch();

  const titleEnglishInputHandler = (event) => {
    setTitleEnglish(event.target.value);
  };
  const titleFrenchInputHandler = (event) => {
    setTitleFrench(event.target.value);
  };

  const formSubmissionHandler = (event) => {
    event.preventDefault();
    dispatch(showLoadingBarWithoutMessage(200000));

    if (titleEnglish.trim() || titleFrench.trim()) {
      updateCategory({
        id: categoryId ?? null,
        translations: [
          {
            locale: "en",
            name: titleEnglish,
          },
          {
            locale: "fr",
            name: titleFrench,
          },
        ],
      });
    }
    switchToDisplayMode();
  };

  useEffect(() => {
    if (!titleEnglish || !titleFrench) {
      setTitleEnglish(iniitialTitleEnglish);
      setTitleFrench(iniitialTitleFrench);
    }
  }, []);

  const en = (
    <Col md={6}>
      <FloatingLabel label={out("Anglais: ", "English: ")}>
        <Form.Control
          type="text"
          name="titleEnglish"
          onChange={titleEnglishInputHandler}
          defaultValue={iniitialTitleEnglish}
        />
      </FloatingLabel>
    </Col>
  );

  const fr = (
    <Col md={6}>
      <FloatingLabel label={out("Français: ", "French: ")}>
        <Form.Control
          type="text"
          name="editTitleFrench"
          onChange={titleFrenchInputHandler}
          defaultValue={iniitialTitleFrench}
        />
      </FloatingLabel>
    </Col>
  );

  return (
    <Card className={`${styles.categoryContainer} mb-3 w-100`} body>
      <form onSubmit={formSubmissionHandler}>
        <Row className="gy-2">
          {language === "en" ? (
            <>
              {en}
              {fr}
            </>
          ) : (
            <>
              {fr}
              {en}
            </>
          )}
        </Row>

        <Row className="my-3">
          <Col>
            <ActionItemButton
              className="ms-1"
              icon="fa fa-trash-o"
              variant="danger"
              label={out("Supprimer", "Delete")}
              onClick={() => {
                dispatch(showLoadingBarWithoutMessage(200000));
                deleteCategory(categoryId);
              }}
            />
          </Col>

          <Col>
            <div className="d-flex flex-row-reverse">
              <Button type="submit" variant="primary" className="ms-2">
                {out("Mettre à jour", "Update")}
              </Button>
              <Button
                type="button"
                variant="alt-secondary"
                onClick={switchToDisplayMode}
              >
                {out("Annuler", "Cancel")}
              </Button>
            </div>
          </Col>
        </Row>
      </form>
    </Card>
  );
};
