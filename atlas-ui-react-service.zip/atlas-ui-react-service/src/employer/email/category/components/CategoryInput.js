import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import { useTranslation } from "global/utils/useTranslation";
import { useDispatch, useSelector } from "react-redux";
import { showLoadingBarWithoutMessage } from "global/store/statusMessagesSlice";
import { useForm } from "react-hook-form";
import { Card, FloatingLabel, Form } from "react-bootstrap";
import styles from "../assets/CategoryUI.module.scss";

const CategoryInput = ({ createCategory, categoryId = 0 }) => {
  const [titleEnglish, setTitleEnglish] = useState("");
  const [titleFrench, setTitleFrench] = useState("");
  const language = useSelector((s) => s.user.language);
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm();
  const enWatch = watch("enCategory");
  const frWatch = watch("frCategory");

  const titleEnglishInputClickHandler = (event) => {
    setTitleEnglish(event.target.value);
  };
  const titleFrenchInputClickHandler = (event) => {
    setTitleFrench(event.target.value);
  };

  const formSubmissionHandler = () => {
    dispatch(showLoadingBarWithoutMessage(200000));
    createCategory({
      id: categoryId ?? null,
      translations: [
        {
          locale: "en",
          name: enWatch,
        },
        {
          locale: "fr",
          name: frWatch,
        },
      ],
    });
    setValue("enCategory", "");
    setValue("frCategory", "");
  };

  const en = (
    <div className="flex-grow-1 p-md-2 mb-2 m-md-0 text-center">
      <FloatingLabel label={out("Titre anglais", "English title")}>
        <Form.Control
          type="text"
          name="titleEnglish"
          defaultValue={titleEnglish}
          onChange={titleEnglishInputClickHandler}
          placeholder=" "
          {...register("enCategory", {
            required: true,
          })}
        />
      </FloatingLabel>

      {errors.enCategory && errors.enCategory.type === "required" && (
        <div className="text-danger text-start fs-7">
          {out("Champ obligatoire", "Required")}
        </div>
      )}
    </div>
  );

  const fr = (
    <div className="flex-grow-1 p-md-2 mb-2 m-md-0 text-center">
      <FloatingLabel label={out("Titre français", "French title")}>
        <Form.Control
          type="text"
          name="titleFrench"
          defaultValue={titleFrench}
          onChange={titleFrenchInputClickHandler}
          placeholder=" "
          {...register("frCategory", {
            required: true,
          })}
        />
      </FloatingLabel>

      {errors.frCategory && errors.frCategory.type === "required" && (
        <div className="text-danger text-start fs-7">
          {out("Champ obligatoire", "Required")}
        </div>
      )}
    </div>
  );

  return (
    <form onSubmit={handleSubmit(formSubmissionHandler)}>
      <Card className={`${styles.categoryContainer} p-2 mb-3 w-100`}>
        <Card.Body className="p-0 m-0">
          <div className="d-md-flex">
            <div className="d-flex flex-grow-2 p-2 text-secondary-200 fw-500">
              <div className="d-flex flex-column justify-content-around">
                <div className="flex-fill d-flex">
                  <div className="d-none d-md-flex align-items-center">
                    {out(
                      "Ajouter une nouvelle catégorie:",
                      "Add New Category:",
                    )}
                  </div>
                  <div className="d-flex d-md-none p-0">
                    <h1 className="h5">
                      {out(
                        "Ajouter une nouvelle catégorie:",
                        "Add New Category:",
                      )}
                    </h1>
                  </div>
                </div>

                {(errors.frCategory || errors.enCategory) && (
                  <div className="w-100 d-none d-md-flex fs-7">&nbsp;</div>
                )}
              </div>
            </div>

            {language === "en" ? (
              <>
                {en}
                {fr}
              </>
            ) : (
              <>
                {fr}
                {en}
              </>
            )}
            <div className="flex-grow-2 p-md-2 text-md-start text-end">
              <Button
                type="submit"
                variant="primary"
                size="lg-float"
                className={styles.categorySaveButton}
              >
                {out("Sauvegarder", "Save")}
              </Button>
            </div>
          </div>
        </Card.Body>
      </Card>
    </form>
  );
};

export default CategoryInput;
