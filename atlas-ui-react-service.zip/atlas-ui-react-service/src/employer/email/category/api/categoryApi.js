import {
  deleteRestrictedApi,
  putRestrictedApi,
  postRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const createCategory = async (payload) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.messaging,
      `categories`,
      getToken(),
      payload,
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateCategory = async (id, payload) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.messaging,
      `categories`,
      getToken(),
      id,
      payload,
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteCategory = async (id) => {
  try {
    const response = await deleteRestrictedApi(
      serviceNames.messaging,
      `categories/${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
