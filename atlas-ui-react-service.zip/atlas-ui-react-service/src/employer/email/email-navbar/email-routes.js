export const emailRoutes = Object.freeze([
  {
    title: { en: "Compose Email", fr: "Écrire un courriel" },
    icon: "plus-circle",
    name: "compose",
    path: "compose",
  },
  {
    title: { en: "Inbox", fr: "Boîte de réception" },
    icon: "inbox",
    name: "inbox",
    path: "inbox",
  },
  {
    title: { en: "Sent", fr: "Envoyé" },
    icon: "paper-plane",
    name: "sent",
    path: "sent",
  },
  {
    title: { en: "Trash", fr: "Corbeille" },
    icon: "trash",
    name: "trash",
    path: "trash",
  },
  {
    title: { en: "Spam", fr: "Pourriels" },
    icon: "exclamation-circle",
    name: "spam",
    path: "spam",
  },
  {
    title: { en: "Email Templates", fr: "Modèles de messages" },
    icon: "file-text",
    name: "template",
    path: "template",
    children: [
      {
        title: { en: "My Templates", fr: "Mes modèles" },
        name: "template.default",
        path: "template",
        alternativePath: "template/:templateId/edit",
      },
      {
        title: { en: "Create Template", fr: "Créer un modèle" },
        name: "template.create",
        path: "template/create",
      },
    ],
  },
  {
    title: { en: "Signature", fr: "Signature" },
    icon: "pencil",
    name: "signature",
    path: "signature",
  },
  {
    title: { en: "Category", fr: "Catégorie" },
    icon: "list",
    name: "category",
    path: "category",
  },
  {
    title: { en: "Settings", fr: "Paramètres" },
    icon: "gear",
    name: "settings",
    path: "settings",
  },
]);
