import { useLayoutEffect } from "react";
import { NavLink, matchPath } from "react-router-dom";
import cx from "classnames";
import { emailRoutes } from "./email-routes";
import { useTranslation } from "global/utils/useTranslation";

export const EmailNavbar = () => {
  const { out } = useTranslation();

  useLayoutEffect(() => {
    window.addEventListener("resize", window.design.sidebar.handleResize);
    window.design.sidebar.initDropdowns();

    return () =>
      window.removeEventListener("resize", window.design.sidebar.handleResize);
  }, []);

  return (
    <nav
      className={`sidebar sidebar-small ${window.design.sidebar.getSidebarStateForScreenSize()}`}
      aria-labelledby="sidebar-title"
      ref={() => {
        window.design.sidebar.rcInit("email");
      }}
    >
      <div id="arc" />

      <div id="sidebar-title">{out("Courriel", "Email")}</div>

      <button
        className="sidebar-collapse-button"
        onClick={() => window.design.sidebar.toggleSidebar()}
      />

      <div className="sidebar-navigation-viewport">
        <ul className="sidebar-navigation">
          {emailRoutes.map((route) => {
            const url = `/emails/${route.path}`;

            return (
              <li
                key={route.name}
                className={cx("sidebar-navigation-item ng-init", {
                  "has-dropdown": !!route.children?.length,
                  "open-dropdown":
                    !!route.children?.length &&
                    matchPath(window.location.pathname, {
                      path: url,
                      exact: false,
                    }),
                })}
              >
                <NavLink
                  className="sidebar-nav-link"
                  to={url}
                  activeClassName={route.children?.length && "active"}
                  onClick={(e) =>
                    window.design.sidebar.openDropdown(e.currentTarget)
                  }
                >
                  <span className="icon">
                    <i className={`fa fa-${route.icon}`} aria-hidden="true" />
                  </span>
                  <span className="text">
                    {out(route.title.fr, route.title.en)}
                  </span>
                </NavLink>

                {route.children?.length && (
                  <ul
                    className={cx("sidebar-navigation-dropdown", {
                      open: matchPath(window.location.pathname, {
                        path: url,
                        exact: false,
                      }),
                    })}
                  >
                    {route.children.map((c, i) => {
                      return (
                        <li
                          className="sidebar-navigation-subitem"
                          key={`${route.name}:${c.name}`}
                        >
                          <NavLink
                            to={`/emails/${c.path}`}
                            activeClassName="active"
                            exact
                            className={cx("sidebar-nav-link", {
                              active:
                                c.alternativePath &&
                                matchPath(window.location.pathname, {
                                  path: `/emails/${c.alternativePath}`,
                                  exact: true,
                                  strict: true,
                                })?.isExact,
                            })}
                          >
                            {out(c.title.fr, c.title.en)}
                          </NavLink>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};
