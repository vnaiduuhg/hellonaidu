import { EmailFeaturesProvider } from "employer/sync/contexts/EmailFeaturesContext";
import { useEmailAccount } from "employer/sync/hooks/useEmailAccount";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";
import { useTranslation } from "global/utils/useTranslation";
import { FolderMappingPreferences } from "./components/FolderMappingPreferences";

export const EmailSettingsPage = () => {
  const { out } = useTranslation();
  const { account } = useEmailAccount("regular");

  return (
    <div className="h-100">
      {account ? (
        <EmailFeaturesProvider type={account.type} account={account}>
          <div
            style={{
              marginTop: "-1rem",
              marginLeft: "-1.5rem",
              marginRight: "-1.5rem",
            }}
          >
            <PageHeaderPanel
              title={out("Paramètres de boîte de courriel", "Email Settings")}
              iconClass="fa fa-gear"
            />

            <div className="p-3 pt-4">
              {/* settings page only needed for one provider. if each provider
                has their own distinct customisable settings, set this prop to
                true and list each customisation section as a prop in their
                respective providers.
               */}
              {account.hasCustomizableSettings ? (
                <FolderMappingPreferences account={account} />
              ) : (
                <AtlasAlert variant="info">
                  {out(
                    `${account.displayName} n'a pas de paramètres personnalisables.`,
                    `${account.displayName} has no customisable settings.`,
                  )}
                </AtlasAlert>
              )}
            </div>
          </div>
        </EmailFeaturesProvider>
      ) : (
        <NestedPageLoader wait />
      )}
    </div>
  );
};
