import {
  deleteRestrictedApi,
  getRestrictedApi,
  postRestrictedApi,
  putRestrictedApi,
} from "global/utils/apiUtils";
import { getToken } from "global/utils/getToken";
import { serviceNames } from "global/utils/serviceNames";

export const createFolderMappingPreference = async (provider, payload) => {
  try {
    const response = await postRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails/folders/mapping-preferences`,
      getToken(),
      payload,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getFolderMappingPreferences = async (provider) => {
  try {
    const response = await getRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails/folders/mapping-preferences`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateFolderMappingPreference = async (provider, id, payload) => {
  try {
    const response = await putRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails/folders/mapping-preferences`,
      getToken(),
      id,
      payload,
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteFolderMappingPreference = async (provider, id) => {
  try {
    const response = await deleteRestrictedApi(
      serviceNames.messaging,
      `${provider}/regular-emails/folders/mapping-preferences/${id}`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
