import { useCallback, useEffect, useMemo, useState } from "react";
import { Alert, Button, Card } from "react-bootstrap";
import { useMutation, useQuery, useQueryClient } from "react-query";
import {
  deleteFolderMappingPreference,
  getFolderMappingPreferences,
  updateFolderMappingPreference,
} from "../api/folderMappingPreferenceApi";
import { getFolders } from "../../inbox/apis/inboxApi";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasSelect } from "global/components/select/atlas-select";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { createFolderMappingPreference } from "../api/folderMappingPreferenceApi";
import { useDispatch } from "react-redux";
import statusMessagesSlice, {
  showMessage,
} from "global/store/statusMessagesSlice";
import styles from "../styles/EmailSettingsPage.module.scss";
import { useHistory } from "react-router-dom";
import { error401 } from "global/utils/_commonApiStatusMessages";

// folders that are allowed to have a custom path
const customizablePaths = {
  inbox: { en: "Inbox", fr: "Boîte de réception" },
  sent: { en: "Sent", fr: "Envoyé" },
  trash: { en: "Trash", fr: "Corbeille" },
  spam: { en: "Spam", fr: "Pourriels" },
};

export const FolderMappingPreferences = ({ account }) => {
  const [selectedFolders, setSelectedFolders] = useState({});
  const [showInfoPanel, setShowInfoPanel] = useState(true);

  const dispatch = useDispatch();
  const history = useHistory();
  const queryClient = useQueryClient();
  const { out } = useTranslation();

  const { data: preferences, isLoading: isPreferencesLoading } = useQuery(
    ["folder-mapping-preferences", { provider: account._routeName }],
    () => getFolderMappingPreferences(account._routeName),
    {
      onError: (error) => {
        if (error?.response?.status === 401) {
          dispatch(
            showMessage(
              "error",
              out(error401.title.fr, error401.title.en),
              out(error401.message.fr, error401.message.en),
              8000,
            ),
          );
          setTimeout(() => history.replace("/"), 1200);
        }
      },
    },
  );

  const { data: foldersResponse, isLoading: isFolderLoading } = useQuery(
    ["folders", { provider: account._routeName }],
    () => getFolders(account._routeName),
  );

  const customPreferencesHashmap = useMemo(
    () =>
      new Map(
        (foldersResponse?.folder_mappings ?? []).map((p) => {
          return [p.folder_name, p];
        }),
      ),
    [foldersResponse?.folder_mappings],
  );

  const optionsHashmap = useMemo(
    () => new Map((foldersResponse?.mailboxes ?? []).map((m) => [m.path, m])),
    [foldersResponse?.mailboxes],
  );

  const options = useMemo(
    () =>
      !!foldersResponse
        ? foldersResponse.mailboxes.map((mailbox) => ({
            value: mailbox,
            label: mailbox.name,
          }))
        : [],
    [foldersResponse],
  );

  // prevent infinite loader when leaving page while query is executing
  useEffect(() => {
    return () => {
      dispatch(statusMessagesSlice.actions.clearLoaders());
    };
  }, [dispatch]);

  useEffect(() => {
    if (preferences && foldersResponse && account) {
      // connect default: done on previous step

      // connect custom

      // set folder paths
      let initialValues = { ...selectedFolders };

      let tbUpdated = false;

      Object.keys(customizablePaths).forEach((folderKey) => {
        const customPath = customPreferencesHashmap.get(folderKey)?.folder_path;

        if (customPath) {
          const o = optionsHashmap.get(customPath);
          if (initialValues[folderKey] !== o) {
            initialValues[folderKey] = o;
            tbUpdated = true;
          }
        }
      });

      if (tbUpdated) {
        setSelectedFolders(initialValues);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    account,
    customPreferencesHashmap,
    foldersResponse,
    options,
    optionsHashmap,
    preferences,
  ]);

  const createPreference = useMutation({
    mutationFn: (payload) =>
      createFolderMappingPreference(account._routeName, payload),
  });
  const updatePreference = useMutation({
    mutationFn: ({ id, payload }) => {
      updateFolderMappingPreference(account._routeName, id, payload);
    },
  });
  const deletePreference = useMutation({
    mutationFn: ({ id }) =>
      deleteFolderMappingPreference(account._routeName, id),
  });

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();

      let changes = [];

      // check if any folder has been changed

      // if new field: post
      Object.keys(customizablePaths).forEach((folderKey) => {
        if (selectedFolders[folderKey]) {
          // something is found. check if the path is new, changed or the same
          // new: post
          // changed: put
          // the same: do nothing

          if (!customPreferencesHashmap.has(folderKey)) {
            changes.push({
              method: "post",
              payload: {
                folder_name: folderKey,
                folder_path: selectedFolders[folderKey].path,
              },
            });
          } else {
            // update
            if (
              customPreferencesHashmap.get(folderKey).folder_path !==
              selectedFolders[folderKey].path
            ) {
              changes.push({
                method: "put",
                id: customPreferencesHashmap.get(folderKey).id,
                payload: {
                  folder_name: folderKey,
                  folder_path: selectedFolders[folderKey].path,
                },
              });
            }
          }
        } else {
          // doesn't have a path. check if a path can be reliably determined.
          // if not, show validation error
          // if yes:
          //   if it didn't have one before: do nothing
          //   if there was a path before: delete

          if (customPreferencesHashmap.has(folderKey)) {
            // to be deleted

            changes.push({
              method: "delete",
              id: customPreferencesHashmap.get(folderKey).id,
            });
          }
        }
      });

      if (changes.length) {
        dispatch(
          showMessage(
            "loading",
            out("Chargement...", "Loading..."),
            out("Mise à jour des dossiers...", "Updating folders..."),
            200000,
          ),
        );
      }

      let changesMade = false;
      for (const change of changes) {
        if (change.method === "post") {
          changesMade = true;
          await createPreference.mutateAsync(change.payload);
        } else if (change.method === "put") {
          changesMade = true;
          await updatePreference.mutateAsync({
            id: change.id,
            payload: change.payload,
          });
        } else if (change.method === "delete") {
          changesMade = true;
          await deletePreference.mutateAsync({ id: change.id });
        }
      }

      if (changesMade) {
        queryClient.invalidateQueries("folders").then(() => {
          Promise.all([
            queryClient.invalidateQueries("folder-mapping-preferences", {
              exact: false,
            }),
            queryClient.removeQueries("messages", { exact: false }),
          ]).then(() => {
            // show message that changes have been made
            dispatch(statusMessagesSlice.actions.clearLoaders());
          });
        });
      }
    },
    [
      selectedFolders,
      customPreferencesHashmap,
      dispatch,
      out,
      createPreference,
      updatePreference,
      deletePreference,
      queryClient,
    ],
  );

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <Card.Header className="d-flex" id={styles.customPaths}>
          <Card.Title>
            {out("Dossiers personnalisés :", "Custom folders:")}
          </Card.Title>
        </Card.Header>

        {isPreferencesLoading || isFolderLoading ? (
          <div id={styles.loaderContainer}>
            <ComponentLoader wait />
          </div>
        ) : (
          <Card.Body>
            <Alert
              variant="info"
              hidden={!showInfoPanel}
              onClose={() => setShowInfoPanel(false)}
              dismissible
            >
              {out(
                `Les dossiers de boîtes de courriel sur Atlas peuvent ne pas correspondre aux noms de votre fournisseur de messagerie. Si c'est le cas, vous pouvez utiliser les options ci-dessous pour les relier manuellement.`,
                `The mailbox folders on Atlas may not match the names from your Email Provider. If that's the case, you can use the settings below to link them manually.`,
              )}
            </Alert>
            {Object.entries(customizablePaths).map(([key, customPath]) => {
              const defaultPath = account.getDefaultFolderPath(
                key,
                foldersResponse.mailboxes,
              );

              const placeholder = defaultPath ? (
                <span>
                  {defaultPath}
                  <span className="ms-2 fs-small text-muted">
                    {out("(Défaut)", "(Default)")}
                  </span>
                </span>
              ) : (
                <span className="text-warning">
                  {out(
                    "Veuillez sélectionner un dossier",
                    "Please select a folder",
                  )}
                </span>
              );

              return (
                <div className="py-2 pe-3" key={key}>
                  <div>{out(customPath.fr, customPath.en)}:</div>

                  <div>
                    <AtlasSelect
                      name={key}
                      placeholder={placeholder}
                      isClearable={true}
                      noOptionsMessage={() =>
                        out("Aucun dossier", "No folders")
                      }
                      options={options}
                      className=""
                      multiselect={false}
                      isSearchable={true}
                      onChange={(newFolder) => {
                        if (newFolder?.value) {
                          setSelectedFolders({
                            ...selectedFolders,
                            [key]: newFolder.value,
                          });
                        } else {
                          const newSelectedFolders = {
                            ...selectedFolders,
                          };
                          delete newSelectedFolders[key];
                          setSelectedFolders(newSelectedFolders);
                        }
                      }}
                      value={
                        selectedFolders[key]
                          ? {
                              label: selectedFolders[key].name,
                              value: selectedFolders[key],
                            }
                          : null
                      }
                    />
                  </div>
                </div>
              );
            })}
          </Card.Body>
        )}
        <div className="d-flex justify-content-end pb-3 px-3">
          <Button type="submit" variant="primary" className="me-3">
            {out("Sauvegarder", "Save")}
          </Button>
        </div>
      </Card>
    </form>
  );
};
