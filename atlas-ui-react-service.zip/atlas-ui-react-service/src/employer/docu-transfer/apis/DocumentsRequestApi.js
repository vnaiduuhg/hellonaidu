import {
  postRestrictedApi,
  putRestrictedApi,
  patchRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const createDocumentsRequestApi = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateDocumentsRequestApi = async (
  documentRequestTemplateId,
  data,
) => {
  try {
    const reponse = await putRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates`,
      getToken(),
      documentRequestTemplateId,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const publishDocumentRequestTemplateApi = async (
  documentRequestTemplateId,
) => {
  try {
    const reponse = await patchRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates`,
      getToken(),
      documentRequestTemplateId,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteDocumentRequestTemplate = async (id) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates/${id}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
