import React from "react";

const AccessCheckboxes = ({ access }) => (
  <div className="d-flex justify-content-end me-3">
    <div className="form-check d-flex align-items-center me-3">
      <label className="form-check-label">
        <input
          className="form-check-input form-check-input-md"
          name="readOnly"
          type="checkbox"
          checked={access ? +access.pivot?.has_write_access === 0 : false}
          disabled={true}
        />
      </label>
    </div>
    <div className="form-check d-flex align-items-center ms-3">
      <label className="form-check-label">
        <input
          className="form-check-input form-check-input-md"
          name="readAndWrite"
          type="checkbox"
          checked={access ? +access.pivot?.has_write_access === 1 : false}
          disabled={true}
        />
      </label>
    </div>
  </div>
);

export default AccessCheckboxes;
