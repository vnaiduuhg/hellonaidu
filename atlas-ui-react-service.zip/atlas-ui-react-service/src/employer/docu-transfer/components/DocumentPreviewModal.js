import { memo, useCallback, useMemo, useState } from "react";
import { getSendRequestFileUrl } from "global/apis/ToolkitApi";
import { DocumentViewer } from "global/components/DocumentViewer/DocumentViewer";
import { docuTransferGetDocumentMsgHandler } from "../utils/docutransfer-viewer-msg-handler";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import { useTranslation } from "global/utils/useTranslation";
import { Alert, Modal } from "react-bootstrap";
import { useQuery } from "react-query";
import { FaExclamationTriangle } from "react-icons/fa";

export const DocumentPreviewModal = memo(({ show, hide, document }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(false);
  const { out } = useTranslation();

  const onLoad = useCallback(() => {
    setIsLoading(false);
  }, []);

  const onError = useCallback((error) => {
    setIsLoading(false);
    setError(error);
  }, []);

  const errorMessage = error
    ? docuTransferGetDocumentMsgHandler(error?.status ?? 500)
    : null;

  // get url for the actual file
  const { data: documentUrl } = useQuery(
    ["document-request-template-file", { id: document.id }],
    () =>
      getSendRequestFileUrl(document.id).then(
        (res) => res.url,
        (error) => {
          throw error.response ?? error;
        },
      ),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError,
    },
  );

  const title = useMemo(
    () =>
      // show the document name in current UI language, fallback to alternate language
      // if neither exists, show the file name instead
      document.translations?.fr?.title || document.translations?.en?.title
        ? out(
            document.translations?.fr?.title ??
              `[EN] ${document.translations.en.title}`,
            document.translations?.en?.title ??
              `[FR] ${document.translations.fr.title}`,
          )
        : document.file_name,
    [document, out],
  );

  return (
    <Modal centered show={show} onHide={hide} size="lg">
      <Modal.Header closeButton>
        <Modal.Title className="w-100 ellipsis">{title}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {!!error && (
          <Alert variant="warning">
            <div className="d-flex">
              <div className="fs-5 mt-3 me-3">
                <FaExclamationTriangle />
              </div>
              <div>
                <Alert.Heading className="mb-1">
                  {errorMessage.title}
                </Alert.Heading>
                {errorMessage.text}
              </div>
            </div>
          </Alert>
        )}
        {(!documentUrl || isLoading) && !error && (
          <div className="p-3">
            <ComponentLoader />
          </div>
        )}

        {!!documentUrl && (
          <DocumentViewer
            path={documentUrl}
            fileName={document.file_name}
            onLoad={onLoad}
            onError={onError}
          />
        )}
      </Modal.Body>
    </Modal>
  );
});
