import React, { useEffect } from "react";
import { Controller } from "react-hook-form";
import { Col, Row } from "react-bootstrap";
import {
  langLabels,
  informationsHeader,
} from "../../assets/translations/translations";
import { AtlasAlert } from "global/components/atlas-alert";
import { AtlasSelect } from "global/components/select/atlas-select";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const Informations = ({
  templateData,
  templateIsDraft,
  templateIsPublished,
  showIsDraftWarning,
  control,
  setValue,
  watch,
  languages,
  errors,
}) => {
  const { out } = useTranslation();
  const templateLanguages = watch("informations.languages", []);
  const descriptionFr = watch(`informations.translations.fr.description`);
  const descriptionEn = watch(`informations.translations.en.description`);

  // resets languages values when language is unselected
  useEffect(() => {
    languages.forEach((l) => {
      if (
        templateLanguages?.length > 0 &&
        !templateLanguages.find((t) => t.value === l.value)
      ) {
        setValue(`informations.translations[${l.value}].title`, "");
        setValue(`informations.translations[${l.value}].description`, "");
      }
    });

    return () => {};
  }, [templateLanguages]);

  return (
    <div className="p-3 pt-5">
      <Row className="my-3">
        <Col xs={12}>
          <div className="d-flex align-self-center mb-3">
            <h5 className="mb-0">
              {out(informationsHeader.title.fr, informationsHeader.title.en)}
            </h5>
            {templateData && templateIsDraft > 0 && (
              <div>
                <span
                  className={cx(`ms-2 ${styles.draftLabelSm}`, {
                    [styles.blueLabel]: !templateIsPublished,
                    [styles.warningLabel]:
                      templateIsPublished && showIsDraftWarning,
                  })}
                >
                  {out("Brouillon", "Draft")}
                </span>
              </div>
            )}
          </div>
        </Col>
      </Row>
      <Row className="my-3">
        <Col sm={6} xxl={3}>
          {!languages || languages.length < 1 ? (
            <AtlasAlert>
              {out("Aucune langue disponible", "No language available")}
            </AtlasAlert>
          ) : (
            <>
              <label>{out("Liste des langues", "Language list")}</label>
              <Controller
                name="informations.languages"
                control={control}
                rules={{
                  required: {
                    value: true,
                    message: out(
                      "Veuillez sélectionner au moins une langue",
                      "Please select at least one language",
                    ),
                  },
                }}
                render={({ field: { ref, ...rest } }) => (
                  <AtlasSelect
                    {...rest}
                    isMulti
                    isClearable
                    closeMenuOnSelect={true}
                    placeholder={out(
                      "Sélectionnez une ou plusieurs langues",
                      "Select one or many languages",
                    )}
                    options={
                      languages.length > 0
                        ? languages.map((l) => ({
                            label: out(l.translations.fr, l.translations.en),
                            value: l.value,
                          }))
                        : []
                    }
                  />
                )}
              />
              {errors?.informations?.languages && (
                <div className="form-text text-warning">
                  {errors.informations.languages.message}
                </div>
              )}
            </>
          )}
        </Col>
      </Row>
      <Row className="my-3">
        {templateLanguages?.find((l) => l.value === "fr") && (
          <Col lg={6} className="pb-3">
            {
              <>
                <div
                  className={cx({
                    "mb-1": !errors?.informations?.translations?.fr?.title,
                    "mb-2": errors?.informations?.translations?.fr?.title,
                  })}
                >
                  <FormHookFloatingLabel
                    name="informations.translations.fr.title"
                    control={control}
                    type="text"
                    title={out(langLabels.titleFr.fr, langLabels.titleFr.en)}
                    mandatory={true}
                    rules={{
                      required: {
                        value: true,
                        message: out(
                          "Veuillez entrer un titre français",
                          "Please enter a french title",
                        ),
                      },
                      maxLength: {
                        value: 255,
                        message: out(
                          "Le titre doit contenir un maximum de 255 caractères",
                          "The title must contain a maximum of 255 characters",
                        ),
                      },
                    }}
                    error={errors?.informations?.translations?.fr?.title}
                    showError={errors?.informations?.translations?.fr?.title}
                  />
                </div>
                <div
                  className={cx({
                    "mb-1":
                      !errors?.informations?.translations?.fr?.description,
                    "mb-2": errors?.informations?.translations?.fr?.description,
                  })}
                >
                  <FormHookFloatingLabel
                    type="textarea"
                    name="informations.translations.fr.description"
                    control={control}
                    mandatory={true}
                    title={out(
                      langLabels.descriptionFr.fr,
                      langLabels.descriptionFr.en,
                    )}
                    style={{ height: "7.5rem" }}
                    rules={{
                      required: {
                        value: true,
                        message: out(
                          "Veuillez entrer une description française",
                          "Please enter a french description",
                        ),
                      },
                      maxLength: {
                        value: 255,
                        message: out(
                          "La description doit contenir un maximum de 255 caractères",
                          "The description must contain a maximum of 255 characters",
                        ),
                      },
                    }}
                    error={errors?.informations?.translations?.fr?.description}
                    showError={false}
                  />
                  <div className="d-flex justify-content-between">
                    <div>
                      {errors?.informations?.translations?.fr?.description && (
                        <div className="form-text text-warning">
                          {
                            errors.informations.translations.fr.description
                              .message
                          }
                        </div>
                      )}
                    </div>
                    <span className="d-flex align-items-center text-form text-muted fs-small">
                      {descriptionFr && descriptionFr.length
                        ? descriptionFr.length
                        : 0}
                      /255
                    </span>
                  </div>
                </div>
              </>
            }
          </Col>
        )}
        {templateLanguages?.find((l) => l.value === "en") && (
          <Col lg={6} className="pb-3">
            {
              <>
                <div
                  className={cx({
                    "mb-1": !errors?.informations?.translations?.en?.title,
                    "mb-2": errors?.informations?.translations?.en?.title,
                  })}
                >
                  <FormHookFloatingLabel
                    name="informations.translations.en.title"
                    control={control}
                    type="text"
                    mandatory={true}
                    title={out(langLabels.titleEn.en, langLabels.titleEn.en)}
                    rules={{
                      required: {
                        value: true,
                        message: out(
                          "Veuillez entrer un titre anglais",
                          "Please enter an english title",
                        ),
                      },
                      maxLength: {
                        value: 255,
                        message: out(
                          "Le titre doit contenir un maximum de 255 caractères",
                          "The title must contain a maximum of 255 characters",
                        ),
                      },
                    }}
                    error={errors?.informations?.translations?.en?.title}
                    showError={errors?.informations?.translations?.en?.title}
                  />
                </div>
                <div
                  className={cx({
                    "mb-1":
                      !errors?.informations?.translations?.en?.description,
                    "mb-2": errors?.informations?.translations?.en?.description,
                  })}
                >
                  <FormHookFloatingLabel
                    type="textarea"
                    name="informations.translations.en.description"
                    control={control}
                    mandatory={true}
                    title={out(
                      langLabels.descriptionEn.fr,
                      langLabels.descriptionEn.en,
                    )}
                    style={{ height: "7.5rem" }}
                    rules={{
                      required: {
                        value: true,
                        message: out(
                          "Veuillez entrer une description anglaise",
                          "Please enter an english description",
                        ),
                      },
                      maxLength: {
                        value: 255,
                        message: out(
                          "La description doit contenir un maximum de 255 caractères",
                          "The description must contain a maximum of 255 characters",
                        ),
                      },
                    }}
                    error={errors?.informations?.translations?.en?.description}
                    showError={false}
                  />

                  <div className="d-flex justify-content-between">
                    <div>
                      {errors?.informations?.translations?.en?.description && (
                        <div className="form-text text-warning">
                          {
                            errors.informations.translations.en.description
                              .message
                          }
                        </div>
                      )}
                    </div>
                    <span className="d-flex align-items-center text-form text-muted fs-small">
                      {descriptionEn && descriptionEn.length
                        ? descriptionEn.length
                        : 0}
                      /255
                    </span>
                  </div>
                </div>
              </>
            }
          </Col>
        )}
      </Row>
    </div>
  );
};

export default Informations;
