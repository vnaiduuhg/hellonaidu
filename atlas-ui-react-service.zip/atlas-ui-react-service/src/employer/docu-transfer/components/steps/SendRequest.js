import React, { useState, useEffect } from "react";
import { Col, Row, Button } from "react-bootstrap";
import { sendRequestHeader } from "../../assets/translations/translations";
import DocumentSettings from "./steps-components/DocumentSettings";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../../styles/DocuTransfer.module.scss";
import { FaPlus } from "react-icons/fa";
import cx from "classnames";

const SendRequest = ({
  templateIsDraft,
  templateIsPublished,
  showIsDraftWarning,
  fields,
  append,
  remove,
  control,
  watch,
  trigger,
  errors,
  setValue,
  getValues,
  submitSendRequest,
  processingData,
  setProcessingData,
  documentTypes,
  documentTypesIsError,
  docuRequestTemplateId,
  documentIdsMissing,
  setDocumentIdsMissing,
}) => {
  const { out } = useTranslation();
  const [chosenLanguages, setChosenLanguages] = useState([]);

  useEffect(() => {
    const languages = getValues("informations.languages");
    const languagesArray = [];
    languages.forEach((l) => {
      languagesArray.push(l.value);
    });
    setChosenLanguages(languagesArray);
    return () => {};
  }, []);

  const addNewDocumentField = () => {
    append({
      requestType: "",
      uploadType: "",
      documentType: "",
      documentUrl: "",
      documentFile: null,
      documentFileName: "",
      documentId: null,
      dmFileId: null,
      translations: {
        en: {
          documentTitle: "",
          documentText: "",
        },
        fr: {
          documentTitle: "",
          documentText: "",
        },
      },
    });
  };

  const removeDocumentField = (index) => {
    remove(index);
    submitSendRequest(true);
  };

  return (
    <div className="p-3 pt-5">
      <Row className="mb-3">
        <Col sm={12} className="mb-3">
          <div className="d-flex flex-row flex-wrap justify-content-between">
            <div className="d-flex align-self-center mb-0 mt-3">
              <h5 className="d-flex align-items-center mb-0">
                {out(sendRequestHeader.title.fr, sendRequestHeader.title.en)}
              </h5>
              {templateIsDraft > 0 && (
                <div>
                  <span
                    className={cx(`ms-2 ${styles.draftLabelSm}`, {
                      [styles.blueLabel]: !templateIsPublished,
                      [styles.warningLabel]:
                        templateIsPublished && showIsDraftWarning,
                    })}
                  >
                    {out("Brouillon", "Draft")}
                  </span>
                </div>
              )}
            </div>
            <div className="d-flex flex-fill align-items-center justify-content-end mt-3 ms-3">
              <label className="fs-5 me-2">
                {out("Ajouter une requête", "Add a request")}
              </label>
              <Button
                className="btn btn-secondary"
                disabled={processingData}
                onClick={() => addNewDocumentField()}
              >
                <FaPlus className="" />
              </Button>
            </div>
          </div>
        </Col>
      </Row>
      {fields.map((field, index) => {
        return (
          <DocumentSettings
            key={field.id}
            field={field}
            index={index}
            control={control}
            watch={watch}
            trigger={trigger}
            errors={errors}
            setValue={setValue}
            chosenLanguages={chosenLanguages}
            submitSendRequest={submitSendRequest}
            processingData={processingData}
            setProcessingData={setProcessingData}
            documentTypes={documentTypes}
            documentTypesIsError={documentTypesIsError}
            docuRequestTemplateId={docuRequestTemplateId}
            removeDocumentField={removeDocumentField}
            documentIdsMissing={documentIdsMissing}
            setDocumentIdsMissing={setDocumentIdsMissing}
          />
        );
      })}
    </div>
  );
};

export default SendRequest;
