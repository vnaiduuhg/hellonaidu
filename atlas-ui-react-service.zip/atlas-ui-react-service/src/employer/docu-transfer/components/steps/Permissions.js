import React, { useState, useEffect } from "react";
import { Col, Row, Table } from "react-bootstrap";
import UsersRolesPermissionsSettings from "./steps-components/UsersRolesPermissionsSettings";
import { permissionsHeader } from "../../assets/translations/translations";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasAlert } from "global/components/atlas-alert";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import Tooltip from "@material-ui/core/Tooltip";
import { AiFillInfoCircle } from "react-icons/ai";
import styles from "../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const Permissions = ({
  templateIsDraft,
  templateIsPublished,
  showIsDraftWarning,
  rolesFields,
  rolesAppend,
  usersFields,
  usersAppend,
  control,
  watch,
  setValue,
  getValues,
  reset,
  settingsMode,
  roles,
  rolesIsError,
  selectedRolesList,
  selectedUsersList,
}) => {
  const { out } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [documentsList, setDocumentsList] = useState(true);

  useEffect(() => {
    const documents = getValues("documentsList");
    setDocumentsList(documents);

    if (
      settingsMode === "create" &&
      roles?.length > 0 &&
      usersFields.length < 1 &&
      rolesFields.length < 1
    ) {
      setLoading(true);
      selectedRolesList.forEach((r) => {
        appendRoles(r);
      });
      selectedUsersList.forEach((u) => {
        appendUsers(u);
      });
      reset({}, { keepValues: true });
      setLoading(false);
    }

    return () => {};
  }, []);

  const appendRoles = (role) => {
    rolesAppend({
      data: role,
      documentsSelected: [],
      roleId: role.id,
      readOnly: false,
      readAndWrite: false,
    });
  };
  const appendUsers = (user) => {
    usersAppend({
      data: user,
      documentsSelected: [],
      userId: user.user_id,
      roleId: user.role_id,
      readOnly: false,
      readAndWrite: false,
    });
  };

  return (
    <div className="p-3 pt-5">
      <Row className="my-3">
        <Col xs={12}>
          <div className="d-flex alin-self-center mb-3">
            <h5 className="mb-0">
              {out(permissionsHeader.title.fr, permissionsHeader.title.en)}
            </h5>
            {templateIsDraft > 0 && (
              <div>
                <span
                  className={cx(`ms-2 ${styles.draftLabelSm}`, {
                    [styles.blueLabel]: !templateIsPublished,
                    [styles.warningLabel]:
                      templateIsPublished && showIsDraftWarning,
                  })}
                >
                  {out("Brouillon", "Draft")}
                </span>
              </div>
            )}
          </div>
        </Col>
      </Row>
      {loading ? (
        <div className={`bg-white ${styles.componentLoaderPadding}`}>
          <NestedPageLoader
            message={out(
              "Chargement des permissions...",
              "Loading permissions...",
            )}
          />
        </div>
      ) : (
        <>
          {!rolesIsError ? (
            <>
              <Row>
                <Col>
                  <Table striped hover>
                    <thead>
                      <tr className="text-secondary-100">
                        <th>
                          {out("Rôles", "Roles")}&nbsp;
                          <Tooltip
                            placement="top"
                            title={
                              <h5 className="my-0 p-1 pt-2 fs-6 text-center">
                                {out(
                                  "Autorisations attribuées par rôles",
                                  "Permissions assigned by roles",
                                )}
                              </h5>
                            }
                          >
                            <span>
                              <AiFillInfoCircle className="text-info fs-3" />
                            </span>
                          </Tooltip>
                        </th>
                        <th>
                          {out("Accès aux documents", "Documents access")}
                        </th>
                        <th>
                          <div className="d-flex justify-content-end">
                            <div className={`text-center ${styles.wContent}`}>
                              {out("Accès à la liste", "List access")}
                              <br />
                              <span className="fs-7">
                                {out(
                                  "Lecture / Écriture",
                                  "Read only / Update",
                                )}
                              </span>
                            </div>
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {rolesFields.map((field, index) => (
                        <UsersRolesPermissionsSettings
                          key={field.id}
                          index={index}
                          name="permissionsRoles"
                          control={control}
                          watch={watch}
                          setValue={setValue}
                          role={field.data}
                          documentsList={documentsList}
                        />
                      ))}
                    </tbody>
                  </Table>
                </Col>
              </Row>
              <Row>
                <Col>
                  <Table striped hover>
                    <thead>
                      <tr className="text-secondary-100">
                        <th>
                          {out("Utilisateurs", "Users")}&nbsp;
                          <Tooltip
                            placement="top"
                            title={
                              <h5 className="my-0 p-1 pt-2 fs-6 text-center">
                                {out(
                                  "Les autorisations pour des utilisateurs spécifiques ont priorité sur les autorisations par rôles",
                                  "Permissions for specific users take precedence over permissions by roles",
                                )}
                              </h5>
                            }
                          >
                            <span>
                              <AiFillInfoCircle className="text-info fs-3" />
                            </span>
                          </Tooltip>
                        </th>
                        <th>{out("Rôle", "Role")}</th>
                        <th>
                          {out("Accès aux documents", "Documents access")}
                        </th>
                        <th>
                          <div className="d-flex justify-content-end">
                            <div className={`text-center ${styles.wContent}`}>
                              {out("Accès à la liste", "List access")}
                              <br />
                              <span className="fs-7">
                                {out(
                                  "Lecture / Écriture",
                                  "Read only / Update",
                                )}
                              </span>
                            </div>
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {usersFields.map((field, index) => (
                        <UsersRolesPermissionsSettings
                          key={field.id}
                          index={index}
                          name="permissionsUsers"
                          control={control}
                          watch={watch}
                          setValue={setValue}
                          role={roles.find((r) => +r.id === +field.roleId)}
                          documentsList={documentsList}
                          user={field.data}
                        />
                      ))}
                    </tbody>
                  </Table>
                </Col>
              </Row>
            </>
          ) : (
            <div>
              <AtlasAlert variant="danger">
                {out(
                  "Une erreur s'est produite et nous ne pouvons afficher les permissions",
                  "An error has occured and we cannot display permissions",
                )}
              </AtlasAlert>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Permissions;
