import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { messagesHeader } from "../../assets/translations/translations";
import MessageSettings from "./steps-components/MessageSettings";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasAlert } from "global/components/atlas-alert";
import { Col, Row } from "react-bootstrap";
import { FaExclamationCircle } from "react-icons/fa";
import styles from "../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const Messages = ({
  templateIsDraft,
  templateIsPublished,
  showIsDraftWarning,
  control,
  watch,
  errors,
  setValue,
  emailTemplates,
  emailTemplateIsError,
  smsTemplates,
  smsTemplateIsError,
  templateCategories,
  templateCategorieIsError,
  notification,
  notificationIsError,
}) => {
  const { out } = useTranslation();
  const [emailIsEnabled, setEmailIsEnabled] = useState(-1);
  const [defaultEmailTemplate, setDefaultEmailTemplate] = useState(null);

  useEffect(() => {
    if (!notificationIsError && notification.length > 0) {
      if (notification[0].hasOwnProperty("is_email_enabled")) {
        setEmailIsEnabled(notification[0].is_email_enabled);
      }
      if (notification[0].hasOwnProperty("email_template")) {
        setDefaultEmailTemplate(notification[0].email_template);
      }
    }
  }, []);

  return (
    <div className="p-3 pt-5">
      <Row className="my-3">
        <Col xs={12}>
          <div className="d-flex align-self-center mb-3">
            <h5 className="mb-0">
              {out(messagesHeader.title.fr, messagesHeader.title.en)}
            </h5>
            {templateIsDraft > 0 && (
              <div>
                <span
                  className={cx(`ms-2 ${styles.draftLabelSm}`, {
                    [styles.blueLabel]: !templateIsPublished,
                    [styles.warningLabel]:
                      templateIsPublished && showIsDraftWarning,
                  })}
                >
                  {out("Brouillon", "Draft")}
                </span>
              </div>
            )}
          </div>
          <div>
            <AtlasAlert
              variant="info"
              icon={<FaExclamationCircle />}
              className="d-flex justify-content-start"
            >
              <p className="ms-3 mb-0">
                {out(
                  "Le message automatisé par défaut pour l'envoi de demande de documents se trouve sous l'étiquette",
                  "The default automated message for sending document requests is found under the",
                )}
                &nbsp;
                <span className="fw-bold">
                  {out(
                    "DocuSecur - Demande de documents",
                    "DocuSecur - Document Request",
                  )}
                </span>
                &nbsp;
                {out(".", "label.")}&nbsp;
                <Link to="/automated-messages">
                  <span>
                    {out(
                      "Consulter les messages automatisés.",
                      "Consult automated messages.",
                    )}
                  </span>
                </Link>
              </p>
              <p className="ms-3 mb-0">
                {out(
                  "Vous pouvez également personnaliser le modèle de courriel pour une demande de documents. Le modèle de courriel choisi ne s'appliquera qu'à cette demande de documents.",
                  "You can also customize the email template for a document request. The email template chosen will only apply to this documents request.",
                )}
              </p>
            </AtlasAlert>
          </div>
        </Col>
      </Row>
      <Row>
        <MessageSettings
          control={control}
          watch={watch}
          errors={errors}
          setValue={setValue}
          automatedMsgLabel={out("Message automatisé", "Automated message")} // add courriel|email when sms will be active
          previewTemplateLabel={out(
            "Aperçu du modèle de courriel personnalisé",
            "Preview customized email template",
          )}
          previewDefaultTemplateLabel={out(
            "Aperçu du modèle de courriel par défaut",
            "Preview default email template",
          )}
          templateName="messages.emailTemplate"
          templateList={emailTemplates}
          templateListError={emailTemplateIsError}
          defaultTemplate={defaultEmailTemplate}
          templateIsEnabled={emailIsEnabled}
          selectDataPlaceholder={out(
            "Sélectionnez un modèle de courriel",
            "Select an email template",
          )}
          alertText={out(
            "Aucun modèle de courriel disponible",
            "No email template available",
          )}
          alertErrorText={out(
            "La liste de modèles de courriel n'a pu être récupérée",
            "Email templates list could not be retrieved",
          )}
          categorList={templateCategories}
          categorListError={templateCategorieIsError}
          selectCategoryPlaceholder={out(
            "Sélectionnez une catégorie de modèles de courriel",
            "Select a category of email templates",
          )}
          alertCategoryText={out(
            "Aucune categorie de modèle de courriel disponible",
            "No email template category available",
          )}
          alertCategoryErrorText={out(
            "La liste de categories de modèles de courriel n'a pu être récupérée",
            "Email template categories list could not be retrieved",
          )}
        />
        {/* @hide until sms feature implementation
        <MessageSettings
          control={control}
          watch={watch}
          errors={errors}
          setValue={setValue}
          automatedMsgLabel={out(
            "Message sms automatisé",
            "Automated sms message",
          )}
          previewTemplateLabel={out(
            "Aperçu du modèle sms personnalisé",
            "Preview customized sms template",
          )}
          previewDefaultTemplateLabel={out(
            "Aperçu du modèle sms par défaut",
            "Preview default sms template",
          )}
          templateName="messages.smsTemplate"
          templateList={smsTemplates}
          templateListError={smsTemplateIsError}
          defaultTemplate={defaultSmsTemplate}
          templateIsEnabled={smsIsEnabled}
          selectDataPlaceholder={out(
            "Sélectionnez un modèle de sms",
            "Select a sms template",
          )}
          alertText={out(
            "Aucun modèle de sms disponible",
            "No sms template available",
          )}
          alertErrorText={out(
            "La liste de modèles de sms n'a pu être récupérée",
            "Sms templates list could not be retrieved",
          )}
          categorList={templateCategories}
          categorListError={templateCategorieIsError}
          selectCategoryPlaceholder={out(
            "Sélectionnez une catégorie de modèles sms",
            "Select a category of sms templates",
          )}
          alertCategoryText={out(
            "Aucune categorie de modèles sms disponible",
            "No sms template category available",
          )}
          alertCategoryErrorText={out(
            "La liste de categories de modèles de courriel n'a pu être récupérée",
            "Email template categories list could not be retrieved",
          )}
        /> */}
      </Row>
    </div>
  );
};

export default Messages;
