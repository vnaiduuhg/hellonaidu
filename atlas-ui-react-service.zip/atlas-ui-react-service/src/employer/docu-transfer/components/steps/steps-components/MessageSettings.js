import React, { useEffect, useState } from "react";
import { Controller } from "react-hook-form";
import { Col } from "react-bootstrap";
import DocumentViewModal from "../../TemplateViewModal";
import { AtlasAlert } from "global/components/atlas-alert";
import { AtlasSelect } from "global/components/select/atlas-select";
import { useTranslation } from "global/utils/useTranslation";
import { FaFilter } from "react-icons/fa";
import { FiFilter } from "react-icons/fi";
import { AiFillEye, AiOutlineEye, AiOutlineCheck } from "react-icons/ai";
import styles from "../../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const MessageSettings = ({
  control,
  watch,
  errors,
  setValue,
  automatedMsgLabel,
  previewTemplateLabel,
  previewDefaultTemplateLabel,
  templateName,
  templateList,
  templateListError,
  defaultTemplate,
  templateIsEnabled,
  selectDataPlaceholder,
  alertText,
  alertErrorText,
  categorList,
  categorListError,
  selectCategoryPlaceholder,
  alertCategoryText,
  alertCategoryErrorText,
}) => {
  const { out } = useTranslation();
  const templateValue = watch(templateName);
  const categoryValues = watch("messages.categoryIds", []);
  const [openFilter, setOpenFilter] = useState(false);
  const [viewTemplate, setViewTemplate] = useState(false);
  const [viewDefaultTemplate, setViewDefaultTemplate] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState(null);
  const [currentTemplateList, setCurrentTemplateList] = useState(templateList);

  useEffect(() => {
    if (categoryValues.length > 0) {
      const newList = categoryValues.map(({ value }) => value);
      const newTemplateList = templateList.filter((t) => {
        if (t.categories.length > 0) {
          return t.categories.find((c) => {
            return newList.includes(c.id);
          });
        }
      });
      if (
        !newTemplateList.find(
          (template) => +template.id === +templateValue?.value,
        )
      ) {
        setValue(templateName, []);
      }
      setCurrentTemplateList(newTemplateList);
      setOpenFilter(true);
    } else {
      setCurrentTemplateList(templateList);
    }
  }, [categoryValues]);

  const categorySelect = !categorListError ? (
    !categorList || categorList.length < 1 ? (
      <div className="mt-2">
        <AtlasAlert>{alertCategoryText}</AtlasAlert>
      </div>
    ) : (
      <div className="mt-2">
        <Controller
          name="messages.categoryIds"
          control={control}
          isMandatory={false}
          render={({ field: { ref, ...rest } }) => (
            <AtlasSelect
              {...rest}
              isMulti
              isClearable
              closeMenuOnSelect={true}
              placeholder={selectCategoryPlaceholder}
              options={categorList.map((c) => {
                return {
                  label: out(c.translations[1].name, c.translations[0].name),
                  value: c.id,
                };
              })}
            />
          )}
        />
      </div>
    )
  ) : (
    <div className="mt-2">
      <AtlasAlert variant="danger">{alertCategoryErrorText}</AtlasAlert>
    </div>
  );

  return (
    <>
      <Col lg={6} className="mb-3">
        <div className="mb-3">
          <label>{automatedMsgLabel}</label>&nbsp;
          {templateIsEnabled > 0 && (
            <span className="ms-2">
              <AiOutlineCheck className="text-success fs-3" />
              <label>{out("activé", "enabled")}</label>
            </span>
          )}
          {templateIsEnabled === 0 && (
            <span className="text-muted fst-italic ms-2">
              <label>{out("désactivé", "disabled")}</label>
            </span>
          )}
          {templateIsEnabled < 0 && (
            <span className="text-warning fst-italic ms-2">
              <label>
                {out("statut non disponible", "status not available")}
              </label>
            </span>
          )}
        </div>
        <div
          className={cx(`d-flex align-items-center ${styles.meMedium}`, {
            "mt-1": !templateList || templateList.length < 1,
          })}
        >
          <label>
            {templateValue ? previewTemplateLabel : previewDefaultTemplateLabel}
          </label>
          {templateList?.length > 0 && !templateListError && (
            <button
              className="btn btn-sm text-secondary"
              /* @std by
              className={cx(`btn btn-sm text-secondary`, {
                [styles.notAllowed]: !defaultTemplate && !templateValue,
              })} */
              type="button"
              // disabled={!defaultTemplate && !templateValue} - @std by
              onClick={() => {
                const templateSelected = currentTemplateList.find(
                  (t) => +t.id === +templateValue?.value,
                );
                setCurrentTemplate(templateSelected ?? null);
                if (templateSelected) {
                  setViewTemplate(true);
                } else {
                  setViewDefaultTemplate(true);
                }
                /* @std by
                else if (defaultTemplate) {
                  setViewDefaultTemplate(true);
                } */
              }}
            >
              {viewTemplate ? (
                <AiFillEye className="fs-5" />
              ) : (
                <AiOutlineEye className="fs-5" />
              )}
            </button>
          )}
        </div>
        {!templateListError ? (
          <>
            {!templateList || templateList.length < 1 ? (
              <AtlasAlert className="mt-1">{alertText}</AtlasAlert>
            ) : (
              <div className="d-flex justify-content-between">
                <div className="flex-fill me-2">
                  <div>
                    <Controller
                      name={templateName}
                      control={control}
                      render={({ field: { ref, ...rest } }) => (
                        <AtlasSelect
                          {...rest}
                          isClearable
                          className={styles.singularSelect}
                          closeMenuOnSelect={true}
                          placeholder={selectDataPlaceholder}
                          options={currentTemplateList.map((t) => ({
                            label: out(
                              t.translations[1].name,
                              t.translations[0].name,
                            ),
                            value: t.id,
                          }))}
                        />
                      )}
                    />
                    {errors?.messages && errors.messages.emailTemplate && (
                      <div className="form-text text-warning">
                        {errors.messages.emailTemplate.message}
                      </div>
                    )}
                  </div>
                  {openFilter && categorySelect}
                </div>
                <div className={`d-flex ${styles.filterBtnContainer}`}>
                  <div className="d-flex align-items-center">
                    <button
                      className={`btn text-secondary py-2 ${styles.filterIconBtn}`}
                      type="button"
                      onClick={() => {
                        setOpenFilter(!openFilter);
                      }}
                    >
                      {openFilter ? (
                        <FaFilter className="fs-4" />
                      ) : (
                        <FiFilter className="fs-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </>
        ) : (
          <AtlasAlert variant="danger" className="mt-1">
            {alertErrorText}
          </AtlasAlert>
        )}
      </Col>
      {viewTemplate && currentTemplate && (
        <DocumentViewModal
          show={true}
          setModalOpen={setViewTemplate}
          template={currentTemplate}
        />
      )}
      {viewDefaultTemplate && (
        <DocumentViewModal
          show={true}
          setModalOpen={setViewDefaultTemplate}
          template={defaultTemplate}
        />
      )}
    </>
  );
};

export default MessageSettings;
