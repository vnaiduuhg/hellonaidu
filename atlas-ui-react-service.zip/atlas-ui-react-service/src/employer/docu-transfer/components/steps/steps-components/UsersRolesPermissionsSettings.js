import React from "react";
import { Controller } from "react-hook-form";
import { AtlasSelect } from "global/components/select/atlas-select";
import { useTranslation } from "global/utils/useTranslation";

const UsersRolesPermissionsSettings = ({
  index,
  name,
  control,
  watch,
  setValue,
  role,
  documentsList,
  user = null,
}) => {
  const { out } = useTranslation();
  const readOnly = watch(`${name}.${index}.readOnly`);
  const readAndWrite = watch(`${name}.${index}.readAndWrite`);

  return (
    <tr>
      {user?.user && (
        <td className="align-middle">{`${user.user.first_name} ${user.user.last_name}`}</td>
      )}
      <td className="align-middle">
        {out(role?.translation.fr.name, role?.translation.en.name)}
      </td>
      <td>
        <Controller
          name={`${name}.${index}.documentsSelected`}
          control={control}
          render={({ field: { ref, ...rest } }) => (
            <AtlasSelect
              {...rest}
              isMulti
              isClearable
              closeMenuOnSelect={false}
              placeholder={out(
                "Sélectionnez une ou plusieurs documents",
                "Select one or many documents",
              )}
              options={
                documentsList?.length > 0
                  ? documentsList.map((d) => ({
                      value: d.value,
                      label: out(d.translations.fr, d.translations.en),
                    }))
                  : []
              }
            />
          )}
        />
        <div className="form-check">
          <label className="form-check-label">
            <input
              className="form-check-input form-check-input-sm"
              name="checkAllDocuments"
              type="checkbox"
              onChange={(e) => {
                if (e.target.checked) {
                  const allDocumentsSelected = documentsList.map((d) => ({
                    value: d.value,
                    label: out(d.translations.fr, d.translations.en),
                  }));
                  setValue(
                    `${name}.${index}.documentsSelected`,
                    allDocumentsSelected,
                    { shouldDirty: true },
                  );
                } else {
                  setValue(`${name}.${index}.documentsSelected`, [], {
                    shouldDirty: true,
                  });
                }
              }}
            />
            <span className="fs-small">
              {out("Sélectionner tous les documents", "Check all documents")}
            </span>
          </label>
        </div>
      </td>
      <td className="align-middle">
        <div className="d-flex justify-content-end me-3">
          <div className="form-check d-flex align-items-center me-3">
            <label className="form-check-label">
              <input
                className="form-check-input form-check-input-md"
                name={`${name}.${index}.readOnly`}
                type="checkbox"
                checked={readOnly}
                onChange={(e) => {
                  setValue(`${name}.${index}.readOnly`, e.target.checked, {
                    shouldDirty: true,
                  });
                  if (readAndWrite)
                    setValue(`${name}.${index}.readAndWrite`, false, {
                      shouldDirty: true,
                    });
                }}
              />
            </label>
          </div>
          <div className="form-check d-flex align-items-center ms-3">
            <label className="form-check-label">
              <input
                className="form-check-input form-check-input-md"
                name={`${name}.${index}.readAndWrite`}
                type="checkbox"
                checked={readAndWrite}
                disabled={user ? +user.role_id === 10 : +role?.id === 10}
                onChange={(e) => {
                  setValue(`${name}.${index}.readAndWrite`, e.target.checked, {
                    shouldDirty: true,
                  });
                  if (readOnly)
                    setValue(`${name}.${index}.readOnly`, false, {
                      shouldDirty: true,
                    });
                }}
              />
            </label>
          </div>
        </div>
      </td>
    </tr>
  );
};

export default UsersRolesPermissionsSettings;
