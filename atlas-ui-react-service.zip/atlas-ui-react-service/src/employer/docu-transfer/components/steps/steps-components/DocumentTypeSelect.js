import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import { Controller } from "react-hook-form";
import { AtlasSelect } from "global/components/select/atlas-select";
import cx from "classnames";
import styles from "../../../styles/DocuTransfer.module.scss";

const DocumentTypeSelect = ({ control, errors, index, documentTypes }) => {
  const { out } = useTranslation();

  return (
    <>
      <Controller
        name={`sendRequest.${index}.documentType`}
        control={control}
        mandatory={true}
        rules={{
          required: {
            value: true,
            message: out(
              "Veuillez sélectionner un type de document",
              "Please select a document type",
            ),
          },
        }}
        render={({ field: { ref, ...rest } }) => (
          <AtlasSelect
            {...rest}
            className={cx(styles.singularSelect, {
              [styles.isInvalid]:
                errors?.sendRequest && errors.sendRequest[index]?.documentType,
            })}
            closeMenuOnSelect={true}
            placeholder={out(
              "Sélectionnez un type de document",
              "Select a document type",
            )}
            options={documentTypes.map((d) => ({
              label: out(d.name_fr, d.name),
              value: d.id,
            }))}
          />
        )}
      />
      {errors?.sendRequest && errors.sendRequest[index]?.documentType && (
        <div className="form-text text-warning">
          {errors.sendRequest[index].documentType.message}
        </div>
      )}
    </>
  );
};

export default DocumentTypeSelect;
