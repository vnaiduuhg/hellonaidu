import React, { useState, useEffect } from "react";
import { langLabels } from "../../../assets/translations/translations";
import MinusPlusButton from "global/components/MinusPlusButton";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { useTranslation } from "global/utils/useTranslation";
import { Button } from "react-bootstrap";
import { FaPlus, FaMinus } from "react-icons/fa";
import cx from "classnames";

const ReceiveRequestTableRow = ({
  index,
  type,
  control,
  watch,
  setValue,
  getValues,
  insertTypeRowOnArray,
  removeTypeRowFromArray,
}) => {
  const { out } = useTranslation();
  const [prevNumberOfDocumentType, setPrevNumberOfDocumentType] =
    useState(null);
  const [translationsField, openTranslationsField] = useState(false);
  const numberOfDocumentType = watch(
    `receiveRequest.${index}.numberOfDocumentType`,
  );
  const requiredNumber = watch(`receiveRequest.${index}.requiredNumber`);
  const isOptional = watch(`receiveRequest.${index}.isOptional`);
  const customTranslationsFrTitle = watch(
    `receiveRequest.${index}.customTranslations.fr.title`,
  );
  const customTranslationsEnTitle = watch(
    `receiveRequest.${index}.customTranslations.en.title`,
  );
  const translationsFrTitle = watch(
    `receiveRequest.${index}.translations.fr.title`,
  );
  const translationsEnTitle = watch(
    `receiveRequest.${index}.translations.en.title`,
  );

  useEffect(() => {
    if (!Number.isInteger(prevNumberOfDocumentType)) {
      return;
    }

    if (numberOfDocumentType > prevNumberOfDocumentType) {
      if (numberOfDocumentType > 1) {
        const typeIndex = numberOfDocumentType - 1;
        insertTypeRowOnArray(
          index + (numberOfDocumentType - 2),
          typeIndex,
          type,
        );
      } else if (numberOfDocumentType === 1) {
        setValue(`receiveRequest.${index}.requiredNumber`, 1, {
          shouldDirty: true,
        });
      }
    } else if (numberOfDocumentType < prevNumberOfDocumentType) {
      if (numberOfDocumentType > 0) {
        const indexToRemove = index + numberOfDocumentType;
        removeTypeRowFromArray(indexToRemove);
      } else if (numberOfDocumentType === 0) {
        setValue(`receiveRequest.${index}.requiredNumber`, 0, {
          shouldDirty: true,
        });
        setValue(`receiveRequest.${index}.isOptional`, 1, {
          shouldDirty: true,
        });
      }
    }

    return () => {};
  }, [numberOfDocumentType]);

  useEffect(() => {
    setValue(
      `receiveRequest.${index}.translations.fr.title`,
      customTranslationsFrTitle?.length > 0
        ? customTranslationsFrTitle
        : getValues(`receiveRequest.${index}.originalType.name_fr`),
    );

    return () => {};
  }, [customTranslationsFrTitle]);

  useEffect(() => {
    setValue(
      `receiveRequest.${index}.translations.en.title`,
      customTranslationsEnTitle?.length > 0
        ? customTranslationsEnTitle
        : getValues(`receiveRequest.${index}.originalType.name`),
    );

    return () => {};
  }, [customTranslationsEnTitle]);

  return (
    <>
      <tr
        className={cx({
          "border border-white border-bottom-0": translationsField,
        })}
      >
        <td>
          {type.typeIndex < 1 && (
            <MinusPlusButton
              name={`receiveRequest.${index}.numberOfDocumentType`}
              increaseValue={() => {
                setPrevNumberOfDocumentType(numberOfDocumentType);
                setValue(
                  `receiveRequest.${index}.numberOfDocumentType`,
                  numberOfDocumentType + 1,
                  { shouldDirty: true },
                );
              }}
              decreaseValue={() => {
                if (numberOfDocumentType > 0) {
                  setPrevNumberOfDocumentType(numberOfDocumentType);
                  setValue(
                    `receiveRequest.${index}.numberOfDocumentType`,
                    numberOfDocumentType - 1,
                    { shouldDirty: true },
                  );
                }
              }}
              inputValue={numberOfDocumentType}
              updateValue={() => {}}
            />
          )}
        </td>
        <td className="align-middle">
          {out(translationsFrTitle, translationsEnTitle)}
        </td>
        <td className="align-middle">
          <div className="d-inline-flex justify-content-around w-100 justify-content-evenly">
            <div className="form-check d-flex align-items-center">
              <label className="form-check-label">
                <input
                  className="form-check-input form-check-input-md"
                  type="radio"
                  name={`receiveRequest.${index}.isOptional`}
                  checked={isOptional}
                  disabled={numberOfDocumentType < 1 && type.typeIndex < 1}
                  onChange={(e) => {
                    setValue(`receiveRequest.${index}.isOptional`, 1, {
                      shouldDirty: true,
                    });
                  }}
                />
              </label>
            </div>
            <div className="form-check d-flex align-items-center ms-3">
              <label className="form-check-label">
                <input
                  className="form-check-input form-check-input-md"
                  type="radio"
                  name={`receiveRequest.${index}.isOptional`}
                  checked={!isOptional}
                  disabled={numberOfDocumentType < 1 && type.typeIndex < 1}
                  onChange={(e) => {
                    setValue(`receiveRequest.${index}.isOptional`, 0, {
                      shouldDirty: true,
                    });
                  }}
                />
              </label>
            </div>
          </div>
        </td>
        <td>
          <MinusPlusButton
            name={`receiveRequest.${index}.requiredNumber`}
            increaseValue={() => {
              setValue(
                `receiveRequest.${index}.requiredNumber`,
                requiredNumber + 1,
                { shouldDirty: true },
              );
            }}
            decreaseValue={() => {
              if (
                requiredNumber >
                (numberOfDocumentType > 0 || type.typeIndex > 0 ? 1 : 0)
              ) {
                setValue(
                  `receiveRequest.${index}.requiredNumber`,
                  requiredNumber - 1,
                  { shouldDirty: true },
                );
              }
            }}
            inputValue={requiredNumber}
            updateValue={() => {}}
            disabled={numberOfDocumentType < 1 && type.typeIndex < 1}
          />
        </td>
        <td>
          <Button
            variant="secondary"
            disabled={numberOfDocumentType < 1 && type.typeIndex < 1}
            onClick={() => openTranslationsField(!translationsField)}
          >
            {!translationsField && <FaPlus />}
            {translationsField && <FaMinus />}
          </Button>
        </td>
      </tr>
      {translationsField && (
        <tr className="border-bottom-1">
          <td></td>
          <td>
            <div className="mb-1">
              <FormHookFloatingLabel
                control={control}
                type="text"
                name={`receiveRequest.${index}.customTranslations.fr.title`}
                title={out(langLabels.titleFr.fr, langLabels.titleFr.en)}
              />
            </div>
            <div className="mb-1">
              <FormHookFloatingLabel
                control={control}
                type="text"
                name={`receiveRequest.${index}.customTranslations.en.title`}
                title={out(langLabels.titleEn.fr, langLabels.titleEn.en)}
              />
            </div>
          </td>
        </tr>
      )}
    </>
  );
};

export default ReceiveRequestTableRow;
