import React, { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { Col, Row, Button } from "react-bootstrap";
import { Controller } from "react-hook-form";
import {
  requestTypes,
  langLabels,
} from "../../../assets/translations/translations";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import DocumentUploadModal from "./DocumentUploadModal";
import DocumentTypeSelect from "./DocumentTypeSelect";
import {
  sendDocumentUploadFileMsgHandler,
  sendDocumentDeleteFileMsgHandler,
} from "../../../utils/steps-msg-handler";
import {
  uploadSendRequestFile,
  deleteSendRequestFile,
} from "global/apis/ToolkitApi";
import { AtlasAlert } from "global/components/atlas-alert";
import { AtlasSelect } from "global/components/select/atlas-select";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { FileProgressBar } from "global/components/progress-bar/FileProgressBar";
import { AtlasDriveModal } from "../../../../email/compose/components/AtlasDriveModal";
import {
  DM_FILE_ATTACHMENT_MAXIMUM_FILES_SIZE_IN_KB,
  DM_FILE_ATTACHMENT_TYPES,
} from "global/constants/utils";
import { useTranslation } from "global/utils/useTranslation";
import { FiUpload } from "react-icons/fi";
import { BiTrash } from "react-icons/bi";
import { HiDatabase } from "react-icons/hi";
import styles from "../../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const DocumentSettings = ({
  field,
  index,
  control,
  watch,
  trigger,
  errors,
  setValue,
  chosenLanguages,
  submitSendRequest,
  processingData,
  setProcessingData,
  documentTypes,
  documentTypesIsError,
  docuRequestTemplateId,
  removeDocumentField,
  documentIdsMissing,
  setDocumentIdsMissing,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const queryClient = useQueryClient();
  const [documentUploadModalOpen, setDocumentUploadModalOpen] = useState(false);
  const [atlasDriveModalOpen, setAtlasDriveModalOpen] = useState(false);
  const [fileUploading, setFileUploading] = useState(false);
  const [fileUploadError, setFileUploadError] = useState("");
  const [urlUploadError, setUrlUploadError] = useState("");
  const [savingAtlasDriveFile, setSavingAtlasDriveFile] = useState(false);
  const uploadType = watch(`sendRequest.${index}.uploadType`); // url|file|atlas_drive
  const documentType = watch(`sendRequest.${index}.documentType`);
  const documentUrl = watch(`sendRequest.${index}.documentUrl`);
  const documentFile = watch(`sendRequest.${index}.documentFile`);
  const documentFileName = watch(`sendRequest.${index}.documentFileName`);
  const documentId = watch(`sendRequest.${index}.documentId`);
  const dmFileId = watch(`sendRequest.${index}.dmFileId`);
  const requestType = watch(`sendRequest.${index}.requestType`);
  const titleFr = watch(`sendRequest.${index}.translations.fr.documentTitle`);
  const titleEn = watch(`sendRequest.${index}.translations.en.documentTitle`);
  const descriptionFr = watch(
    `sendRequest.${index}.translations.fr.documentText`,
  );
  const descriptionEn = watch(
    `sendRequest.${index}.translations.en.documentText`,
  );

  useEffect(() => {
    if (
      savingAtlasDriveFile &&
      dmFileId &&
      +dmFileId > 0 &&
      uploadType === "atlas_drive"
    ) {
      fileUploadHandler();
      setSavingAtlasDriveFile(false);
    }
    return () => {};
  }, [savingAtlasDriveFile]);

  useEffect(() => {
    if (documentIdsMissing.length > 0 && documentIdsMissing.includes(index)) {
      const tempIdsMissingArray = documentIdsMissing.filter(
        (i) => +i !== +index,
      );
      setDocumentIdsMissing(tempIdsMissingArray);
    }

    return () => {};
  }, [documentId]);

  const uploadSendRequestFileApi = useMutation(
    (data) => uploadSendRequestFile(docuRequestTemplateId, data),
    {
      onSuccess: (response) => {
        if (response?.id) {
          setValue(`sendRequest.${index}.documentFileName`, response.file_name);
          setValue(`sendRequest.${index}.documentId`, response.id);
          queryClient.invalidateQueries("document-request-templates");
          submitSendRequest();
        } else {
          const msg = sendDocumentUploadFileMsgHandler(500, null, () =>
            history.replace("/"),
          );
          dispatch(showMessage("error", msg.title, msg.text, 8000));
          setProcessingData(false);
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setFileUploading(false);
      },
      onError: (error) => {
        const msg = sendDocumentUploadFileMsgHandler(error.status, error, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setProcessingData(false);
        setFileUploading(false);
      },
    },
  );

  const deleteSendRequestFileApi = useMutation(
    () => deleteSendRequestFile(documentId),
    {
      onSuccess: () => {
        resetUploadDocumentValues();
        const msg = sendDocumentDeleteFileMsgHandler(204);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("document-request-templates");
      },
      onError: (error) => {
        const msg = sendDocumentDeleteFileMsgHandler(error.status, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // validate file
  const fileUploadValidated = () => {
    setFileUploadError("");
    const invalidFormat = () => {
      return out(
        "Format invalide, les formats acceptés sont: .png, .jpeg, .jpg, .gif, .pdf, .docx, .doc, .odt, .txt, .xlsx, .xls, .pptx, .ppt",
        "Invalid format, the accepted formats are: .png, .jpeg, .jpg, .gif, .pdf, .docx, .doc, .odt, .txt, .xlsx, .xls, .pptx, .ppt",
      );
    };

    if (uploadType === "file") {
      if (!documentFile) {
        setFileUploadError(
          out("Veuillez ajouter un fichier", "Please select a file"),
        );
        return false;
      }

      if (
        !documentFile.size ||
        documentFile.size / 1000 > DM_FILE_ATTACHMENT_MAXIMUM_FILES_SIZE_IN_KB
      ) {
        setFileUploadError(
          out(
            "La taille du fichier ne doit pas dépasser: 5 Mo",
            "File size should not exceed: 5MB",
          ),
        );
        return false;
      }

      const fileExtention = documentFile.name
        ? documentFile.name.split(".").pop()
        : null;
      if (!DM_FILE_ATTACHMENT_TYPES.includes(fileExtention)) {
        setFileUploadError(invalidFormat());
        return false;
      }
    } else if (uploadType === "url") {
      if (!documentUrl) {
        return false;
      }

      const fileExtension = documentUrl.split(".").pop();
      if (!DM_FILE_ATTACHMENT_TYPES.includes(fileExtension)) {
        setUrlUploadError(invalidFormat());
        return false;
      }
    }

    return true;
  };

  // prepare file query data
  const fileUploadHandler = () => {
    dispatch(showLoadingBarWithoutMessage(200000));
    setFileUploading(true);

    const data = {
      upload_type: uploadType,
      type_id: documentType.value,
    };

    if (uploadType === "file" && documentFile) {
      data.file = documentFile;
    } else if (uploadType === "url" && documentUrl) {
      data.url_link = documentUrl;
    } else {
      data.dm_file_id = dmFileId;
    }

    const formData = new FormData();
    for (const key in data) {
      formData.append(key, data[key]);
    }

    setProcessingData(true);
    uploadSendRequestFileApi.mutate(formData);
  };

  const setUploadTypeValue = (e) => {
    setValue(`sendRequest.${index}.uploadType`, e.target.value);
    if (e.target.value === "file") setUrlUploadError("");
    if (e.target.value === "url") setFileUploadError("");
  };

  const resetUploadDocumentValues = (goDirty = true) => {
    setValue(`sendRequest.${index}.documentFileName`, "");
    setValue(`sendRequest.${index}.uploadType`, "");
    setValue(`sendRequest.${index}.documentType`, "");
    setValue(`sendRequest.${index}.documentFile`, null);
    setValue(`sendRequest.${index}.documentUrl`, "");
    setValue(`sendRequest.${index}.documentId`, null, { shouldDirty: goDirty });
    setValue(`sendRequest.${index}.dmFileId`, null);
  };

  const setAtlasDriveFileValues = (fileId) => {
    setValue(`sendRequest.${index}.uploadType`, "atlas_drive");
    setValue(`sendRequest.${index}.dmFileId`, fileId);
    setSavingAtlasDriveFile(true);
    // reset other field types values
    setValue(`sendRequest.${index}.documentUrl`, "");
    setValue(`sendRequest.${index}.documentFile`, null);
  };

  return (
    <>
      <Row>
        <Col>
          <div className="d-flex justify-content-between">
            <div
              className={`${styles.sendRequestCard} flex-fill rounded p-3 my-1`}
            >
              <Row className="d-flex d-md-none">
                <Col className="d-flex justify-content-end">
                  <div>
                    <Button
                      type="button"
                      variant="alt-warning"
                      className={cx({
                        [styles.notAllowed]: processingData,
                      })}
                      disabled={processingData}
                      onClick={() => {
                        removeDocumentField(index);
                      }}
                    >
                      <BiTrash />
                    </Button>
                  </div>
                </Col>
              </Row>
              <Row className="my-0 mb-3 my-md-3">
                <Col sm={6} xxl={3}>
                  {!requestTypes || requestTypes.length < 1 ? (
                    <AtlasAlert>
                      {out(
                        "Aucun type de requête disponible",
                        "No request type available",
                      )}
                    </AtlasAlert>
                  ) : (
                    <>
                      <div>
                        <label>
                          {out("Type de demande", "Type of request")}
                        </label>
                        <Controller
                          name={`sendRequest.${index}.requestType`}
                          control={control}
                          rules={{
                            required: {
                              value: true,
                              message: out(
                                "Veuillez sélectionner un type de requête",
                                "Please select a request type",
                              ),
                            },
                          }}
                          render={({ field: { ref, ...rest } }) => (
                            <AtlasSelect
                              {...rest}
                              className={styles.singularSelect}
                              closeMenuOnSelect={true}
                              defaultValue={field.documentType}
                              mandatory={true}
                              placeholder={out(
                                "Sélectionnez un type de requête",
                                "Select a request type",
                              )}
                              options={requestTypes.map((r) => ({
                                label: out(
                                  r.translations.fr,
                                  r.translations.en,
                                ),
                                value: r.value,
                              }))}
                            />
                          )}
                        />
                        {errors?.sendRequest &&
                          errors.sendRequest[index]?.requestType && (
                            <div className="form-text text-warning">
                              {errors.sendRequest[index].requestType.message}
                            </div>
                          )}
                      </div>
                    </>
                  )}
                </Col>
                {requestType.value === "read" &&
                  documentId &&
                  documentFileName &&
                  !uploadType && (
                    <Col sm={6} className="d-flex align-items-end">
                      <div
                        className={`d-flex align-items-center ${styles.h3Dot5rem}`}
                      >
                        <div
                          className={`d-flex justify-content-between border border-1 ${styles.borderPrimary300} rounded-pill px-3 ms-1`}
                        >
                          <span className="d-flex align-items-center text-break fs-small">
                            {documentFileName}
                          </span>
                          <Button
                            type="button"
                            className={cx(
                              `align-self-center btn btn-frameless-icon btn-danger border-0 btn-sm ms-1`,
                              {
                                [styles.notAllowed]: processingData,
                              },
                            )}
                            disabled={processingData}
                            onClick={() => {
                              if (documentId) {
                                dispatch(showLoadingBarWithoutMessage(200000));
                                deleteSendRequestFileApi.mutate();
                              }
                            }}
                          >
                            <BiTrash className="fs-5" />
                          </Button>
                        </div>
                      </div>
                    </Col>
                  )}
              </Row>
              <Row className="mt-3">
                <label>
                  {out("Information sur le document", "Document information")}
                </label>
                <Col lg={6}>
                  <div className="mb-1">
                    <FormHookFloatingLabel
                      control={control}
                      type="text"
                      name={`sendRequest.${index}.translations.fr.documentTitle`}
                      mandatory={chosenLanguages.includes("fr")}
                      title={out(langLabels.titleFr.fr, langLabels.titleFr.en)}
                      rules={{
                        required: {
                          value:
                            chosenLanguages.includes("fr") || descriptionFr,
                          message: chosenLanguages.includes("fr")
                            ? out(
                                "Veuillez entrer un titre français",
                                "Please enter a french title",
                              )
                            : out(
                                "Vous devez également entrer un titre lorsque la description est définie",
                                "You must also enter a title when the description is defined",
                              ),
                        },
                        maxLength: {
                          value: 255,
                          message: out(
                            "Le titre doit contenir un maximum de 255 caractères",
                            "The title must contain a maximum of 255 characters",
                          ),
                        },
                      }}
                      error={
                        errors?.sendRequest &&
                        errors.sendRequest[index]?.translations?.fr
                          ?.documentTitle
                      }
                    />
                  </div>
                  <div className="mb-1">
                    <FormHookFloatingLabel
                      type="textarea"
                      control={control}
                      name={`sendRequest.${index}.translations.fr.documentText`}
                      mandatory={chosenLanguages.includes("fr")}
                      title={out(
                        langLabels.descriptionFr.fr,
                        langLabels.descriptionFr.en,
                      )}
                      style={{ height: "7.5rem" }}
                      rules={{
                        required: {
                          value: chosenLanguages.includes("fr") || titleFr,
                          message: chosenLanguages.includes("fr")
                            ? out(
                                "Veuillez entrer une description française",
                                "Please enter a french description",
                              )
                            : out(
                                "Vous devez également entrer une description lorsque le titre est défini",
                                "You must also enter a description when the title is defined",
                              ),
                        },
                        maxLength: {
                          value: 255,
                          message: out(
                            "La description doit contenir un maximum de 255 caractères",
                            "The description must contain a maximum of 255 characters",
                          ),
                        },
                      }}
                      error={
                        errors?.sendRequest &&
                        errors.sendRequest[index]?.translations?.fr
                          ?.documentText
                      }
                      showError={false}
                    />
                    <div className="d-flex justify-content-between">
                      <div>
                        {errors?.sendRequest &&
                          errors.sendRequest[index]?.translations?.fr
                            ?.documentText && (
                            <div className="form-text text-warning">
                              {
                                errors.sendRequest[index].translations?.fr
                                  ?.documentText.message
                              }
                            </div>
                          )}
                      </div>
                      <span className="d-flex align-items-center text-form text-muted fs-small">
                        {descriptionFr && descriptionFr.length
                          ? descriptionFr.length
                          : 0}
                        /255
                      </span>
                    </div>
                  </div>
                </Col>
                <Col lg={6}>
                  <div className="mb-1">
                    <FormHookFloatingLabel
                      control={control}
                      type="text"
                      name={`sendRequest.${index}.translations.en.documentTitle`}
                      mandatory={chosenLanguages.includes("en")}
                      title={out(langLabels.titleEn.fr, langLabels.titleEn.en)}
                      rules={{
                        required: {
                          value:
                            chosenLanguages.includes("en") || descriptionEn,
                          message: chosenLanguages.includes("en")
                            ? out(
                                "Veuillez entrer un titre anglais",
                                "Please enter an english title",
                              )
                            : out(
                                "Vous devez également entrer un titre lorsque la description est définie",
                                "You must also enter a title when the description is defined",
                              ),
                        },
                        maxLength: {
                          value: 255,
                          message: out(
                            "Le titre doit contenir un maximum de 255 caractères",
                            "The title must contain a maximum of 255 characters",
                          ),
                        },
                      }}
                      error={
                        errors?.sendRequest &&
                        errors.sendRequest[index]?.translations?.en
                          ?.documentTitle
                      }
                    />
                  </div>
                  <div className="mb-1">
                    <FormHookFloatingLabel
                      type="textarea"
                      control={control}
                      name={`sendRequest.${index}.translations.en.documentText`}
                      mandatory={chosenLanguages.includes("en")}
                      title={out(
                        langLabels.descriptionEn.fr,
                        langLabels.descriptionEn.en,
                      )}
                      style={{ height: "7.5rem" }}
                      rules={{
                        required: {
                          value: chosenLanguages.includes("en") || titleEn,
                          message: chosenLanguages.includes("en")
                            ? out(
                                "Veuillez entrer une description anglaise",
                                "Please enter an english description",
                              )
                            : out(
                                "Vous devez également entrer une description lorsque le titre est défini",
                                "You must also enter a description when the title is defined",
                              ),
                        },
                        maxLength: {
                          value: 255,
                          message: out(
                            "La description doit contenir un maximum de 255 caractères",
                            "The description must contain a maximum of 255 characters",
                          ),
                        },
                      }}
                      error={
                        errors?.sendRequest &&
                        errors.sendRequest[index]?.translations?.en
                          ?.documentText
                      }
                      showError={false}
                    />
                    <div className="d-flex justify-content-between">
                      <div>
                        {errors?.sendRequest &&
                          errors.sendRequest[index]?.translations?.en
                            ?.documentText && (
                            <div className="form-text text-warning">
                              {
                                errors.sendRequest[index].translations?.en
                                  ?.documentText.message
                              }
                            </div>
                          )}
                      </div>
                      <span className="d-flex align-items-center text-form text-muted fs-small">
                        {descriptionEn && descriptionEn.length
                          ? descriptionEn.length
                          : 0}
                        /255
                      </span>
                    </div>
                  </div>
                </Col>
              </Row>
              {requestType.value === "read" && (
                <Row className="my-0 mb-3">
                  <Col
                    md={6}
                    xl={4}
                    className={cx("d-flex", {
                      "align-items-end":
                        !errors.sendRequest ||
                        (errors.sendRequest &&
                          !errors.sendRequest[index]?.requestType),
                      "align-items-center":
                        errors.sendRequest &&
                        errors.sendRequest[index]?.requestType,
                    })}
                  >
                    <div
                      className={`d-flex align-items-center w-100 ${styles.h3Dot5rem}`}
                    >
                      <Button
                        className={cx("px-2 me-2", {
                          [styles.notAllowed]: documentId,
                        })}
                        variant="secondary"
                        disabled={
                          documentId ||
                          (chosenLanguages.includes("fr") &&
                            (!titleFr || !descriptionFr)) ||
                          (chosenLanguages.includes("en") &&
                            (!titleEn || !descriptionEn)) ||
                          processingData
                        }
                        onClick={() => {
                          setDocumentUploadModalOpen(true);
                        }}
                      >
                        <FiUpload className="fs-4" />
                      </Button>
                      {!fileUploading &&
                        (!documentId ||
                          (documentId &&
                            !["file", "url"].includes(uploadType))) && (
                          <label className="fs-5">
                            {out("Téléverser un document", "Upload document")}
                          </label>
                        )}
                      {fileUploading && ["file", "url"].includes(uploadType) && (
                        <div className="progress progress-rounded w-75">
                          <FileProgressBar id={1} />
                        </div>
                      )}
                      {!documentUploadModalOpen &&
                        !fileUploading &&
                        documentId &&
                        ((uploadType === "file" && documentFileName) ||
                          (uploadType === "url" && documentUrl)) && (
                          <div
                            className={`d-flex justify-content-between border border-1 ${styles.borderPrimary300} rounded-pill px-3 ms-1`}
                          >
                            <span className="d-flex align-items-center text-break fs-small">
                              {uploadType === "file"
                                ? documentFileName
                                : documentUrl}
                            </span>
                            <Button
                              type="button"
                              className={cx(
                                `align-self-center btn btn-frameless-icon btn-danger border-0 btn-sm ms-1`,
                                {
                                  [styles.notAllowed]: processingData,
                                },
                              )}
                              disabled={processingData}
                              onClick={() => {
                                if (documentId) {
                                  dispatch(
                                    showLoadingBarWithoutMessage(200000),
                                  );
                                  deleteSendRequestFileApi.mutate();
                                }
                              }}
                            >
                              <BiTrash className="fs-5" />
                            </Button>
                          </div>
                        )}
                    </div>
                  </Col>
                  <Col
                    md={6}
                    xl={4}
                    className={cx("d-flex", {
                      "align-items-end":
                        !errors.sendRequest ||
                        (errors.sendRequest &&
                          !errors.sendRequest[index]?.requestType),
                      "align-items-center":
                        errors.sendRequest &&
                        errors.sendRequest[index]?.requestType,
                    })}
                  >
                    <div
                      className={`d-flex align-items-center w-100 ${styles.h3Dot5rem}`}
                    >
                      <Button
                        className={cx("px-2 me-2", {
                          [styles.notAllowed]: documentId,
                        })}
                        variant="secondary"
                        disabled={
                          documentId ||
                          (chosenLanguages.includes("fr") &&
                            (!titleFr || !descriptionFr)) ||
                          (chosenLanguages.includes("en") &&
                            (!titleEn || !descriptionEn)) ||
                          processingData
                        }
                        onClick={() => {
                          setAtlasDriveModalOpen(true);
                        }}
                      >
                        <HiDatabase className="fs-4" />
                      </Button>
                      {!(
                        documentId &&
                        uploadType === "atlas_drive" &&
                        // !["url", "file"].includes(uploadType) && - @std by
                        documentFileName
                      ) && (
                        <label className="fs-5">
                          {out("Classeur Atlas", "Atlas drive")}
                        </label>
                      )}
                      {fileUploading && uploadType === "atlas_drive" && (
                        /* !["url", "file"].includes(uploadType) &&  - @std by */
                        <div className="progress progress-rounded w-75">
                          <FileProgressBar id={2} />
                        </div>
                      )}
                      {!atlasDriveModalOpen &&
                        documentId &&
                        uploadType === "atlas_drive" &&
                        // !["url", "file"].includes(uploadType) && - @std by
                        documentFileName && (
                          <div
                            className={`d-flex justify-content-between border border-1 ${styles.borderPrimary300} rounded-pill px-3 ms-1`}
                          >
                            <span className="d-flex align-items-center text-break fs-small">
                              {documentFileName}
                            </span>
                            <Button
                              type="button"
                              className={cx(
                                `align-self-center btn btn-frameless-icon btn-danger border-0 btn-sm ms-1`,
                                {
                                  [styles.notAllowed]: processingData,
                                },
                              )}
                              disabled={processingData}
                              onClick={() => {
                                if (documentId) {
                                  dispatch(
                                    showLoadingBarWithoutMessage(200000),
                                  );
                                  deleteSendRequestFileApi.mutate();
                                }
                              }}
                            >
                              <BiTrash className="fs-5" />
                            </Button>
                          </div>
                        )}
                    </div>
                  </Col>
                  {documentIdsMissing.includes(index) && !documentId && (
                    <div
                      className={`d-flex align-items-start ${styles.mtMinus5px}`}
                      col={12}
                    >
                      <label
                        className={cx("fs-small", {
                          "text-warning":
                            documentIdsMissing.includes(index) && !documentId,
                        })}
                      >
                        {out(
                          "Veuillez téléverser un document",
                          "Please upload a document",
                        )}
                      </label>
                    </div>
                  )}
                  <Col xs={12}>
                    <div
                      className={`form-text text-muted ${styles.disabledUploadInfoMsg}`}
                    >
                      {out(
                        "Veuillez supprimer le document actuel avant d'en télécharger un nouveau",
                        "Please delete the current document before to upload a new one",
                      )}
                    </div>
                  </Col>
                </Row>
              )}
            </div>
            <div className="d-none d-md-flex align-items-center">
              <div className="ms-3">
                <Button
                  type="button"
                  variant="alt-danger"
                  className={cx({
                    [styles.notAllowed]: processingData,
                  })}
                  disabled={processingData}
                  onClick={() => {
                    removeDocumentField(index);
                  }}
                >
                  <BiTrash />
                </Button>
              </div>
            </div>
          </div>
        </Col>
      </Row>
      <DocumentUploadModal
        show={documentUploadModalOpen}
        setModalOpen={setDocumentUploadModalOpen}
        control={control}
        setValue={setValue}
        trigger={trigger}
        errors={errors}
        index={index}
        chosenLanguages={chosenLanguages}
        documentTypes={documentTypes}
        documentTypesIsError={documentTypesIsError}
        uploadType={uploadType}
        setUploadTypeValue={setUploadTypeValue}
        fileUploadValidated={fileUploadValidated}
        fileUploading={fileUploading}
        fileUploadHandler={fileUploadHandler}
        fileUploadError={fileUploadError}
        urlUploadError={urlUploadError}
        setFileUploadError={setFileUploadError}
        resetUploadDocumentValues={resetUploadDocumentValues}
      />
      <AtlasDriveModal
        showModal={atlasDriveModalOpen}
        hide={() => {
          setValue(`sendRequest.${index}.dmFileId`, null);
          setValue(`sendRequest.${index}.documentType`, "");
          setAtlasDriveModalOpen(false);
        }}
        singleFileSelect={true}
        attachFile={(file) => {
          trigger([
            `sendRequest.${index}.documentType`,
            // @todo fix - bring translation title & description under one condition
            chosenLanguages.includes("fr")
              ? `sendRequest.${index}.translations.fr.documentTitle`
              : null,
            chosenLanguages.includes("fr")
              ? `sendRequest.${index}.translations.fr.documentText`
              : null,
            chosenLanguages.includes("en")
              ? `sendRequest.${index}.translations.en.documentTitle`
              : null,
            chosenLanguages.includes("en")
              ? `sendRequest.${index}.translations.en.documentText`
              : null,
          ]).then((isClearOfErrors) => {
            if (isClearOfErrors) {
              setAtlasDriveFileValues(file.dm_file_id);
              setAtlasDriveModalOpen(false);
            } else if (!errors.sendRequest[index]?.documentType) {
              setAtlasDriveModalOpen(false);
            }
          });
        }}
      >
        <>
          <label>
            {out(
              "Veuillez sélectionner un type de document",
              "Please select a document type",
            )}
          </label>
          {documentTypesIsError && (
            <div>
              <AtlasAlert variant="danger">
                {out(
                  "La liste des types de documents n'a pu être récupérée",
                  "Document types list could not be retrieved",
                )}
              </AtlasAlert>
            </div>
          )}
          <DocumentTypeSelect
            control={control}
            errors={errors}
            index={index}
            documentTypes={documentTypes}
          />
        </>
      </AtlasDriveModal>
    </>
  );
};

export default DocumentSettings;
