import React, { useRef, useState } from "react";
import { Modal, Button } from "react-bootstrap";
import DocumentTypeSelect from "./DocumentTypeSelect";
import { useTranslation } from "global/utils/useTranslation";
import { FormHookFloatingLabel } from "global/components/form-hook/regular/FormHookFloatingLabel";
import { AtlasAlert } from "global/components/atlas-alert";
import { FiUpload } from "react-icons/fi";
import { AiOutlineClose } from "react-icons/ai";
import styles from "../../../styles/DocuTransfer.module.scss";
import { DM_FILE_ATTACHMENT_TYPES } from "global/constants/utils";

const DocumentUploadModal = ({
  show,
  setModalOpen,
  control,
  setValue,
  trigger,
  errors,
  index,
  chosenLanguages,
  documentTypes,
  documentTypesIsError,
  uploadType,
  setUploadTypeValue,
  fileUploadValidated,
  fileUploading,
  fileUploadHandler,
  fileUploadError,
  urlUploadError,
  setFileUploadError,
  resetUploadDocumentValues,
}) => {
  const { out } = useTranslation();
  const $fileUpload = useRef(null);
  const [tempFileUploadedName, setTempFileUploadedName] = useState("");

  return (
    <Modal
      show={show}
      onHide={() => {
        setModalOpen(false);
      }}
    >
      <Modal.Header closeButton>
        <Modal.Title>
          {out("Téléverser un nouveau document", "Upload a new document")}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div>
          <label>{out("Catégories", "Categories")}</label>
          {documentTypesIsError && (
            <div>
              <AtlasAlert variant="danger">
                {out(
                  "La liste des types de documents n'a pu être récupérée",
                  "Document types list could not be retrieved",
                )}
              </AtlasAlert>
            </div>
          )}
          {!documentTypesIsError && (
            <DocumentTypeSelect
              control={control}
              errors={errors}
              index={index}
              documentTypes={documentTypes}
            />
          )}
        </div>
        <div className="d-flex my-3">
          <label className="me-3">
            {out("Source du téléversement", "Upload source")}
          </label>
          <div className="d-flex">
            <div className="form-check me-3">
              <label className="form-check-label">
                <input
                  className="form-check-input form-check-input-md me-1"
                  type="radio"
                  name={`sendRequest.${index}.uploadType`}
                  value="file"
                  checked={uploadType === "file"}
                  onChange={(e) => {
                    setUploadTypeValue(e);
                    setValue(`sendRequest.${index}.documentUrl`, "");
                    setValue(`sendRequest.${index}.dmFileId`, null);
                  }}
                />
                {out("Ordinateur", "Computer")}
              </label>
            </div>
            <div className="form-check">
              <label className="form-check-label">
                <input
                  className="form-check-input form-check-input-md me-1"
                  type="radio"
                  name={`sendRequest.${index}.uploadType`}
                  value="url"
                  checked={uploadType === "url"}
                  onChange={(e) => {
                    setUploadTypeValue(e);
                    setTempFileUploadedName("");
                    setValue(`sendRequest.${index}.documentFile`, null);
                    setValue(`sendRequest.${index}.dmFileId`, null);
                  }}
                />
                {out("Url", "Url")}
              </label>
            </div>
          </div>
        </div>
        {uploadType === "url" && (
          <div className="mb-1">
            <FormHookFloatingLabel
              control={control}
              type="url"
              placeholder="https://example.com"
              name={`sendRequest.${index}.documentUrl`}
              mandatory={true}
              title={out("Url", "Url")}
              rules={{
                required: {
                  value: true,
                  message: out(
                    "Veuillez entrer l'url du document",
                    "Please enter the document url",
                  ),
                },
                pattern: {
                  value: /(http|ftp)(s)?:\/\/.*/gm,
                  message: out("Url invalide", "Invalid url"),
                },
              }}
              error={
                errors?.sendRequest && errors.sendRequest[index]?.documentUrl
                  ? errors.sendRequest[index].documentUrl
                  : null
              }
            />
          </div>
        )}
        {uploadType === "file" && (
          <div
            className={`d-flex flex-column align-items-center rounded p-3 ${styles.borderMediumGray}`}
          >
            <FiUpload className="fs-3 text-secondary-100 mb-2" />
            <h5 className="mb-3">
              {out(
                "Téléversez votre document ici",
                "Upload your document here",
              )}
            </h5>
            <Button
              type="button"
              variant="secondary"
              onClick={() => $fileUpload.current.click()}
            >
              {out("Sélectionnez un fichier", "Select file")}
            </Button>
            <input
              className="d-none"
              type="file"
              ref={$fileUpload}
              accept={DM_FILE_ATTACHMENT_TYPES.map((f) => `.${f}`).join(",")}
              onChange={(e) => {
                if (e?.target?.files.length > 0) {
                  setTempFileUploadedName(e.target.files[0].name);
                  setValue(
                    `sendRequest.${index}.documentFile`,
                    e.target.files[0],
                  );
                  setFileUploadError("");
                }
              }}
            />
            {tempFileUploadedName && (
              <div
                className={`border border-1 ${styles.borderPrimary300} rounded-pill mt-3 px-3`}
              >
                {tempFileUploadedName}
                <Button
                  type="button"
                  className="btn btn-frameless-icon btn-tertiary btn-square-frame btn-sm ms-1"
                  onClick={() => {
                    setTempFileUploadedName("");
                    setValue(`sendRequest.${index}.documentFile`, null);
                    setFileUploadError("");
                  }}
                >
                  <AiOutlineClose className="fs-5" />
                </Button>
              </div>
            )}
            <p className="text-center text-muted fs-6 my-3">
              <i className="mb-3">
                {out(
                  "Formats acceptés: .png, .jpeg, .jpg, .gif, .pdf, .docx, .doc, .odt, .txt, .xlsx, .xls, .pptx, .ppt",
                  "Accepted formats: .png, .jpeg, .jpg, .gif, .pdf, .docx, .doc, .odt, .txt, .xlsx, .xls, .pptx, .ppt",
                )}
              </i>
              <br />
              <i>
                {out(
                  "La taille du fichier ne doit pas dépasser 5 Mo",
                  "File size should not exceed 5MB",
                )}
              </i>
            </p>
          </div>
        )}
        {fileUploadError && uploadType === "file" && (
          <div className="form-text text-warning">{fileUploadError}</div>
        )}
        {urlUploadError && uploadType === "url" && (
          <div className="form-text text-warning">{urlUploadError}</div>
        )}
      </Modal.Body>

      <Modal.Footer>
        <div className="d-flex justify-content-end mt-3">
          <Button
            className="ms-3"
            type="button"
            variant="alt-secondary btn-md"
            onClick={() => {
              resetUploadDocumentValues();
              setModalOpen(false);
            }}
          >
            {out("Annuler", "Cancel")}
          </Button>
          <Button
            type="submit"
            variant="secondary btn-md"
            className="ms-3"
            disabled={!uploadType || fileUploading}
            onClick={async () => {
              const isClearedOfErrors = await trigger([
                `sendRequest.${index}.documentType`,
                // @todo fix - bring translation title & description under one condition
                chosenLanguages.includes("fr")
                  ? `sendRequest.${index}.translations.fr.documentTitle`
                  : null,
                chosenLanguages.includes("fr")
                  ? `sendRequest.${index}.translations.fr.documentText`
                  : null,
                chosenLanguages.includes("en")
                  ? `sendRequest.${index}.translations.en.documentTitle`
                  : null,
                chosenLanguages.includes("en")
                  ? `sendRequest.${index}.translations.en.documentText`
                  : null,
                uploadType === "url"
                  ? `sendRequest.${index}.documentUrl`
                  : null,
              ]);
              const fileIsValid = fileUploadValidated();

              if (isClearedOfErrors && fileIsValid) {
                fileUploadHandler();
                setModalOpen(false);
              } /* @std by - does not seem to make sense
              else if (
                errors?.sendRequest &&
                !errors.sendRequest[index]?.documentType
              ) {
                setModalOpen(false);
              } */
            }}
          >
            {out("Téléverser", "Upload")}
          </Button>
        </div>
      </Modal.Footer>
    </Modal>
  );
};

export default DocumentUploadModal;
