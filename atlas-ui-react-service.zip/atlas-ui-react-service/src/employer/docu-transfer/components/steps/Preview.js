import React, { useEffect } from "react";
import DocuTransferTemplateView from "../DocuTransferTemplateView";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";

const Preview = ({
  template,
  templateIsPublished,
  showIsDraftWarning,
  emailTemplates,
  smsTemplates,
  selectedRolesList,
  selectedUsersList,
  setSaveIsDisabled,
  getValues,
  notification,
  dataRetrievedError = false,
}) => {
  const { out } = useTranslation();

  useEffect(() => {
    const receiveRequestArray = getValues("receiveRequest");
    const receiveRequest =
      receiveRequestArray?.length > 0
        ? receiveRequestArray.filter(
            (d) => d.numberOfDocumentType > 0 && d.requiredNumber > 0,
          )
        : [];
    const sendRequest = getValues("sendRequest") ?? [];

    setSaveIsDisabled(sendRequest.length < 1 && receiveRequest.length < 1);
    return () => {};
  }, []);

  return (
    <div className="p-3 mt-5">
      {!dataRetrievedError ? (
        <DocuTransferTemplateView
          template={template}
          templateIsPublished={templateIsPublished}
          showIsDraftWarning={showIsDraftWarning}
          emailTemplates={emailTemplates}
          smsTemplates={smsTemplates}
          selectedRolesList={selectedRolesList}
          selectedUsersList={selectedUsersList}
          notification={notification}
          isPreview={true}
        />
      ) : (
        <div className="mt-2">
          <AtlasAlert variant="danger">
            {out(
              "Une erreur s'est produite et nous ne pouvons afficher l'apreçu du modèle de requête de documents",
              "An error has occurred and we cannot display the preview of the document request template",
            )}
          </AtlasAlert>
        </div>
      )}
    </div>
  );
};

export default Preview;
