import React, { useState, useEffect } from "react";
import { Col, Row, Table } from "react-bootstrap";
import { receiveRequestHeader } from "../../assets/translations/translations";
import ReceiveRequestTableRow from "./steps-components/ReceiveRequestTableRow";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import styles from "../../styles/DocuTransfer.module.scss";
import cx from "classnames";

const ReceiveRequest = ({
  templateIsDraft,
  templateIsPublished,
  showIsDraftWarning,
  fields,
  append,
  remove,
  insert,
  control,
  watch,
  setValue,
  getValues,
  reset,
  settingsMode,
  documentTypes,
  documentTypesIsError,
}) => {
  const { out } = useTranslation();
  const [loadingDocumentTypes, setLoadingDocumentTypes] = useState(false);

  useEffect(() => {
    if (
      settingsMode === "create" &&
      documentTypes.length > 0 &&
      !documentTypesIsError &&
      fields.length < 1
    ) {
      setLoadingDocumentTypes(true);
      documentTypes.forEach((type) => {
        appendTypeOnArray(type);
      });
      reset({}, { keepValues: true });
      setLoadingDocumentTypes(false);
    }

    return () => {};
  }, []);

  const appendTypeOnArray = (type) => {
    append({
      originalType: type,
      documentTypeId: type.id,
      documentId: null,
      requiredNumber: 0,
      isOptional: 1,
      translations: {
        fr: {
          title: type.name_fr,
        },
        en: {
          title: type.name,
        },
      },
      customTranslations: {
        fr: {
          title: "",
        },
        en: {
          title: "",
        },
      },
      typeIndex: 0,
      numberOfDocumentType: 0,
    });
  };

  const insertTypeRowOnArray = (index, typeIndex, field) => {
    const type = documentTypes.find(
      (type) => +type.id === +field.documentTypeId,
    );
    insert(index + 1, {
      originalType: type,
      documentTypeId: type.id,
      requiredNumber: 1,
      isOptional: 1,
      translations: {
        fr: {
          title: type.name_fr,
        },
        en: {
          title: type.name,
        },
      },
      customTranslations: {
        fr: {
          title: "",
        },
        en: {
          title: "",
        },
      },
      typeIndex: typeIndex,
      numberOfDocumentType: 1,
    });
  };

  return (
    <div className="p-3 pt-5">
      <Row className="my-3">
        <Col xs={12}>
          <div className="d-flex align-self-center mb-3">
            <h5 className="mb-0">
              {out(
                receiveRequestHeader.title.fr,
                receiveRequestHeader.title.en,
              )}
            </h5>
            {templateIsDraft > 0 && (
              <div>
                <span
                  className={cx(`ms-2 ${styles.draftLabelSm}`, {
                    [styles.blueLabel]: !templateIsPublished,
                    [styles.warningLabel]:
                      templateIsPublished && showIsDraftWarning,
                  })}
                >
                  {out("Brouillon", "Draft")}
                </span>
              </div>
            )}
          </div>
        </Col>
      </Row>
      {loadingDocumentTypes && (
        <div className={`bg-white ${styles.componentLoaderPadding}`}>
          <NestedPageLoader
            message={out("Veuillez patienter...", "Please wait...")}
          />
        </div>
      )}
      {!loadingDocumentTypes && (
        <Row>
          <Col>
            <Table responsive="md">
              <thead>
                <tr className="text-secondary-100">
                  <th scope="col">{out("Quantité", "Quantity")}</th>
                  <th scope="col">
                    {out("Documents requis", "Required documents")}
                  </th>
                  <th className="text-center" scope="col">
                    {out("Optionnel / Obligatoire", "Optional / Mandatory")}
                  </th>
                  <th scope="col">{out("Nombre requis", "Number required")}</th>
                  <th scope="col">{out("Modifier le titre", "Edit title")}</th>
                </tr>
              </thead>
              <tbody>
                {documentTypesIsError && (
                  <div>
                    <AtlasAlert variant="danger">
                      {out(
                        "La liste des types de documents n'a pu être récupérée",
                        "Document types list could not be retrieved",
                      )}
                    </AtlasAlert>
                  </div>
                )}
                {fields.map((field, index) => {
                  return (
                    <ReceiveRequestTableRow
                      key={field.id}
                      index={index}
                      type={field}
                      control={control}
                      watch={watch}
                      setValue={setValue}
                      getValues={getValues}
                      insertTypeRowOnArray={insertTypeRowOnArray}
                      removeTypeRowFromArray={(index) => remove(index)}
                    />
                  );
                })}
              </tbody>
            </Table>
          </Col>
        </Row>
      )}
    </div>
  );
};

export default ReceiveRequest;
