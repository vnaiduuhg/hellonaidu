import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Table, Button, OverlayTrigger, Tooltip } from "react-bootstrap";
import AccessCheckboxes from "./AccessCheckboxes";
import DocumentViewModal from "./TemplateViewModal";
import { DocumentPreviewModal } from "./DocumentPreviewModal";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import { getTimeFormat } from "global/utils/dateTimeLanguageUtils";
import { AiFillEye, AiOutlineEye } from "react-icons/ai";
import styles from "../styles/DocuTransfer.module.scss";
import cx from "classnames";

const DocuTransferTemplateView = ({
  template,
  templateIsPublished,
  showIsDraftWarning,
  emailTemplates,
  smsTemplates,
  selectedRolesList,
  selectedUsersList,
  notification,
  isPreview = false,
}) => {
  const { out } = useTranslation();
  const language = useSelector((state) => state.user.language);
  const [loading, setLoading] = useState(true);
  const [viewTemplate, setViewTemplate] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState(null);
  const [emailTemplate, setEmailTemplate] = useState(null);
  const [smsTemplate, setSmsTemplate] = useState(null);
  const [showDocumentPreview, setShowDocumentPreview] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);
  const createdAt = template.created_at
    ? getTimeFormat(template.created_at, "LL")
    : "N/A";

  useEffect(() => {
    if (template?.email_template_id) {
      const selectedTemplate = emailTemplates.find(
        (t) => +t.id === +template.email_template_id,
      );
      setEmailTemplate(selectedTemplate);
    }

    if (template?.sms_template_id) {
      const selectedTemplate = smsTemplates.find(
        (t) => +t.id === +template.sms_template_id,
      );
      setSmsTemplate(selectedTemplate);
    }
    setLoading(false);

    return () => {};
  }, [template]);

  return (
    <>
      {loading && (
        <div className="bg-white pb-3">
          <ComponentLoader
            message={out("Veuillez patienter...", "Please wait...")}
          />
        </div>
      )}
      {!loading && (
        <div>
          <div className="fs-large">
            <div className="d-inline-flex align-items-center mb-3">
              {!isPreview && (
                <div className="me-2">
                  <label className="text-dark-blue me-3 fw-bold">
                    {out("Création", "Creation")}:
                  </label>
                  <span>{out(createdAt.fr, createdAt.en)}</span>
                </div>
              )}
              {template.is_draft > 0 && (
                <span
                  className={cx(`${styles.blueLabel} ${styles.draftLabelMd}`, {
                    [styles.blueLabel]: !templateIsPublished,
                    [styles.warningLabel]:
                      templateIsPublished && showIsDraftWarning,
                  })}
                >
                  {out("Brouillon", "Draft")}
                </span>
              )}
            </div>
            {isPreview && (
              <div className="mb-3">
                <label className="text-dark-blue me-2 fw-bold">
                  {language === "fr"
                    ? out("Titre français", "French title")
                    : out("Titre anglais", "English title")}
                  :
                </label>
                <span className="me-1">
                  {language === "fr"
                    ? template.translations?.fr?.title ??
                      template.translations?.en?.title
                    : template.translations?.en?.title ??
                      template.translations?.fr?.title}
                </span>
                <span className="text-muted">
                  <i>
                    {language === "fr"
                      ? !template.translations?.fr?.title
                        ? " (aucun titre disponible en français)"
                        : ""
                      : !template.translations?.en?.title
                      ? " (no english title available)"
                      : ""}
                  </i>
                </span>
                <div className="text-soft-dark fst-italic">
                  <label className="me-2 fw-bold">
                    {language === "fr"
                      ? out("Titre anglais", "English title")
                      : out("Titre français", "French title")}
                    :
                  </label>
                  <span className="me-1">
                    {language === "fr"
                      ? template.translations?.en?.title ??
                        template.translations?.fr?.title
                      : template.translations?.fr?.title ??
                        template.translations?.en?.title}
                  </span>
                  <span className="text-muted">
                    <i>
                      {language === "fr"
                        ? !template.translations?.en?.title
                          ? " (aucun titre disponible en anglais)"
                          : ""
                        : !template.translations?.fr?.title
                        ? " (no french title available)"
                        : ""}
                    </i>
                  </span>
                </div>
              </div>
            )}
            {!isPreview && (
              <div className="mb-2">
                <label className="text-dark-blue me-2 fw-bold">
                  {out("Description", "Description")}:
                </label>
                <span className="me-1">
                  {out(
                    template.translations?.fr?.description ??
                      template.translations?.en?.description,
                    template.translations?.en?.description ??
                      template.translations?.fr?.description,
                  )}
                </span>
                <span className="text-muted">
                  <i>
                    {out(
                      !template.translations.fr?.description
                        ? " (aucune description disponible en français)"
                        : "",

                      !template.translations.en?.description
                        ? " (no english description available)"
                        : "",
                    )}
                  </i>
                </span>
              </div>
            )}
            {isPreview && (
              <div className="mb-3">
                <label className="text-dark-blue me-2 fw-bold">
                  {language === "fr"
                    ? out("Description française", "French description")
                    : out("Description anglaise", "English description")}
                  :
                </label>
                <span className="me-1">
                  {language === "fr"
                    ? template.translations?.fr?.description ??
                      template.translations?.en?.description
                    : template.translations?.en?.description ??
                      template.translations?.fr?.description}
                </span>
                <span className="text-muted">
                  <i>
                    {language === "fr"
                      ? !template.translations?.fr?.description
                        ? " (aucune description disponible en français)"
                        : ""
                      : !template.translations?.en?.description
                      ? " (no english description available)"
                      : ""}
                  </i>
                </span>
                <div className="text-soft-dark fst-italic">
                  <label className="me-2 fw-bold">
                    {language === "fr"
                      ? out("Description anglaise", "English description")
                      : out("Description française", "French description")}
                    :
                  </label>
                  <span className="me-1">
                    {language === "fr"
                      ? template.translations?.en?.description ??
                        template.translations?.fr?.description
                      : template.translations?.fr?.description ??
                        template.translations?.en?.description}
                  </span>
                  <span className="text-muted">
                    <i>
                      {language === "fr"
                        ? !template.translations?.en?.description
                          ? " (aucune description disponible en anglais)"
                          : ""
                        : !template.translations?.fr?.description
                        ? " (no french description available)"
                        : ""}
                    </i>
                  </span>
                </div>
              </div>
            )}
            <div>
              <label className="text-dark-blue me-2 fw-bold">
                {out("Modèle de courriel", "Email template")}:
              </label>
              <span>
                {emailTemplate
                  ? out(
                      emailTemplate.translations[1]?.name ??
                        emailTemplate.translations[0].name,
                      emailTemplate.translations[0]?.name ??
                        emailTemplate.translations[1].name,
                    )
                  : notification?.length > 0
                  ? out(
                      notification[0]?.email_template?.translations[1]?.name ??
                        notification[0]?.email_template?.translations[0].name,
                      notification[0]?.email_template?.translations[0]?.name ??
                        notification[0]?.email_template?.translations[1].name,
                    )
                  : "N/A"}
              </span>
              <span className="text-muted me-2">
                <i>
                  {out(
                    template.email_template_id &&
                      !emailTemplate?.translations[1]?.name
                      ? " (aucun titre disponible en français)"
                      : "",
                    template.email_template_id &&
                      !emailTemplate?.translations[0]?.name
                      ? " (no english title available)"
                      : "",
                  )}
                </i>
              </span>
              {(template.email_template_id || notification?.length > 0) && (
                <Button
                  variant="secondary"
                  size="sm"
                  className="btn-frameless-icon text-secondary d-inline-flex"
                  type="button"
                  onClick={(e) => {
                    setCurrentTemplate(
                      emailTemplate ?? notification[0].email_template,
                    );
                    setViewTemplate(e);
                  }}
                >
                  {viewTemplate ? (
                    <AiFillEye className="fs-5" />
                  ) : (
                    <AiOutlineEye className="fs-5" />
                  )}
                </Button>
              )}
            </div>
            {/* @hide until sms feature implementation
            <div>
              <label className="text-dark-blue me-2 fw-bold">
                {out("Modèle de sms", "Sms template")}:
              </label>
              <span>
                {smsTemplate
                  ? out(
                      smsTemplate.translations[1]?.name ??
                        smsTemplate.translations[0].name,
                      smsTemplate.translations[0]?.name ??
                        smsTemplate.translations[1].name,
                    )
                  : notification?.length > 0
                  ? out(
                      notification[0]?.sms_template?.translations[1]?.name ??
                        notification[0]?.sms_template?.translations[0].name,
                      notification[0]?.sms_template?.translations[0]?.name ??
                        notification[0]?.sms_template?.translations[1].name,
                    )
                  : "N/A"}
              </span>
              <span className="text-muted me-2">
                <i>
                  {out(
                    template.sms_template_id &&
                      !smsTemplate?.translations[1]?.name
                      ? " (aucun titre disponible en français)"
                      : "",
                    template.sms_template_id &&
                      !smsTemplate?.translations[0]?.name
                      ? " (no english title available)"
                      : "",
                  )}
                </i>
              </span>
              {template.sms_template_id && smsTemplate && (
                <Button
                  variant="secondary"
                  size="sm"
                  className="btn-frameless-icon text-secondary d-inline-flex"
                  type="button"
                  onClick={() => {
                    setCurrentTemplate(smsTemplate);
                    setViewTemplate(true);
                  }}
                >
                  {viewTemplate ? (
                    <AiFillEye className="fs-5" />
                  ) : (
                    <AiOutlineEye className="fs-5" />
                  )}
                </Button>
              )}
            </div> */}
          </div>
          <div
            className={`${styles.documentsListHeader} fs-large px-0 pt-3 mx-2 mb-2`}
          >
            <label className="text-secondary-100 fw-bold pb-1">
              {out("Liste des requêtes", "Request list")}
            </label>
          </div>
          {template.read_request_files.length < 1 &&
            template.send_request_template_documents.length < 1 && (
              <div className="px-2 mt-2">
                {!isPreview ? (
                  <AtlasAlert>
                    {out(
                      "Aucune requête de documents pour le moment",
                      "No documents request at the moment",
                    )}
                  </AtlasAlert>
                ) : (
                  <AtlasAlert variant="danger">
                    {out(
                      "Vous devez ajouter au moins un document avant d'enregistrer le modèle de requête de document",
                      "You must add a minimum of one document before saving the document request template",
                    )}
                  </AtlasAlert>
                )}
              </div>
            )}
          {(template.read_request_files.length > 0 ||
            template.send_request_template_documents.length > 0) && (
            <div className="px-3">
              <Table className="">
                <thead>
                  <tr className={`border-0`}>
                    <th className="col-10 border-0">
                      <label className="text-secondary-100 fw-bold">
                        {out("Titre du document", "Document title")}
                      </label>
                    </th>
                    <th className="col-2 border-0">
                      <label className="text-secondary-100 fw-bold">
                        {out("Type de requête", "Request type")}
                      </label>
                    </th>
                  </tr>
                </thead>
                <tbody className={`${styles.documentsList}`}>
                  {template.read_request_files.length > 0 &&
                    template.read_request_files.map((f) => (
                      <tr key={f.id}>
                        <td>
                          <div>
                            {out(
                              f.translations.fr?.title ??
                                f.translations.en?.title,
                              f.translations.en?.title ??
                                f.translations.fr?.title,
                            )}
                            <span className="text-muted ms-2">
                              <i>
                                {out(
                                  !f.translations.fr?.title
                                    ? " (aucun titre disponible en français)"
                                    : "",
                                  !f.translations.en?.title
                                    ? " (no english title available)"
                                    : "",
                                )}
                              </i>
                            </span>
                          </div>
                        </td>
                        <td>
                          <div>
                            <span>{out("Lecture", "Read")}</span>
                          </div>
                        </td>
                        <td>
                          <OverlayTrigger
                            placement="top"
                            overlay={
                              <Tooltip>
                                {out("Visionner ce fichier", "View this file")}
                              </Tooltip>
                            }
                          >
                            <Button
                              variant="secondary"
                              size="sm"
                              className="btn-frameless-icon text-secondary d-inline-flex py-0"
                              type="button"
                              onClick={() => {
                                setPreviewDocument(f);
                                setShowDocumentPreview(true);
                              }}
                            >
                              {previewDocument === f ? (
                                <AiFillEye className="fs-5" />
                              ) : (
                                <AiOutlineEye className="fs-5" />
                              )}
                            </Button>
                          </OverlayTrigger>
                        </td>
                      </tr>
                    ))}
                  {template.send_request_template_documents.length > 0 &&
                    template.send_request_template_documents.map((f) => (
                      <tr key={f.id}>
                        <td>
                          <div>
                            {out(
                              f.translations.fr?.title ??
                                f.translations.en?.title,
                              f.translations.en?.title ??
                                f.translations.fr?.title,
                            )}
                            <span className="text-muted ms-2">
                              <i>
                                {out(
                                  !f.translations.fr?.title
                                    ? " (aucun titre disponible en français)"
                                    : "",
                                  !f.translations.en?.title
                                    ? " (no english title available)"
                                    : "",
                                )}
                              </i>
                            </span>
                          </div>
                        </td>
                        {/* span onto the adjacent field where the preview button would otherwise be */}
                        <td colSpan={2}>
                          <div>
                            <span>{out("Téléversement", "Upload")}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>
          )}
          <div
            className={`${styles.documentsListHeader} fs-large px-0 pt-3 mx-2 mb-2`}
          >
            <label className="text-secondary-100 fw-bold pb-1">
              {out("Permissions & accès", "Authorization & access")}
            </label>
          </div>
          <div className="px-3">
            <Table className="">
              <thead>
                <tr className={`border-0`}>
                  <th className="col-10 border-0">
                    <label className="text-secondary-100 fw-bold">
                      {out("Autorisations par rôle", "Permissions by role")}
                    </label>
                  </th>
                  <th className="col-2 border-0">
                    <div className="d-flex justify-content-end">
                      <div className={`text-center ${styles.wContent}`}>
                        <label className="text-secondary-100 fw-bold fs-7">
                          {out("Accès à la liste", "List access")}
                        </label>
                        <br />
                        <label className="text-secondary-100 fw-bold fs-7">
                          {out("Lecture / Écriture", "Read only / Update")}
                        </label>
                      </div>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className={`${styles.documentsList}`}>
                {selectedRolesList.length > 0 &&
                  selectedRolesList.map((r) => (
                    <tr key={r.id}>
                      <td>
                        <div>
                          {out(
                            r.translation.fr?.name ?? r.translation.en?.name,
                            r.translation.en?.name ?? r.translation.fr?.name,
                          )}
                          <span className="text-muted ms-2">
                            <i>
                              {out(
                                !r.translation.fr?.name
                                  ? " (aucun nom de rôle disponible en français)"
                                  : "",
                                !r.translation.en?.name
                                  ? " (no english role name available)"
                                  : "",
                              )}
                            </i>
                          </span>
                        </div>
                      </td>
                      <td className="align-middle">
                        <AccessCheckboxes
                          access={template.roles?.find(
                            (role) => +role.id === r.id,
                          )}
                        />
                      </td>
                    </tr>
                  ))}
              </tbody>
            </Table>
            <Table className="">
              <thead>
                <tr className={`border-0`}>
                  <th className="col-10 border-0">
                    <label className="text-secondary-100 fw-bold">
                      {out("Autorisations par membre", "Permissions by member")}
                    </label>
                  </th>
                  <th className="col-10 border-0">
                    <label className="text-secondary-100 fw-bold">
                      {out("Rôle", "Role")}
                    </label>
                  </th>
                  <th className="col-2 border-0">
                    <div className="d-flex justify-content-end">
                      <div className={`text-center ${styles.wContent}`}>
                        <label className="text-secondary-100 fw-bold fs-7">
                          {out("Accès à la liste", "List access")}
                        </label>
                        <br />
                        <label
                          className={`text-secondary-100 fw-bold fs-7 ${styles.wMaxContent}`}
                        >
                          {out("Lecture / Écriture", "Read only / Update")}
                        </label>
                      </div>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className={`${styles.documentsList}`}>
                {selectedUsersList.length > 0 &&
                  selectedUsersList.map((u) =>
                    u?.user ? (
                      <tr key={u.id}>
                        {u && (
                          <td className="align-middle">{`${u.user.first_name} ${u.user.last_name}`}</td>
                        )}
                        {selectedRolesList.map((r) => {
                          return (
                            +r.id === +u.role_id && (
                              <td key={r.id} className="align-middle">
                                {out(
                                  r.translation.fr.name,
                                  r.translation.en.name,
                                )}
                              </td>
                            )
                          );
                        })}
                        <td className="align-middle">
                          <AccessCheckboxes
                            access={template.users?.find(
                              (user) => +user.id === u.user_id,
                            )}
                          />
                        </td>
                      </tr>
                    ) : null,
                  )}
              </tbody>
            </Table>
          </div>
        </div>
      )}
      {viewTemplate && currentTemplate && (
        <DocumentViewModal
          show={true}
          setModalOpen={(e) => {
            setCurrentTemplate(null);
            setViewTemplate(e);
          }}
          template={currentTemplate}
        />
      )}
      {!!previewDocument && (
        <DocumentPreviewModal
          show={!!previewDocument && showDocumentPreview}
          hide={() => {
            setShowDocumentPreview(false);
            setPreviewDocument(null);
          }}
          document={previewDocument}
        />
      )}
    </>
  );
};

export default DocuTransferTemplateView;
