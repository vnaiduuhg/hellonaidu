import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import { useSelector } from "react-redux";
import { sanitize } from "dompurify";
import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import cx from "classnames";

const DocumentViewModal = ({ show, setModalOpen, template }) => {
  const { out } = useTranslation();
  const language = useSelector((state) => state.user.language);
  const [switchTemplateLanguage, setSwitchTemplateLanguage] =
    useState(language);

  return (
    <Modal
      size="lg"
      show={show}
      onHide={() => {
        setModalOpen(false);
      }}
    >
      <Modal.Header closeButton className="">
        <Modal.Title className="text-center w-100 mt-3">
          {out("Vue du modèle", "Template view")}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <>
          {template && (
            <div>
              <div className="text-dark-blue fs-6 mb-3">
                <h5 className="mb-0">
                  {out(
                    template.translations[1].name,
                    template.translations[0].name,
                  )}
                  <span className="text-muted me-2">
                    {out(
                      !template.translations[1]?.name
                        ? " (aucun titre disponible en français)"
                        : "",
                      !template.translations[0]?.name
                        ? " (no english title available)"
                        : "",
                    )}
                  </span>
                </h5>
                <div className="d-flex">
                  <h6 className="d-flex align-items-center m-0">
                    {out(
                      template.translations[0]?.name
                        ? template.translations[0].name
                        : "",
                      template.translations[1]?.name
                        ? template.translations[1].name
                        : "",
                    )}
                  </h6>
                  <label className="d-flex align-items-center ms-2">
                    <i>
                      {out(
                        template.translations[0]?.name
                          ? "(titre anglais)"
                          : "(Aucun title disponible en anglais)",
                        template.translations[1]?.name
                          ? "(french title)"
                          : "(No french title available)",
                      )}
                    </i>
                    &nbsp;
                  </label>
                </div>
              </div>
              <div className="d-flex justify-content-end mt-3 mb-1">
                <div
                  className="btn-group"
                  role="group"
                  aria-label="Secondary group"
                >
                  <Button
                    type="button"
                    variant="outline-secondary"
                    className={cx(`btn-sm`, {
                      active: switchTemplateLanguage === "fr",
                    })}
                    onClick={() => setSwitchTemplateLanguage("fr")}
                  >
                    FR
                  </Button>
                  <Button
                    type="button"
                    variant="outline-secondary"
                    className={cx(`btn-sm`, {
                      active: switchTemplateLanguage === "en",
                    })}
                    onClick={() => setSwitchTemplateLanguage("en")}
                  >
                    EN
                  </Button>
                </div>
              </div>
              <div className="border border-1 rounded p-3">
                <div>
                  <label className="text-dark-blue me-2">
                    <b>
                      {switchTemplateLanguage === "fr" ? "Sujet" : "Subject"}
                    </b>
                    :
                  </label>
                  {switchTemplateLanguage === "fr"
                    ? template.translations[1].subject
                    : template.translations[0].subject}
                </div>
                <hr />
                <div
                  dangerouslySetInnerHTML={{
                    __html: sanitize(
                      switchTemplateLanguage === "fr"
                        ? template.translations[1].body
                        : template.translations[0].body,
                    ),
                  }}
                />
              </div>
            </div>
          )}
          {!template && (
            <div>
              <AtlasAlert variant="warning">
                <p className="ms-3 mb-0">
                  {out(
                    "Le modèle de courriel par défaut n'a pu être récupéré. Veuillez réessayer ou consulter la page des messages automatisés.",
                    "The email template could not be retrieved. Please try again or consult automated messages page.",
                  )}
                </p>
              </AtlasAlert>
            </div>
          )}
        </>
      </Modal.Body>
      <Modal.Footer>
        <div className="d-flex justify-content-end p-3">
          <Button
            type="submit"
            variant="alt-secondary"
            onClick={() => setModalOpen(false)}
          >
            {out("Fermer", "Close")}
          </Button>
        </div>
      </Modal.Footer>
    </Modal>
  );
};

export default DocumentViewModal;
