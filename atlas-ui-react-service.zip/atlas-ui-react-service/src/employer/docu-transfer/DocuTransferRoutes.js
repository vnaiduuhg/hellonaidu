import React from "react";
import { Route, Switch } from "react-router-dom";
import DocuTransfer from "./pages/DocuTransfer";

const DocuTransferRoutes = () => (
  <Switch>
    <Route path="/docu-secur" exact={true}>
      <DocuTransfer />
    </Route>
  </Switch>
);

export default DocuTransferRoutes;
