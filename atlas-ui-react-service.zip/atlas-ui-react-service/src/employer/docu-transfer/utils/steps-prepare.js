import { languages, requestTypes } from "../assets/translations/translations";

export const prepareInformationStep = (templateData, setValue, out) => {
  setValue(`isDraft`, templateData.is_draft);

  // information prepare
  if (templateData.translations) {
    const translationsSelected = [];
    const languagesSelected = [];
    for (const key in templateData.translations) {
      const selectedLanguage = languages.find((l) => l.value === key);
      languagesSelected.push({
        value: selectedLanguage.value,
        label: out(
          selectedLanguage.translations.fr,
          selectedLanguage.translations.en,
        ),
      });

      translationsSelected[key] = {
        title: templateData.translations[key].title,
        description: templateData.translations[key].description,
      };
    }

    setValue(`informations.languages`, languagesSelected);
    setValue(`informations.translations`, translationsSelected);
  }
};

export const prepareSendRequestStep = (templateData, setValue, out) => {
  // send request prepare
  const filesSelected = [];
  if (templateData.read_request_files.length > 0) {
    const requestType = requestTypes.find((type) => type.value === "read");
    templateData.read_request_files.forEach((document) => {
      const file = {
        requestType: {
          value: requestType.value,
          label: out(requestType.translations.fr, requestType.translations.en),
        },
        documentType: document.type_id,
        documentId: document.id,
        documentFileName: document.file_name,
        translations: {},
      };

      for (const key in document.translations) {
        file.translations[key] = {};
        file.translations[key].documentTitle = document.translations[key].title;
        file.translations[key].documentText =
          document.translations[key].description;
      }
      filesSelected.push(file);
    });
    setValue(`sendRequest`, filesSelected);
  }
};

export const prepareReceiveRequestStep = (
  templateData,
  documentTypes,
  setValue,
) => {
  const documentsList = [];
  const originalType = (type) => {
    return {
      originalType: type,
      documentTypeId: type.id,
      requiredNumber: 0,
      isOptional: 1,
      translations: {
        fr: {
          title: type.name_fr,
        },
        en: {
          title: type.name,
        },
      },
      customTranslations: {
        fr: {
          title: "",
        },
        en: {
          title: "",
        },
      },
      typeIndex: 0,
      numberOfDocumentType: 0,
    };
  };

  // receive request prepare
  if (templateData.send_request_template_documents.length > 0) {
    const documentsTypesArray = [];
    documentTypes.forEach((type) => {
      const typeSelected = templateData.send_request_template_documents.filter(
        (doc) => +doc.document_type_id === +type.id,
      );
      if (typeSelected.length > 0) {
        typeSelected.forEach((t, i) => {
          const singleDocumentRequest = {
            originalType: type,
            documentTypeId: t.document_type_id,
            documentId: t.id,
            requiredNumber: t.required_number,
            isOptional: t.is_optional,
            translations: {
              fr: {
                title: type.name_fr,
              },
              en: {
                title: type.name,
              },
            },
            customTranslations: {},
            typeIndex: i,
            numberOfDocumentType: typeSelected.length,
          };

          for (const key in t.translations) {
            singleDocumentRequest.customTranslations[key] = {};
            singleDocumentRequest.customTranslations[key].title =
              t.translations[key].title;
          }
          documentsTypesArray.push(singleDocumentRequest);
          documentsList.push({
            value: singleDocumentRequest.documentId,
            translations: {
              fr:
                singleDocumentRequest.customTranslations.fr?.title ??
                singleDocumentRequest.customTranslations.en.title +
                  " (aucun titre disponible en français)",
              en:
                singleDocumentRequest.customTranslations.en?.title ??
                singleDocumentRequest.customTranslations.fr.title +
                  " (no english title available)",
            },
          });
        });
      } else {
        documentsTypesArray.push(originalType(type));
      }
    });
    setValue(`receiveRequest`, documentsTypesArray);
  } else {
    const documentsTypesArray = [];
    documentTypes.forEach((type) => {
      documentsTypesArray.push(originalType(type));
    });
    setValue(`receiveRequest`, documentsTypesArray);
  }
  setValue("documentsList", documentsList);
};

export const prepareMessagesStep = (
  templateData,
  emailTemplates,
  smsTemplates,
  setValue,
  out,
) => {
  // messages prepare - email
  if (templateData.email_template_id) {
    const selectedTemplate = emailTemplates.find(
      (t) => +t.id === +templateData.email_template_id,
    );
    setValue("messages.emailTemplate", {
      label: out(
        selectedTemplate.translations[1].name,
        selectedTemplate.translations[0].name,
      ),
      value: selectedTemplate.id,
    });
  }

  setValue(
    "messages.emailEnabled",
    templateData.is_email_notification_enabled ? true : false,
  );

  // messages prepare - sms
  if (templateData.sms_template_id) {
    const selectedTemplate = smsTemplates.find(
      (t) => +t.id === +templateData.sms_template_id,
    );
    setValue("messages.smsTemplate", {
      label: out(
        selectedTemplate.translations[1].name,
        selectedTemplate.translations[0].name,
      ),
      value: selectedTemplate.id,
    });
  }

  setValue(
    "messages.smsEnabled",
    templateData.is_sms_notification_enabled ? true : false,
  );
};

export const preparePermissionsStep = (
  templateData,
  roles,
  accountUsers,
  setValue,
  out,
) => {
  // permissions prepare - roles
  const rolesArray = [];
  const selectedRoles = roles.filter((r) => +r.id < 30);

  selectedRoles.forEach((r) => {
    const permission = templateData.roles.find((role) => +role.id === +r.id);

    const singleRole = {
      data: r,
      documentsSelected: [],
      roleId: r.id,
      readOnly:
        permission?.pivot && Number.isInteger(permission.pivot.has_write_access)
          ? permission.pivot.has_write_access
            ? 0
            : 1
          : false,
      readAndWrite:
        permission?.pivot && Number.isInteger(permission.pivot.has_write_access)
          ? permission.pivot.has_write_access
            ? 1
            : 0
          : false,
    };

    if (templateData.send_request_template_documents.length > 0) {
      templateData.send_request_template_documents.forEach((document) => {
        const role = document.roles.find((docRole) => +docRole.id === +r.id);

        if (role)
          singleRole.documentsSelected.push({
            value: +role.pivot.send_request_template_document_id,
            label: out(
              document.translations.fr?.title ??
                document.translations.en.title +
                  " (aucun titre disponible en français)",
              document.translations.en?.title ??
                document.translations.fr.title +
                  " (no english title available)",
            ),
          });
      });
    }
    rolesArray.push(singleRole);
  });
  setValue("permissionsRoles", rolesArray);

  // permissions prepare - users
  const usersArray = [];
  const selectedUsers = accountUsers.filter((u) => +u.role_id < 30);

  selectedUsers.forEach((u) => {
    const userPermission = templateData.users.find(
      (user) => +user.id === u.user_id,
    );

    const singleUser = {
      data: u,
      documentsSelected: [],
      userId: u.user_id,
      roleId: u.role_id,
      readOnly:
        userPermission?.pivot &&
        Number.isInteger(userPermission.pivot.has_write_access)
          ? userPermission.pivot.has_write_access
            ? 0
            : 1
          : false,
      readAndWrite:
        userPermission?.pivot &&
        Number.isInteger(userPermission.pivot.has_write_access)
          ? userPermission.pivot.has_write_access
            ? 1
            : 0
          : false,
    };

    if (templateData.send_request_template_documents.length > 0) {
      templateData.send_request_template_documents.forEach((document) => {
        const user = document.users.find((user) => +user.id === +u.user_id);

        if (user) {
          singleUser.documentsSelected.push({
            value: +user.pivot.send_request_template_document_id,
            label: out(
              document.translations.fr?.title ??
                document.translations.en.title +
                  " (aucun titre disponible en français)",
              document.translations.en?.title ??
                document.translations.fr.title +
                  " (no english title available)",
            ),
          });
        }
      });
    }
    usersArray.push(singleUser);
  });
  setValue("permissionsUsers", usersArray);
};
