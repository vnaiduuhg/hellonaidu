export const validateInformations = (data, languages) => {
  if (languages.length < 1) return false;

  let isValid = true;
  const informationsPayload = {};
  languages.forEach((l) => {
    if (!data[l.value].title || !data[l.value].description) {
      isValid = false;
    } else {
      informationsPayload[l.value] = {
        title: data[l.value].title,
        description: data[l.value].description,
        locale: l.value,
      };
    }
  });
  return isValid ? informationsPayload : false;
};

export const validateSendRequest = (data, languages, roles, users) => {
  let isValid = true;
  const payload = {
    read_request_files: [],
    read_request_file_roles: [],
    read_request_file_users: [],
  };

  const rolesFiltered = roles.reduce(
    (f, r) => ((r.readAndWrite || r.readOnly) && f.push(r.roleId), f),
    [],
  );
  const usersFiltered = users.reduce(
    (f, u) => ((u.readAndWrite || u.readOnly) && f.push(u.userId), f),
    [],
  );

  data.forEach((document) => {
    if (document.requestType.value === "read") {
      const singleDocumentrequest = {
        id: document.documentId,
        translations: {},
      };

      if (
        Object.keys(document.translations).length > 0 &&
        document.documentId
      ) {
        for (const key in document.translations) {
          if (
            document.translations[key].documentText &&
            document.translations[key].documentTitle
          ) {
            singleDocumentrequest.translations[key] = {
              title: document.translations[key].documentTitle,
              description: document.translations[key].documentText,
              locale: key,
            };
          } else {
            if (languages[key]) isValid = false;
          }
        }
        payload.read_request_files.push(singleDocumentrequest);
        payload.read_request_file_roles.push({
          read_request_file_id: document.documentId,
          role_ids: rolesFiltered,
        });
        payload.read_request_file_users.push({
          read_request_file_id: document.documentId,
          user_ids: usersFiltered,
        });
      }
    }
  });

  return isValid ? payload : false;
};

export const validateReceiveRequest = (data) => {
  const receiveRequestPayload = [];
  const arrayOfDocuments = data.filter(
    (document) => document.requiredNumber > 0,
  );

  arrayOfDocuments.forEach((document) => {
    const singleDocumentRequest = {
      document_type_id: document.documentTypeId,
      required_number: document.requiredNumber,
      is_optional: document.isOptional,
      translations: {},
    };
    if (document.documentId) singleDocumentRequest.id = document.documentId;

    for (const key in document.translations) {
      singleDocumentRequest.translations[key] = {
        title: document.translations[key].title,
        locale: key,
      };
    }

    receiveRequestPayload.push(singleDocumentRequest);
  });

  return receiveRequestPayload;
};

export const validateMessages = (data) => {
  return {
    email_template_id: data.emailTemplate?.value ?? null,
    is_email_notification_enabled: data.emailTemplate
      ? data.emailEnabled
        ? 1
        : 0
      : 0,
    sms_template_id: data.smsTemplate?.value ?? null,
    is_sms_notification_enabled: data.smsTemplate
      ? data.smsEnabled
        ? 1
        : 0
      : 0,
  };
};

const validateReadRequestFiles = (users, roles, readFilesList) => {
  const payload = {
    read_request_file_roles: [],
    read_request_file_users: [],
  };

  const rolesFiltered = roles.reduce(
    (f, r) => ((r.readAndWrite || r.readOnly) && f.push(r.roleId), f),
    [],
  );
  const usersFiltered = users.reduce(
    (f, u) => ((u.readAndWrite || u.readOnly) && f.push(u.userId), f),
    [],
  );

  readFilesList.forEach((file) => {
    if (file.requestType.value === "read") {
      payload.read_request_file_roles.push({
        read_request_file_id: file.documentId,
        role_ids: rolesFiltered,
      });
      payload.read_request_file_users.push({
        read_request_file_id: file.documentId,
        user_ids: usersFiltered,
      });
    }
  });

  return payload;
};

export const validatePermissions = (
  roles,
  users,
  documentsList,
  readFilesList,
) => {
  const payload = {
    document_request_template_roles: [],
    document_request_template_users: [],
    send_request_template_document_roles: [],
    send_request_template_document_users: [],
  };

  documentsList.forEach((document) => {
    payload.send_request_template_document_roles.push({
      send_request_template_document_id: +document.value,
      role_ids: [],
    });
    payload.send_request_template_document_users.push({
      send_request_template_document_id: +document.value,
      user_ids: [],
    });
  });

  roles.forEach((r) => {
    if (r.readAndWrite || r.readOnly) {
      payload.document_request_template_roles.push({
        role_id: r.roleId,
        has_write_access: r.readAndWrite ? 1 : 0,
      });
    }

    if (r.documentsSelected.length > 0) {
      r.documentsSelected.forEach((d) => {
        const documentRolesIndex =
          payload.send_request_template_document_roles.findIndex(
            (r) => +r.send_request_template_document_id === +d.value,
          );
        if (documentRolesIndex > -1) {
          payload.send_request_template_document_roles[
            documentRolesIndex
          ].role_ids.push(r.roleId);
        }
      });
    }
  });

  users.forEach((u) => {
    if (u.readAndWrite || u.readOnly) {
      payload.document_request_template_users.push({
        user_id: u.userId,
        has_write_access: u.readAndWrite ? 1 : 0,
      });
    }

    if (u.documentsSelected.length > 0) {
      u.documentsSelected.forEach((d) => {
        const documentUsersIndex =
          payload.send_request_template_document_users.findIndex(
            (user) => +user.send_request_template_document_id === +d.value,
          );
        if (documentUsersIndex > -1) {
          payload.send_request_template_document_users[
            documentUsersIndex
          ].user_ids.push(u.userId);
        }
      });
    }
  });

  const readRequestFilesPayload = validateReadRequestFiles(
    users,
    roles,
    readFilesList,
  );
  payload.read_request_file_roles =
    readRequestFilesPayload.read_request_file_roles;
  payload.read_request_file_users =
    readRequestFilesPayload.read_request_file_users;

  return payload;
};
