import { out } from "global/utils/useTranslation";
import { error401 } from "global/utils/_commonApiStatusMessages";

export const documentsRequestTemplatePostMsgHandler = (code, step, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        `L'étape ${step.translations.fr} a été sauvegardée`,
        `${step.translations.en} step has been saved`,
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour créer un modèle de requête de documents",
        "You do not have the required permission to create a documents request template",
      );
      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      msg.text = out(
        "Veuillez vous assurer que tous les champs requis sont remplis",
        "Please make sure that all reqired fields are filled",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text =
        step.name !== "preview"
          ? out(
              `L'étape ${step.translations.fr} n'a pu être sauvegardée`,
              `${step.translations.en} step could not be saved`,
            )
          : out(
              "Le modèle de requête de documents n'a pu être sauvegardé",
              "Documents request template could not be saved",
            );
  }

  return msg;
};

export const documentsRequestTemplatePutMsgHandler = (code, step, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        `L'étape ${step.translations.fr} a été sauvegardée`,
        `${step.translations.en} step has been saved`,
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour modifier un modèle de requête de documents",
        "You do not have the required permission to modify a documents request template",
      );
      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      msg.text = out(
        `Veuillez vous assurer que tous les champs requis sont remplis à l'étape ${step.translations.fr}`,
        `Please make sure that all reqired fields are filled at step ${step.translations.en}`,
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        `L'étape ${step.translations.fr} n'a pu être sauvergardé`,
        `${step.translations.en} step could not be saved`,
      );
  }

  return msg;
};

export const documentsRequestTemplatePatchMsgHandler = (code, error, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        `Le modèle de requête de documents a été publié`,
        `The documents request template has been published`,
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour publier un modèle de requête de documents",
        "You do not have the required permission to publish a documents request template",
      );
      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      if (error?.read_request_files || error?.send_request_template_documents) {
        msg.text = out(
          "Le modèle de demande de documents doit contenir au moins 1 document",
          "The documents request template must contain at least one document",
        );
      } else {
        msg.text = out(
          "Veuillez réviser le modèle de demande de documents et vous assurer que tous les champs requis sont remplis",
          "Please revise the documents request template and make sure that all reqired fields are filled",
        );
      }
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le modèle de requête de documents n'a pu être publié",
        "the documents request template could not be published",
      );
  }

  return msg;
};

export const deleteDocumentRequestTemplateMsgHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        `Le modèle de requête de documents a été supprimé`,
        `Documents request template has been deleted`,
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer ce modèle de requête de documents",
        "You do not have the required permission to delete this documents request template",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le modèle de requête de documents n'a pu être supprimé, veuillez réessayer",
        "The documents request template could not be deleted, please try again",
      );
  }

  return msg;
};

export const sendDocumentUploadFileMsgHandler = (
  code,
  response = null,
  login,
) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        `Le document a été sauvegardé`,
        `The document has been saved`,
      );
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour téléverser un document pour ce modèle de requête de documents",
        "You do not have the required permission to upload a document for this documents request template",
      );
      break;
    case 422:
      msg.title = out("Attention!", "Attention!");
      if (response?.data?.file) {
        msg.text = out(
          "Le fichier téléversé est invalide",
          "The file uploaded is invalid",
        );
      } else {
        msg.text = out(
          "Veuillez vérifier le fichier et vous assurer que tous les champs requis sont remplis",
          "Please vérify your file and make sure that all required fields are filled",
        );
      }
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Ce document n'a pu être sauvergardé, veuillez réessayer",
        "This document could not be saved, please try again",
      );
  }

  return msg;
};

export const sendDocumentDeleteFileMsgHandler = (code, login) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 204:
      msg.title = out("Succès!", "Success!");
      msg.text = out(`Le document a été supprimé`, `Document has been deleted`);
      break;
    case 401:
      setTimeout(login, 2200);
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour supprimer ce document",
        "You do not have the required permission to delete this document",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le document n'a pu être supprimé, veuillez réessayer",
        "The document could not be deleted, please try again",
      );
  }

  return msg;
};
