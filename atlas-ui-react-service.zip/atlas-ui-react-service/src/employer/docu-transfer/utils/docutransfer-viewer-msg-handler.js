import { out } from "global/utils/useTranslation";
import { error401 } from "global/utils/_commonApiStatusMessages";

export const docuTransferGetDocumentMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg.title = out(error401.title.fr, error401.title.en);
      msg.text = out(error401.message.fr, error401.message.en);
      break;
    case 404:
      msg.title = out("Document non trouvé!", "Document not found!");
      msg.text = out(
        "Le document est introuvable",
        "The document cannot be found",
      );
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour consulter ce document",
        "You do not have the required permission to view this document",
      );
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le document n'a pas pu être chargé. Veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.",
        "Document could not be loaded. Please try again or contact support@workland.com for assistance.",
      );
  }

  return msg;
};
