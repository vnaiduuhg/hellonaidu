import React, { useState } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import { useAccountUsers } from "global/hooks/useAccountUsers";
import {
  getDocumentsRequestTemplates,
  getDocumentTypes,
} from "global/apis/ToolkitApi";
import { getRoles } from "global/apis/authorizationApi";
import { getEventNotificationsByEvent } from "global/apis/messagingApi";
import { authLevelApiOptions } from "global/apis/utils/authLevelApiOptions";
import { useTranslation } from "global/utils/useTranslation";
import {
  createListBtnLabel,
  viewListBtnLabel,
} from "../assets/translations/translations";
import { PageLoader } from "global/components/loaders/page-loader";
import PageHeaderPanel from "global/components/page-header-panel/PageHeaderPanel";
import DocuTransferSettings from "./DocuTransferSettings";
import DocuTransferList from "./DocuTransferList";
import cx from "classnames";
import Tooltip from "@material-ui/core/Tooltip";
import styles from "../styles/DocuTransfer.module.scss";
import { FaAngleDoubleLeft } from "react-icons/fa";
import { FaPlus } from "react-icons/fa";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";

const DocuTransfer = () => {
  const { out } = useTranslation();
  const user = useSelector((state) => state.user.data);
  const language = useSelector((state) => state.user.language);
  const [activeTab, setActiveTab] = useState("docuList");
  const [btnLabel, setBtnLabel] = useState(createListBtnLabel);
  const [docuRequestTemplateId, setDocuRequestTemplateId] = useState(null);
  const [settingsMode, setSettingsMode] = useState("create");
  const [templateData, setTemplateData] = useState(null);

  // gets documents request templates list
  const {
    data: documentsRequestTemplates = [],
    isLoading: documentsRequestTemplatesIsLoading,
    isFetched: documentsRequestTemplatesIsFetched,
    isError: documentsRequestTemplatesIsError,
  } = useQuery(
    "document-request-templates",
    () => getDocumentsRequestTemplates(),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onSuccess: (response) => {
        if (docuRequestTemplateId && response.length > 0) {
          const updatedTemplate = response.find(
            (template) => +template.id === +docuRequestTemplateId,
          );
          if (updatedTemplate) setTemplateData(updatedTemplate);
        }
      },
    },
  );

  // gets document types
  const {
    data: documentTypes = [],
    isLoading: documentTypesIsLoading,
    isFetched: documentTypesIsFetched,
    isError: documentTypesIsError,
  } = useQuery("document-types", () => getDocumentTypes(), {
    ...REACT_QUERY_GETTER_OPTIONS,
    onSuccess: () => {},
  });

  // gets email templates list
  const {
    data: emailTemplates,
    isLoading: emailTemplatesIsLoading,
    isFetched: emailTemplatesIsFetched,
    isError: emailTemplateIsError,
  } = useQuery(
    "email-templates",
    () =>
      authLevelApiOptions.account.emailTemplateApi({
        locale: language,
        sort: "name",
        withDefaults: true,
      }),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onSuccess: () => {},
    },
  );

  // gets sms templates list
  const {
    data: smsTemplates,
    isLoading: smsTemplatesIsLoading,
    isFetched: smsTemplatesIsFetched,
    isError: smsTemplateIsError,
  } = useQuery(
    "sms-templates",
    () =>
      authLevelApiOptions.account.smsTemplateApi({
        locale: language,
        sort: "name",
        withDefaults: true,
      }),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onSuccess: () => {},
    },
  );

  // gets sms & emails templates categories list
  const {
    data: templateCategories,
    isLoading: templateCategoriesIsLoading,
    isFetched: templateCategoriesIsFetched,
    isError: templateCategorieIsError,
  } = useQuery(
    "template-categories",
    () => authLevelApiOptions.account.categoryApi(),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onSuccess: () => {},
    },
  );

  // gets roles
  const {
    data: roles = [],
    isLoading: rolesIsLoading,
    isFetched: rolesIsFetched,
    isError: rolesIsError,
  } = useQuery("roles", () => getRoles(), {
    ...REACT_QUERY_GETTER_OPTIONS,
    onSuccess: () => {},
  });

  // gets event-notification by event
  const {
    data: notification,
    isLoading: notificationIsLoading,
    isFetched: notificationIsFetched,
    isError: notificationIsError,
  } = useQuery(
    "notification-by-event",
    () =>
      getEventNotificationsByEvent(
        user.user_account.account_id,
        "send-document-request",
      ),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onSuccess: () => {},
    },
  );

  // fill users-accounts member on store
  const {
    isLoading: accountUserIsLoading,
    isFetched: accountUserIsFetched,
    isError: accountUserIsError,
  } = useAccountUsers(user.id);

  // toggles between tabs
  const toggleDocuTab = () => {
    setBtnLabel(
      activeTab !== "docuList" ? createListBtnLabel : viewListBtnLabel,
    );
    setDocuRequestTemplateId(null);
    setTemplateData(null);
    setSettingsMode("create");
    setActiveTab(activeTab !== "docuList" ? "docuList" : "docuSettings");
  };

  const toggleBtn = (
    <button
      className={cx("btn btn-md", {
        "btn-tertiary": activeTab !== "docuList",
        "btn-secondary": activeTab === "docuList",
      })}
      onClick={toggleDocuTab}
    >
      {activeTab !== "docuList" ? <FaAngleDoubleLeft /> : <FaPlus />}
    </button>
  );

  const editDocumentRequestTemplate = (template) => {
    if (template && template.id) {
      setDocuRequestTemplateId(template.id);
      setSettingsMode("update");
      setActiveTab("docuSettings");
      setBtnLabel(viewListBtnLabel);
      setTemplateData(template);
    }
  };

  return (
    <div className={styles.docuTransfer}>
      <div>
        <PageHeaderPanel
          title={out("DocuSecur", "DocuSecur")}
          iconClass="fa-solid fa-file-shield"
        >
          <div className="d-flex d-md-none">
            <Tooltip
              placement="left"
              title={
                <h5 className="my-0 p-1 pt-2 fs-6 text-center">
                  {out(btnLabel.fr, btnLabel.en)}
                </h5>
              }
            >
              {toggleBtn}
            </Tooltip>
          </div>
          <div className="d-none d-md-flex align-items-center">
            <label className="me-2 fs-5">{out(btnLabel.fr, btnLabel.en)}</label>
            {toggleBtn}
          </div>
        </PageHeaderPanel>
        {documentsRequestTemplatesIsFetched &&
          documentTypesIsFetched &&
          emailTemplatesIsFetched &&
          templateCategoriesIsFetched &&
          smsTemplatesIsFetched &&
          rolesIsFetched &&
          accountUserIsFetched &&
          notificationIsFetched &&
          (activeTab !== "docuList" ? (
            <DocuTransferSettings
              settingsMode={settingsMode}
              setSettingsMode={setSettingsMode}
              templateData={templateData}
              docuRequestTemplateId={docuRequestTemplateId}
              setDocuRequestTemplateId={setDocuRequestTemplateId}
              documentTypes={documentTypes.message}
              documentTypesIsError={documentTypesIsError}
              emailTemplates={emailTemplates}
              emailTemplateIsError={emailTemplateIsError}
              smsTemplates={smsTemplates}
              smsTemplateIsError={smsTemplateIsError}
              templateCategories={templateCategories}
              templateCategorieIsError={templateCategorieIsError}
              roles={roles}
              rolesIsError={rolesIsError}
              accountUserIsError={accountUserIsError}
              notification={notification}
              notificationIsError={notificationIsError}
            />
          ) : (
            <DocuTransferList
              documentsRequestTemplates={documentsRequestTemplates}
              documentsRequestTemplatesIsError={
                documentsRequestTemplatesIsError
              }
              dataRetrievedError={
                emailTemplateIsError ||
                smsTemplateIsError ||
                rolesIsError ||
                accountUserIsError
              }
              editDocumentRequestTemplate={editDocumentRequestTemplate}
              emailTemplates={emailTemplates}
              smsTemplates={smsTemplates}
              roles={roles}
              notification={notification}
            />
          ))}
        {(documentsRequestTemplatesIsLoading ||
          documentTypesIsLoading ||
          emailTemplatesIsLoading ||
          templateCategoriesIsLoading ||
          smsTemplatesIsLoading ||
          rolesIsLoading ||
          accountUserIsLoading ||
          notificationIsLoading) && (
          <div>
            <PageLoader
              message={out(
                "Chargement des demandes de documents...",
                "Loading Document requests...",
              )}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default DocuTransfer;
