import React, { useState, useEffect } from "react";
import { useQueryClient, useMutation } from "react-query";
import { batch, useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { useForm, useFieldArray } from "react-hook-form";
import { Form, Button } from "react-bootstrap";
import {
  createDocumentsRequestApi,
  updateDocumentsRequestApi,
  publishDocumentRequestTemplateApi,
} from "../apis/DocumentsRequestApi";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import {
  validateInformations,
  validateSendRequest,
  validateReceiveRequest,
  validateMessages,
  validatePermissions,
} from "../utils/steps-validation";
import {
  prepareInformationStep,
  prepareSendRequestStep,
  prepareReceiveRequestStep,
  prepareMessagesStep,
  preparePermissionsStep,
} from "../utils/steps-prepare";
import {
  documentsRequestTemplatePostMsgHandler,
  documentsRequestTemplatePutMsgHandler,
  documentsRequestTemplatePatchMsgHandler,
} from "../utils/steps-msg-handler";
import HorizontalStepsNavbar from "../../../global/components/Navigation/horizontal-steps-navbar/HorizontalStepsNavbar";
import Informations from "../components/steps/Informations";
import ReceiveRequest from "../components/steps/ReceiveRequest";
import SendRequest from "../components/steps/SendRequest";
import Messages from "../components/steps/Messages";
import Permissions from "../components/steps/Permissions";
import Preview from "../components/steps/Preview";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { steps, languages } from "../assets/translations/translations";
import { useTranslation } from "global/utils/useTranslation";
import Tooltip from "@material-ui/core/Tooltip";
import { AiFillInfoCircle } from "react-icons/ai";
import styles from "../styles/DocuTransfer.module.scss";
import cx from "classnames";

const DocuTransferSettings = ({
  settingsMode,
  setSettingsMode,
  templateData,
  docuRequestTemplateId,
  setDocuRequestTemplateId,
  documentTypes,
  documentTypesIsError,
  emailTemplates,
  emailTemplateIsError,
  smsTemplates,
  smsTemplateIsError,
  templateCategories,
  templateCategorieIsError,
  roles,
  rolesIsError,
  accountUserIsError,
  notification,
  notificationIsError,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const queryClient = useQueryClient();
  const accountUsers = useSelector((state) => state.user.accountUser);
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [activeTab, setActiveTab] = useState(steps[0]);
  const [lastStepCompleted, setLastStepCompleted] = useState(-1);
  const [documentIdsMissing, setDocumentIdsMissing] = useState([]);
  const [preparingUpdateData, setPreparingUpdateData] = useState(false);
  const [selectedRolesList, setSelectedRolesList] = useState(null);
  const [selectedUsersList, setSelectedUsersList] = useState(null);
  const [saveIsDisabled, setSaveIsDisabled] = useState(false);
  const [processingData, setProcessingData] = useState(false);
  const [goNextPage, setGoNextPage] = useState(false);
  const [dirtySteps, setDirtySteps] = useState([]);
  const [templateIsPublished, setTemplateIsPublished] = useState(false);
  const [showIsDraftWarning, setShowIsDraftWarning] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors, isDirty, dirtyFields },
    setValue,
    getValues,
    trigger,
    watch,
    reset,
  } = useForm({
    defaultValues: {
      informations: {
        languages: [],
        translations: {
          fr: {
            title: "",
            description: "",
          },
          en: {
            title: "",
            description: "",
          },
        },
      },
      sendRequest: [],
      receiveRequest: [],
      documentsList: [],
      messages: {
        emailTemplate: null,
        smsTemplate: null,
        categoryIds: [],
      },
      permissions: {
        templateUsers: [],
        templateRoles: [],
        templateDocumentUsers: [],
        templateDocumentRoles: [],
      },
      permissionsRoles: [],
      permissionsUsers: [],
      preview: {
        isDraft: 1,
      },
    },
    mode: "onChange",
  });

  const {
    fields: sendRequestFields,
    append: sendRequestAppend,
    remove: sendRequestRemove,
  } = useFieldArray({
    control,
    name: "sendRequest",
  });

  const {
    fields: receiveRequestFields,
    append: receiveRequestAppend,
    remove: receiveRequestRemove,
    insert: receiveRequestInsert,
  } = useFieldArray({
    control,
    name: "receiveRequest",
  });

  const { fields: permissionsRolesFields, append: permissionsRolesAppend } =
    useFieldArray({
      control,
      name: "permissionsRoles",
    });

  const { fields: permissionsUsersFields, append: permissionsUsersAppend } =
    useFieldArray({
      control,
      name: "permissionsUsers",
    });

  useEffect(() => {
    const selectedRoles = roles.filter((r) => +r.id < 30);
    const selectedUsers = accountUsers.filter((u) => +u.role_id < 30);
    batch(() => {
      setSelectedRolesList(selectedRoles);
      setSelectedUsersList(selectedUsers);
    });

    if (settingsMode === "update") {
      setPreparingUpdateData(true);
      batch(() => {
        prepareInformationStep(templateData, setValue, out);
        prepareSendRequestStep(templateData, setValue, out);
        prepareReceiveRequestStep(templateData, documentTypes, setValue);
        prepareMessagesStep(
          templateData,
          emailTemplates,
          smsTemplates,
          setValue,
          out,
        );
        preparePermissionsStep(
          templateData,
          roles,
          accountUsers,
          setValue,
          out,
        );
      });
      setLastStepCompleted(4);
      setPreparingUpdateData(false);
    } else {
      reset();
    }

    return () => {};
  }, []);

  useEffect(() => {
    if (templateData && templateData.is_draft < 1) {
      setTemplateIsPublished(true);
    }

    return () => {};
  }, [templateData]);

  useEffect(() => {
    if (showIsDraftWarning) {
      setDirtySteps([...dirtySteps, "preview"]);
    } else {
      removeStepFromDirtySteps("preview");
    }
  }, [showIsDraftWarning]);

  const submitSendRequest = (isDeleting = false) => {
    setProcessingData(true);
    if (goNextPage) setGoNextPage(false);
    if (
      (isDirty && dirtyFields?.sendRequest) ||
      dirtySteps.includes(activeTab.name) ||
      isDeleting
    ) {
      const data = getValues("sendRequest");
      if (data.length > 0 || isDeleting) {
        setDocumentIdsMissing([]);
        const validatedResult = validateSendRequest(
          data,
          getValues("informations.languages"),
          getValues("permissionsRoles"),
          getValues("permissionsUsers"),
        );

        if (validatedResult) {
          dispatch(showLoadingBarWithoutMessage(200000));
          updateDocumentsRequest.mutate(validatedResult);
        }
      } else {
        reset({}, { keepValues: true });
        setProcessingData(false);
        validateNextStep();
      }
    } else {
      reset({}, { keepValues: true });
      setProcessingData(false);
      validateNextStep();
    }
  };

  const onSubmit = (data) => {
    setProcessingData(true);
    if (goNextPage) setGoNextPage(false);
    let validatedResult = null;
    switch (activeTab.name) {
      case "informations":
        if (
          (isDirty && dirtyFields?.informations) ||
          dirtySteps.includes(activeTab.name)
        ) {
          validatedResult = validateInformations(
            data.informations.translations,
            data.informations.languages,
          );
          if (validatedResult) {
            dispatch(showLoadingBarWithoutMessage(200000));
            if (settingsMode === "create") {
              createDocumentsRequest.mutate({ translations: validatedResult });
            } else {
              updateDocumentsRequest.mutate({ translations: validatedResult });
            }
          } else {
            setProcessingData(false);
          }
        } else {
          reset({}, { keepValues: true });
          setProcessingData(false);
          validateNextStep();
        }
        break;
      case "sendRequest":
        if (
          (isDirty && dirtyFields?.sendRequest) ||
          dirtySteps.includes(activeTab.name)
        ) {
          const documentsIdMissingIndexes = [];
          data.sendRequest.forEach((request, i) => {
            if (
              request.requestType.value === "read" &&
              (!request.documentId || +request.documentId < 1)
            ) {
              documentsIdMissingIndexes.push(i);
            }
          });

          if (documentsIdMissingIndexes.length > 0) {
            setDocumentIdsMissing(documentsIdMissingIndexes);
            setProcessingData(false);
          } else {
            setDocumentIdsMissing([]);
            validatedResult = validateSendRequest(
              data.sendRequest,
              data.informations.languages,
              data.permissionsRoles,
              data.permissionsUsers,
            );

            if (validatedResult) {
              setGoNextPage(true);
              dispatch(showLoadingBarWithoutMessage(200000));
              updateDocumentsRequest.mutate(validatedResult);
            }
          }
        } else {
          reset({}, { keepValues: true });
          setProcessingData(false);
          validateNextStep();
        }
        break;
      case "receiveRequest":
        if (
          (isDirty && dirtyFields?.receiveRequest) ||
          dirtySteps.includes(activeTab.name)
        ) {
          validatedResult = validateReceiveRequest(data.receiveRequest);
          if (validatedResult && validatedResult.length > 0) {
            dispatch(showLoadingBarWithoutMessage(200000));
            updateDocumentsRequest.mutate({
              send_request_template_documents: validatedResult,
            });
          } else {
            reset({}, { keepValues: true });
            setProcessingData(false);
            validateNextStep();
          }
        } else {
          reset({}, { keepValues: true });
          setProcessingData(false);
          validateNextStep();
        }
        break;
      case "messages":
        if (
          (isDirty && dirtyFields.messages) ||
          dirtySteps.includes(activeTab.name)
        ) {
          validatedResult = validateMessages(data.messages);
          dispatch(showLoadingBarWithoutMessage(200000));
          updateDocumentsRequest.mutate(validatedResult);
        } else {
          reset({}, { keepValues: true });
          setProcessingData(false);
          validateNextStep();
        }
        break;
      case "permissions":
        if (
          (isDirty &&
            (dirtyFields?.permissionsRoles || dirtyFields?.permissionsUsers)) ||
          dirtySteps.includes(activeTab.name)
        ) {
          validatedResult = validatePermissions(
            data.permissionsRoles,
            data.permissionsUsers,
            data.documentsList,
            data.sendRequest,
          );
          dispatch(showLoadingBarWithoutMessage(200000));
          updateDocumentsRequest.mutate(validatedResult);
        } else {
          reset({}, { keepValues: true });
          setProcessingData(false);
          validateNextStep();
        }
        break;
      case "preview":
        const receiveDocsArray = data.receiveRequest.filter(
          (doc) => doc.numberOfDocumentType > 0 && doc.requiredNumber > 0,
        );
        if (data.sendRequest.length > 0 || receiveDocsArray.length > 0) {
          dispatch(showLoadingBarWithoutMessage(200000));
          publishDocumentRequestTemplate.mutate();
        } else {
          setProcessingData(false);
        }
        break;
      default:
      // nothing to do in this case, it shouldn't happen
    }
  };

  // creates new documents request template - as a draft
  const createDocumentsRequest = useMutation(
    (data) => createDocumentsRequestApi(data),
    {
      onSuccess: (response) => {
        if (response?.id) {
          setDocuRequestTemplateId(response.id);
          reset({}, { keepValues: true });
          validateNextStep();
          const msg = documentsRequestTemplatePostMsgHandler(201, activeTab);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          queryClient.invalidateQueries("document-request-templates");
        } else {
          const msg = documentsRequestTemplatePostMsgHandler(
            500,
            activeTab,
            () => history.replace("/"),
          );
          dispatch(showMessage("error", msg.title, msg.text, 8000));
        }
        setProcessingData(false);
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        setProcessingData(false);
        const msg = documentsRequestTemplatePostMsgHandler(
          error.status,
          activeTab,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  // updates documents request template
  const updateDocumentsRequest = useMutation(
    (data) => updateDocumentsRequestApi(docuRequestTemplateId, data),
    {
      onSuccess: (response) => {
        if (response) {
          if (dirtyFields?.receiveRequest) {
            batch(() => {
              prepareReceiveRequestStep(response, documentTypes, setValue);
              preparePermissionsStep(
                response,
                roles,
                accountUsers,
                setValue,
                out,
              );
            });
          } else if (dirtyFields?.messages) {
            setValue("messages.categoryIds", []); // @todo fix - doesn't work for unknown reason
          }
          if (activeTab.name === "sendRequest") {
            prepareSendRequestStep(response, setValue, out);
          }
          removeStepFromDirtySteps(activeTab.name);
          if (dirtyFields?.receiveRequest) {
            removeStepFromDirtySteps("permissions");
          }
          reset({}, { keepValues: true });
          const msg = documentsRequestTemplatePutMsgHandler(200, activeTab);
          dispatch(showMessage("ok", msg.title, msg.text, 5000));
          // if we need to publish the template, we wait to switch step to keep true active step
          if (templateIsPublished) {
            publishDocumentRequestTemplate.mutate();
          } else {
            if (activeTab.name !== "sendRequest" || goNextPage) {
              validateNextStep();
              if (goNextPage) setGoNextPage(false);
            }
            queryClient.invalidateQueries("document-request-templates");
          }
        } else {
          const msg = documentsRequestTemplatePutMsgHandler(
            500,
            activeTab,
            () => history.replace("/"),
          );
          dispatch(showMessage("error", msg.title, msg.text, 8000));
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setProcessingData(false);
      },
      onError: (error) => {
        const msg = documentsRequestTemplatePutMsgHandler(
          error.status,
          activeTab,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setProcessingData(false);
      },
    },
  );

  const publishDocumentRequestTemplate = useMutation(
    () => publishDocumentRequestTemplateApi(docuRequestTemplateId),
    {
      onSuccess: (response) => {
        if (response) {
          if (settingsMode !== "update") setSettingsMode("update");
          reset({}, { keepValues: true });
          if (activeTab.name === "preview") {
            const msg = documentsRequestTemplatePatchMsgHandler(200);
            dispatch(showMessage("ok", msg.title, msg.text, 5000));
            batch(() => {
              prepareInformationStep(response, setValue, out);
              prepareSendRequestStep(response, setValue, out);
              prepareReceiveRequestStep(response, documentTypes, setValue);
              prepareMessagesStep(
                response,
                emailTemplates,
                smsTemplates,
                setValue,
                out,
              );
              preparePermissionsStep(
                response,
                roles,
                accountUsers,
                setValue,
                out,
              );
            });
            setDirtySteps([]);
            setTemplateIsPublished(true);
          }
          // on sendRequest step we have a case where we want to switch step (goNextPage), on other cases we stay on page
          if (activeTab.name !== "sendRequest" || goNextPage) {
            validateNextStep();
            if (goNextPage) setGoNextPage(false);
          }
          if (showIsDraftWarning) setShowIsDraftWarning(false);
        } else {
          if (templateIsPublished) setShowIsDraftWarning(true);
          const msg = documentsRequestTemplatePatchMsgHandler(500, () =>
            history.replace("/"),
          );
          dispatch(showMessage("error", msg.title, msg.text, 8000));
        }
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("document-request-templates");
        setProcessingData(false);
      },
      onError: (error) => {
        if (templateIsPublished) setShowIsDraftWarning(true);
        const msg = documentsRequestTemplatePatchMsgHandler(
          error.status,
          error.data ?? null,
          () => history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        // need to update data in case of update query success
        queryClient.invalidateQueries("document-request-templates");
        setProcessingData(false);
      },
    },
  );

  // validates if we can go on selected step
  const validateSelectedStep = (index) => {
    return !!index <= lastStepCompleted + 1;
  };

  const switchTab = (e, i) => {
    if (
      validateSelectedStep(i) &&
      docuRequestTemplateId &&
      docuRequestTemplateId > 0
    ) {
      setActiveStepIndex(i);
      setActiveTab(steps[i]);
    }
  };

  // sets next step
  const validateNextStep = () => {
    const index = activeStepIndex;
    if (index > 0 && (!docuRequestTemplateId || +docuRequestTemplateId < 1)) {
      // show error msg
      return;
    }

    if (index > lastStepCompleted) setLastStepCompleted(index > -1 ? 5 : index);
    if (index + 1 < steps.length) {
      setActiveStepIndex(index + 1);
      setActiveTab(steps[index + 1]);
    }
  };

  const removeStepFromDirtySteps = (stepName) => {
    const newDirtyStepsArray = dirtySteps.filter((s) => s !== stepName);
    setDirtySteps(newDirtyStepsArray);
  };

  return (
    <>
      <div
        className={`container-fluid d-flex flex-column align-items-center mt-5 ${styles.tabMenuContainer} `}
      >
        <HorizontalStepsNavbar
          steps={steps}
          handleClick={(step, i) => {
            const hasUnsavedChanges =
              activeTab.name !== "permissions"
                ? dirtyFields.hasOwnProperty(activeTab.name)
                : dirtyFields?.permissionsRoles ||
                  dirtyFields?.permissionsUsers;
            if (hasUnsavedChanges) {
              setDirtySteps([...dirtySteps, activeTab.name]);
            }
            switchTab(step, i);
            reset({}, { keepValues: true, keepDirty: true });
          }}
          activeStepIndex={activeStepIndex}
          lastStepCompleted={lastStepCompleted}
          unsavedStepsArray={dirtySteps}
        />
      </div>
      {preparingUpdateData && (
        <div className={`bg-white ${styles.componentLoaderPadding}`}>
          <NestedPageLoader
            message={out("Veuillez patienter...", "Please wait...")}
          />
        </div>
      )}
      {!preparingUpdateData && (
        <div className={`bg-white mx-3 mb-5 ${styles.settingsPanel}`}>
          <Form onSubmit={handleSubmit(onSubmit)}>
            <div>
              {activeTab.name === "informations" && (
                <Informations
                  templateData={templateData}
                  templateIsDraft={templateData?.is_draft > 0}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  control={control}
                  setValue={setValue}
                  watch={watch}
                  languages={languages}
                  errors={errors}
                />
              )}
              {activeTab.name === "sendRequest" && (
                <SendRequest
                  templateIsDraft={templateData?.is_draft > 0}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  fields={sendRequestFields}
                  append={sendRequestAppend}
                  remove={sendRequestRemove}
                  control={control}
                  watch={watch}
                  trigger={trigger}
                  errors={errors}
                  setValue={setValue}
                  getValues={getValues}
                  submitSendRequest={submitSendRequest}
                  processingData={processingData}
                  setProcessingData={setProcessingData}
                  documentTypes={documentTypes}
                  documentTypesIsError={documentTypesIsError}
                  docuRequestTemplateId={docuRequestTemplateId}
                  documentIdsMissing={documentIdsMissing}
                  setDocumentIdsMissing={setDocumentIdsMissing}
                />
              )}
              {activeTab.name === "receiveRequest" && (
                <ReceiveRequest
                  templateIsDraft={templateData?.is_draft > 0}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  fields={receiveRequestFields}
                  append={receiveRequestAppend}
                  remove={receiveRequestRemove}
                  insert={receiveRequestInsert}
                  control={control}
                  watch={watch}
                  setValue={setValue}
                  getValues={getValues}
                  reset={reset}
                  settingsMode={settingsMode}
                  documentTypes={documentTypes}
                  documentTypesIsError={documentTypesIsError}
                />
              )}
              {activeTab.name === "messages" && (
                <Messages
                  templateIsDraft={templateData?.is_draft > 0}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  control={control}
                  watch={watch}
                  errors={errors}
                  setValue={setValue}
                  emailTemplates={emailTemplates}
                  emailTemplateIsError={emailTemplateIsError}
                  smsTemplates={smsTemplates}
                  smsTemplateIsError={smsTemplateIsError}
                  templateCategories={templateCategories}
                  templateCategorieIsError={templateCategorieIsError}
                  notification={notification}
                  notificationIsError={notificationIsError}
                />
              )}
              {activeTab.name === "permissions" && (
                <Permissions
                  templateIsDraft={templateData?.is_draft > 0}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  rolesFields={permissionsRolesFields}
                  rolesAppend={permissionsRolesAppend}
                  usersFields={permissionsUsersFields}
                  usersAppend={permissionsUsersAppend}
                  control={control}
                  watch={watch}
                  setValue={setValue}
                  getValues={getValues}
                  reset={reset}
                  settingsMode={settingsMode}
                  roles={roles}
                  rolesIsError={rolesIsError}
                  selectedRolesList={selectedRolesList}
                  selectedUsersList={selectedUsersList}
                />
              )}
              {activeTab.name === "preview" && (
                <Preview
                  template={templateData}
                  templateIsPublished={templateIsPublished}
                  showIsDraftWarning={showIsDraftWarning}
                  emailTemplates={emailTemplates}
                  smsTemplates={smsTemplates}
                  selectedRolesList={selectedRolesList}
                  selectedUsersList={selectedUsersList}
                  setSaveIsDisabled={setSaveIsDisabled}
                  getValues={getValues}
                  notification={notification}
                  dataRetrievedError={
                    emailTemplateIsError ||
                    smsTemplateIsError ||
                    rolesIsError ||
                    accountUserIsError
                  }
                />
              )}
            </div>
            <div className="d-flex justify-content-end p-3">
              {activeTab.name !== "preview" && (
                <Button
                  type="button"
                  variant="alt-secondary btn-md"
                  className="ms-3"
                  disabled={processingData}
                  onClick={() => {
                    switch (activeTab.name) {
                      case "informations":
                        prepareInformationStep(templateData, setValue, out);
                        break;
                      case "sendRequest":
                        prepareSendRequestStep(templateData, setValue, out);
                        break;
                      case "receiveRequest":
                        prepareReceiveRequestStep(
                          templateData,
                          documentTypes,
                          setValue,
                        );
                        preparePermissionsStep(
                          templateData,
                          roles,
                          accountUsers,
                          setValue,
                          out,
                        );
                        break;
                      case "messages":
                        prepareMessagesStep(
                          templateData,
                          emailTemplates,
                          smsTemplates,
                          setValue,
                          out,
                        );
                        break;
                      case "permissions":
                        preparePermissionsStep(
                          templateData,
                          roles,
                          accountUsers,
                          setValue,
                          out,
                        );
                        break;
                      // no default case
                    }
                    // @to improve - did not find yet a good solution to reset one step at the time - resetField is not working fine with nested values
                    // Ideally we would reset the step we are on, and remove this step from dirtySteps - removeStepFromDirtySteps(activeTab.name);
                    reset({}, { keepValues: true });
                    setDirtySteps([]);
                    if (documentIdsMissing.length > 0) {
                      setDocumentIdsMissing([]);
                    }
                  }}
                >
                  <span>{out("Annuler", "Cancel")}</span>
                </Button>
              )}
              {((activeTab.name === "preview" && templateData?.is_draft > 0) ||
                activeTab.name !== "preview") && (
                <Button
                  type="submit"
                  variant={cx({
                    secondary: activeTab.name !== "preview",
                    primary: activeTab.name === "preview",
                  })}
                  className={cx(`d-flex align-items-center ms-3 btn-md`, {
                    [styles.notAllowed]:
                      activeTab.name === "preview" && saveIsDisabled,
                  })}
                  disabled={
                    (activeTab.name === "preview" && saveIsDisabled) ||
                    processingData ||
                    emailTemplateIsError ||
                    smsTemplateIsError ||
                    rolesIsError ||
                    accountUserIsError
                  }
                  onClick={async () => {
                    return await trigger(activeTab.name);
                  }}
                >
                  <span>
                    {activeTab.name !== "preview"
                      ? isDirty
                        ? out("Sauvegarder", "Save")
                        : out("Suivant", "Next")
                      : out("Publier", "Publish")}
                  </span>
                  {activeTab.name === "preview" && templateData?.is_draft > 0 && (
                    <Tooltip
                      placement="top"
                      title={
                        <h5 className="my-0 p-1 pt-2 fs-6 text-center">
                          {out(
                            "En cliquant sur Créer, ce modèle de demande de document cessera d'être un brouillon et sera disponible à l'envoi.",
                            "By clicking Create, this document request template will cease to be a draft and will be available for submission.",
                          )}
                        </h5>
                      }
                    >
                      <span className="ms-3">
                        <AiFillInfoCircle className="text-white fs-4" />
                      </span>
                    </Tooltip>
                  )}
                </Button>
              )}
            </div>
          </Form>
        </div>
      )}
    </>
  );
};

export default DocuTransferSettings;
