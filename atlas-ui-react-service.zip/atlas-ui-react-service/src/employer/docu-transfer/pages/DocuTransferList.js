import React, { useEffect, useState } from "react";
import { useQueryClient, useMutation } from "react-query";
import { batch, useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { Accordion, Button } from "react-bootstrap";
import DocuTransferTemplateView from "../components/DocuTransferTemplateView";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { deleteDocumentRequestTemplate } from "../apis/DocumentsRequestApi";
import { deleteDocumentRequestTemplateMsgHandler } from "../utils/steps-msg-handler";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { useTranslation } from "global/utils/useTranslation";
import { AtlasAlert } from "global/components/atlas-alert";
import { languages } from "global/constants/languages";
import { RECRUITER } from "global/constants/accountsConstants";
import styles from "../styles/DocuTransfer.module.scss";
import { FiEdit } from "react-icons/fi";
import { BiTrash } from "react-icons/bi";

const DocuTransferList = ({
  documentsRequestTemplates,
  documentsRequestTemplatesIsError,
  dataRetrievedError,
  editDocumentRequestTemplate,
  emailTemplates,
  smsTemplates,
  roles,
  notification,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const queryClient = useQueryClient();
  const user = useSelector((state) => state.user.data);
  const accountUsers = useSelector((state) => state.user.accountUser);
  const [loadingData, setLoadingData] = useState(true);
  const [selectedRolesList, setSelectedRolesList] = useState(null);
  const [selectedUsersList, setSelectedUsersList] = useState(null);

  useEffect(() => {
    if (!dataRetrievedError && !documentsRequestTemplatesIsError) {
      const selectedRoles = roles.filter((r) => +r.id < 30);
      const selectedUsers = accountUsers.filter((u) => +u.role_id < 30);

      batch(() => {
        setSelectedRolesList(selectedRoles);
        setSelectedUsersList(selectedUsers);
        setLoadingData(false);
      });
    }

    return () => {};
  }, []);

  // deletes a documents request template
  const deleteDocumentRequestTemplateApi = useMutation(
    (id) => deleteDocumentRequestTemplate(id),
    {
      onSuccess: () => {
        const msg = deleteDocumentRequestTemplateMsgHandler(204);
        dispatch(showMessage("ok", msg.title, msg.text, 5000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        queryClient.invalidateQueries("document-request-templates");
      },
      onError: (error) => {
        const msg = deleteDocumentRequestTemplateMsgHandler(error.status, () =>
          history.replace("/"),
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
    },
  );

  return (
    <>
      {!documentsRequestTemplatesIsError && !dataRetrievedError && (
        <div className="my-5 mx-3 mx-md-5 py-3">
          {documentsRequestTemplates.length > 0 && (
            <div className={styles.listPanel}>
              {/* defaultActiveKey={0} - not sure we want an active panel by default */}
              <Accordion>
                {documentsRequestTemplates.map((template, i) => (
                  <Accordion.Item key={template.id} eventKey={i}>
                    <Accordion.Header
                      className={`${styles.accordionHeader} mb-1`}
                    >
                      <div className="d-flex justify-content-between w-100 fs-large">
                        <div className="d-flex justify-content-between flex-fill flex-wrap w-100">
                          {template?.translations &&
                            Object.keys(template.translations).map((k, i) => (
                              <div key={i}>
                                <label className="me-1 fw-bold">
                                  {out(languages[k].fr, languages[k].en)}:
                                </label>
                                <span>{template.translations[k].title}</span>
                              </div>
                            ))}
                        </div>
                        <div className="d-flex mx-3">
                          <label className="me-1">
                            {out("Total", "Total")}:
                          </label>
                          <span>
                            {template.read_request_files.length +
                              template.send_request_template_documents.length}
                          </span>
                        </div>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      {(+user.user_account?.role_id !== RECRUITER ||
                        (+user.user_account?.role_id === RECRUITER &&
                          (template.users.find((u) => +u.id === +user.user_id)
                            ? template.users.find(
                                (u) =>
                                  +u.id === +user.user_id &&
                                  u.pivot.has_write_access,
                              )
                            : template.roles.find(
                                (r) =>
                                  +r.id === RECRUITER &&
                                  r.pivot.has_write_access,
                              )))) && (
                        <div className="d-flex justify-content-end mb-3">
                          <Button
                            type="button"
                            variant="secondary"
                            className="fs-5 ms-3"
                            onClick={() => {
                              editDocumentRequestTemplate(template);
                            }}
                          >
                            <FiEdit />
                          </Button>
                          <Button
                            type="button"
                            variant="alt-danger"
                            className="fs-5 ms-3"
                            onClick={() => {
                              dispatch(showLoadingBarWithoutMessage(200000));
                              deleteDocumentRequestTemplateApi.mutate(
                                template.id,
                              );
                            }}
                          >
                            <BiTrash />
                          </Button>
                        </div>
                      )}
                      {loadingData && (
                        <NestedPageLoader
                          message={out(
                            "Chargement du modèle de requête de documents...",
                            "Loading document request template...",
                          )}
                        />
                      )}
                      {!loadingData && (
                        <div className="mt-3">
                          <DocuTransferTemplateView
                            template={template}
                            emailTemplates={emailTemplates}
                            smsTemplates={smsTemplates}
                            selectedRolesList={selectedRolesList}
                            selectedUsersList={selectedUsersList}
                            notification={notification}
                          />
                        </div>
                      )}
                    </Accordion.Body>
                  </Accordion.Item>
                ))}
              </Accordion>
            </div>
          )}
          {documentsRequestTemplates.length < 1 && (
            <div>
              <AtlasAlert variant="info">
                {out(
                  "Il n'y a aucune liste de modèles de requête de documents",
                  "There is no documents request templates list",
                )}
              </AtlasAlert>
            </div>
          )}
        </div>
      )}
      {documentsRequestTemplatesIsError && (
        <div className="my-5 mx-3 mx-md-5 py-3">
          <AtlasAlert variant="danger">
            {out(
              "La liste de modèles de requête de documents n'a pu être récupérée",
              "Documents request templates list could not be retrieved",
            )}
          </AtlasAlert>
        </div>
      )}
      {dataRetrievedError && !documentsRequestTemplatesIsError && (
        <div className="my-5 mx-3 mx-md-5 py-3">
          <AtlasAlert variant="danger">
            {out(
              "Une erreur s'est produite et nous ne pouvons afficher la liste de modèles de requête de documents",
              "An error has occurred and we cannot display the list of document request templates",
            )}
          </AtlasAlert>
        </div>
      )}
    </>
  );
};

export default DocuTransferList;
