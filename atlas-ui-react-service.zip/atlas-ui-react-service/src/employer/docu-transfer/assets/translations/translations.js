export const createListBtnLabel = {
  fr: "Créer une nouvelle liste",
  en: "Create a new list",
};
export const viewListBtnLabel = {
  fr: "Afficher la liste des demandes de documents",
  en: "View document requests list",
};
export const steps = [
  {
    name: "informations",
    translations: {
      fr: "Informations",
      en: "Informations",
    },
  },
  {
    name: "sendRequest",
    translations: {
      fr: "Requête de réception",
      en: "Send request",
    },
  },
  {
    name: "receiveRequest",
    translations: {
      fr: "Requête d'envoi",
      en: "Receive request",
    },
  },
  {
    name: "messages",
    translations: {
      fr: "Messages",
      en: "Messages",
    },
  },
  {
    name: "permissions",
    translations: {
      fr: "Permissions",
      en: "Permissions",
    },
  },
  {
    name: "preview",
    translations: {
      fr: "Prévisualiser & soumettre",
      en: "Preview & submit",
    },
  },
];
export const langLabels = {
  titleFr: {
    fr: "Titre en français",
    en: "French Title",
  },
  titleEn: {
    fr: "Titre en anglais",
    en: "English Title",
  },
  descriptionFr: {
    fr: "Description en français",
    en: "French description",
  },
  descriptionEn: {
    fr: "Description en anglais",
    en: "English description",
  },
};

/* Informations */
export const informationsHeader = {
  title: {
    fr: "Informations sur le groupe de document. Veuillez noter que ces informations seront vues par les candidats",
    en: "Informations about documents group. Please note that these informations will be seen by candidates",
  },
};
export const languages = [
  {
    value: "en",
    translations: {
      fr: "Anglais",
      en: "English",
    },
  },
  {
    value: "fr",
    translations: {
      fr: "Français",
      en: "French",
    },
  },
];

/* SendReqest */
export const sendRequestHeader = {
  title: {
    fr: "Ici, vous pouvez ajouter les documents que vous souhaitez être lus par les candidats",
    en: "Here you can add the documents you want to be read by candidates",
  },
};
export const requestTypes = [
  {
    value: "read",
    translations: {
      fr: "Lecture",
      en: "Read",
    },
  },
];

/* Messages */
export const messagesHeader = {
  title: {
    fr: "Ici vous pouvez choisir le message de communication",
    en: "Here you can choose the communication message",
  },
};

/* Receive request */
export const receiveRequestHeader = {
  title: {
    fr: "Ici vous pouvez ajouter les documents que vous souhaitez que le candidat téléverse",
    en: "Here you can add the documents you want the candidate to upload",
  },
};

/* Permissions */
export const permissionsHeader = {
  title: {
    fr: "Ici vous pouvez personnaliser l'accès aux documents et à la liste",
    en: "Here you can customize access to documents and list",
  },
};
