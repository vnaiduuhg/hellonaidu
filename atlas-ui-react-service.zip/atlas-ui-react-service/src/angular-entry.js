import React, { Suspense } from "react";
import ReactDOM from "react-dom";
import * as Sentry from "@sentry/react";
import SentryFallback from "./global/components/SentryFallback";
import "./global/components/SentryInit";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { BrowserRouter, Route, Switch, useHistory } from "react-router-dom";
import { QueryClientProvider } from "react-query";
import SubscribeSettingsRoutes from "./atlas/subscribe-settings/SubscribeSettingsRoutes";
import RequisitionRoutes from "employer/requisition-module/RequisitionRoutes";
import SyncPage from "employer/sync/pages/SyncPage";
import CalendarSyncPage from "employer/sync-calendar/pages/CalendarSyncPage";
import AutomatedMessagesRoutes from "employer/automated-messages/AutomatedMessagesRoutes";
import UploadDocumentsJobRoutes from "employer/upload-documents-job/UploadDocumentsJobRoutes";
import store, { persistor } from "./global/store/store";
import { queryClient } from "global/utils/queryClient";
import StatusMessageContainer from "global/components/StatusMessage/StatusMessageContainer";
import DocuTransferRoutes from "./employer/docu-transfer/DocuTransferRoutes";
import { EmailPages } from "employer/email/email-page";
import { Integrations } from "employer/integrations/integrations";
import CareerPage from "./atlas/public-pages/pages/career-page";
import JobDetailsPage from "./atlas/public-pages/pages/job-details-page";
import Header from "./atlas/public-pages/components/header/header";
import "./global/assets/global.css";
import "./i18n";
import { setAngularState } from "global/utils/angularState";

const HistoryProviderForNgApp = () => {
  window.h = useHistory();

  return <></>;
};

// all up-front initialization goes here before App is mounted
export const render = (container = document.getElementById("root"), $state) => {
  setAngularState($state);

  return ReactDOM.render(
    <React.StrictMode>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <Sentry.ErrorBoundary fallback={SentryFallback}>
            <Suspense fallback={<div>...</div>}>
              <QueryClientProvider client={queryClient}>
                <BrowserRouter>
                  <HistoryProviderForNgApp />
                  <header>
                    <Header angularRoute={true} />
                  </header>
                  <Switch>
                    <Route
                      path="/subscribe-settings/:slugName"
                      component={SubscribeSettingsRoutes}
                    />
                    <Route path="/emails" render={() => <EmailPages />} />
                    <Route
                      path={[
                        "/planning",
                        "/planning-settings",
                        "/requisition",
                        "/requisition/view/:requisitionId",
                        "/requisition/:operation(edit|clone|create)/:id/:step(info|budget|manpower|additional|preview)",
                      ]}
                      component={RequisitionRoutes}
                    />
                    <Route path="/sync" component={SyncPage} exact />
                    <Route
                      path="/sync-calendar"
                      component={CalendarSyncPage}
                      exact
                    />
                    <Route
                      path="/automated-messages"
                      component={AutomatedMessagesRoutes}
                    />
                    <Route
                      path="/careers/:company"
                      render={() => <CareerPage />}
                    />
                    <Route
                      path="/work/:id/:jobUrl"
                      render={() => <JobDetailsPage />}
                      exact
                    />
                    <Route
                      path="/docu-secur"
                      component={DocuTransferRoutes}
                      exact
                    />
                    <Route
                      path="/integrations"
                      render={() => <Integrations />}
                    />
                    <Route
                      path="/job/:id/upload-documents"
                      render={() => <UploadDocumentsJobRoutes />}
                      exact
                    />
                  </Switch>
                </BrowserRouter>

                {/* status messages */}
                <StatusMessageContainer />

                {/* <ReactQueryDevtools /> */}
              </QueryClientProvider>
            </Suspense>
          </Sentry.ErrorBoundary>
        </PersistGate>
      </Provider>
    </React.StrictMode>,
    container,
  );
};
