import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { ATLAS_UI_URL, DEBUG_REDIRECT_404_TO_ANGULAR } from "config";
import { useTranslation } from "global/utils/useTranslation";

// This is a placholder page for 404 errors. It is not used in the application.
// 404 errors are handled by the Angular application. When migrating, rewrite
// this page and remove the redirect
export const Error404Page = () => {
  const { pathname, hash, search } = useLocation();
  const { out } = useTranslation();

  const slashLessPath = ATLAS_UI_URL.slice(0, -1);

  // mimic the hash and query the same order as it is on production redirects between
  // ng- and react app
  const redirectPath = `${slashLessPath}${pathname}${search}${hash}`;

  // Just a safety net in case this route gets accidentally added to the
  // production router while angular app is still handling routing
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "AngularJS's 404 error page should be shown instead. Remove this page from the router.",
    );
  }

  const translatedTitle = out("Page non trouvée", "Page Not Found");
  useEffect(() => {
    document.title = `${translatedTitle} - Workland`;
  }, [translatedTitle]);

  if (DEBUG_REDIRECT_404_TO_ANGULAR === "true") {
    window.location.replace(redirectPath);

    return null;
  }

  return (
    <div className="d-flex justify-content-center">
      <div className="m-5 w-75">
        <h2 className="text-center text-warning">
          This path does not exist on React
        </h2>

        <hr className="my-4" />

        <a className="fs-5" href={redirectPath}>
          Click here to redirect to angular: {redirectPath}
        </a>

        <hr className="my-4" />

        <p>
          This page is only shown in <strong>development mode</strong>. To
          automatically redirect, set the environment of{" "}
          <code>ATLAS_UI_URL</code> to the local or hosted path for the angular
          app (eg: <code>https://atlas-ui-test.workland.ca</code> or{" "}
          <code>http://localhost:8100</code>). Then set the env{" "}
          <code>DEBUG_REDIRECT_404_TO_ANGULAR = true</code>.
        </p>

        <p>See README.md for more info</p>
      </div>
    </div>
  );
};
