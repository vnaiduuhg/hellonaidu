import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import useQuery from "../../../public-pages/hooks/use-query";
import { useGetJobDetailsQuery } from "../../services/job-details/job-details";
import JobDetailsWrapper from "./job-details-wrapper";
import style from "./job-details.module.css";
import {
  setIsPublicPage,
  setIsJobDetailsPage,
} from "../../slices/account-info/public-page-slice";
import { PageLoader } from "global/components/loaders/page-loader";

const JobDetailsPage = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const urlInternalToken = useQuery().get("token");

  useEffect(() => {
    dispatch(setIsPublicPage(true));
    dispatch(setIsJobDetailsPage(true));

    return () => {
      dispatch(setIsPublicPage(false));
      dispatch(setIsJobDetailsPage(false));
    };
  }, [dispatch]);

  const {
    data,
    isLoading: isJobDataLoading,
    isError: isJobDataError,
  } = useGetJobDetailsQuery({ id, urlInternalToken });

  return (
    <div className={style.jobDetailsPage}>
      {isJobDataLoading ? (
        <PageLoader message="Loading / Chargement ..." />
      ) : !isJobDataError ? (
        <JobDetailsWrapper jobData={data} urlInternalToken={urlInternalToken} />
      ) : (
        window.location.replace("/404")
      )}
    </div>
  );
};

JobDetailsPage.propTypes = {};

JobDetailsPage.defaultProps = {};

export default JobDetailsPage;
