import parser from "html-react-parser";
import PropTypes from "prop-types";
import { useContext } from "react";
import { useTranslation } from "react-i18next";
import { useTranslation as globalUseTranslation } from "global/utils/useTranslation";
import { useGetLocationDetailsQuery } from "../../services/about-us/location-details";
import BenefitsItem from "../../components/benefits-item/benefits-item";
import SkillItem from "../../components/skill-item/skill-item";
import googleMapContext from "../../components/google-map/google-map-context";
import GoogleMapWrapper from "../../components/google-map/google-map-wrapper";
import { benefitsProps, skillsProps } from "./job-details-props";
import style from "./job-details.module.css";

const JobDetailsLeftSection = ({
  translations,
  benefits,
  skills,
  companyLoactions,
}) => {
  const {
    i18n: { language },
    t,
  } = useTranslation();
  const { out } = globalUseTranslation();
  const requiredSkills = skills.filter((item) => item.is_asset === 0);
  const assetsSkills = skills.filter((item) => item.is_asset === 1);
  const { showMap } = useContext(googleMapContext);

  const locationIds = companyLoactions.map((item) => item.location_id);

  const { data: locationDetails, isLoading: isLocationLoading } =
    useGetLocationDetailsQuery({
      key: "id",
      "values[]": locationIds,
    });

  return (
    <div className={style.jobDetailsLeft}>
      <section>
        <div className="mb-4">
          <h2 className="mb-1">
            <div className={style.jobDetailInnerTitle}>
              <span>{t("description")}</span>
            </div>
          </h2>
          <span className="text-muted fs-6">
            <i>
              {out(
                !translations[1]?.description
                  ? "Aucune description disponible en français"
                  : "",
                !translations[0]?.description
                  ? "No english description available"
                  : "",
              )}
            </i>
          </span>
        </div>
        <div className={`${style.jobDetailText}`}>
          <p
            dangerouslySetInnerHTML={{
              __html: out(
                translations[1]?.description ?? translations[0].description,
                translations[0]?.description ?? translations[1].description,
              ),
            }}
          />
        </div>
      </section>

      {skills.length > 0 && (
        <section>
          <h2>
            <div className={style.jobRequirementsLeft}>
              <span>{t("job-requirements")}</span>
            </div>
          </h2>
          <div className={style.jobDetailsRequirements}>
            {requiredSkills.length > 0 && (
              <span className={style.jobDetailRequiredSkilsTitle}>
                {t("required-skills")}
              </span>
            )}
            {requiredSkills.map((item) => {
              const skill = item.translations.find(
                (txt) => txt.locale === language,
              );

              return (
                <SkillItem
                  key={item.id}
                  skillName={skill.name}
                  skillDefinition={skill.definition}
                />
              );
            })}
            {assetsSkills.length > 0 && (
              <span className={style.jobDetailRequiredSkilsTitle}>
                {t("assets")}
              </span>
            )}
            {assetsSkills.map((item) => {
              const skill = item.translations.find(
                (txt) => txt.locale === language,
              );

              return (
                <SkillItem
                  key={item.id}
                  skillName={skill.name}
                  skillDefinition={skill.definition}
                />
              );
            })}
          </div>
        </section>
      )}

      {benefits.length > 0 && (
        <section style={{ marginTop: skills.length < 1 ? "60px" : "0" }}>
          <h2>
            <div className={style.jobDetailInnerTitle}>
              <span>{t("benefits")}</span>
            </div>
          </h2>

          <div className={style.jobDetailBenefitsSection}>
            {benefits.map((item) => {
              const benefitContent = item.translations.find(
                (txt) => txt.locale === language,
              ).content;

              return (
                <BenefitsItem
                  key={item.id}
                  iconName={item.icon_name}
                  benefitText={benefitContent}
                />
              );
            })}
          </div>
        </section>
      )}

      {showMap && (
        <GoogleMapWrapper
          locationDetails={Object.values(locationDetails)}
          isLocationLoading={isLocationLoading}
        />
      )}
    </div>
  );
};

JobDetailsLeftSection.propTypes = {
  translations: PropTypes.arrayOf(
    PropTypes.shape({ description: PropTypes.string }),
  ).isRequired,
  benefits: benefitsProps.isRequired,
  skills: skillsProps.isRequired,
  companyLoactions: PropTypes.arrayOf(
    PropTypes.shape({ location_id: PropTypes.number }),
  ).isRequired,
};

JobDetailsLeftSection.defaultProps = {};

export default JobDetailsLeftSection;
