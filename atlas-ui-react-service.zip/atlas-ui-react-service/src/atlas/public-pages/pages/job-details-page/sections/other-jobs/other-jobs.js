import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { usePublishedExternalApiMutation } from "../../../../services/job-offers/published-external";
import { usePublishedInternalApiMutation } from "../../../../services/job-offers/published-internal";
import style from "../job-sections.module.css";
import OtherJobsList from "./other-jobs-list";

const OtherJobs = ({
  currentJobId,
  accountId,
  showExternalJobs,
  internalToken,
}) => {
  const { t } = useTranslation();
  const [otherJobs, setOtherJobs] = useState([]);
  const [locationIds, setLocationIds] = useState([]);
  const [publishedExternalApi, { isLoading }] =
    usePublishedExternalApiMutation();
  const [publishedInternalApi, { isLoading: internalJobIsLoading }] =
    usePublishedInternalApiMutation();

  const setJobsList = (jobs) => {
    setOtherJobs(jobs);
    const locationIdSet = new Set();
    jobs.forEach((job) => {
      const { locations } = job;
      locations.forEach((item) => locationIdSet.add(item.location_id));
    });
    setLocationIds(Array.from(locationIdSet));
  };

  useEffect(() => {
    if (showExternalJobs) {
      publishedExternalApi({
        account_ids: [accountId],
      }).then((response) => {
        if (response.error) return;
        const jobs = response.data.filter((job) => {
          return job.id.toString() !== currentJobId;
        });
        setJobsList(jobs);
      });
    } else if (internalToken) {
      publishedInternalApi({
        account_ids: [accountId],
        internal_job_token: internalToken,
      }).then((response) => {
        if (response.error) return;
        const jobs = response.data.filter((job) => {
          return +job.id !== +currentJobId;
        });
        setJobsList(jobs);
      });
    }
  }, [accountId, publishedExternalApi, publishedInternalApi, currentJobId]);

  return (
    otherJobs.length > 0 && (
      <section className={style.jobDetailsRightSections}>
        <h2>
          <span className={style.jobDetailInnerTitle}>{t("other-jobs")}</span>
        </h2>
        {(!isLoading || !internalJobIsLoading) && locationIds.length > 0 && (
          <OtherJobsList
            otherJobs={otherJobs}
            locationIds={locationIds}
            internalToken={internalToken}
          />
        )}
      </section>
    )
  );
};

OtherJobs.propTypes = {
  currentJobId: PropTypes.string.isRequired,
  accountId: PropTypes.number.isRequired,
};

OtherJobs.defaultProps = {};

export default OtherJobs;
