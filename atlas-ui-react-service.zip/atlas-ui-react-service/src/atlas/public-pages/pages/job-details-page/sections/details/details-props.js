import PropTypes from "prop-types";

const durationsAndSalariesTranslationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    type: PropTypes.string,
    locale: PropTypes.string,
  }),
);

const workHoursProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    max_hours: PropTypes.string,
    min_hours: PropTypes.string,
  }),
);

const shiftsTranslationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    name: PropTypes.string,
    locale: PropTypes.string,
  }),
);

const shiftsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    name: PropTypes.string,
    translations: shiftsTranslationsProps,
  }),
);

const salariesProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    max_amount: PropTypes.number,
    min_amount: PropTypes.number,
    currency: PropTypes.string,
    translations: durationsAndSalariesTranslationsProps,
    type: PropTypes.string,
  }),
);

const durationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    amount: PropTypes.number,
    start_date: PropTypes.string,
    translations: durationsAndSalariesTranslationsProps,
    type: PropTypes.string,
  }),
);

const translationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    locale: PropTypes.string,
    name: PropTypes.string,
  }),
);

export const typesProps = PropTypes.arrayOf(
  PropTypes.shape({
    durations: durationsProps,
    id: PropTypes.number,
    name: PropTypes.string,
    salaries: salariesProps,
    shifts: shiftsProps,
    translations: translationsProps,
    work_hours: workHoursProps,
  }),
);

export default typesProps;
