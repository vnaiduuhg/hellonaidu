import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import OtherJobText from "../../../../components/other-job-item/other-job-item";
import { useGetLocationDetailsQuery } from "../../../../services/about-us/location-details";
import { otherJobsProps } from "../../job-details-props";

const OtherJobsList = ({ otherJobs, locationIds, internalToken }) => {
  const { i18n } = useTranslation();

  const { data: locationDetails, isLoading } = useGetLocationDetailsQuery({
    key: "id",
    "values[]": locationIds,
  });

  const renderOtherJobs = () => {
    return otherJobs.map((job, index) => {
      let tempTitle = job.translations.find(
        (lang) => lang.locale === i18n.language,
      ).title;
      if (tempTitle === null) {
        for (const lang of job.translations) {
          tempTitle = tempTitle || lang.title;
        }
      }
      const title = tempTitle;

      const jobUrl = internalToken
        ? `/work/${job.id}/${job.url}?token=${internalToken}`
        : `/work/${job.id}/${job.url}`;

      let location = "";
      const locationId = job.locations[0].location_id;

      const city = locationDetails[locationId]?.city;
      const province = locationDetails[locationId]?.province;

      if (city && province) location = `${city}, ${province}`;

      return (
        <OtherJobText
          key={job.id}
          jobUrl={jobUrl}
          jobTitle={title}
          locations={location}
          isOtherLocations={job.locations.length > 1}
          isLastItem={otherJobs.length === index + 1}
        />
      );
    });
  };

  return <div className="pt-3">{!isLoading && renderOtherJobs()}</div>;
};

OtherJobsList.propTypes = {
  otherJobs: otherJobsProps.isRequired,
  locationIds: PropTypes.arrayOf(PropTypes.number).isRequired,
};

OtherJobsList.defaultProps = {};

export default OtherJobsList;
