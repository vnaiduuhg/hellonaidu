import moment from "moment";
import { Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { useTranslation as globalUseTranslation } from "global/utils/useTranslation";
import JobDetailsText from "../../../../components/job-key-item/job-key-item";
import { FRENCH_LOCALE_CODE } from "../../../../constants";
import getSalaryFormatted from "../../../../helper/salary-formatter";
import style from "../job-sections.module.css";
import { typesProps } from "./details-props";

const Details = ({ types, isFullTime }) => {
  const {
    t,
    i18n: { language },
  } = useTranslation();
  const { out } = globalUseTranslation();

  const {
    durations = [],
    shifts = [],
    translations = [],
    work_hours: workHours = [],
    salaries = [],
  } = types[0] || {};

  let startTimeText = t("not-available");
  if (durations.length > 0 && durations[0].start_date !== null) {
    moment.locale(language);
    startTimeText = moment(durations[0].start_date).format("LL");
  }

  let jobType =
    translations.find((item) => item.locale === language)?.name || "";
  if (
    durations.length > 0 &&
    durations[0].translations.length > 0 &&
    durations[0].amount
  ) {
    let jobAmount = `${durations[0].amount} `;

    let jobTypeTranslation = durations[0].translations.find(
      (type) => type.locale === language,
    )?.type;

    jobType = out(
      `${jobType ? jobType : ""}` +
        `${
          jobAmount && jobTypeTranslation
            ? " " + jobAmount + " " + jobTypeTranslation.toLowerCase()
            : ""
        }`,
      `${
        jobAmount && jobTypeTranslation
          ? jobAmount + " " + jobTypeTranslation
          : ""
      }` + `${jobType ? " " + jobType : ""}`,
    );
  }

  let isFullTimeType = Number.isInteger(isFullTime)
    ? isFullTime > 0
      ? t("full-time")
      : t("part-time")
    : "";

  let jobTypeText =
    !jobType && !isFullTimeType
      ? t("not-available")
      : jobType + (jobType && isFullTimeType ? " / " : "") + isFullTimeType;

  let shift = t("not-available");
  if (shifts && shifts.length > 0)
    shift = shifts
      .map((shiftItems) => {
        return shiftItems.translations.find((item) => item.locale === language)
          .name;
      })
      .join(", ");

  let workHourText = t("not-available");
  if (workHours && workHours.length > 0)
    workHourText = `${workHours[0].min_hours} ${t("work-hour-formet")}`;

  let salaryText = t("not-available");
  if (salaries.length > 0) {
    const { minAmount, maxAmount } = getSalaryFormatted(salaries[0]);
    salaryText = `$${minAmount}`;
    salaryText += maxAmount ? ` - $${maxAmount}` : "";
    salaryText += ` ${salaries[0].currency}`;
    salaryText += ` ${
      salaries[0].translations.find((item) => item.locale === language).type
    }`;
  }

  return (
    <Col xs={12} className={style.jobDetailsRightSections}>
      <JobDetailsText
        iconName="icon-jobcalendar"
        headingText={t("start-date")}
        contentText={startTimeText}
      />

      <JobDetailsText
        iconName="icon-jobtype"
        headingText={t("job-type")}
        contentText={jobTypeText}
      />

      <JobDetailsText
        iconName="icon-jobtime"
        headingText={t("work-shift")}
        contentText={shift}
      />

      <JobDetailsText
        iconName="icon-jobtiming"
        headingText={t("work-schedule")}
        contentText={workHourText}
      />

      <JobDetailsText
        iconName="icon-jobsalary"
        headingText={t("salary")}
        contentText={salaryText}
      />
    </Col>
  );
};

Details.propTypes = {
  types: typesProps.isRequired,
};

Details.defaultProps = {};

export default Details;
