import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import DocumentViewerModal from "../../../components/document-modal/document-viewer-modal";
import { Button } from "react-bootstrap";
import { AiOutlineEye } from "react-icons/ai";
import style from "./job-sections.module.css";
import docStyle from "../../../components/required-document/required-document.module.css";
import { downloadFile } from "global/components/DocumentDownloader/DocumentDownloader"; // @std by
import { FaDownload } from "react-icons/fa"; // @std by

const DescriptionDocuments = ({ documents }) => {
  const { t, i18n } = useTranslation();
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [documentClicked, setDocumentClicked] = useState(null);

  return (
    <>
      <div className={style.jobDetailsRightSections}>
        <div className="mb-4">
          <span className={style.jobDetailsDocumentsTitle}>
            {t("description-documents")}
          </span>
        </div>
        {documents.map((doc) => {
          return (
            <div className={docStyle.jobDetailsDocumentsList} key={doc.id}>
              <span className="ms-0">{doc.translations[i18n.language]}</span>
              <Button
                variant="secondary"
                className="btn-frameless-icon ms-1"
                onClick={() => {
                  setDocumentClicked(doc);
                  setShowDocumentModal(true);
                }}
              >
                <AiOutlineEye className="fs-5" alt={t("view-document")} />
              </Button>
              {/* @std by - downloader
                <Button
                  variant="secondary"
                  className="btn-frameless-icon ms-1"
                  onClick={() =>
                    downloadFile({ fileUrl: doc.url, fileName: doc.filename })
                  }
                >
                  <FaDownload alt={t("download-document")} />
                </Button> */}
            </div>
          );
        })}
      </div>
      {showDocumentModal && documentClicked && (
        <DocumentViewerModal
          show={showDocumentModal}
          hide={() => {
            setDocumentClicked(null);
            setShowDocumentModal(false);
          }}
          document={documentClicked}
        />
      )}
    </>
  );
};

export default DescriptionDocuments;
