import { nanoid } from "@reduxjs/toolkit";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import RequiredDocumentText from "../../../components/required-document/required-document";
import { useGetDocumentTypesQuery } from "../../../services/job-details/document-type";
import style from "./job-sections.module.css";

const Documents = ({ documents }) => {
  const { t, i18n } = useTranslation();

  const { data, isLoading } = useGetDocumentTypesQuery();

  const getDocuments = (isOptionalDoc) => {
    const { message } = data;

    return documents
      .filter((item) => item.isOptional === isOptionalDoc)
      .map((doc) => {
        const { en, fr } = doc.descriptionTranslations;
        if (en !== "" && fr !== "") {
          return {
            name: en,
            nameFr: fr,
            id: doc.documentTypeId,
          };
        }
        const { name, name_fr: nameFr } = message.find(
          (item) => item.id === doc.documentTypeId,
        );
        return {
          name,
          nameFr,
          id: doc.documentTypeId,
        };
      });
  };
  const renderDocuments = (isOptionalDoc) => {
    const docs = getDocuments(isOptionalDoc);

    if (docs?.length > 0) {
      return (
        <>
          <div className="mb-4">
            <span className={style.jobDetailsDocumentsTitle}>
              {!isOptionalDoc
                ? t("required-documents")
                : t("optional-documents")}
            </span>
          </div>
          {docs.map((doc) => {
            return (
              <RequiredDocumentText
                key={nanoid(3)}
                documentText={i18n.language === "fr" ? doc.nameFr : doc.name}
              />
            );
          })}
          {!isOptionalDoc && <br />}
        </>
      );
    }
    return <div />;
  };
  return (
    <section className={style.jobDetailsRightSections}>
      {!isLoading && renderDocuments(false)}

      {!isLoading && renderDocuments(true)}
    </section>
  );
};

Documents.propTypes = {
  documents: PropTypes.arrayOf(
    PropTypes.shape({
      documentTypeId: PropTypes.number,
      isOptional: PropTypes.bool,
      descriptionTranslations: PropTypes.shape({
        en: PropTypes.string,
        fr: PropTypes.string,
      }),
    }),
  ),
};

Documents.defaultProps = {
  documents: [],
};

export default Documents;
