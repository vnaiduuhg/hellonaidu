import { useEffect } from "react";
import PropTypes from "prop-types";
import { useTranslation } from "global/utils/useTranslation";
import metaTagsHelper from "../../helper/meta-tags-helper";
import BannerAndLeftLogo from "../../components/banner-and-logo/banner-and-left-logo";
import TitleAndAdressWithVacency from "../../components/title-and-adress/title-address-and-vacancy";
import { useGetLocationDetailsQuery } from "../../services/about-us/location-details";
import style from "./job-details.module.css";
import { ComponentLoader } from "global/components/loaders/component-loader";

const JobDetailsTopSection = ({
  isLoading,
  jobTitle,
  jobDescription,
  translations,
  companyData,
  numberOfPosition,
  companyNameLocations,
  jobTypes,
  datePosted,
  externalExpiryDate,
  internalExpiryDate,
  externalJob,
  internalJob,
  workLocation,
  job,
}) => {
  const { out } = useTranslation();
  const locationIds = companyNameLocations.map((item) => item.location_id);
  const onlyInternal = !externalJob && internalJob;

  const getMetaData = () => {
    const identifier = {
      "@type": "PropertyValue",
      name: "Workland",
      value: "1234567890",
    };
    const hiringOrganization = {
      "@type": "Organization",
      name: companyData.name,
      sameAs: `/careers/${companyData.slug}`,
    };
    let jobLocation = {};
    if (locationIds && !!locationIds.length && locationDetails) {
      const firstLocation = Object.values(locationDetails)[0];
      jobLocation = {
        "@type": "PostalAddress",
        streetAddress: `${firstLocation.street_number} ${firstLocation.street}`,
        addressLocality: firstLocation.city,
        addressRegion: firstLocation.province,
        postalCode: firstLocation.postalCode,
        addressCountry: firstLocation.country,
      };
    }

    const metaData = {
      "@context": "http://schema.org/",
      "@type": "JobPosting",
      title: jobTitle,
      description: jobDescription,
      datePosted,
      validThrough: externalExpiryDate,
      identifier,
      hiringOrganization,
      jobLocation: {
        "@type": "Place",
        address: jobLocation,
      },
    };

    if (jobTypes && jobTypes.length > 0) {
      metaData.employmentType = jobTypes[0].name;
    }
    return metaData;
  };

  const { data: locationDetails, isLoading: isLocationLoading } =
    useGetLocationDetailsQuery({
      key: "id",
      "values[]": locationIds,
    });

  useEffect(() => {
    if (!isLocationLoading) {
      metaTagsHelper.setJsonToScriptTag("job-details", getMetaData());
    }
  }, [locationDetails, isLocationLoading]);

  return (
    <section className={style.jobPageSections}>
      <div>
        {isLoading ? (
          <ComponentLoader />
        ) : (
          <BannerAndLeftLogo
            bannerName={companyData.banner}
            logoName={companyData.logo}
            metaLogoName={companyData.metaLogo}
          />
        )}
      </div>

      <div className={style.jobDetailsHeader}>
        {translations?.length > 0 && (
          <div className="mb-3">
            <h1 className="mb-0">
              <span className={style.jobDetailsHeaderTitleText}>
                {out(
                  translations[1]?.title ?? translations[0].title,
                  translations[0]?.title ?? translations[1].title,
                )}
              </span>
            </h1>
            <span className="text-muted fs-6">
              <i>
                {out(
                  !translations[1]?.title
                    ? "Aucun titre disponible en français"
                    : "",
                  !translations[0]?.title ? "No english title available" : "",
                )}
              </i>
            </span>
          </div>
        )}
        {isLocationLoading ? (
          <ComponentLoader />
        ) : (
          <TitleAndAdressWithVacency
            companyName={companyData.name}
            companySlug={companyData.slug}
            locations={Object.values(locationDetails)}
            numberOfPosition={numberOfPosition}
            externalExpiryDate={externalExpiryDate}
            internalExpiryDate={internalExpiryDate}
            onlyInternal={Boolean(onlyInternal)}
            workLocation={workLocation}
            job={job}
          />
        )}
      </div>
    </section>
  );
};

JobDetailsTopSection.propTypes = {
  isLoading: PropTypes.bool,
  jobTitle: PropTypes.string,
  jobDescription: PropTypes.string,
  translations: PropTypes.array,
  numberOfPosition: PropTypes.number,
  companyData: PropTypes.shape({
    banner: PropTypes.string,
    logo: PropTypes.string,
    slug: PropTypes.string,
    name: PropTypes.string,
  }).isRequired,
  companyNameLocations: PropTypes.arrayOf(
    PropTypes.shape({
      location_id: PropTypes.number,
    }),
  ).isRequired,
  jobTypes: PropTypes.arrayOf(PropTypes.object),
  datePosted: PropTypes.string,
  externalExpiryDate: PropTypes.string,
  internalExpiryDate: PropTypes.string,
  externalJob: PropTypes.number,
  internalJob: PropTypes.number,
};

JobDetailsTopSection.defaultProps = {
  isLoading: true,
  jobTitle: null,
  jobDescription: null,
  translations: [],
  datePosted: null,
  jobTypes: [],
  externalExpiryDate: null,
  internalExpiryDate: null,
  externalJob: 0,
  internalJob: 0,
  numberOfPosition: 0,
};

export default JobDetailsTopSection;
