import PropTypes from "prop-types";
import { useContext } from "react";
import { useParams } from "react-router-dom";
import JobApply from "../../components/job-apply/job-apply";
import GoogleMapButton from "../../components/buttons/long-responsive-buttons/map-button";
import JobAlertButton from "../../components/buttons/long-responsive-buttons/job-alert-button";
import SocialMedia from "../../components/social-media/social-media";
import Details from "./sections/details/details";
import Documents from "./sections/documents";
import DescriptionDocuments from "./sections/description-documents";
import OtherJobs from "./sections/other-jobs/other-jobs";
import style from "./job-details.module.css";
import googleMapContext from "../../components/google-map/google-map-context";
import { useGetJobDetailsQuery } from "../../../../atlas/public-pages/services/job-details/job-details";

const JobDetailsRightSection = ({
  internalJob,
  slug,
  isPublished,
  urlInternalToken,
  publishedExternal,
}) => {
  const { id } = useParams();

  const {
    data: {
      account_id: accountId,
      required_documents: requiredDocuments,
      description_documents: descriptionDocuments,
      title,
      types,
      url,
      is_full_time: isFullTime,
    },
    isLoading,
  } = useGetJobDetailsQuery({ id, urlInternalToken });

  const documents = requiredDocuments.map((item) => {
    let en = "";
    let fr = "";
    if (
      item.translations.en !== undefined ||
      item.translations.fr !== undefined
    ) {
      en = item.translations.en
        ? item.translations.en.description
        : `${item.translations.fr.description} (English not available)`;
      fr = item.translations.fr
        ? item.translations.fr.description
        : `${item.translations.en.description} (Français non disponible)`;
    }
    return {
      documentTypeId: item.document_type_id,
      isOptional: Boolean(item.is_optional),
      descriptionTranslations: {
        en,
        fr,
      },
    };
  });

  const descDocuments = descriptionDocuments
    .map((doc) => {
      // relying on BE to make the filtering of internal And/Or external docuemnts depending on job publishing state
      if (doc.translations.length > 0 && doc.url) {
        const hasTranslations = {
          fr: doc.translations.find(
            (item) => item.locale === "fr" && item.title,
          ),
          en: doc.translations.find(
            (item) => item.locale === "en" && item.title,
          ),
        };

        const translations = {
          fr: hasTranslations.fr
            ? hasTranslations.fr.title
            : hasTranslations.en
            ? `${hasTranslations.en.title} (Titre non disponible en français)`
            : "",
          en: hasTranslations.en
            ? hasTranslations.en.title
            : hasTranslations.fr
            ? `${hasTranslations.fr.title} (English title not available)`
            : "",
        };

        return {
          id: doc.id,
          url: doc.url,
          filename: doc.file_name,
          translations: translations,
        };
      }
    })
    .filter((item) => item);

  const { showMap, setShowMap } = useContext(googleMapContext);
  const onClickHandler = () => {
    setShowMap((prev) => !prev);
  };

  return (
    <section className={style.jobDetailsRight}>
      <JobApply jobId={id} disabled={!isPublished} />
      {types && <Details types={types} isFullTime={isFullTime} />}
      {!isLoading && documents.length > 0 && (
        <Documents documents={documents} />
      )}
      {!isLoading && descDocuments.length > 0 && (
        <DescriptionDocuments documents={descDocuments} />
      )}
      {slug?.length > 0 && <JobAlertButton slug={slug} />}
      {!isLoading && (
        <OtherJobs
          currentJobId={id}
          accountId={accountId}
          showExternalJobs={publishedExternal && !urlInternalToken}
          internalToken={urlInternalToken}
        />
      )}
      {!showMap && <GoogleMapButton onClickHandler={onClickHandler} />}
      {!isLoading && isPublished && !internalJob && (
        <SocialMedia id={id} title={title} url={url} />
      )}
    </section>
  );
};

JobDetailsRightSection.propTypes = {
  internalJob: PropTypes.bool,
  slug: PropTypes.string.isRequired,
  isPublished: PropTypes.bool.isRequired,
};

JobDetailsRightSection.defaultProps = {
  internalJob: false,
};

export default JobDetailsRightSection;
