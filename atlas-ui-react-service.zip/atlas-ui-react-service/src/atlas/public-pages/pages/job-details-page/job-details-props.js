import PropTypes from "prop-types";

const otherJobTranslationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    title: PropTypes.string,
    locale: PropTypes.string,
  }),
);

export const otherJobsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    url: PropTypes.string,
    translations: otherJobTranslationsProps,
  }),
);

const skillsTranslationProps = PropTypes.arrayOf(
  PropTypes.shape({
    definition: PropTypes.string,
    id: PropTypes.number,
    name: PropTypes.string,
  }),
);

export const skillsProps = PropTypes.arrayOf(
  PropTypes.shape({
    definition: PropTypes.string,
    id: PropTypes.number,
    translations: skillsTranslationProps,
  }),
);

const benefitsTranslationProps = PropTypes.arrayOf(
  PropTypes.shape({
    content: PropTypes.string,
    locale: PropTypes.string,
  }),
);

export const benefitsProps = PropTypes.arrayOf(
  PropTypes.shape({
    content: PropTypes.string,
    icon_name: PropTypes.string,
    translations: benefitsTranslationProps,
  }),
);

export const jobDataProps = PropTypes.shape({
  account_id: PropTypes.number,
  number_of_positions: PropTypes.number,
  translations: otherJobTranslationsProps,
  benefits: benefitsProps,
  skills: skillsProps,
  locations: PropTypes.arrayOf(
    PropTypes.shape({ location_id: PropTypes.number }),
  ),
  external_expiry_date: PropTypes.string,
  published_external: PropTypes.number,
  published_internal: PropTypes.number,
});
