import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useTranslation as globalUseTranslation } from "global/utils/useTranslation";
import { useDispatch, useSelector } from "react-redux";
import { BsExclamationLg } from "react-icons/bs";
import descriptionParser from "../../helper/description-parser";
import metaTagsHelper from "../../helper/meta-tags-helper";
import utils from "../../helper/utils";
import { useDefaultUserDetailsApiMutation } from "../../services/account-info/default-user-details";
import {
  setNavLogoName,
  setAccountDataIsLoaded,
} from "../../slices/account-info/public-page-slice";
import { GoogleMapContextProvider } from "../../components/google-map/google-map-context";
import JobDetailsLeftSection from "./job-details-left-section";
import { jobDataProps } from "./job-details-props";
import JobDetailsRightSection from "./job-details-right-section";
import JobDetailsTopSection from "./job-details-top-section";
import style from "./job-details.module.css";
import AlertModelWithAction from "../../components/alert-modal/alert-modal-with-action";

const JobDetailsWrapper = ({ jobData, urlInternalToken }) => {
  const { t } = useTranslation();
  const { out } = globalUseTranslation();
  const [companyData, setCompanyData] = useState(null);
  const [title, setTitle] = useState(null);
  const [description, setDescription] = useState(null);
  const language = useSelector((state) => state.user.language);
  const dispatch = useDispatch();

  const {
    account_id: accountId,
    number_of_positions: numberOfPosition,
    translations,
    benefits,
    skills,
    locations,
    types,
    created_at: datePosted,
    external_expiry_date: externalExpiryDate,
    internal_expiry_date: internalExpiryDate,
    published_external: publishedExternal,
    published_internal: publishedInternal,
    work_location: workLocation,
  } = jobData;

  const isPublished = publishedExternal || publishedInternal;
  const onlyInternal = publishedInternal && !publishedExternal;
  const [defaultUserDetailsApi, { isLoading, isSuccess }] =
    useDefaultUserDetailsApiMutation();

  const [showExpireModule, setShowExpireModule] = useState(true);

  useEffect(() => {
    defaultUserDetailsApi({ account_ids: [accountId] }).then((UserData) => {
      const {
        banner,
        logo,
        alternate_logo_2: alternateLogo2,
        name,
        slug,
        color,
      } = UserData.data.data[accountId];

      setCompanyData({
        banner,
        metaLogo: logo,
        logo: alternateLogo2 || logo,
        name,
        slug,
        color,
      });

      dispatch(setNavLogoName(logo));
    });
  }, [accountId, defaultUserDetailsApi, dispatch]);

  useEffect(() => {
    dispatch(setAccountDataIsLoaded(isSuccess));
  }, [isSuccess, dispatch]);

  useEffect(() => {
    return () => {
      dispatch(setAccountDataIsLoaded(false));
    };
  }, []);

  useEffect(() => {
    const jobTitle = out(
      translations[1]?.title ?? translations[0].title,
      translations[0]?.title ?? translations[1].title,
    );
    setTitle(jobTitle);

    const jobDescription = out(
      translations[1]?.description ?? translations[0].description,
      translations[0]?.description ?? translations[1].description,
    );
    setDescription(jobDescription);

    if (companyData !== null) {
      document.documentElement.style.setProperty(
        "--company-profile-custom-color",
        `${companyData.color}`,
      );
      document.documentElement.style.setProperty(
        "--ats-body-font-family",
        "sans-serif",
      );

      // set metadata
      document.title = jobTitle;
      metaTagsHelper.addMetaTagWithName(
        "description",
        descriptionParser(jobDescription),
      );
      metaTagsHelper.addMetaTagWithProperty(
        "og:description",
        descriptionParser(jobDescription),
      );
      metaTagsHelper.addMetaTagWithProperty("og:url", window.location.href);
      metaTagsHelper.addMetaTagWithProperty("og:title", jobTitle);
    }
  }, [companyData, language]);

  /* can't currently use this - need to handle case when current language doens't have translation
  const translationData = translations.find(
    (data) => i18n.language === data.locale,
  ); */

  return (
    <div className={style.jobContainer}>
      {companyData && title && description && (
        <JobDetailsTopSection
          isLoading={isLoading}
          jobTitle={title}
          jobDescription={description}
          translations={translations}
          companyData={companyData}
          numberOfPosition={numberOfPosition}
          companyNameLocations={locations}
          jobTypes={Object.values(types)}
          datePosted={datePosted}
          externalExpiryDate={externalExpiryDate}
          internalExpiryDate={internalExpiryDate}
          externalJob={publishedExternal}
          internalJob={publishedInternal}
          workLocation={workLocation}
          job={jobData}
        />
      )}

      <div className={style.jobDetails}>
        <GoogleMapContextProvider>
          <JobDetailsLeftSection
            translations={translations}
            benefits={benefits}
            skills={skills}
            companyLoactions={locations}
          />

          <JobDetailsRightSection
            internalJob={Boolean(onlyInternal)}
            publishedExternal={publishedExternal}
            slug={companyData?.slug ?? ""}
            isPublished={Boolean(isPublished)}
            urlInternalToken={urlInternalToken}
          />
        </GoogleMapContextProvider>
        {!isPublished && (
          <AlertModelWithAction
            icon={<BsExclamationLg />}
            title={t("expire-module.header")}
            alertText={t("expire-module.text")}
            show={showExpireModule}
            yes={() => {
              window.location.href = `/careers/${
                companyData?.slug ?? ""
              }?open=about`;
            }}
            no={() => {
              setShowExpireModule(false);
            }}
          />
        )}
      </div>
    </div>
  );
};

JobDetailsWrapper.propTypes = {
  jobData: jobDataProps.isRequired,
};

JobDetailsWrapper.defaultProps = {};

export default JobDetailsWrapper;
