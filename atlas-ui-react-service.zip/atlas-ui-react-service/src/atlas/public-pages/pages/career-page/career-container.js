import { useCallback, useEffect, useState } from "react";
import { ButtonGroup, Container } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import TabButton from "../../components/buttons/tab-button/tab-button";
import Slider from "../../components/slider/slider.styled";
import blur from "../../helper/blur";
import useQuery from "../../hooks/use-query";
import { useGetLocationDetailsQuery } from "../../services/about-us/location-details";
import { useGetAccountTypeQuery } from "../../services/account-info/account-type";
import AboutUs from "./about-us/about-us";
import CareerPageContentWrapper from "./career-page-content-wrapper";
import { accountDataProps } from "./career-page-props";
import style from "./career-page.module.css";
import JobOffers from "./job-offers/job-offers";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { AtlasAlert } from "global/components/atlas-alert";

const CareerContainer = ({ accountData }) => {
  const aboutTab = "about";
  const jobsTab = "jobs";
  const internalTab = "internal";
  const { company } = useParams();
  const token = useQuery().get("token");
  const open = useQuery().get("open");
  const [openTab, setOpenTab] = useState(open);
  const history = useHistory();
  const { t: translate } = useTranslation();
  const emptyTranslation = { en: {}, fr: {} };

  const {
    data: {
      account_id: accountId,
      translation,
      name,
      location_id: locationId,
      phone,
      phone_extension: extension,
      banner,
      logo,
      alternate_logo_1: alternateLogo1,
      slug,
    },
  } = accountData;

  const phoneWithExt = phone ? `${phone} ${extension ?? ""}` : null;

  const { data: locationDetails, isLoading } = useGetLocationDetailsQuery({
    key: "id",
    "values[]": [locationId],
  });

  const imageUrls = [];
  for (let i = 1; i <= 6; i += 1) {
    const url = accountData.data[`image_url_${i}`];
    if (url) {
      imageUrls.push(url);
    }
  }

  const { data: accountType, isLoading: isAccountTypeLoading } =
    useGetAccountTypeQuery(accountId);

  const handleTabButtons = useCallback(
    (tabName) => {
      blur();
      history.push({
        pathname: `/careers/${company}`,
        search: `?open=${tabName}${
          token ? `&token=${encodeURIComponent(token)}` : ""
        }`,
      });
      setOpenTab(tabName);
    },
    [company, history, token],
  );

  useEffect(() => {
    if (
      open === "" ||
      (open !== aboutTab && open !== jobsTab && open !== internalTab)
    ) {
      handleTabButtons(aboutTab);
    } else if (open === internalTab && !token) {
      handleTabButtons(jobsTab);
    }
  }, [open, token, handleTabButtons]);

  useEffect(() => {
    if (name) {
      document.title = name;
    }
  }, [name]);

  const getSliderTransform = () => {
    if (openTab === aboutTab) {
      return token ? -27 : -14;
    }
    if (openTab === jobsTab) {
      return token ? 47 : 85;
    }
    if (openTab === internalTab) {
      return 120;
    }

    return 15;
  };

  return (
    <Container fluid className={`${style.careerContainer} px-4 pb-5`}>
      {!isLoading && !isAccountTypeLoading && (
        <CareerPageContentWrapper
          locationDetails={locationDetails[locationId]}
          companyName={name}
          companyPhone={phoneWithExt}
          bannerName={banner}
          logoName={alternateLogo1 || logo}
        >
          <section className={style.tabsCareerPage}>
            <ButtonGroup className={style.tabButtonGroup}>
              <ul className={style.tabs}>
                <li>
                  <TabButton
                    name={translate("about-us")}
                    icon="AboutUs"
                    currentValue={open}
                    activeValue={aboutTab}
                    handleTabButtons={handleTabButtons}
                  />
                </li>
                <li>
                  <TabButton
                    name={translate("job-offers")}
                    icon="JobOffers"
                    currentValue={open}
                    activeValue={jobsTab}
                    handleTabButtons={handleTabButtons}
                  />
                </li>
                {token && (
                  <li>
                    <TabButton
                      name={translate("internal-job-offers")}
                      icon="JobOffers"
                      currentValue={open}
                      activeValue={internalTab}
                      handleTabButtons={handleTabButtons}
                    />
                  </li>
                )}
                {slug && (
                  <li>
                    <TabButton
                      name={translate("job-alert")}
                      icon="JobAlert"
                      handleTabButtons={() => {
                        window.location = `/subscribe-settings/${slug}`;
                      }}
                      activeValue="jobAlert"
                      currentValue={open}
                      as="button"
                    />
                  </li>
                )}
              </ul>
            </ButtonGroup>
            <Slider transform={getSliderTransform()}>
              <div className={style.indicator} />
            </Slider>
          </section>

          {openTab === aboutTab ? (
            <AboutUs
              translation={
                Object.keys(translation).length > 0
                  ? translation
                  : emptyTranslation
              }
              imageUrls={imageUrls}
            />
          ) : (
            <JobOffers
              accountId={accountId}
              isAgency={accountType?.data === "agency"}
              isInternal={openTab === internalTab && token?.length > 0}
              token={token}
              companyName={name}
            />
          )}
        </CareerPageContentWrapper>
      )}
      {!isLoading && (
        <div className={style.errorMessageBlock}>
          {!isAccountTypeLoading && !accountType ? (
            <AtlasAlert variant="warning">
              <div>{translate("company-data-not-found")}</div>
            </AtlasAlert>
          ) : (
            isAccountTypeLoading && <ComponentLoader />
          )}
        </div>
      )}
    </Container>
  );
};

CareerContainer.propTypes = {
  accountData: accountDataProps.isRequired,
};

CareerContainer.defaultProps = {};

export default CareerContainer;
