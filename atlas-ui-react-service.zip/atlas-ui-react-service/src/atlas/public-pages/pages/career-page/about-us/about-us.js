import { useEffect } from "react";
import parser from "html-react-parser";
import PropTypes from "prop-types";
import { Col, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import CompanyBenefitItem from "../../../components/benefits-item/company-benefit-item";
import ImageGrid from "../../../components/image-grid/image-grid";
import { translationProps } from "../career-page-props";
import metaTagsHelper from "../../../helper/meta-tags-helper";
import style from "./about-us.module.css";

const AboutUs = ({ translation, imageUrls }) => {
  const { t: translate, i18n } = useTranslation();

  const getTranslatedData = (key) => {
    return translation[i18n.language][key];
  };
  const companyBenefitsTitle = parser(getTranslatedData("section_title") ?? "");

  const companyBenefits = [];
  for (let i = 1; i <= 6; i += 1) {
    const title = getTranslatedData(`subsection_${i}_title`);
    const description = getTranslatedData(`subsection_${i}_description`);
    if (title || description) {
      companyBenefits.push({
        title,
        description,
      });
    }
  }

  useEffect(() => {
    metaTagsHelper.addMetaTagWithProperty("og:url", window.location.href);
  }, []);

  return (
    <Row className={`${style.company_more_container} px-3 px-md-5`}>
      <section className={style.aboutUsText}>
        {parser(getTranslatedData("summary") ?? "")}
      </section>

      {getTranslatedData("success") && (
        <section className={style.aboutUsText}>
          <h2>
            <span className={style.paragraphHeader}>
              {translate("about-us-success-stories")}
            </span>
          </h2>
          <div className="pt-4" />
          {parser(getTranslatedData("success") ?? "")}
        </section>
      )}

      {getTranslatedData("benefits") && (
        <section xs={12} className={style.aboutUsText}>
          <h2>
            <span className={style.paragraphHeader}>
              {translate("about-us-advantages-benefits")}
            </span>
          </h2>
          <div className="pt-4" />
          {parser(getTranslatedData("benefits") ?? "")}
        </section>
      )}

      {getTranslatedData("atwork") && (
        <section xs={12} className={style.aboutUsText}>
          <h2>
            <span className={style.paragraphHeader}>
              {translate("quality-of-life")}
            </span>
          </h2>

          {parser(getTranslatedData("atwork") ?? "")}
        </section>
      )}

      {/* removed section. adding it for posterity just in case it'll be brought back in the future */}
      {/* <div ng-if="employerData.courses"> */}
      {/* <h2>{{::out('Prix et distinctions', 'Prizes and distinctions')}}</h2> */}
      {/* <ul>
          <li ng-repeat="course in employerData.courses">
              <strong>{{course.titlecomp}}</strong>
              <br />
              <i> {{::course.year1comp}} </i>
          </li>
      </ul> */}
      {/* </div> */}

      {/* gallery */}
      {imageUrls.length > 0 && (
        <section className="pt-2 pb-5">
          <ImageGrid imageUrls={imageUrls} />
        </section>
      )}

      {companyBenefitsTitle.length > 0 && (
        <section>
          <h2>
            <div className={`${style.companyDetailsTitleBenefits}`}>
              {companyBenefitsTitle}
            </div>
          </h2>
          <Row>
            {companyBenefitsTitle.length > 0 &&
              companyBenefits.map((benefit) => {
                return (
                  <Col xs={12} md={4} className="pb-4" key={benefit.title}>
                    <CompanyBenefitItem
                      benefitTitle={benefit.title}
                      benefitDescription={benefit.description}
                    />
                  </Col>
                );
              })}
          </Row>
        </section>
      )}
    </Row>
  );
};

AboutUs.propTypes = {
  translation: translationProps.isRequired,
  imageUrls: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default AboutUs;
