import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { useGetAccountDetailsQuery } from "../../services/about-us/account-details";
import CareerContainer from "./career-container";
import {
  setAccountDataIsLoaded,
  setNavLogoName,
  setIsPublicPage,
} from "../../slices/account-info/public-page-slice";
import metaTagsHelper from "../../helper/meta-tags-helper";
import { PageLoader } from "global/components/loaders/page-loader";
import { routeTo } from "global/utils/utils";
import { getAngularState } from "global/utils/angularState";

const CareerPage = () => {
  const { company } = useParams();
  const {
    data: accountDetails,
    isLoading: accountDetailsApiIsLoading,
    isSuccess,
  } = useGetAccountDetailsQuery(company);
  const language = useSelector((state) => state.user.language);
  const dispatch = useDispatch();

  useEffect(() => {
    if (!accountDetailsApiIsLoading) {
      document.documentElement.style.setProperty(
        "--company-profile-custom-color",
        `${accountDetails?.data.color}`,
      );
      document.documentElement.style.setProperty(
        "--ats-body-font-family",
        "sans-serif",
      );

      //set metadata
      if (accountDetails?.data.name) {
        document.title = accountDetails?.data.name;
      }
      metaTagsHelper.addMetaTagWithName(
        "description",
        accountDetails?.data.name,
      );
      metaTagsHelper.addMetaTagWithProperty(
        "og:description",
        accountDetails?.data.name,
      );
      metaTagsHelper.addMetaTagWithProperty(
        "og:title",
        accountDetails?.data.name,
      );
    }
  }, [accountDetails, accountDetailsApiIsLoading, language]);

  useEffect(() => {
    dispatch(setIsPublicPage(true));
    return () => {
      dispatch(setIsPublicPage(false));
    };
  }, [dispatch]);

  useEffect(() => {
    if (!accountDetailsApiIsLoading) {
      dispatch(setNavLogoName(accountDetails?.data.logo));
    }
  }, [accountDetails, accountDetailsApiIsLoading, dispatch]);

  useEffect(() => {
    dispatch(setAccountDataIsLoaded(isSuccess));

    return () => {
      dispatch(setAccountDataIsLoaded(false));
    };
  }, [isSuccess, dispatch]);

  if (!accountDetailsApiIsLoading && !accountDetails) {
    return !!getAngularState()
      ? routeTo("404")
      : window.location.replace("/404");
  }

  return (
    <div>
      {accountDetailsApiIsLoading ? (
        <PageLoader message="Loading / Chargement ..." />
      ) : (
        accountDetails && <CareerContainer accountData={accountDetails} />
      )}
    </div>
  );
};

export default CareerPage;
