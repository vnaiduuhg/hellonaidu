import PropTypes from "prop-types";
import {
  useEffect,
  useState,
  useLayoutEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import { Col, Row } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { nanoid } from "@reduxjs/toolkit";
import useFirstRender from "../../../hooks/use-first-render";
import PagePagination from "../../../components/pagination/page-pagination";
import { useGetLocationDetailsMutation } from "../../../services/about-us/location-details";
import { useDefaultUserDetailsApiMutation } from "../../../services/account-info/default-user-details";
import { usePublishedExternalApiMutation } from "../../../services/job-offers/published-external";
import { usePublishedInternalApiMutation } from "../../../services/job-offers/published-internal";
import {
  setCurrentPage,
  setLastPage,
  setPageSize,
} from "../../../slices/job-offers/pagination-slice";
import Filters from "./filters";
import JobList from "./job-lists";
import style from "./job-offers.module.css";
import utils from "../../../helper/utils";
import metaTagsHelper from "../../../helper/meta-tags-helper";
import RenderOnce from "../../../components/render-once/render-once";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { useHistory, useLocation } from "react-router-dom";
import {
  parseQuery,
  slugifyValue,
  stringifyQuery,
} from "atlas/public-pages/helper/query-param-helper";
import { useGetJobGroupsQuery } from "atlas/public-pages/services/job-offers/job-groups";

const JobOffers = ({ accountId, isAgency, isInternal, token, companyName }) => {
  const companySearchKeyword = useSelector(
    (state) => state.companySearchKeyword.searchKeyword,
  );
  const currentPage = useSelector((state) => state.pagination.currentPage);
  const lastPage = useSelector((state) => state.pagination.lastPage);
  const pageSize = useSelector((state) => state.pagination.pageSize);
  const [jobData, setJobData] = useState([]);
  const [groupJobs, setGroupJobs] = useState([]);
  const [locationIds, setLocationIds] = useState([]);
  const [totalData, setTotalData] = useState(0);
  const [companyIds, setCompanyIds] = useState([]);
  const [companyProfiles, setCompanyProfiles] = useState([]);
  const firstRender = useFirstRender();
  const [showSpinner, setShowSpinner] = useState(true);
  const dispatch = useDispatch();
  const { t: translate } = useTranslation();
  const updatedCurrentPage = useRef(-1);

  const [showError, setShowError] = useState(false);

  const [publishedExternalApi, { isLoading: isExternalLoading }] =
    usePublishedExternalApiMutation();

  const [publishedInternalApi, { isLoading: isInternalLoading, isError }] =
    usePublishedInternalApiMutation();

  const [locationDetailsApi] = useGetLocationDetailsMutation();

  const [defaultUserDetailsApi] = useDefaultUserDetailsApiMutation();

  const isJobsLoading = () =>
    isInternal ? isInternalLoading : isExternalLoading;

  const handlePaginationPageChanges = (pageNumber) => {
    updatedCurrentPage.current = pageNumber;
    dispatch(setCurrentPage(pageNumber));
  };

  const {
    data: jobGroups,
    isLoading: jobGroupsApiIsLoading,
    isSuccess: jobGroupsApiIsSuccess,
  } = useGetJobGroupsQuery({
    id: accountId,
    query: isAgency ? { include_clients_groups: 1 } : {},
  });

  const location = useLocation();
  const queryString = location.search.slice(1);
  const selectedJobGroups = useMemo(
    () => parseQuery(queryString ?? "").groups ?? [],
    [queryString],
  );

  const history = useHistory();

  const onSelectJobGroups = (value) => {
    let updatedselectedJobGroups = [...selectedJobGroups];

    const slugifiedValue = slugifyValue(value ?? "");

    if (value !== null) {
      const alreadySelected = selectedJobGroups.find(
        (item) => slugifyValue(item) === slugifiedValue,
      );
      if (alreadySelected) {
        updatedselectedJobGroups = selectedJobGroups.filter(
          (item) => slugifyValue(item) !== slugifiedValue,
        );
      } else {
        updatedselectedJobGroups = selectedJobGroups.concat(slugifiedValue);
      }
    } else {
      updatedselectedJobGroups = [];
    }
    history.push({
      pathname: location.pathname,
      search: stringifyQuery({
        ...(parseQuery(location.search.slice(1)) ?? {}),
        groups: updatedselectedJobGroups,
      }),
    });
  };

  const getJobsApi = useCallback(() => {
    const job_group_names = selectedJobGroups.length
      ? selectedJobGroups
          .map(
            (group) =>
              jobGroups.find((item) => slugifyValue(item.name) === group)?.name,
          )
          .filter((item) => item !== undefined)
      : undefined;

    return isInternal
      ? publishedInternalApi({
          internal_job_token: token,
          page: updatedCurrentPage.current,
          job_group_names,
          pageSize,
          ...(!isAgency && { account_ids: [accountId] }),
          ...(isAgency &&
            companySearchKeyword.trim().length && {
              company_name_search: utils.sanitizeInput(companySearchKeyword),
            }),
          ...(isAgency && { including_agency_account_ids: [accountId] }),
        })
      : publishedExternalApi({
          page: updatedCurrentPage.current,
          job_group_names,
          pageSize,
          ...(!isAgency && { account_ids: [accountId] }),
          ...(isAgency &&
            companySearchKeyword.trim().length && {
              company_name_search: utils.sanitizeInput(companySearchKeyword),
            }),
          ...(isAgency && { including_agency_account_ids: [accountId] }),
        });
  }, [
    accountId,
    companySearchKeyword,
    isAgency,
    isInternal,
    pageSize,
    publishedExternalApi,
    publishedInternalApi,
    selectedJobGroups,
    token,
    jobGroups,
  ]);

  useLayoutEffect(() => {
    setShowError(isInternal && token && isError);
  }, [isInternal, token, isError]);

  useEffect(() => {
    metaTagsHelper.addMetaTagWithProperty("og:url", window.location.href);
  }, []);

  useEffect(() => {
    setGroupJobs([]);
    setJobData([]);
  }, [isInternal]);

  useEffect(() => {
    if (!firstRender) {
      updatedCurrentPage.current = 1;
      dispatch(setCurrentPage(1));
    }
  }, [companySearchKeyword, dispatch, firstRender]);

  useEffect(() => {
    if (updatedCurrentPage.current < 0) {
      updatedCurrentPage.current = currentPage;
    }

    if (jobGroupsApiIsLoading || !jobGroupsApiIsSuccess) return;

    getJobsApi().then((UserData) => {
      if (UserData.error !== undefined) return;

      setJobData(
        UserData.data.data.map((job) => {
          return { ...job, nanoid: nanoid() };
        }),
      );
      updatedCurrentPage.current = UserData.data.current_page;
      dispatch(setCurrentPage(UserData.data.current_page));
      dispatch(setLastPage(UserData.data.last_page));
      dispatch(setPageSize(UserData.data.per_page));
      setTotalData(UserData.data.total);

      const locationIdSet = new Set();
      const accountIdSet = new Set();
      UserData.data.data.forEach((job) => {
        const { locations, account_id: profileId } = job;
        locations.forEach((item) => locationIdSet.add(item.location_id));
        accountIdSet.add(profileId);
      });

      setLocationIds(Array.from(locationIdSet));
      setCompanyIds(Array.from(accountIdSet));
    });
  }, [
    currentPage,
    accountId,
    selectedJobGroups,
    pageSize,
    publishedExternalApi,
    companySearchKeyword,
    isInternal,
    dispatch,
    getJobsApi,
    jobGroupsApiIsLoading,
    jobGroupsApiIsSuccess,
  ]);

  useEffect(() => {
    if (companyIds.length) {
      defaultUserDetailsApi({
        account_ids: [...companyIds],
      }).then((companyData) => {
        const arr = Object.keys(companyData.data.data).map(
          (k) => companyData.data.data[k],
        );
        setCompanyProfiles(arr);
      });
    }
  }, [companyIds, defaultUserDetailsApi]);

  useEffect(() => {
    if (locationIds.length) {
      locationDetailsApi({
        key: "id",
        "values[]": locationIds,
      }).then((locationData) => {
        const jobDataWithLocation = jobData.map((job) => {
          const city = job.locations.length
            ? locationData.data[job.locations[0].location_id]?.city
            : "";
          const province = job.locations.length
            ? locationData.data[job.locations[0].location_id]?.province
            : "";
          return { ...job, city, province };
        });

        jobDataWithLocation.sort((a, b) =>
          `${a.city}, ${a.province}`.localeCompare(`${b.city}, ${b.province}`),
        );

        setJobData(jobDataWithLocation);
        if (isAgency) {
          const map = new Map();
          jobDataWithLocation.forEach((job) =>
            !map.has(job.account_id)
              ? map.set(job.account_id, [job])
              : map.get(job.account_id).push(job),
          );
          setGroupJobs([...map]);
        }
      });
    } else {
      setJobData([]);
      setGroupJobs([]);
    }
  }, [locationIds, locationDetailsApi, isAgency]);

  const handleSpinner = () => {
    setShowSpinner(false);
  };

  return (
    <Row className="mx-1 mx-sm-5 pb-4">
      {showError && (
        <div className={style.invalidTokenWarning}>
          {translate("feature-not-activated", { companyName })}
        </div>
      )}
      <Filters
        accountId={accountId}
        selectedFilters={selectedJobGroups}
        onSelectFilter={onSelectJobGroups}
        isAgency={isAgency}
      />

      {showSpinner && isJobsLoading() ? (
        <RenderOnce handleRender={handleSpinner}>
          <ComponentLoader />
        </RenderOnce>
      ) : (
        <Col xs={12} className="px-3 py-4">
          {locationIds.length > 0 &&
            (isAgency ? (
              groupJobs.map((group) => {
                return (
                  <div className={style.companyPageGroup} key={group[0]}>
                    <div className="p-1">
                      <div className={style.companyPageGroupTitle}>
                        <h5>
                          {
                            companyProfiles.filter((profile) => {
                              return profile.account_id === group[0];
                            })[0]?.name
                          }
                        </h5>
                      </div>

                      <JobList
                        jobData={group[1]}
                        isInternal={isInternal}
                        isAgency={isAgency}
                      />
                    </div>
                  </div>
                );
              })
            ) : (
              <div className={style.jobList}>
                <JobList
                  jobData={jobData}
                  isInternal={isInternal}
                  isAgency={isAgency}
                />
              </div>
            ))}
        </Col>
      )}

      {!isJobsLoading() && totalData !== 0 && (
        <section className="d-flex justify-content-center">
          <PagePagination
            currentPage={currentPage}
            handlePageChanges={handlePaginationPageChanges}
            numberOfPages={lastPage}
          />
        </section>
      )}
    </Row>
  );
};

JobOffers.propTypes = {
  accountId: PropTypes.number.isRequired,
  isAgency: PropTypes.bool,
  isInternal: PropTypes.bool,
  token: PropTypes.string,
  companyName: PropTypes.string,
};

JobOffers.defaultProps = {
  isAgency: false,
  isInternal: false,
  token: "",
  companyName: "",
};

export default JobOffers;
