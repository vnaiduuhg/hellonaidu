import React from "react";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import useQuery from "../../../hooks/use-query";
import utils from "../../../helper/utils";
import SingleJobContent from "../../../components/job-summary/job-summary";
import descriptionParser from "../../../helper/description-parser";
import jobProps from "./job-offers-props";
import style from "./job-offers.module.css";

const JobList = ({ jobData, isInternal, isAgency }) => {
  const { t, i18n } = useTranslation();
  const token = useQuery().get("token") ?? "";

  const loadJobContents = () => {
    return jobData.map((job) => {
      let tempTitle = job.translations.find(
        (lang) => lang.locale === i18n.language,
      ).title;
      if (tempTitle === null) {
        for (const lang of job.translations) {
          tempTitle = tempTitle || lang.title;
        }
      }
      const title = tempTitle;

      const getGroupByLanguage = (trans) => {
        return trans.find((lang) => lang.locale === i18n.language).name;
      };

      const groupTexts = [];
      job.groups.forEach((group) => {
        groupTexts.push(getGroupByLanguage(group.translations));
      });

      const tempData = job.translations.find(
        (lang) => lang.locale === i18n.language,
      );

      let DescriptionSummary = "...";
      if (tempData.summary) DescriptionSummary = tempData.summary;
      else if (tempData.description)
        DescriptionSummary = descriptionParser(tempData.description);

      const summary = DescriptionSummary;

      let location = t("no-job-location");
      if (job.locations.length > 0) {
        location = `${job.city}, ${job.province}`;
      }

      const otherLocations = job.locations.length > 1;

      const jobUrl = `/work/${job.id}/${job.url}${
        isInternal && token ? `?token=${encodeURIComponent(token)}` : ""
      }`;

      return (
        <Link to={jobUrl} key={job.nanoid} className={style.jobListLink}>
          <motion.div
            animate={
              true && {
                scale: [0, 1],
                opacity: [0, 1],
              }
            }
            transition={{ duration: 0.4 }}
            style={{
              originY: 1,
              paddingLeft: `${isAgency && "15px"}`,
              paddingRight: `${isAgency && "15px"}`,
            }}
          >
            <SingleJobContent
              expiryDate={
                !isInternal
                  ? job.external_expiry_date
                  : job.internal_expiry_date
              }
              title={title}
              groups={groupTexts.sort((a, b) =>
                utils.strCompare(a.toLowerCase(), b.toLowerCase()),
              )}
              description={summary}
              address={location}
              otherLocations={otherLocations}
              className={style.jobContent}
            />
          </motion.div>
        </Link>
      );
    });
  };

  return <section>{loadJobContents()}</section>;
};

JobList.propTypes = {
  jobData: jobProps.isRequired,
  isInternal: PropTypes.bool,
  isAgency: PropTypes.bool,
};

JobList.defaultProps = {
  isInternal: false,
  isAgency: false,
};

export default React.memo(JobList);
