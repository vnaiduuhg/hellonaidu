import PropTypes from "prop-types";

const jobGroupTranslationProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    name: PropTypes.string,
    locale: PropTypes.string,
  }),
);

const jobGroupsProps = PropTypes.arrayOf(
  PropTypes.shape({
    id: PropTypes.number,
    name: PropTypes.string,
    translations: jobGroupTranslationProps,
  }),
);

const jobLocationProps = PropTypes.arrayOf(
  PropTypes.shape({
    location_id: PropTypes.number,
  }),
);

const jobTranslationsProps = PropTypes.arrayOf(
  PropTypes.shape({
    description: PropTypes.string,
    id: PropTypes.number,
    locale: PropTypes.string,
    summary: PropTypes.string,
    title: PropTypes.string,
  }),
);

const jobProps = PropTypes.arrayOf(
  PropTypes.shape({
    external_expiry_date: PropTypes.string,
    groups: jobGroupsProps,
    id: PropTypes.number,
    locations: jobLocationProps,
    translations: jobTranslationsProps,
  }),
);

export default jobProps;
