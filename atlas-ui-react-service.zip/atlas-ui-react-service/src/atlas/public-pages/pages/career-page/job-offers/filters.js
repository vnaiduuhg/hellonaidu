import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import { Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import utils from "../../../helper/utils";
import FilterButton from "../../../components/buttons/filter-button/filter-button";
import ResetButton from "../../../components/buttons/reset-button/reset-button";
import SearchBar from "../../../components/search/search";
import blur from "../../../helper/blur";
import { useGetJobGroupsQuery } from "../../../services/job-offers/job-groups";
import style from "./job-offers.module.css";
import { setCompanySearchKeyword } from "../../../slices/job-offers/company-search-slice";

const Filters = ({ accountId, selectedFilters, onSelectFilter, isAgency }) => {
  const companySearchKeyword = useSelector(
    (state) => state.companySearchKeyword.searchKeyword,
  );
  const [localSearchKey, setLocalSearchKey] = useState(companySearchKeyword);
  const [sortedJobGroups, setSortedJobGroups] = useState([]);
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();

  const { data: jobGroups, isLoading: jobGroupsApiIsLoading } =
    useGetJobGroupsQuery({
      id: accountId,
      query: isAgency ? { include_clients_groups: 1 } : {},
    });

  useEffect(() => {
    if (jobGroups && jobGroups.length) {
      const sortedGroups = [...jobGroups];
      sortedGroups.sort((a, b) => {
        const aName = a.translations.find(
          (trans) => trans.locale === i18n.language,
        )?.name;
        const bName = b.translations.find(
          (trans) => trans.locale === i18n.language,
        )?.name;
        return utils.strCompare(aName.toLowerCase(), bName.toLowerCase());
      });
      setSortedJobGroups(sortedGroups);
    }
  }, [jobGroups, i18n.language]);

  const clearSearchGroups = () => {
    blur();
    setLocalSearchKey("");
    dispatch(setCompanySearchKeyword(""));
    onSelectFilter(null);
  };

  const onSearch = (searchKey) => {
    dispatch(setCompanySearchKeyword(searchKey));
  };

  const getDiplayText = () => {
    return (
      <>
        <span>{t("filtered-jobs")}</span> [{" "}
        {localSearchKey.trim().length ? (
          <>
            {t("company-name")}: <i>{`" ${localSearchKey} "`}</i>
            {selectedFilters.length ? " & " : ""}
          </>
        ) : (
          ""
        )}
        {selectedFilters.length
          ? selectedFilters
              .map((item) => {
                return jobGroups
                  .filter((group) => {
                    return group.name === item;
                  })[0]
                  .translations.find((trans) => trans.locale === i18n.language)
                  .name;
              })
              .join(` ${t("or")} `)
          : ""}{" "}
        ]
      </>
    );
  };

  return (
    <>
      <section className="col-xs-12">
        {!jobGroupsApiIsLoading &&
          sortedJobGroups.map((item) => {
            const buttonText = item.translations.find(
              (trans) => trans.locale === i18n.language,
            ).name;

            return (
              <FilterButton
                key={item.id}
                buttonText={buttonText}
                buttonName={item.name}
                selectedFilters={selectedFilters}
                onSelectFilter={onSelectFilter}
              />
            );
          })}
      </section>
      <div className={`ps-3 pt-3 ${style.seachWraper}`}>
        {isAgency && (
          <SearchBar
            placeholder={t("company-name")}
            localSearchKey={localSearchKey}
            onSearchLocal={setLocalSearchKey}
            onSearch={onSearch}
          />
        )}
        {!jobGroupsApiIsLoading && jobGroups.length > 0 && (
          <ResetButton
            clearSearch={clearSearchGroups}
            buttonText={t("reset-button")}
            className={`${!isAgency && style.resetButton}`}
          />
        )}
      </div>
      {isAgency && (
        <Col xs={12} className={`${style.filterText} px-3 pt-3`}>
          <span className="fw-bold">{t("display")}: </span>
          <span>
            {!selectedFilters.length && !companySearchKeyword.length
              ? t("all-jobs")
              : getDiplayText()}
          </span>
        </Col>
      )}
    </>
  );
};

Filters.propTypes = {
  accountId: PropTypes.number.isRequired,
  selectedFilters: PropTypes.arrayOf(PropTypes.string).isRequired,
  onSelectFilter: PropTypes.func.isRequired,
  isAgency: PropTypes.bool.isRequired,
};

Filters.defaultProps = {};

export default Filters;
