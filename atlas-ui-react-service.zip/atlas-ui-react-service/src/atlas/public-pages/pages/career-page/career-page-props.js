import PropTypes from "prop-types";

// Location API Props
const LocationTransProps = PropTypes.arrayOf(
  PropTypes.shape({
    city: PropTypes.string,
    country: PropTypes.string,
    id: PropTypes.number,
    locale: PropTypes.string,
    province: PropTypes.string,
    region: PropTypes.string,
    street: PropTypes.string,
  }),
);

export const locationProps = PropTypes.shape({
  locationId: PropTypes.shape({
    city: PropTypes.string,
    country: PropTypes.string,
    id: PropTypes.number,
    postal_code: PropTypes.string,
    province: PropTypes.string,
    region: PropTypes.string,
    street: PropTypes.string,
    street_number: PropTypes.string,
    translation: LocationTransProps,
  }),
});

// Account details API Props
const languageProps = PropTypes.shape({
  benefits: PropTypes.string,
  section_title: PropTypes.string,
  success: PropTypes.string,
  summary: PropTypes.string,
});

export const translationProps = PropTypes.shape({
  en: languageProps,
  fn: languageProps,
});

const dataProps = PropTypes.shape({
  account_id: PropTypes.number,
  banner: PropTypes.string,
  color: PropTypes.string,
  id: PropTypes.number,
  location_id: PropTypes.number,
  logo: PropTypes.string,
  alternate_logo_1: PropTypes.string,
  name: PropTypes.string,
  phone: PropTypes.string,
  slug: PropTypes.string,
  translation: translationProps,
});

export const accountDataProps = PropTypes.shape({
  code: PropTypes.number,
  data: dataProps,
  status: PropTypes.string,
});
