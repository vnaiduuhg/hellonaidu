import PropTypes from "prop-types";
import { Container } from "react-bootstrap";
import BannerAndCenteredLogo from "../../components/banner-and-logo/banner-and-centered-logo";
import TitleAndAdress from "../../components/title-and-adress/title-and-address";
import { generateFullAddress } from "../../helper/address";
import { locationProps } from "./career-page-props";
import style from "./career-page.module.css";

const CareerPageContentWrapper = ({
  children,
  companyName,
  locationDetails,
  companyPhone,
  bannerName,
  logoName,
}) => {
  const address = generateFullAddress(locationDetails);

  return (
    <Container className={`${style.mainPage} px-0 mt-5`}>
      <BannerAndCenteredLogo bannerName={bannerName} logoName={logoName} />

      <TitleAndAdress
        companyName={companyName}
        fullLocation={address}
        companyPhone={companyPhone}
      />

      {children}
    </Container>
  );
};

CareerPageContentWrapper.propTypes = {
  children: PropTypes.node.isRequired,
  companyName: PropTypes.string.isRequired,
  locationDetails: locationProps,
  companyPhone: PropTypes.string,
  bannerName: PropTypes.string,
  logoName: PropTypes.string,
};

CareerPageContentWrapper.defaultProps = {
  companyPhone: "",
  bannerName: "",
  logoName: "",
  locationDetails: null,
};

export default CareerPageContentWrapper;
