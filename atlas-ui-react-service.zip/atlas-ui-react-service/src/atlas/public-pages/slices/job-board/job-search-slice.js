import { createSlice } from "@reduxjs/toolkit";
import utils from "../../helper/utils";

const SearchKwds = {
  job: "jobSearch",
  companyName: "companyName",
  locationText: "locationText",
  locationData: "locationData",
};

const initialState = {
  companyNameSearch: utils.getSessionStorageItem(SearchKwds.companyName) || "",
  search: utils.getSessionStorageItem(SearchKwds.job) || "",
  location: {
    data: utils.getSessionStorageItem(SearchKwds.locationData)
      ? JSON.parse(utils.getSessionStorageItem(SearchKwds.locationData))
      : [],
    text: utils.getSessionStorageItem(SearchKwds.locationText) || "",
  },
};

export const jobSearchSlice = createSlice({
  name: "jobSearch",
  initialState,
  reducers: {
    setCompanySearchKeyword: (state, action) => {
      state.companyNameSearch = action.payload;
      utils.setOrRemoveItemFromSessionStorage(
        SearchKwds.companyName,
        state.companyNameSearch,
      );
    },
    setJobKeyword: (state, action) => {
      state.search = action.payload;
      utils.setOrRemoveItemFromSessionStorage(SearchKwds.job, state.search);
    },
    setLocationKeyword: (state, action) => {
      state.location = action.payload;

      utils.setOrRemoveItemFromSessionStorage(
        SearchKwds.locationText,
        state.location.text,
      );
      utils.setOrRemoveItemFromSessionStorage(
        SearchKwds.locationData,
        state.location.data.length ? JSON.stringify(state.location.data) : "",
      );
    },
    clearSearchParams: (state) => {
      state.companyNameSearch = "";
      state.search = "";
      state.location = { data: [], text: "" };

      utils.removeItemSessionStorage(
        SearchKwds.job,
        SearchKwds.companyName,
        SearchKwds.locationText,
        SearchKwds.locationData,
      );
    },
  },
});

export const {
  setCompanySearchKeyword,
  setJobKeyword,
  setLocationKeyword,
  clearSearchParams,
} = jobSearchSlice.actions;

export default jobSearchSlice.reducer;
