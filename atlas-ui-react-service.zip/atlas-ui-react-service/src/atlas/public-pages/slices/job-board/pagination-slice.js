import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  currentPage: 1,
  lastPage: 0,
  pageSize: 10,
};

export const paginationSlice = createSlice({
  name: "pagination",
  initialState,
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setLastPage: (state, action) => {
      state.lastPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
  },
});

export const { setCurrentPage, setLastPage, setPageSize } =
  paginationSlice.actions;

export default paginationSlice.reducer;
