import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  logoName: "",
  isPublicPage: false,
  isJobDetailsPage: false,
  accountDataIsLoaded: false,
};

export const publicPageSlice = createSlice({
  name: "publicPage",
  initialState,
  reducers: {
    setNavLogoName: (state, name) => {
      state.logoName = name;
    },
    setAccountDataIsLoaded: (state, action) => {
      state.accountDataIsLoaded = action.payload;
    },
    setIsJobDetailsPage: (state, jobDetailsPage) => {
      state.isJobDetailsPage = jobDetailsPage;
    },
    setIsPublicPage: (state, show) => {
      state.isPublicPage = show;
    },
  },
});

export const {
  setNavLogoName,
  setAccountDataIsLoaded,
  setIsJobDetailsPage,
  setIsPublicPage,
} = publicPageSlice.actions;

export default publicPageSlice.reducer;
