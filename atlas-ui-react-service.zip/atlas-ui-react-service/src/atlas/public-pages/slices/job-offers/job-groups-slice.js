import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  selectedGroups: [],
};

export const jobGroupsSlice = createSlice({
  name: "selectedJobGroups",
  initialState,
  reducers: {
    setSelectedGroups: (state, action) => {
      state.selectedGroups = action.payload;
    },
  },
});

export const { setSelectedGroups } = jobGroupsSlice.actions;

export default jobGroupsSlice.reducer;
