import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  searchKeyword: "",
};

export const companySearchSlice = createSlice({
  name: "companySearch",
  initialState,
  reducers: {
    setCompanySearchKeyword: (state, action) => {
      state.searchKeyword = action.payload;
    },
  },
});

export const { setCompanySearchKeyword } = companySearchSlice.actions;

export default companySearchSlice.reducer;
