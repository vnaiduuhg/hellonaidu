export const ENGLISH_LOCALE_CODE = "en";
export const FRENCH_LOCALE_CODE = "fr";
export const GENERIC_LOGO = "generic_logo.png";
export const GENERIC_BANNER = "generic_banner.jpg";
