import PropTypes from "prop-types";

const ExpireClockIcon = ({ width, height }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      id="clock-circular-outline"
      width={width}
      height={height}
      viewBox="0 0 16 16"
    >
      <g id="Group_49" data-name="Group 49">
        <path
          id="Path_38"
          data-name="Path 38"
          d="M8,0a8,8,0,1,0,8,8A8.009,8.009,0,0,0,8,0ZM8,14.251A6.251,6.251,0,1,1,14.251,8,6.258,6.258,0,0,1,8,14.251Z"
          fill="#9e9eb5"
        />
        <path
          id="Path_39"
          data-name="Path 39"
          d="M258.144,143.286v-3.353a.678.678,0,1,0-1.355,0v3.57c0,.011,0,.021,0,.031a.674.674,0,0,0,.2.512l2.524,2.524a.678.678,0,1,0,.958-.958Z"
          transform="translate(-249.452 -135.276)"
          fill="#9e9eb5"
        />
      </g>
    </svg>
  );
};

ExpireClockIcon.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
};

ExpireClockIcon.defaultProps = {
  width: "16",
  height: "16",
};

export default ExpireClockIcon;
