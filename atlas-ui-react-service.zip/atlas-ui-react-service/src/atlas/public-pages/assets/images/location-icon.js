import PropTypes from "prop-types";

const LocationIcon = ({ width, height }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 16 16"
    >
      <defs>
        <clipPath id="clipPath">
          <rect
            id="Rectangle_256"
            data-name="Rectangle 256"
            width="16"
            height="16"
            transform="translate(828 153)"
            fill="#4d4d50"
          />
        </clipPath>
      </defs>
      <g
        id="Mask_Group_88"
        data-name="Mask Group 88"
        transform="translate(-828 -153)"
        clipPath="url(#clipPath)"
      >
        <g id="location" transform="translate(828.969 153)">
          <g id="Group_410" data-name="Group 410">
            <g id="Group_409" data-name="Group 409">
              <path
                id="Path_261"
                data-name="Path 261"
                d="M10.489,10.571c1.7-2.672,1.489-2.338,1.538-2.408a5.118,5.118,0,0,0,.948-2.976A5.156,5.156,0,1,0,3.637,8.2l1.51,2.37c-1.615.248-4.36.988-4.36,2.616,0,.594.387,1.44,2.233,2.1a14.8,14.8,0,0,0,4.8.714c3.376,0,7.031-.952,7.031-2.812C14.85,11.559,12.108,10.82,10.489,10.571ZM4.42,7.686,4.4,7.662a4.219,4.219,0,1,1,6.863-.047c-.045.06.19-.306-3.449,5.4Zm3.4,7.377c-3.687,0-6.094-1.084-6.094-1.875,0-.532,1.236-1.406,3.977-1.747l1.722,2.7a.469.469,0,0,0,.791,0l1.722-2.7c2.74.341,3.977,1.215,3.977,1.747C13.912,13.972,11.527,15.063,7.818,15.063Z"
                transform="translate(-0.787)"
                fill="#4d4d50"
              />
            </g>
          </g>
          <g
            id="Group_412"
            data-name="Group 412"
            transform="translate(4.688 2.844)"
          >
            <g id="Group_411" data-name="Group 411">
              <path
                id="Path_262"
                data-name="Path 262"
                d="M6.939,2.311A2.344,2.344,0,1,0,9.283,4.654,2.346,2.346,0,0,0,6.939,2.311Zm0,3.75A1.406,1.406,0,1,1,8.346,4.654,1.408,1.408,0,0,1,6.939,6.061Z"
                transform="translate(-4.596 -2.311)"
                fill="#4d4d50"
              />
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
};

LocationIcon.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
};

LocationIcon.defaultProps = {
  width: "16",
  height: "16",
};

export default LocationIcon;
