import PropTypes from "prop-types";

const CompanyBuildingIcon = ({ width, height }) => {
  return (
    <svg width={width} height={height} viewBox="0 0 16 16">
      <defs>
        <clipPath id="clip-path">
          <rect
            id="Rectangle_254"
            data-name="Rectangle 254"
            width="16"
            height="16"
            transform="translate(580 153)"
            fill="#4d4d50"
          />
        </clipPath>
      </defs>
      <g
        id="Mask_Group_87"
        data-name="Mask Group 87"
        transform="translate(-580 -153)"
        clipPath="url(#clip-path)"
      >
        <g id="XMLID_1_" transform="translate(580 153.06)">
          <path
            id="Path_244"
            data-name="Path 244"
            d="M7.646,4.924,13.519,6.09a.985.985,0,0,1,.793.973v6.8a1,1,0,0,1-1,1h-6a.33.33,0,0,0,.333-.333V14.2h5.667a.334.334,0,0,0,.333-.333v-6.8a.335.335,0,0,0-.26-.327L7.646,5.6Z"
            transform="translate(1.687 1.016)"
            fill="#4d4d50"
          />
          <path
            id="Path_245"
            data-name="Path 245"
            d="M10.875,7.583a.333.333,0,1,1,0,.667H9.542a.333.333,0,0,1,0-.667Z"
            transform="translate(2.125 1.63)"
            fill="#4d4d50"
          />
          <path
            id="Path_246"
            data-name="Path 246"
            d="M10.875,9.208a.333.333,0,1,1,0,.667H9.542a.333.333,0,0,1,0-.667Z"
            transform="translate(2.125 2.005)"
            fill="#4d4d50"
          />
          <path
            id="Path_247"
            data-name="Path 247"
            d="M10.875,10.833a.333.333,0,0,1,0,.667H9.542a.333.333,0,0,1,0-.667Z"
            transform="translate(2.125 2.38)"
            fill="#4d4d50"
          />
          <path
            id="Path_248"
            data-name="Path 248"
            d="M7.708,14.542a.333.333,0,0,1-.667,0V5.208a.354.354,0,0,1,.12-.26.35.35,0,0,1,.28-.067l.267.053v9.607Z"
            transform="translate(1.625 1.005)"
            fill="#4d4d50"
          />
          <path
            id="Path_249"
            data-name="Path 249"
            d="M7.479,12.458v.333a.33.33,0,0,0,.333.333H5.146a.33.33,0,0,0,.333-.333v-.333Z"
            transform="translate(1.187 2.755)"
            fill="#4d4d50"
          />
          <path
            id="Path_250"
            data-name="Path 250"
            d="M6,2.708a.333.333,0,1,1,0,.667H4.667a.333.333,0,1,1,0-.667Z"
            transform="translate(1 0.505)"
            fill="#4d4d50"
          />
          <path
            id="Path_251"
            data-name="Path 251"
            d="M6.333,4.667A.33.33,0,0,1,6,5H4.667a.333.333,0,1,1,0-.667H6A.33.33,0,0,1,6.333,4.667Z"
            transform="translate(1 0.88)"
            fill="#4d4d50"
          />
          <path
            id="Path_252"
            data-name="Path 252"
            d="M6,5.958a.333.333,0,0,1,0,.667H4.667a.333.333,0,1,1,0-.667Z"
            transform="translate(1 1.255)"
            fill="#4d4d50"
          />
          <path
            id="Path_253"
            data-name="Path 253"
            d="M6,7.583A.333.333,0,1,1,6,8.25H4.667a.333.333,0,1,1,0-.667Z"
            transform="translate(1 1.63)"
            fill="#4d4d50"
          />
          <path
            id="Path_254"
            data-name="Path 254"
            d="M3.625,7.917a.33.33,0,0,1-.333.333H1.958a.333.333,0,1,1,0-.667H3.292A.33.33,0,0,1,3.625,7.917Z"
            transform="translate(0.375 1.63)"
            fill="#4d4d50"
          />
          <path
            id="Path_255"
            data-name="Path 255"
            d="M3.292,2.708a.333.333,0,1,1,0,.667H1.958a.333.333,0,1,1,0-.667Z"
            transform="translate(0.375 0.505)"
            fill="#4d4d50"
          />
          <path
            id="Path_256"
            data-name="Path 256"
            d="M3.292,4.333a.333.333,0,1,1,0,.667H1.958a.333.333,0,1,1,0-.667Z"
            transform="translate(0.375 0.88)"
            fill="#4d4d50"
          />
          <path
            id="Path_257"
            data-name="Path 257"
            d="M3.292,5.958a.333.333,0,1,1,0,.667H1.958a.333.333,0,1,1,0-.667Z"
            transform="translate(0.375 1.255)"
            fill="#4d4d50"
          />
          <path
            id="Path_258"
            data-name="Path 258"
            d="M5.5,10.208a.334.334,0,0,0-.333-.333h-2a.33.33,0,0,0-.333.333v3H2.167v-3a1,1,0,0,1,1-1h2a1,1,0,0,1,1,1v3H5.5Z"
            transform="translate(0.5 2.005)"
            fill="#4d4d50"
          />
          <path
            id="Path_259"
            data-name="Path 259"
            d="M2.833,12.458H6.167v.333a.33.33,0,0,1-.333.333H2.5a.33.33,0,0,1-.333-.333v-.333Z"
            transform="translate(0.5 2.755)"
            fill="#4d4d50"
          />
          <path
            id="Path_260"
            data-name="Path 260"
            d="M1.167.111,8.493,1.224a1,1,0,0,1,.84.987V6.037l-.267-.053a.35.35,0,0,0-.28.067.354.354,0,0,0-.12.26v-4.1a.337.337,0,0,0-.28-.333L1.06.771A.185.185,0,0,0,1,.764a.314.314,0,0,0-.213.08.319.319,0,0,0-.12.253v13.88A.334.334,0,0,0,1,15.311H2.667v.333A.33.33,0,0,0,3,15.977H1a1,1,0,0,1-1-1V1.1A.982.982,0,0,1,.353.337,1,1,0,0,1,1.167.111Z"
            transform="translate(0 -0.098)"
            fill="#4d4d50"
          />
        </g>
      </g>
    </svg>
  );
};

CompanyBuildingIcon.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
};

CompanyBuildingIcon.defaultProps = {
  width: "16",
  height: "16",
};

export default CompanyBuildingIcon;
