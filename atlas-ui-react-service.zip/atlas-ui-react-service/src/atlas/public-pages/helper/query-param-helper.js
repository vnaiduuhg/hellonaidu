import { parse, stringify } from "qs";
import slugify from "slugify";

export const slugifyValue = (str) => slugify(str, { lower: true });

export const stringifyQuery = (query) =>
  stringify(query, {
    arrayFormat: "brackets",
    encodeValuesOnly: true,
    skipNulls: true,
  });

export const parseQuery = (query) =>
  parse(query, { parseArrays: true, arrayLimit: 256 });
