import parser from "html-react-parser";

const descriptionParser = (rawText) => {
  if (!rawText) return "";

  const reg = /<\/?[^>]+(>|$)/g;
  const textWithoutHtmlTag = rawText.replace(reg, "");
  const cleanText = parser(textWithoutHtmlTag);

  return `${cleanText.substring(0, 300)}...`;
};

export default descriptionParser;
