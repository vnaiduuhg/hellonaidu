const generateFullAddress = (locationData, addCountry = true) => {
  let address = "";
  if (locationData) {
    const {
      street_number: streetNumber,
      street,
      city,
      province,
      country,
      postal_code: postalCode,
    } = locationData;

    if (streetNumber) {
      address += `${streetNumber} `;
    }
    if (street) {
      address += `${street}, `;
    }
    if (city) {
      address += `${city}, `;
    }
    if (province) {
      address += province;
    }
    if (country && addCountry) {
      address += province && ", ";
      address += `${country},`;
    }
    if (postalCode) {
      address += ` ${postalCode}`;
    }

    if (
      address.length > 1 &&
      address[address.length - 2] === "," &&
      address[address.length - 1] === " "
    ) {
      address = address.slice(0, -2);
    }
  }

  return address;
};

const generateShortAddress = (locationData) => {
  let address = "";
  if (locationData) {
    const { city, province } = locationData;

    address = `${city},${province}`;
  }
  return address;
};
export { generateShortAddress, generateFullAddress };
