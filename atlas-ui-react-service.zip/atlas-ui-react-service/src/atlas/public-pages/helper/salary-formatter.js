function addCommaForThousands(amount) {
  return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getSalaryFormat(salary) {
  let salaryFormatted = (salary / 100).toFixed(2);
  // check if the amount needs comma (for thousands)
  const regex = /^(\d+)\.?\d{0,2}/g;
  const amountMatched = regex.exec(salaryFormatted.toString());
  if (amountMatched[1].length > 3) {
    salaryFormatted = addCommaForThousands(salaryFormatted);
  }
  return salaryFormatted;
}

function getSalaryFormatter(salary) {
  const resultSalary = {};
  resultSalary.minAmount = getSalaryFormat(salary.min_amount);
  resultSalary.maxAmount = null;
  if (salary.min_amount !== salary.max_amount) {
    resultSalary.maxAmount = getSalaryFormat(salary.max_amount);
  }

  return resultSalary;
}

export default getSalaryFormatter;
