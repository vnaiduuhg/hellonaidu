import moment from "moment";
import "moment/locale/fr-ca";
import "moment-timezone";

function handleArrayAsQueryParamter(key, arr) {
  arr = arr.map((item) => `${key}=${item}`);
  const joined = arr.join("&");
  return !!joined ? joined : `${key}=[]`;
}

function encode(val) {
  return encodeURI(val).replace("+", "%2B");
}

function removeAccents(strAccentsin) {
  const strAccents = strAccentsin.split("");
  let strAccentsOut = [];
  const strAccentsLen = strAccents.length;
  const accents =
    "ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž";
  const accentsOut =
    "AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz";
  for (let y = 0; y < strAccentsLen; y += 1) {
    if (accents.indexOf(strAccents[y]) !== -1) {
      strAccentsOut[y] = accentsOut.substring(
        accents.indexOf(strAccents[y]),
        accents.indexOf(strAccents[y]) + 1,
      );
    } else strAccentsOut[y] = strAccents[y];
  }
  strAccentsOut = strAccentsOut.join("");
  return strAccentsOut;
}

const utils = {
  generateQueryString: (query = {}, isFirstParam = true) => {
    let queryString = "";
    let first = isFirstParam;
    let queryParameter;

    for (const queryKey in query) {
      if ({}.hasOwnProperty.call(query, queryKey)) {
        const delimiter = first ? "?" : "&";
        first = false;
        const isObjectKey = typeof query[queryKey] === "object";
        const isArrayKey = Array.isArray(query[queryKey]);

        if (isArrayKey) {
          queryParameter = handleArrayAsQueryParamter(
            queryKey,
            query[queryKey],
          );
        } else if (isObjectKey) {
          queryParameter = `${queryKey}=${JSON.stringify(query[queryKey])}`;
        } else {
          queryParameter = `${queryKey}=${query[queryKey]}`;
        }
        queryString += delimiter + queryParameter;
      }
    }

    return queryString;
  },

  buildUrl: (urlTemplate, params, query = {}, isFirstParam = true) => {
    let paramNames;
    let url = urlTemplate;
    const paramRegex = /{(.+?)}/m;

    do {
      paramNames = paramRegex.exec(url);
      if (
        paramNames &&
        Object.prototype.hasOwnProperty.call(params, paramNames[1])
      ) {
        url = url.replace(paramNames[0], params[paramNames[1]]);
      }
    } while (paramNames);

    url += query ? utils.generateQueryString(query, isFirstParam) : "";

    return encode(url);
  },

  sanitizeInput: (input) => {
    if (!input) {
      return input;
    }

    let inputCleaned = removeAccents(input).toString().toLowerCase();
    inputCleaned = inputCleaned
      .replace("-", " ")
      .replace(/[^a-zA-Z0-9'\s]/gi, "")
      .replace(/ +/, " ")
      .trim();
    return inputCleaned;
  },

  strCompare: (a, b) => {
    return a > b ? 1 : -1;
  },

  getTimeFormat: (date, preset, language) => {
    if (language === "fr") {
      moment.locale("fr-ca");
    } else {
      moment.locale("en");
    }
    return moment(date).format(preset);
  },

  utcToTimezone: (datetime) => {
    const dateTimeMoment = moment.tz(datetime, "UTC");
    const convertedDate = moment.utc(dateTimeMoment).local();
    return convertedDate.format("YYYY-MM-DD HH:mm:ss");
  },

  isDateExpired: (date, localTime) => {
    // this function compares the raw timestamp (YYYY-MM-DD hh:mm:ss) with current time
    const now = new Date();
    const expiryDate = new Date(date);
    if (!localTime) {
      // the now time is local timezone but database time is GMT, so we must adjust for that when comparing
      return (
        now.getTime() + now.getTimezoneOffset() * 60000 > expiryDate.getTime()
      );
    }
    // when want to know if local timezone date is expired
    return now.getTime() > expiryDate.getTime();
  },

  buildQueryStr: (obj) => {
    const components = [];
    for (const [key, value] of Object.entries(obj)) {
      components.push(`${key}=${encodeURIComponent(value)}`);
    }
    return components.join("&");
  },
  setOrRemoveItemFromSessionStorage: (key, value) => {
    if (value) {
      sessionStorage.setItem(key, value);
    } else {
      sessionStorage.removeItem(key);
    }
  },
  getSessionStorageItem: (key) => sessionStorage.getItem(key),
  removeItemSessionStorage: (...keys) => {
    keys.forEach((key) => {
      sessionStorage.removeItem(key);
    });
  },

  truncateString: (str, n, add3Dots) => {
    const dots = add3Dots ? "..." : "";
    return str.length > n ? str.slice(0, n - 1) + dots : str;
  },
};

export default utils;
