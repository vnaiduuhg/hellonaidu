const blur = () => {
  if (document.activeElement) {
    document.activeElement.blur();
  }
};

export default blur;
