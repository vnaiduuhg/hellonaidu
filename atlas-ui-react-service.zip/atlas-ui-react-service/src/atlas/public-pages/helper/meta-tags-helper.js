// Insert meta tag at the begining
const insertMetaTag = (meta) => {
  const head = document.getElementsByTagName("head")[0];
  head.insertBefore(meta, head.firstElementChild);
};

// Updates meta tag having a property attribute
const updateMetaTagWithProperty = (property, content) => {
  const meta = document.querySelector(`meta[property="${property}"]`);
  if (meta) {
    meta.setAttribute("content", content);
    return true;
  }

  return false;
};

// Updates meta tag having a name attribute
const updateMetaTagWithName = (name, content) => {
  const meta = document.querySelector(`meta[name="${name}"]`);
  if (meta) {
    meta.setAttribute("content", content);
    return true;
  }

  return false;
};

const metaTagsHelper = {
  // Creates new meta tag with a property attribute
  addMetaTagWithProperty: (property, content) => {
    if (!updateMetaTagWithProperty(property, content)) {
      const meta = document.createElement("meta");
      meta.setAttribute("property", property);
      meta.setAttribute("content", content);
      insertMetaTag(meta);
    }
  },
  // Creates new meta tag with a name attribute
  addMetaTagWithName: (name, content) => {
    if (!updateMetaTagWithName(name, content)) {
      const meta = document.createElement("meta");
      meta.setAttribute("name", name);
      meta.setAttribute("content", content);
      insertMetaTag(meta);
    }
  },
  setJsonToScriptTag: (id, jsonData) => {
    const tag = document.getElementById(id);
    tag.innerText = JSON.stringify(jsonData);
  },
};

export default metaTagsHelper;
