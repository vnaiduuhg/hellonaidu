import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import checkMark from "../../assets/job_document_check.png";
import style from "./required-document.module.css";

const RequiredDocument = ({ documentText }) => {
  const { t } = useTranslation();
  return (
    <div className={style.jobDetailsDocumentsList}>
      <img src={checkMark} alt={t("check-icon")} />
      <span>{documentText}</span>
    </div>
  );
};

RequiredDocument.propTypes = {
  documentText: PropTypes.string.isRequired,
};

RequiredDocument.defaultProps = {};

export default RequiredDocument;
