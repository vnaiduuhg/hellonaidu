import React from "react";
import { useSelector } from "react-redux";
import PropTypes from "prop-types";
import NavigationBar from "../navbar/navigation-bar";
import { getUrlParam } from "global/utils/utils";
import style from "./header.module.css";
import { InternalNavbar } from "global/components/Navigation/InternalNavbar";

// FIXME: This component needs to be rebuilt to accept all variations of the header
// based on current route, login status, permissions and if it's loaded as an
// independant app or through angular.
const Header = ({ angularRoute }) => {
  const urlParamToken = getUrlParam("token");
  const token = useSelector(({ user }) => user.token);
  const navLogo = useSelector(({ publicPage }) => publicPage.logoName);
  const showPublicNavbar = useSelector(
    ({ publicPage }) => publicPage.isPublicPage.payload,
  );
  const isJobDetailsPage = useSelector(
    ({ publicPage }) => publicPage.isJobDetailsPage.payload,
  );

  const careerPageMenuItem = token
    ? []
    : [
        { name: "log-in", link: "/", onClick: () => (window.location = "/") },
        {
          name: "support",
          link: "/support",
          onClick: () => window.open("/support", "_blank").focus(),
        },
      ];

  const jobDetailsPageMenuItem = token
    ? []
    : [
        {
          name: "log-in",
          link: "/",
          onClick: () => (window.location = "/"),
        },
        !urlParamToken
          ? {
              name: "job-board",
              link: "/jobs",
              onClick: () => (window.location = "/jobs"),
            }
          : null,
        {
          name: "support",
          link: "/support",
          onClick: () => window.open("/support", "_blank").focus(),
        },
      ].filter((item) => !!item);

  return (
    <div className={style.wrapperContent}>
      {showPublicNavbar ? (
        <NavigationBar
          logoName={navLogo.payload}
          menuItems={
            isJobDetailsPage ? jobDetailsPageMenuItem : careerPageMenuItem
          }
        />
      ) : (
        // FIXME: yeah, no that's not the condition to show internal navbar!
        !angularRoute && <InternalNavbar />
      )}
    </div>
  );
};

Header.propTypes = {
  angularRoute: PropTypes.bool,
};

Header.defaultProps = {
  angularRoute: false,
};

export default Header;
