Navbar & header belong in global components and needs to be completely redone to
conform to all the cases found on ng-app.

This was a quick fix created by Enosis to integrate into the app but doesn't
work well with the rest of the app
