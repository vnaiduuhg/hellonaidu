import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Image } from "react-bootstrap";
import Location from "../../assets/images/locationInfo.png";
import Expire from "../../assets/images/expire.png";
import Position from "../../assets/images/position.png";
import { generateFullAddress } from "../../helper/address";
import { getUsersApplications } from "global/apis/applicationsApi";
import style from "./title-and-address.module.css";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import utils from "../../helper/utils";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";

const TitleAndAdressWithVacency = ({
  companyName,
  companySlug,
  locations,
  numberOfPosition,
  externalExpiryDate,
  internalExpiryDate,
  onlyInternal,
  workLocation,
  job,
}) => {
  const [showInternalExpiryDate, setShowInternalExpiryDate] = useState(null);
  const [showExternalExpiryDate, setShowExternalExpiryDate] = useState(null);
  const user = useSelector((state) => state.user);
  const { i18n, t } = useTranslation();

  const { data: application, isFetched } = useQuery(
    [
      "applications",
      { candidate_user_id: [user.data?.user_id], job_id: [job.id] },
    ],
    async () => {
      const applications = await getUsersApplications({
        candidate_user_id: [user.data?.user_id],
        job_id: [job.id],
      });

      return applications.find((application) => application.job_id === job.id);
    },
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      staleTime: Infinity,
      enabled: !!user?.permissions?.isCandidate,
    },
  );

  useEffect(() => {
    if (onlyInternal) {
      setShowInternalExpiryDate(true);
      setShowExternalExpiryDate(false);
    } else {
      if (typeof user.token === "string") {
        // user is logged in
        if (user.permissions.isCandidate) {
          // check if the user applied internally or externally to this job
          if (isFetched) {
            if (!!application) {
              // user has applied, show the expiry according to if they applied
              // internally or externally
              setShowInternalExpiryDate(!application?.is_external);
              setShowExternalExpiryDate(!!application?.is_external);
            } else {
              setShowInternalExpiryDate(false);
              setShowExternalExpiryDate(true);
            }
          }
        } else {
          // non-candidate logged-in user
          setShowInternalExpiryDate(true);
          setShowExternalExpiryDate(true);
        }
      } else {
        // public: show only external expiry date
        setShowInternalExpiryDate(false);
        setShowExternalExpiryDate(true);
      }
    }
  }, [
    application,
    application?.is_external,
    externalExpiryDate,
    internalExpiryDate,
    isFetched,
    onlyInternal,
    user.permissions.isCandidate,
    user.token,
  ]);

  const internalExternalJob = showExternalExpiryDate && showInternalExpiryDate;

  const externalExpiryDateTranslated = `${t(
    internalExternalJob
      ? job.published_external
        ? "expires-externally-on"
        : "expired-externally-on"
      : job.published_external
      ? "expires-on"
      : "expired-on",
  )} ${utils.getTimeFormat(
    utils.utcToTimezone(externalExpiryDate),
    "LL",
    i18n.language,
  )}`;

  const internalExpiryDateTranslated = `${t(
    job.published_internal ? "expires-internally-on" : "expired-internally-on",
  )} ${utils.getTimeFormat(
    utils.utcToTimezone(internalExpiryDate),
    "LL",
    i18n.language,
  )}`;

  return (
    <div>
      <div className={style.textCursor}>
        <a
          href={`/careers/${companySlug}?open=about`}
          className={`${style.companyTitleLeft} ${
            !companySlug || onlyInternal ? "pe-none" : ""
          }`}
        >
          {companyName}
        </a>
      </div>

      <div className={style.jobDetailsAddressAndOther}>
        {locations.length > 0 &&
          locations.map((location) => {
            return (
              <div key={location.id} className={style.centerIconWithText}>
                <Image src={Location} alt={t("location-icon")} />
                <span>&nbsp;{generateFullAddress(location, false)}</span>
                {workLocation && (
                  <>
                    <span className="ms-2">|</span>
                    <span className="ms-2">
                      {t(workLocation.toLowerCase())}
                    </span>
                  </>
                )}
              </div>
            );
          })}

        {numberOfPosition > 0 && (
          <div className={style.centerIconWithText}>
            <Image src={Position} alt={t("position-icon")} />
            <span>
              &nbsp;{numberOfPosition}&nbsp;
              {numberOfPosition > 1
                ? t("multi-positions-available")
                : t("single-position-available")}
            </span>
          </div>
        )}

        {externalExpiryDate && showExternalExpiryDate && (
          <div className={style.centerIconWithText}>
            <Image src={Expire} alt={t("expire-icon")} />
            <span>&nbsp;{externalExpiryDateTranslated}</span>
          </div>
        )}

        {internalExpiryDate && showInternalExpiryDate && (
          <div className={style.centerIconWithText}>
            <Image src={Expire} alt={t("expire-icon")} />
            <span>&nbsp;{internalExpiryDateTranslated}</span>
          </div>
        )}
      </div>
    </div>
  );
};

TitleAndAdressWithVacency.propTypes = {
  companyName: PropTypes.string.isRequired,
  companySlug: PropTypes.string,
  locations: PropTypes.arrayOf(
    PropTypes.shape({
      suite_number: PropTypes.string,
      street_number: PropTypes.string,
      street: PropTypes.string,
      city: PropTypes.string,
      province: PropTypes.string,
      country: PropTypes.string,
      postal_code: PropTypes.string,
      id: PropTypes.number,
    }),
  ),
  numberOfPosition: PropTypes.number,
  externalExpiryDate: PropTypes.string,
  internalExpiryDate: PropTypes.string,
  onlyInternal: PropTypes.bool,
  job: PropTypes.object.isRequired,
};

TitleAndAdressWithVacency.defaultProps = {
  companySlug: null,
  locations: [],
  numberOfPosition: 0,
  externalExpiryDate: "",
  internalExpiryDate: "",
  onlyInternal: false,
};

export default TitleAndAdressWithVacency;
