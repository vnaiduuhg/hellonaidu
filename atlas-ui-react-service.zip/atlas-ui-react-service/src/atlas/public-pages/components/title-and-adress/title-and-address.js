import PropTypes from "prop-types";
import { ImLocation } from "react-icons/im";
import { IoCall } from "react-icons/io5";
import { useTranslation } from "react-i18next";
import style from "./title-and-address.module.css";

const TitleAndAdress = ({ companyName, fullLocation, companyPhone }) => {
  const { t } = useTranslation();
  return (
    <section className="text-center">
      <h1>
        <div className="pt-3">
          <span className={style.companyTitle}>{companyName}</span>
        </div>
      </h1>
      <div>
        <ImLocation className={style.companyAddressIcons} />
        <span className={style.companyAddress}>
          &nbsp;{fullLocation || t("not-available-2")}
        </span>
      </div>
      <div>
        <IoCall className={style.companyAddressIcons} aria-hidden="true" />
        <span className={style.companyAddress}>
          &nbsp;{companyPhone || t("not-available-2")}
        </span>
      </div>
    </section>
  );
};

TitleAndAdress.propTypes = {
  companyName: PropTypes.string.isRequired,
  fullLocation: PropTypes.string.isRequired,
  companyPhone: PropTypes.string,
};

TitleAndAdress.defaultProps = {
  companyPhone: "",
};

export default TitleAndAdress;
