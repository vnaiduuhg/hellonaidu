import styled from "styled-components";

const Tile = styled.div`
  background-size: cover;
  background-position: center center;
  ${({ index, url }) => `grid-area: image${index};
  background-image: url(${url});`}
`;

export default Tile;
