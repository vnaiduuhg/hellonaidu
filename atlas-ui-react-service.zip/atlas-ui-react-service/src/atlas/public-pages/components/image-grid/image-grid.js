import PropTypes from "prop-types";
import style from "./image-grid.module.css";
import Tile from "./tile.style";

const ImageGrid = ({ imageUrls }) => {
  const gallaryGridCss = [
    style.galleryGrid0,
    style.galleryGrid1,
    style.galleryGrid2,
    style.galleryGrid3,
    style.galleryGrid4,
    style.galleryGrid5,
    style.galleryGrid6,
  ];

  return (
    <div className={style.image_gallery}>
      <div className={gallaryGridCss[imageUrls.length]}>
        {imageUrls.map((imageUrl, index) => (
          <Tile key={`${index}-${imageUrl}`} index={index + 1} url={imageUrl} />
        ))}
      </div>
    </div>
  );
};

ImageGrid.propTypes = {
  imageUrls: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default ImageGrid;
