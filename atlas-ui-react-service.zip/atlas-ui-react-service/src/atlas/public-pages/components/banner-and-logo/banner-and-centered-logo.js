import { useEffect } from "react";
import PropTypes from "prop-types";
import { Col, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { MINIO_URL } from "../../../../config";
import utils from "../../helper/utils";
import metaTagsHelper from "../../helper/meta-tags-helper";
import { getCompanyLogo } from "../../services/endpoints";
import { GENERIC_LOGO, GENERIC_BANNER } from "../../constants";
import style from "./banner-and-logo.module.css";
import Banner from "./banner.styled";

const BannerAndCenteredLogo = ({ bannerName, logoName }) => {
  const { t } = useTranslation();

  logoName = logoName || GENERIC_LOGO;
  bannerName = bannerName || GENERIC_BANNER;
  const profileLogoUrl = utils.buildUrl(MINIO_URL + getCompanyLogo.endpoint, {
    logoName,
  });

  useEffect(() => {
    if (logoName) {
      metaTagsHelper.addMetaTagWithProperty("og:image:height", "340");
      metaTagsHelper.addMetaTagWithProperty("og:image:width", "680");
      metaTagsHelper.addMetaTagWithProperty("og:image", profileLogoUrl);
      window.prerenderReady = true;
    }
  }, [logoName, profileLogoUrl]);

  return (
    <>
      <Banner bannerName={bannerName} />
      <Row>
        <Col className={`${style.alignLogo} d-flex justify-content-center`}>
          <div className={style.companyCenterLogoContainer}>
            <img
              src={profileLogoUrl}
              alt={t("company-logo")}
              className="w-100"
            />
          </div>
        </Col>
      </Row>
    </>
  );
};

BannerAndCenteredLogo.propTypes = {
  bannerName: PropTypes.string,
  logoName: PropTypes.string,
};

BannerAndCenteredLogo.defaultProps = {
  bannerName: null,
  logoName: null,
};

BannerAndCenteredLogo.defaultProps = {};

export default BannerAndCenteredLogo;
