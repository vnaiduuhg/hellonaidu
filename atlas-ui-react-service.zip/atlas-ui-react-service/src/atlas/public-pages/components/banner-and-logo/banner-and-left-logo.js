import PropTypes from "prop-types";
import { Col, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { MINIO_URL } from "../../../../config";
import utils from "../../helper/utils";
import metaTagsHelper from "../../helper/meta-tags-helper";
import { getCompanyLogo } from "../../services/endpoints";
import { GENERIC_LOGO, GENERIC_BANNER } from "../../constants";
import style from "./banner-and-logo.module.css";
import Banner from "./banner.styled";
import { useEffect } from "react";

const BannerAndLeftLogo = ({ bannerName, logoName, metaLogoName }) => {
  const { t } = useTranslation();

  bannerName = bannerName || GENERIC_BANNER;
  logoName = logoName || GENERIC_LOGO;
  metaLogoName = metaLogoName || GENERIC_LOGO;

  const profileLogoUrl = utils.buildUrl(MINIO_URL + getCompanyLogo.endpoint, {
    logoName,
  });
  const metaLogoUrl = utils.buildUrl(MINIO_URL + getCompanyLogo.endpoint, {
    logoName: metaLogoName,
  });

  useEffect(() => {
    if (metaLogoName) {
      metaTagsHelper.addMetaTagWithProperty("og:image:height", "340");
      metaTagsHelper.addMetaTagWithProperty("og:image:width", "680");
      metaTagsHelper.addMetaTagWithProperty("og:image", metaLogoUrl);
      window.prerenderReady = true;
    }
  }, [metaLogoName, metaLogoUrl]);

  return (
    <>
      <Banner bannerName={bannerName} />
      <Row>
        <Col className={`${style.alignLogoLeft} d-flex justify-content-start`}>
          <div className={style.companyCenterLogoleft}>
            <img
              src={profileLogoUrl}
              alt={t("company-logo")}
              className="w-100"
            />
          </div>
        </Col>
      </Row>
    </>
  );
};

BannerAndLeftLogo.propTypes = {
  bannerName: PropTypes.string,
  logoName: PropTypes.string,
  metaLogoName: PropTypes.string,
};

BannerAndLeftLogo.defaultProps = {
  bannerName: null,
  logoName: null,
  metaLogoName: null,
};

export default BannerAndLeftLogo;
