import styled from "styled-components";
import { MINIO_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getCompanyBanner } from "../../services/endpoints";

const Banner = styled.div`
  height: 280px;
  background-image: url("${({ bannerName }) =>
    utils.buildUrl(MINIO_URL + getCompanyBanner.endpoint, { bannerName })}");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
`;

export default Banner;
