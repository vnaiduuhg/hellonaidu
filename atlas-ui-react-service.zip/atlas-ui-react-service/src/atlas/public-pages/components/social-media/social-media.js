import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { useTranslation as globalUseTranslation } from "global/utils/useTranslation";
import PropTypes from "prop-types";
import { FaFacebookF, FaTwitter, FaEnvelope } from "react-icons/fa";
import { SiLinkedin } from "react-icons/si";
import { LinkedinShareButton } from "react-share";
import blur from "../../helper/blur";
import style from "./social-media.module.css";
import utils from "../../helper/utils";
import { ATLAS_UI_URL } from "config";

const SocialMedia = ({ id, title, url }) => {
  const { t, i18n } = useTranslation();
  const { out } = globalUseTranslation();
  const token = useSelector((state) => state.user.token);
  const { isCandidate } = useSelector((state) => state.user.permissions);
  // const link = `${ATLAS_UI_URL}work/${id}/${url}`;  // @std by
  const link = `<a href="${ATLAS_UI_URL}work/${id}/${url}">${out(
    "Lien du poste",
    "job link",
  )}</a>`;
  const params = { body: link, subject: title };
  const mail = `/emails/compose?${utils.buildQueryStr(params)}`;

  const shareOnFacebook = () => {
    blur();
    const link = `${window.location.href}&source=facebook&lang=${i18n.language}`;
    window.FB.ui(
      {
        method: "share_open_graph",
        action_type: "og.likes",
        action_properties: JSON.stringify({
          object: link,
        }),
        app_id: "374702106720091",
      },
      (response) => {
        // Action after response
      },
    );
  };

  const shareOnTwitter = () => {
    blur();
    window.open(
      `https://twitter.com/intent/tweet?text=Workland&url=${window.location.href}&source=twitter`,
      "popup",
      "width=600,height=500",
    );
    return false;
  };

  return (
    <div className={style.jobDetailsShare}>
      <strong className={style.jobDetailsShareTitle}>
        {t("share-the-opportunity")}
      </strong>

      <div className={style.jobDetailsSharetext}>
        {t("know-someone")}
        <br />
        {t("share-it")}
      </div>

      <div className={style.socialMediaShare} id="socialMedia">
        <button
          className={`${style.socialMediaBtn} ${style.socialMediaLink} ${style.socialMediaLinkTransform}`}
          onClick={() => shareOnFacebook()}
        >
          <FaFacebookF className={style.socialMediaIcon} />
        </button>
        <a
          href={`https://twitter.com/intent/tweet?text=Workland&url=${window.location.href}&source=twitter`}
          target="popup"
          className={`${style.socialMediaLink} ${style.socialMediaLinkTransform}`}
          onClick={() => shareOnTwitter()}
        >
          <FaTwitter className={style.socialMediaIcon} />
        </a>
        {token && !isCandidate && (
          <a
            target="_blank"
            rel="noreferrer"
            href={mail}
            className={`${style.socialMediaLink} ${style.socialMediaLinkTransform}`}
            onClick={() => blur()}
          >
            <FaEnvelope
              className={style.socialMediaIcon}
              title="mail"
              aria-label="mail"
            />
          </a>
        )}
        <LinkedinShareButton
          url={`${window.location.href}&source=linkedin&lang=${i18n.language}`}
          className={style.socialMediaLink}
          onClick={() => blur()}
        >
          <div className={style.socialMediaLInIcon}>
            <SiLinkedin title="linkedin" />
            &nbsp;&nbsp;Share
          </div>
        </LinkedinShareButton>
      </div>
    </div>
  );
};

SocialMedia.propTypes = {
  id: PropTypes.string,
  title: PropTypes.string,
  url: PropTypes.string,
};

SocialMedia.defaultProps = {
  id: "",
  title: "",
  url: "",
};

export default SocialMedia;
