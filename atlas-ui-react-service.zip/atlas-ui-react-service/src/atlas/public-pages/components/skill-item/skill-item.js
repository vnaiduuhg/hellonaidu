import PropTypes from "prop-types";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import info from "../../assets/info.png";
import triangle from "../../assets/triangle.png";
import style from "./skill-item.module.css";

const SkillsItem = ({ skillName, skillDefinition }) => {
  const { t } = useTranslation();
  return (
    <div className={style.requiredSkillsItem}>
      <img src={triangle} alt={t("triangle-icon")} className="pe-2 mb-1" />
      <span>{skillName}</span>

      {skillDefinition && (
        <OverlayTrigger
          overlay={<Tooltip id="tooltip-disabled">{skillDefinition}</Tooltip>}
        >
          <img src={info} alt={t("info-icon")} className="ps-2" />
        </OverlayTrigger>
      )}
    </div>
  );
};

SkillsItem.propTypes = {
  skillName: PropTypes.string.isRequired,
  skillDefinition: PropTypes.string,
};

SkillsItem.defaultProps = {
  skillDefinition: "",
};

export default SkillsItem;
