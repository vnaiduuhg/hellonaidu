import { useTranslation } from "react-i18next";
import { RiErrorWarningFill } from "react-icons/ri";
import style from "./no-data-found.module.css";

const NoDataFound = () => {
  const { t } = useTranslation();
  return (
    <section className={style.container}>
      <br />
      <br />
      <br />
      <br />
      <div>
        <RiErrorWarningFill size="1.4em" />
      </div>
      <h4 className={style.text}>{t("no-result-found")}</h4>
    </section>
  );
};

export default NoDataFound;
