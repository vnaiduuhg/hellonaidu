import styled from "styled-components";

const Slider = styled.div`
  ${({ transform }) => `transform: translateX(${transform}%);
  position: relative;
  width: 33%;
  transition: all 0.33s cubic-bezier(0.38, 0.8, 0.32, 1.07);
  @media (max-width: 600px) {
    display: none;
  }`}
`;

export default Slider;
