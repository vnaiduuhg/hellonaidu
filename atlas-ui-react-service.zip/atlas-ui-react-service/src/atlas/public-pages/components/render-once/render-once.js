import { useEffect } from "react";
import PropTypes from "prop-types";

const RenderOnce = ({ handleRender, children }) => {
  useEffect(() => {
    return () => {
      handleRender();
    };
  });
  return <div>{children}</div>;
};

RenderOnce.propTypes = {
  handleRender: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
};

RenderOnce.defaultProps = {};

export default RenderOnce;
