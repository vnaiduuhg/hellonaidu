import React from "react";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import JobCard from "./job-card";
import utils from "../../helper/utils";
import { GENERIC_LOGO } from "../../constants";
import NoDataFound from "../no-data-found/no-data-found";
import style from "./job-card-list.module.css";

const JobCardList = ({ grid, jobData, isError, isAccountLoading }) => {
  const { t, i18n } = useTranslation();

  if (isError || jobData.length === 0) {
    return <NoDataFound />;
  }
  return (
    <section
      className={`${style.jobListSection} ${!grid && style.jobListSectionList}`}
    >
      {jobData.map((job) => {
        const {
          logo,
          title,
          translations,
          companyName,
          slug,
          url,
          id,
          city,
          province,
          otherLocationAvailable,
          external_expiry_date: expiryDate,
        } = job;

        const jobUrl = `/work/${id}/${url}`;
        const companyUrl = slug ? `/careers/${slug}?open=about` : "";

        let titleTrans =
          translations.find((item) => item.locale === i18n.language).title ||
          title;

        titleTrans =
          titleTrans || translations.find((item) => item.title != null).title;

        const expiryDateTranslated = utils.getTimeFormat(
          utils.utcToTimezone(expiryDate),
          "LL",
          i18n.language,
        );
        let logoName = logo;

        if (isAccountLoading === true && logo === null) {
          logoName = GENERIC_LOGO;
        }
        return (
          <JobCard
            key={id}
            logoName={logoName}
            jobTitle={titleTrans}
            companyName={companyName}
            companyUrl={companyUrl}
            jobUrl={jobUrl}
            address={city && province ? `${city}, ${province}` : ""}
            expireDate={`${t("expires")} ${expiryDateTranslated}`}
            otherLocationAvailable={otherLocationAvailable}
          />
        );
      })}
    </section>
  );
};

JobCardList.propTypes = {
  grid: PropTypes.bool,
  jobData: PropTypes.arrayOf(PropTypes.object).isRequired,
  isError: PropTypes.bool,
  isAccountLoading: PropTypes.bool,
};

JobCardList.defaultProps = {
  grid: true,
  isError: false,
  isAccountLoading: false,
};

export default React.memo(JobCardList);
