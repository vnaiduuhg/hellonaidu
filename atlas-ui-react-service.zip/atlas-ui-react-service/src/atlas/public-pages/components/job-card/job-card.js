// import "bootstrap/dist/css/bootstrap.min.css";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Card } from "react-bootstrap";
import { ImLocation } from "react-icons/im";
import style from "./job-card.module.css";
import utils from "../../helper/utils";
import { MINIO_URL } from "../../../../config";
import { getCompanyLogo } from "../../services/endpoints";
import ExpireIcon from "../../assets/images/expire-clock-icon";

const JobCard = ({
  logoName,
  jobTitle,
  companyName,
  expireDate,
  address,
  companyUrl,
  jobUrl,
  otherLocationAvailable,
}) => {
  const { t } = useTranslation();

  const logoUrl = logoName
    ? utils.buildUrl(MINIO_URL + getCompanyLogo.endpoint, {
        logoName,
      })
    : "#";

  return (
    <Card className={style.jobCard}>
      <Card.Body className={style.jobCardBody}>
        <div className={style.jobCardImage}>
          <img src={logoUrl} alt="Company Logo" title="" />
        </div>
        <div className={style.jobCardInfo}>
          <div className="jobCardHeader">
            <h5 className="mb-0">
              <Link
                to={jobUrl}
                className={style.jobCardTitle}
                title={`${jobTitle} ${companyName}`}
              >
                {jobTitle}
              </Link>
            </h5>
            <div>
              {companyUrl ? (
                <Link
                  to={companyUrl}
                  className={style.jobCardCompanyName}
                  title={`${jobTitle} ${companyName}`}
                >
                  {companyName}
                </Link>
              ) : (
                <div className={style.jobCardCompanyName}>{companyName}</div>
              )}
            </div>
          </div>
          <div className={style.jobCardFooter}>
            <div className={style.jobCardFooterText}>
              <ExpireIcon />

              <span>&nbsp;{expireDate}</span>
            </div>

            {address && (
              <div className={style.jobCardFooterText}>
                <ImLocation size="1.2em" />
                <span>&nbsp;{address}</span>
              </div>
            )}

            {otherLocationAvailable && (
              <div className={style.jobCardFooterText}>
                <ImLocation size="1.2em" />
                <span>&nbsp;{t("other-location-capitalize")}</span>
              </div>
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
};

JobCard.propTypes = {
  logoName: PropTypes.string,
  jobTitle: PropTypes.string.isRequired,
  companyName: PropTypes.string,
  expireDate: PropTypes.string.isRequired,
  address: PropTypes.string.isRequired,
  companyUrl: PropTypes.string,
  jobUrl: PropTypes.string.isRequired,
  otherLocationAvailable: PropTypes.bool,
};

JobCard.defaultProps = {
  logoName: "",
  companyName: "",
  companyUrl: "",
  otherLocationAvailable: false,
};

export default JobCard;
