import PropTypes from "prop-types";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import useQuery from "../../hooks/use-query";
import { FaCheckCircle } from "react-icons/fa";
import ApplyButton from "../buttons/long-responsive-buttons/apply-button";
import { useJobApplicationStatusApiMutation } from "../../services/job-details/application-status";
import utils from "../../helper/utils";
import style from "./job-apply.module.css";

const JobApply = ({ jobId, disabled }) => {
  const { t } = useTranslation();
  const [hasApplied, setHasApplied] = useState(false);
  const [incompleteApplication, setIncompleteApplication] = useState(false);
  const user = useSelector((state) => state.user.data);
  const isCandidate = useSelector(
    (state) => state.user.permissions.isCandidate,
  );
  const internalJobToken = useQuery().get("token");
  const source = useQuery().get("source") || "Workland";
  const newsletter = useQuery().get("newsletter");
  const jobAlert = useQuery().get("job-alert");
  const urlParams = {
    jobId,
    source,
    ...(internalJobToken && {
      token: encodeURI(internalJobToken),
    }),
  };
  if (newsletter) urlParams.newsletter = newsletter;
  if (jobAlert) urlParams["job-alert"] = jobAlert;

  const applyJobUrl = `/job-apply?${utils.buildQueryStr(urlParams)}`;

  const [jobApplicationStatusApi, { isLoading }] =
    useJobApplicationStatusApiMutation();

  useEffect(() => {
    if (!!user && isCandidate) {
      jobApplicationStatusApi({
        candidate_user_id: [user.user_id],
        job_id: [jobId],
      }).then((response) => {
        if (response.data.length > 0) {
          const status = response.data[0].status.toLowerCase();
          setHasApplied(status === "submitted");
          setIncompleteApplication(status === "incomplete");
        }
      });
    }
  }, [user, jobApplicationStatusApi, jobId]);

  useEffect(() => {
    localStorage.setItem("url", applyJobUrl);
  }, []);

  return (
    !isLoading &&
    (!!user && hasApplied ? (
      <div>
        <FaCheckCircle fontSize="1.3rem" color="#009385" />
        &nbsp;
        <span className={style.alreadyApplied}>{t("job-applied")}</span>
      </div>
    ) : !!user && incompleteApplication ? (
      <ApplyButton
        disabled={disabled}
        buttonText={t("incomplete-application").toUpperCase()}
        url={applyJobUrl}
      />
    ) : (
      <ApplyButton
        disabled={disabled}
        buttonText={t("apply")}
        url={applyJobUrl}
      />
    ))
  );
};

JobApply.propTypes = {
  jobId: PropTypes.string.isRequired,
  internalJob: PropTypes.bool,
  disabled: PropTypes.bool,
};

JobApply.defaultProps = {
  internalJob: false,
  disabled: false,
};

export default JobApply;
