import { useEffect, useState } from "react";

import PropTypes from "prop-types";
import { FormControl } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import AlertModelWithText from "../alert-modal/alert-modale-with-text";
import utils from "../../helper/utils";
import style from "./search.module.css";

const SearchBar = ({
  placeholder,
  localSearchKey,
  onSearchLocal,
  onSearch,
}) => {
  const [showAlert, setShowAlert] = useState(false);
  const { t } = useTranslation();

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      const sanitizedInput = utils.sanitizeInput(localSearchKey);
      if (localSearchKey.trim().length) {
        if (sanitizedInput.length >= 3) {
          onSearch(localSearchKey);
        } else {
          setShowAlert(true);
        }
      } else {
        onSearch(localSearchKey);
      }
    }, 1000);

    return () => clearTimeout(delayDebounceFn);
  }, [localSearchKey, onSearch]);

  return (
    <>
      <FormControl
        placeholder={placeholder}
        aria-label="search box"
        className={style.searchBar}
        value={localSearchKey}
        onChange={(e) => onSearchLocal(e.target.value)}
      />
      <AlertModelWithText
        show={showAlert}
        alertText={t("short-search-message")}
        onHide={() => setShowAlert(false)}
      />
    </>
  );
};

SearchBar.propTypes = {
  placeholder: PropTypes.string.isRequired,
  localSearchKey: PropTypes.string,
  onSearchLocal: PropTypes.func.isRequired,
  onSearch: PropTypes.func.isRequired,
};

SearchBar.defaultProps = {
  localSearchKey: "",
};

export default SearchBar;
