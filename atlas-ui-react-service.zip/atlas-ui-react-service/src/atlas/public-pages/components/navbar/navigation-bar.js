import { useEffect } from "react";
import { NavLink } from "react-router-dom";
import { Navbar, Container, Nav, NavDropdown, Image } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { useTranslation } from "react-i18next";
import PropTypes from "prop-types";
import { GENERIC_LOGO } from "../../constants";
import { MINIO_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getCompanyLogo } from "../../services/endpoints";
import styles from "./navigation-bar.module.css";
import userSlice from "global/store/userSlice";
import cx from "classnames";

// TODO: only completable after layout component & router are done. They will
// manage the component that is loaded and the props that are passed. Work
// in progress!!!

// This is a placeholder. This needs to go into i18next as a list of languages
// each of which is translated t
const languages = {
  en: {
    key: "en",
    translations: {
      en: { long: "English" },
      fr: { long: "Anglais" },
    },
  },
  fr: {
    key: "fr",
    translations: {
      en: { long: "French" },
      fr: { long: "Français" },
    },
  },
};

// TODO: run through menu items
// TODO: pass menu items in router
const NavigationBar = ({ logoName, menuItems, noHeader = false }) => {
  const { t: translate, i18n } = useTranslation();
  const { language } = i18n;
  const dispatch = useDispatch();

  const { language: userLng, permissions } = useSelector(({ user }) => user);
  const accountDataIsLoaded = useSelector(
    (state) => state.publicPage.accountDataIsLoaded,
  );

  // FIXME: Logo shown/hidden status depends also on agency account. This logic
  // is incomplete
  logoName = logoName || GENERIC_LOGO;

  const profileLogoUrl = utils.buildUrl(MINIO_URL + getCompanyLogo.endpoint, {
    logoName,
  });

  // FIXME: unify loading & setting translations. Once migrated to i18next,
  // remove redux out of the equation for languages and initialize the library
  // using getDefaultLanguage() in the language provider
  const setLanguage = (currentLang) => {
    if (language !== currentLang) {
      localStorage.setItem("currentLanguage", currentLang);
      i18n.changeLanguage(currentLang);

      dispatch(userSlice.actions.changeLanguage({ language: currentLang }));
    }
  };

  // FIXME: This is too hacky and needs to predictably set initially.
  // This workaround seems to have been introduced to fix it quickly for public
  // pages but leaving the rest of the pages to use an inconsistent logic
  useEffect(() => {
    if (language !== userLng) {
      i18n.changeLanguage(userLng);
    }
  }, []);

  return (
    // TODO: check if header component is necessary
    /* id 'a seco' gives an error - removed this attribute */
    <header className={styles["custom-global-header"]}>
      {/* NavBar */}
      <Navbar
        expand="lg"
        variant="light"
        className={`fixed-top ${styles.navbar}`}
      >
        <Container
          fluid
          id={styles["custom-main-content"]}
          // TODO: implement this when it's added
          hidden={noHeader}
        >
          {/* FIXME: @agency: add checks for agency to redirect to correct pages, show/hide logo */}
          {/* <div
            ng-if="!(notworkland && !logoforpage) && !$root.agencyIframe"
            ng-show="worklandLogo"
          > */}
          {accountDataIsLoaded && logoName && (
            <Navbar.Brand
              href="/"
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                window.location = "/";
                return false;
              }}
            >
              {/* TODO: conflict in which logo is shown: workland vs generic */}
              <Image
                className="navbar-logo-img "
                // ng-src="{{notworkland ? logoforpage : worklandLogo}}"
                src={profileLogoUrl}
                height="40"
                hidden={permissions.isAgency || permissions.isClient}
              />
            </Navbar.Brand>
          )}

          {/* agency check </div> */}

          <Navbar.Toggle
            aria-controls="wl-navbar-collapse"
            aria-label="Toggle navigation"
          />

          <Navbar.Collapse
            id="wl-navbar-collapse"
            className="justify-content-end"
          >
            {/* <div
            className="collapse navbar-collapse justify-content-end"
            id="wl-navbar-collapse"
            > */}
            {/* on angular: <Nav className="me-auto mb-2 mb-lg-0"> */}
            <Nav className="navbar-right mb-2 mb-lg-0">
              {menuItems.map((m) => {
                const linkProps = m.onClick
                  ? {
                      onClick: (e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        m.onClick();
                        return false;
                      },
                      to: "#",
                    }
                  : {
                      to: m.link,
                    };

                return (
                  <Nav.Item as="li" key={m.link}>
                    <Nav.Link as={NavLink} {...linkProps} exact>
                      {translate(m.name)}
                    </Nav.Link>
                  </Nav.Item>
                );
              })}

              <NavDropdown
                align="end"
                title={userLng.toUpperCase()}
                id="navbarScrollingDropdown"
                className=" dropdown-menu-internal dropdown-menu-end d-flex align-items-center"
              >
                {/* TODO: create a list of supported languages inside i18next */}
                {Object.values(languages).map((l) => {
                  return (
                    <NavDropdown.Item
                      key={l.key}
                      href="#"
                      onClick={() => setLanguage(l.key)}
                    >
                      {/* This is a temporary code to make it work but it will need to be changed once this is moved to languages translations module in i18next */}
                      <span>{languages[l.key].translations[userLng].long}</span>
                      <i
                        className={cx("fa", {
                          "fa-circle-o fa-inverse": l.key !== userLng,
                          "fa-check": l.key === userLng,
                        })}
                      />
                    </NavDropdown.Item>
                  );
                })}
              </NavDropdown>
            </Nav>
            {/* </div> */}
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </header>
  );
};

NavigationBar.propTypes = {
  logoName: PropTypes.string,
  menuItems: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string,
      link: PropTypes.string,
    }),
  ).isRequired,
  noHeader: PropTypes.bool,
};

NavigationBar.defaultProps = {
  logoName: "",
  noHeader: false,
};

export default NavigationBar;
