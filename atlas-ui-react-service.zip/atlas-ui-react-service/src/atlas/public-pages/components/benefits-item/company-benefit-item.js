import PropTypes from "prop-types";
import style from "./benefits-item.module.css";

const CompanyBenefitItem = ({ benefitTitle, benefitDescription }) => {
  return (
    <section>
      <h3>
        <span className={style.companyBenefitsTitle}>{benefitTitle}</span>
      </h3>
      <div className={style.companyBenefitsTitleBar} />
      {benefitDescription && (
        <span className={style.companyBenefitsDescription}>
          {benefitDescription}
        </span>
      )}
    </section>
  );
};

CompanyBenefitItem.propTypes = {
  benefitTitle: PropTypes.string,
  benefitDescription: PropTypes.string,
};

CompanyBenefitItem.defaultProps = {
  benefitTitle: "",
  benefitDescription: "",
};

export default CompanyBenefitItem;
