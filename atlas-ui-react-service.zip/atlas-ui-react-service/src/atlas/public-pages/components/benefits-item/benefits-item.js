import PropTypes from "prop-types";
import style from "./benefits-item.module.css";

const BenefitsItem = ({ iconName, benefitText }) => {
  return (
    <div className={style.jobDetailBenefitsItems}>
      <div className={style.jobDetailBenefitsIcons}>
        <span className={iconName} />
      </div>
      <p className={style.jobDetailBenefitsText}>{benefitText}</p>
    </div>
  );
};

BenefitsItem.propTypes = {
  iconName: PropTypes.string.isRequired,
  benefitText: PropTypes.string.isRequired,
};

BenefitsItem.defaultProps = {};

export default BenefitsItem;
