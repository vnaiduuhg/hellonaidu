import PropTypes from "prop-types";
import { Pagination } from "react-bootstrap";
import style from "./pagination.module.css";

const PagePagination = ({
  currentPage,
  numberOfPages,
  handlePageChanges,
  pageSize,
}) => {
  const onPageChanges = (event) => {
    if (event.type === "keypress" && event.charCode !== 13) {
      return;
    }
    handlePageChanges(parseInt(event.target.text, 10));
  };

  const onPaginationBtnClicked = (event, page) => {
    if (event.type === "keypress" && event.charCode !== 13) {
      return;
    }
    handlePageChanges(page);
  };

  const pageComponents = [];
  let staringPage;
  let endingPage;

  if (currentPage - 6 < 0) {
    staringPage = 1;
    endingPage = numberOfPages <= pageSize ? numberOfPages : pageSize;
  } else if (currentPage + 4 >= numberOfPages) {
    staringPage = Math.max(1, numberOfPages - (pageSize - 1));
    endingPage = numberOfPages;
  } else {
    staringPage = currentPage - 5;
    endingPage = currentPage + 4;
  }

  for (let page = staringPage; page <= endingPage; page += 1)
    pageComponents.push(
      <Pagination.Item
        key={page}
        className={page === currentPage && style.ActivePaginationItem}
        onClick={onPageChanges}
        onKeyPress={onPageChanges}
      >
        {page}
      </Pagination.Item>,
    );

  const navigationButtonPreviousClass = `${
    currentPage === 1 ? style.NavigationButtonsNotAllowed : ""
  }`;
  const navigationButtonNextClass = `${
    currentPage === numberOfPages ? style.NavigationButtonsNotAllowed : ""
  }`;
  return (
    <Pagination className={style.customPaginationItem}>
      <Pagination.First
        className={navigationButtonPreviousClass}
        onClick={(e) => onPaginationBtnClicked(e, 1)}
        onKeyPress={(e) => onPaginationBtnClicked(e, 1)}
        disabled={currentPage === 1}
      >
        {"<<"}
      </Pagination.First>
      <Pagination.Prev
        className={navigationButtonPreviousClass}
        onClick={(e) => onPaginationBtnClicked(e, Math.max(currentPage - 1, 1))}
        onKeyPress={(e) =>
          onPaginationBtnClicked(e, Math.max(currentPage - 1, 1))
        }
        disabled={currentPage === 1}
      >
        {"<"}
      </Pagination.Prev>
      {pageComponents}
      <Pagination.Next
        className={navigationButtonNextClass}
        onClick={(e) =>
          onPaginationBtnClicked(e, Math.min(currentPage + 1, numberOfPages))
        }
        onKeyPress={(e) =>
          onPaginationBtnClicked(e, Math.min(currentPage + 1, numberOfPages))
        }
        disabled={currentPage === numberOfPages}
      >
        {">"}
      </Pagination.Next>
      <Pagination.Last
        className={navigationButtonNextClass}
        onClick={(e) => onPaginationBtnClicked(e, numberOfPages)}
        onKeyPress={(e) => onPaginationBtnClicked(e, numberOfPages)}
        disabled={currentPage === numberOfPages}
      >
        {">>"}
      </Pagination.Last>
    </Pagination>
  );
};

PagePagination.propTypes = {
  currentPage: PropTypes.number.isRequired,
  numberOfPages: PropTypes.number.isRequired,
  handlePageChanges: PropTypes.func.isRequired,
  pageSize: PropTypes.number,
};

PagePagination.defaultProps = {
  pageSize: 10,
};

export default PagePagination;
