import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { Wrapper } from "@googlemaps/react-wrapper";
import { generateShortAddress } from "../../helper/address";
import Marker from "./marker";
import Map from "./map";
import { GOOGLE_API } from "../../../../config";
import style from "./google-map.module.css";
import { ComponentLoader } from "global/components/loaders/component-loader";

const RenderMapStatus = (status) => {
  return <p>{status}</p>;
};
const defaultMapConfig = {
  zoom: 3,
  center: {
    lat: 0,
    lng: 0,
  },
};
const GoogleMapWrapper = ({ locationDetails, isLocationLoading }) => {
  const [mapConfig, setMapConfig] = useState(defaultMapConfig);

  const [markers, setMarkers] = useState([]);

  useEffect(() => {
    const markerList = locationDetails.map((location) => {
      const { id, latitude, longitude } = location;
      return {
        id,
        position: { lat: Number(latitude), lng: Number(longitude) },
        shortAddress: generateShortAddress(location),
      };
    });

    const center =
      markerList.length > 0 ? markerList[0].position : defaultMapConfig.center;

    const zoom = markerList.length > 1 ? 3 : 15;

    setMapConfig({ zoom, center });
    setMarkers([...markerList]);
  }, [locationDetails]);

  return (
    <section className={style.mapWrapper}>
      {isLocationLoading ? (
        <ComponentLoader />
      ) : (
        <Wrapper apiKey={GOOGLE_API} render={RenderMapStatus}>
          <Map option={mapConfig}>
            {markers.map((item) => (
              <Marker
                key={item.id}
                position={item.position}
                shortAddress={item.shortAddress}
              />
            ))}
          </Map>
        </Wrapper>
      )}
    </section>
  );
};

GoogleMapWrapper.propTypes = {
  locationDetails: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number,
      city: PropTypes.string,
      country: PropTypes.string,
      google_place_id: PropTypes.string,
      latitude: PropTypes.string,
      longitude: PropTypes.string,
      postal_code: PropTypes.string,
      province: PropTypes.string,
      region: PropTypes.string,
      street: PropTypes.string,
      street_number: PropTypes.string,
      suite_number: PropTypes.string,
      translations: PropTypes.arrayOf(
        PropTypes.shape({
          id: PropTypes.number,
          city: PropTypes.string,
          country: PropTypes.string,
          locale: PropTypes.string,
          province: PropTypes.string,
          region: PropTypes.string,
          street: PropTypes.string,
        }),
      ),
    }),
  ).isRequired,
  isLocationLoading: PropTypes.bool.isRequired,
};

GoogleMapWrapper.defaultProps = {};

export default GoogleMapWrapper;
