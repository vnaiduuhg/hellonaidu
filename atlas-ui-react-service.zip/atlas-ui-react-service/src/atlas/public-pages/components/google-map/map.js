import React, { useRef, useState, useEffect } from "react";
import PropTypes from "prop-types";
import style from "./google-map.module.css";

const Map = ({ option, children }) => {
  const ref = useRef();
  const [map, setMap] = useState();
  const [infoWindow, setInfoWindow] = useState();

  useEffect(() => {
    if (ref.current && !map) {
      setMap(new window.google.maps.Map(ref.current, { ...option }));

      setInfoWindow(new window.google.maps.InfoWindow());
    }
  }, [ref, map, option]);

  return (
    <div ref={ref} className={style.map}>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          // set the map prop on the child component
          return React.cloneElement(child, { map, infoWindow });
        }
        return null;
      })}
    </div>
  );
};

Map.propTypes = {
  option: PropTypes.shape({
    zoom: PropTypes.number,
    center: PropTypes.shape({
      lat: PropTypes.number,
      lng: PropTypes.number,
    }),
  }).isRequired,
  children: PropTypes.node.isRequired,
};

Map.defaultProps = {};

export default Map;
