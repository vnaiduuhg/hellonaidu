import React, { useMemo, useState } from "react";
import PropTypes from "prop-types";

const googleMapContext = React.createContext();

const GoogleMapContextProvider = ({ children }) => {
  const [showMap, setShowMap] = useState(false);
  const value = useMemo(() => {
    return { showMap, setShowMap };
  }, [showMap, setShowMap]);
  return (
    <googleMapContext.Provider value={value}>
      {children}
    </googleMapContext.Provider>
  );
};

GoogleMapContextProvider.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
  ]).isRequired,
};
export { GoogleMapContextProvider };
export default googleMapContext;
