import { useState, useEffect } from "react";

const Marker = (options) => {
  const [marker, setMarker] = useState();
  const { map, shortAddress, infoWindow } = options;

  useEffect(() => {
    if (!marker) {
      setMarker(new window.google.maps.Marker());
    }

    // remove marker from map on unmount
    return () => {
      if (marker) {
        marker.setMap(null);
      }
    };
  }, [marker]);

  useEffect(() => {
    if (marker) {
      marker.setOptions(options);

      marker.addListener("click", () => {
        infoWindow.setContent(shortAddress);

        infoWindow.open({
          anchor: marker,
          map,
          shouldFocus: false,
        });
      });
    }
  }, [marker, options, shortAddress, infoWindow, map]);

  return null;
};
export default Marker;
