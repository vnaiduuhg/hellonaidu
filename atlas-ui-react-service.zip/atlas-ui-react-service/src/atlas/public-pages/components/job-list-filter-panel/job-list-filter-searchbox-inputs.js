import React from "react";
import { useTranslation } from "react-i18next";
import { FormControl } from "react-bootstrap";
import { BsSearch, BsBuilding } from "react-icons/bs";
import { IoLocationOutline } from "react-icons/io5";
import PropTypes from "prop-types";
import style from "./job-list-filter-panel.module.css";
import CompanyBuildingIcon from "../../assets/company-building-icon";
import LocationIcon from "../../assets/images/location-icon";

const JobListFilterSearchBoxInputs = ({
  inputHandler,
  handelModal,
  addLeftBorder,
  dataInputPopup,
  searchInput,
}) => {
  const { t } = useTranslation();
  return (
    <>
      <div className={style.jobsListFilterPanelSearchBoxItem}>
        <BsSearch size="1em" color="#9c9999" />
        <FormControl
          type="input"
          placeholder={t("search-job")}
          name="job"
          onClick={handelModal}
          onChange={inputHandler}
          value={searchInput.job.value}
          autoComplete="off"
          aria-label={t("search-job")}
        />
      </div>
      <div
        className={`${style.jobsListFilterPanelSearchBoxItem}  ${
          addLeftBorder && style.borderLeft
        } `}
        data-input-popup={dataInputPopup}
      >
        {/* <BsBuilding size="1.4em" color="#9c9999" /> */}
        <CompanyBuildingIcon width="1.4em" height="1.4em" />
        <FormControl
          type="input"
          placeholder={t("company-name")}
          name="companyName"
          onChange={inputHandler}
          value={searchInput.companyName.value}
          autoComplete="off"
          aria-label={t("company-name")}
        />
      </div>
      <div
        className={`${style.jobsListFilterPanelSearchBoxItem} ${
          addLeftBorder && style.borderLeft
        } `}
        data-input-popup={dataInputPopup}
      >
        <LocationIcon width="1.4em" height="1.4em" />
        <FormControl
          type="input"
          placeholder={t("location")}
          name="location"
          onChange={inputHandler}
          value={searchInput.location.value}
          autoComplete="off"
          aria-label={t("location")}
        />
      </div>
    </>
  );
};

JobListFilterSearchBoxInputs.propTypes = {
  inputHandler: PropTypes.func,
  handelModal: PropTypes.func,
  addLeftBorder: PropTypes.bool,
  dataInputPopup: PropTypes.bool,
  searchInput: PropTypes.shape({
    job: PropTypes.shape({ title: PropTypes.string, value: PropTypes.string }),
    companyName: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
    location: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
  }).isRequired,
};

JobListFilterSearchBoxInputs.defaultProps = {
  inputHandler: () => {},
  handelModal: () => {},
  addLeftBorder: true,
  dataInputPopup: false,
};

export default React.memo(JobListFilterSearchBoxInputs);
