const initialSearchInput = {
  job: { title: "job-title", value: "", priority: 1 },
  location: { title: "location", value: "", priority: 2 },
  companyName: { title: "company-name", value: "", priority: 3 },
};

export default initialSearchInput;
