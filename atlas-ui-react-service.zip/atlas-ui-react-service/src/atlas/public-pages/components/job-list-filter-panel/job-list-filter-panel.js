import React, { useState, useEffect, useRef } from "react";
import { Container } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { MdRestartAlt } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import PropTypes from "prop-types";
import { useGetLocationIdMutation } from "../../services/job-board/job-list-location";
import utils from "../../helper/utils";
import AlertModal from "../alert-modal/alert-modale-with-text";
import JobListFilterSearchBoxInputs from "./job-list-filter-searchbox-inputs";
import BasicModal from "../basic-modal/basic-modal";
import style from "./job-list-filter-panel.module.css";
import {
  clearSearchParams,
  setJobKeyword,
  setLocationKeyword,
  setCompanySearchKeyword,
} from "../../slices/job-board/job-search-slice";
import initialSearchInput from "./initialSearchInput";

const equals = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);

const useDebounce = (func, value, delay, ...args) => {
  useEffect(() => {
    const handler = setTimeout(() => {
      func(...args);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
};

const JobListFilterPanel = ({
  searchInput,
  handelInput,
  emptySearchInput,
  updatedCurrentPage,
}) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const locationNotfound = useRef(false);

  const jobSearchParams = useSelector((state) => state.jobSearchParams);

  const [alertModalConfig, setAlertModalConfig] = useState({
    show: false,
    alertText: "",
  });

  const [localInput, setLocalInput] = useState({ ...initialSearchInput });

  useEffect(() => {
    setLocalInput({
      job: { ...searchInput.job, value: jobSearchParams.search },
      companyName: {
        ...searchInput.companyName,
        value: jobSearchParams.companyNameSearch,
      },
      location: {
        ...searchInput.location,
        value: jobSearchParams.location.text,
      },
    });
  }, []);

  const handelLocalInput = (e) => {
    setLocalInput((prev) => {
      return {
        ...prev,
        [e.target.name]: { ...prev[e.target.name], value: e.target.value },
      };
    });
  };

  const [showInputModal, setShowInputModal] = useState(false);

  const [getSearchLocationIdApi] = useGetLocationIdMutation();

  const handelModal = () => {
    if (window.innerWidth <= 767) setShowInputModal(true);
  };
  const ValidateLocalInputField = (fieldName) => {
    const inputValue = localInput[fieldName].value || "";
    if (inputValue.trim().length) {
      const sanitizedInput = utils.sanitizeInput(inputValue);
      if (sanitizedInput.length < 3) {
        setAlertModalConfig({
          show: true,
          alertText: t("short-search-message"),
        });
        return false;
      }
    }
    return true;
  };

  useDebounce(
    async () => {
      handelInput(localInput);

      if (ValidateLocalInputField("location")) {
        // only dispatch when localSearch key is empty and
        // location not found in previous state
        if (locationNotfound.current && !localInput.location.value) {
          updatedCurrentPage.current = "1";

          dispatch(
            setLocationKeyword({
              data: [],
              text: localInput.location.value,
            }),
          );

          locationNotfound.current = false;
          return;
        }

        // ignore when localSearch key is empty with the Global state.
        if (
          !(
            localInput.location.value === "" &&
            jobSearchParams.location.text === ""
          )
        ) {
          if (localInput.location.value === "") {
            updatedCurrentPage.current = "1";

            dispatch(
              setLocationKeyword({
                data: [],
                text: "",
              }),
            );
          } else {
            try {
              const locationData = await getSearchLocationIdApi({
                search: utils.sanitizeInput(localInput.location.value),
              });
              if (locationData?.data?.length === 0) {
                locationNotfound.current = true;
                setAlertModalConfig({
                  show: true,
                  alertText: t("no-location-found"),
                });
                return;
              }
              if (!equals(locationData.data, jobSearchParams.location.data)) {
                updatedCurrentPage.current = "1";

                dispatch(
                  setLocationKeyword({
                    data: locationData.data,
                    text: localInput.location.value,
                  }),
                );
              }
            } catch (error) {
              console.log(error);
            }
          }
        }
      }
      if (ValidateLocalInputField("job")) {
        if (!(localInput.job?.value === "" && jobSearchParams.search === "")) {
          updatedCurrentPage.current = "1";

          dispatch(setJobKeyword(utils.sanitizeInput(localInput.job.value)));
        }
      }

      if (ValidateLocalInputField("companyName")) {
        if (
          !(
            localInput.companyName?.value === "" &&
            jobSearchParams.companyNameSearch === ""
          )
        ) {
          updatedCurrentPage.current = "1";

          dispatch(
            setCompanySearchKeyword(
              utils.sanitizeInput(localInput.companyName.value),
            ),
          );
        }
      }
    },
    localInput,
    1000,
  );

  const clearSearchInput = () => {
    dispatch(clearSearchParams());
    emptySearchInput();
    setLocalInput({ ...initialSearchInput });
    updatedCurrentPage.current = "1";
  };

  const closeInputModal = () => {
    setShowInputModal(false);
  };

  const closeAlertModal = () => {
    setAlertModalConfig({ ...alertModalConfig, show: false });
  };

  return (
    <section className={style.jobListFilterPanel}>
      <Container>
        <div className={style.topText}>{t("we-bring-jobs-to-you")}</div>
        <div className={style.jobsListFilterPanelSearch}>
          <div className={style.jobsListFilterPanelSearchBox}>
            <JobListFilterSearchBoxInputs
              handelModal={handelModal}
              inputHandler={handelLocalInput}
              searchInput={localInput}
            />
          </div>
          <div className={style.jobsListFilterPanelSearchBtn}>
            <button type="button" onClick={clearSearchInput}>
              <span data-btn-inner-ele="icon">
                <MdRestartAlt size="1.5em" color="white" />
              </span>
              <span data-btn-inner-ele="text">{t("reset-button")}</span>
            </button>
          </div>
        </div>
        <BasicModal show={showInputModal}>
          <div className={style.jobsListFilterPanelPopUpContent}>
            <div className={style.jobsListFilterPanelPopUpHeader}>
              <div className={style.jobsListFilterPanelPopUpTitle}>
                Search For
              </div>
              <div
                className={style.jobsListFilterPanelPopUpClose}
                role="button"
                tabIndex="0"
                onClick={closeInputModal}
              >
                X
              </div>
            </div>
            <div className={style.jobsListFilterPanelSearchBoxPopUp}>
              <JobListFilterSearchBoxInputs
                addLeftBorder={false}
                dataInputPopup
                inputHandler={handelLocalInput}
                searchInput={localInput}
              />

              <div className={style.jobsListFilterPanelSearchBtn}>
                <button type="button" onClick={clearSearchInput}>
                  <span>{t("reset-button")}</span>
                </button>
              </div>
            </div>
          </div>
        </BasicModal>
        <AlertModal
          show={alertModalConfig.show}
          alertText={alertModalConfig.alertText}
          onHide={closeAlertModal}
        />
      </Container>
    </section>
  );
};

JobListFilterPanel.propTypes = {
  handelInput: PropTypes.func.isRequired,
  emptySearchInput: PropTypes.func.isRequired,
  searchInput: PropTypes.shape({
    job: PropTypes.shape({ title: PropTypes.string, value: PropTypes.string }),
    companyName: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
    location: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
  }).isRequired,
  updatedCurrentPage: PropTypes.shape({
    current: PropTypes.string,
  }).isRequired,
};

JobListFilterPanel.defaultProps = {};

export default React.memo(JobListFilterPanel);
