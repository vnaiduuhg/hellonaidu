import { memo } from "react";
import { useTranslation } from "react-i18next";
import { DocumentViewer } from "global/components/DocumentViewer/DocumentViewer";
import { ComponentLoader } from "global/components/loaders/component-loader";
import { Modal } from "react-bootstrap";

const DocumentViewerModal = memo(({ document, show, hide }) => {
  const { i18n } = useTranslation();

  return (
    <Modal centered show={show} onHide={hide} size="lg">
      <Modal.Header closeButton>
        <Modal.Title className="w-100 ellipsis">
          {document.translations[i18n.language]}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {!document && (
          <div className="p-3">
            <ComponentLoader />
          </div>
        )}
        {!!document.url && (
          <DocumentViewer
            path={document.url}
            fileName={document.filename}
            // protection is removed because it will hinder accessibility as
            // is a terrible & futile practice.
            protect={false}
          />
        )}
      </Modal.Body>
    </Modal>
  );
});

export default DocumentViewerModal;
