import React from "react";
import { useSelector } from "react-redux";
import PublicFooter from "./public-footer";

const Footer = () => {
  const isPublicPage = useSelector((state) => state.publicPage.isPublicPage);
  return isPublicPage ? <PublicFooter /> : null;
};

export default Footer;
