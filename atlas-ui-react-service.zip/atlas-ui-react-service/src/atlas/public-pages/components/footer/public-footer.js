import { lazy } from "react";
import { useTranslation } from "react-i18next";
import { Col, OverlayTrigger, Row, Tooltip } from "react-bootstrap";
import blur from "../../helper/blur";
import style from "./public-footer.module.css";

const PowerdByIcon = lazy(() =>
  import("../../assets/workland-powered-by-icon"),
);

const PublicFooter = () => {
  const { t: translate } = useTranslation();

  return (
    <footer className={style.footer}>
      <Row>
        <Col className="px-sm-5">
          <OverlayTrigger
            overlay={
              <Tooltip id="tooltip-disabled" className={style.tooltipText}>
                {translate("powered-by")} WORKLAND
              </Tooltip>
            }
          >
            <a
              href="/"
              className={`${style.footerElement} ${style.footerPowerbyText}`}
              target="_blank"
              rel="noreferrer"
              onClick={() => blur()}
            >
              <span className={style.footerText}>
                {translate("powered-by")} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              </span>
              <PowerdByIcon />
            </a>
          </OverlayTrigger>
        </Col>

        <Col className="px-sm-5 text-end">
          <OverlayTrigger
            overlay={
              <Tooltip id="tooltip-disabled" className={style.tooltipText}>
                {translate("privacy-policy")}
              </Tooltip>
            }
          >
            <a
              href="/privacy-policy/"
              className={`${style.footerElement} ${style.footerPrivacyPolicyText}`}
              target="_blank"
              rel="noreferrer"
              onClick={() => blur()}
            >
              <span>{translate("privacy-policy")}</span>
            </a>
          </OverlayTrigger>
        </Col>
      </Row>
    </footer>
  );
};

export default PublicFooter;
