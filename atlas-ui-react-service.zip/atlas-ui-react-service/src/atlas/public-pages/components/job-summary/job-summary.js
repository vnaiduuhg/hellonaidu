import { nanoid } from "@reduxjs/toolkit";

import PropTypes from "prop-types";
import { Card } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { BsTagFill } from "react-icons/bs";
import utils from "../../helper/utils";
import style from "./job-summary.module.css";

const JobSummary = ({
  expiryDate,
  title,
  groups,
  description,
  address,
  otherLocations,
  className,
}) => {
  const { t, i18n } = useTranslation();

  const expiryDateTranslated = utils.getTimeFormat(
    utils.utcToTimezone(expiryDate),
    "LL HH:mm",
    i18n.language,
  );

  return (
    <Card className={`${className} ${style.singleJobContainer}`}>
      <Card.Body className={style.jobDetails}>
        <Card.Text className="text-end pt-2">
          {t("expires")} {expiryDateTranslated}
        </Card.Text>

        <Card.Text className={style.jobTitle}>{title}</Card.Text>

        {groups && (
          <Card.Text>
            {groups.map((group) => {
              return (
                <span key={nanoid()}>
                  <BsTagFill className={style.tagIcons} aria-hidden="true" />
                  &nbsp;
                  {group}&nbsp;&nbsp;
                </span>
              );
            })}
          </Card.Text>
        )}
        <Card.Text className={style.descriptionText}>{description}</Card.Text>

        <Card.Text className="mb-0">{address}</Card.Text>

        {otherLocations && t("other-location")}
      </Card.Body>
    </Card>
  );
};

JobSummary.propTypes = {
  expiryDate: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  groups: PropTypes.arrayOf(PropTypes.string).isRequired,
  description: PropTypes.string.isRequired,
  address: PropTypes.string.isRequired,
  otherLocations: PropTypes.bool.isRequired,
  className: PropTypes.string,
};

JobSummary.defaultProps = {
  className: "",
};

export default JobSummary;
