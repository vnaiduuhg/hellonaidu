// import "bootstrap/dist/css/bootstrap.min.css";
import PropTypes from "prop-types";
import { motion, AnimatePresence, useAnimation } from "framer-motion";
import style from "./basic-modal.module.css";

const dialog = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
};

const modal = {
  hidden: {
    opacity: 0,
    y: "-20px",
  },
  visible: {
    opacity: 1,
    y: "0px",
    transition: { delay: 0.2 },
  },
};

const BasicModal = ({ show, children }) => {
  const control = useAnimation();

  return (
    <AnimatePresence>
      (
      {show && (
        <motion.div
          variants={dialog}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className={style.dialog}
        >
          <div
            className={`${style.modalDialog} ${style.alertWidth}`}
            onClick={(e) => e.stopPropagation()}
            role="button"
            tabIndex="0"
          >
            <motion.div
              animate={control}
              style={{ width: "100%", margin: "10px" }}
            >
              <motion.div
                variants={modal}
                initial="hidden"
                animate="visible"
                exit="hidden"
                className={`${style.modalMain} ${style.alertModal}`}
              >
                {children}
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      )}
      )
    </AnimatePresence>
  );
};

BasicModal.propTypes = {
  show: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
};

BasicModal.defaultProps = {};

export default BasicModal;
