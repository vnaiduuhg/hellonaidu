import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { Button } from "react-bootstrap";
import AlertBaseModal from "./alert-base-modal";
import style from "./alert-modal.module.css";

const AlertModelWithText = ({ show, onHide, alertText }) => {
  const [element, setElement] = useState();

  useEffect(() => {
    setElement((prev) => {
      if (show) {
        const ele = document.activeElement;
        ele.blur();
        return ele;
      }
      return prev;
    });
  }, [show]);

  return (
    <AlertBaseModal show={show} onHide={onHide}>
      <p>{alertText}</p>
      <div className="d-flex flex-row-reverse">
        <Button
          onClick={(e) => {
            element?.focus();
            onHide(e);
          }}
          className={style.closeButton}
        >
          OK
        </Button>
      </div>
    </AlertBaseModal>
  );
};

AlertModelWithText.propTypes = {
  show: PropTypes.bool.isRequired,
  onHide: PropTypes.func.isRequired,
  alertText: PropTypes.string.isRequired,
};

AlertModelWithText.defaultProps = {};

export default AlertModelWithText;
