import PropTypes from "prop-types";
import { motion, AnimatePresence, useAnimation } from "framer-motion";
import style from "./alert-modal.module.css";

const x = 8;
const shakeX = {
  x: [0, -x, x, -x, x, -x, 0],
  transition: { duration: 0.5 },
};

const dialog = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
};

const modal = {
  hidden: {
    opacity: 0,
    y: "-20px",
  },
  visible: {
    opacity: 1,
    y: "0px",
    transition: { delay: 0.2 },
  },
};

const AlertBaseModal = ({ show, children }) => {
  const control = useAnimation();
  const handelAnimation = () => {
    control.start(shakeX);
  };

  return (
    <AnimatePresence>
      (
      {show && (
        <motion.div
          variants={dialog}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className={style.dialog}
          onClick={handelAnimation}
        >
          <div
            className={`${style.modalDialog} ${style.alertWidth}`}
            onClick={(e) => e.stopPropagation()}
            role="button"
            tabIndex="0"
          >
            <motion.div
              animate={control}
              style={{ width: "100%", margin: "10px" }}
            >
              <motion.div
                variants={modal}
                initial="hidden"
                animate="visible"
                exit="hidden"
                className={`${style.modalMain} ${style.alertModal}`}
              >
                {children}
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      )}
      )
    </AnimatePresence>
  );
};

AlertBaseModal.propTypes = {
  show: PropTypes.bool.isRequired,

  children: PropTypes.node.isRequired,
};

AlertBaseModal.defaultProps = {};

export default AlertBaseModal;
