import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import AlertBaseModal from "./alert-base-modal";
import style from "./alert-modal.module.css";
import { useTranslation } from "react-i18next";

const AlertModelWithAction = ({ show, yes, no, icon, title, alertText }) => {
  const [element, setElement] = useState();
  const { t } = useTranslation();

  useEffect(() => {
    setElement((prev) => {
      if (show) {
        const ele = document.activeElement;
        ele.blur();
        return ele;
      }
      return prev;
    });
  }, [show]);

  return (
    <AlertBaseModal show={show}>
      <div className={style.alertModalTitleWrapper}>
        {icon}
        <span>{title}</span>
      </div>
      <p>{alertText}</p>
      <div className="d-flex flex-row-reverse gap-2">
        <Button onClick={yes} className={style.jobAlertBtn}>
          {t("yes")}
        </Button>
        <button
          onClick={(e) => {
            element?.focus();
            no(e);
          }}
          type="button"
          className={`${style.closeButton} btn-dark`}
        >
          {t("no")}
        </button>
      </div>
    </AlertBaseModal>
  );
};

AlertModelWithAction.propTypes = {
  show: PropTypes.bool.isRequired,
  icon: PropTypes.node.isRequired,
  title: PropTypes.string.isRequired,
  alertText: PropTypes.string.isRequired,
  yes: PropTypes.func.isRequired,
  no: PropTypes.func.isRequired,
};

AlertModelWithAction.defaultProps = {};

export default AlertModelWithAction;
