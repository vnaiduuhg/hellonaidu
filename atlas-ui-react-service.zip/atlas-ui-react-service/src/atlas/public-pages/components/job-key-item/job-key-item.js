import PropTypes from "prop-types";
import style from "./job-key-item.module.css";

const JobKeyItem = ({ iconName, headingText, contentText }) => {
  return (
    <div className={style.jobDetailsTimingItem}>
      <div className={style.jobDetailsTimingIcon}>
        <span className={iconName} />
      </div>
      <div className="ps-2">
        <span className={style.jobDetailsTimingTitle}>{headingText}</span>
        <span className={style.jobDetailsTimingTitleUnderTitle}>
          {contentText}
        </span>
      </div>
    </div>
  );
};

JobKeyItem.propTypes = {
  iconName: PropTypes.string.isRequired,
  headingText: PropTypes.string.isRequired,
  contentText: PropTypes.string,
};

JobKeyItem.defaultProps = {
  contentText: "",
};

export default JobKeyItem;
