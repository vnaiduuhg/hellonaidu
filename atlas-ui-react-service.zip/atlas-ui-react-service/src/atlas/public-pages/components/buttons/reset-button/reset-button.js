import PropTypes from "prop-types";
import { Button } from "react-bootstrap";
import style from "./reset-button.module.css";

export default function ResetButton({ clearSearch, buttonText, className }) {
  return (
    <Button
      variant="outline-secondary"
      className={`${style.resetSearchButton} ${className}`}
      onClick={clearSearch}
    >
      {buttonText}
    </Button>
  );
}

ResetButton.propTypes = {
  buttonText: PropTypes.string.isRequired,
  clearSearch: PropTypes.func.isRequired,
  className: PropTypes.string,
};

ResetButton.defaultProps = {
  className: "",
};
