import { useEffect, useRef } from "react";
import PropTypes from "prop-types";
import { Button, ToggleButton } from "react-bootstrap";
import { FaBell } from "react-icons/fa";
import AboutUsIcon from "../../../assets/career-page-icons/about-us-icon";
import JobOfferIcon from "../../../assets/career-page-icons/job-offer-icon";
import style from "./tab-button.module.css";

const TabButton = ({
  name,
  icon,
  currentValue,
  activeValue,
  handleTabButtons,
  as,
}) => {
  let iconView;
  if (icon === "AboutUs") {
    iconView = <AboutUsIcon />;
  } else if (icon === "JobOffers") {
    iconView = <JobOfferIcon />;
  } else if (icon === "JobAlert") {
    iconView = <FaBell />;
  }

  const toggleButtonRef = useRef(null);
  useEffect(() => {
    if (toggleButtonRef.current) {
      toggleButtonRef.current.previousElementSibling.setAttribute(
        "tabindex",
        "-1",
      );
      toggleButtonRef.current.previousElementSibling.setAttribute(
        "hidden",
        "true",
      );
    }
  }, []);

  const eleProps = {
    variant: "outline-light",
    className: `${style.toggleButton} ${
      currentValue === activeValue ? style.tabActive : style.tabInactive
    }`,
    checked: currentValue === activeValue,
    onClick: () => handleTabButtons(activeValue),
    onKeyPress: (key) =>
      key.code === "Enter" ? handleTabButtons(activeValue) : null,
    value: activeValue,
    id: `id_${activeValue}`,
  };

  const tabText = (
    <div className={style.textWrapper}>
      {iconView}
      <span className={style.tabText}>{name}</span>
    </div>
  );

  if (as === "button") {
    eleProps["aria-label"] = name;
    return <Button {...eleProps}>{tabText}</Button>;
  }

  eleProps["aria-label"] = `radio button ${
    currentValue === activeValue ? "selected, " : " unselected, "
  }${name}`;

  eleProps.ref = toggleButtonRef;

  return <ToggleButton {...eleProps}>{tabText}</ToggleButton>;
};

TabButton.propTypes = {
  name: PropTypes.string,
  icon: PropTypes.string,
  currentValue: PropTypes.string,
  activeValue: PropTypes.string,
  handleTabButtons: PropTypes.func.isRequired,
  as: PropTypes.oneOf(["radio", "button"]),
};

TabButton.defaultProps = {
  name: "About Us",
  icon: "AboutUs",
  currentValue: "about",
  activeValue: "about",
  as: "radio",
};

export default TabButton;
