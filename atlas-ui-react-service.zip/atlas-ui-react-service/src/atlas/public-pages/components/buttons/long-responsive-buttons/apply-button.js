import PropTypes from "prop-types";
import style from "./responsive-buttons.module.css";

const ApplyButton = ({ buttonText, url, disabled }) => {
  return (
    <button
      type="button"
      className={`${style.buttonResponsive} ${
        disabled ? style.disableBtn : ""
      }`}
      size="lg"
      onClick={() => {
        window.location = url ?? `/job-apply`;
      }}
      disabled={disabled}
    >
      {buttonText}
    </button>
  );
};

ApplyButton.propTypes = {
  buttonText: PropTypes.string.isRequired,
  url: PropTypes.string,
  disabled: PropTypes.bool,
};

ApplyButton.defaultProps = {
  url: null,
  disabled: false,
};

export default ApplyButton;
