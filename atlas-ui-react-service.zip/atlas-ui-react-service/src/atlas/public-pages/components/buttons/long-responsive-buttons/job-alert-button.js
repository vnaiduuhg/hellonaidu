import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { FaBell } from "react-icons/fa";
import style from "./responsive-buttons.module.css";

const JobAlertButton = ({ slug }) => {
  const { t } = useTranslation();

  return (
    <button
      type="button"
      className={`${style.buttonResponsive} ${style.jobAlertButton}`}
      size="lg"
      onClick={() => (window.location = `/subscribe-settings/${slug}`)}
    >
      <FaBell className={style.jobAlertIcon} />
      {t("job-alert")}
    </button>
  );
};

JobAlertButton.propTypes = {
  slug: PropTypes.string.isRequired,
};

JobAlertButton.defaultProps = {};

export default JobAlertButton;
