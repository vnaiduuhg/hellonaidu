import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Image } from "react-bootstrap";
import MapIcon from "../../../assets/images/map.png";
import style from "./responsive-buttons.module.css";

const GoogleMapButton = ({ onClickHandler }) => {
  const { t } = useTranslation();

  return (
    <button
      type="button"
      className={`${style.buttonResponsive} ${style.mapButton}`}
      size="lg"
      onClick={onClickHandler}
    >
      <Image src={MapIcon} className={style.mapIcon} alt={t("location-icon")} />
      {t("display-map")}
    </button>
  );
};

GoogleMapButton.propTypes = {
  onClickHandler: PropTypes.func.isRequired,
};

GoogleMapButton.defaultProps = {};

export default GoogleMapButton;
