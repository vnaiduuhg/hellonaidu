import { slugifyValue } from "atlas/public-pages/helper/query-param-helper";
import PropTypes from "prop-types";
import style from "./filter-button.module.css";

const FilterButton = ({
  buttonText,
  buttonName,
  selectedFilters,
  onSelectFilter,
}) => {
  const onButtonClick = () => {
    onSelectFilter(buttonName);
  };

  const slugifiedButtonName = slugifyValue(buttonName);
  const isSelected = !!selectedFilters.find((f) => f === slugifiedButtonName);

  return (
    <span className={style.filterButtonWrapper}>
      <input
        id={`id_${slugifiedButtonName}`}
        type="checkbox"
        checked={isSelected}
        onChange={onButtonClick}
        onKeyPress={(key) => {
          if (key.code === "Enter") onButtonClick();
        }}
        className={style.filterCheckbox}
      />
      <label
        className={`${style.filterButton} ${
          isSelected ? style.activeFilterButton : ""
        } btn-outline-secondary`}
        htmlFor={`id_${slugifiedButtonName}`}
      >
        {buttonText}
      </label>
    </span>
  );
};

FilterButton.propTypes = {
  buttonText: PropTypes.string.isRequired,
  buttonName: PropTypes.string.isRequired,
  selectedFilters: PropTypes.arrayOf(PropTypes.string).isRequired,
  onSelectFilter: PropTypes.func.isRequired,
};

FilterButton.defaultProps = {};

export default FilterButton;
