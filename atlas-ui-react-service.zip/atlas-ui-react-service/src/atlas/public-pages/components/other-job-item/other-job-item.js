import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import style from "./other-job-item.module.css";

const OtherJobItem = ({
  jobUrl,
  jobTitle,
  locations,
  isOtherLocations,
  isLastItem,
}) => {
  const { t } = useTranslation();

  return (
    <div
      className={`${style.jobDetailsOtherJobsItem} ${
        isLastItem ? style.jobDetailsOtherJobsItemLast : ""
      }`}
    >
      <Link to={jobUrl} className={style.jobTitle}>
        {jobTitle}
      </Link>

      <p>
        <span>{locations}</span>
      </p>

      {isOtherLocations && (
        <p>
          <span>{t("other-location")}</span>
        </p>
      )}
    </div>
  );
};

OtherJobItem.propTypes = {
  jobUrl: PropTypes.string.isRequired,
  jobTitle: PropTypes.string.isRequired,
  locations: PropTypes.string,
  isOtherLocations: PropTypes.bool.isRequired,
  isLastItem: PropTypes.bool,
};

OtherJobItem.defaultProps = {
  locations: "",
  isLastItem: false,
};

export default OtherJobItem;
