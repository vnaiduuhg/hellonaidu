import React, { useCallback } from "react";
import { useTranslation } from "react-i18next";
import PropTypes from "prop-types";

import style from "./job-board-navigation-top.module.css";
import ListDisplayActiveIcon from "../../assets/images/list-display-active.png";
import ListDisplayIcon from "../../assets/images/list-display.png";
import BlockDisplayActiveIcon from "../../assets/images/blocks-display-active.png";
import BlockDisplayIcon from "../../assets/images/blocks-display.png";

const JobBoardNavigationTop = ({
  isExternalLoading,
  displayJobListGrid,
  handelJobList,
  isError,
  dataAvailable,
  searchInput,
}) => {
  const { t } = useTranslation();

  const getDisplayText = useCallback(() => {
    const searchParams = Object.values(searchInput).filter(
      (item) => item.value.length,
    );
    searchParams.sort((a, b) => a.priority - b.priority);
    if (searchParams.length === 0) {
      return <span>{t("all-jobs")}</span>;
    }

    return (
      <span>
        {t("filtered-jobs")}&nbsp;[&nbsp;
        {searchParams.map((item, index) => {
          return (
            <span key={item.title}>
              {t(item.title)}:&nbsp; <i>&quot;{item.value}&quot;</i>
              {index < searchParams.length - 1 && <>&nbsp;&amp;&nbsp;</>}
            </span>
          );
        })}
        &nbsp;]&nbsp;
      </span>
    );
  }, [searchInput]);

  return (
    <section className={style.jobListNavigation}>
      <div className={style.displaySearchParams}>
        <strong>{t("display")}:</strong> {getDisplayText()}
      </div>
      {isExternalLoading || isError || !dataAvailable ? null : (
        <div className={style.toggleBtnGrp}>
          <button
            type="button"
            className={`${style.toggleBtn} ${
              !displayJobListGrid && style.toggleBtnActive
            }`}
            onClick={() => handelJobList(false)}
            aria-label="grid view"
          >
            <img
              src={
                !displayJobListGrid ? ListDisplayActiveIcon : ListDisplayIcon
              }
              alt="list display"
            />
          </button>
          <button
            type="button"
            className={`${style.toggleBtn} ${
              displayJobListGrid && style.toggleBtnActive
            }`}
            onClick={() => handelJobList(true)}
            aria-label="list view"
          >
            <img
              src={
                displayJobListGrid ? BlockDisplayActiveIcon : BlockDisplayIcon
              }
              alt="block display"
            />
          </button>
        </div>
      )}
    </section>
  );
};

JobBoardNavigationTop.propTypes = {
  isExternalLoading: PropTypes.bool.isRequired,
  displayJobListGrid: PropTypes.bool.isRequired,
  handelJobList: PropTypes.func.isRequired,
  isError: PropTypes.bool.isRequired,
  dataAvailable: PropTypes.bool.isRequired,
  searchInput: PropTypes.shape({
    job: PropTypes.shape({ title: PropTypes.string, value: PropTypes.string }),
    companyName: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
    location: PropTypes.shape({
      title: PropTypes.string,
      value: PropTypes.string,
    }),
  }).isRequired,
};

JobBoardNavigationTop.defaultProp = {};

export default React.memo(JobBoardNavigationTop);
