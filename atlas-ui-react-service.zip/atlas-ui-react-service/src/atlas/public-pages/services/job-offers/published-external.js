import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { JOBS_URL } from "../../../../config";
import { getPublishedExternals } from "../endpoints";

export const publishedExternalApi = createApi({
  reducerPath: "publishedExternalApi",
  baseQuery: fetchBaseQuery({
    baseUrl: JOBS_URL,
  }),
  endpoints: (builder) => ({
    publishedExternalApi: builder.mutation({
      query(body) {
        return {
          url: getPublishedExternals.endpoint,
          method: getPublishedExternals.method,
          body,
        };
      },
    }),
  }),
});

export const { usePublishedExternalApiMutation } = publishedExternalApi;
