import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { JOBS_URL } from "../../../../config";
import { getPublishedInternals } from "../endpoints";

export const publishedInternalApi = createApi({
  reducerPath: "publishedInternalApi",
  baseQuery: fetchBaseQuery({
    baseUrl: JOBS_URL,
  }),
  endpoints: (builder) => ({
    publishedInternalApi: builder.mutation({
      query(body) {
        return {
          url: getPublishedInternals.endpoint,
          method: getPublishedInternals.method,
          body,
        };
      },
    }),
  }),
});

export const { usePublishedInternalApiMutation } = publishedInternalApi;
