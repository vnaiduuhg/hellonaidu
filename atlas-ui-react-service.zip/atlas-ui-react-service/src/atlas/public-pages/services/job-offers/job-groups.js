import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { JOBS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getJobGroups } from "../endpoints";

export const jobGroupsApi = createApi({
  reducerPath: "jobGroupsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: JOBS_URL,
  }),
  endpoints: (builder) => ({
    getJobGroups: builder.query({
      query: ({ id, query }) =>
        utils.buildUrl(getJobGroups.endpoint, { id }, query),

      transformResponse: (response) => {
        return response.sort((a, b) => utils.strCompare(a.name, b.name));
      },
    }),
  }),
});

export const { useGetJobGroupsQuery } = jobGroupsApi;
