module.exports = {
  getUserAccountDetails: {
    method: "GET",
    endpoint: "api/v1/accounts/profiles/by-slug/{slug}",
  },

  getUserAccountType: {
    method: "GET",
    endpoint: "api/v1/accounts/{accountId}/type",
  },

  getLocationDetails: {
    method: "GET",
    endpoint: "api/v1/location/list-by-key-and-values",
  },

  getDefaultUserDetails: {
    method: "POST",
    endpoint: "api/v1/accounts/default-profiles",
  },

  getJobGroups: {
    method: "GET",
    endpoint: "api/v1/group/account/{id}/groups",
  },

  getPublishedExternals: {
    method: "POST",
    endpoint: "api/v1/job/published-external",
  },

  getPublishedInternals: {
    method: "POST",
    endpoint: "api/v1/job/published-internal",
  },

  getJobDetails: {
    method: "GET",
    endpoint: "api/v1/job/{id}?increment_views=1",
  },

  getDocumentType: {
    method: "GET",
    endpoint: "api/v1/document-manager/candidate-file-versions/document-types",
  },

  getCompanyBanner: {
    endpoint: "media/Profile/Banners/{bannerName}",
  },

  getCompanyLogo: {
    endpoint: "media/Profile/Logos/{logoName}",
  },

  getJobApplicationStatus: {
    method: "POST",
    endpoint: "api/v1/application/read-all",
  },
  getSearchLocationID: {
    method: "GET",
    endpoint: "api/v1/location/get-ids-by-text-search",
  },
};
