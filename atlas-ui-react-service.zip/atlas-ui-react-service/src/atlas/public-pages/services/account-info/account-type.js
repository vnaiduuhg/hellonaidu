import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { USER_ACCOUNTS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getUserAccountType } from "../endpoints";

export const accountTypeApi = createApi({
  reducerPath: "accountTypeApi",
  baseQuery: fetchBaseQuery({
    baseUrl: USER_ACCOUNTS_URL,
  }),
  endpoints: (builder) => ({
    getAccountType: builder.query({
      query: (accountId) => {
        return utils.buildUrl(getUserAccountType.endpoint, { accountId });
      },
    }),
  }),
});

export const { useGetAccountTypeQuery } = accountTypeApi;
