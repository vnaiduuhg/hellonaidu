import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { USER_ACCOUNTS_URL } from "../../../../config";
import { getDefaultUserDetails } from "../endpoints";

export const defaultUserDetailsApi = createApi({
  reducerPath: "defaultUserDetailsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: USER_ACCOUNTS_URL,
  }),
  endpoints: (builder) => ({
    defaultUserDetailsApi: builder.mutation({
      query(body) {
        return {
          url: getDefaultUserDetails.endpoint,
          method: getDefaultUserDetails.method,
          body,
        };
      },
    }),
  }),
});

export const { useDefaultUserDetailsApiMutation } = defaultUserDetailsApi;
