import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { SHARED_APIS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getLocationDetails } from "../endpoints";

export const locationDetailsApi = createApi({
  reducerPath: "locationDetailsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: SHARED_APIS_URL,
  }),
  endpoints: (builder) => ({
    getLocationDetails: builder.query({
      query: (params) =>
        utils.buildUrl(getLocationDetails.endpoint, {}, params),
    }),
  }),
});

export const locationDetailsApiMutation = createApi({
  reducerPath: "locationDetailsApiMutation",
  baseQuery: fetchBaseQuery({
    baseUrl: SHARED_APIS_URL,
  }),
  endpoints: (builder) => ({
    getLocationDetails: builder.mutation({
      query: (params) =>
        utils.buildUrl(getLocationDetails.endpoint, {}, params),
    }),
  }),
});

export const { useGetLocationDetailsQuery } = locationDetailsApi;
export const { useGetLocationDetailsMutation } = locationDetailsApiMutation;
