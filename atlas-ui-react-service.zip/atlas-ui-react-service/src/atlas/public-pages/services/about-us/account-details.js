import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { USER_ACCOUNTS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getUserAccountDetails } from "../endpoints";

export const accountDetailsApi = createApi({
  reducerPath: "accountDetailsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: USER_ACCOUNTS_URL,
  }),
  endpoints: (builder) => ({
    getAccountDetails: builder.query({
      query: (slug) => {
        return utils.buildUrl(getUserAccountDetails.endpoint, { slug });
      },
    }),
  }),
});

export const { useGetAccountDetailsQuery } = accountDetailsApi;
