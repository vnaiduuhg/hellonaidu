import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { SHARED_APIS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getSearchLocationID } from "../endpoints";

export const searchLocationApi = createApi({
  reducerPath: "searchLocationApi",
  baseQuery: fetchBaseQuery({
    baseUrl: SHARED_APIS_URL,
  }),
  endpoints: (builder) => ({
    getLocationId: builder.mutation({
      query: (params) =>
        utils.buildUrl(getSearchLocationID.endpoint, {}, params),
    }),
  }),
});

export const { useGetLocationIdMutation } = searchLocationApi;
