import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { TOOLKIT_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getDocumentType } from "../endpoints";

export const documentTypesApi = createApi({
  reducerPath: "documentTypesApi",
  baseQuery: fetchBaseQuery({
    baseUrl: TOOLKIT_URL,
  }),

  endpoints: (builder) => ({
    getDocumentTypes: builder.query({
      query: () => utils.buildUrl(getDocumentType.endpoint),
    }),
  }),
});

export const { useGetDocumentTypesQuery } = documentTypesApi;
