import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { JOBS_URL } from "../../../../config";
import utils from "../../helper/utils";
import { getJobDetails } from "../endpoints";

export const jobDetailsApi = createApi({
  reducerPath: "jobDetailsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: JOBS_URL,
  }),

  endpoints: (builder) => ({
    getJobDetails: builder.query({
      query: ({ id, internalJobToken }) =>
        utils.buildUrl(
          getJobDetails.endpoint,
          { id: id },
          internalJobToken ? { internal_job_token: internalJobToken } : {},
          false,
        ),
    }),
  }),
});

export const { useGetJobDetailsQuery } = jobDetailsApi;
