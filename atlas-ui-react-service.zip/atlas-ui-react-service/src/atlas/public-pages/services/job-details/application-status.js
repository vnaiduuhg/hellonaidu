import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { APPLICATION_URL } from "../../../../config";
import { getJobApplicationStatus } from "../endpoints";

export const jobApplicationStatusApi = createApi({
  reducerPath: "jobApplicationStatusApi",
  baseQuery: fetchBaseQuery({
    baseUrl: APPLICATION_URL,
  }),
  endpoints: (builder) => ({
    jobApplicationStatusApi: builder.mutation({
      query(body) {
        return {
          url: getJobApplicationStatus.endpoint,
          method: getJobApplicationStatus.method,
          body,
        };
      },
    }),
  }),
});

export const { useJobApplicationStatusApiMutation } = jobApplicationStatusApi;
