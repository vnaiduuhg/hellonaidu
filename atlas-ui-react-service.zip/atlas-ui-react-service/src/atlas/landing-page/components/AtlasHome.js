import { Col, Container, Row } from "react-bootstrap";
import TemporaryLoginComponent from "./TemporaryLoginComponent";
import QuickJwtLogin from "./QuickJwtLogin";

const Home = () => {
  return (
    <Container fluid>
      <Row>
        <Col>
          <h1>The home page</h1>
        </Col>
      </Row>
      <Row>
        <TemporaryLoginComponent />
      </Row>
      <Row className="mt-5">
        <QuickJwtLogin />
      </Row>
    </Container>
  );
};

export default Home;
