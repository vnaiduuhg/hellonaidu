import userSlice from "global/store/userSlice";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";

// New changes in Chrome do not allow for updates to cookies through devtools
// because it's disabling 3rd party cookies. When you're not developing on
// localhost, loging in becomes impossible. This quick fix will all bypass that
// issue.
const QuickJwtLogin = () => {
  const token = useSelector((state) => state.user.token);
  const [jwt, setJwt] = useState("");
  const dispatch = useDispatch();
  const history = useHistory();

  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    dispatch(userSlice.actions.login({ token: jwt }));
    history.push("/planning");
  };

  useEffect(() => {
    if (token) setJwt(token);

    return () => {};
  }, [token]);

  return (
    <>
      {error && (
        <div className="col-xs-12" style={{ color: "red" }}>
          {error.toString()}
        </div>
      )}

      {!token && (
        <form
          onSubmit={handleSubmit}
          className="col-xs-12"
          style={{ marginTop: 10 }}
        >
          <table>
            <tbody>
              <tr>
                <td>
                  <textarea
                    placeholder="Paste Jwt token here for quick login"
                    value={jwt}
                    onChange={(e) => setJwt(e.target.value)}
                    style={{ width: "85vw", height: 75 }}
                  />
                </td>
              </tr>
              <tr>
                <td colSpan="2">
                  <button type="submit">Login</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      )}
    </>
  );
};

export default QuickJwtLogin;
