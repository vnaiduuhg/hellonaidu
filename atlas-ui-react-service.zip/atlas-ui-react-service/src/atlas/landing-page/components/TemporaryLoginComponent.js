import axios from "axios";
import { USER_ACCOUNTS_URL } from "config";
import userSlice from "global/store/userSlice";
import { useState } from "react";
import { unstable_batchedUpdates } from "react-dom";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";

const TemporaryLoginComponent = () => {
  const token = useSelector((state) => state.user.token);
  const dispatch = useDispatch();
  const history = useHistory();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post(`${USER_ACCOUNTS_URL}api/v1/auth/login`, {
        email: username,
        password,
      })
      .then(
        (response) => {
          const token = response.data.data.token;

          unstable_batchedUpdates(() => {
            setError("");
            dispatch(userSlice.actions.login({ token }));
            history.push("/planning");
          });
        },
        (error) => {
          setError(error);
        },
      );
  };

  return (
    <>
      {error && (
        <div className="col-xs-12" style={{ color: "red" }}>
          {error.toString()}
        </div>
      )}

      {/* <div className="col-xs-12">
        Status:{" "}
        {token ? (
          <span style={{ color: "green" }}>Logged In</span>
        ) : (
          <span style={{ color: "red" }}>Not Logged in</span>
        )}
      </div> */}

      {!token && (
        <form
          onSubmit={handleSubmit}
          className="col-xs-12"
          style={{ marginTop: 10 }}
        >
          <table>
            <tbody>
              <tr>
                <td>
                  <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    autoFocus
                  />
                </td>
                <td>
                  <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </td>
              </tr>
              <tr>
                <td colSpan="2">
                  <button type="submit">Login</button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      )}

      {token && (
        <div className="col-xs-12">
          <button
            onClick={(e) => {
              dispatch(userSlice.actions.logout());
            }}
          >
            Logout
          </button>
        </div>
      )}
    </>
  );
};

export default TemporaryLoginComponent;
