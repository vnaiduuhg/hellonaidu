import { Route, Switch } from "react-router-dom";
import AtlasHome from "./components/AtlasHome";

const AtlasRoutes = () => (
  <Switch>
    <Route exact path="/" component={AtlasHome} />
  </Switch>
);

export default AtlasRoutes;
