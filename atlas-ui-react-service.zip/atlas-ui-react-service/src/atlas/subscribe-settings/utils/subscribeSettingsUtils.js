export const setNLFrequencyTranslations = (frequency) => {
  const translations = { fr: "", en: "" };
  switch (frequency) {
    case "daily":
      translations.fr = "journalier";
      translations.en = "Daily";
      break;
    case "weekly":
      translations.fr = "hebdomadaire";
      translations.en = "Weekly";
      break;
    case "bimonthly":
      translations.fr = "bimensuel";
      translations.en = "Bimonthly";
      break;
    case "monthly":
      translations.fr = "mensuel";
      translations.en = "Monthly";
      break;
    default:
      return null;
  }
  return translations;
};
