import { out } from "global/utils/useTranslation";

export const JobAlertSubscriptionMsgHandler = (code, message) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Vos préférences ont été sauvegardées avec succès!",
        "Your preferences have been saved successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 403:
      msg.title = out("Accès refusé!", "Access denied!");
      msg.text = out(
        "Vous n'avez pas l'autorisation requise pour souscrire à cette liste d'envoi",
        "You do not have the required authorization to subscribe to this mailing list",
      );
      break;
    // could glide into default from here
    case 422:
      if (message.receive_alerts || message.receive_newsletters) {
        msg.title = out("Attention!", "Attention!");
        msg.text = out(
          "Veuillez vous assurer de sélectionner au moins l'une des listes d'envoi offertes",
          "Please make sure you select at least one of the mailing lists offered",
        );
        break;
      }
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Vos préférences n'ont pu être sauvegardées, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
        "Your preferences could not be saved, please try again or contact support@workland.com for assistance",
      );
  }
  return msg;
};

export const refreshTokenMsgHandler = (code) => {
  let msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 200:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Vous êtes maintenant connecté avec votre compte candidat!",
        "You are now logged in with your candidate account!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Nous n'avons pu vous reconnecter avec votre compte candidat, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
        "We were unable to reconnect you with your candidate account, please try again or contact support@workland.com for assistance",
      );
  }

  return msg;
};

export const sendCodeVerificationMsgHandler = (code) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 201:
      msg.title = out("Succès!", "Success!");
      msg.text = out(
        "Code de vérification renvoyé avec succès!",
        "Verification code sent back successfully!",
      );
      break;
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    default:
      msg.title = out("Une erreur s'est produite!", "An error has occurred!");
      msg.text = out(
        "Le code de vérification n'a pu être envoyé, veuiller générer un nouveau code de vérification en cliquant sur le lien prévu à cet effet",
        "The verification code could not be sent, please generate a new verification code by clicking on the link provided for this purpose",
      );
  }

  return msg;
};

export const getTempTokenMsgHandler = (code, message = null) => {
  const msg = {
    title: "",
    text: "",
  };

  switch (code) {
    case 401:
      msg.title = out(
        "Votre session est expirée!",
        "Your session has expired!",
      );
      msg.text = out("Veuillez vous connecter à nouveau", "Please login again");
      break;
    case 404:
      if (message && message === "code_not_found") {
        msg.title = out(
          "Code de vérification expiré ou invalide!",
          "Verification code expired or invalid!",
        );
        msg.text = out(
          "Veuillez vérifier à nouveau votre boîte de réception, ou générer un nouveau code de vérification en cliquant sur le lien prévu à cet effet",
          "Please check your inbox again, or generate a new verification code by clicking on the link provided for this purpose",
        );
        break;
      }
    default:
      msg.title = out("Erreur!", "Error!");
      msg.text = out(
        "Une erreur s'est produite avec le code de vérification entré, veuillez vérifier à nouveau votre boîte de réception, ou générer un nouveau code de vérification en cliquant sur le lien prévu à cet effet",
        "An error occurred with the verification code entered, please check your inbox again, or generate a new verification code by clicking on the link provided for this purpose",
      );
  }

  return msg;
};
