import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "global/utils/useTranslation";
import { saveTempToken, deleteTempToken } from "global/utils/authUtils";
import userSlice from "global/store/userSlice";
import statusMessagesSlice, {
  showMessage,
  showLoadingBarWithoutMessage,
} from "global/store/statusMessagesSlice";
import { getJobsGroupsByAccount } from "global/apis/jobsApis";
import { getJobsCategoriesAndFunctions } from "global/apis/sharedApi";
import {
  getUserByEmail,
  registerCandidate,
  refreshToken,
  sendVerificationCode,
  getVerificationCodeToken,
} from "global/apis/userApi";
import {
  createJobAlertPreferences,
  updateJobAlertPreferences,
  getJobAlertPreferences,
} from "./apis/subscribeSettingsApis";
import {
  getUserByEmailMsgHandler,
  registerCandidateMsgHandler,
} from "global/utils/userAccountsMsgHandler";
import {
  JobAlertSubscriptionMsgHandler,
  refreshTokenMsgHandler,
  getTempTokenMsgHandler,
  sendCodeVerificationMsgHandler,
} from "./utils/subscribeMsgHandler";
import SubscribeJobSettings from "./components/SubscribeJobSettings";
import SubscribePreferences from "./components/SubscribePreferences";
import UserIdentificationForSubscribtion from "./components/UserIdentificationForSubscribtion";
import UserVerificationWithCode from "./components/UserVerificationWithCode";
import NewsLettersSubscription from "./components/NewsLettersSubscription";
import CandidateRegistrationForm from "./components/CandidateRegistrationForm";
import CandidateLoginSwitch from "./components/CandidateLoginSwitch";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "./assets/SubscribeSettingsPage.module.css";
import { Col, Container, Row } from "react-bootstrap";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

const SubscribeSettings = ({
  profile,
  user,
  banner,
  logo,
  setActivePage,
  setSubscriptionType,
  setJobsCategoriesList,
  candidatePreferences,
  setCandidatePreferences,
  setShowPreferencesPreview,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const currentLanguage = useSelector((state) => state.user.language);
  const [categoriesArray, setCategoriesArray] = useState([]);
  const [functionsArray, setFunctionsArray] = useState([]);
  const [jobGroupsArray, setJobGroupsArray] = useState([]);
  const [locationArray, setLocationArray] = useState([]);
  const [receiveAlertsSelected, setReceiveAlertsSelected] = useState(false);
  const [receiveNewslettersSelected, setReceiveNewslettersSelected] =
    useState(false);
  const [newsletterFrequency, setNewsletterFrequency] = useState("weekly");
  // identification step
  const [showIdentificationStep, setShowIdentificationStep] = useState(false);
  const [candidateEmail, setCandidateEmail] = useState("");
  const [candidateAccountId, setCandidateAccountId] = useState(0);
  const [registrationType, setRegistrationType] = useState("");
  const [hasCandidateAccount, setHasCandidateAccount] = useState();
  // registration step
  const [showRegistrationStep, setShowRegistrationStep] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [registrationOn, setRegistrationOn] = useState(false);
  // login step
  const [showLoginSwitchStep, setShowLoginSwitchStep] = useState(false);
  const [refreshTokenAccountId, setRefreshTokenAccountId] = useState(0);
  const [loginSuccess, setLoginSuccess] = useState(false);
  // code verification step
  const [showVerificationStep, setShowVerificationStep] = useState(false);
  const [codeVerified, setCodeVerified] = useState(false);
  const [numberOfCodeSent, setNumberOfCodeSent] = useState(0);
  // subscription step
  const [showSubscriptionSubmit, setShowSubscriptionSubmit] = useState(false);
  const [candidateUserId, setCandidateUserId] = useState(0);
  // for process stopped msg - shows after 3 errors
  const [numberProcessError, setNumberProcessError] = useState(0);
  // to scroll down to next step
  const generalProcessErrorRef = useRef();
  const scrollToRef = (ref) =>
    window.scrollTo({
      top: ref.current.offsetTop,
      left: 0,
      behavior: "smooth",
    });
  const executeScroll = (e) => scrollToRef(e);

  useEffect(() => {
    if (user && +user.user_account.role_id !== 70) {
      const accounts = JSON.parse(localStorage.getItem("accounts"));
      if (accounts.length > 1) {
        const hasCandidateAccount = accounts.find(
          (account) => +account.role_id === 70,
        );
        if (hasCandidateAccount) {
          setRefreshTokenAccountId(hasCandidateAccount.account_id);
          setHasCandidateAccount(true);
        } else {
          setRegistrationType("existingUser");
        }
      } else {
        setRegistrationType("existingUser");
      }
    }
  }, [user]);

  useEffect(() => {
    if (numberProcessError > 3) {
      executeScroll(generalProcessErrorRef);
    }
  }, [numberProcessError]);

  useEffect(() => {
    return () => {
      deleteTempToken();
    };
  }, []);

  const resetJobPreferences = () => {
    setCategoriesArray([]);
    setFunctionsArray([]);
    setJobGroupsArray([]);
    setLocationArray([]);
  };

  // Gets jobs groups (by account)
  const {
    data: jobsGroups = [],
    isError: jobsGroupsError,
    isLoading: jobsGroupsIsLoading,
  } = useQuery(
    "jobs-groups-by-account",
    () => getJobsGroupsByAccount(profile.account_id),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
    },
  );

  // Gets jobs categories & functions
  const {
    data: jobsCategories = [],
    isError: jobsCategoriesError,
    isLoading: jobsCategoriesIsLoading,
  } = useQuery(
    "jobs-categories-and-functions",
    () => getJobsCategoriesAndFunctions(),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
      onSuccess: (response) => {
        setJobsCategoriesList(response);
      },
    },
  );

  // user identification by email
  const getUserByEmailApi = useMutation((data) => getUserByEmail(data), {
    onSuccess: (response) => {
      if (response.code === 200) {
        setNumberProcessError(0);
        if (Array.isArray(response.data) && response.data.length < 1) {
          setRegistrationType("newUser");
          setShowRegistrationStep(true);
        } else {
          if (response.data.user_id && response.data.account_id) {
            setCandidateAccountId(response.data.account_id);
            setShowVerificationStep(true);
          } else {
            setRegistrationType("existingUser");
            setCandidateUserId(response.data.user_id);
            setShowRegistrationStep(true);
          }
        }
      } else {
        const msg = getUserByEmailMsgHandler(500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        setNumberProcessError(numberProcessError + 1);
      }
      dispatch(statusMessagesSlice.actions.clearLoaders());
    },
    onError: (error) => {
      const msg = getUserByEmailMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      setNumberProcessError(numberProcessError + 1);
    },
  });

  // register a candidate - new & existing users
  const registerCandidateApi = useMutation((data) => registerCandidate(data), {
    onSuccess: (response) => {
      if (response.code === 201 && response.data?.account.id) {
        if (user) {
          refreshTokenApi.mutate({ account_id: response.data.account.id });
        } else {
          setCandidateAccountId(response.data.account.id);
          setCandidateUserId(0);
          dispatch(statusMessagesSlice.actions.clearLoaders());
          setNumberProcessError(0);
          setShowVerificationStep(true);
        }
        setRegistrationSuccess(true);
      } else {
        const msg = registerCandidateMsgHandler(500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setNumberProcessError(numberProcessError + 1);
      }
      setRegistrationOn(false);
    },
    onError: (error) => {
      const msg = registerCandidateMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      setNumberProcessError(numberProcessError + 1);
      setRegistrationOn(false);
    },
  });

  // reconnect the user with his candidate account
  const refreshTokenApi = useMutation((data) => refreshToken(data), {
    onSuccess: (response) => {
      if (response.data?.account && response.data?.token) {
        localStorage.setItem(
          "account_type",
          response.data.account.account.type,
        );
        localStorage.setItem("account_role", response.data.account.role_id);
        localStorage.setItem("account_id", response.data.account.account_id);
        dispatch(userSlice.actions.updateToken({ token: response.data.token }));
        setLoginSuccess(true);
        setNumberProcessError(0);
        setShowSubscriptionSubmit(true);
        setRefreshTokenAccountId(0);
      } else {
        const msg = refreshTokenMsgHandler(500);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
      }
    },
    onError: (error) => {
      const msg = refreshTokenMsgHandler(error.status);
      dispatch(showMessage("error", msg.title, msg.text, 8000));
      dispatch(statusMessagesSlice.actions.clearLoaders());
      setNumberProcessError(numberProcessError + 1);
    },
  });

  // send a verification code by email
  const sendVerificationCodeApi = useMutation(
    (data) => sendVerificationCode(data),
    {
      onSuccess: (response) => {
        if (response.code === 201) {
          if (numberOfCodeSent > 0) {
            const msg = sendCodeVerificationMsgHandler(201);
            dispatch(showMessage("ok", msg.title, msg.text, 5000));
            dispatch(statusMessagesSlice.actions.clearLoaders());
          }
        } else {
          const msg = sendCodeVerificationMsgHandler(500);
          dispatch(showMessage("error", msg.title, msg.text, 8000));
          dispatch(statusMessagesSlice.actions.clearLoaders());
          setNumberProcessError(numberProcessError + 1);
        }
      },
      onError: (error) => {
        const msg = sendCodeVerificationMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setNumberProcessError(numberProcessError + 1);
      },
    },
  );

  // gets a token from the verification code
  const getVerificationCodeTokenApi = useMutation(
    (data) => getVerificationCodeToken(data.code, data.params),
    {
      onSuccess: (response) => {
        if (response.code === 200 && response.data?.token) {
          saveTempToken(response.data.token);
          setCodeVerified(true);
          setNumberProcessError(0);
          setShowSubscriptionSubmit(true);
        } else {
          const msg = getTempTokenMsgHandler(500);
          dispatch(showMessage("error", msg.title, msg.text, 8000));
          setNumberProcessError(numberProcessError + 1);
          dispatch(statusMessagesSlice.actions.clearLoaders());
        }
      },
      onError: (error) => {
        const msg = getTempTokenMsgHandler(
          error.status,
          error.data?.message ? error.data.message : null,
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setNumberProcessError(numberProcessError + 1);
      },
    },
  );

  // create new preferences
  const createJobAlertPreferencesApi = useMutation(
    (data) => createJobAlertPreferences(data, !!user),
    {
      onSuccess: (response) => {
        setCandidatePreferences([response]);
        setSubscriptionType({
          newUser: registrationType === "newUser" ? true : false,
          newCandidate: registrationType ? true : false,
          firstPreferenceSettings: true,
        });
        resetJobPreferences();
        setActivePage("subscribeSettingsSuccess");
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = JobAlertSubscriptionMsgHandler(error.status);
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setNumberProcessError(numberProcessError + 1);
      },
    },
  );

  // uppdate existing preferences
  const updateJobAlertPreferencesApi = useMutation(
    (data) => updateJobAlertPreferences(data.id, data.data, !!user),
    {
      onSuccess: (response) => {
        setCandidatePreferences([response]);
        setSubscriptionType({
          newUser: registrationType === "newUser" ? true : false,
          newCandidate: registrationType ? true : false,
          firstPreferenceSettings: false,
        });
        resetJobPreferences();
        setActivePage("subscribeSettingsSuccess");
        dispatch(statusMessagesSlice.actions.clearLoaders());
      },
      onError: (error) => {
        const msg = JobAlertSubscriptionMsgHandler(
          error.status,
          error.data && typeof error.data !== "string" ? error.data : null,
        );
        dispatch(showMessage("error", msg.title, msg.text, 8000));
        dispatch(statusMessagesSlice.actions.clearLoaders());
        setNumberProcessError(numberProcessError + 1);
      },
    },
  );

  return (
    <React.Fragment>
      {!jobsCategoriesIsLoading && !jobsGroupsIsLoading && (
        <div className={`${style.subsribeSettingsContainer}`}>
          {banner && logo && (
            <div className={`${style.subsribeSettings}`}>
              <div
                className={style.companyBanner}
                style={{ backgroundImage: `url(${banner})` }}
              ></div>
              <div className={`${style.logoContainer}`}>
                <div>
                  <div className={`${style.logo}`}>
                    <img src={logo} alt="Company logo" />
                  </div>
                </div>
              </div>
            </div>
          )}
          <SubscribeJobSettings
            jobsGroups={jobsGroups}
            jobsCategories={jobsCategories}
            jobsGroupsError={jobsGroupsError}
            jobsCategoriesError={jobsCategoriesError}
            setCategoriesArray={setCategoriesArray}
            setFunctionsArray={setFunctionsArray}
            setJobGroupsArray={setJobGroupsArray}
            locationArray={locationArray}
            setLocationArray={setLocationArray}
          />
          <SubscribePreferences
            setReceiveNewslettersSelected={setReceiveNewslettersSelected}
            receiveNewslettersSelected={receiveNewslettersSelected}
            setReceiveAlertsSelected={setReceiveAlertsSelected}
            receiveAlertsSelected={receiveAlertsSelected}
            setNewsletterFrequency={setNewsletterFrequency}
            newsletterFrequency={newsletterFrequency}
            openNextSection={() => {
              setNumberProcessError(0);
              if (!user) {
                setShowIdentificationStep(true);
              } else {
                if (registrationType) {
                  setShowRegistrationStep(true);
                } else if (hasCandidateAccount) {
                  setShowLoginSwitchStep(true);
                } else {
                  if (!showSubscriptionSubmit)
                    dispatch(showLoadingBarWithoutMessage(200000));
                  setShowSubscriptionSubmit(true);
                }
              }
            }}
            executeScroll={executeScroll}
          />
          {showIdentificationStep && (
            <UserIdentificationForSubscribtion
              candidateEmail={candidateEmail}
              setCandidateEmail={setCandidateEmail}
              getUserByEmail={(e) => {
                dispatch(showLoadingBarWithoutMessage(200000));
                getUserByEmailApi.mutate(e);
              }}
              executeScroll={executeScroll}
            />
          )}
          {showRegistrationStep && (
            <CandidateRegistrationForm
              user={user}
              candidateUserId={candidateUserId}
              companyProfile={profile}
              currentLanguage={currentLanguage}
              emailValue={candidateEmail}
              registrationType={registrationType}
              registerCandidate={(e) => {
                dispatch(showLoadingBarWithoutMessage(200000));
                registerCandidateApi.mutate(e);
              }}
              registrationSuccess={registrationSuccess}
              registrationOn={registrationOn}
              setRegistrationOn={setRegistrationOn}
              executeScroll={executeScroll}
            />
          )}
          {showLoginSwitchStep && (
            <CandidateLoginSwitch
              login={() => {
                dispatch(showLoadingBarWithoutMessage(200000));
                refreshTokenApi.mutate({
                  account_id: refreshTokenAccountId,
                });
              }}
              loginSuccess={loginSuccess}
              executeScroll={executeScroll}
            />
          )}
          {showVerificationStep && (
            <UserVerificationWithCode
              candidateEmail={candidateEmail}
              currentLanguage={currentLanguage}
              sendVerificationCode={(e) => {
                if (numberOfCodeSent > 0) {
                  dispatch(showLoadingBarWithoutMessage(200000));
                }
                sendVerificationCodeApi.mutate(e);
              }}
              getVerificationCode={(e) => {
                dispatch(showLoadingBarWithoutMessage(200000));
                getVerificationCodeTokenApi.mutate(e);
              }}
              codeVerified={codeVerified}
              executeScroll={executeScroll}
              setNumberOfCodeSent={setNumberOfCodeSent}
              numberOfCodeSent={numberOfCodeSent}
              numberProcessError={numberProcessError}
            />
          )}
          {showSubscriptionSubmit &&
            (!user || (user && +user.user_account.role_id === 70)) && (
              <NewsLettersSubscription
                user={user}
                candidateAccountId={candidateAccountId}
                companyProfile={profile}
                receiveNewslettersSelected={receiveNewslettersSelected}
                receiveAlertsSelected={receiveAlertsSelected}
                getJobAlertPreferences={getJobAlertPreferences}
                candidatePreferences={candidatePreferences}
                setCandidatePreferences={setCandidatePreferences}
                setShowPreferencesPreview={setShowPreferencesPreview}
                subscribe={(e) => {
                  dispatch(showLoadingBarWithoutMessage(200000));
                  const data = {
                    employer_account_id: profile.account_id,
                    receive_alerts: +receiveAlertsSelected,
                    receive_newsletters: +receiveNewslettersSelected,
                  };
                  if (receiveNewslettersSelected)
                    data.newsletter_frequency = newsletterFrequency;
                  if (categoriesArray.length)
                    data.category_ids = categoriesArray;
                  if (functionsArray.length) data.function_ids = functionsArray;
                  if (jobGroupsArray.length) data.group_ids = jobGroupsArray;
                  if (locationArray.length) data.location_ids = locationArray;
                  e.action === "create"
                    ? createJobAlertPreferencesApi.mutate(data)
                    : updateJobAlertPreferencesApi.mutate({
                        id: e.id,
                        data: data,
                      });
                }}
                executeScroll={executeScroll}
                setNumberProcessError={setNumberProcessError}
              />
            )}
          {numberProcessError > 3 && (
            <Container className={style.stepContainer}>
              <Row>
                <Col xs={12}>
                  <div className={`${style.atlasSpeechDiv}`}>
                    <img src={atlasRobotLogo} alt="Company logo" />
                    <p>
                      {out(
                        "Désolé! Vous semblez éprouver des difficultés. Veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide.",
                        "Sorry! You seem to be experiencing difficulty. Please try again or contact support@workland.com for assistance.",
                      )}
                    </p>
                  </div>
                </Col>
              </Row>
              <div ref={generalProcessErrorRef}></div>
            </Container>
          )}
        </div>
      )}
      {(jobsGroupsIsLoading || jobsCategoriesIsLoading) && (
        <NestedPageLoader
          message={out(
            "Nous téléchargeons les paramètres d'abonnement",
            "Loading subscribe settings",
          )}
        />
      )}
    </React.Fragment>
  );
};

export default SubscribeSettings;
