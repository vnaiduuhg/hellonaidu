import {
  postRestrictedApi,
  putRestrictedApi,
  getRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
import { getTempToken } from "global/utils/authUtils";

export const createJobAlertPreferences = async (data, isLoggedIn) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.jobs,
      `job-alert/preferences`,
      isLoggedIn ? getToken() : getTempToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const updateJobAlertPreferences = async (id, data, isLoggedIn) => {
  try {
    const reponse = await putRestrictedApi(
      serviceNames.jobs,
      `job-alert/preferences`,
      isLoggedIn ? getToken() : getTempToken(),
      id,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getJobAlertPreferences = async (
  accountId,
  urlParams,
  isLoggedIn,
) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.jobs,
      `job-alert/accounts/${accountId}/preferences?${urlParams}`,
      isLoggedIn ? getToken() : getTempToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
