import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import { ATLAS_UI_URL } from "../../config";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "./assets/SubscribeSettingsPage.module.css";
import { Button, Col, Container, Image, Row } from "react-bootstrap";

const SubscribeSettingsSuccess = ({
  profile,
  banner,
  logo,
  subscriptionType,
  setShowPreferencesPreview,
}) => {
  const { out } = useTranslation();

  return (
    <div className={`${style.subsribeSettingsContainer}`}>
      {banner && logo && (
        <div className={`${style.subsribeSettings}`}>
          <img src={banner} alt="Company banner" />
          <div className={`${style.logoContainer}`}>
            <div>
              <div className={`${style.logo}`}>
                <img src={logo} alt="Company logo" />
              </div>
            </div>
          </div>
        </div>
      )}
      <Container className={style.stepContainer}>
        <Row>
          <Col xs={12} className={style.jobAlertSuccessTitleContainer}>
            {subscriptionType && (
              <>
                <h1 className={`h3 text-center`}>
                  {subscriptionType.firstPreferenceSettings
                    ? out(
                        `Votre abonnement aux alertes d'emploi de ${profile.name} s'est effectué avec succès!`,
                        `Your subscription to ${profile.name} job alerts was successful!`,
                      )
                    : out(
                        `Votre abonnement aux alertes d'emploi de ${profile.name} a été modifié avec succès!`,
                        `Your subscription to ${profile.name} job alerts has been updated successfully!`,
                      )}
                </h1>
                <div className={`${style.jobAlertInfo}`}>
                  <div>
                    <p>
                      {out(
                        "Vous recevrez une alerte par courriel chaque fois qu'une offre d'emploi correspondant à vos préférences est publiée." +
                          (subscriptionType.firstPreferenceSettings
                            ? " Veuillez noter que vous pouvez modifier vos préférences en tout temps."
                            : ""),
                        "You will receive an email alert whenever a job offer matching your preferences is posted." +
                          (subscriptionType.firstPreferenceSettings
                            ? "  Please note that you can change your preferences at any time."
                            : ""),
                      )}
                    </p>
                    {subscriptionType.newCandidate &&
                      subscriptionType.newUser && (
                        <p>
                          {out(
                            `Pour vous aider dans votre recherche d'emplois, nous vous avons créé un compte candidat. Veuillez consulter votre courriel pour plus d'instructions. Si vous ne voyez pas le courriel dans votre boîte de réception, vérifiez votre dossier spam / courrier indésirable.`,
                            `To help accelerate your job search and save you hours of time, we created a candidate account for you. Please check your email for further instructions. If you do not see the email in your inbox, please check your spam / junk folder as it may have found its way there by mistake.`,
                          )}
                        </p>
                      )}
                    {subscriptionType.newCandidate &&
                      !subscriptionType.newUser && (
                        <p>
                          {out(
                            `Pour vous aider dans votre recherche d'emplois, nous vous avons créé un compte candidat. Lors de votre prochaine connexion à Atlas, cliquez sur l'option candidat pour accéder à votre profil.`,
                            `To help accelerate your job search and save you hours of time, we created a candidate account for you. The next time you log in to Atlas, click on the candidate option to access your profile.`,
                          )}
                        </p>
                      )}
                  </div>
                </div>
              </>
            )}
          </Col>
        </Row>
        <Row>
          <Col xs={12}>
            <div className={`${style.atlasSpeechDiv}`}>
              <img src={atlasRobotLogo} />
              <p>
                {out(
                  "Que voudriez-vous faire maintenant?",
                  "What would you like to do now?",
                )}
              </p>
            </div>
          </Col>
          <Col xs={12} className={style.jobAlertSuccessBtn}>
            <Button
              variant="secondary"
              className="float-end"
              type="button"
              onClick={() => {
                window.location = `${ATLAS_UI_URL}careers/${profile.slug}?open=jobs`;
              }}
            >
              {out(`Consulter la liste des postes`, `Consult jobs list`)}
            </Button>
            <Button
              variant="alt-secondary"
              className="float-end"
              type="button"
              onClick={() => {
                setShowPreferencesPreview(true);
              }}
            >
              {out("Consulter mes préférences", "Consult my preferences")}
            </Button>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default SubscribeSettingsSuccess;
