import React, { useState, useEffect } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { useTranslation } from "global/utils/useTranslation";
import { getProfileBySlugName } from "global/apis/userApi";
import { getJobsFunctions } from "global/apis/sharedApi";
import SubscribeSettings from "./SubscribeSettings";
import SubscribeSettingsSuccess from "./SubscribeSettingsSuccess";
import PreferencesPreview from "./components/PreferencesPreview";
import { MINIO_URL } from "../../config";
import { Container } from "react-bootstrap";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";
import { AtlasAlert } from "global/components/atlas-alert";
import style from "./assets/SubscribeSettingsPage.module.css";

const SubscribeSettingsPage = () => {
  const { slugName } = useParams();
  const { out } = useTranslation();
  const user = useSelector((state) => state.user.data);
  const [activePage, setActivePage] = useState("subscribeSettings");
  const [showPreferencesPreview, setShowPreferencesPreview] = useState(false);
  const [subscriptionType, setSubscriptionType] = useState();
  const [jobsCategoriesList, setJobsCategoriesList] = useState([]);
  const [candidatePreferences, setCandidatePreferences] = useState([]);
  const [banner, setBanner] = useState();
  const [logo, setLogo] = useState();
  const [errorStatus, setErrorStatus] = useState(0);

  const {
    data: companyProfile = null,
    isError: companyProfileError,
    isLoading: companyProfileIsLoading,
  } = useQuery(
    "company-profile-by-slug",
    () => getProfileBySlugName(slugName),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
      onError: (error) => {
        setErrorStatus(error.status);
      },
    },
  );

  const {
    data: jobsFunctionsList = [],
    // isError: jobsFunctionsListError,
    // isLoading: jobsFunctionsListIsLoading,
  } = useQuery("jobs-functions", () => getJobsFunctions(), {
    staleTime: 100000 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (companyProfile?.data) {
      setBanner(
        companyProfile.data.banner
          ? MINIO_URL + "media/Profile/Banners/" + companyProfile.data.banner
          : MINIO_URL + "media/Profile/Banners/649_649.jpg",
      );
      setLogo(
        companyProfile.data.alternate_logo_2
          ? MINIO_URL +
              "media/Profile/Logos/" +
              companyProfile.data.alternate_logo_2
          : companyProfile.data.alternate_logo_1
          ? MINIO_URL +
            "media/Profile/Logos/" +
            companyProfile.data.alternate_logo_1
          : companyProfile.data.logo
          ? MINIO_URL + "media/Profile/Logos/" + companyProfile.data.logo
          : MINIO_URL + "media/Profile/Logos/generic_logo.png",
      );
    }
  }, [companyProfile]);

  const translatedTitle = out("Alerte Emploi", "Job Alert");
  useEffect(() => {
    document.title = `${
      companyProfile?.data?.name ? companyProfile.data.name + " - " : ""
    }${translatedTitle} - Workland`;
  }, [translatedTitle]);

  return (
    <div className="page-wrapper-internal-page">
      <div className="content-container">
        <div className={style.subsribeSettingsContainer}>
          {!companyProfileIsLoading && companyProfile?.data && (
            <>
              {activePage === "subscribeSettings" && (
                <SubscribeSettings
                  profile={companyProfile.data}
                  user={user}
                  banner={banner}
                  logo={logo}
                  setActivePage={setActivePage}
                  setSubscriptionType={setSubscriptionType}
                  setJobsCategoriesList={setJobsCategoriesList}
                  candidatePreferences={candidatePreferences}
                  setCandidatePreferences={setCandidatePreferences}
                  setShowPreferencesPreview={setShowPreferencesPreview}
                />
              )}
              {activePage === "subscribeSettingsSuccess" && (
                <SubscribeSettingsSuccess
                  profile={companyProfile.data}
                  banner={banner}
                  logo={logo}
                  subscriptionType={subscriptionType}
                  setShowPreferencesPreview={setShowPreferencesPreview}
                />
              )}
            </>
          )}
          {/* @todo revise if we need all conditions here */}
          {showPreferencesPreview &&
            jobsFunctionsList.length > 0 &&
            jobsCategoriesList.length > 0 &&
            candidatePreferences.length > 0 && (
              <PreferencesPreview
                show={showPreferencesPreview}
                user={user}
                jobsFunctionsList={jobsFunctionsList}
                jobsCategoriesList={jobsCategoriesList}
                candidatePreferences={candidatePreferences}
                setShowPreferencesPreview={setShowPreferencesPreview}
              />
            )}
          {activePage === "subscribeSettings" &&
            !companyProfileIsLoading &&
            companyProfileError && (
              <Container fluid>
                <div className="p-5">
                  <AtlasAlert variant="error">
                    {errorStatus !== 404
                      ? out(
                          "Désolé! Une erreur est survenue et la page n'est pas disponible pour le moment.",
                          "Sorry! An error has occurred and the page is not available at the moment.",
                        )
                      : out(
                          "Désolé! Ce lien est erroné et la page ne peut être affichée.",
                          "Sorry! This link is wrong and the page cannot be displayed",
                        )}
                  </AtlasAlert>
                </div>
              </Container>
            )}
          {companyProfileIsLoading && (
            <NestedPageLoader
              message={out(
                "Nous téléchargeons les paramètres d'abonnement",
                "Loading subscribe settings",
              )}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default SubscribeSettingsPage;
