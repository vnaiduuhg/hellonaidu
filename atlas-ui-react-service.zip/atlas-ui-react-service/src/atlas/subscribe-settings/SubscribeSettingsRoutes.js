import React from "react";
import { Route, Switch } from "react-router-dom";
import SubscribeSettingsPage from "./SubscribeSettingsPage";

const SubscribeSettingsRoutes = () => (
  <Switch>
    <Route exact path="/subscribe-settings/:slugName">
      <SubscribeSettingsPage />
    </Route>
  </Switch>
);

export default SubscribeSettingsRoutes;
