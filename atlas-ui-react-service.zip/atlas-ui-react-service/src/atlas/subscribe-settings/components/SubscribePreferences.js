import React, { useState, useEffect, useRef, Fragment } from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import { useTranslation } from "global/utils/useTranslation";
import style from "../assets/SubscribeSettingsPage.module.css";

const SUBSCRIPTION_FREQUENCY = [
  {
    value: "daily",
    label: ["journalière", "daily"],
    defaultChecked: false,
  },
  {
    value: "weekly",
    label: ["hebdomadaire", "weekly"],
    defaultChecked: true,
  },
  {
    value: "bimonthly",
    label: ["bimensuelle", "bimonthly"],
    defaultChecked: false,
  },
  {
    value: "monthly",
    label: ["mensuelle", "monthly"],
    defaultChecked: false,
  },
];

const SubscribePreferences = ({
  setReceiveNewslettersSelected,
  receiveNewslettersSelected,
  setReceiveAlertsSelected,
  receiveAlertsSelected,
  setNewsletterFrequency,
  newsletterFrequency,
  openNextSection,
  executeScroll,
}) => {
  const { out } = useTranslation();
  const subscribePreferencesRef = useRef();
  const [newSectionOpen, setNewSectionOpen] = useState(false);

  useEffect(() => {
    executeScroll(subscribePreferencesRef);
  }, [executeScroll]);

  return (
    <Container className={style.subscribePreferences}>
      <Row>
        <Col xs={12}>
          <div className="form-check">
            <input
              id="subscribe-newletter"
              type="checkbox"
              disabled={!newsletterFrequency}
              aria-invalid="false"
              value="true"
              className="form-check-input form-check-input-lg"
              onChange={({ target: { checked } }) =>
                setReceiveNewslettersSelected(checked)
              }
            />
            <label className={`form-check-label`} htmlFor="subscribe-newletter">
              <span>
                {out(
                  "Recevoir votre liste de postes par courriel",
                  "Receive your list of positions by email",
                )}
              </span>
            </label>
          </div>
        </Col>

        <Col xs={12} className={style.periodsContainer}>
          <label>{out("Choisir la fréquence:", "Choose frequency:")}</label>

          <div
            className={`${style.periodsInputsContainer}`}
            onChange={({ target: { value } }) => setNewsletterFrequency(value)}
          >
            {SUBSCRIPTION_FREQUENCY.map((frequency) => (
              <Fragment key={frequency.value}>
                <input
                  type="radio"
                  name="span"
                  className="btn-check"
                  id={frequency.value}
                  value={frequency.value}
                  defaultChecked={frequency.defaultChecked}
                />
                <label
                  className="ml-1 mr-1 btn btn-outline-secondary btn-sm px-3 rounded-pill"
                  htmlFor={frequency.value}
                >
                  {out(...frequency.label)}
                </label>
              </Fragment>
            ))}
          </div>
        </Col>
      </Row>

      <Row>
        <Col xs={12}>
          <div className="form-check">
            <input
              type="checkbox"
              aria-invalid="false"
              value="true"
              id="alerts"
              className="form-check-input form-check-input-lg"
              onChange={({ target: { checked } }) =>
                setReceiveAlertsSelected(checked)
              }
            />

            <label className="form-check-label" htmlFor="alerts">
              <span>
                {out(
                  "Recevoir des alertes d'emploi par courriel dès la publication du poste",
                  "Receive job alerts by email as soon as the position is published",
                )}
              </span>
            </label>
          </div>
        </Col>
      </Row>

      {!newSectionOpen && (
        <Row>
          <Col xs={12}>
            <Button
              variant="secondary"
              className="float-end"
              type="button"
              disabled={!receiveNewslettersSelected && !receiveAlertsSelected}
              onClick={() => {
                openNextSection();
                setNewSectionOpen(true);
              }}
            >
              {out("Continuer", "Continue")}
            </Button>
          </Col>
        </Row>
      )}
      <div ref={subscribePreferencesRef}></div>
    </Container>
  );
};

export default SubscribePreferences;
