import React, { useEffect, useRef } from "react";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import { Container, Row, Col, Button } from "react-bootstrap";

const CandidateLoginSwitch = ({ login, loginSuccess, executeScroll }) => {
  const { out } = useTranslation();
  const switchLoginRef = useRef();

  useEffect(() => {
    executeScroll(switchLoginRef);
  }, [executeScroll]);

  return (
    <Container className={style.stepContainer}>
      <Row>
        <Col xs={12}>
          {!loginSuccess && (
            <>
              <div className={style.atlasSpeechDiv}>
                <img src={atlasRobotLogo} />
                <p>
                  {out(
                    "Vous aurez besoin d'être connecté en tant que candidat pour souscrire à ces alertes d'emplois",
                    "You will need to be logged in as a candidate to subscribe to these job alerts",
                  )}
                </p>
              </div>
              <Col xs={12}>
                <Button
                  variant="primary"
                  size="lg"
                  className="float-end"
                  type="button"
                  onClick={() => {
                    login();
                  }}
                >
                  {out(
                    "Me reconnecter avec mon compte candidat",
                    "Reconnect with my candidate account",
                  )}
                </Button>
              </Col>
            </>
          )}
          {loginSuccess && (
            <Col
              xs={12}
              sm={8}
              className={`col-sm-offset-4 float-end ${style.userInputDisplay}`}
            >
              <p>
                <span>
                  {out(
                    "Vous êtes maintenant connecté avec votre compte candidat",
                    "You are now logged in with your candidate account",
                  )}
                </span>
              </p>
            </Col>
          )}
        </Col>
      </Row>
      <div ref={switchLoginRef}></div>
    </Container>
  );
};

export default CandidateLoginSwitch;
