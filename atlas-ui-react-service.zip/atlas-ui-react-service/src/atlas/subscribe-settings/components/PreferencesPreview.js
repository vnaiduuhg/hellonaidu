import React, { useState, useEffect } from "react";
import { useTranslation } from "global/utils/useTranslation";
import { getLocationsByKeyAndValues } from "global/apis/locationApi";
import { setFromattedAddress } from "global/utils/locationUtil";
import { setNLFrequencyTranslations } from "../utils/subscribeSettingsUtils";
import style from "../assets/SubscribeSettingsPage.module.css";
import { Alert, Button, Modal } from "react-bootstrap";
import { BsFillCheckCircleFill } from "react-icons/bs";
import { NestedPageLoader } from "global/components/loaders/nested-page-loader";

const PreferencesPreview = ({
  user,
  show,
  jobsFunctionsList,
  jobsCategoriesList,
  candidatePreferences,
  setShowPreferencesPreview,
}) => {
  const { out } = useTranslation();
  const [frequencyTranslations, setFrequencyTranslations] = useState(null);
  const [functions, setFunctions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [locations, setLocations] = useState([]);
  const [locationsError, setLocationsError] = useState(false);
  const [dataIsloading, setDataIsloading] = useState(true);

  const fetchPreferencesLocations = (arrayOfLocationIds) => {
    getLocationsByKeyAndValues(arrayOfLocationIds, !!user)
      .then((response) => {
        const tempLocationsArray = [];
        arrayOfLocationIds.forEach((locationId) => {
          if (response[locationId]) {
            tempLocationsArray.push(setFromattedAddress(response[locationId]));
          }
        });
        setLocations(tempLocationsArray);
        setDataIsloading(false);
      })
      .catch(() => {
        setLocationsError(true);
        setDataIsloading(false);
      });
  };

  useEffect(() => {
    if (candidatePreferences[0].newsletter_frequency) {
      setFrequencyTranslations(
        setNLFrequencyTranslations(
          candidatePreferences[0].newsletter_frequency,
        ),
      );
    }
    if (candidatePreferences[0].preferred_locations.length > 0) {
      const arrayOfLocationIds =
        candidatePreferences[0].preferred_locations.map(
          (location) => location.location_id,
        );
      fetchPreferencesLocations(arrayOfLocationIds);
    }
    if (candidatePreferences[0].preferred_categories.length > 0) {
      const categories = candidatePreferences[0].preferred_categories.map(
        (c) => {
          return jobsCategoriesList.find(
            (jobCategory) => +jobCategory.id === +c.category_id,
          );
        },
      );
      setCategories(categories);
    }
    if (candidatePreferences[0].preferred_functions.length > 0) {
      const functions = candidatePreferences[0].preferred_functions.map((f) => {
        return jobsFunctionsList.find(
          (jobFunction) => +jobFunction.id === +f.function_id,
        );
      });
      setFunctions(functions);
    }
    if (!candidatePreferences[0].preferred_locations.length)
      setDataIsloading(false);
  }, []);

  return (
    <Modal
      show={show}
      onHide={() => {
        setShowPreferencesPreview(false);
      }}
    >
      <div className="modal-empty-header">
        <button
          type="button"
          className="btn-close"
          onClick={() => setShowPreferencesPreview(false)}
          aria-label={out("Fermer", "Close")}
        />
      </div>

      <Modal.Body className={`${style.preferencesPreviewModal}`}>
        {!dataIsloading && (
          <>
            <div className="mb-4">
              <Alert variant="info">
                <h4 className="text-center">
                  {candidatePreferences[0].receive_alerts > 0 &&
                  candidatePreferences[0].receive_newsletters > 0
                    ? out("Vos abonnements", "Your subscriptions")
                    : out("Votre abonnement", "Your subscription")}
                </h4>
                {candidatePreferences[0].receive_newsletters > 0 &&
                  frequencyTranslations && (
                    <div className="d-flex">
                      <BsFillCheckCircleFill
                        size="2rem"
                        className="mt-1 me-3"
                      />

                      <p>
                        {out(
                          `Abonnement ${frequencyTranslations.fr} à votre liste de postes par courriel`,
                          `${frequencyTranslations.en} subscription to your list of positions by email`,
                        )}
                      </p>
                    </div>
                  )}
                {candidatePreferences[0].receive_alerts > 0 && (
                  <div className="d-flex">
                    <BsFillCheckCircleFill size="2.75rem" className="me-3" />

                    <p>
                      {out(
                        `Abonnement à des alertes d'emploi par courriel dès la publication du poste`,
                        `Subscription to job alerts by email as soon as the position is published`,
                      )}
                    </p>
                  </div>
                )}
              </Alert>
            </div>
            <div className={`${style.preferencesContainer}`}>
              <label>
                {categories.length > 1 || categories.length < 1
                  ? out("Catégories sélectionnées", "Selected categories")
                  : out("Catégorie sélectionnée", "Selected category")}
              </label>
              <ul>
                {categories.length > 0 ? (
                  categories.map((category, i) => {
                    return (
                      <li key={i}>
                        {out(
                          category.translations[1].name,
                          category.translations[0].name,
                        )}
                      </li>
                    );
                  })
                ) : (
                  <li className={`${style.noItemSelected}`}>
                    {out(
                      "Aucune catégorie sélectionnée",
                      "No category selected",
                    )}
                  </li>
                )}
              </ul>
            </div>
            <div className={`${style.preferencesContainer}`}>
              <label>
                {functions.length > 1 || functions.length < 1
                  ? out("Fonctions sélectionnées", "Selected functions")
                  : out("Fonction sélectionnée", "Selected function")}
              </label>
              <ul>
                {functions.length > 0 ? (
                  functions.map((func, i) => {
                    return (
                      <li key={i}>
                        {out(
                          func.translations[1].content,
                          func.translations[0].content,
                        )}
                      </li>
                    );
                  })
                ) : (
                  <li className={`${style.noItemSelected}`}>
                    {out(
                      "Aucune fonction sélectionnée",
                      "No function selected",
                    )}
                  </li>
                )}
              </ul>
            </div>
            <div className={`${style.preferencesContainer}`}>
              <label>
                {candidatePreferences[0].preferred_groups.length > 1 ||
                candidatePreferences[0].preferred_groups.length < 1
                  ? out("Groupes sélectionnés", "Selected groups")
                  : out("Groupe sélectionné", "Selected group")}
              </label>
              <ul>
                {candidatePreferences[0].preferred_groups.length > 0 ? (
                  candidatePreferences[0].preferred_groups.map((group, i) => {
                    return (
                      <li key={i}>
                        {out(
                          group.translations[1].name,
                          group.translations[0].name,
                        )}
                      </li>
                    );
                  })
                ) : (
                  <li className={`${style.noItemSelected}`}>
                    {out("Aucun groupe sélectionné", "No group selected")}
                  </li>
                )}
              </ul>
            </div>
            <div className={`${style.preferencesContainer}`}>
              <label>
                {locations.length > 1 || locations.length < 1
                  ? out("Emplacements sélectionnés", "Selected locations")
                  : out("Emplacement sélectionné", "Selected location")}
              </label>
              <ul>
                {!locationsError && (
                  <>
                    {locations.length > 0 ? (
                      locations.map((location, i) => {
                        return <li key={i}>{location}</li>;
                      })
                    ) : (
                      <li className={`${style.noItemSelected}`}>
                        {out(
                          "Aucun emplacement sélectionné",
                          "No location selected",
                        )}
                      </li>
                    )}
                  </>
                )}
                {locationsError && (
                  <li
                    className={`${style.smallEmptyList} ${style.noItemSelected}`}
                  >
                    <i className="fa fa-exclamation-triangle"></i>
                    <span>
                      {out(
                        "Les emplacements ne sont pas disponibles",
                        "Locations are not available",
                      )}
                    </span>
                  </li>
                )}
              </ul>
            </div>
          </>
        )}
        {dataIsloading && (
          <div className="h-100">
            <NestedPageLoader
              message={out(
                "Nous téléchargeons vos préférences",
                "Loading preferences",
              )}
            />
          </div>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button
          variant="secondary"
          onClick={() => setShowPreferencesPreview(false)}
        >
          {out("Fermer", "Close")}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default PreferencesPreview;
