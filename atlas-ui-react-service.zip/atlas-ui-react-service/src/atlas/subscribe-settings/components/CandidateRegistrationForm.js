import React, { useState, useEffect, useRef } from "react";
import { IMaskInput } from "react-imask";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import {
  Col,
  Container,
  Row,
  Button,
  FloatingLabel,
  Form,
} from "react-bootstrap";

const CandidateRegistrationForm = ({
  user,
  candidateUserId,
  companyProfile,
  currentLanguage,
  emailValue,
  registrationType,
  registerCandidate,
  registrationSuccess,
  registrationOn,
  setRegistrationOn,
  executeScroll,
}) => {
  const { out } = useTranslation();
  const [firstNameValue, setFirstNameValue] = useState("");
  const [lastNameValue, setLastNameValue] = useState("");
  const [phoneValue, setPhoneValue] = useState("");
  const [firstNameValidated, setFirstNameValidated] = useState(false);
  const [lastNameValidated, setLastNameValidated] = useState(false);
  const [phoneValidated, setPhoneValidated] = useState(false);
  const [phoneErrorMsg, setPhoneErrorMsg] = useState(false);
  const phoneRegExp = /^(\+?\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/g;
  const registrationRef = useRef();
  const maskOptions = {
    mask: "(000) 000-0000",
  };

  useEffect(() => {
    executeScroll(registrationRef);
  }, []);

  return (
    <Container className={style.stepContainer}>
      <Row>
        <Col xs={12}>
          <div className={`${style.inputWrapper}`}>
            {registrationType === "newUser" && (
              <>
                <div className={`${style.atlasSpeechDiv}`}>
                  <img src={atlasRobotLogo} />
                  <p>
                    {out(
                      "Vous y êtes presque! Nous avons besoin de quelques informations additionnelles afin de créer votre compte candidat.",
                      "You are almost there! We need some additional information in order to create your candidate account.",
                    )}
                  </p>
                </div>
                {!registrationSuccess && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();

                      const phoneValueStripped = phoneValue.replace(
                        /[().-]|\s/g,
                        "",
                      );
                      if (phoneValueStripped.length >= 10) {
                        setRegistrationOn(true);
                        registerCandidate({
                          email: emailValue,
                          username: emailValue,
                          first_name: firstNameValue,
                          last_name: lastNameValue,
                          phone: phoneValue,
                          language: currentLanguage,
                          is_quick_registration: true,
                          owner_account_ids: [companyProfile.account_id],
                        });
                      } else {
                        setPhoneErrorMsg(true);
                      }
                    }}
                  >
                    <Row className="g-3">
                      <Col xs={12} sm={6}>
                        <FloatingLabel label={out("Prénom", "First name")}>
                          <Form.Control
                            type="text"
                            // placeholder={out("Prénom", "First name")}
                            placeholder=" "
                            value={firstNameValue}
                            onChange={(e) => {
                              setFirstNameValue(e.target.value);
                              setFirstNameValidated(e.target.value.length > 1);
                            }}
                          />
                        </FloatingLabel>
                      </Col>
                      <Col xs={12} sm={6}>
                        <FloatingLabel label={out("Nom", "Last name")}>
                          <Form.Control
                            type="text"
                            placeholder={out("Nom", "Last name")}
                            value={lastNameValue}
                            onChange={(e) => {
                              setLastNameValue(e.target.value);
                              setLastNameValidated(e.target.value.length > 1);
                            }}
                          />
                        </FloatingLabel>
                      </Col>

                      <Col xs={12} sm={6}>
                        <div className="form-floating">
                          <IMaskInput
                            id="phone"
                            className="form-control"
                            type="text"
                            // placeholder="(123) 456-7890"
                            placeholder=" "
                            value={phoneValue}
                            onChange={({ target: { value } }) => {
                              setPhoneValue(value);
                              setPhoneValidated(phoneRegExp.test(value));
                              if (phoneErrorMsg) setPhoneErrorMsg(false);
                            }}
                            {...maskOptions}
                          />
                          <label htmlFor="phone">
                            {out("Numéro de téléphone", "Phone number")}
                          </label>
                        </div>

                        {phoneErrorMsg && (
                          <span className={`${style.validationError}`}>
                            *&nbsp;
                            {out(
                              "Le numéro de téléphone est invalide",
                              "The phone number is invalid",
                            )}
                          </span>
                        )}
                      </Col>
                      <Col xs={12} sm={6} md={4}>
                        <Button
                          variant="primary"
                          className="btn-lg-float w-75"
                          type="submit"
                          disabled={
                            !firstNameValidated ||
                            !lastNameValidated ||
                            !phoneValidated ||
                            !emailValue ||
                            registrationOn
                          }
                        >
                          {out("Soumettre", "Submit")}
                        </Button>
                      </Col>
                    </Row>
                  </form>
                )}
              </>
            )}
            {registrationType === "existingUser" && (
              <>
                <div className={`${style.atlasSpeechDiv}`}>
                  <img src={atlasRobotLogo} />
                  <p>
                    {out(
                      "Nous avons besoin de créer votre compte candidat avant de soumettre votre demande.",
                      "We need to create your candidate account before submitting your request.",
                    )}
                  </p>
                </div>
                {!registrationSuccess && (
                  <Col xs={12}>
                    <Button
                      variant="primary"
                      className="float-end"
                      type="button"
                      onClick={() => {
                        registerCandidate({
                          user_id: user ? user.user_id : candidateUserId,
                          owner_account_ids: [companyProfile.account_id],
                        });
                      }}
                    >
                      {out(
                        "Créer mon compte candidat",
                        "Create my candidate account",
                      )}
                    </Button>
                  </Col>
                )}
              </>
            )}
          </div>

          {registrationSuccess && (
            <Col
              xs={12}
              sm={8}
              className={`col-sm-4 offset-sm-4  ${style.userInputDisplay}`}
            >
              <p>
                <span>
                  {out(
                    "Votre compte candidat a été créé avec succèss!",
                    "Your candidate account has been successfully created!",
                  )}
                </span>
              </p>
            </Col>
          )}
        </Col>
      </Row>
      <div ref={registrationRef}></div>
    </Container>
  );
};

export default CandidateRegistrationForm;
