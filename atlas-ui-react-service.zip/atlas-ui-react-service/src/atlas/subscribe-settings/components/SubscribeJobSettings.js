import React, { useEffect, useState } from "react";
import Tooltip from "@material-ui/core/Tooltip";
import GoogleAutocomplete from "global/components/GoogleAutocomplete";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import { Col, Container, Row } from "react-bootstrap";
import { AtlasAlert } from "global/components/atlas-alert";
import { AtlasSelect } from "global/components/select/atlas-select";
import { BiWorld } from "react-icons/bi";
import { AiFillInfoCircle } from "react-icons/ai";

const SubscribeJobSettings = ({
  jobsGroups,
  jobsCategories,
  jobsGroupsError,
  jobsCategoriesError,
  setCategoriesArray,
  setFunctionsArray,
  setJobGroupsArray,
  locationArray,
  setLocationArray,
}) => {
  const { out } = useTranslation();
  const [jobsGroupsOptions, setJobsGroupsOptions] = useState([]);
  const [categoriesOptions, setCategoriesOptions] = useState([]);
  const [functionsOptions, setFunctionsOptions] = useState([]);
  const [formattedAddressesArray, setFormattedAddressesArray] = useState([]);
  const [editLocation, setEditLocation] = useState(false);

  useEffect(() => {
    // sets jobs groups for react-select
    const jOptions = [];
    jobsGroups.forEach((group) => {
      jOptions.push({
        value: group.id,
        label: out(group.translations[1].name, group.translations[0].name),
      });
    });
    setJobsGroupsOptions(jOptions);

    // sets categories for react-select
    const catOptions = [];
    jobsCategories.forEach((cat) => {
      catOptions.push({
        value: cat.id,
        label: out(cat.translations[1].name, cat.translations[0].name),
        default_functions: cat.default_functions,
      });
    });
    setCategoriesOptions(catOptions);

    return () => {};
  }, [jobsCategories, jobsGroups, out]);

  const jobCategoriesHandler = (e) => {
    // sets the functions for react-select selected categories
    const tempFunctionsArray = [];
    const tempCategoriesArray = [];
    e.forEach((f) => {
      let optionsObj = {};
      optionsObj.label = f.label;
      optionsObj.options = [];
      f.default_functions.forEach((fList) => {
        optionsObj.options.push({
          label: out(
            fList.translations[1].content,
            fList.translations[0].content,
          ),
          value: fList.id,
        });
      });
      tempFunctionsArray.push(optionsObj);
      // sets the categories to be saved
      tempCategoriesArray.push(f.value);
    });
    setFunctionsOptions(tempFunctionsArray);
    setCategoriesArray(tempCategoriesArray);
  };

  const categoryFunctionsHandler = (e) => {
    const tempFunctionsArray = [];
    e.forEach((f) => {
      tempFunctionsArray.push(f.value);
    });
    setFunctionsArray(tempFunctionsArray);
  };

  const jobGroupsHandler = (e) => {
    const tempJobGroups = [];
    e.forEach((jobGroup) => {
      tempJobGroups.push(jobGroup.value);
    });
    setJobGroupsArray(tempJobGroups);
  };

  // adds a new address
  const handleSelectedLocation = (e) => {
    let tempFormattedAddresses = [...formattedAddressesArray];
    let tempLocationArray = [...locationArray];
    const locationIndex = tempLocationArray.findIndex(
      (id) => id === +e.location.id,
    );
    if (locationIndex < 0) {
      tempFormattedAddresses.push({
        formattedAddress: e.formattedAddress,
        locationId: +e.location.id,
      });
      setFormattedAddressesArray(tempFormattedAddresses);
      tempLocationArray.push(e.location.id);
      setLocationArray(tempLocationArray);
    }
    setEditLocation(false);
  };

  // removes a selected address
  const deleteLocationHandler = (item, index) => {
    let tempFormattedAddresses = [...formattedAddressesArray];
    let tempLocationArray = [...locationArray];
    const locationIndex = tempLocationArray.findIndex(
      (id) => id === item.locationId,
    );
    if (locationIndex > -1) {
      tempFormattedAddresses.splice(index, 1);
      setFormattedAddressesArray(tempFormattedAddresses);
      tempLocationArray.splice(locationIndex, 1);
      setLocationArray(tempLocationArray);
    }
  };

  // sets category labels for functions select
  const formatGroupLabel = (data) => (
    <div className={`${style.groupStyles}`}>
      <span>{data.label}</span>
      <span className={`float-end ${style.groupBadgeStyles}`}>
        {data.options.length}
      </span>
    </div>
  );

  return (
    <Container className={style.jobsPreferences}>
      <div className={`${style.atlasSpeechDiv} mb-3`}>
        <img src={atlasRobotLogo} />
        <p>
          {out(
            "Veuillez d'abord définir vos préférences afin de recevoir des alertes d'emploi pertinentes.",
            "Please set your preferences first in order to receive relevant job alerts.",
          )}
        </p>
      </div>

      <Row className="g-4">
        <Col xs={12} lg={6} className={``}>
          <label>{out("Catégories d'emplois", "Job categories")}</label>
          {!jobsCategoriesError && (
            <AtlasSelect
              placeholder={out(
                "Veuillez sélectionner une catégorie",
                "Please select a category",
              )}
              isMulti
              isClearable
              name="groups"
              options={categoriesOptions}
              onChange={jobCategoriesHandler}
            />
          )}
          {jobsCategoriesError && (
            <AtlasAlert variant="error" className="py-3 mb-0">
              {out(
                "Les catégories d'emplois ne sont pas disponibles",
                "Job categories are not available",
              )}
            </AtlasAlert>
          )}
        </Col>
        <Col xs={12} lg={6} className="">
          <label>{out("Fonctions", "Functions")}</label>
          {!jobsCategoriesError && functionsOptions.length < 1 && (
            <span className="text-muted">
              &nbsp;&nbsp;
              <i>
                {out(
                  "Veuillez sélectionner une catégorie d'abord",
                  "Please select a category first",
                )}
              </i>
            </span>
          )}
          {!jobsCategoriesError && (
            <AtlasSelect
              placeholder={out(
                "Veuillez sélectionner une fonction",
                "Please select a function",
              )}
              isMulti
              isClearable
              isDisabled={!functionsOptions.length}
              name="groups"
              options={functionsOptions}
              formatGroupLabel={formatGroupLabel}
              onChange={categoryFunctionsHandler}
            />
          )}
          {jobsCategoriesError && (
            <AtlasAlert variant="error" className="py-3 mb-0">
              {out(
                "Les fonctions ne sont pas disponibles",
                "Functions are not available",
              )}
            </AtlasAlert>
          )}
        </Col>

        <Col xs={12} lg={6} className="">
          <label>{out("Groupes d'emplois", "Job groups")}</label>
          {jobsGroupsOptions.length < 1 && (
            <span className="text-muted">
              &nbsp;&nbsp;
              <i>
                {out(
                  "Aucun groupe d'emplois disponible",
                  "No job groups available",
                )}
              </i>
            </span>
          )}
          {!jobsGroupsError && (
            <AtlasSelect
              placeholder={out(
                "Veuillez sélectionner un groupe",
                "Please select a group",
              )}
              isMulti
              isClearable
              name="groups"
              options={jobsGroupsOptions}
              isDisabled={jobsGroupsOptions.length < 1}
              onChange={jobGroupsHandler}
            />
          )}
          {jobsGroupsError && (
            <AtlasAlert variant="error" className="py-3 mb-0">
              {out(
                "Les groupes d'emplois ne sont pas disponibles",
                "Job groups are not available",
              )}
            </AtlasAlert>
          )}
        </Col>
        <Col xs={12} lg={6} className={`${style.locationDiv}`}>
          <label>{out("Emplacement", "Location")}</label>&nbsp;&nbsp;
          <Tooltip
            placement="top-start"
            title={
              <div className="text-center p-1 h6">
                {out(
                  "Nous vous recommandons fortement de choisir des villes comme emplacements",
                  "We strongly recommend that you choose cities as locations",
                )}
              </div>
            }
          >
            <span>
              <AiFillInfoCircle className="text-secondary mb-1 me-1 fs-5" />
            </span>
          </Tooltip>
          {!editLocation && (
            <div className="input-group floating-input-group-prepend">
              <div className="input-group-text input-group-prepend text-secondary">
                <BiWorld />
              </div>
              <div className="form-floating form-floating-group flex-grow-1">
                <input
                  id="googleLocation"
                  className="form-control"
                  name="googleLocation"
                  onClick={() => setEditLocation(true)}
                  placeholder=" "
                />

                <label htmlFor="googleLocation">
                  {out("Ajouter une adresse", "Add location")}
                </label>
              </div>
            </div>
          )}
          {editLocation && (
            <GoogleAutocomplete
              autocompletCallback={handleSelectedLocation}
              label={["Ajouter une adresse", "Add location"]}
            />
          )}
          {formattedAddressesArray.length > 0 && (
            <div className="mt-2">
              {formattedAddressesArray.map((item, i) => {
                return (
                  <span
                    key={i}
                    className={`form-control ${style.autoCompleteDisplaySpan}`}
                    name="location"
                    id="location"
                  >
                    {item.formattedAddress}
                    <span
                      onClick={() => {
                        deleteLocationHandler(item, i);
                      }}
                    >
                      <i className="fa fa-trash" aria-hidden="true"></i>
                    </span>
                  </span>
                );
              })}
            </div>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default SubscribeJobSettings;
