import React, { useState, useEffect, useRef } from "react";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import {
  Button,
  Col,
  Container,
  FloatingLabel,
  Form,
  Image,
  Row,
} from "react-bootstrap";

const UserVerificationWithCode = ({
  candidateEmail,
  currentLanguage,
  sendVerificationCode,
  getVerificationCode,
  codeVerified,
  executeScroll,
  numberOfCodeSent,
  setNumberOfCodeSent,
}) => {
  const { out } = useTranslation();
  const [codeValue, setCodeValue] = useState("");
  const verificationRef = useRef();

  useEffect(() => {
    executeScroll(verificationRef);
    setNumberOfCodeSent(numberOfCodeSent + 1);
    sendVerificationCode({
      email: candidateEmail,
      locale: currentLanguage,
    });
  }, []);

  return (
    <Container className={style.stepContainer}>
      <Row>
        <Col xs={12}>
          <>
            <div className={`${style.atlasSpeechDiv}`}>
              <img src={atlasRobotLogo} />
              <p>
                {out(
                  `Nous vous avons envoyé un code de vérification à ${candidateEmail}`,
                  `We have sent you a verification code at ${candidateEmail}`,
                )}
              </p>
            </div>
            {!codeVerified && (
              <>
                <div className={`d-flex ${style.inputWrapper}`}>
                  <Col xs={12} sm={6}>
                    <FloatingLabel
                      label={out(
                        "Saisir votre code de vérification",
                        "Enter your verification code",
                      )}
                    >
                      <Form.Control
                        maxLength="6"
                        placeholder=" "
                        value={codeValue}
                        onChange={({ target: { value } }) => {
                          const regex = /\D/g;
                          setCodeValue(value.replace(regex, ""));
                        }}
                      />
                    </FloatingLabel>
                  </Col>
                  <Col xs={12} sm={2} className="mx-4">
                    <Button
                      variant="primary"
                      type="button"
                      className="btn-lg-float"
                      disabled={!codeValue || codeValue.length < 6}
                      onClick={() => {
                        getVerificationCode({
                          code: codeValue,
                          params: `email=${candidateEmail}`,
                        });
                      }}
                    >
                      {out("Soumettre", "Submit")}
                    </Button>
                  </Col>
                </div>
                <Col xs={12} className={style.smallNotification}>
                  <label>
                    {out(
                      "Vous n'avez pas reçu de code? Vérifiez d'abord votre dossier spam / courrier indésirable. Si vous n'avez toujours pas de code, cliquer",
                      "Haven't received a code? Check your spam / junk folder first. If you still don't have a code, click",
                    )}
                  </label>
                  <Button
                    variant="link"
                    bsPrefix={style.smallNotificationButton}
                    type="button"
                    disabled={numberOfCodeSent > 3}
                    onClick={() => {
                      setNumberOfCodeSent(numberOfCodeSent + 1);
                      sendVerificationCode({
                        email: candidateEmail,
                        locale: currentLanguage,
                      });
                    }}
                  >
                    {out(
                      "renvoyez-moi un code de vérification",
                      "resend me a verification code",
                    )}
                  </Button>
                </Col>
              </>
            )}
          </>
          {codeVerified && (
            <Col
              xs={12}
              sm={8}
              className={`col-sm-offset-4 ${style.userInputDisplay}`}
            >
              <p>
                <span>******</span>
              </p>
            </Col>
          )}
        </Col>
      </Row>
      <div ref={verificationRef}></div>
    </Container>
  );
};

export default UserVerificationWithCode;
