import React, { useState, useEffect, useRef } from "react";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import {
  Button,
  Col,
  Container,
  FloatingLabel,
  Form,
  Image,
  Row,
} from "react-bootstrap";

const UserIdentificationForSubscribtion = ({
  candidateEmail,
  setCandidateEmail,
  getUserByEmail,
  executeScroll,
}) => {
  const { out } = useTranslation();
  const [emailValue, setEmailValue] = useState("");
  const [emailValidated, setEmailValidated] = useState(false);
  const regExp = /^[^@]+@{1}([^@]+\.)+\w{2,}$/g;
  const identificationRef = useRef();

  useEffect(() => {
    executeScroll(identificationRef);
  }, [executeScroll]);

  return (
    <Container className={style.stepContainer}>
      <Row>
        <Col xs={12}>
          <div className={`${style.atlasSpeechDiv}`}>
            <img src={atlasRobotLogo} />
            <p>
              {out(
                "Veuillez saisir votre adresse courriel.",
                "Please enter your email address.",
              )}
            </p>
          </div>
          {!candidateEmail && (
            <form
              onSubmit={(e) => {
                e.preventDefault();

                setCandidateEmail(emailValue);
                getUserByEmail({
                  email: emailValue,
                  type: "candidate",
                });
              }}
            >
              <div className={`d-flex ${style.inputWrapper} me-3`}>
                <div className="d-flex w-100">
                  <FloatingLabel
                    className="w-100"
                    label={out(
                      "Courriel (abc@exemple.com)",
                      "Email (abc@example.com)",
                    )}
                  >
                    <Form.Control
                      type="email"
                      className="form-control mx-auto"
                      // placeholder={out("abc@exemple.com", "abc@example.com")}
                      placeholder=" "
                      value={emailValue}
                      onChange={({ target: { value } }) => {
                        setEmailValue(value);
                        setEmailValidated(regExp.test(value));
                      }}
                    />
                  </FloatingLabel>

                  <Button
                    variant="primary"
                    type="submit"
                    className="ms-3"
                    disabled={!emailValidated}
                  >
                    {out("Soumettre", "Submit")}
                  </Button>
                </div>
              </div>
            </form>
          )}
          {candidateEmail && (
            <Col
              xs={12}
              sm={8}
              className={`col-sm-4 offset-sm-4 ${style.userInputDisplay}`}
            >
              <p>
                <span>{candidateEmail}</span>
              </p>
            </Col>
          )}
        </Col>
      </Row>
      <div ref={identificationRef}></div>
    </Container>
  );
};

export default UserIdentificationForSubscribtion;
