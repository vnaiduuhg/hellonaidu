import React, { useEffect, useRef } from "react";
import { useQuery } from "react-query";
import { useDispatch } from "react-redux";
import statusMessagesSlice from "global/store/statusMessagesSlice";
import { useTranslation } from "global/utils/useTranslation";
import atlasRobotLogo from "global/assets/images/robot_talk.png";
import style from "../assets/SubscribeSettingsPage.module.css";
import { Col, Container, Row, Button } from "react-bootstrap";

const NewsLettersSubscription = ({
  user,
  candidateAccountId,
  companyProfile,
  receiveNewslettersSelected,
  receiveAlertsSelected,
  getJobAlertPreferences,
  candidatePreferences,
  setCandidatePreferences,
  setShowPreferencesPreview,
  subscribe,
  executeScroll,
  setNumberProcessError,
}) => {
  const { out } = useTranslation();
  const dispatch = useDispatch();
  const subscribeRef = useRef();

  useEffect(() => {
    executeScroll(subscribeRef);
  }, [executeScroll]);

  // Gets jobs categories & functions
  const {
    data: jobAlertPreferences = null,
    isError: jobAlertPreferencesError,
    isLoading: jobAlertPreferencesIsLoading,
  } = useQuery(
    "job-alert-preferences",
    () =>
      getJobAlertPreferences(
        user ? user.user_account.account_id : candidateAccountId,
        `employer_account_ids[]=${companyProfile.account_id}`,
        !!user,
      ),
    {
      staleTime: 100000 * 60 * 1000,
      refetchOnWindowFocus: false,
      onSuccess: (response) => {
        setCandidatePreferences(response);
      },
      onError: () => {
        setNumberProcessError(4);
      },
    },
  );

  useEffect(() => {
    if (!jobAlertPreferencesIsLoading) {
      dispatch(statusMessagesSlice.actions.clearLoaders());
    }
  }, [dispatch, jobAlertPreferencesIsLoading]);

  return (
    <Container className={style.subscribePreferences}>
      {!jobAlertPreferencesIsLoading && !jobAlertPreferencesError && (
        <Row>
          <div className={`mt-5 ${style.atlasSpeechDiv}`}>
            <img src={atlasRobotLogo} />
            <p>
              {out(
                "Excellent! Vous pouvez maintenant soumettre vos préférences!",
                "Great! You can now submit your preferences!",
              )}
            </p>
          </div>
          {!!candidatePreferences?.length && (
            <Col xs={12} className={style.smallNotification}>
              <label>
                {out(
                  "Veuillez noter que vos préférences actuelles seront remplacées par celles que vous vous apprêtez à soumettre.",
                  "Please note that your current preferences will be replaced with those you are about to submit.",
                )}
              </label>
              <br />
              <Button
                variant="secondary"
                bsPrefix={style.smallNotificationButton}
                onClick={() => {
                  setShowPreferencesPreview(true);
                }}
              >
                {out("Consulter mes préférences", "Consult my preferences")}
              </Button>
            </Col>
          )}
          <div className={`${style.inputWrapper}`}>
            <Col xs={12}>
              <Button
                variant="primary"
                className="float-end"
                type="button"
                disabled={!receiveAlertsSelected && !receiveNewslettersSelected}
                onClick={() => {
                  subscribe({
                    action:
                      jobAlertPreferences !== null &&
                      jobAlertPreferences.length > 0
                        ? "update"
                        : "create",
                    id:
                      jobAlertPreferences !== null &&
                      jobAlertPreferences.length > 0
                        ? jobAlertPreferences[0].id
                        : null,
                  });
                }}
              >
                {out("Soumettre", "Submit")}
              </Button>
            </Col>
          </div>
        </Row>
      )}
      <div ref={subscribeRef}></div>
    </Container>
  );
};

export default NewsLettersSubscription;
