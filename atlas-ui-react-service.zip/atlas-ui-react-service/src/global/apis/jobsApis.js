import { getUnrestrictedApi } from "../utils/apiUtils";
import { serviceNames } from "../utils/serviceNames";

export const getJobsGroupsByAccount = async (accountId) => {
  const reponse = await getUnrestrictedApi(
    serviceNames.jobs,
    `group/account/${accountId}/groups`,
  );

  return reponse;
};
