import { getRestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getRoles = async () => {
  const response = await getRestrictedApi(
    serviceNames.authorization,
    `roles`,
    getToken(),
  );

  return response.data.roles;
};
