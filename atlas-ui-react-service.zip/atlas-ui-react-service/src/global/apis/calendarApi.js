import {
  getRestrictedApi,
  postRestrictedApi,
  getUnrestrictedApi,
  postUnrestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
import store from "global/store/store";

export const getCurrentUserCalendarAccount = async () => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.calendar,
      `calendar-accounts`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const syncCalendarAccountByProvider = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.calendar,
      `calendar-accounts`,
      getToken(),
      data,
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const desyncCalendarAccountByProvider = async () => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.calendar,
      `calendar-accounts`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
