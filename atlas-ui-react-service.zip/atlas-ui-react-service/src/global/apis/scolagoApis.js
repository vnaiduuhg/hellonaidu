import {
  getRestrictedApi,
  postRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const isScolagoAccountSynced = async (accountId) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.substituteTeacher,
      `substitutus/accounts/${accountId}/is-synced`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const syncScolagoAccount = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.substituteTeacher,
      `substitutus/accounts`,
      getToken(),
      data,
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const unsyncScolagoAccount = async (accountId) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.substituteTeacher,
      `substitutus/accounts/${accountId}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
