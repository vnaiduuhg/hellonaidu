import {
  getEmailTemplatesByUser,
  getEmailTemplatesByAccount,
  getAllEmailTemplates,
  getSmsTemplatesByUser,
  getSmsTemplatesByAccount,
  getAllSmsTemplates,
  getCategoriesByAccount,
  getCategoriesByUser,
  getCategories,
} from "../messagingApi";

export const authLevelApiOptions = {
  user: {
    key: "user",
    emailTemplateApi: getEmailTemplatesByUser,
    smsTemplateApi: getSmsTemplatesByUser,
    categoryApi: getCategoriesByUser,
  },

  account: {
    key: "account",
    emailTemplateApi: getEmailTemplatesByAccount,
    smsTemplateApi: getSmsTemplatesByAccount,
    categoryApi: getCategoriesByAccount,
  },

  admin: {
    key: "all",
    emailTemplateApi: getAllEmailTemplates,
    smsTemplateApi: getAllSmsTemplates,
    categoryApi: getCategories,
  },
};
