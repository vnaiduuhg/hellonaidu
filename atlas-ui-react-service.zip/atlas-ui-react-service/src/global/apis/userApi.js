import {
  getRestrictedApi,
  postRestrictedApi,
  getUnrestrictedApi,
  postUnrestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
import store from "global/store/store";

export const getAccountProfile = async () => {
  const userAccount = store.getState().user.data?.user_account ?? null;

  let urlAction;
  switch (userAccount.role_id) {
    case 70:
      urlAction = "accounts/candidates/";
      break;
    case 100:
      urlAction = "accounts/agencies/";
      break;
    case 40:
      urlAction = "accounts/clients/";
      break;
    default:
      if (userAccount.account.type === "company") {
        urlAction = "accounts/companies/";
      } else {
        urlAction = "accounts/agencies/";
      }
  }
  return getRestrictedApi(
    serviceNames.accounts,
    `${urlAction}${userAccount.account_id}`,
    getToken(),
  );
};

export const getProfileBySlugName = async (slugName) => {
  try {
    const reponse = await getUnrestrictedApi(
      serviceNames.accounts,
      `accounts/profiles/by-slug/${slugName}`,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getUserByEmail = async (data) => {
  try {
    const reponse = await postUnrestrictedApi(
      serviceNames.accounts,
      `accounts/find`,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const registerCandidate = async (data) => {
  try {
    const reponse = await postUnrestrictedApi(
      serviceNames.accounts,
      `accounts/candidates`,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const loginWithMicrosoftAccount = async () => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.accounts,
      `auth/social-login/microsoft`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getCallbackFromLoginWithProviderAccount = async (data) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.accounts,
      `auth/social-login/${data.provider}/callback?code=${data.codeUrlParam}&redirect_to=sync-calendar&state=${data.stateUrlParam}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const loginWithProviderAccount = async (provider) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.accounts,
      `auth/social-login/${provider}?redirect_to=sync-calendar`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const refreshMicrosoftToken = async (provider, data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.accounts,
      `auth/social-login/${provider}/refresh`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const refreshToken = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.accounts,
      `auth/refresh`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const sendVerificationCode = async (data) => {
  try {
    const reponse = await postUnrestrictedApi(
      serviceNames.accounts,
      `auth/verification-codes`,
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getVerificationCodeToken = async (code, urlParams) => {
  try {
    const reponse = await getUnrestrictedApi(
      serviceNames.accounts,
      `auth/verification-codes/${code}/token?${urlParams}`,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
