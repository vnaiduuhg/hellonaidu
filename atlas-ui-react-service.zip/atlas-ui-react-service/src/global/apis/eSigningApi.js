import {
  getRestrictedApi,
  postRestrictedApi,
  deleteRestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";
// import store from "global/store/store";

export const getDocusignAccount = async () => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.eSigning,
      `docusign/auth/accounts/my-account`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getDocusignAuthRedirectionApi = async () => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.eSigning,
      `docusign/auth/uris`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const postDocusignAuthApi = async (data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.eSigning,
      `docusign/auth/accounts`,
      getToken(),
      data,
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteDocusignAccountApi = async () => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.eSigning,
      `docusign/auth/accounts/my-account`,
      getToken(),
    );
    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getDocusignTemplatesListApi = async () => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.eSigning,
      `docusign/templates`,
      getToken(),
    );
    return reponse.data;
  } catch (e) {
    throw e.response ?? e;
  }
};
