import {
  getRestrictedApi,
  postRestrictedApi,
  deleteRestrictedApi,
} from "../utils/apiUtils";
import { serviceNames } from "../utils/serviceNames";
import { getToken } from "../utils/getToken";

export const getDocumentsRequestTemplates = async () => {
  try {
    const response = await getRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates`,
      getToken(),
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getDocumentTypes = async () => {
  try {
    const response = await postRestrictedApi(
      serviceNames.toolkit,
      `document-manager/fetch-document-types`,
      getToken(),
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const uploadSendRequestFile = async (documentsTemplateId, data) => {
  try {
    const reponse = await postRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates/${documentsTemplateId}/read-request-files`,
      getToken(),
      data,
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const deleteSendRequestFile = async (documentRequestFileId) => {
  try {
    const reponse = await deleteRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates/read-request-files/${documentRequestFileId}`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getSendRequestFileUrl = async (fileId) => {
  try {
    const reponse = await getRestrictedApi(
      serviceNames.toolkit,
      `docutransfer/document-request-templates/read-request-files/${fileId}/url`,
      getToken(),
    );

    return reponse;
  } catch (e) {
    throw e.response ?? e;
  }
};
