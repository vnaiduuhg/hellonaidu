import { getRestrictedApi, patchRestrictedApi } from "../utils/apiUtils";
import { serviceNames } from "../utils/serviceNames";
import { getToken } from "../utils/getToken";
import store from "../store/store";

/* email templates */
export const getAllEmailTemplates = async ({ locale, sort }) =>
  getRestrictedApi(
    serviceNames.messaging,
    "email-templates",
    getToken(),
    locale || sort ? { locale, sort_by: sort } : undefined,
  );

export const getEmailTemplatesByUser = async ({ locale, sort }) => {
  const userId = store.getState().user.data?.user_id ?? null;

  if (!userId) {
    throw new Error("Need to be logged in to get user sms-templates");
  }

  return getRestrictedApi(
    serviceNames.messaging,
    `users/${userId}/email-templates`,
    getToken(),
    locale || sort ? { locale, sort_by: sort } : undefined,
  );
};

// only list by account has withDefaults prop
export const getEmailTemplatesByAccount = async ({
  locale,
  sort,
  withDefaults,
}) => {
  const accountId = store.getState().user.data.user_account?.account_id ?? null;

  if (!accountId) {
    throw new Error("Need to be logged in to get account email-templates");
  }

  return getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/email-templates`,
    getToken(),
    locale || sort || withDefaults
      ? { locale, sort_by: sort, with_defaults: +withDefaults }
      : undefined,
  );
};

/* sms templates */
export const getAllSmsTemplates = async ({ locale, sort }) =>
  getRestrictedApi(
    serviceNames.messaging,
    "sms-templates",
    getToken(),
    locale || sort ? { locale, sort_by: sort } : undefined,
  );

export const getSmsTemplatesByUser = async ({ locale, sort }) => {
  const userId = store.getState().user.data?.user_id ?? null;

  if (!userId) {
    throw new Error("Need to be logged in to get user sms-templates");
  }

  return getRestrictedApi(
    serviceNames.messaging,
    `users/${userId}/sms-templates`,
    getToken(),
    locale || sort ? { locale, sort_by: sort } : undefined,
  );
};

export const getSmsTemplatesByAccount = async ({
  locale,
  sort,
  withDefaults,
}) => {
  const accountId = store.getState().user.data.user_account?.account_id ?? null;

  if (!accountId) {
    throw new Error("Need to be logged in to get account sms-templates");
  }

  return getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/sms-templates`,
    getToken(),
    locale || sort || withDefaults
      ? { locale, sort_by: sort, with_defaults: +withDefaults }
      : undefined,
  );
};

/* email categories */
export const getCategories = async () => {
  const response = await getRestrictedApi(
    serviceNames.messaging,
    "categories",
    getToken(),
  );
  return response;
};

export const getCategoriesByAccount = async () => {
  const accountId = store.getState().user.data.user_account?.account_id ?? null;

  if (!accountId) {
    throw new Error("Not logged in for categories api");
  }

  try {
    const response = await getRestrictedApi(
      serviceNames.messaging,
      `accounts/${accountId}/categories`,
      getToken(),
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getCategoriesByUser = async () => {
  const userId = store.getState().user.data?.user_id ?? null;

  if (!userId) {
    throw new Error("Not logged in for categories api");
  }

  try {
    const response = await getRestrictedApi(
      serviceNames.messaging,
      `users/${userId}/categories`,
      getToken(),
    );
    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getCurrentUserEmailAccounts = async () => {
  try {
    const response = await getRestrictedApi(
      serviceNames.messaging,
      `users/current-user/email-accounts`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const setDefaultEmailAccountsApi = async (
  type,
  data,
  accountId = null,
) => {
  const url =
    type === "regular" ? `users/current-user` : `accounts/${accountId}`;
  try {
    const response = await patchRestrictedApi(
      serviceNames.messaging,
      `${url}/${type}-email-accounts`,
      getToken(),
      null,
      data,
    );

    return { data: response, email_type: type };
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getEventNotificationsByEvent = async (accountId, eventSlug) => {
  const reponse = await getRestrictedApi(
    serviceNames.messaging,
    `accounts/${accountId}/notification-settings`,
    getToken(),
    { event_slug: eventSlug },
  );

  return reponse;
};
