import { getRestrictedApi, getUnrestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getNylasAccountInfo = async () => {
  try {
    const response = await getRestrictedApi(
      serviceNames.shared,
      `preference/preferences`,
      getToken(),
    );

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const getJobsCategoriesAndFunctions = async () => {
  const reponse = await getUnrestrictedApi(serviceNames.shared, `jobCategory`);

  return reponse;
};

export const getJobsFunctions = async () => {
  const reponse = await getUnrestrictedApi(
    serviceNames.shared,
    `jobCategory/function`,
  );

  return reponse;
};
