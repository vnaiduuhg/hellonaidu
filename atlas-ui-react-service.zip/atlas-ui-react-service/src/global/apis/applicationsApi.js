import { postUnrestrictedApi } from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";

// Note, this is a post request behind the scenes. It's used to get Candidates'
// applications
export const getUsersApplications = async (data) => {
  const response = await postUnrestrictedApi(
    serviceNames.application,
    `application/read-all`,
    data,
  );

  return response;
};
