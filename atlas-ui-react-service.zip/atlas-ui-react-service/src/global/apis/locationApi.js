import {
  getRestrictedApi,
  getUnrestrictedApi,
  postRestrictedApi,
  postUnrestrictedApi,
} from "global/utils/apiUtils";
import { serviceNames } from "global/utils/serviceNames";
import { getToken } from "global/utils/getToken";

export const getLocationsByKeyAndValues = async (values, isLoggedIn = true) => {
  if (!values || !Array.isArray(values) || !values.length) {
    throw new Error("Invalid locations values. Must be an array.");
  }

  const valuesString = "&" + values.map((v) => `values[]=${v}`).join("&");

  let response;
  try {
    if (isLoggedIn) {
      response = await getRestrictedApi(
        serviceNames.shared,
        `location/list-by-key-and-values?key=id${valuesString}`,
        getToken(),
      );
    } else {
      response = await getUnrestrictedApi(
        serviceNames.shared,
        `location/list-by-key-and-values?key=id${valuesString}`,
      );
    }

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};

export const saveLocation = async (data, isLoggedIn) => {
  let response;
  try {
    if (isLoggedIn) {
      response = await postRestrictedApi(
        serviceNames.shared,
        `location`,
        getToken(),
        {
          locations: [data],
        },
      );
    } else {
      response = await postUnrestrictedApi(serviceNames.shared, `location`, {
        locations: [data],
      });
    }

    return response;
  } catch (e) {
    throw e.response ?? e;
  }
};
