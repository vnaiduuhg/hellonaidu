import { AtlasSelect } from "global/components/select/atlas-select";
import { Controller } from "react-hook-form";

/**
 * Accepts all ReactSelect props
 */
export const FormHookSelect = ({
  control,
  id,
  name,
  defaultValue,
  options,
  // title,
  rules,
  placeholder,
  setValue,

  // mandatory = false,
  error = null,
  ...props
}) => (
  <Controller
    control={control}
    name={name}
    rules={rules}
    // { value: ***, label: *** }
    defaultValue={defaultValue}
    render={({ field: { onChange, value, ...rest } }) => {
      const selected = options.filter((o) => value === o.value);

      const currentValue = !!selected.length ? selected[0] : null;

      const handleChange = (o) => {
        onChange(o.value);
        setValue(name, o.value);
      };

      const styles = {
        // Fixes the overlapping problem of the component
        menu: (provided) => ({ ...provided, zIndex: 2 }),
        control: (provided, state) => ({
          ...provided,
          border: "1px solid var(--ats-secondary-200)",
          boxShadow: state.isFocused
            ? "0 0 0 3px rgba(var(--ats-secondary-rgb), 0.25)"
            : "",
          transition: "box-shadow 0.15s ease-in-out",
          "&:hover": {
            border: "1px solid var(--ats-secondary-200)",
          },
        }),
        ...(typeof props.styles !== "undefined" ? props.styles : {}),
      };

      return (
        <AtlasSelect
          {...rest}
          {...props}
          id={id}
          styles={styles}
          // aria-labelledby=""
          // aria-errormessage=""
          placeholder={placeholder}
          options={options}
          // for future:
          // loadingMessage={loadingMessage}
          value={currentValue}
          onChange={handleChange}
        />
      );
    }}
  />
);
