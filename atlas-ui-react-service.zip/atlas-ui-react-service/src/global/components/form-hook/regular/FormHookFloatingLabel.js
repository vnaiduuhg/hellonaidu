import { Controller } from "react-hook-form";
import { FloatingLabel, Form } from "react-bootstrap";
import cx from "classnames";
import styles from "./FormHookFloatingLabel.module.css";

// TODO: get to the source of the placeholder problem on ng-app. It's preventing
// label and placeholder from working together. Once fixed, stop overriding
// placeholder prop on all reusable form components
export const FormHookFloatingLabel = ({
  control,
  name,
  title,
  rules,
  type = "text",
  mandatory = false,
  error = null,
  showError = true,
  ...props
}) => (
  <Controller
    control={control}
    name={name}
    rules={rules}
    render={({ field }) => {
      const component = type === "textarea" ? "textarea" : "input";
      return (
        <>
          <FloatingLabel
            className={cx({
              [styles.mandatory]: !!mandatory,
              "text-warning": !!error,
            })}
            label={title}
          >
            <Form.Control
              as={component}
              {...field}
              {...props}
              type={type}
              // placeholder={title}
              placeholder=" "
              isInvalid={!!error}
            />

            {/* show for screen readers */}
            {showError && !!error && (
              <Form.Control.Feedback type="invalid" className="visually-hidden">
                {error.message}
              </Form.Control.Feedback>
            )}
          </FloatingLabel>

          {/* 
            switched to labelled error messages. If this is not possible in 
            floating input groups, then revert to lined error messages 
          */}
          {showError && (
            <div
              className={cx("form-text text-warning", {
                "d-none opacity-0": !error,
              })}
            >
              {error?.message}
            </div>
          )}
        </>
      );
    }}
  />
);
