import React, { useState } from "react";
import { useSelector } from "react-redux";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import DatePicker from "@mui/lab/DatePicker";
import { datetimeToUTC } from "global/utils/dateTimeLanguageUtils";
import frLocale from "date-fns/locale/fr";
import enLocale from "date-fns/locale/en-CA";
import styles from "./SingleDatePicker.module.css";

const localeMap = {
  fr: frLocale,
  en: enLocale,
};

// TODO: get to the source of the placeholder problem on ng-app. It's preventing
// label and placeholder from working together. Once fixed, stop overriding
// placeholder prop on all reusable form components
const SingleDatePicker = ({ id, label, date, setDate, control, ...rest }) => {
  const language = useSelector(({ user }) => user.language);
  const [dateOpen, setDateOpen] = useState(false);

  if (!id) throw new Error("SingleDatePicker requires an id");

  return (
    <LocalizationProvider
      dateAdapter={AdapterDateFns}
      locale={localeMap[language]}
    >
      <DatePicker
        label={label}
        open={dateOpen}
        onClose={() => setDateOpen(false)}
        value={date}
        onChange={(newValue) => setDate(datetimeToUTC(newValue, "flatTime"))}
        renderInput={({ inputRef, inputProps, InputProps }) => (
          <div
            className="input-group floating-input-group-prepend"
            onClick={() => setDateOpen(true)}
          >
            <div className="input-group-text input-group-prepend">
              <div id={styles.adornmentWrapper}>{InputProps.endAdornment}</div>
            </div>
            <div className="form-floating form-floating-group w-100">
              <input
                id={id}
                ref={inputRef}
                control={control}
                className={`form-control ${styles.pointer}`}
                aria-labelledby={`label-${id}`}
                {...inputProps}
                placeholder=" "
              />
              <label id={`label-${id}`} htmlFor={id}>
                {label}
              </label>
            </div>
          </div>
        )}
        {...rest}
      />
    </LocalizationProvider>
  );
};

export default SingleDatePicker;
