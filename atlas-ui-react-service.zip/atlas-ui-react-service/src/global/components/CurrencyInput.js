import { Component } from "react";
import { connect } from "react-redux";
import { IMaskInput } from "react-imask";

// TODO: not functional, work on this later if needed. resets to inital value
// at the end (bug in react hook form perhaps?)

class CurrencyInput extends Component {
  constructor(props) {
    super(props);

    const { value, change, language, ...rest } = props;

    this.value = value;
    this.change = change;
    this.language = language;
    this.rest = rest;
  }

  shouldComponentUpdate() {
    return true;
  }

  render() {
    const currencyMask = {
      mask: Number,
      scale: 2,
      signed: false,
      thousandsSeparator: this.language === "en" ? "," : ".",
      padFractionalZeros: true,
      normalizeZeros: true,
      radix: this.language === "en" ? "." : ",",
      mapToRadix: ["."],
      min: 0,
      max: 9999999999999.99,
    };

    return (
      <IMaskInput
        {...currencyMask}
        type="text"
        unmask={true}
        lazy={false}
        value={this.value}
        onAccept={(v, mask) => this.change(v)}
        {...this.rest}
      />
    );
  }
}

const mapStateToProps = (state) => ({
  language: state.user.language,
});

export default connect(mapStateToProps)(CurrencyInput);
