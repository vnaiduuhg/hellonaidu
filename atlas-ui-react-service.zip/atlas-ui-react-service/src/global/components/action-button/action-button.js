import React from "react";
import { Button } from "react-bootstrap";
import cx from "classnames";

const ActionButton = ({ click, className = null, ...rest }) => (
  <Button
    variant="floating-action"
    onClick={click}
    className={cx({
      [className]: !!className,
    })}
    {...rest}
  />
);

export default ActionButton;
