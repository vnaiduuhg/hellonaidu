import React from "react";
import { connect } from "react-redux";
import { showMessage } from "global/store/statusMessagesSlice";
import StatusMessageContainer from "./StatusMessage/StatusMessageContainer";
import { out } from "global/utils/useTranslation";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.log("error", error);
  }

  render() {
    if (this.state.hasError) {
      this.props.showMessage(
        out("Erreur", "Error"),
        out(
          // TODO: rewrite french message
          "Désolé, une erreur s'est produite. Veuillez contacter support@workland.com pour plus d'aide.",
          "Sorry, there was an error rendering page. Please contact our support team at support@workland.com for further assistance.",
        ),
        5000,
      );

      return <StatusMessageContainer />;
    }

    return this.props.children;
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    showMessage: (title, message) =>
      dispatch(showMessage("error", title, message, 5700)),
  };
};

export default connect(null, mapDispatchToProps)(ErrorBoundary);
