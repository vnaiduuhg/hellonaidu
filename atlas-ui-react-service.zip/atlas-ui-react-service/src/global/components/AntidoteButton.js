import React from "react";
import { useTranslation } from "global/utils/useTranslation";
import AntidoteIcon from "global/assets/images/partnerLogos/antidoteCorrector.svg";
import style from "./AntidoteButton.module.css";

const AntidoteButton = ({ id, ...props }) => {
  const { out } = useTranslation();

  return (
    <>
      <button
        type="button"
        onClick={(e) => {
          e.preventDefault();
        }}
        className={`${style.antidoteButton}`}
        data-antidoteapi_jsconnect_groupe_id={id}
        {...props}
      >
        <img src={AntidoteIcon} />
      </button>
      <span>
        &nbsp;
        {out(
          "Vérifier et corriger l'orthographe avec Antidote",
          "Check and correct spelling with Antidote",
        )}
      </span>
    </>
  );
};

export default AntidoteButton;
