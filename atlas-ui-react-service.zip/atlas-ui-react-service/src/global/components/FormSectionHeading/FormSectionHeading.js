import cx from "classnames";
import styles from "./FormSectionHeading.module.css";

export const FormSectionHeading = ({
  Component = "div",
  containerClasses,
  textClasses,
  children,
  ...props
}) => (
  <div className={`${containerClasses}`} id={styles.container}>
    <Component className={cx("form-section", "h4")} {...props}>
      <span className={textClasses}>{children}</span>
    </Component>
  </div>
);
