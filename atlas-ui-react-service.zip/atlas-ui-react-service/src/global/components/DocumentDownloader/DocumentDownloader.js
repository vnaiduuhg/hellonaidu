import axios from "axios";
import { out } from "global/utils/useTranslation";
import { AtlasAlert } from "../atlas-alert";

export const downloadFile = ({ fileUrl, fileName }) => {
  /* to be redirected to default print-download settings page */
  // window.open(fileUrl, "_blank");

  /* to download directly the file on download folder - w/o opening it */
  axios
    .get(fileUrl, { responseType: "blob" })
    .then((response) => {
      const url = window.URL.createObjectURL(
        new Blob([response.data], {
          type: response.headers["content-type"],
        }),
      );

      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
    })
    .catch((error) => {
      console.log(error);
    });
};
