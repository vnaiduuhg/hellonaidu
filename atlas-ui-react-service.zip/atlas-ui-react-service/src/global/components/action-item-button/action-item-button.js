import React from "react";
import { Button } from "react-bootstrap";
import cx from "classnames";
import styles from "./action-item-button.module.scss";

const ActionItemButton = ({
  icon,
  label,
  onClick,
  variant = "secondary",
  isDisabled = false,
  className = null,
  ...rest
}) => {
  variant = ((variant || "secondary") ?? "secondary").toLowerCase();

  // for legacy FA icons, allow them to be passed as classes. otherwise, use
  // new react-icon components
  if (typeof icon === "string")
    icon = <i className={icon} aria-hidden="true" />;

  return (
    <Button
      variant=""
      className={cx([styles.actionItem, styles[`actionItem-${variant}`]], {
        [className]: !!className,
      })}
      onClick={onClick}
      disabled={isDisabled}
      {...rest}
    >
      {icon}
      {label}
    </Button>
  );
};

export default ActionItemButton;
