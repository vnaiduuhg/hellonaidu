import { Alert } from "react-bootstrap";
import { FaExclamationTriangle } from "react-icons/fa";
import cx from "classnames";

// TODO: use different icons for info & warning. missing design

export const AtlasAlert = ({
  children,
  /** info, warning, error, primary */
  variant = "info",
  icon = <FaExclamationTriangle />,
  className = "",
  ...rest
}) => (
  <Alert
    variant={variant}
    className={cx("d-flex align-items-center justify-content-center", {
      [className]: !!className,
    })}
    {...rest}
  >
    {!!icon && (
      <span className="d-flex align-items-center h-100 fs-5 me-2">{icon}</span>
    )}
    <div className="fs-6 fw-500">{children}</div>
  </Alert>
);
