import styles from "./cliffhanger.module.scss";

export const Cliffhanger = ({ children }) => (
  <div className="edash_searchtop">
    <div className="py-0 px-5">
      <div className={styles.edash_searchtopContainer}>{children}</div>
    </div>
  </div>
);
