import cx from "classnames";

export const GradientHeaderIconWidget = ({
  content,
  icon,
  label,
  isLoading,
  isError,
  className,
}) => {
  return (
    <div
      className={cx("employer-stats-widget-Icon", {
        [className]: !!className,
      })}
    >
      <div className="employer-stats-icon">{icon}</div>
      <div className="employer-stats-number d-flex flex-column">
        <div className="employer-stats-label d-flex justify-content-center">
          {label}
        </div>
        <div className="d-flex justify-content-center">
          {/* TODO: create this btn-loader as a component */}
          {isLoading && !isError ? (
            <i className="btn-loader" />
          ) : (
            <span>{content}</span>
          )}
          {isError && !isLoading && "-"}
        </div>
      </div>
    </div>
  );
};
