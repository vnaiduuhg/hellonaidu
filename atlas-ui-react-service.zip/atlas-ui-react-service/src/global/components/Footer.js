const Footer = () => <div>Place holder footer</div>;

export default Footer;
