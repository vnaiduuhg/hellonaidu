import GlobalRoutes from "../GlobalRoutes";
import * as Sentry from "@sentry/react";
import SentryFallback from "./SentryFallback";
import { Suspense } from "react";
// import ErrorBoundary from "./ErrorBoundary";

const App = () => (
  <Sentry.ErrorBoundary fallback={SentryFallback}>
    <Suspense fallback={<div>...</div>}>
      <GlobalRoutes />
    </Suspense>
  </Sentry.ErrorBoundary>
);

// const App = () => (
//   <ErrorBoundary>
//     <GlobalRoutes />
//   </ErrorBoundary>
// );

export default App;
