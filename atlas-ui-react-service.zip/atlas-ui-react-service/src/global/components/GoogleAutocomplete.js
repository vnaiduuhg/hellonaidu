import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { GOOGLE_API, APP_ENV } from "config";
import { setLocationObject } from "../utils/locationUtil";
import { saveLocation } from "../apis/locationApi";
import { useTranslation } from "global/utils/useTranslation";
import { showMessage } from "global/store/statusMessagesSlice";
import { BiWorld } from "react-icons/bi";

const GoogleAutocomplete = ({
  autocompletCallback,
  label = ["Veuillez entrer une adresse", "Please enter an address"],
}) => {
  const { out } = useTranslation();
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch();
  const autocompleteInputRef = useRef();

  // if it is read from the index script, we can remove this call
  const loadScript = (url, callback) => {
    let script = document.createElement("script");
    script.type = "text/javascript";

    if (script.readyState) {
      script.onreadystatechange = () => {
        if (["loaded", "complete"].includes(script.readyState)) {
          script.onreadystatechange = null;
          callback();
        }
      };
    } else {
      script.onload = () => callback();
    }

    script.src = url;
    document.getElementsByTagName("body")[0].appendChild(script);
  };

  const saveNewLocation = (newLocation, formattedAddress) => {
    saveLocation(newLocation, !!user)
      .then((response) => {
        if (response.length && response[0].id) {
          autocompletCallback({
            location: response[0],
            formattedAddress: formattedAddress,
          });
        } else {
          dispatch(
            showMessage(
              "error",
              out("Adresse non sauvegardée", "Unsaved location"),
              out(
                "Un problème est survenu et l'adresse n'a pu être enregistrée",
                "A problem has occured and the address could not be saved",
              ),
              8000,
            ),
          );
        }
      })
      .catch((error) => {
        dispatch(
          showMessage(
            "error",
            out("Adresse non sauvegardée", "Unsaved location"),
            out(
              "Un problème est survenu et l'adresse n'a pu être enregistrée",
              "A problem has occured and the address could not be saved",
            ),
            8000,
          ),
        );
      });
  };

  const handleLocationSelected = (address) => {
    if (
      address &&
      Object.keys(address).length &&
      address.formatted_address &&
      address.address_components &&
      address.address_components.length
    ) {
      const newLocation = setLocationObject(address);
      if (newLocation) {
        saveNewLocation(newLocation, address.formatted_address);
      } else {
        dispatch(
          showMessage(
            "error",
            out("Adresse incomplète", "Incomplete address"),
            out(
              "Veuillez vous assurer de choisir l'une des suggestions de saisie semi-automatique",
              "Please make sure to choose one of the autocomplete suggestion",
            ),
            7000,
          ),
        );
      }
    } else {
      dispatch(
        showMessage(
          "error",
          out("Adresse invalide", "Invalid address"),
          out(
            "Veuillez vous assurer de choisir l'une des suggestions de saisie semi-automatique",
            "Please make sure to choose one of the autocomplete suggestion",
          ),
          7000,
        ),
      );
    }
  };

  const initGoogleAutocomplete = () => {
    let classExist = false;
    autocompleteInputRef.current.classList.forEach((item) => {
      if (item === "pac-target-input") {
        classExist = true;
      }
    });

    if (typeof autocompleteInputRef.current?.focus === "function")
      autocompleteInputRef.current?.focus();

    if (!classExist) {
      const autocompleteInput = document.getElementById(
        "google-autocomplete-input",
      );

      const autocomplete = new window.google.maps.places.Autocomplete(
        autocompleteInput,
      );

      autocomplete.setFields([
        "address_components",
        "formatted_address",
        "geometry",
        "place_id",
      ]);
      autocomplete.addListener("place_changed", () => {
        const address = autocomplete.getPlace();
        handleLocationSelected(address);
      });
    }
  };

  // if the script source if initialez on the index, just call initGoogleAutocomplete() and remove loadScript()
  useEffect(() => {
    if (APP_ENV !== "local") {
      initGoogleAutocomplete();
    } else {
      // when running the app with npm start - @temp just to be able to work with real data
      const googleInit = document.getElementsByClassName("pac-container");
      if (googleInit.length < 1) {
        loadScript(
          `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_API}&libraries=places%2Cgeometry&ver=3.34"`,
          () => initGoogleAutocomplete(),
        );
      } else {
        initGoogleAutocomplete();
      }

      /*
      @for development purpose - fake object returned
      - you need also to toggle long and lang on setLocationObject */
      // handleLocationSelected(fakeGooleAutocompleteResponse);
    }
  }, []);

  return (
    <>
      {/* <input
        className="form-control"
        id="google-autocomplete-input"
        type="text"
        autoComplete="false"
        ref={autocompleteInputRef}
        placeholder={out(
          "Veuillez entrer une adresse",
          "Please enter an address",
        )}
        onKeyPress={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            return false;
          }

          return true;
        }}
      /> */}

      <div className="input-group floating-input-group-prepend">
        <div className="input-group-text input-group-prepend text-secondary">
          <BiWorld />
        </div>
        <div className="form-floating form-floating-group flex-grow-1">
          <input
            id="google-autocomplete-input"
            type="text"
            placeholder=" "
            autoComplete="false"
            ref={autocompleteInputRef}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                return false;
              }

              return true;
            }}
            className="form-control"
          />

          <label htmlFor="google-autocomplete-input">{out(...label)}</label>
        </div>
      </div>
    </>
  );
};

export default GoogleAutocomplete;
