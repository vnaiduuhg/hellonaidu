import { ImageViewer } from "./Viewers/ImageViewer";
import { OfficeViewer } from "./Viewers/OfficeViewer";
import { NativePdfViewer } from "./Viewers/NativePdfViewer";
import { PdfViewer } from "./Viewers/PdfViewer";
import { TextViewer } from "./Viewers/TextViewer";

export const VIEWER_TYPES = new Map([
  ["pdf", navigator.pdfViewerEnabled ? NativePdfViewer : PdfViewer],
  ["ppt", OfficeViewer],
  ["pptx", OfficeViewer],
  ["doc", OfficeViewer],
  ["docx", OfficeViewer],
  ["xls", OfficeViewer],
  ["xlsx", OfficeViewer],
  ["odt", OfficeViewer],
  ["png", ImageViewer],
  ["bmp", ImageViewer],
  ["jpg", ImageViewer],
  ["jpeg", ImageViewer],
  ["gif", ImageViewer],
  ["txt", TextViewer],
]);
