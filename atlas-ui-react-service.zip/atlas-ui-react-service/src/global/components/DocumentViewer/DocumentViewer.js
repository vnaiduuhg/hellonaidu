import { out } from "global/utils/useTranslation";
import { memo, useMemo } from "react";
import { AtlasAlert } from "../atlas-alert";
import { ProtectDocument } from "./ProtectDocument";
import { VIEWER_TYPES } from "./viewerTypes";

/**
 *
 * @param {*} path url of the file
 * @param {*} fileName (optional) if it's different from the path
 * @param {*} onLoad (optional) callback function
 * @param {*} onError (optional) callback function
 */
export const DocumentViewer = memo(
  ({
    path,
    fileName = null,
    onLoad = () => {},
    onError = () => {},

    // minimal protection from saving file. just right-click disabled and printing
    protect = false,
  }) => {
    // get file type from path
    const Viewer = useMemo(() => {
      const possibleExtension = (fileName ?? path)
        .toLowerCase()
        .split(".")
        .pop();

      return VIEWER_TYPES.get(possibleExtension) ?? null;
    }, [path, fileName]);

    if (!Viewer) {
      onLoad();

      return (
        <AtlasAlert variant="warning">
          {out(
            "Impossible d'afficher les documents de type: ",
            "Unable to display documents of type: ",
          )}
          "{(fileName ?? path).toLowerCase().split(".").pop()}"
        </AtlasAlert>
      );
    }

    return (
      <ProtectDocument enabled={protect}>
        <Viewer url={path} onLoad={onLoad} onError={onError} />
      </ProtectDocument>
    );
  },
);
