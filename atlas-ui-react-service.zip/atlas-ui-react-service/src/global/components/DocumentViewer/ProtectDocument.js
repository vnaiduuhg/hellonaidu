import { useCallback, useEffect, useRef } from "react";
import styles from "./ProtectDocument.module.scss";

// Doesn't really protect anything. just prevents the user from
// right clicking, copying, cutting, pasting, selecting text, etc.
// Client wants this, so here it is
export const ProtectDocument = ({ enabled, children }) => {
  const $el = useRef(null);

  const preventDefault = useCallback((e) => e.preventDefault(), []);
  const preventKeyboardShortcuts = useCallback((e) => {
    if (
      e.ctrlKey &&
      (e.key === "c" || e.key === "v" || e.key === "x" || e.key === "p")
    ) {
      e.preventDefault();
    }
  }, []);

  useEffect(() => {
    if (!$el.current || !enabled) {
      return;
    }

    const $elCurrent = $el.current;

    $elCurrent.addEventListener("contextmenu", preventDefault);
    $elCurrent.addEventListener("copy", preventDefault);
    $elCurrent.addEventListener("cut", preventDefault);
    $elCurrent.addEventListener("paste", preventDefault);
    $elCurrent.addEventListener("selectstart", preventDefault);
    $elCurrent.addEventListener("select", preventDefault);
    document.addEventListener("keydown", preventKeyboardShortcuts);

    return () => {
      $elCurrent.removeEventListener("contextmenu", preventDefault);
      $elCurrent.removeEventListener("copy", preventDefault);
      $elCurrent.removeEventListener("cut", preventDefault);
      $elCurrent.removeEventListener("paste", preventDefault);
      $elCurrent.removeEventListener("selectstart", preventDefault);
      $elCurrent.removeEventListener("select", preventDefault);
      document.removeEventListener("keydown", preventKeyboardShortcuts);
    };
  }, [enabled, preventDefault, preventKeyboardShortcuts]);

  if (!enabled) {
    return children;
  }

  return (
    <div ref={$el} id={styles.protection}>
      {children}
    </div>
  );
};
