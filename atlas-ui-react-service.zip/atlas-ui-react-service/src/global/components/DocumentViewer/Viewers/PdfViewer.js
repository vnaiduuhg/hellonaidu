import { AtlasAlert } from "global/components/atlas-alert";
import { useTranslation } from "global/utils/useTranslation";
import { memo, useEffect, useRef, useState } from "react";
import styles from "./PdfViewer.module.scss";

export const PdfViewer = memo(({ url, onLoad, onError }) => {
  const $canvasContainer = useRef(null);
  const [invalidPdfFile, setInvalidPdfFile] = useState(false);
  const { out } = useTranslation();

  useEffect(() => {
    if ($canvasContainer.current) {
      $canvasContainer.current.innerHTML = "";
    }
  }, [url]);

  useEffect(() => {
    const pdfjsLib = window.pdfjsLib;
    if (!pdfjsLib?.getDocument) {
      // TODO: show a pdfs cannot be displayed at the moment message
      throw new Error("pdfjsLib is not loaded");
    }

    if ($canvasContainer.current) {
      pdfjsLib
        .getDocument(url)
        .promise.then((pdf) => {
          const pagePromises = new Array(pdf.numPages)
            .fill(0)
            .map((_, i) => i + 1)
            .map((number) => pdf.getPage(number));

          return Promise.all(pagePromises);
        })
        .then(
          (pages) => {
            const scale = 1.5;

            pages.forEach((page) => {
              const viewport = page.getViewport({ scale });

              const $canvas = document.createElement("canvas");
              $canvas.id = `canvas${page._pageIndex}`;
              $canvas.className = "canvasClass";
              $canvas.style.width = "100%";
              $canvas.height = viewport.height;
              $canvas.width = viewport.width;

              const canvasContext = $canvas.getContext("2d");

              $canvasContainer.current?.append($canvas);

              const renderContext = {
                canvasContext,
                viewport,
              };

              page.render(renderContext);

              $canvasContainer.current?.appendChild($canvas);
            });

            if (onLoad) {
              onLoad();
            }

            if ($canvasContainer.current) {
              $canvasContainer.current.style.display = "block";
            }
          },
          (error) => {
            if (error.name === "InvalidPDFException") {
              if (onLoad) {
                onLoad();
              }

              setInvalidPdfFile(true);
            } else {
              if (onError) onError(error);
            }
          },
        );
    }
    /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [url, $canvasContainer]);

  if (invalidPdfFile) {
    return (
      <AtlasAlert variant="danger">
        {out(
          "Ce n'est pas un fichier PDF valide. Il peut être corrompu ou crypté.",
          "This is not a valid PDF file. It may be corrupted or encrypted.",
        )}
      </AtlasAlert>
    );
  }

  return (
    <div
      className="canvasContainer docViewer"
      id={styles.canvasContainer}
      ref={$canvasContainer}
    />
  );
});
