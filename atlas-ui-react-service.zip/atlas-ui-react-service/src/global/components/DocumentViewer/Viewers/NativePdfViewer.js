import { memo, useCallback, useRef } from "react";

export const NativePdfViewer = memo(({ url, onLoad, onError }) => {
  const $el = useRef(null);

  const handleLoad = useCallback(() => {
    onLoad();
    $el.current.classList.remove("d-none");
    $el.current.classList.add("d-block");
  }, [onLoad]);

  return (
    <iframe
      className="docViewer w-100 d-none border-0"
      title="Pdf"
      id="canvasContainer"
      src={`${url}#toolbar=0&view=FitH`}
      width="100%"
      height="900px"
      frameBorder={0}
      ref={$el}
      onLoad={handleLoad}
      onError={onError}
    />
  );
});
