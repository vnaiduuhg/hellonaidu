import { memo, useCallback, useRef } from "react";
import styles from "./ImageViewer.module.scss";

export const ImageViewer = memo(({ url, onLoad, onError }) => {
  const $el = useRef(null);

  const pictureLoaded = useCallback(() => {
    onLoad();
    $el.current.classList.remove("d-none");
    $el.current.classList.add("d-block");
  }, [onLoad]);

  return (
    <img
      ref={$el}
      src={url}
      id={styles.image}
      className="docViewer d-none"
      width="100%"
      onLoad={pictureLoaded}
      onError={onError}
    />
  );
});
