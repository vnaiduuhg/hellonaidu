import { memo, useCallback, useRef } from "react";

export const OfficeViewer = memo(({ url, onLoad, onError }) => {
  const $el = useRef(null);

  const handleLoad = useCallback(() => {
    onLoad();
    $el.current.classList.remove("d-none");
    $el.current.classList.add("d-block");
  }, [onLoad]);

  return (
    <iframe
      className="docViewer w-100 d-none"
      title="MSDocx"
      id="MSDocx"
      src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(
        url,
      )}`}
      width="100%"
      height="900px"
      frameBorder={0}
      ref={$el}
      onLoad={handleLoad}
      onError={onError}
    />
  );
});
