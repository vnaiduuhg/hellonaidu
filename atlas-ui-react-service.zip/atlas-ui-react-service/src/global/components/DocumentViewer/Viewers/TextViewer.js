import { memo, useEffect, useState } from "react";
import { useQuery } from "react-query";
import { REACT_QUERY_GETTER_OPTIONS } from "global/utils/useAtlasQuery";
import styles from "./TextViewer.module.scss";

export const TextViewer = memo(({ url, onLoad, onError }) => {
  const [show, setShow] = useState(false);

  const { data, isFetched } = useQuery(
    ["text-file", { url }],
    () => fetch(url).then((res) => res.text()),
    {
      ...REACT_QUERY_GETTER_OPTIONS,
      onError,
    },
  );

  useEffect(() => {
    if (isFetched) {
      onLoad();
      setShow(true);
    }
  }, [onLoad, isFetched]);

  return (
    <div className="docViewer w-100 overflow-visible" id="textViewer">
      <textarea
        id={styles.viewerTextarea}
        className={`border-0 p-5 w-100 ${show ? "d-block" : "d-none"}`}
        defaultValue={data ?? ""}
        readOnly
      />
    </div>
  );
});
