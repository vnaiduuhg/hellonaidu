import { makeStyles } from "@material-ui/core/styles";
import { styled } from "@mui/material/styles";
import MuiAccordion from "@mui/material/Accordion";
import MuiAccordionSummary from "@mui/material/AccordionSummary";

export const useStyles = makeStyles(() => ({
  ul: {
    "& .MuiPaginationItem-root": {
      color: "#6FBDF2",
      fontWeight: "bold",
    },
    "& button.Mui-selected": {
      backgroundColor: "#6FBDF2",
      color: "white",
    },
    "& button.Mui-selected:hover": {
      backgroundColor: "#337ab7",
    },
  },
}));

// Used in Email templates only so far. Refactor to bootstrap accordion
export const AccordionSummary = styled((props) => (
  <MuiAccordionSummary {...props} />
))(({ theme }) => ({
  color: "#337ab7",

  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
  "& .MuiAccordionSummary-content p": {
    width: "100%",
  },
  "& .MuiAccordionSummary-content span": {
    marginRight: "0.5rem",
    backgroundColor: "var(--ats-secondary-300)",
    color: "var(--ats-ui-1000)",
    padding: "6.3px 11.7px",
    fontSize: "1rem",
    borderRadius: "99px",
    fontWeight: 700,
  },
}));

export const Accordion = styled((props) => <MuiAccordion {...props} />)(() => ({
  marginBottom: 15,
  borderRadius: "5px !important",

  ".MuiTypography-root": {
    fontSize: "1.125rem",
    fontWeight: 700,
    fontFamily: "Karla, sans-serif",
  },

  "& .MuiAccordionSummary-root": {
    background: "var(--ats-secondary-700)",
  },
  "& .MuiAccordionSummary-root:hover": {
    background: "var(--ats-secondary-800)",
  },
}));
