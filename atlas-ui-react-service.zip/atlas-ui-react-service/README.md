# Atlas UI React Service

## Code

- Javascript version: any
  - Use any new JavaScript feature in code. @babel/preset-env will transpile code. Production build will polyfill necessary code to be cross-browser complient in listed browsers.
- React Version: 17
  - might update to 18 once it's stable for alleged performance boost (Concurrent Mode)
- State Management: TBD
- Framework: Create React App (not really a framework, but a React boilerplate)
  - research vite for support and functionality. supposed to be much faster at building
- Target browsers listed in package.json under 'browserslist'
  - default used, not yet discussed

## File Structure

- App is grouped by features/modules. These are the subdirectories under `/src`. The main app itself is a module and is found under `/src/global`. React styling and naming conventions followed by this app.
- Each module is made of:
  - `components`: React view components (dumb components). PascalCased .js files. Each of its test & css files are accompanied w/ the same naming convention (eg: `App.js`)
    - tests: `App.test.js` (optional)
    - style: `App.css`, `App.less`...
  - `containers`: React container components (smart components). Used to hook global states to view components and provide html layout structure
  - `redux`: (placeholder, might change) based on module-level redux abstractions (might switch to component level once researched)
    - `redux/reducer.js` - module-level reducers
    - `redux/actions.js` - module-level actions
  - `utils`: helper functions such as api calls
  - `assets`: optional module specific assets
    - webpack will automatically fill in filename for assets imported into js from this dir and may inline it into the code if small enough (set size in webpack config)
  - `Routes.js` file: module specific route file
    - The root route binds to each module's route file which in turn sets up its own routes
  - shared components, utils & state belong in global module
- Naming conventions based on standard React conventions: file & component names are PascalCased

## Instructions for Development

- Run `npm start` to compile & serve development version of the app. It will watch for changes, recompile & push changes to the browser.
- Copy `example.env` to `.env` and set the environement variables if needed. Each branch has the default values set to their environment that matches the branch's name
- Launch angular-built with `serve:angular-built` and launch the angular app with the react script pointing to `http://localhost:5000/static/js/index.js` in `src/atlas/views/react-gateway/react-gateway.template.html` of the angular app to test the integration
- **Tokens:** set `jwtToken` in Local Storage to use the backend. All backends are using test, so login to https://atlas-ui-test.workland.ca/ to retrieve it (it's a cookie)

### Debugging

- Install `React Developer Tools` extention for your browser
- Install `Redux DevTools` extention for your browser (if going w/ redux)

#### Debug Environment variables

- `DEBUG_REDIRECT_404_TO_ANGULAR`
  - When a linked page does not exist on React app, you can set this to `true` and automatically have it redirected to either the live test/dev enironments or a locally hosted Angular app. It will use `ATLAS_UI_URL` to construct url
  - example: To test "Job Apply" functionality from job list page inside react app without needing to launch Angular app

## Instructions for Production Deployment

- `npm run build` will always be the command to run to build the production app. Currently it is using customized build script to be loadable by angular app. When that goes out of service, replace it with original build script.
  - optionally set path to alternate entry file (default: `src/index.js`)
  - use `npm run build:original` to build complete react app
