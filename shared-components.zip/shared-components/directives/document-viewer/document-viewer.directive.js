(function (angular) {
  function documentViewerCtrl($scope, utils, $element) {
    const scope = {
      out: utils.out,
      utils: utils,
      loading: true,
      error: false,
      viewer: null,
      url
    };
    angular.extend($scope, scope);

    
    function loadFromUrl() {
      const $container = $element[0];
      let url;

      $scope.error = false;
      $scope.loading = true;

      // if a function is passed, use that to resolve the url of the document
      if (typeof $scope.resolveUrl === 'function') {
        try {
          // url = await $scope.resolveUrl();
          $scope.url = url;
        } catch(e) {
          // TODO: handle error
          $scope.loading = false;
          $scope.error = true;
          console.error(e);
        }
      } else {
        // must set url if resolveUrl is not set on the directive
        if (typeof $scope.url !== 'string') {
          $scope.loading = false;
          $scope.error = true;

          // Dev-time error: url must be set if resolveUrl is not
          throw new Error('Missing url or wrong type. Must be a string');
        }

        // get the url directly on the element
        url = $scope.url;
      }

      const fileType = getFileTypeFromUrl(url);
      switch (fileType) {
        case 'pdf':
          if (navigator.pdfViewerEnabled) {
            // can't manage to create a new viewer type ('native-pdf') for this, 
            // so using 'office' instead. ng-class did not show when using 'native-pdf' || 'office'
            $scope.viewer = 'office'; 
            utils.showNativePdfFile({ url: $scope.url }, $container);
            $scope.loading = false;
          } else {
            $scope.viewer = 'pdf';
            utils.showPdfFile({ url: $scope.url }, $container);
            $scope.loading = false;
          }
          break;
        case 'docx':
        case 'doc':
        case 'odt':
        case 'xlsx':
        case 'xls':
        case 'pptx':
        case 'ppt':
          $scope.viewer = 'office';
          utils.showOfficeFile({ url: $scope.url }, $container);
          $scope.loading = false;
          break;
        case 'txt':
          $scope.viewer = 'text';
          utils.showTxtFile({ url: $scope.url }, $container);
          $scope.loading = false;
          break;
        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
          $scope.viewer = 'image';
          utils.showImage({ url: $scope.url }, $container);
          $scope.loading = false;
          break;
        default:
          // FIXME: file type not supported
          console.error("File type not supported");
          $scope.error = true;
          $scope.loading = false;
      }
      $scope.loading = false;
    }
    
    $scope.$watch('url', (newValue, oldValue) => {
      if (!!newValue && newValue !== oldValue) {
        $scope.viewer = '';
        loadFromUrl();
      }
    });
  }

  function getFileTypeFromUrl(url) {
    return url.split(/[#?]/)[0].split('.').pop().trim();
  }

  documentViewerCtrl.$inject = ["$scope", "utils", "$element"];

  angular.module("shared-components").directive("documentViewer", () => {
    // https://stackoverflow.com/questions/26409460/angularjs-pass-argument-to-directive
    return {
      scope: {
        // add scope params passed on directive here
        // @ = string, = = model, & = function
        // priority override: resolveUrl() > url
        resolveUrl: '&?', // promise to resolve url (used to get tokenized url to view private documents)
        // url: '@?',  // pass url directly if not using resolveUrl (used to view public documents).
        url: '=?',  // pass url directly if not using resolveUrl (used to view public documents).

        file: '=?',
        
        fileTypes: '=?', // array of strings
        maxSize: '@?', // in MB
      },
      controller: documentViewerCtrl,
      templateUrl:
        "./shared-components/directives/document-viewer/document-viewer.template.html",
    };
  });
})(angular);
