(function (angular) {
    function loadingSpinnerModuleCtrl($scope, api, utils, ) {
        let scope = {
            out: utils.out,
        };
        angular.extend($scope, scope);
    }


    loadingSpinnerModuleCtrl.$inject = ['$scope', 'api', 'utils', ];
    angular.module('shared-components')
        .directive('loadingSpinnerModule', () => ({
            scope: {
                condition: '=',
                message: '@',
                loaderType: '@',
                additionalMessage: '@?',
                additionalCondition: '=?',
            },
            controller: loadingSpinnerModuleCtrl,
            template: require('./loading-spinner-module.template.html'),
        })).controller('loadingSpinnerModuleCtrl', loadingSpinnerModuleCtrl);
})(angular);