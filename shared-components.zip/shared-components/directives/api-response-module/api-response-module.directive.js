(function (angular) {
  function apiResponseModuleCtrl($scope, api, utils, $rootScope, $state, $timeout) {
    angular.extend($scope, {
      strings: utils.strings,
      out: utils.out,
      alert: [],
    });

    var onTimeout = function () {
      if ($scope.alert && $scope.alert.length > 0) {
        $scope.alert.splice(0, 1);
      }
    };

    let createTimeout1; let createTimeout2;

    $rootScope.api_status = function (status, msgEn, msgFr, titleEn, titleFr, timespan) {
      // *** Note: valid 'status' includes: waiting, ok, error. Other values will not work ***
      $scope.apiPromise = status;
      $scope.timespan = timespan ? timespan : 4000;

      if ($scope.alert.length > 0 && $scope.alert[$scope.alert.length - 1].apiPromise == 'waiting') {
        createTimeout1 = $timeout(onTimeout, $scope.timespan);
      }

      $scope.alert.push({
        apiPromise: status,
        responseTitleEn: titleEn,
        responseTitleFr: titleFr,
        responseMsgEn: msgEn,
        responseMsgFr: msgFr,
      });

      if (status != 'waiting') {
        $scope.apiPromise = null;
        createTimeout2 = $timeout(onTimeout, $scope.timespan);
      }
    };

     $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
    });


    /**
    *  this function can close an api_status msg box
    */
    $rootScope.closeCurrentAlert = function (status) {
      if ($scope.apiPromise == status) {
        $scope.apiPromise = null;
      }
    };
  }

  apiResponseModuleCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', '$state', '$timeout'];

  angular.module('shared-components')
    .directive('apiResponseModule', () => ({
      controller: apiResponseModuleCtrl,
      template: require('./api-response-module.template.html'),
    })).controller('apiResponseModuleCtrl', apiResponseModuleCtrl);
}(angular));
