( function ( angular ) {
    'use strict';

     angular.module( 'shared-components' )
        .factory( 'questionnaireUtils', ['_', function questionnaireUtils( _ ) {
            var sectionSprits = {
                "40f6f9c5-761c-449d-a0c6-9d9b99480cca": "dealbreaker",
                "61cf1755-3094-11e5-ac63-00ff84a458ef": "compensation",
                "85c216f8-3094-11e5-ac63-00ff84a458ef": "work_env",
                "30fa5df8-356a-11e5-b40d-00ff84a458ef": "skills",
                "4244f4b6-356a-11e5-b40d-00ff84a458ef": "work_life",
                "57a3f297-356a-11e5-b40d-00ff84a458ef": "social_val",
                "7e004187-356a-11e5-b40d-00ff84a458ef": "personality",
                "c13a0251-d6bb-46e1-9a95-5dec9bee3352": 'fccq'
            };
            var select2QuestionIds = {
                '427dea90-cd3d-11e2-8861-080027001c5f': true,
                '427df715-cd3d-11e2-8861-080027001c5f': true
            };

            /* Questions of this type should have progressive labels
             * and can only have one option selected e.g radiobuttons
             */
            var sliderQuestionIds = {
                // 17 - Salaire minimum
                '427dee7f-cd3d-11e2-8861-080027001c5f': true,
                // 18 - Expérience en gestion de personnel
                '427deefd-cd3d-11e2-8861-080027001c5f': true,
                // 19 - Expérience en gestion de personnel
                '427df588-cd3d-11e2-8861-080027001c5f': true,
                // 21 - Portion de temps envoyages d'affaires
                '427df0fe-cd3d-11e2-8861-080027001c5f': true,
                // 47 Promotions
                '427df290-cd3d-11e2-8861-080027001c5f': true,
                //48 - Vacances
                '427df40e-cd3d-11e2-8861-080027001c5f': true,
                //49 - Bonification
                '427df487-cd3d-11e2-8861-080027001c5f': true

            };
            var interfaceBase = '../shared-components/directives/questionnaire/';
            var interfaceExt = '.template.html';

            var interfaces = {
                '427e0521-cd3d-11e2-8861-080027001c5f': 'checkbox-personality-profile',
                slider: 'slider',
                select2: 'select2',
                multidimensional: 'checkbox-multidimensional',
                sortableUnique: 'sortable-unique',
                pairsUnique: 'array-pairs',
                unique: 'radiobutton-bubbles',
                checkboxMultiple: 'checkbox-hexagon',
                checkboxExact: 'checkbox-hexagon',
                sortable: 'sortable'
            };

            var qUtils = {
                getInterface: function ( question ) {
       
                    var type = question._type;
                    var questionInterface;
                    var questionId = question.questionId;

                    // create template by questionId if needed
                    if ( interfaces[questionId] ) {
                        questionInterface = interfaces[questionId];
                    } else if ( qUtils.isSelect2Interface( question ) ) {
                        questionInterface = interfaces.select2;
                    } else if ( qUtils.isSliderInterface( question ) ) {
                        questionInterface = interfaces.slider;
                    } else {
                        questionInterface = interfaces[type];
                    }
                    if(questionInterface == 'sortable' || questionInterface == 'sortableUnique') {
                        question._options = qUtils.getArrayOrder(question);
                    }
                    // return interfaceBase + questionInterface + interfaceExt;
                    return 'template-'+questionInterface;
                },
                getArrayOrder: function( question ) {
                   
                    switch ( question._type ) {
                        case 'sortable':
                            var sort_reverse = question.controlType === 'cote18' ? true : false;
                             
                            var choicesDescOrdered = question.choices.sort( function(a,b) {
                                return a.selected - b.selected;
                            });
                            var choicesOrdered = _.map(question.choices.sort( function(c) {
                                return c.selected;
                            })).reverse();
                            
                            return sort_reverse ? choicesDescOrdered : choicesOrdered;
                            break;

                        // @todo
                        case 'sortableUnique':
                            // var sortable_section = WLUTIL::array_orderby( array_slice( $question_choices, 0, 4 ), 'selected', SORT_ASC );
                            // $unique_setion = array_slice( $question_choices, 4 );
                            // $question_choices = array_merge( $sortable_section, $unique_setion );
                            break;
                    }
                },
                getValues: function ( question ) {
                    return _.pluck( question.choices, 'selected' ).join( "" );
                },
                getSelect2Selected: function ( question ) {
                    return _.filter( question.choices, function ( choice ) {
                        return choice.selected === '1';
                    } );
                },
                syncSelect2Items: function ( question, $item, action ) {
                    _.find( question.choices, function ( choice ) {
                        var found = choice.key === $item.key;
                        if ( found ) {
                            choice.selected = action === 'select' ? '1' : '0';
                        }
                        return found;
                    } );
                },
                nbSelected: function ( question ) {
                    var selected = 0,
                            emptySelection = question._type === 'multidimensional' ? '9' : '0';

                    _.each( question.choices, function ( choice ) {
                        if ( choice.selected !== emptySelection && choice.selected !== " " ) {
                            selected++;
                        }
                    } );
                    return selected;
                },
                isInvalid: function ( question ) {
                    var nbSelected = question.nbSelected;
                    var nothingSelected = !nbSelected;
                    var specificInvalid = false;
                    switch ( question._type ) {
                        case 'sortable':
                            nothingSelected = false;
                            break;
                        case 'sortableUnique':
                            var last3bits = qUtils.getValues( question ).slice( -3 );
                            specificInvalid = !parseInt( last3bits, 10 );
                            break;
                        case 'checkboxExact':
                            specificInvalid = nbSelected < question.nbChoices;
                            break;
                        case 'pairsUnique':
                            specificInvalid = nbSelected !== 34;
                    }
                    return nothingSelected || specificInvalid;
                },
                isSliderInterface: function ( question ) {
                    return sliderQuestionIds[question.questionId];
                },
                isSelect2Interface: function ( question ) {
                    return select2QuestionIds[question.questionId];
                },
                modifyUniqueData: function ( question, key, range ) {
                    range = range || [];
                    var choices = question.choices; //array_pairs

                    if ( question._type === 'pairsUnique' ) {
                        ( key % 2 ) ? --key : ++key;
                        choices[key].selected = '0';

                    } else {
                        var start = range[0] || 0,
                                end = range[1] || choices.length;
                        for ( var i = start; i < end; i++ ) {
                            if ( choices[i].key !== key ) {
                                choices[i].selected = '0';
                            }
                        }
                    }
                },
                modifySortableData: function ( question, range ) {
                    
                    var sortableType = question.controlType;
                    var choices = question.choices;
                    var isArrRange = angular.isArray( range );
                    var start = isArrRange ? range[0] || 0 : 0;
                    var end = isArrRange ? range[1] || choices.length : choices.length;
                    var dataToSort = choices.slice( start, end );

                    for ( var selected = start + 1, len = end; selected <= len; selected++ ) {
                        dataToSort[selected - 1].selected = ( sortableType === 'cote18' ?
                                ( len + 1 ) - selected : selected ).toString();

                    }

                    // delete unsorted section
                    choices.splice( start, end - start );
                    var sorted = _.sortBy( dataToSort, 'key' );
                    // add sorted section
                    question.choices = sorted.concat( choices );
                },
                getSectionNextUnansweredQuestion: function ( section ) {
                    return _.find( section.questions, function ( question ) {
                        return !question.bAnswered;
                    } );
                },
                getSectionQuestionById: function ( questionId, section ) {
                    return _.find( section.questions, function ( question ) {
                        return question.questionId === questionId;
                    } );
                },
                getSectionClass: function ( currentSection, section ) {

                    var sectionClass;
                    if ( currentSection === section ) {
                        sectionClass = 'section-selected';
                    } else if ( section._isComplete ) {
                        sectionClass = 'section-completed';
                    } else if ( section._started ) {
                        sectionClass = 'section-not-finished';
                    } else {
                        sectionClass = 'section-unselected';
                    }

                    return sectionClass;
                },
                getSectionSprite: function ( section ) {
                    var sprit = sectionSprits[section.sectionId];
                    if ( !section._started && !section._isComplete ) {
                        sprit += '_inactive';
                    } else if (section._isComplete) {
                        sprit += '_completed';
                    } 
                    return 'sprite-' + sprit;
                },
                numTimes: function ( times ) {
                    return new Array( Math.ceil( times ) );
                }

            };

            return qUtils;
        } 
    ]);
} )
( angular );