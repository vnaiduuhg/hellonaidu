(function (angular) {
    'use strict';

    var app = angular.module('shared-components');
    app.directive('questionnaire', function () {
        return {
            scope: {
                jobId: '@',
                jobAccountId: '@',
                init: '=',
                qSpinner: '=',
                isQuestionnaireSpinner: '=',
                initQTab: '=',
                fromJobUpdate: '=?'
            },
            templateUrl: '../shared-components/directives/questionnaire/questionnaire.template.html',
            controller: ['$q', '$scope', '$rootScope', '$timeout', '$window', '_', 'api',
                'utils', 'questionnaireUtils', 'Event', 'worklandLocalize', 'matchService', '$state', '$stateParams', '$ngConfirm',
                function QuestionnaireCtrl($q, $scope, $rootScope, $timeout, $window, _, api,
                        utils, qUtils, Event, worklandLocalize, matchService, $state, $stateParams, $ngConfirm) {

                    if ($stateParams.initQTab) {
                        $scope.initQTab = true;
                    }

                    const isCandidate = $rootScope.currentUser.permissions.isCandidate;
                    $scope.isCandidate = isCandidate;
                    const isCompany = $rootScope.currentUser.permissions.isEmployer ||
                                    (!$rootScope.currentUser.permissions.isAgency && ($rootScope.currentUser.permissions.isAdminRecruiter || $rootScope.currentUser.permissions.isRegularRecruiter));
                    // Main Entry Point to Quesionniare Directive
                    var questionnaireData,
                            questionnaireSections,
                            jobId,
                            jobAccountId;
                    var blindQ = [];

                    $scope.$watchCollection('quesIsOpened', onAccordionBoxOpen);
                    var scope = {
                        language: $rootScope.language,
                        qUtils: qUtils,
                        syncSelect2Items: syncSelect2Items,
                        quesSelect2Seleced: {},
                        quesAnsweredStatus: {},
                        quesIsOpened: {},
                        quesOpening: {},
                        strings: worklandLocalize.strings,
                        out: utils.out,
                        currentQuestionId: null,
                        numTimes: qUtils.numTimes,
                        numRows: qUtils.numRows,
                        isInvalid: qUtils.isInvalid,
                        getInterface: qUtils.getInterface,
                        getSectionSprite: qUtils.getSectionSprite,
                        getSectionClass: qUtils.getSectionClass,
                        updateQuestion: updateQuestion,
                        selectedChanged: selectedChanged,
                        maxSelectedReached: maxSelectedReached,
                        isSelect2Interface: qUtils.isSelect2Interface,
                        selectSection: selectSection,
                        getUnansweredQInterface: getUnansweredQInterface,
                        setQuestionSelected: setQuestionSelected,
                        reloadPage: reloadPage,
                        getQuestionnaireAnswer: getQuestionnaireAnswer,
                        countQueries: countQueries,
                        trustAsHtml: utils.trustAsHtml,
                        questionSection: { _nbAnsweredQuestions: 0 },
                        showMatchSectionMsg: showMatchSectionMsg,
                        findIndexUncompleteSection: findIndexUncompleteSection,
                        getQuestionnaireSectionMsg: getQuestionnaireSectionMsg,
                        selectSectionChoice: selectSectionChoice
                    };


                    if (false) {
                        var funcs = _.functions(scope);
                    }
                    angular.extend($scope, scope);
                    _.once(init);

                    let createTimeout;

                    init();

                    $scope.tagHandler = function (tag) {
                        return null;
                    };

                    function showMatchSectionMsg(action, nextUncompleteSection) {
                        getQuestionnaireSectionMsg(action);
                        const buttons = {
                            close: {
                                text: $scope.out("Fermer", "Close"),
                                btnClass: 'btn btn-lg btn-alt-secondary',
                                action: function () {}
                            },
                            dashboard: {
                                text: $scope.out(
                                    isCandidate ? "VOIR TABLEAU DE BORD" :
                                                $scope.fromJobUpdate ? "VOIR LE POSTE" : "RETOUR À LA PAGE DU POSTE",
                                    isCandidate ? "VIEW DASHBOARD" :
                                                $scope.fromJobUpdate ? "VIEW JOB" : "BACK TO JOB PAGE"
                                ),
                                btnClass: 'btn btn-lg btn-tertiary',
                                action: function () {
                                    isCandidate ? $state.go('dashboard')
                                                : $state.go('job', {
                                                    jobId: $scope.jobId,
                                                    tab: $scope.fromJobUpdate ? 0 : 1
                                                });
                                }
                            }
                        };
                        if(nextUncompleteSection > -1 && nextUncompleteSection < 7 && !$scope.questionnaireSections[nextUncompleteSection]._isComplete) {
                            buttons.next = {
                                text: $scope.out("SECTION SUIVANTE", "NEXT SECTION"),
                                btnClass: 'btn btn-lg btn-tertiary',
                                action: function () {
                                    selectSectionChoice($scope.questionnaireSections[nextUncompleteSection], null, nextUncompleteSection);
                                }
                            }
                        }
                        // @agency: can add buttons here to show specific sections for agency
                        $ngConfirm({
                            title: '',
                            contentUrl: './shared-components/directives/questionnaire/questionnaire-popup.template.html',
                            scope: $scope,
                            columnClass: 'col-12 col-md-6 col-md-offset-3',
                            containerFluid: true,
                            type: 'blue',
                            typeAnimated: true,
                            animation: 'scale',
                            theme: 'light',        
                            backdrop: 'static',
                            keyboard: false,
                            buttons: buttons
                        });
                    }

                    function selectSectionChoice(sectionIndex, unwansweredQ, userSelected) {
                        selectSection(sectionIndex, unwansweredQ, userSelected);
                        $scope.$apply();
                    }

                    function findIndexUncompleteSection(currentSectionIndex) {
                        let nextSection = -1;
                        let i = currentSectionIndex;
                        let flag = false;
                        let loopLength = $scope.questionnaireSections.length;
                        do {
                            loopLength--;
                            i = i < $scope.questionnaireSections.length-1 ? i+1 : 0;
                            if(!$scope.questionnaireSections[i]._isComplete) {
                                flag = true;
                                nextSection = i;
                            }
                        } while (!flag && loopLength);
                        return nextSection;
                    }

                    function getQuestionnaireSectionMsg(action) {
                        $scope.messageFr = '';
                        $scope.messageEn = '';
                        switch(action) {
                            // @agency: can have code to congratulate client/candidate for filling out the questionnaire
                            case 'first_section':
                                $scope.messageFr = '<h6>Félicitations! Vous avez rempli la section requise pour démarrer l’algorithme de match qui automatisera vos recherches et la mise en relation avec des candidats compatibles.</h6><br>';
                                $scope.messageEn = '<h6>Congratulations! You have completed the section required to start the Match Algorithm which will automate your searches and matchmaking with suitable candidates.</h6><br>';
                                break;
                            case 'candidate_first_section':
                                $scope.messageFr = '<h6>Félicitations !</h6><br><h6>Votre profil a été activé suite à vos réponses à la section "Points critiques" du questionnaire. '
                                                +'Vous pourrez donc à partir de maintenant recevoir des "matchs" automatisés avec des employeurs compatibles.</h6><br>'
                                                +'<h6>Vous voulez augmenter la précision du « match »?  Nous vous recommandons d\'aller remplir les autres sections du questionnaire '
                                                +'afin de confirmer tous les critères qui sont importants pour vous.</h6><br>';
                                $scope.messageEn ='<h6>Congratulations!</h6><br><h6>Your profile has been activated following the answers you provided in section "Deal breakers" of the questionnaire '
                                                +'and you are now able to receive automated matches with compatible employers.</h6><br>'
                                                +'<h6>Want to increase the precision of the match? We recommend that you '
                                                +'complete the other sections to confirm all of the criteria that is important to you.</h6><br>';
                                break;
                            case 'any_section':
                                $scope.messageFr = '<h6>Section terminée! Sélectionner un autre module ou retourner à la page précédente.</h6>';
                                $scope.messageEn = '<h6>Section completed! Select another module or return to the previous page.</h6>';
                                break;
                            case 'complete':
                                $scope.messageFr = '<h6>Félicitations! Vous avez rempli toutes les sections du questionnaire.</h6>';
                                $scope.messageEn = '<h6>Congratulations! You have completed all the sections of the questionnaire.</h6>';
                                break;
                            default:
                        }
                    }

                    function reloadPage() {
                        location.reload();
                    }

                    $scope.$watch('qSpinner', function () {
                        if ($scope.qSpinner == true) {
                            $scope.qSpinner = $scope.questionnaireSpinner != false ? true : false;
                        }
                        else if ($scope.qSpinner == false) {
                            $scope.questionnaireSpinner = false;
                        }
                    });

                    function selectedChanged(question, choice, $event) {

                        var quesType = question._type;
                        var uniques = ['unique', 'sortableUnique', 'pairsUnique'];
                        if (_.indexOf(uniques, quesType) > -1) {
                            var range = quesType === 'sortableUnique' ? [4] : [];
                            qUtils.modifyUniqueData(question, choice.key, range);
                        } else if (quesType === 'multidimensional') {
                            var condition = $event && $event.target
                                ? !$event.target.checked
                                : choice.selected < '9';
                            if (condition) {
                                choice.selected = '9';
                                choice.showOptions = false;

                            } else if (choice.selected === '9') {
                                choice.selected = '0';
                                choice.showOptions = true;
                            }
                        }
                        question.nbSelected = qUtils.nbSelected(question);
                    }

                    function maxSelectedReached(question, choice) {

                        var quesType = question._type,
                                nbSelected = question.nbSelected,
                                canSelect = question.nbChoices,
                                notSelected = choice.selected ===
                                (quesType === 'multidimensional' ? '9' : '0');
                        // *** special cases
                        //limit to 3 choices for Q1
                        if (question.questionId === '83564f38-84eb-4def-b594-1af5192698db') {
                            canSelect = 3;
                        }                            
                        var maxLimit = nbSelected === canSelect && notSelected;
                        return maxLimit;
                    }

                    function getCompletion() {
                        /** @todo revise the logic: the mandatory section is index 0, but now it doesn't consider this, and it creates bugs.
                            If we fill other sections before the first mandatory one:
                                - on candidate side it shows first section complete msg after 20 questions (of any sections) even if first section not filled,
                                - on employer side, it stop the process after filling 20 questions (of any section) without msg or warning
                        */

                        /* @to be fixed
                        if(questionnaireData.currentSelectedSection && questionnaireData.currentSelectedSection._answerBySection == questionnaireData.currentSelectedSection._length) {
                            questionnaireData.currentSelectedSection._isComplete = true;
                        }
                        */
                        const level = ($scope.questionnaireSections[0]._answerBySection / questionnaireData._nbMandatoryTotalQuestions) * 100;
                        const completion = parseInt(level.toFixed(), 10);
                        return completion;
                    }

                    function syncSelect2Items(question, $item, action) {
                        qUtils.syncSelect2Items(question, $item, action);
                        selectedChanged(question);
                    }
                    /*
                        * Function to get the sprites image class
                        * for personality profile question
                        */
                    function _getSpriteClass(choice) {
                        /* this will refer to the question as we are attaching
                            * this method to the question object
                            */
                        var question = this;
                        var choiceClass = "pp-i" + choice.key;
                        if (maxSelectedReached(question, choice)) {

                            choiceClass += " pp-disabled";
                        } else if (choice._hover) {
                            choiceClass += 'h';
                        } else if (choice.selected === '1') {
                            choiceClass += 'c';
                        }
                        return choiceClass;
                    }

                    function beforeQuestionRender(question) {

                        if (qUtils.isSelect2Interface(question)) {
                            $scope.quesSelect2Seleced[question.questionId] = qUtils.getSelect2Selected(question);
                        } else if (qUtils.isSliderInterface(question)) {
                            question._slider = newSliderOptions(question);
                        } else if (question.questionId === '427e0521-cd3d-11e2-8861-080027001c5f') {
                            question._getSpriteClass = _getSpriteClass;
                        }
                    }

                    function updateQuestion(question, action) {

                        action = action || 'update';
                        var questionCopy = angular.copy(question);
                        var questionType = question._type;
                        var questionId = question.questionId;
                        // var sectionId = questionnaireSections[question._sectionIndex].sectionId;
                        var sectionId = questionnaireData.currentSelectedSection.sectionId;
                        var ReqJobId = questionnaireData.currentSelectedSection.jobId == 'default' ? '00000000-0000-0000-0000-000000000000' : questionnaireData.currentSelectedSection.jobId;

                        switch (questionType) {
                            case 'sortableUnique':
                            case 'sortable':
                                var sortableRange = questionType === 'sortableUnique' ? [0, 4] : null;
                                qUtils.modifySortableData(questionCopy, sortableRange);
                                qUtils.getArrayOrder(questionCopy);
                                break;

                            case 'multidimensional':
                                // qUtils.sortMultidimensionalData(questionCopy);
                                break;
                        }

                        var path = 'answer';
                        var requestId = $scope.jobId ? $scope.jobId : ReqJobId;
                        var obj = {
                            questionId: questionId,
                            sectionId: sectionId,
                            values: qUtils.getValues(questionCopy),
                            requestId: requestId.toString()
                        }
                        if(!isCandidate) {
                            obj.userId = $scope.jobAccountId;
                        }

                        /**
                         * To improved performance we will mark the question as
                         * answered/updated successfully immediately before the API responds.
                         * When the API responds if there is an error we mark
                         * the question's answered/updated status as failed and undo any changes
                         * done by the success operation.
                         *
                         */
                        var updateFailed = onQuestionUpdateFailure.bind(null, question, action);
                        function updateSuccess() {

                            $scope.quesAnsweredStatus[questionId] = 'ok';
                            if (action === 'create') {
                                $scope.showMatchButton = false;
                                countQueries(1);
                                $scope.questionSection = questionnaireData.currentSelectedSection;
                                $scope.questionSection._nbAnsweredQuestions = questionnaireData.currentSelectedSection._answerBySection;                                    
                                onQuestionAnswer(question);
                            }
                            createTimeout = $timeout(function () {
                                $scope.quesAnsweredStatus[questionId] = null;
                            }, 2000);
                            if (action === 'update') {
                                $scope.showMatchButton = false;
                                countQueries(1);
                                qUtils.getArrayOrder(questionCopy);
                            }
                        }

                        var deferred = $q.defer();
                        deferred.resolve();
                        var promise = deferred.promise;
                        promise.then(updateSuccess);

                        if (action === 'create') {
                            var promiseCreateQ = matchService.postData(path, obj).then(function (res) {
                                countQueries(-1);
                            });
                            promiseCreateQ.catch(updateFailed);
                            return promise;
                        }
                        else if (action === 'update') {
                            var promiseUpdateQ = matchService.updData(path, obj).then(function (res) {
                                countQueries(-1);
                            });
                            promiseUpdateQ.catch(updateFailed);
                            return promise;
                        }
                    }

                    // set a count of queries to be sure they all are finished before to show match button
                    var countQ = 0;
                    function countQueries(arg) {
                        countQ = arg + countQ;
                        if (countQ < 1) {
                            $scope.showMatchButton = true;
                        }
                    }

                    function onQuestionAnswer(question) {
                        question.bAnswered = $scope.questionSection._isStarted = true;
                        questionnaireData._nbAnsweredQuestions++;
                        questionnaireData.currentSelectedSection._answerBySection++;
                        if(questionnaireData._nbMandatoryAnsweredQuestions <= questionnaireData._nbMandatoryTotalQuestions) {
                            questionnaireData._nbMandatoryAnsweredQuestions++;
                        }
                        $scope.questionSection._nbAnsweredQuestions++;
                        if ($scope.questionSection._nbAnsweredQuestions === $scope.questionSection.questions.length) {
                            $scope.questionSection._isComplete = true;
                            $scope.questionSection.userSelected = false;                                
                        }

                        if($scope.questionSection._isComplete) {
                            let action;
                            const nextUncompleteSection = findIndexUncompleteSection(question._sectionIndex);
                            if(nextUncompleteSection < 0) {
                                $scope.currentQuestionData = null;
                                action = 'complete';
                                showMatchSectionMsg(action, nextUncompleteSection);
                            }
                            else if($scope.questionnaireSections[0]._isComplete && question._sectionIndex == 0) {
                                action = isCandidate ? 'candidate_first_section' : 'first_section';
                                showMatchSectionMsg(action, nextUncompleteSection);
                            }
                            else if(question._sectionIndex > 0 && question._sectionIndex < 7) {
                                action = 'any_section';
                                showMatchSectionMsg(action, nextUncompleteSection);
                            }
                            // @agency: code to show optional sections for agency
                            $scope.currentQuestionData = null;
                        }
                        else {
                            autoSelectSection($scope.questionSection);
                        }
                    }

                    function onQuestionUpdateFailure(question, action) {

                        $scope.quesAnsweredStatus[question.questionId] = 'error';
                        if (action === 'create') {
                            var questionSection = questionnaireSections[question._sectionIndex];
                            question.bAnswered = questionSection._isComplete = false;
                            questionnaireData._nbAnsweredQuestions--;
                            questionSection._nbAnsweredQuestions--;
                            questionnaireData.currentSelectedSection._answerBySection--;
                            if(questionnaireData._nbMandatoryAnsweredQuestions >= 0) {
                                questionnaireData._nbMandatoryAnsweredQuestions--;
                            }
                            questionSection.userSelected = true;
                            if (!questionSection._nbAnsweredQuestions || questionSection._nbAnsweredQuestions == 0) {
                                questionSection._isStarted = false;
                            }
                            autoSelectSection(questionSection);
                        }
                    }

                    function autoSelectSection(questionSection) {
                        //selectSection( section, sectionUnansweredQuestion, userSelected )
                        var sectionSelector = function (section, userSelected) {
                            if (!section._isComplete) {
                                // find next unanswered questions in section
                                var unansweredQuestion = qUtils.getSectionNextUnansweredQuestion(section);
                                if (unansweredQuestion) {
                                    selectSection(section, unansweredQuestion, userSelected);
                                    return true;
                                }
                            }
                        };
                        /* If user selected a particular section, that section must be completed
                            * before auto selecting the next unanswered section.
                            */
                        if (questionSection && questionSection.userSelected) {
                            sectionSelector(questionSection, true);

                        } else {
                            /* Auto selecting section.
                                * Scan sections until the next uncompleted section is found.
                                * When the next uncompleted section is found call selectSection
                                * passing it the found uncompleted section and the first unanswerd question in
                                * that section which will be then loaded into the answering interface.
                                */
                            _.find(questionnaireData.sections, sectionSelector);
                        }
                    }

                    function selectSection(section, sectionUnansweredQuestion, userSelected) {
                        // $scope.selected = $scope.selected === section ? null : section ;
                        $scope.selected = ($scope.selected !== section || userSelected)  ? section : null ;
                        section.userSelected = userSelected || false;
                        questionnaireData.currentSelectedSection = $scope.questionnaireData.currentSelectedSection = section;
                        $scope.questionSection._nbAnsweredQuestions = questionnaireData.currentSelectedSection._answerBySection;
                        if (section._isComplete) {
                            $scope.currentQuestionData = null;
                        } else {
                            // find next unanswered questions in the section
                            sectionUnansweredQuestion = sectionUnansweredQuestion || qUtils.getSectionNextUnansweredQuestion(section);
                            beforeQuestionRender(sectionUnansweredQuestion);
                            // Load unanswered question in the answering inteface
                            $scope.currentQuestionData = [sectionUnansweredQuestion];
                            // set unanswered questions to 0 or 9, instead of ' '
                            setQuestionSelected($scope.currentQuestionData);
                            $scope.templateQValue = qUtils.getInterface($scope.currentQuestionData[0]); 
                        }
                    }

                    function onAccordionBoxOpen(newOpenedQuestionsIds, oldOpenedQuestionsIds) {

                        _.find(newOpenedQuestionsIds, function (isOpened, questionId) {
                            var foundNewlyOpenedQuestion = isOpened && !oldOpenedQuestionsIds[questionId];

                            if (foundNewlyOpenedQuestion) {
                                var question = qUtils.getSectionQuestionById(
                                        questionId,
                                        questionnaireData.currentSelectedSection);
                                beforeQuestionRender(question);
                            }
                            return foundNewlyOpenedQuestion;
                        }); //
                    }

                    // ** setting scope fields
                    function newSliderOptions(question) {
                        var choices = question.choices;
                        var nbChoices = choices.length;
                        var selectedIndex = _.findIndex(choices, function (choice) {
                            return choice.selected === '1';
                        });

                        /* If the question has not been answered
                            * yet we select the first option by default.
                            */
                        if (selectedIndex === -1) {
                            var defaultChoice = choices[selectedIndex = 0];
                            defaultChoice.selected = '1';
                            selectedChanged(question, defaultChoice);
                        }
                        var getLabel = function (index) {
                            return choices[index].value;
                        };
                        var config = {
                            index: selectedIndex,
                            options: {
                                //from index
                                floor: 0,
                                //to index
                                ceil: nbChoices - 1,
                                /* When the slider changes you will get the index
                                    * of the choice which the slider has selected.
                                    * Select the choice by setting selected = '1';
                                    * Unselect all other choices via modifyUniqueData func
                                    
                                    */
                                showTicks: true,
                                hideLimitLabels: true,
                                ticksTooltip: getLabel,
                                translate: getLabel,
                                onChange: function (sliderId, index, highValue) {
                                    var choice = choices[index];
                                    choice.selected = '1';
                                    selectedChanged(question, choice);
                                },
                            }
                        }
                        return config;
                    }

                    function setQuestionSelected(question) {
                        _.each(question, function (q) {
                            _.each(q.choices, function (c) {
                                if (c.selected == ' ') {
                                    c.selected = q._type === 'multidimensional' ? '9' : '0';
                                }
                            })
                        });
                    }

                    function getUnansweredQInterface(question) {
                        $scope.templateQValue = qUtils.getInterface(question);
                    }

                    $scope.getAnsweredQInterface = function (question) {
                        $scope.templateValue = qUtils.getInterface(question);
                        // $scope.quesIsOpened[question.questionId] = true;
                    }

                    function init( ) {
                        $scope.questionnaireSpinner = true;
                        $scope.initCalled = true;
                        getQuestionnaireAnswer();
                        $scope.worklandAvatar = "./../../assets/images/lady.svg";
                    }

                    function getQuestionnaireAnswer() {
                        // reset data on every init 
                        var promise;
                        $scope.questionnaireData = null;

                        var params = {
                            lang: $rootScope.language
                        }
                        if (!isCandidate) {
                            params.userId = $scope.jobAccountId;
                            params.requestId = $scope.jobId;

                            // query to matchService
                            $scope.promise = promise = matchService.getData('answer', params);
                            $scope.promise.then(function (response) {
                                $scope.questionnaireSpinner = false;
                                const res = response;
                                if (res.data && res.data.status == 'ok') {
                                    var dataRaw = res.data.data;
                                    if(isCompany) {
                                        dataRaw._nbTotalQuestions = dataRaw._nbTotalQuestions - dataRaw.sections[dataRaw.sections.length - 1]._length;
                                        dataRaw.sections.pop();
                                    }
                                    // @temp solution - to be added into api business logic
                                    _.each(dataRaw.sections, function (section) {
                                        var i = 0;
                                        _.each(section._emptyKeys, function (v, k) {
                                            blindQ.push(section.questions[v]);
                                            section.questions.splice(v - i, 1);
                                            i++;
                                        });
                                    });
                                    questionnaireData = $scope.questionnaireData = dataRaw;
                                    questionnaireSections = $scope.questionnaireSections = dataRaw.sections;

                                    $scope.$watch('questionnaireData._nbAnsweredQuestions', function () {
                                        var completionLevel = getCompletion();
                                        if (completionLevel === 100) {
                                            questionnaireData._questionnaireCompleted = true;
                                            $scope.showMatchButton = true;
                                        }
                                        else {
                                            questionnaireData._questionnaireCompleted = false;
                                        }
                                        questionnaireData._questionnaireCompletionLevel = (completionLevel > 100) ? 100 : completionLevel;
                                    });
                                    autoSelectSection();
                                }
                            }).catch((error) => {
                                $scope.questionnaireSpinner = false;
                            });
                        } else if (isCandidate) {
                            $scope.promise = promise = matchService.getData('answer/batch', params);
                            $scope.promise.then(function (response) {
                                const res = response;
                                $scope.questionnaireSpinner = false;
                                if(res.data && res.data.status == 'ok') {
                                    var allSections = [];
                                    var dataRaw = _.values(res.data.data);
                                    _.each(dataRaw, function(job) {
                                        var i = 0;
                                        questionnaireData = $scope.questionnaireData = job;
                                        _.each(job.sections, function(section) {
                                            _.each(section._emptyKeys, function (v, k) {
                                                blindQ.push(section.questions[v]);
                                                section.questions.splice(v - i, 1);
                                                i++;
                                            });
                                            allSections.push(section);
                                        });
                                    });

                                    questionnaireSections = $scope.questionnaireSections = allSections;
                                    $scope.$watch('questionnaireData._nbAnsweredQuestions', function () {
                                        var completionLevel = getCompletion();
                                        if (completionLevel === 100) {
                                            questionnaireData._questionnaireCompleted = true;
                                            $scope.showMatchButton = true;
                                            if ($scope.initCalled) {
                                                const nextUncompleteSection = findIndexUncompleteSection(0);
                                                const numberOfSectionsAnswered = _.filter($scope.questionnaireSections, (section) => {
                                                    return section._isComplete;
                                                }).length;
                                                if (!$scope.jobId && numberOfSectionsAnswered < $scope.questionnaireSections.length && $scope.questionnaireSections[0]._isComplete) {
                                                    showMatchSectionMsg('candidate_first_section', nextUncompleteSection);
                                                }                                                    
                                                $scope.initCalled = false;
                                            }
                                        }
                                        else {
                                            questionnaireData._questionnaireCompleted = false;
                                            // adding this because we want to show msg only at init. The same msg is show on answering section process
                                            $scope.initCalled = false;
                                        }
                                        questionnaireData._questionnaireCompletionLevel = (completionLevel > 100) ? 100 : completionLevel;
                                    });
                                    autoSelectSection();
                                }
                            }).catch((error) => {
                                $scope.questionnaireSpinner = false;
                            });
                        }
                    }
                    
                    $scope.$on('$destroy', function () {
                      $timeout.cancel(createTimeout);
                    });
                }
            ]
        }
    });

}) (angular);
