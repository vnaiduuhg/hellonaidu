( function ( angular ) {

    'use strict';
    angular.module( 'shared-components' )
            .directive( 'compatibilityReportModule', function () {

                return {
                    scope: {
                        candidate: '=',
                        jobTitle:'=',
                        jobTitleEn:'=',
                        jobId:'=',
                        jobRequestId: '@',
                        isCandidate: '@'
                    },
                    controller: CompatibilityReportModuleCtrl,
                    templateUrl: './../shared-components/directives/compatibility-report-module/compatibility-report-module.template.html'
                };
            } );

    CompatibilityReportModuleCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'matchService', '$sce'];

    function CompatibilityReportModuleCtrl( $scope, $rootScope, api, utils, matchService, $sce) {

        $scope.jobTitleEnMessage = '';
        $scope.jobTitleMessage = '';
        if(!$scope.jobTitleEn) {
            $scope.jobTitleEn = $scope.jobTitle;
            $scope.jobTitleEnMessage = 'No english title available';
        }
        if(!$scope.jobTitle) {
            $scope.jobTitle = $scope.jobTitleEn;
            $scope.jobTitleMessage = 'Aucun titre français disponible';
        }
        $scope.toggleLanguage = false;
        var rootModelListener = $rootScope.$watch('language', function(l) {
            if(!$scope.toggleLanguage) {
                $scope.toggleLanguage = true;
            }
            else {
                $scope.dataCReport = $scope.originalData ? $scope.dataCReportReverse : $scope.dataCReportOriginal;
                $scope.originalData = $scope.originalData == true ? false : true;
            }
            $scope.crIcon = l == 'en' ? './shared-components/icons/intro.png': './shared-components/icons/introFR.png';
            $scope.language = $rootScope.language;
        });

        $scope.out = utils.out;
        var useruid = $scope.candidate.userId ? $scope.candidate.userId : $scope.candidate.user_id; // in crm it is user_id
        $scope.hasUseruid = useruid != '' ? true : false;
        var jobRequestId = $scope.jobId;  
        if ($scope.hasUseruid){
            // @to make tests
            var promiseCR = matchService.getData( 'BI', {userId: useruid, requestId: jobRequestId, lang: $rootScope.language})
                .then( function( res ) {

                if(res.data.status == 'ok') {

                    $scope.qNotFilled = false;
                    var dataCReportOriginal = res.data.data[0];
                    var lang = $rootScope.language;
                    _.each(dataCReportOriginal.sections, function(section, key) {
                        if( section.trace.length > 0 ) {
                            _.each(section.trace, function(trace, traceKey) {
                                trace.candidateAnswer = getAnswerText(trace, 'candidate', lang, '<br><br>');
                                trace.employerAnswer = getAnswerText(trace, 'employer', lang, '<br><br>');
                            });
                        } 
                        setSectionsData(section);
                    });
                    $scope.dataCReportOriginal = dataCReportOriginal;
                    $scope.dataCReport = $scope.dataCReportOriginal;
                    $scope.originalData = true;
                }
                else {
                    $scope.hasUseruid = false; // @temp
                    // @todo - handle problem loading personality report
                }
                return $scope.promiseCR = promiseCR;
            });
        }
            
        $scope.sectionsPercentage = {};
        function setSectionsData( section ) {
            switch(section.sectionId) {

                case "40f6f9c5-761c-449d-a0c6-9d9b99480cca" :
                    $scope.sectionsPercentage.dealBreaker = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "7e004187-356a-11e5-b40d-00ff84a458ef" :
                    $scope.sectionsPercentage.personalityProfile = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "57a3f297-356a-11e5-b40d-00ff84a458ef" :
                    $scope.sectionsPercentage.socialValues = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "4244f4b6-356a-11e5-b40d-00ff84a458ef" :
                    $scope.sectionsPercentage.worklifeBalance = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "30fa5df8-356a-11e5-b40d-00ff84a458ef" :
                    $scope.sectionsPercentage.skillsCompetencies = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "85c216f8-3094-11e5-ac63-00ff84a458ef"  :
                    $scope.sectionsPercentage.workEnvCulture = section.percentage != 0 ? section.percentage : 0;
                    break;
                case "61cf1755-3094-11e5-ac63-00ff84a458ef" :
                    $scope.sectionsPercentage.compensation = section.percentage != 0 ? section.percentage : 0;
                    break;
            }
        }

        var who = 'candidate';
        var conjunction = ",";
        var key = false;
        function getAnswerText( data, who, lang, conjunction, key ) {
        var args = [ ];

            var inL = lang == 'en' ? 'in' : 'dans';
            var selected_values = {};
            if ( lang == 'en' ) {
                var selected_values = {
                    0 : 'No experience', 
                    1 : 'Less than a year', 
                    2 : '1-3 years', 
                    3 : '3-5 years', 
                    4 : '5-7 years', 
                    5 : '7-10 years', 
                    6 : '10-15 years', 
                    7 : '15-20 years', 
                    8 : 'More than 20 years', 
                    9 : null
                }
            }
            if ( $scope.language == 'fr' ) {
                var selected_values = {
                    0 : "Pas d'expérience", 
                    1 : "Moins d'un an", 
                    2 : '1-3 ans', 
                    3 : '3-5 ans', 
                    4 : '5-7 ans', 
                    5 : '7-10 ans', 
                    6 : '10-15 ans', 
                    7 : '15-20 ans', 
                    8 : 'Plus de 20 ans', 
                    9 : null
                }
            }
            if ( data ) {
                // cote09 | cote14 | cote16 | cote18 | checkbox
                var controlType = data.controlType;

                // unique | multiple | exact | array_pairs
                var choiceType = data.choiceType;

                if ( who === 'candidate' ) {
                    var answers = data.answers.user.choices;
                } else {
                    var answers = data.answers.employer.choices;
                }

                var max_item_value = '';
                if ( key == 'max' && controlType == 'checkbox' ) {
                    
                    var max_item_value = _.find(answers, function(a) {
                        return (a.selected == 1) ? a.value : '';
                    });
                }

                var textVals = [];
                _.each(answers, function(a) {

                    var cond8 = _.find([1, 2, 3, 4, 5, 6, 7, 8], function(num) { return a.selected == num; });
                    var cond6 = _.find([1,2,3,4,5,6], function(num) { return a.selected == num; }); 
                    var cond4 = _.find([1,2,3,4], function(num) { return a.selected == num; }); 
                    var cote09 = controlType == 'cote09' && choiceType == 'multiple' && a.selected < 9;
                    var cote18 = controlType == 'cote18' && cond8;
                    var cote16 = controlType == 'cote16' && cond6;
                    var cote14 = controlType == 'cote14uni3' && cond4;
                    var checkbox = controlType == 'checkbox' && a.selected == 1;

                    if ( cote18 || cote16 || cote14 || checkbox ) {
                        if ( choiceType == 'multiple' || choiceType == 'exact' ||
                            choiceType == 'array_pairs' ) {
                            textVals.push(a.value);
                        } else if ( choiceType == 'unique' ) {
                            textVals.push(a.value);
                        }
                    } 
                    else if ( cote09 ) {
                        if (  args.no_years ) {
                            textVals.push(a.value);
                        } else {
                            textVals.push(selected_values[a.selected] + ' ' + inL + ' ' + a.value);
                        }
                    }
                });

                if ( textVals.length > 0) {
                    return textVals.join(conjunction + ' ');
                }
            }
            return "";
        }
        
        var scope = {
            trustAsHtml: utils.trustAsHtml,
            getAnswerText: getAnswerText,
            setSectionsData: setSectionsData
        };
        angular.extend($scope, scope);
        $scope.$on('$destroy', function () {
          // disable the listener
          rootModelListener();
        })
    }

} )( angular );