(function (angular) {
  function customHeaderModuleCtrl(
    $scope,
    $rootScope,
    utils,
    $location,
    $state,
    authService,
    storageService,
    $cookies,
    _,
    inventoryService,
  ) {
    const { out } = utils;
    const urlParams = $location.$$search;
    const scope = {
      worklandLogo: './../assets/images/atlas-logo-new.svg',
      currentUser: $rootScope.currentUser,
      user: $rootScope.currentUser ? $rootScope.currentUser.permissions : null,
      out,
      pagename: $state.$current.name,
      rootUrl: $location.$$absUrl,
      rootUrlDefault: $location,
      logout,
      navbar: [],
      leftTabs: [],
      rightTabs: [],
      profile: [],
      settings: [],
      language: [],
    };
    angular.extend($scope, scope);

    let stateJobBoard;
    let stateLogin;
    switch ($cookies.get('mode')) {
      // @agency: add conditions for agency to redirect to correct pages
      default:
        stateJobBoard = 'jobsList';
        stateLogin = 'home';
    }

    // tabs
    const logIn = {
      titleEn: 'Log in',
      titleFr: 'Connexion',
      state: stateLogin,
      rank: 1,
    };

    const support = {
      titleEn: 'Support', titleFr: 'Support', state: 'support', rank: 3, target: '_blank',
    };
    const jobBoard = {
      titleEn: 'Job Board', titleFr: 'Emplois', state: stateJobBoard, rank: ($scope.currentUser ? 7 : 2)
    };
    const languageButton = {
      titleEn: 'EN', titleFr: 'FR', dropdown: 'language', dropdownData: $scope.language, rank: 8
    };
    const languageEnglish = {
      titleEn: 'English',
      titleFr: 'Anglais',
      switchLanguage: 'fr',
      icon: $rootScope.language === 'en' ? 'fa-check' : 'fa-circle-o fa-inverse',
      isActive: $rootScope.language === 'en',
    };
    const languageFrench = {
      titleEn: 'French',
      titleFr: 'Français',
      switchLanguage: 'en',
      icon: $rootScope.language === 'fr' ? 'fa-check' : 'fa-circle-o fa-inverse',
      isActive: $rootScope.language === 'fr',
    };

    // user logged out
    if (!$scope.currentUser) {
      inventoryService.setAgencyCookies();
      if ($rootScope.agencyIframe) {
        $scope.rightTabs.push(logIn);
      } else {
        $scope.rightTabs.push(logIn);
        $scope.rightTabs.push(support);
        // @agency: add checks for agency state name here
        if ($state.current.name !== 'companyDescription' && !(urlParams.jobId && $state.current.name === 'jobApply')) $scope.rightTabs.push(jobBoard);
      }

      // --------------------------------------------------- @todo check with Yuliya
      // if we want language and support as an external user
      if ($scope.isExternalUser) {
        const indexes = [];
        _.each($scope.rightTabs, (item, index) => {
          if (item.rank < 3) {
            indexes.push(index);
          }
        });
        _.each(indexes.reverse(), (i) => {
          $scope.rightTabs.splice(i, 1);
        });
      }
    }
    $scope.rightTabs.push(languageButton);
    $scope.language.push(languageEnglish);
    $scope.language.push(languageFrench);

    // Creating Left and RightTabs for Front End
    $scope.navbar.push({ tabs: $scope.leftTabs });
    $scope.navbar.push({ tabs: $scope.rightTabs, align: 'navbar-right' });

    function logout() {
      authService.logout().then(() => {
        redirectUser();
      }, () => {
        redirectUser();
        // @todo handle user message
      });
    }

    function redirectUser() {
      // @agency: add checks for agency to redirect to correct pages
      if ($rootScope.agencyIframe) {
        location.href = '?iframe=true';
      } else if ($state.current.name == 'home' || $state.current.name == 'jobsList' || $state.current.name == 'jobsDescription'
            || $state.current.name == 'companyDescription') {
        window.location.reload();
      } else {
        $state.go('home');
      }
    }

    // @todo keep that meanwhile MongoDB isn't updated
    /* var dataForMongoDB = api.query('get_updated_data_for_mongo_db').then( function( res ) {
            console.log(res);
      }); */

    $scope.toggleLanguageValue = function (tab) {
      $scope.language[0].icon = 'fa-circle-o fa-inverse';
      $scope.language[1].icon = 'fa-circle-o fa-inverse';
      $scope.language[0].isActive = false;
      $scope.language[1].isActive = false;
      tab.icon = 'fa-check';
      tab.isActive = true;
      if (tab.switchLanguage == 'en') {
        $rootScope.language = 'fr';
        $rootScope.langLabel = 'English';
        storageService.setItem('currentLanguage', $rootScope.language);
      } else {
        $rootScope.language = 'en';
        $rootScope.langLabel = 'Français';
        storageService.setItem('currentLanguage', $rootScope.language);
      }
      window.location.reload();
    };

    $scope.$watch('noheader', (newValue, oldValue) => {
      if (angular.isDefined(newValue)) {
        $scope.noheader = newValue;
      }
    });
  }
  customHeaderModuleCtrl.$inject = ['$scope', '$rootScope', 'utils', '$location', '$state', 'authService', 'storageService', '$cookies', '_', 'inventoryService'];
  angular.module('shared-components')
    .directive('customHeaderModule', () => ({
      scope: {
        notworkland: '@',
        logoforpage: '@',
        noheader: '@',
        isExternalUser: '@',
      },
      controller: customHeaderModuleCtrl,
      template: require('./custom-header-module.template.html'),
    }));
}(angular));
