(function (angular) {
    'use strict';
    var app = angular.module('shared-components');
    app.directive('shortFooterModule', function () {

        var inject = ['$scope', 'api', 'utils', '$rootScope', '$state', shortFooterModuleCtrl];
        function shortFooterModuleCtrl($scope, api, utils, $rootScope, $state) {

            var out = utils.out;
            var scope = {
                strings: utils.strings,
                out: out
            };
            $rootScope.isPageLoaded = $state.$current.name;
            angular.extend($scope, scope);
        }

        return {
            controller: inject,
            template: require('./short-footer-module.template.html')
        };

    });
})(angular);