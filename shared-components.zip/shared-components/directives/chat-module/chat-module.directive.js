(function (angular) {
  function chatModuleCtrl($scope, utils) {
  	const vm = this;
    const vmExtend = {
    	trustAsHtml: utils.trustAsHtml,
    	out: utils.out,
    };

     angular.extend(vm, vmExtend);

      
  }

  chatModuleCtrl.$inject = ['$scope', 'utils'];
  angular.module('shared-components')
  	.directive('chatModule', () => ({
    scope: {
    },
    bindToController: {
      applicationChat: '=',
	   worklandAvatar: '=',
    },
    controller: chatModuleCtrl,
    controllerAs: 'vm',
    template: require('./chat-module.template.html'),
  }));
}(angular));