( function ( angular ) {

    'use strict';
    angular.module( 'shared-components' )
            .directive( 'personalityReportModule', function () {

                return {
                    scope: {
                        candidate: '=',
                        jobTitle:'=',
                        jobTitleEn:'=',
                        jobId: '@',
                        jobRequestId: '@',
                        isCandidate: '@'
                    },
                    controller: PersonalityReportModuleCtrl,
                    templateUrl: './../shared-components/directives/personality-report-module/personality-report-module.template.html'
                };
            } );

    PersonalityReportModuleCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'matchService', '$sce', 'translationService'];

    function PersonalityReportModuleCtrl( $scope, $rootScope, api, utils, matchService, $sce, translationService) {

        clearAllFlags();
        $scope.ppSpinner = true;
        $scope.out = utils.out;  
        var useruid = $scope.candidate.userId ? $scope.candidate.userId : $scope.candidate.ID;
        $scope.hasUseruid = useruid != '' ? true : false;
        var jobRequestId = $scope.jobRequestId;
        $scope.openPersonalityTab = 'primary';

        function switchPersonalityText(personalityText) {
            $scope.openPersonalityTab = personalityText;
        }

        if($scope.hasUseruid) {
            var promisePR = matchService.getData( 'BI/ProfilAncres', {userId: useruid})
            .then( function( res ) {

                $scope.ppSpinner = false;
                if(res.data.status == 'questionnaires unfilled') {
                    $scope.qNotFilled = true;
                    $scope.noData = true;
                    // show link to fill questionnaire here
                }
                else if(res.data.status == 'ok') {

                    $scope.qNotFilled = false;
                    var dataPReport = res.data;
                    $scope.dataReport = dataPReport;

                    // @todo - handle error case - message to user template 
                    if ( !dataPReport.status ) {
                        $scope.noData = true;
                        return;
                    }
                    if(dataPReport.data[1].resArray.length < 1) {
                        // "Unable to create personality profile compatibility report";
                        $scope.failLoadingData = true;
                        return;
                    }
                    set_personality_profile_data($scope.dataReport);
                }
                else {
                    // @todo - handle problem loading personality report
                    $scope.qNotFilled = true;
                    $scope.failLoadingData = true;
                }

            }).catch( function() {
                $scope.ppSpinner = false;
                $scope.failLoadingData = true;
            });
        }

        function clearAllFlags() {
            $scope.noData = false;
            $scope.failLoadingData = false;
            $scope.qNotFilled = false;
        }

        function array_flip(trans) { 
                    
            var key, tmp_ar = {}; 
            for (key in trans) { 
                if (trans.hasOwnProperty(key)) { 
                    tmp_ar[trans[key]] = key; 
                } 
            } 
            return tmp_ar; 
        }

        function set_personality_profile_data( dataReport ) {
        
            var data_report = dataReport;
            var response = {};
            var personality_profiles_text = {};

            var specific_recommendation_codes = {
                1 : '031',
                2 : '030',
                3 : '011',
                4 : '010',
                5 : '121',
                6 : '120',
                7 : '101',
                8 : '100',
                9 : '231',
                10 : '230',
                11 : '211',
                12 : '210',
                13 : '321',
                14 : '320',
                15 : '301',
                16 : '300',
            };

            // retieve personality profile static text
            setPersonalityProfileText();

            // set main personality traits text
            $scope.personality_arr_per = {};
            $scope.personality_arr_intro = {};
            _.each(data_report.data[1].resArray, function(trait, key) {
                if(key != 2) {
                    $scope.personality_arr_per[key] = trait;
                }
                else {
                    $scope.personality_arr_intro[0] = trait;
                }
            });

            //  retrieving code for specific recommendations 
            var profile_num = _.map(data_report.data[1].resArray, function(value, key) {
                return value;
            }).join('');

            var code = _.find(array_flip(specific_recommendation_codes), function(value, key) {
                return profile_num == key;
            });
            
            var specific_recommendations = code+'_specific_recommendations';
            setSpecificRecommendationsText(specific_recommendations);
        }

        function setSpecificRecommendationsText(fileCode) {

            var promiseSRData = translationService.translateReportProfile(fileCode)
            .then( function( response ) {
                $scope.sp = response;
                $scope.specific_recommendations = $rootScope.language == 'en' ? $scope.sp.en : $scope.sp.fr;
            });
        }

        function setPersonalityProfileText() {

            var promisePPData = translationService.translateReportProfile('report_profile')
            .then( function( response ) {
                $scope.pp = response;
                $scope.profile_personality = $rootScope.language == 'en' ? $scope.pp.en : $scope.pp.fr;
                $scope.profile_personality_style = $rootScope.language == 'en' ? $scope.pp.en.style : $scope.pp.fr.style;
                $scope.profile_personality_features = $rootScope.language == 'en' ? $scope.pp.en.personality : $scope.pp.fr.personality;
            });
            var promiseGRData = translationService.translateReportProfile('general_recommendations')
            .then( function( response ) {
                $scope.gr = response;
                $scope.general_recommendations = $rootScope.language == 'en' ? $scope.gr.en : $scope.gr.fr;
            });
        }

        var rootModelListener = $rootScope.$watch('language', function(l) {

            switch(l) {
                case 'en':
                    $scope.specific_recommendations = $scope.sp ? $scope.sp.en : "";
                    $scope.profile_personality_style = $scope.pp ? $scope.pp.en.style : "";
                    $scope.profile_personality_features = $scope.pp ? $scope.pp.en.personality : "";
                    $scope.profile_personality = $scope.pp ? $scope.pp.en : "";
                    $scope.general_recommendations = $scope.gr ? $scope.gr.en : "";
                    break;
                case 'fr':
                    $scope.specific_recommendations = $scope.sp ? $scope.sp.fr : "";
                    $scope.profile_personality_style = $scope.pp ? $scope.pp.fr.style : "";
                    $scope.profile_personality_features = $scope.pp ? $scope.pp.fr.personality : "";
                    $scope.profile_personality = $scope.pp ? $scope.pp.fr : "";
                    $scope.general_recommendations = $scope.gr ? $scope.gr.fr : "";
                    break;
            }
        });

        var scope = {
            trustAsHtml: utils.trustAsHtml, // this function allows displaying HTML styles inside the email template content
            array_flip: array_flip,
            set_personality_profile_data: set_personality_profile_data,
            setSpecificRecommendationsText: setSpecificRecommendationsText,
            setPersonalityProfileText: setPersonalityProfileText,
            clearAllFlags: clearAllFlags,
            failLoadingData: false,
            noData: false
        }
        angular.extend($scope, scope);
        $scope.$on('$destroy', function () {
          // disable the listener
          rootModelListener();
        })
    }

} )( angular );