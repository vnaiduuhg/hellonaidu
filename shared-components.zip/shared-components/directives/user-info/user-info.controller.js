(function (angular) {
  function UserInfoCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    authService,
    storageService,
    userAccountsService,
  ) {
    $scope.out = utils.out;
    const scope = {
      firstName: '',
      lastName: '',
      firstNameChange: 'false',
      lastNameChange: 'false',
      currentPassword: '',
      password: '',
      passwordConfirmation: '',
      message: '',
      loading: false,
      error: false,
      changes: [],
      init,
      resetInputFields,
      passwordChangeSuccessMsg,
      passwordChangeFailMsg,
      passwordError,
      pwdNotMatchedMsg: false,
      pwdWrongPatternMsg: false,
      pwdPatternOk: false,
      pwdMatchOk: false,
    };
    angular.extend($scope, scope);

    function init() {
        if ($rootScope.currentUser && $rootScope.currentUser.user) {
          $scope.firstName = $rootScope.currentUser.user.first_name;
          $scope.lastName = $rootScope.currentUser.user.last_name;
        }
    }
    init();

    function reloadData() {
      return userAccountsService.getCurrentUserData().then( ()=> { init();})
    }

    $scope.nameFormat = /^[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]+(([',. -][áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z ])?[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]*)*$/;

    $scope.updateFirstName = function () {
      $scope.firstNameChange = 'true';
    };
    $scope.updateLastName = function () {
      $scope.lastNameChange = 'true';
    };

    function serverError() {
      $.confirm({
        title: utils.out('Oups! Une erreur s\'est produite lors du traitement de votre demande', 'Oops! Something went wrong while processing your request'),
        content: utils.out('Si le problème persiste, veuillez le signaler à notre équipe d\'assistance à support@workland.com.', 'If the problem persists please report the issue to our Support Team at support@workland.com.'),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-secondary',
            action() {

            },
          },
        },
      });
    }

    let msgFr;
    let msgEn;
    let msgTitleFr;
    let msgTitleEn;

    function passwordError() {
      msgFr = '';
      msgEn = '';
      if ($scope.pwdWrongPatternMsg) {
        msgFr = 'Le mot de passe est invalide';
        msgEn = 'Invalid password';
      }
      if ($scope.pwdNotMatchedMsg) {
        msgFr = `${msgFr}<br>La confirmation du mot de passe doit être indentique au mot de passe entré.`;
        msgEn = `${msgFr}<br>Password confirmation must be identical to the password entered.`;
      }
      if(!$scope.password || !$scope.passwordConfirmation) {
        msgFr = `${msgFr}<br>Veuillez rentrer un nouveau mot de passe et le confirmer.`;
        msgEn = `${msgFr}<br>Please enter a new password and confirm it.`;
      }

      $.confirm({
        title: utils.out('Erreur!', 'Error!'),
        content: utils.out(msgFr, msgEn),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function nameError(err) {
      switch (err) {
        case 'unchanged':
          msgTitleFr = 'Champs de nom ou prénom non modifiés!';
          msgTitleEn = 'Name fields not modified!';
          msgFr = 'Veuillez fournir un nouveau nom ou prénom.';
          msgEn = 'Please provide a new first or last name.';
          break;
        case 'required':
          msgTitleFr = 'Champs requis!';
          msgTitleEn = 'Required field!';
          msgFr = 'Veuillez remplir le champ requis.';
          msgEn = 'Please fill in the required field.';
          break;
        case 'invalid':
        default:
          msgTitleFr = 'Format de nom invalide!';
          msgTitleEn = 'Invalid name format!';
          msgFr = 'Veuillez entrer votre nom ou prénom à nouveau.';
          msgEn = 'Please re-enter your first or last name.';
      }

      $.confirm({
        title: utils.out(msgTitleFr, msgTitleEn),
        content: utils.out(msgFr, msgEn),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function passwordChangeFailMsg(error) {
      switch(error) {
        case 'current_password_not_matched':
          msgTitleEn = 'Wrong current password!';
          msgTitleFr = 'Mot de passe erroné!';
          msgEn = 'Please re-enter your current password.';
          msgFr = 'Veuillez entrer votre mot de passe actuel à nouveau.';
          break;
        case 'invalid_password_pattern':
          msgTitleEn = 'Wrong password pattern!';
          msgTitleFr = 'Mauvais modèle de mot de passe!';
          msgEn = "Your new password must be 8+ characters, including at least one special character, one uppercase letter and one lowercase letter or digit";
          msgFr = "Votre nouveau mot de passe doit comporter au moins 8 caractères, dont au moins un caractère spécial, une lettre majuscule ainsi qu'une lettre minuscule ou chiffre";
          break;
        default:
          msgTitleEn = "Error!";
          msgTitleFr = "Erreur!";
          msgEn = "Your password could not be updated. Please check all fields and try again.";
          msgFr = "Votre mot de passe n'a pas pu être mis à jour. Veuillez vérifier tous les champs et réessayer.";

      }
      $.confirm({
        title: utils.out(msgTitleFr, msgTitleEn),
        content: utils.out(msgFr, msgEn),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function passwordChangeSuccessMsg() {
      $.confirm({
        title: utils.out('Succès!', 'Success!'),
        content: utils.out('Votre mot de passe a été changé avec succès.', 'Your password has been changed successfully.'),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'Ok',
            btnClass: 'btn-secondary',
            action() {
              reloadData();
            },
          },
        },
      });
    }

    function nameChangeSuccessMsg() {
      $.confirm({
        title: utils.out('Succès!', 'Success!'),
        content: utils.out('Votre nom a été changé avec succès.', 'Your name has been changed successfully.'),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'Ok',
            btnClass: 'btn-secondary',
            action() {
              reloadData();
            },
          },
        },
      });
    }

    function nameChangeFailMsg() {
      $.confirm({
        title: utils.out('Échec!', 'Fail!'),
        content: utils.out('Une erreur est survenue. Veuillez entrer votre nom à nouveau.', 'An error has occurred. Please enter your name again.'),
        theme: 'modern',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function resetInputFields(resetAll) {
      $scope.currentPassword = '';
      if (resetAll) {
        $scope.password = '';
        $scope.passwordConfirmation = '';
        $scope.email = '';
        $scope.firstName = '';
        $scope.lastName = '';
        $scope.passwordResetForm.$setPristine();
      }
    }

    $scope.validateConfirmationPassword = function () {
      if ($scope.passwordConfirmation && $scope.password) {
        if ($scope.passwordConfirmation === $scope.password) {
          $scope.pwdMatchOk = true;
          $scope.pwdNotMatchedMsg = false;
        } else {
          $scope.pwdNotMatchedMsg = true;
        }
      } else {
        $scope.pwdNotMatchedMsg = true;
      }
    };

    $scope.validatePassword = function () {
      const pattern = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
      $scope.pwdPatternOk = false;
      if ($scope.password) {
        if (pattern.test($scope.password)) {
          $scope.pwdPatternOk = true;
          $scope.pwdWrongPatternMsg = false;
        } else {
          $scope.pwdWrongPatternMsg = true;
        }
      } else {
        $scope.pwdWrongPatternMsg = true;
      }
    };

    $scope.updateUserName = function () {
      if (angular.equals($scope.firstNameChange, 'true') || angular.equals($scope.lastNameChange, 'true')) {
        if (!$scope.passwordResetForm.firstName.$error.pattern && !$scope.passwordResetForm.lastName.$error.pattern && !$scope.passwordResetForm.lastName.$error.required && !$scope.passwordResetForm.lastName.$error.required) {
          $scope.loading = true;
          $scope.error = false;
          const id = storageService.getItem('userId');
          const data = {
            first_name: $scope.firstName,
            last_name: $scope.lastName,
          };

          api.service_query('accounts', `users/${id}`, 'PUT', data).then((response) => {
            $scope.loading = false;
            if (response.data.status === 'success') {
              $scope.firstNameChange = 'false';
              $scope.lastNameChange = 'false';
              resetInputFields(true);
              nameChangeSuccessMsg();
            } else {
              resetInputFields(false);
              nameChangeFailMsg();
            }
          }).catch(() => {
            $scope.loading = false;
            $scope.error = true;
            serverError();
          });
        } else {
          $scope.error = true;
          if ($scope.passwordResetForm.lastName.$error.required || $scope.passwordResetForm.firstName.$error.required) {
            nameError('required');
          } else {
            nameError('invalid');
          }
        }
      } else {
        $scope.error = true;
        nameError('unchanged');
      }
    };

    $scope.updateUserPassword = function () {
      if ($scope.password !== $scope.passwordConfirmation) {
        passwordError();
        return false;
      }

      if ($scope.pwdPatternOk && $scope.pwdMatchOk) {
        $scope.loading = true;
        $scope.error = false;

        const data = {
          current_password: $scope.currentPassword,
          password: $scope.password,
        };

        authService.resetPassword(data).then((response) => {
          $scope.loading = false;
          if (response.data.status === 'success') {
            $scope.passwordChange = 'false';
            resetInputFields(true);
            passwordChangeSuccessMsg();
          } else {
            resetInputFields(false);
            passwordChangeFailMsg();
          }
        }).catch((error) => {
          $scope.loading = false;
          $scope.error = true;
          if (error.data.message === 'current_password_not_matched') {
            passwordChangeFailMsg('current_password_not_matched');
          } else if (error.status === 422 && error.data.password[0] === 'invalid_password_pattern') {
            passwordChangeFailMsg('invalid_password_pattern');
          } else {
            serverError();
          }
        });
      } else {
        passwordError();
      }
    };
  }

  UserInfoCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    'authService',
    'storageService',
    'userAccountsService',
  ];

  angular.module('shared-components')

    .controller('UserInfoCtrl', UserInfoCtrl);
}(angular));
