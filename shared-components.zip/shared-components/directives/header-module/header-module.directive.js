(function (angular) {
  function headerModuleCtrl(
    $scope,
    $rootScope,
    utils,
    worklandLocalize,
    $location,
    $state,
    authService,
    storageService,
    $cookies,
    _,
    inventoryService,
  ) {
    const { out } = utils;
    const urlParams = $location.$$search;
    const scope = {
      worklandLogo: './../assets/images/atlas-logo-new.svg',
      currentUser: $rootScope.currentUser,
      user: $rootScope.currentUser ? $rootScope.currentUser.permissions : null,
      strings: worklandLocalize.strings,
      out,
      worklandLocalize,
      pagename: $state.$current.name,
      rootUrl: $location.$$absUrl,
      rootUrlDefault: $location,
      logout,
      navbar: [],
      leftTabs: [],
      rightTabs: [],
      profile: [],
      settings: [],
      language: [],
    };
    angular.extend($scope, scope);

    let stateJobBoard;
    let stateLogin;

    $scope.$on('languageChanged', (evt, language) => {
      $rootScope.language = language;
    })

    switch ($cookies.get('mode')) {
      // @agency: add conditions for agency to redirect to correct pages
      default:
        stateJobBoard = 'jobsList';
        stateLogin = 'home';
    }

    if (!$rootScope.storageEvent) {
      $rootScope.storageEvent = (event) => {
        if (['account_role', 'account_type', 'userId', 'account_id'].includes(event.key) && $scope.currentUser) {
          const item = storageService.getItem(event.key);
          if (item != $rootScope[event.key]) {
            storageService.setItem('duplicated_login', true);
            logout();
          }
        }
      };
      window.addEventListener('storage', $rootScope.storageEvent);
    }

    // tabs
    const logIn = {
      titleEn: 'Log in',
      titleFr: 'Connexion',
      state: stateLogin,
      rank: 1,
    };

    const support = {
      titleEn: 'Support', titleFr: 'Support', state: 'support', rank: 3, target: '_blank',
    };
    const planningModule = {
      titleEn: 'Planning', titleFr: 'Planification', state: 'planning', rank: -1
    };
    const myJobs = {
      titleEn: 'My Jobs', titleFr: 'Mes emplois', state: 'employer', rank: 0
    };
    const diffusion = {
      titleEn: 'Diffusion', titleFr: 'Diffusion', state: 'diffusion', rank: 1
    };
    const statistics = {
      titleEn: 'Statistics', titleFr: 'Statistiques', state: 'statistics', rank: 2
    };
    const modules = {
      titleEn: 'Modules', titleFr: 'Modules', state: 'modules', rank: 3
    };
    const leads = {
      titleEn: 'Leads', titleFr: 'Potentiels', state: 'crmLeads', rank: 4
    };
    const candidates = {
      titleEn: 'Candidates', titleFr: 'Candidats', state: 'crmCandidates', rank: 5
    };
    const candidateHomePage = {
      titleEn: 'Home', titleFr: 'Accueil', state: 'candidateProfile', rank: 6
    };
    const jobBoard = {
      titleEn: 'Job Board', titleFr: 'Emplois', state: stateJobBoard, rank: ($scope.currentUser ? 7 : 2)
    };
    const languageButton = {
      titleEn: 'EN', titleFr: 'FR', dropdown: 'language', dropdownData: $scope.language, rank: 8
    };
    const myAccount = {
      titleEn: 'My Account', titleFr: 'Mon compte', state: 'userInfo', icon: 'bi bi-person', rank: 0
    };
    const companyProfile = {
      titleEn: 'Company Profile',
      titleFr: 'Profil de l\'organisation',
      state: 'employerProfile',
      icon: 'bi bi-building',
      rank: 1       
    };
    const myPlan = {
      titleEn: 'Plan', titleFr: 'Forfait', state: 'userPlan', icon: 'bi bi-cart', rank: 2
    };
    const settings = {
      titleEn: 'Settings', titleFr: 'Paramètres', state: 'accountSettings', icon: 'bi bi-gear', rank: 4
    };
    const supportProfile = {
      titleEn: 'Support', titleFr: 'Support', state: 'support', icon: 'bi bi-telephone', rank: 5, target: '_blank',
    };
    const logOut = {
      titleEn: 'Log Out', titleFr: 'Se déconnecter', logout: true, icon: 'bi bi-power', rank: 6
    };
    const accountMembers = {
      titleEn: 'Account Members', titleFr: 'Membres du compte', state: 'userAssignment', icon: 'bi bi-people', rank: 1
    };
    const languageEnglish = {
      titleEn: 'English',
      titleFr: 'Anglais',
      switchLanguage: 'fr',
      icon: $rootScope.language === 'en' ? 'fa fa-check' : 'fa fa-circle-o fa-inverse',
      isActive: $rootScope.language === 'en',
    };
    const languageFrench = {
      titleEn: 'French',
      titleFr: 'Français',
      switchLanguage: 'en',
      icon: $rootScope.language === 'fr' ? 'fa fa-check' : 'fa fa-circle-o fa-inverse',
      isActive: $rootScope.language === 'fr',
    };

    function getProfileLogo() {
      const minioUrl = `${window.appConfig.MINIO_URL}media/Profile/Logos/`;
      if ($scope.user.isCandidate) {
        if ($scope.currentUser.account.detail.length > 0 && $scope.currentUser.account.detail[0].photo) {
          return minioUrl + $scope.currentUser.account.detail[0].photo;
        }
        return `${minioUrl}generic_avatar.jpg`;
      }
      if ($scope.currentUser.profile_page.length > 0 && $scope.currentUser.profile_page[0].logo) {
        return minioUrl + $scope.currentUser.profile_page[0].logo;
      }
      return `${minioUrl}generic_logo.png`;
    }

    // user logged out
    if (!$scope.currentUser) {
      inventoryService.setAgencyCookies();
      if ($rootScope.agencyIframe) {
        $scope.rightTabs.push(logIn);
      } else {
        $scope.rightTabs.push(logIn);
        $scope.rightTabs.push(support);
        // @agency: add checks for agency state name here
        if ($state.current.name !== 'companyDescription' && !(urlParams.jobId && $state.current.name === 'jobApply')) $scope.rightTabs.push(jobBoard);
      }

      // --------------------------------------------------- @todo check with Yuliya
      // if we want language and support as an external user
      if ($scope.isExternalUser) {
        const indexes = [];
        _.each($scope.rightTabs, (item, index) => {
          if (item.rank < 3) {
            indexes.push(index);
          }
        });
        _.each(indexes.reverse(), (i) => {
          $scope.rightTabs.splice(i, 1);
        });
      }
    } else {
      // for everybody
      $scope.profile.push(myAccount);
      $scope.profile.push(supportProfile);
      $scope.profile.push(logOut);
      if ($scope.user.isUserManager) {
        $scope.profile.push(accountMembers);
      }
      if (!$scope.user.isCandidate) {
        if (($scope.user.isEmployer || $scope.user.isRecruiter || $scope.user.isClient || $scope.user.isAgency)
            && !$scope.user.isUserManager) {
          $scope.leftTabs.push(myJobs);
          if (!$scope.user.isClient) $scope.leftTabs.push(planningModule);
          $scope.leftTabs.push(statistics);
          $scope.leftTabs.push(modules);
        }
        if ($scope.user.isClient) {
          $scope.profile.push(myPlan);
        }
        if (!($scope.user.isDeptMgrRecruiter || $scope.user.isUserManager || $scope.user.isClient)) {
          $scope.profile.push(settings);
          $scope.leftTabs.push(diffusion);
        }
        if (($scope.user.isATSFull && !$scope.user.isDeptMgrRecruiter && !$scope.user.isUserManager && !$scope.user.isClient) || ($scope.user.isClient && $rootScope.isPremiumClient)) {
          $scope.leftTabs.push(candidates);
          $scope.leftTabs.push(leads);
        }
      } else {
        $scope.rightTabs.push(candidateHomePage);
      }

      if (!$scope.user.isAgency && !$scope.user.isClient && !$scope.user.isInternalEmployee) {
        $scope.rightTabs.push(jobBoard);
      }
      if ($scope.user.isEmployer || $scope.user.isAdminRecruiter || $scope.user.isAgency || $scope.user.isClient) {
        $scope.profile.push(companyProfile);
      }
      $scope.rightTabs.push({
        img: getProfileLogo(),
        dropdown: 'profile',
        dropdownData: $scope.profile,
        rank: 7,
      });
    }
    $scope.rightTabs.push(languageButton);
    $scope.language.push(languageEnglish);
    $scope.language.push(languageFrench);

    // Creating Left and RightTabs for Front End
    $scope.navbar.push({ tabs: $scope.leftTabs });
    $scope.navbar.push({ tabs: $scope.rightTabs, align: 'navbar-right' });

    function logout() {
      authService.logout().then(() => {
        redirectUser();
      }, () => {
        redirectUser();
        // @todo handle user message
      });
    }

    function redirectUser() {
      // @agency: add checks for agency to redirect to correct pages
      if ($rootScope.agencyIframe) {
        location.href = '?iframe=true';
      } else if ($state.current.name == 'home' || $state.current.name == 'jobsList' || $state.current.name == 'jobsDescription'
            || $state.current.name == 'companyDescription') {
        window.location.reload();
      } else {
        $state.go('home');
      }
    }

    // @todo keep that meanwhile MongoDB isn't updated
    /* var dataForMongoDB = api.query('get_updated_data_for_mongo_db').then( function( res ) {
            console.log(res);
      }); */

    $scope.toggleLanguageValue = function (tab) {
      storageService.setItem('currentLanguage', tab.switchLanguage == 'en' ? 'fr' : 'en');
      $scope.$emit('menuLanguageSwitched', storageService.getItem('currentLanguage'));
      window.location.reload();
    };

    $scope.$watch('noheader', (newValue, oldValue) => {
      if ( angular.isDefined(newValue) ) {
        $scope.noheader = newValue;
      }
    })
  
    // @agency: can define agency logos here
  }
  headerModuleCtrl.$inject = ['$scope', '$rootScope', 'utils', 'worklandLocalize', '$location', '$state', 'authService', 'storageService', '$cookies', '_', 'inventoryService'];
  angular.module('shared-components')
    .directive('headerModule', () => ({
      scope: {
        notworkland: '@',
        logoforpage: '@',
        noheader: '@',
        isExternalUser: '@',
      },
      controller: headerModuleCtrl,
      template: require('./header-module.template.html'),
    }));
}(angular));
