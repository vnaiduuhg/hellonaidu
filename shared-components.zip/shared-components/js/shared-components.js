
(function (angular) {
    'use strict';

    //*** External dependencie
    angular.module('underscore', []).constant('_', window._);

    angular.module( 'worklandLocalize', [])
    .constant('worklandLocalize', {

        "servicesPageUrl" : window.appConfig.ATLAS_URL + "services/",
        "compatibilityReportUrl" : "analyse-de-compatibilite/",
        "cvUrl" : window.appConfig.ATLAS_URL + "print-cv/",
        "iconsUrl": window.appConfig.ATLAS_UI_URL + "shared-components/icons",
        "apps_directory": window.appConfig.ATLAS_UI_URL,
    	"images_directory": window.appConfig.ATLAS_UI_URL + 'assets/images/',
        "ajaxUrl": window.appConfig.ATLAS_URL + "wp-admin/admin-ajax.php",
        "themeUrl": window.appConfig.ATLAS_UI_URL,
        "servicesPaymentUrl": window.appConfig.ATLAS_URL + "payment-page/",
        "language": "fr",
        "questionnaireUrl": window.appConfig.ATLAS_UI_URL + "shared-components/directives/questionnaire",
        "worklandNonce": "5191efd7b1",
        'iconsUrlEmployer' : window.appConfig.ATLAS_UI_URL + "/employer-profile/images/icons",
        'imagesUrlEmployer' :  window.appConfig.ATLAS_UI_URL + "/employer-profile/images",

        "strings": {
            "countries": {
                "Canada": "Canada",
                "US": "United States"
            },
            "provinces": {
                "Alberta": "Alberta",
                "British Columbia": "British Columbia",
                "Manitoba": "Manitoba",
                "New Brunswick": "New Brunswick",
                "Newfoundland": "Newfoundland",
                "Northwest Territories": "Northwest Territories",
                "Nova Scotia": "Nova Scotia",
                "Nunavut": "Nunavut",
                "Ontario": "Ontario",
                "Prince Edward Island": "Prince Edward Island",
                "Québec": "Québec",
                "Saskatchewan": "Saskatchewan",
                "Yukon": "Yukon"
            },
            "months": {
                "1": "January",
                "2": "February",
                "3": "March",
                "4": "April",
                "5": "May",
                "6": "June",
                "7": "July",
                "8": "August",
                "9": "September",
                "10": "October",
                "11": "November",
                "12": "December"
            },
            "jobDescription": "Job Description",
            "requiredField": "Required Field",
            "socialMedia": "Social Networks",
            "contactInfo": "Contact Information",
            "myLists": "My Jobs",
            "preSelection": " Pre-Selection",
            "answerToQuestion": "Answer to the question",
            "candidate": "Candidate",
            "employer": "Employer",
            "candidates": "Candidates",
            "publish": "Diffusion",
            "addSections": "Add Sections",
            "operations": "Operations",
            "whoAreWe": "About Us",
            "companySuccess": "Our Success Stories",
            "prizesDistinctions": "Awards & Distinctions",
            "advantagesBenefits": "Advantages & Benefits",
            "qualityLife": "Quality of Life",
            "yes": "Yes",
            "no": "No",
            "from": "From",
            "to": "To",
            "seekingPosition": "Seeking position of:",
            "categoryExpertise": "Target Job Category:",
            "generateResume": "Generate Resume",
            "compatibilityReport": "Personality Test",
            "jobSearchStatus": "Job Search Status",
            "clickHere": "Click Here",
            "myInterviews": "My Interviews",
            "public": "Public",
            "passive": "Passive",
            "active": "Active",
            "inactive": "Inactive",
            "anonymous": "Anonymous",
            "email": "Email",
            "mobile": "Mobile",
            "phone": "Phone",
            "skype": "Skype",
            "profile": "Profile",
            "questionnaire": "Questionnaire",
            "references": "References",
            "mockInterview": "Mock Interview",
            "matches": "Matches",
            "pending_questionnaire": "Pending Pre-selection Questionnaires",
            "applications": "Applications",
            "period": "Period",
            "position": "Position",
            "address": "Address",
            "dashboard": "MY DASHBOARD",
            "name": "Name",
            "relation": "Relation",
            "company": "Company",
            "dateSent": "Date sent",
            "dateResponse": "Responded date",
            "title": "Title",
            "english": "English",
            "french": "French",
            "progressChart": "Progress chart",
            "mostRecent": "Most recent",
            "location": "Location",
            "present": "Present",
            "degree": "Degree",
            "del": "Delete",
            "update": "Update",
            "submit": "Submit",
            "cancel": "Cancel",
            "clear": "Clear",
            "reset": "Reset",
            "updateSuccessful": "Update Successful",
            "saveNext": "Save and next",
            "addReference": "Add a reference",
            "awaitingResponse": "Awaiting response",
            "confirmDelete": "Are you sure?",
            "confirmDeletePost": "Are you sure you want to delete this post?",
            "needHelp": "Need some extra help? Check out our additional services to support you in your job searching",
            "tools": "Tools and Services",
            "dealBreaker": "Deal Breakers",
            "totalCompensation": "Compensation",
            "workEnviroment": "Work Environment and Culture",
            "skillsCompetencies": "Skills and Competencies",
            "workLifeBalance": "Work / Life Balance",
            "socialValues": "Social Values",
            "personalityProfile": "Personality Profile",
            "uploadResume": "Upload Resume",
            "progress": "Progress",
            "permanent": "Permanent",
            "temporary": "Temporary",
            "contract": "Contract",
            "fulltime": "Full time",
            "parttime": "Part time",
            "postalCode": "Postal code",
            "category": "Category",
            "function": "Function",
            "city": "City",
            "province": "Province/State",
            "country": "Country",
            "extensionNum": "Extension #",
            "hideQuestions": "Hide my questions",
            "showQuestions": "Display my questions",
            "personalityType": "Personality Type",
            "lvlofEdu": "Level of Education",
            "requestAccess": "Request access",
            "showInterest": "Show your interest",
            "summary": "Summary",
            "careerObjectives": "Career Objectives",
            "experience": "Work Experience",
            "education": "Education",
            "certifications": "Certifications & Trainings",
            "socialInv": "Additional Skills, Activities, & Information",
            "miQues": "Mock Interview Questions",
            "q1mi": "Describe one of your top professional or personal accomplishments?",
            "q2mi": "What is your ideal supervisor like? Describe how you like to be managed.",
            "q3mi": "Have you supervised the work of employees or teams? What is your management style ?",
            "q4mi": "What are your key strengths and points you wish to further develop?",
            "q5mi": "What are your relationships to people within organizations? How would your boss and colleagues describe you?",
            "q6mi": "What is your unique contribution to companies? What makes you different?",
            "q7mi": "If you were a utensil, what would you be? Why?",
            "selectTemplate": "Select template",
            "send": "Send",
            "subject": "Subject",
            "message": "Message",
            "select": "Select",
            "recurencePeriods": {
                "Daily": "Daily",
                "Weekly": "Weekly",
                "Bi-weekly": "Bi-weekly",
                "Monthly": "Monthly"
            },
            "priorities": {
                "Low": "Low",
                "Medium": "Medium",
                "High": "High"
            },
            "recruiterPermissions": [
                [
                    80,
                    "User manager"
                ],
                [
                    30,
                    "Administrator"
                ],
                [
                    20,
                    "Recruiter"
                ],
                [
                    10,
                    "Requesting/Approving Manager"
                ]
            ],
            "recruiterPermissionsFr": [
                [
                    80,
                    "Gestionnaire principal"
                ],
                [
                    30,
                    "Administrateur"
                ],
                [
                    20,
                    "Recruteur"
                ],
                [
                    10,
                    "Gestionnaire"
                ]
            ],
            "dashboardPermissions": {
                "Recruiter Previous": "Recruiter Previous",
                "Recruiter": "Recruiter",
                "Admin": "Admin",
                "Sales": "Sales",
                "delete": "Remove"
            },
            "crudQuestionnaireModule": {
                "weight": "Weight",
                "dealBreaker": "Deal Breakers",
                "limited": "Limited",
                "questionSettings": "Settings",
                "questionTitle": "Title",
                "questionChoices": "Answer Choices",
                "questionText": "Questions Text",
                "employerInterface": "Employer Interface",
                "candidateInterface": "Candidate Interface",
                "nbChoices": "Number of choices",
                "multipleChoice": "Multiple choice",
                "singleChoice": "Single choice",
                "matchIf": "Match criteria",
                "checkbox": "Checkbox",
                "radioButton": "Radio button",
                "atLeastOneInCommon": "At least one choice in common",
                "selectAlgorithm": "Select algorithm",
                "selectQuestionType": "Select question type",
                "exactNbChoices": "Number of choices"
            },
            "interviewModule": {
                "notes": "Notes",
                "selectType": "Select type",
                "selectAttendee": "Select Attendee",
                "selectColor": "Select Color",
                "refresh": "Refresh",
                "cancelschedule": "Cancel Schedule",
                "attendee_confirm": "Attendee Confirm Expire Date",
                "expire_date": "Expire Date",
                "scheduleInterviewWith": "Schedule an interview ",
                "interviewType": "Interview Type",
                "jobType": "Jobs",
                "attendees": "Attendees",
                "cancel": "Cancel",
                "modify": "Modify",
                "reject": "Reject",
                "accept": "Accept",
                "hide": "Hide",
                "completed": "Completed",
                "send": "Send",
                "with": "with",
                "reject_reason": "Reject Reason",
                "cancel_reason": "Cancel Reason"
            },
            "interviewTypes": {
                "phone": "Phone interview",
                "in-person": "In person interview",
                "google-hangout": "Google Hangout interview",
                "skype": "Skype interview"
            },
            "questionnaireModule": {
                "yearsOfCatExp": "Years of Experience",
                "selectCatYearsExp": "Please selected the years of experience in this category",
                "readyToBeMatched": "Congratulations, you are ready to be matched with potential employers!",
                "congratsMsg": "Congratulations! You have completed all the required sections of the questionnaire to activate your search on Workland.\r\n<br /><br />\r\nTo see the list of jobs matched with your criteria, please click My Jobs and then Jobs Matched.\r\n<br /><br />\r\nNo matches? Don’t worry, new job offers are posted every week!",
                "employerCongratsMsg": "Congratulations! You have completed all the required sections of the questionnaire to activate your search on Workland.",
                //After clicking the MATCH button below, you will automatically be matched with jobs that fit your criteria. If you want to review your answers one last time, you can do so by pressing the EDIT button.
                "anneesDexperience": "Années d’expérience",
                "selectionnerAnneesDexperience": "Veuillez choisir le nombre d’années d’expérience dans cette catégorie.",
                "pretAEtreMatch": "Félicitations, vous êtes prêt à être jumelé avec des employeurs potentiels!",
                "felicitationsMsg": "Félicitations! Vous avez rempli toutes les sections requises du questionnaire pour activer votre recherche sur Workland.\r\n<br /><br />\r\nPour afficher la liste des tâches correspondant à vos critères, veuillez cliquer sur mes travaux, puis sur tâches appariées.\r\n<br /><br />\r\nAucun résultat? Ne vous inquiétez pas, de nouvelles offres d'emploi sont affichées chaque semaine!",
                "emploiFelicitationsMsg": "Félicitations! Vous avez rempli toutes les sections requises du questionnaire pour activer votre recherche sur Workland."
                //After clicking the MATCH button below, you will automatically be matched with jobs that fit your criteria. If you want to review your answers one last time, you can do so by pressing the EDIT button.
            },
            "candidatesModule": {
                "sourced": "Sourced",
                "applied": "Applied",
                "matches": "Matched",
                "preselected": "Prescreen",
                "interviews": "Interview",
                "referencesRequested": "Reference checks",
                "backcheck": "Backcheck",
                "offered": "Offer",
                "hired": "Hired",
                "rejected": "Rejected",
                "emailed": "Email",
                "notes": "Notes",
                "cv": "CV",
                "stages": "Stages",
                "tagged": "Tag",
                "flagged": "Flag",
                "edited": "Edit",
                "deleted": "Delete",
                "comments": "Comment",
                "dashboard": "History",
                "sendQuestionnaire": "Send Questionnaire",
                "psychometric-test":"Psychometric Test",
                "test": "Test"
            },
            "communicationsModule": {
                "dynamicTags": "Dynamic Tags",
                "candidateName": "Candidate Full Name",
                "contactForJob": "Job Title",
                "jobLink": "Public Job Link",
                "registrationLink": "Registration Link",
                "yourCompanyName": "Company Name",
                "offerOrcontract": "Offer or Contract"
            },
            "candidatesModuleFrench": {
                "sourced": "Potentiels",
                "applied": "Appliqué",
                "matches": "Assorti",
                "preselected": "Présélectionné",
                "interviews": "Entrevue",
                "referencesRequested": "Références",
                "backcheck": "Antécédents",
                "offered": "Offre",
                "hired": "Embauché",
                "rejected": "Rejeté",
                "emailed": "Contacté",
                "notes": "Notes",
                "cv": "CV",
                "stages": "Étapes",
                "tagged": "Étiqueté",
                "flagged": "Marqué",
                "edited": "Édité",
                "deleted": "Supprimé",
                "comments": "Commentaire",
                "history": "Historique",
                "sendQuestionnaire": "Envoyer le questionnaire",
                "test": "Test"
            },
            "candidatesModuleFrenchCRM": {
                "interviews": "Entrevue",
                "emailed": "Courriel",
                "cv": "CV",
                "tagged": "Étiquette",
                "flagged": "Marquer",
                "deleted": "Supprimer",
                "comments": "Commentaire",
                "dashboard": "Historique"
            },
            "referenceModule": {
                "numReferencesRequested": "Number of references requested",
                "awaitingCandidateReponse": "Awaiting candidate response"
            }
        }
    });

	// var wpLocalizeFunctions =
    angular.module( 'wpLocalizeFunctions', [])
	.constant('wpLocalizeFunctions', {
        "translations":
            {"inProgress": "In Progress ..."},
            "lang": "en",
            "worklandNonce":"5191efd7b1",
            "ajaxUrl": window.appConfig.ATLAS_URL + "/wp-admin/admin-ajax.php",
            "themeUrl": window.appConfig.ATLAS_UI_URL
    });


    var app = angular.module( 'shared-components', ['worklandLocalize', 'wpLocalizeFunctions', 'underscore', /*'route' ,*/ 'ui.router', 'ngResource', 'ui.sortable'] );
    app.controller( 'ModalInstanceCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'params',

        function ( $scope, $rootScope, $uibModalInstance, params) {

            function cancel( reason ) {
                params.onCancel( reason );
            }

            function ok() {
                params.onOk( $scope );
            }

            var scope = {
                ok: ok,
                cancel: cancel
            };
            angular.extend( $scope, params, scope );
        }
    ] );

    app.filter( 'slice', function () {
        return function ( arr, start, end ) {
            return arr.slice( start, end );
        };
    } );

} )( angular );