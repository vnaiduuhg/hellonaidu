var INTERVIEW = ( function ( $, sandbox, wp_localize ) {
    var interviews_result = null;
    var interview_modal = null;
    var nonce_code = null;
    var api = {
        reload_interviews: function () {
            if ( wp_localize.user_status === 'employer' ) {
                this.review_interview( 'get_employer_interviews' );
            } else {
                this.review_interview( 'get_candidate_interviews' );
            }
        },
        review_interview: function ( action ) {
            interviews_result.html( 'Loading Interviews' );
            this.ajax( {
                action: action
            }, function ( result ) {
                interviews_result.html( result );
            } );
        },
        update_status: function ( el, new_interview_status ) {
            var btn = $( el );
            var btn_html = btn.html();
            var interview_data = btn.parent().data( 'interview_data' );
            var candidate_skype_name = "";

            btn.attr( "disabled", true ).html( "In Progress ..." );
            sandbox.ajax( {
                action: 'manage_interview',
                data: {
                    interview_id: interview_data.ID,
                    interview_status: new_interview_status,
                    last_modified: interview_data.last_modified,
                    job_id: interview_data.job_id,
                    receiver_id: interview_data.receiver_id,
                    skype_name: candidate_skype_name
                }
            }, function ( result ) {
                if ( result.status === 0 ) {
                    alert( result.message );
                }
                INTERVIEW.reload_interviews()
                btn.attr( "disabled", false ).html( btn_html );
            } );
        },
        modify: function ( el, interview_status ) {

            var btn_main = $( el );
            var modal_ref = sandbox.reset_modal( "#interviewModal", interview_modal );

            // populate modal fields
            var interview_data = btn_main.parent().data( 'interview_data' );

            for ( var id in interview_data ) {
                modal_ref.find( "#" + id ).val( interview_data[id] );
            }

            modal_ref.find( "#date" ).datepicker( {
                minDate: new Date(),
                dateFormat: "yy-mm-dd"
            } );
            modal_ref.find( ".modal-title" ).html( wp_localize.messages.modal_title_m + " " + interview_data.name );
            modal_ref.find( "#photo" ).attr( "src", interview_data.image );

            if ( wp_localize.user_status === 'employer' ) {
                if ( modal_ref.find( "#type" ).val() === 'in-person' ) {
                    modal_ref.find( "#interview_location, #Linterview_location" ).show()
                }
                modal_ref.find( "#type" ).change( function () {
                    if ( $( this ).val() === 'in-person' ) {
                        modal_ref.find( "#interview_location, #Linterview_location" ).show()
                    } else {
                        modal_ref.find( "#interview_location, #Linterview_location" ).hide()
                    }
                } )
            }

            modal_ref.find( "#btn-schedule-interview" ).click( function () {
                var btn = $( this );
                var btn_html = btn.html();
                if ( !$.trim( modal_ref.find( "#date" ).val() ) ) {
                    alert( 'Please enter an interview date' );
                    modal_ref.find( "#date" ).focus();
                    return;
                }
                btn.attr( "disabled", true ).html( "In Progress ..." );

                var data = {
                    interview_id: interview_data.ID,
                    interview_type: modal_ref.find( "#type" ).val(),
                    interview_date: modal_ref.find( "#date" ).val(),
                    interview_starttime: modal_ref.find( "#hour" ).val() + ":" + modal_ref.find( "#min" ).val(),
                    interview_endtime: modal_ref.find( "#end_hour" ).val() + ":" + modal_ref.find( "#end_min" ).val(),
                    interview_status: interview_status,
                    interview_location: $.trim( modal_ref.find( "#interview_location" ).val() ),
                    last_modified: interview_data.last_modified,
                    job_id: interview_data.job_id,
                    receiver_id: interview_data.receiver_id
                };

                sandbox.ajax( {
                    action: "modify_interview",
                    data: data
                },
                        function ( result ) {
                            if ( result.status === 0 ) {
                                alert( result.message );
                            }
                            INTERVIEW.reload_interviews();
                            modal_ref.modal( 'hide' );
                            btn.attr( "disabled", false ).html( btn_html );
                        } );

            } );
            modal_ref.modal( 'show' );
        },
        schedule: function ( job_id, candidate_id, candidate_name, user_photo ) {

            var modal_ref = sandbox.reset_modal( "#interviewModal", interview_modal );

            modal_ref.find( "#date" ).datepicker( {
                minDate: new Date(),
                dateFormat: "yy-mm-dd"
            } );
            modal_ref.find( "#type" ).change( function () {
                if ( $( this ).val() === 'in-person' ) {
                    modal_ref.find( "#interview_location, #Linterview_location" ).show();
                } else {
                    modal_ref.find( "#interview_location, #Linterview_location" ).hide();
                }
            } );

            modal_ref.find( ".modal-title" ).html( wp_localize.messages.modal_title_s + " " + candidate_name );
            modal_ref.find( "#photo" ).attr( "src", user_photo );
            modal_ref.find( "#btn-schedule-interview" ).click( function () {
                var btn = $( this );
                var btn_html = btn.html();
                if ( !$.trim( modal_ref.find( "#date" ).val() ) ) {
                    alert( 'Please enter an interview date' );
                    modal_ref.find( "#date" ).focus();
                    return;
                }
                btn.attr( "disabled", true ).html( "In Progress ..." );

                var data = {
                    candidate_id: candidate_id,
                    job_id: job_id,
                    interview_type: modal_ref.find( "#type" ).val(),
                    interview_date: modal_ref.find( "#date" ).val(),
                    interview_starttime: modal_ref.find( "#hour" ).val() + ":" + modal_ref.find( "#min" ).val(),
                    interview_endtime: modal_ref.find( "#end_hour" ).val() + ":" + modal_ref.find( "#end_min" ).val(),
                    interview_location: $.trim( modal_ref.find( "#interview_location" ).val() ),
                    interview_notes: $.trim( modal_ref.find( "#interview_notes" ).val() )
                };

                sandbox.ajax( {
                    action: "schedule_interview",
                    data: data
                }, function ( result ) {
                    alert( result );
                    btn.attr( "disabled", false ).html( btn_html );
                } );
            } );
            modal_ref.modal( 'show' );
        },
        init: function () {
            interviews_result = $( "#interviews_result" );
            interview_modal = $( '#interviewModal' ).clone();
        }
    }
    return $.extend( {}, sandbox, api );
}( jQuery, WORKLAND, interview_object ) );

jQuery( function () {
    INTERVIEW.init();
} );