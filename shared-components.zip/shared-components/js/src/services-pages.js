$( function () {

    'use strict';

    //#main-slider
    $( '#main-slider .carousel' ).carousel( {
        interval: 8000
    } );

    //#testimonial
    $( '#testimonial .carousel' ).carousel( {
        interval: 8000
    } );


    // jQuery for page scrolling feature - requires jQuery Easing plugin
    $( 'a.page-scroll' ).bind( 'click', function ( event ) {
        var $anchor = $( this );
        $( 'html, body' ).stop().animate( {
            scrollTop: ( $( $anchor.attr( 'href' ) ).offset().top - 60 )
        }, 1250, 'easeInOutExpo' );
        event.preventDefault();
    } );

    //Initiat WOW JS
    new WOW(
            {
                boxClass: 'wow',
                animateClass: 'animated',
                offset: 0
            }
    ).init();
} );
