jQuery( function ( $ ) {
} );
