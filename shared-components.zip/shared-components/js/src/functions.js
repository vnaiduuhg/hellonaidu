// Jquery plugins
( function ( $ ) {
    // https://github.com/hongymagic/jQuery.serializeObject
    $.fn.serializeObject = function () {
        "use strict";

        var result = {};
        var extend = function ( i, element ) {
            var node = result[element.name];

            // If node with same name exists already, need to convert it to an array as it
            // is a multi-value field (i.e., checkboxes)

            if ( 'undefined' !== typeof node && node !== null ) {
                if ( $.isArray( node ) ) {
                    node.push( element.value );
                } else {
                    result[element.name] = [node, element.value];
                }
            } else {
                result[element.name] = element.value;
            }
        };

        $.each( this.serializeArray(), extend );
        return result;
    };

    $.fn.mapObject = function ( obj ) {
        var form = this;
        $.each( obj, function ( k, v ) {
            form.find( "[name='" + k + "']" ).val( v );
        } );
        return form;
    };
    $.fn.clearInputs = function () {
        var form = this;
        form.find( "[name]" ).each( function ( k, v ) {
            var element = $( this );
            element.val( "" );
        } );
        return form;
    };
    $.fn.setBorder = function ( size, type, color ) {
        this.css( {
            "border-color": color,
            "border-width": size,
            "border-style": type
        } );
        return this;
    };

    $.isEmail = function ( email ) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test( email );
    };
    $.hasNoValues = function ( obj ) {
        for ( var key in obj ) {
            if ( obj[key] ) {
                return false;
            }
        }
        return true;
    };

    $.fn.blink = function ( options ) {
        var defaults = {delay: 500};
        options = $.extend( defaults, options );

        return this.each( function () {
            var obj = $( this );
            setInterval( function () {
                if ( $( obj ).css( "visibility" ) === "visible" ) {
                    $( obj ).css( 'visibility', 'hidden' );
                } else {
                    $( obj ).css( 'visibility', 'visible' );
                }
            }, options.delay );
        } );
    };
} )( jQuery );

// Workland Module
var WORKLAND = ( function ( $, wpLocalizeFunctions ) {

    var progressBtnText = wpLocalizeFunctions.translations.inProgress;

    function formSubmitHandler( e ) {
        e.preventDefault();

        var form = $( this );

        // Form's name has to match Wordpress's ajax action name
        var formName = form.attr( "name" );

        // Convert form data to a JS Object
        var data = form.serializeObject();

        var submitBtn = form.find( ":submit" );

        var submitBtnText = submitBtn.text();


        submitBtn.attr( 'disabled', true ).text( progressBtnText );

        // Sending data to server
        var params = {
            action: formName,
            data: data
        };

        var promise = ajax( params );

        // Custom Pub/Sub events for ajax forms
        // https://learn.jquery.com/events/introduction-to-custom-events/
        promise.done( function () {
            form.trigger( 'submitDone', arguments );
        } );


        promise.fail( function () {
            form.trigger( 'submitFail', arguments );
        } );


        promise.always( function () {
            form.trigger( 'submitAlways', arguments );
            submitBtn.attr( 'disabled', false ).text( submitBtnText );
        } );

    }

    function ajax( data, callback ) {
        data.data = JSON.stringify( data.data || {} );
        data.worklandNonce = wpLocalizeFunctions.worklandNonce;

        var params = {
            type: "POST",
            url: wpLocalizeFunctions.ajaxUrl,
            data: data
        };
        var promise = $.ajax( params );

        if ( $.isFunction( callback ) ) {
            promise.done( callback );
        }
        promise.fail( function ( jqXHR ) {
        } );
        return promise;
    }

    function ajaxBtn( button, action, data, callback ) {
        var btn = $( button );
        var btnText = btn.text();

        btn.attr( "disabled", true ).text( progressBtnText );

        var params = {
            action: action,
            data: data
        };

        var promise = ajax( params );

        promise.done( function ( result ) {
            if ( $.isFunction( callback ) ) {
                callback( result, btn );
            }
        } );


        promise.always( function () {
            btn.attr( "disabled", false ).text( btnText );
        } );

        return promise;
    }

    function init() {
        var body = $( "body" );

        body.on( "submit", "form.general_ajax_form", formSubmitHandler );


        var ajaxLogoutButton = $( '#ajaxLogoutButton' );

        ajaxLogoutButton.click( function () {
            var promise = ajaxBtn( this, 'ajax_logout' );

            promise.done( function ( data ) {
                window.location = data.params.redirectTo;
            } );

        } );

        //Code for ajax user login form
        ( function ( $ ) {
            'use strict';

            var ajaxLoginForm = $( '#ajax_login_form' );
            var successAlert = ajaxLoginForm.find( '.alert-success' );
            var failAlert = ajaxLoginForm.find( '.alert-danger' );

            ajaxLoginForm.on( 'submitDone', function ( event, data ) {

                successAlert.hide().removeClass( 'hide' ).fadeIn();

                failAlert.addClass( 'hide' );

                successAlert.text( data.message );

                var redirectTo = data.params ? data.params.redirectTo : null;

                //Send to profile page after a successful login
                if ( redirectTo && window.location.href !== redirectTo ) {
                    window.location = redirectTo;
                }
            } );

            ajaxLoginForm.on( 'submitFail', function ( event, data ) {

                //console.log( data.responseJSON );

                failAlert.hide().removeClass( 'hide' ).fadeIn();
                successAlert.addClass( 'hide' );
                failAlert.text( data.responseJSON.message );
                // Maybe Nonce expired? refresh page to get a new one.
                if ( data.responseJSON.params.worklandNonceInvalid ) {
                    window.location.reload();
                }
            } );

        } )( $ );

        // Code for adding google map to contact form
        ( function ( $ ) {
            $( '#modalContact' ).on( 'shown.bs.modal',
                    function () {
                        $( this )
                                .find( "#the_map" )
                                .html( '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.6712513655493!2d-73.5537044!3d45.4965645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc91af509f3cdbd%3A0x83c743fa467dd875!2s33+Rue+Prince%2C+Montr%C3%A9al%2C+QC+H3C+2M7!5e0!3m2!1sen!2sca!4v1434650167171" style="width:100%;height:200px; border:0" frameborder="0"></iframe>' );
                    }
            );
        } )( $ );

    }

    var api = {
        ajax: ajax,
        ajaxBtn: ajaxBtn,
        init: init,
        reset_modal: function ( modal_ref, original_ref ) {
            $( modal_ref ).remove();
            $( "body" ).append( original_ref.clone() );
            return $( modal_ref );
        }
    };

    return api;

} )( jQuery, wpLocalizeFunctions || {} );

// Fire Workland's init when page is finished loading
jQuery( WORKLAND.init );

( function ( $ ) {

    $( document ).bind( 'gform_post_render', function ( event, form_id, current_page ) {
        if ( form_id === 3 ) {
            $( '.watermark input, .watermark textarea' ).focus( function () {
                $( this ).parent().prev( '.watermark label' ).fadeOut( 'fast' );
            } );
            $( '.watermark label' ).click( function () {
                $( this ).fadeOut( 'fast' );
                $( this ).next( '.watermark input' ).focus();
            } );
            $( '.watermark input' ).blur( function () {
                var inputValue = $( this ).val();
                if ( inputValue === '' ) {
                    $( this ).parent().prev( '.watermark label' ).fadeIn( 'fast' );
                } else {
                    $( this ).parent().prev( '.watermark label' ).hide();
                }
            } );
            $( '.watermark input, .watermark textarea' ).each( function () {
                var inputValue = $( this ).val();
                $( this ).attr( 'autocomplete', 'off' );
                if ( inputValue === '' ) {
                    $( this ).parent().prev( '.watermark label' ).show();
                } else {
                    $( this ).parent().prev( '.watermark label' ).hide();
                }
            } );
            $( '.watermarkpass .ginput_complex input' ).focus( function () {
                $( this ).next( '.watermarkpass .ginput_complex label' ).fadeOut( 'fast' );
            } );
            $( '.watermarkpass .ginput_complex label' ).click( function () {
                $( this ).fadeOut( 'fast' );
                $( this ).prev( '.watermarkpass .ginput_complex input' ).focus();
            } );
            $( '.watermarkpass .ginput_complex input' ).blur( function () {
                var inputValue = $( this ).val();
                if ( inputValue === '' ) {
                    $( this ).next( '.watermarkpass .ginput_complex label' ).fadeIn( 'fast' );
                } else {
                    $( this ).next( '.watermarkpass .ginput_complex label' ).hide();
                }
            } );
            $( '.watermarkpass .ginput_complex input' ).each( function () {
                var inputValue = $( this ).val();
                $( this ).attr( 'autocomplete', 'off' );
                if ( inputValue === '' ) {
                    $( this ).next( '.watermarkpass .ginput_complex label' ).show();
                } else {
                    $( this ).next( '.watermarkpass .ginput_complex label' ).hide();
                }
            } );
        }
    } );
} )( jQuery );

function reset_modal( modal_ref, original_ref ) {
    jQuery( modal_ref ).remove();
    jQuery( "body" ).append( original_ref.clone() );
}
