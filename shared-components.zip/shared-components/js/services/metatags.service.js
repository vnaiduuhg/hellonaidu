(function (angular) {

    'use strict';

    var app = angular.module('shared-components');

    app.factory('Meta', metaFactory);

    metaFactory.$inject = ['$resource'];

    function metaFactory($resource) {

        return $resource('./../shared-components/json/:urlName.json', {urlName: 'urlName'}, {
            query: {
                method: 'GET',
                params: {},
                isArray: true
            }
        });
    }

    app.service('MetaTagsService', ['Meta', '$transitions', '$state', 'api', function (Meta, $transitions, $state, api) {

            var service = this;
            var defaultTags = {};
            var tagElements = [];
            service.getMetatags = getMetatags;
            service.magageTransitions = magageTransitions;
            service.getDynamicMetatags = getDynamicMetatags;
            service.getJson = getJson;
            service.setTags = setTags;
            service.setJsonToScriptTag = setJsonToScriptTag;
            service.setDefaultTags = setDefaultTags;

            function setDefaultTags(tags){
                angular.copy(tags, defaultTags);
                setTags({}); 
                //list of default tags, can not inject MetaTagsService on run into ui-atlas-routes to generate these tags. 
                //it slowed down execution of pages and caused problems with generating cookies for EQ page
                /*
                "og:url" : "https://atlas.workland.com/",
                "og:title" : "Workland",
                "og:description" : "ATLAS is an A.I. powered recruitment software that allows the precise “match” between job seekers and employers to help you recruit more efficiently!",       
                "og:image" : "./../assets/images/workland-banner.jpg"
                */
            }

            function magageTransitions() {

                var deregisterFns = [];
                deregisterFns.push($transitions.onEnter({}, function (transition) {
                    // any code to occur bwhen there is a transition
                }));
                return deregisterFns;
            }

            function getMetatags(stateName, id) {
                if (stateName == 'jobsDescription') {

                }
                var urlName = {
                    'urlName': stateName
                };

                Meta.query(urlName).$promise.then(function (response) {
                    setTags(response[0]);
                });
            }

            function getDynamicMetatags(Obj) {
                var metasObj = {
                    "og:image:height" : "340",
                    "og:image:width" : "680",
                    "og:image": Obj.metaImage,                    
                    "description": Obj.metaDescription,
                    "og:description": Obj.metaDescription,
                    "title": Obj.metaTitle,
                    "og:title": Obj.metaTitle,
                    "og:url": Obj.metaUrl,
                }
                setTags(metasObj);
            }

            function setJsonToScriptTag(id, jsonData){
                var tag = document.getElementById(id);
                tag.innerText = JSON.stringify(jsonData);
            }

            function setTags(tags) {
                clearTags();
                mergeDefaultTags(tags);
                angular.forEach(tags, function(content, name){
                  var tagElement = getTagElement(content, name);
                  document.head.insertBefore(tagElement, document.head.childNodes[0]);
                  tagElements.push(tagElement); 
                });
            }

            function mergeDefaultTags(tags){
                angular.forEach(defaultTags, function(defaultTagContent, defaultTagName){
                  if(!tags[defaultTagName]){
                    tags[defaultTagName] = defaultTagContent;
                  } else if(defaultTagName === 'title'){
                    tags['title'] += ' - '+defaultTagContent;
                  }
                }); 
                return tags;
              }
            
            function getTagElement(content, name) {
                if(name == 'title'){
                  // Special provision for the title element
                  var title = document.createElement('title');
                  title.textContent = content;
                  return title;
                } else {
                  // Opengraph uses [property], but everything else uses [name]
                  var nameAttr = (name.indexOf('og:') === 0) ? 'property' : 'name';
                  var meta = document.createElement('meta');
                  meta.setAttribute(nameAttr, name);
                  meta.setAttribute('content', content);
                  return meta;
                }
            }

            function clearTags() {
                angular.forEach(tagElements, function(tagElement){
                  document.head.removeChild(tagElement);
                });
                tagElements.length = 0;                             
            }

            function getJson(name) {

                var urlName = {
                    'urlName': name
                };

                Meta.query(urlName).$promise.then(function (response) {
                    return response;
                });
            }

        }]);


})(angular);