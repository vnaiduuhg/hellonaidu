(function (angular) {

    'use strict';

    angular.module('shared-components')
            .service('authService', authService);


    authService.$inject = ['$q', '$http', '$rootScope', '$window', '$state', 'storageService', '$location'];

    function authService($q, $http, $rootScope, $window, $state, storageService, $location) {
        return {
            find: function (data) {
                return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/accounts/find', data);
            },
            registerCandidate: function (data) {
                return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/accounts/candidates', data);
            },
            invite: function (accountId, data) {
                return this.getToken().then(token => {
                        return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + `api/v1/accounts/${accountId}/invitation`, data, {
                            headers: {
                                "Authorization": "Bearer " + token
                            }
                        });
                    },
                    err => {
                        return err
                    }
                )
            },
            key: function (data) {
                return genericPostCall(`${$window.appConfig.USER_ACCOUNTS_URL}api/v1/accounts/parse-invitation-key/${data.key}`);
            },
            getActivationKey: function (accountId, data) {
                return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/accounts/candidates/'+accountId+'/activation-link', data, {}, 'update');
            },
            login: function (data) {
                return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/auth/login', data);
            },
            parseJwt: function (token) {
                var base64Url = token.split('.')[1];
                var base64 = base64Url.replace('-', '+').replace('_', '/');
                return JSON.parse($window.atob(base64));
            },
            saveToken: function (token) {
                storageService.setCookie('jwtToken', token);
            },
            getToken: function () {
                const token = storageService.getCookieByName('jwtToken');
                if (token){
                    const tokenParsed = this.parseJwt(token);
                    if (+tokenParsed.exp*1000 > new Date().getTime() + 5*60*1000) {
                        return $q.when(token);
                    }
                    var url = $window.appConfig.USER_ACCOUNTS_URL + 'api/v1/auth/refresh';
                    var accountId = storageService.getItem('account_id');

                    return $http.post(url, {account_id: accountId}, {headers:{"Authorization": "Bearer " + token}}).then(
                        response => {
                            if (response.data.data.token){
                                this.saveToken(response.data.data.token);
                                return token;
                            }
                            this.clearSessionData();
                            this.redirectToLogin('token has been refreshed, but is not successfull - on response');
                            return null;
                        },
                        err => {
                            this.clearSessionData();
                            this.redirectToLogin('token has been refreshed, but is not successfull - on error');
                            return null;
                        }
                    );
                }
                this.clearSessionData();
                this.redirectToLogin('kicked out when token could not be fetched from storage');
                return $q.when(null);
            },
            isAuthed: function () {
                const token = storageService.getCookieByName('jwtToken');
                if (token){
                    const tokenParsed = this.parseJwt(token);
                    return new Date().getTime() <= +tokenParsed.exp*1000;
                }
                return false;
            },
            refreshToken: function (account_id, authenticationMethod = null) {
                const acc_id = account_id ? account_id : storageService.getItem('account_id');
                const data = {
                    account_id: acc_id
                };
                if (authenticationMethod) data.authentication_method = authenticationMethod;
                const token = storageService.getCookieByName('jwtToken');
                return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/auth/refresh', data, {
                    headers: {
                        "Authorization": "Bearer " + token
                    }
                });
            },
            logout: function (keepStorage = false) {
                return this.getToken().then(
                    token => {
                        var promise = genericGetCall($window.appConfig.USER_ACCOUNTS_URL + 'api/v1/auth/logout', {
                            headers: {
                                "Authorization": "Bearer " + token,
                                "Content-Type": undefined
                            }
                        });
                        this.clearSessionData();
                        if (!keepStorage) {
                            $rootScope.isPageLoaded = "";
                            $rootScope.agencyId = "";
                            $rootScope.openPanel = "";
                            storageService.removeItem('jobIdClicked');
                            storageService.removeItem('url');
                            storageService.removeItem('source');
                            storageService.removeItem('duplicate_job');
                            storageService.removeItem('email_type');
                            storageService.removeItem('redirect_to');
                            storageService.removeCookieByName('jobsListPage');
                            storageService.removeCookieByName('jobTitleSearch');
                            storageService.removeCookieByName('locationSearch');
                            storageService.removeCookieByName('companySearch');
                        }
                        return promise;
                    },
                    err => {
                        return err
                    }
                )
            },
            clearSessionData: function () {
                storageService.removeCookieByName('jwtToken');
                storageService.removeCookieByName('microsoftToken');
                storageService.removeCookieByName('atlasMicrosoftToken');
                storageService.removeCookieByName('provider');
                $rootScope.currentUser = null;
                $rootScope.account_role = null;
                $rootScope.account_type = null;
                $rootScope.userId = null;
                $rootScope.account_id = null;
                storageService.removeItem('user_email');
                storageService.removeItem('userId');
                storageService.removeItem('accounts');
                storageService.removeItem('account_type');
                storageService.removeItem('account_id');
                storageService.removeItem('account_role');
                storageService.removeItem("sync_email_type");
                storageService.removeItem("sync_type");
                storageService.removeItem("email_to_sync");
                storageService.removeItem("name_to_sync");
                storageService.removeItem("callbackFromSocialLogin");
                window.removeEventListener('storage', $rootScope.storageEvent);
                delete $rootScope.storageEvent;
            },
            redirectToLogin: function (msg) {
              const regExp = /(\/jobs|\/work|\/career|\/job\-apply)/g;
              const excludedStates = ['home', 'jobsList', 'companyDescription', 'jobsDescription', 'loginPage', 'registrationPage',
                'accounts', 'agencyPackages', 'theagencyPackages', 'paymentGateway', 'reference', 'referee',
                'jobApply', 'jobAppliedSuccess', 'registration', 'recruiterRegistration', 'passwordReset', 'passwordChange',
                'accountActivationReset', 'unsubscribe'];
              if (
                // If the current state name exists and is not in the excluded states array,
                $state.current.name && !['', ...excludedStates].includes($state.current.name)
                // OR if the current state name does not exist and the current URL path does not match the regular expression
                || !$state.current.name && !regExp.test($location.$$path)
              ) {
                if ($rootScope.agencyIframe) {
                  location.href = '?iframe=true';
                } else {
                  $state.go('home');
                }
              }
            },
            isFirstLogin: function (id) {
                return this.getToken().then(
                    token => {
                        return genericGetCall($window.appConfig.USER_ACCOUNTS_URL + "api/v1/member-first-login/" + id, {
                            headers: {
                                "Authentication": token
                            }
                        });
                    },
                    err => {
                        return err
                    }
                )
            },
            changeFirstLoginStatus: function (id) {
                return this.getToken().then(
                    token => {
                        return genericGetCall($window.appConfig.USER_ACCOUNTS_URL + "api/v1/change-member-first-login/" + id, {
                            headers: {
                                "Authentication": token
                            }
                        });
                    },
                    err => {
                        return err
                    }
                )
            },
            resetPassword: function (data) {
                return this.getToken().then(
                    token => {
                        return genericPostCall($window.appConfig.USER_ACCOUNTS_URL + "api/v1/users/update-password", data, {
                            headers: {
                                "Authorization": "Bearer " + token
                            }
                        });
                    },
                    err => {
                        return err
                    }
                )
            },
        };

        function genericPostCall(url, data, config = {}, update) {
            var defer = $q.defer();
            if (update) {
                $http.put(url, data, config).then(function (res) {
                    defer.resolve(res);
                }, function (err) {
                    defer.reject(err);
                });
            } else {
                $http.post(url, data, config).then(function (res) {
                    defer.resolve(res);
                }, function (err) {
                    defer.reject(err);
                });
            }
            return defer.promise;
        }
        function genericGetCall(url, config = {}) {
            var defer = $q.defer();
            $http.get(url, config).then(function (res) {
                defer.resolve(res);
            }, function (err) {
                defer.reject(err);
            });
            return defer.promise;
        }
    }
})(angular);
