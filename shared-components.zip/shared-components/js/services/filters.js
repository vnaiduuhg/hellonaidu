( function ( angular ) {

    'use strict';
    var app = angular.module( 'shared-components' );

    //https://gist.github.com/jeffjohnson9046/9789876
    app.filter( 'titlecase', function () {
        return function ( input ) {
            var smallWords = /^(a|an|and|as|at|but|by|en|for|if|in|nor|of|on|or|per|the|to|vs?\.?|via)$/i;

            input = input.toLowerCase();
            return input.replace( /[A-Za-z0-9\u00C0-\u00FF]+[^\s-]*/g, function ( match, index, title ) {
                if ( index > 0 && index + match.length !== title.length &&
                        match.search( smallWords ) > -1 && title.charAt( index - 2 ) !== ":" &&
                        ( title.charAt( index + match.length ) !== '-' || title.charAt( index - 1 ) === '-' ) &&
                        title.charAt( index - 1 ).search( /[^\s-]/ ) < 0 ) {
                    return match.toLowerCase();
                }

                if ( match.substr( 1 ).search( /[A-Z]|\../ ) > -1 ) {
                    return match;
                }

                return match.charAt( 0 ).toUpperCase() + match.substr( 1 );
            } );
        }
    } );
    
        
    /**
    * Filters out all duplicate items from an array by checking the specified key
    * @param [key] {string} the name of the attribute of each object to compare for uniqueness
    if the key is empty, the entire object will be compared
    if the key === false then no filtering will be performed
    * @return {array}
    */
   app.filter('unique', function () {

     return function (items, filterOn) {

       if (filterOn === false) {
         return items;
       }

       if ((filterOn || angular.isUndefined(filterOn)) && angular.isArray(items)) {
         var hashCheck = {}, newItems = [];

         var extractValueToCompare = function (item) {
           if (angular.isObject(item) && angular.isString(filterOn)) {
             return item[filterOn];
           } else {
             return item;
           }
         };

         angular.forEach(items, function (item) {
           var valueToCheck, isDuplicate = false;

           for (var i = 0; i < newItems.length; i++) {
             if (angular.equals(extractValueToCompare(newItems[i]), extractValueToCompare(item))) {
               isDuplicate = true;
               break;
             }
           }
           if (!isDuplicate) {
             newItems.push(item);
           }

         });
         items = newItems;
       }
       return items;
     };
   });
   
    app.filter('ceil', function() {
        return function(input) {
            return Math.ceil(input);
        };
    });

  /**
   * @ngdoc filter
   * @name groupBy
   * @kind function
   *
   * @description
   * Create an object composed of keys generated from the result of running each element of a collection,
   * each key is an array of the elements.
   *@from https://github.com/a8m/angular-filter
   */
  app.filter('groupBy', [ '$parse', 'filterWatcher', function ( $parse, filterWatcher ) {
    return function (collection, property) {

      if(!angular.isObject(collection) || angular.isUndefined(property)) {
        return collection;
      }

      return filterWatcher.isMemoized('groupBy', arguments) ||
        filterWatcher.memoize('groupBy', arguments, this,
          _groupBy(collection, $parse(property)));

      /**
       * groupBy function
       * @param collection
       * @param getter
       * @returns {{}}
       */
      function _groupBy(collection, getter) {
        var result = {};
        var prop;

        angular.forEach( collection, function( elm ) {
          prop = getter(elm);

          if(!result[prop]) {
            result[prop] = [];
          }
          result[prop].push(elm);
        });
        return result;
      }
    }
  }]);

  app.provider('filterWatcher', function() {

    this.$get = ['$window', '$rootScope', function($window, $rootScope) {

      /**
       * Cache storing
       * @type {Object}
       */
      var $$cache = {};

      /**
       * Scope listeners container
       * scope.$destroy => remove all cache keys
       * bind to current scope.
       * @type {Object}
       */
      var $$listeners = {};

      /**
       * $timeout without triggering the digest cycle
       * @type {function}
       */
      var $$timeout = $window.setTimeout;

      /**
       * @description
       * get `HashKey` string based on the given arguments.
       * @param fName
       * @param args
       * @returns {string}
       */
      function getHashKey(fName, args) {
        function replacerFactory() {
          var cache = [];
          return function(key, val) {
            if(angular.isObject(val) && !isNull(val)) {
              if (~cache.indexOf(val)) return '[Circular]';
              cache.push(val)
            }
            if($window == val) return '$WINDOW';
            if($window.document == val) return '$DOCUMENT';
            if(isScope(val)) return '$SCOPE';
            return val;
          }
        }
        return [fName, JSON.stringify(args, replacerFactory())]
          .join('#')
          .replace(/"/g,'');
      }

      /**
       * @description
       * fir on $scope.$destroy,
       * remove cache based scope from `$$cache`,
       * and remove itself from `$$listeners`
       * @param event
       */
      function removeCache(event) {
        var id = event.targetScope.$id;
        angular.forEach($$listeners[id], function(key) {
          delete $$cache[key];
        });
        delete $$listeners[id];
      }

      /**
       * @description
       * for angular version that greater than v.1.3.0
       * it clear cache when the digest cycle is end.
       */
      function cleanStateless() {
        $$timeout(function() {
          if(!$rootScope.$$phase)
            $$cache = {};
        }, 2000);
      }

      /**
       * @description
       * Store hashKeys in $$listeners container
       * on scope.$destroy, remove them all(bind an event).
       * @param scope
       * @param hashKey
       * @returns {*}
       */
      function addListener(scope, hashKey) {
        var id = scope.$id;
        if(angular.isUndefined($$listeners[id])) {
          scope.$on('$destroy', removeCache);
          $$listeners[id] = [];
        }
        return $$listeners[id].push(hashKey);
      }

      /**
       * @description
       * return the `cacheKey` or undefined.
       * @param filterName
       * @param args
       * @returns {*}
       */
      function $$isMemoized(filterName, args) {
        var hashKey = getHashKey(filterName, args);
        return $$cache[hashKey];
      }

      /**
       * @description
       * store `result` in `$$cache` container, based on the hashKey.
       * add $destroy listener and return result
       * @param filterName
       * @param args
       * @param scope
       * @param result
       * @returns {*}
       */
      function $$memoize(filterName, args, scope, result) {
        var hashKey = getHashKey(filterName, args);
        //store result in `$$cache` container
        $$cache[hashKey] = result;
        // for angular versions that less than 1.3
        // add to `$destroy` listener, a cleaner callback
        if(isScope(scope)) {
          angular.addListener(scope, hashKey);
        } else {
          cleanStateless();
        }
        return result;
      }

      return {
        isMemoized: $$isMemoized,
        memoize: $$memoize
      }
    }];
  })
  /**
   * @description
   * Test if given object is a Scope instance
   * @param obj
   * @returns {Boolean}
   */
  function isScope(obj) {
    return obj && obj.$evalAsync && obj.$watch;
  }

  function isNull(value) {
      return value === null;
  }

} )( angular );