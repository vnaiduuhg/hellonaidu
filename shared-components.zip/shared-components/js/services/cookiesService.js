( function ( angular ) {

    'use strict'; 

    angular.module('shared-components')
    .service('cookiesService', ['$cookies', function($cookies) {
        return {
            setItem: function(key, value){
                this.setCookie(key, value);
            },
            setSessionItem: function(key, value) {
                this.setCookie(key, value);
            },
            setCookie: function (key, value) {
                if (window.appConfig.APP_ENV == 'local') {
                    document.cookie = key + "=" + value + ";path=/";
                } else {
                    document.cookie = key + "=" + value + ";path=/;SameSite=None;Secure";
                }
            },
            getItem: function(key){
                return $cookies.get(key);
            },
            getSessionItem: function(key){
                return this.getItem(key);
            },
            removeItem: function(key){
                $cookies.remove(key);
            },
            removeSessionItem: function(key){
                this.removeItem(key);
            },
            getCookieByName: function(name) {
                return document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')?.pop() || null;
            },
            removeCookieByName: function(name) {
                document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            }
        };
    }]);

})(angular);
