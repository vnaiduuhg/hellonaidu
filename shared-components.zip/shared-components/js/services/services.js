( function ( angular ) {

    'use strict';

    var app = angular.module( 'shared-components' );

    app.factory( 'CRUDHelper', function () {

        function editEntry( item, box, close ) {
            var CRUD = this.CRUD;
            CRUD.formModel[box.key] = close ? {} : angular.copy( item );
            if ( close ) {
                CRUD.formTab[box.key].list = true;
                CRUD.forms[box.key].$setPristine();
            } else {
                CRUD.formTab[box.key].update = true;
            }
        }

        function editEntryFR( item, box, close ) {
            var CRUD = this.CRUD;
            CRUD.formModel[box.key+'FR'] = close ? {} : angular.copy( item );
            if ( close ) {
                CRUD.formTab[box.key+'FR'].list = true;
                CRUD.forms[box.key].$setPristine();
            } else {
                CRUD.formTab[box.key+'FR'].update = true;
            }
        }

        function updateEntry( box ) {
            var $scope = this;
            var item = $scope.CRUD.formModel[box.key];
            var promise = box.collection.update( item );
            promise.then( function () {
                // reset from model and close update tab
                editEntry.call( $scope, item, box, true );
            } );
            return promise;
        }

        function updateEntryFR( box ) {
            var $scope = this;
            var item = $scope.CRUD.formModel[box.key+'FR'];
            var promise = box.collectionFR.update( item );
            promise.then( function () {
                // reset from model and close update tab
                editEntryFR.call( $scope, item, box, true );
            } );
            return promise;
        }


        function extendScope( $scope ) {
            var extendWith = {
                CRUD: {
                    forms: {},
                    formModel: {},
                    formTab: {},
                    updateEntry: updateEntry.bind( $scope ),
                    editEntry: editEntry.bind( $scope ),
                    updateEntryFR: updateEntryFR.bind( $scope ),
                    editEntryFR: editEntryFR.bind( $scope )
                }
            };
            angular.extend( $scope, extendWith );
        }

        var obj = {
            extendScope: extendScope
        };

        return obj;
    } );

    app.factory( 'referencesQuestions', ['utils', function ( utils ) {
            var obj = {},
                    out = utils.out,
                    referencesQuestions = [{
                            key: 'q2',
                            quesTxt: function ( reference ) {
                                return out( 'Donnez un bref aperçu des rôles et responsabilités de ' +
                                        reference.userfullname + 'au sein de ' + reference.company,
                                        'Give a brief overview of ' +
                                        reference.userfullname + "'s responsibilities at " + reference.company ) + '?';
                            },
                            label: 'Q1'
                        }, {
                            key: 'q3',
                            quesTxt: function ( reference ) {
                                return out( 'Comment décririez-vous  ' +
                                        reference.userfullname,
                                        'How would you describe ' +
                                        reference.userfullname ) + '?';
                            },
                            label: 'Q2'
                        }, {
                            key: 'q4',
                            quesTxt: function ( reference ) {
                                return out(
                                        "Quelles étaient les plus grandes réalisations de " +
                                        reference.userfullname + ' chez ' + reference.company,
                                        'What were ' +
                                        reference.userfullname + "'s top accomplishments at " +
                                        reference.company
                                        ) + '?';
                            },
                            label: 'Q3'
                        }, {
                            key: 'q5',
                            quesTxt: function ( reference ) {
                                return out( "Comment décririez-vous l'expérience de " +
                                        reference.userfullname + ' pour ce qui est du travail d’équipe',
                                        'How would you describe ' +
                                        reference.userfullname + "'s experience regarding team work" ) + '?';
                            },
                            label: 'Q4'
                        }, {
                            key: 'q6',
                            quesTxt: function ( reference ) {
                                return out( 'À votre avis, quels sont les 3 plus grandes forces de ' +
                                        reference.userfullname,
                                        'In your opinion, what are ' +
                                        reference.userfullname + "'s top 3 strengths" ) + '?';
                            },
                            label: 'Q5'
                        }];

            obj.questions = referencesQuestions;

            return obj;
        }] );


    app.factory('Pager', function() {
        // service definition
        var service = {};
        service.GetPager = GetPager;
        return service;

        // service implementation
        function GetPager(totalItems, currentPage, pageSize, small) {
            // default to first page
            currentPage = currentPage || 1;

            // default page size is 10
            pageSize = pageSize || 10;

            // calculate total pages
            var totalPages = Math.ceil(totalItems / pageSize);
            (totalPages == 0 ? totalPages = 1 : totalPages = totalPages);

            var startPage, endPage;
            if(small) {
                if (totalPages <= 3) {
                    // less than 3 total pages so show all
                    startPage = 1;
                    endPage = totalPages;
                } else {
                    // more than 3 total pages so calculate start and end pages
                    if (currentPage <= 2) {
                        startPage = 1;
                        endPage = 3;
                    } else if (currentPage + 1 >= totalPages) {
                        startPage = totalPages - 2;
                        endPage = totalPages;
                    } else {
                        startPage = currentPage - 1;
                        endPage = currentPage + 1;
                    }
                }
            } else {
                if (totalPages <= 10) {
                    // less than 10 total pages so show all
                    startPage = 1;
                    endPage = totalPages;
                } else {
                    // more than 10 total pages so calculate start and end pages
                    if (currentPage <= 6) {
                        startPage = 1;
                        endPage = 10;
                    } else if (currentPage + 4 >= totalPages) {
                        startPage = totalPages - 9;
                        endPage = totalPages;
                    } else {
                        startPage = currentPage - 5;
                        endPage = currentPage + 4;
                    }
                }
            }

            // calculate start and end item indexes
            var startIndex = (currentPage - 1) * pageSize;
            var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

            // create an array of pages to ng-repeat in the pager control
            var pages = _.range(startPage, endPage + 1);

            // return object with all pager properties required by the view
            return {
                totalItems: totalItems,
                currentPage: currentPage,
                pageSize: pageSize,
                totalPages: totalPages,
                startPage: startPage,
                endPage: endPage,
                startIndex: startIndex,
                endIndex: endIndex,
                pages: pages
            };
        }
    });

    app.service( "Event", ['$rootScope', function ( $rootScope ) {
            this.broadcast = function ( eventName, args ) {
                $rootScope.$broadcast( eventName, args );
            };
            this.on = function ( eventName, callback ) {
                $rootScope.$on( eventName, callback );
            };
        }] );

    app.service( "WLEvent", ['$rootScope', function ( $rootScope ) {
            this.send = function ( eventName, args ) {
                $rootScope.$broadcast( eventName, args );
            };
            this.receive = function ( eventName, callback ) {
                $rootScope.$on( eventName, callback );
            };
        }] );

    app.service('AsyncService', ['$q', function($q) {
      return {
        loadDataFromApis: function(promises) {
            var deferred = $q.defer();
            const all = $q.all(promises).then(function(data){
                return data.filter(function(d){return !!d}) // filter out empty, null results
            });
            all.then(function(data){              
              deferred.resolve(data);
            }).catch(function(error){             
              deferred.reject(error);
            })      
            return deferred.promise;
        }
      };
    }] );

} )( angular );