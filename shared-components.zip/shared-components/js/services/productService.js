(function (angular) {
  function productService($q, $http, $rootScope, $cookies, $window, $state, $timeout, authService) {
    const apiUrl = `${$window.appConfig.MARKETPLACE_URL}api/v1/`;
    const obj = {
      getProductsByAccountHash,
      getProductByProductId,
      getProductsByAccountId,
      getAllProducts,
    };
    return obj;

    function genericGetCall(url) {
      const defer = $q.defer();
      const route = apiUrl + url;
      return authService.getToken().then(
        (token) => {
          const headers = {};
          if (token) {
            headers.authentication = token;
          }
          $http.get(route, headers).then((res) => {
            defer.resolve(res);
          }, (err) => {
            defer.reject(err);
          });
          return defer.promise;
        },
        (err) => err,
      );
    }

    function getProductsByAccountHash(hashVal) {
      const url = `hash/${hashVal.agency_hash}/products`;
      return genericGetCall(url);
    }

    function getProductByProductId(id) {
      const url = `product/${id}`;
      return genericGetCall(url);
    }

    function getProductsByAccountId(accountId) {
      const url = `account/${accountId}/products`;
      return genericGetCall(url);
    }

    function getAllProducts() {
      const url = 'products';
      return genericGetCall(url);
    }
  }

  productService.$inject = ['$q', '$http', '$rootScope', '$cookies', '$window', '$state', '$timeout', 'authService'];

  angular.module('shared-components')
    .service('productService', productService);
}(angular));
