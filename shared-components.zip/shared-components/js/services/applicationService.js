( function ( angular ) {
'use strict';

    angular.module('shared-components')
    .service('applicationService', applicationService);


    applicationService.$inject = ['$q', '$http', '$window', '$cookies', 'authService'];

	function applicationService($q, $http, $window, $cookies, authService) {

        var url_base = $window.appConfig.APPLICATION_URL + 'api/v1/';
        var obj = {
            get_query_with_auth: get_query_with_auth,
            post_query: post_query,
            patch_query: patch_query,
            applicationFileUpload: applicationFileUpload,
        }
        return obj;

        function get_query_with_auth(path){
          
            var defer = $q.defer();
            var url = url_base + path;
            return authService.getToken().then(
                token => {
                    $http.get(url, {
                        headers : {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Authentication': token
                        }
                    }).then(function(res) {
                        defer.resolve(res);
                    }, function(err){
                        defer.resolve(err);
                    });
                    return defer.promise;
                }, 
                error => {
                    return error
                }
            )
            
            
        }
   
        function post_query(path, obj){

            var defer = $q.defer();
            var url = url_base + path;
            var data = angular.toJson(obj);

            $http.post(url, data, {
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function(res) {
                defer.resolve(res);
            }, function(err){
                defer.resolve(err);
            });
            return defer.promise;
        }

        function patch_query(path, id, value, obj){

            var defer = $q.defer();
            var url = url_base + path + '/' + id + '/' + value;

            var body = obj ? obj : null;
            var data = body ? angular.toJson(body) : null;

            $http.patch(url, data, {
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function(res) {
                defer.resolve(res);
            }, function(err){
                defer.resolve(err);
            });
            return defer.promise;
        }

        function applicationFileUpload(path, data) {
          return authService.getToken().then(
            (token) => {
              const url = url_base + path;

              const formData = new FormData();
              angular.forEach(data, (value, key) => {
                formData.append(key, value);
              });

              const config = {
                headers: {
                  'Content-Type': undefined,
                  Accept: 'application/json',
                },
              };
              if (token) {
                config.headers.authentication = token;
              }
              return $http.post(url, formData, config);
            },
          );
        }
    }

})(angular);