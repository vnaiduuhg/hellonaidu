( function ( angular ) {

    'use strict';

    var app = angular.module( 'shared-components' );

    app.factory('GetJson', getJsonFactory);

    getJsonFactory.$inject = ['$resource'];

    function getJsonFactory( $resource ) {
        
        return $resource('./../shared-components/json/:urlName.json', {urlName: 'urlName'}, {  
            query: {
                method: 'GET',
                params: {},
                timeout: 4000
            }
        }); 
    }

    app.service( 'GetJsonService', ['GetJson', '$rootScope', function(GetJson, $rootScope) {
        
        var service = this;
        service.getJsonData = getJsonData;
        service.getJson = getJson;

        function getJsonData(name) {
            var urlName = {
                'urlName': name
            };
          
            return GetJson.query(urlName).$promise.then(function (response) {
                response.status = 'success';
                return response;
            });
        }

        function getJson(name) {
            return      {
                "status": "ok",
                "data": {
                    "sections": [
                        {
                            "sectionId": "40f6f9c5-761c-449d-a0c6-9d9b99480cca",
                            "questions": [
                                {
                                    "questionId": "427ddfaf-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.307Z",
                                    "updated_at": "2017-01-11T12:11:23.622Z",
                                    "REPONSE": "00999999999999999999099999999",
                                    "answered": true,
                                    "algo": "algo_ExperienceEtInterets",
                                    "controlType": "cote09",
                                    "choiceType": "multiple",
                                    "nbChoices": 29,
                                    "maxChoices": 29,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Finance & Accounting",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Administration",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Quality Assurance",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Construction & skilled labour",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Media & Entertainment",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Law & Legal Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Education & Training",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Retail",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Manufacturing",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Brand & Product Management",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Project Management",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 11,
                                            "value": "General Management",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Purchasing ",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Editing & Printing",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Engineering",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Order & security",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Food & Food Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Insurance",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 18,
                                            "value": "Science and R&D",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 19,
                                            "value": "Health",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 20,
                                            "value": "Financial Services",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Consumer Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Programming & Development",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Human Resources",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Information Technology",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 25,
                                            "value": "Marketing & Innovation",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Sales & Business Development",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Distribution & Transport",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Supply Chain Management & Logistics",
                                            "selected": "9"
                                        }
                                    ],
                                    "nbSelected": 26,
                                    "bAnswered": true,
                                    "question": "Please select up to 3 employment categories that you would like to work in.\n<br></br>\n<br></br>\n<i>For every category selected, please indicate if you have experience in that field by identifying the number of years.</i>",
                                    "qNumber": 1,
                                    "title": "Employment Categories"
                                },
                                {
                                    "questionId": "427de2df-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.622Z",
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "REPONSE": "1000",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 4,
                                    "maxChoices": 4,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Full-time",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Part-time",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Contractual Position",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Internship",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "What position type(s) are you seeking? \n<br></br>\n<br></br>\n<i>Select ALL the ones that apply:</i>",
                                    "qNumber": 2,
                                    "title": "Position Type"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "questionId": "427de3b1-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "0001000",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 7,
                                    "maxChoices": 7,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Entry Level",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Professional",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Manager",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Director",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Vice-President",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Executive",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "President, CEO",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "What position level(s) are you seeking?\n<br></br>\n<br></br> <i>Select ALL the ones that apply:</i>",
                                    "qNumber": 3,
                                    "title": "Position Level"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "questionId": "427de450-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "REPONSE": "1000000",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 7,
                                    "maxChoices": 7,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Canada",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "United States",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "South America",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Europe",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Africa",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Asia",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Oceania",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Which countries / regions would you be willing to work in?",
                                    "qNumber": 4,
                                    "title": "Mobility: Country / Region"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "questionId": "427de567-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "1000000000010100000",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 19,
                                    "maxChoices": 19,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Island of Montreal",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Abitibi-Temiscamingue",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Estrie",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Lower St. Laurent",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Eastern Townships",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Central Quebec",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "North Shore",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Chaudière-Appalaches",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Gaspesie/ Magdalen Islands",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Lanaudière",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Laurentides",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Laval",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Mauricie",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Montérégie",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Ottawa",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Quebec",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Saguenay-Lac-Saint-Jean",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Other region/city in Quebec ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "None of the above",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 3,
                                    "bAnswered": true,
                                    "question": "Please specify where you are willing to work, in Quebec.  If Quebec does not interest you, please select <i>\"None of the above\"</i>.",
                                    "qNumber": 5,
                                    "title": "Mobility: Quebec"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "questionId": "427de5f3-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "REPONSE": "00000000000000000000000000000000001",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 35,
                                    "maxChoices": 35,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Barrie",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Belleville",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Brampton",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Brantford",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Burlington",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Cambridge",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Cornwall",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Greater Sudbury",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Guelph",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Hamilton",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Kawartha Lakes",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Kingston",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Kitchener",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "London",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Markham",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Mississauga",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Niagara Falls",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Norfolk County",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "North Bay",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "Oshawa",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "Ottawa",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Peterborough",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Pickering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Sarnia",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Sault Ste. Marie",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "St. Catharines",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Thunder Bay",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Timmins",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Toronto",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "Vaughan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 30,
                                            "value": "Waterloo",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 31,
                                            "value": "Welland",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 32,
                                            "value": "Windsor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 33,
                                            "value": "Other region/city in Ontario",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 34,
                                            "value": "None of the above",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Please specify where you are willing to work, in Ontario.  If Ontario does not interest you, please select <i>\"None of the above\"</i>.",
                                    "qNumber": 6,
                                    "title": "Mobility: Ontario"
                                },
                                {
                                    "questionId": "427de676-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.308Z",
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "REPONSE": "0000000000000000000000000000001",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 31,
                                    "maxChoices": 31,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Northern BC",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Cariboo Chilcotin Coast",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "The Islands",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Vancouver Coast & Mountains",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Thompson Okanagan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "BC Rockies",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Alberta Badlands",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Alberta Rockies",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Calgary",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Central Alberta",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "East of Alberta",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Edmonton Capital Region",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Peace River Valley",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Southern Alberta",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Regina",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Saskatoon",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Southeast Saskatchewan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "South West Saskatchewan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "East-Central Saskatchewan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "West Central Saskatchewan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "North Saskatchewan",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Central Plains Manitoba",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Eastman",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Interlake",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Northern Manitoba",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "Parkland",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Pembina Valley",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Westman",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Winnipeg Capital Region",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "Other region/city of Western Canada",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 30,
                                            "value": "None of the above",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Please specify where you are willing to work, in Western Canada.  If Western Canada does not interest you, please select <i>\"None of the above\"</i>.",
                                    "qNumber": 7,
                                    "title": "Mobility: Western Canada"
                                },
                                {
                                    "questionId": "427de707-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.623Z",
                                    "created_at": "2015-12-10T16:10:28.309Z",
                                    "REPONSE": "000001",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 6,
                                    "maxChoices": 6,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "New Brunswick",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Nova Scotia",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Newfoundland and Labrador",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Prince Edward Island",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Other region/city of Eastern Canada",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "None of the above",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Please specify where you are willing to work, in Eastern Canada.  If Eastern Canada does not interest you, please select <i>\"None of the above\"</i>.",
                                    "qNumber": 8,
                                    "title": "Mobility: Eastern Canada"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.309Z",
                                    "questionId": "427de789-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.624Z",
                                    "REPONSE": "00001",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 5,
                                    "maxChoices": 5,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "North-West territories",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Yukon",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Nunavut",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Other region/city in Northern Canada",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "None of the above",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Please specify where you are willing to work, in Northern Canada.  If Northern Canada does not interest you, please select <i>\"None of the above\"</i>.",
                                    "qNumber": 9,
                                    "title": "Mobility: Northern Canada"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.624Z",
                                    "created_at": "2015-12-10T16:10:28.309Z",
                                    "questionId": "427de98a-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "01111",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 5,
                                    "maxChoices": 5,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "None",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "1-2 employees",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 2,
                                            "value": "3-5 employees",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 3,
                                            "value": "6-10 employees",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 4,
                                            "value": "10+ employees",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 4,
                                    "bAnswered": true,
                                    "question": "How many employees would you like to supervise? <br></br><br></br><i>Check ALL those that apply:</i>",
                                    "qNumber": 10,
                                    "title": "Staff Management"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.624Z",
                                    "created_at": "2015-12-10T16:10:28.309Z",
                                    "questionId": "427dea12-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "10",
                                    "answered": true,
                                    "algo": "algo_canNon_empOui",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 2,
                                    "maxChoices": 2,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Yes",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "No",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Do you have international work experience?",
                                    "qNumber": 11,
                                    "title": "International Experience"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.309Z",
                                    "questionId": "427dea90-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.624Z",
                                    "REPONSE": "0000000000000000000000000000000000000000000000001",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 49,
                                    "maxChoices": 49,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Urbanist, Town planner",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Social worker, therapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Certified translator",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Physical Rehabilitation therapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Marriage and Family Therapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Certified terminologist ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Medical imaging technologist, radiation oncology technologist and medical electrophysiology technologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Professional technologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Medical technologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Dental Technician",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Psychologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Psychoeducator ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Podiatrist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Physiotherapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Pharmacist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Speech Therapist, Speech-Language Pathologist and Audiologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Optometrist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Dispensing optician",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "Notary",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "Veterinary Surgeon",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "Doctor, Physician",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Certified interpreter",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Respiratory Therapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Forest Engineer",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Engineer ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "Nursing Assistant and Licensed Practical Nurse",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Nurse",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Dental hygienists",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Bailiff and court bailiff",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "Geologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 30,
                                            "value": "Certified appraiser and Chartered Assessor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 31,
                                            "value": "Occupational Therapist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 32,
                                            "value": "Dietician and nutritionist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 33,
                                            "value": "Denturologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 34,
                                            "value": "Dentist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 35,
                                            "value": "Certified Human Ressources Professional and Certified Industrial Relations Counsellor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 36,
                                            "value": "Vocational Guidance Counsellor and Guidance Counsellor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 37,
                                            "value": "Chartered Professional Accountant, CPA",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 38,
                                            "value": "Chiropractor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 39,
                                            "value": "Chemist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 40,
                                            "value": "Chartered Administrator and Certified Management Advisor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 41,
                                            "value": "Attorney",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 42,
                                            "value": "Hearing-Aid Acoustician",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 43,
                                            "value": "Land Surveyor",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 44,
                                            "value": "Architect",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 45,
                                            "value": "Agrologist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 46,
                                            "value": "Acupuncturist",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 47,
                                            "value": "Other",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 48,
                                            "value": "No designation",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Do you have a recognized professional designation? If YES, specify which one(s) from the list below:<br> <br> <i>Important note: If you do not have a designation, please select \"No designation\".</i>",
                                    "qNumber": 12,
                                    "title": "Professional Designation"
                                },
                                {
                                    "questionId": "427deb95-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "updated_at": "2017-01-11T12:11:23.624Z",
                                    "REPONSE": "1001110",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 7,
                                    "maxChoices": 7,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "High school diploma",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Vocational training",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "College degree",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Professional Certification",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Baccalaureate",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Master's",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Doctorate",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 4,
                                    "bAnswered": true,
                                    "question": "What levels of schooling have you completed? <br></br><br></br><i>Important: Indicate ALL levels completed to make sure that you are not excluded from an interesting opportunity.</i>",
                                    "qNumber": 13,
                                    "title": "Education"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.625Z",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "questionId": "427dec18-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "110000000000",
                                    "answered": true,
                                    "algo": "n(S1i == S2i)",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 12,
                                    "maxChoices": 12,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "English",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "French",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Chinese/ Mandarin",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Italian",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "German",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Arabic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Japonese",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Indi",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Portugese",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Russian",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Spanish",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Other",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 2,
                                    "bAnswered": true,
                                    "question": "Which language(s) are you comfortable speaking?",
                                    "qNumber": 14,
                                    "title": "Languages - Spoken"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.625Z",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "questionId": "427ded6c-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "110000000000",
                                    "answered": true,
                                    "algo": "n(S1i == S2i)",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 12,
                                    "maxChoices": 12,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "English",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "French",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Chinese/ Mandarin",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Italian",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "German",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Arabic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Japonese",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Indi",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Portugese",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Russian",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Spanish",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Other",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 2,
                                    "bAnswered": true,
                                    "question": "In which language(s) can you express yourself in writing?",
                                    "qNumber": 15,
                                    "title": "Languages - Written"
                                },
                                {
                                    "questionId": "427dedfd-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.625Z",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "REPONSE": "10",
                                    "answered": true,
                                    "algo": "algo_canNon_empOui",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 2,
                                    "maxChoices": 2,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Yes",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "No",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Are you available to travel for business purposes?",
                                    "qNumber": 16,
                                    "title": "Business Travel"
                                },
                                {
                                    "questionId": "427dee7f-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.625Z",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "REPONSE": "000001000000000000000000",
                                    "answered": true,
                                    "algo": "algo_SalMin",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 24,
                                    "maxChoices": 24,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Less than $30,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "$30,000-$40,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "$40,000-$50,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "$50,000-$60,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "$60,000-$70,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "$70,000-$80,000",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 6,
                                            "value": "$80,000-$90,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "$90,000-$100,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "$100,000-$110,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "$110,000-$120,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "$120,000-$130,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "$130,000-$140,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "$140,000-$150,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "$150,000-$160,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "$160,000-$170,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "$170,000-$180,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "$190,000-$200,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "$200,000-$250,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "$250,000-$300,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "$300,000-$350,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "$350,000-$400,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "$400,000-$450,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "$450,000-$500,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "$500,000 +",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Indicate the minimum salary bracket necessary for you to consider a potential new employer:",
                                    "qNumber": 17,
                                    "title": "Minimum salary"
                                },
                                {
                                    "questionId": "427deefd-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.625Z",
                                    "created_at": "2015-12-10T16:10:28.310Z",
                                    "REPONSE": "000000100000000000000000",
                                    "answered": true,
                                    "algo": "algo_SalMax",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 24,
                                    "maxChoices": 24,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Less than $30,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "$30,000-$40,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "$40,000-$50,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "$50,000-$60,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "$60,000-$70,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "$70,000-$80,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "$80,000-$90,000",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 7,
                                            "value": "$90,000-$100,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "$100,000-$110,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "$110,000-$120,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "$120,000-$130,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "$130,000-$140,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "$140,000-$150,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "$150,000-$160,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "$160,000-$170,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "$170,000-$180,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "$190,000-$200,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "$200,000-$250,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "$250,000-$300,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "$300,000-$350,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "$350,000-$400,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "$400,000-$450,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "$450,000-$500,000",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "$500,000 +",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Indicate your target base salary:",
                                    "qNumber": 18,
                                    "title": "Target salary"
                                },
                                {
                                    "questionId": "427df0fe-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.311Z",
                                    "updated_at": "2017-01-11T12:11:23.626Z",
                                    "REPONSE": "000001000",
                                    "answered": true,
                                    "algo": "S1i >= S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 9,
                                    "maxChoices": 9,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "I have no experience",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Less than 1 year",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "1-3 years",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "3-5 years",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "5-7 years",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "7-10 years",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 6,
                                            "value": "10-15 years",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "15-20 years",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "20+ years",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "How many years of experience do you have supervising and managing staff?",
                                    "qNumber": 19,
                                    "title": "Staff Management Experience"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.311Z",
                                    "questionId": "427df505-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.626Z",
                                    "REPONSE": "1111",
                                    "answered": true,
                                    "algo": "n(S1i == S2i)",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 4,
                                    "maxChoices": 4,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Regional",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "National",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 2,
                                            "value": "North America",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 3,
                                            "value": "International",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 4,
                                    "bAnswered": true,
                                    "question": "How far are you willing to travel for work purposes?",
                                    "qNumber": 20,
                                    "title": "Types of Travel"
                                },
                                {
                                    "questionId": "427df588-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.311Z",
                                    "updated_at": "2017-01-11T12:11:23.626Z",
                                    "REPONSE": "00001",
                                    "answered": true,
                                    "algo": "S1i >= S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 5,
                                    "maxChoices": 5,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Less than 10%",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Up to 25%",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Up to 50%",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Up to 75%",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "More than 75%",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "How much of your time <i>(in %)</i> would you be willing to spend travelling for business purposes?",
                                    "qNumber": 21,
                                    "title": "Time Spent Traveling"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.311Z",
                                    "questionId": "427df715-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.626Z",
                                    "REPONSE": "0000000000000000000000000000000000000000000000000000000000000000000000000000000010001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000",
                                    "answered": true,
                                    "algo": "algo_LastOneisIgnore",
                                    "controlType": "checkbox",
                                    "choiceType": "multiple",
                                    "nbChoices": 244,
                                    "maxChoices": 244,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "DCS - Natural Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "DCS - Humanities",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "DCS - Arts and Letters",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "DCS - Arts, Letters and communication",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "DCS - Music",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "DCS - Dance",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "DCS - Visual Arts",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "DCS - Sciences, Humanities and Arts",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "DCS - History & Civilization",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "DCS - agricultural technologies",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "DCS - Human Techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "DCS - Technical Administration",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "DCS - Accounting and Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 13,
                                            "value": "DCS - Medical Records",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "DCS - Communication technologies in the media",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "DCS - Clean Water",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "DCS - Industrial sanitation and safety",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "DCS - Electronics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "DCS - Operations",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "DCS - Operation and production of marine resources",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "DCS - Applied Geology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "DCS - Computer technology , computer networks management option",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 22,
                                            "value": "DCS - Management and farming",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 23,
                                            "value": "DCS - Graphic design",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "DCS - Infographics preprint",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "DCS - Computer technology ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "DCS - IT Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 27,
                                            "value": "DCS - Industrial Computing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "DCS - Mineral",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "DCS - Landscape and marketing ornamental horticulture",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 30,
                                            "value": "DCS - Fire safety, prevention",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 31,
                                            "value": "DCS - Business Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 32,
                                            "value": "DCS - Insurance and Financial Services",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 33,
                                            "value": "DCS - Technical development of hunting and fishing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 34,
                                            "value": "DCS - Landscaping techniques and urban planning",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 35,
                                            "value": "DCS - Biomedical Laboratory Techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 36,
                                            "value": "DCS - Office techniques ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 37,
                                            "value": "DCS - Environmental and Wildlife Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 38,
                                            "value": "DCS - Dietetics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 39,
                                            "value": "DCS - Chemical Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 40,
                                            "value": "DCS - Management techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 41,
                                            "value": "DCS - Technical documentation",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 42,
                                            "value": "DCS - Laboratory Techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 43,
                                            "value": "DCS - Printing Techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 44,
                                            "value": "DCS - Science Techniques ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 45,
                                            "value": "DCS - Technics in research",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 46,
                                            "value": "DCS - Animal Health Techniques ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 47,
                                            "value": "DCS - Social Service Work",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 48,
                                            "value": "DCS - Techniques in Applied Ecology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 49,
                                            "value": "DCS - Special education methods",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 50,
                                            "value": "DCS - Techniques in Chemical Process",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 51,
                                            "value": "DCS - Integration of multimedia techniques",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 52,
                                            "value": "DCS - Intervention techniques in crime",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 53,
                                            "value": "DCS - Inventory techniques and research in biology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 54,
                                            "value": "DCS - Natural environment techniques ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 55,
                                            "value": "DCS - Paralegal",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 56,
                                            "value": "DCS - Police techniques ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 57,
                                            "value": "DCS - Electronics design technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 58,
                                            "value": "DCS - Geomatics ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 59,
                                            "value": "DCS - Systems Technology Building",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 60,
                                            "value": "DCS - Horticultural production and environment technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 61,
                                            "value": "DCS - Food processing technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 62,
                                            "value": "DCS - Architectural Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 63,
                                            "value": "DCS - Electronics Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 64,
                                            "value": "DCS - Industrial Electronics Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 65,
                                            "value": "DCS - Electronics technology , audiovisual option",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 66,
                                            "value": "DCS - Technology assessment and evaluation in building",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 67,
                                            "value": "DCS - Animal Production Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 68,
                                            "value": "DCS - Technology of Computerized Systems",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 69,
                                            "value": "DCS - Civil Engineering Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 70,
                                            "value": "DCS - Industrial Engineering Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 71,
                                            "value": "DCS - Forest Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 72,
                                            "value": "DCS - Physics Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 73,
                                            "value": "DPS - Diploma of professional studies ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 74,
                                            "value": "DCS - Other",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 75,
                                            "value": "Bachelor's degree - Actuarial science",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 76,
                                            "value": "Bachelor's degree - Special Education",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 77,
                                            "value": "Bachelor's degree - Academic and social adjustment",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 78,
                                            "value": "Bachelor's degree - Business Administration",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 79,
                                            "value": "Bachelor's degree - Commerce & Administration, Finance",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 80,
                                            "value": "Bachelor's degree - Commerce & Administration, Accounting",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 81,
                                            "value": "Bachelor's degree - Commerce & Administration, Accounting management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 82,
                                            "value": "Bachelor's degree - Commerce & Administration, Professional Accounting",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 83,
                                            "value": "Bachelor's degree - Commerce & Administration, Entrepreneurship",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 84,
                                            "value": "Bachelor's degree - Commerce & Administration, Finance",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 85,
                                            "value": "Bachelor's degree - Commerce & Administration, Management and information systems",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 86,
                                            "value": "Bachelor's degree - Commerce & Administration, Operations management and production",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 87,
                                            "value": "Bachelor's degree - Commerce & Administration, Humain ressource management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 88,
                                            "value": "Bachelor's degree - Commerce & Administration, International Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 89,
                                            "value": "Bachelor's degree - Commerce & Administration, Logistics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 90,
                                            "value": "Bachelor's degree - Commerce & Administration, Financial Services",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 91,
                                            "value": "Bachelor's degree - Commerce & Administration, Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 92,
                                            "value": "Bachelor's degree - Commerce & Administration, Marketing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 93,
                                            "value": "Bachelor's degree - Information system",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 94,
                                            "value": "Bachelor's degree - Commerce & Administration, information technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 95,
                                            "value": "Bachelor's degree - Agronomy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 96,
                                            "value": "Bachelor's degree - Forest Management and Environment",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 97,
                                            "value": "Bachelor's degree - Animation and cultural research",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 98,
                                            "value": "Bachelor's degree - Anthropology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 99,
                                            "value": "Bachelor's degree - Anthropology and Ethnology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 100,
                                            "value": "Bachelor's degree - Archaeology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 101,
                                            "value": "Bachelor's degree - Architecture",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 102,
                                            "value": "Bachelor's degree - Landscaping Architecture",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 103,
                                            "value": "Bachelor's degree - Arts",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 104,
                                            "value": "Bachelor's degree - Visual Arts",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 105,
                                            "value": "Bachelor's degree - Political science",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 106,
                                            "value": "Bachelor's degree - Biochemistry",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 107,
                                            "value": "Bachelor's degree - Biology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 108,
                                            "value": "Bachelor's degree - Medical biology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 109,
                                            "value": "Bachelor's degree - Chemistry",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 110,
                                            "value": "Bachelor's degree - Communication",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 111,
                                            "value": "Bachelor's degree - Communication and Human Relations",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 112,
                                            "value": "Bachelor's degree - Communication and policy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 113,
                                            "value": "Bachelor's degree - Graphic communication",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 114,
                                            "value": "Bachelor's degree - Public Communication",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 115,
                                            "value": "Bachelor's degree - Social Communication",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 116,
                                            "value": "Bachelor's degree - Communication, writing and multimedia",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 117,
                                            "value": "Bachelor's degree - Accounting",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 118,
                                            "value": "Bachelor's degree - Accounting management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 119,
                                            "value": "Bachelor's degree - Computer science",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 120,
                                            "value": "Bachelor's degree - Counseling orientation",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 121,
                                            "value": "Bachelor's degree - Criminology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 122,
                                            "value": "Bachelor's degree - Graphic Design",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 123,
                                            "value": "Bachelor's degree - Career Development",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 124,
                                            "value": "Bachelor's degree - Local and regional development",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 125,
                                            "value": "Bachelor's degree - Law",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 126,
                                            "value": "Bachelor's degree - Economics and Agribusiness Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 127,
                                            "value": "Bachelor's degree - Economics and computer science ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 128,
                                            "value": "Bachelor's degree - Economics and Politics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 129,
                                            "value": "Bachelor's degree - Economics and Mathematics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 130,
                                            "value": "Bachelor's degree - Economics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 131,
                                            "value": "Bachelor's degree - Education",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 132,
                                            "value": "Bachelor's degree - Mathematics Education",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 133,
                                            "value": "Bachelor's degree - Teaching geography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 134,
                                            "value": "Bachelor's degree - Environment",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 135,
                                            "value": "Bachelor's degree - Ethnology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 136,
                                            "value": "Bachelor's degree - French studies",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 137,
                                            "value": "Bachelor's degree - French and Philosophy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 138,
                                            "value": "Bachelor's degree - French studies and linguistics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 139,
                                            "value": "Bachelor's degree - International Studies",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 140,
                                            "value": "Bachelor's degree - International Studies and Modern Languages",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 141,
                                            "value": "Bachelor's degree - Agri-Environmental engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 142,
                                            "value": "Bachelor's degree - Food Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 143,
                                            "value": "Bachelor's degree - Chemical Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 144,
                                            "value": "Bachelor's degree - Civil Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 145,
                                            "value": "Bachelor's degree - Construction Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 146,
                                            "value": "Bachelor's degree - Automated Production Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 147,
                                            "value": "Bachelor's degree - Materials Engineering and Metallurgy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 148,
                                            "value": "Bachelor's degree - Mining engineering and mineral",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 149,
                                            "value": "Bachelor's degree - Wood engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 150,
                                            "value": "Bachelor's degree - Electrical Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 151,
                                            "value": "Bachelor's degree - Geological Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 152,
                                            "value": "Bachelor's degree - Geomatics Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 153,
                                            "value": "Bachelor's degree - Industrial Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 154,
                                            "value": "Bachelor's degree - Computer Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 155,
                                            "value": "Bachelor's degree - Software Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 156,
                                            "value": "Bachelor's degree - Mechanical Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 157,
                                            "value": "Bachelor's degree - Microelectronics engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 158,
                                            "value": "Bachelor's degree - Engineering Physics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 159,
                                            "value": "Bachelor's degree - Unified engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 160,
                                            "value": "Bachelor's degree - Unified engineering, civil engineering option",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 161,
                                            "value": "Bachelor's degree - Geography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 162,
                                            "value": "Bachelor's degree - Environmental Geography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 163,
                                            "value": "Bachelor's degree - Geology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 164,
                                            "value": "Bachelor's degree - Public Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 165,
                                            "value": "Bachelor's degree - History",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 166,
                                            "value": "Bachelor's degree - Art History",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 167,
                                            "value": "Bachelor's degree - Human environment, geography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 168,
                                            "value": "Bachelor's degree - Information and referral business",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 169,
                                            "value": "Bachelor's degree - Computers",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 170,
                                            "value": "Bachelor's degree - IT Management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 171,
                                            "value": "Bachelor's degree - Kinesiology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 172,
                                            "value": "Bachelor's degree - French Language and Professional Writing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 173,
                                            "value": "Bachelor's degree - Linguistics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 174,
                                            "value": "Bachelor's degree - Mathematics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 175,
                                            "value": "Bachelor's degree - Mathematics and Actuarial Science",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 176,
                                            "value": "Bachelor's degree - Mathematics and Computer Science",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 177,
                                            "value": "Bachelor's degree - Microbiology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 178,
                                            "value": "Bachelor's degree - Microelectronics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 179,
                                            "value": "Bachelor's degree - Nutrition",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 180,
                                            "value": "Bachelor's degree - Forestry operations",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 181,
                                            "value": "Bachelor's degree - Remedial",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 182,
                                            "value": "Bachelor's degree - Pharmacology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 183,
                                            "value": "Bachelor's degree - Philosophy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 184,
                                            "value": "Bachelor's degree - Physics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 185,
                                            "value": "Bachelor's degree - Applied Policy",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 186,
                                            "value": "Bachelor's degree - Psychoeducation",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 187,
                                            "value": "Bachelor's degree - Psychology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 188,
                                            "value": "Bachelor's degree - Operations Research",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 189,
                                            "value": "Bachelor's degree - Industrial Relations",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 190,
                                            "value": "Bachelor's degree - Biological Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 191,
                                            "value": "Bachelor's degree - Accounting Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 192,
                                            "value": "Bachelor's degree - Communication Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 193,
                                            "value": "Bachelor's degree - Consumer Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 194,
                                            "value": "Bachelor's degree - Science orientation",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 195,
                                            "value": "Bachelor's degree - Economics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 196,
                                            "value": "Bachelor's degree - Science and food technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 197,
                                            "value": "Bachelor's degree - Nursing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 198,
                                            "value": "Bachelor's degree - Legal Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 199,
                                            "value": "Bachelor's degree - Social Service",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 200,
                                            "value": "Bachelor's degree - Sociology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 201,
                                            "value": "Bachelor's degree - Translation",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 202,
                                            "value": "Bachelor's degree - Social Work",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 203,
                                            "value": "Bachelor's degree - Urban planning ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 204,
                                            "value": "Bachelor's degree - Other ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 205,
                                            "value": "Master's degree - Education and educational technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 206,
                                            "value": "Master's degree - Business & Administration (MBA)",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 207,
                                            "value": "Master's degree - Regional Planning and Regional Development",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 208,
                                            "value": "Master's degree - Policy Analysis",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 209,
                                            "value": "Master's degree - Analysis and urban management",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 210,
                                            "value": "Master's degree - Anthropology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 211,
                                            "value": "Master's degree - Urban architecture",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 212,
                                            "value": "Master's degree - Biochemistry",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 213,
                                            "value": "Master's degree - Chemistry",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 214,
                                            "value": "Master's degree - Demography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 215,
                                            "value": "Master's degree - Regional Development",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 216,
                                            "value": "Master's degree - Economic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 217,
                                            "value": "Master's degree - Environment",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 218,
                                            "value": "Master's degree - Epidemiology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 219,
                                            "value": "Master's degree - Ethnology of francophones in North America",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 220,
                                            "value": "Master's degree - Studies regional intervention",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 221,
                                            "value": "Master's degree - Applied Finance",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 222,
                                            "value": "Master's degree - Mathematical finance and IT",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 223,
                                            "value": "Master's degree - Chemical Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 224,
                                            "value": "Master's degree - Geography",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 225,
                                            "value": "Master's degree - Geography, Planning",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 226,
                                            "value": "Master's degree - Gerontology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 227,
                                            "value": "Master's degree - History",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 228,
                                            "value": "Master's degree - Experimental Medicine",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 229,
                                            "value": "Master's degree - Physics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 230,
                                            "value": "Master's degree - Psychology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 231,
                                            "value": "Master's degree - Psychology of Human Relations",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 232,
                                            "value": "Master's degree - Renewable resources",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 233,
                                            "value": "Master's degree - Community Health",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 234,
                                            "value": "Master's degree - Environmental Health and Occupational Health",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 235,
                                            "value": "Master's degree - Administrative sciences , financial engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 236,
                                            "value": "Master's degree - Environmental Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 237,
                                            "value": "Master's degree - Economics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 238,
                                            "value": "Master's degree - Geographic Sciences",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 239,
                                            "value": "Master's degree - Sociology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 240,
                                            "value": "Master's degree - Educational Technology",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 241,
                                            "value": "Master's degree - Urban planning",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 242,
                                            "value": "Master's degree - Other ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 243,
                                            "value": "None of the above",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 3,
                                    "bAnswered": true,
                                    "question": "Specify the  degree(s) you have completed. If your degree is not listed, please choose the \"Other\" category (Eg: Master's degree - Other)",
                                    "qNumber": 22,
                                    "title": "Diplomas"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.626Z",
                                    "questionId": "427df893-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.311Z",
                                    "REPONSE": "09999999999999990000999909999999999990099999990",
                                    "answered": true,
                                    "algo": "algo_ExperienceEtInterets",
                                    "controlType": "cote09",
                                    "choiceType": "multiple",
                                    "nbChoices": 47,
                                    "maxChoices": 47,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Aerospace & Defence",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Agriculture, Forestry & Fishing",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Architecture",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Arts & entertainment",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Insurance",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Automobiles",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Retail",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Communication",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Construction",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Cosmetic",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Education",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Energy",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Environment",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Finances",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Real estate",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Shipbuilding & Maritime",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Engineering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Logistics",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "Manufacturing",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "Metals & Minerals",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "Food",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Sciences & R&D",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Public Sector / Government",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Security",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Services",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "Sports",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Technology & Multi-media",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Telecommunications",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Printing & Editing",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 29,
                                            "value": "Advertising, marketing & PR",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 30,
                                            "value": "Journalism",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 31,
                                            "value": "Radio & TV",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 32,
                                            "value": "Banks",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 33,
                                            "value": "Accounting",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 34,
                                            "value": "Financial Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 35,
                                            "value": "Brokerage",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 36,
                                            "value": "Investment",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 37,
                                            "value": "Pharmaceutical Equipment",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 38,
                                            "value": "Biotech & Pharmaceuticals",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 39,
                                            "value": "Health & medical services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 40,
                                            "value": "Vet Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 41,
                                            "value": "Legal Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 42,
                                            "value": "Consulting",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 43,
                                            "value": "Recruitment",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 44,
                                            "value": "Business Services",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 45,
                                            "value": "Tourism",
                                            "selected": "9"
                                        },
                                        {
                                            "key": 46,
                                            "value": "Transport",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 38,
                                    "bAnswered": true,
                                    "question": "Please select the industries that you are interested to work in.\n<br></br>\n<br></br>\n<i>Once an industry is selected, please indicate if you already have experience in that field by identifying the number of years.</i>",
                                    "qNumber": 23,
                                    "title": "Industries"
                                }
                            ],
                            "name": "Deal Breakers"
                        },
                        {
                            "sectionId": "7e004187-356a-11e5-b40d-00ff84a458ef",
                            "questions": [
                                {
                                    "created_at": "2015-12-10T16:10:28.361Z",
                                    "questionId": "427e0521-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.628Z",
                                    "REPONSE": "011100",
                                    "answered": true,
                                    "algo": "(S1i == S2i)",
                                    "controlType": "checkbox",
                                    "choiceType": "exact",
                                    "nbChoices": 3,
                                    "maxChoices": 6,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Paul the Realist:  Paul is ingenious, traditional and has an excellent judgment and practical business sense. Very \" down-to- earth,\" he loves to move, operate, construct, repair and has lots of physical coordination and dexterity.   You’ll love to hear the sports anecdotes of this awesome golfer.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Michelle the Conventional:  Michelle enjoys working with numbers and analyzing data and problems and gives her full attention to details. She is precise and very effective in her work and loves to establish procedures and systems.  She an indispensable member of all projects and teams.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Julie the Entrepreneur: Julie likes to take risks and thrives in the face of fierce competition.  She is able to motivate, influence and lead others and excels when comes time to sell, manage and convince. Strong verbal skills allow her to motivate and lead people by inspiring them to participate in achieving her mission.  You’re always left with a sense of being able to “reach the stars” after a discussion with her.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Catherine the Social Bee:  Catherine is a collaborative “social bee” who is generous and compelled to help others constantly. She loves people, teamwork and servicing the community.  She shows great natural aptitude for human relations.  It’s always a pleasure to talk with her by the coffee machine.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Steven the Artist:  Steven is a great idealist with exceptional creativity.  Very imaginative, he always brings innovative ideas and new ways of looking at things. He has a natural talent for communication, arts, loves to create unique and original environments that stimulate the creativity of all his colleagues.  Never a dull moment!",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Nicolas the Investigator:  Is very attentive, alert, independent, curious and always thrives to learn more about the people around him, about his work and his organization. Demonstrates great interest and abilities in solving complex and abstract problems, as well as for research and analysis. Could easily work for the police…",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 3,
                                    "bAnswered": true,
                                    "question": "Please read the following descriptions of 6 types of colleagues that you could end up working with.   Specify the <i>3 profiles</i> that you think you would enjoy working with the most.",
                                    "qNumber": 1,
                                    "title": "Profiles of Colleagues"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.628Z",
                                    "created_at": "2015-12-10T16:10:28.361Z",
                                    "questionId": "427e0924-cd3d-11e2-8861-080027001c5f",
                                    "REPONSE": "01",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 2,
                                    "maxChoices": 2,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Focus on relationships",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Focus on tasks",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Please choose the statement that best describes the type of manager that you are.<br><br>  \"Generally, I tend to...\":",
                                    "qNumber": 2,
                                    "title": "Management Style"
                                },
                                {
                                    "questionId": "427e09a6-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "updated_at": "2017-01-11T12:11:23.628Z",
                                    "REPONSE": "1000",
                                    "answered": true,
                                    "algo": "S1i == S2i",
                                    "controlType": "checkbox",
                                    "choiceType": "unique",
                                    "nbChoices": 4,
                                    "maxChoices": 4,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Participatory: Mobilize others to create commitment and engagement",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Persuasive: Helping and assisting to build trust",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Delegative:  Empower to develop resources",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Directive: Structuring to create security",
                                            "selected": "0"
                                        }
                                    ],
                                    "nbSelected": 1,
                                    "bAnswered": true,
                                    "question": "Select the statement that  best describes your leadership style:",
                                    "qNumber": 3,
                                    "title": "Leadership Style"
                                },
                                {
                                    "questionId": "427e0b25-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.628Z",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "REPONSE": "87421365",
                                    "answered": true,
                                    "algo": "null",
                                    "controlType": "cote18",
                                    "choiceType": "exact",
                                    "nbChoices": 8,
                                    "maxChoices": 8,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Specialization",
                                            "selected": "8"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Manage",
                                            "selected": "7"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Stability",
                                            "selected": "4"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Freedom",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Improve & turnaround",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Ethics",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Challenges",
                                            "selected": "6"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Balanced",
                                            "selected": "5"
                                        }
                                    ],
                                    "nbSelected": 8,
                                    "bAnswered": true,
                                    "question": "Which words would best describe your ideal job? <br><br>Please rank the following statements in order of importance <i>(top-to-bottom)</i>.",
                                    "qNumber": 4,
                                    "title": "Job Profile"
                                },
                                {
                                    "questionId": "5fcb2386-30f8-11e3-8e6f-848f69b7f098",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "updated_at": "2017-01-11T12:11:23.628Z",
                                    "REPONSE": "28671354",
                                    "answered": true,
                                    "algo": "null",
                                    "controlType": "cote18",
                                    "choiceType": "exact",
                                    "nbChoices": 8,
                                    "maxChoices": 8,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Recognition",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Learning & progressing",
                                            "selected": "8"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Job security",
                                            "selected": "6"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Personal Growth",
                                            "selected": "7"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Money",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Promoting strong values",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Guidance",
                                            "selected": "5"
                                        },
                                        {
                                            "key": 7,
                                            "value": "A balanced life",
                                            "selected": "4"
                                        }
                                    ],
                                    "nbSelected": 8,
                                    "bAnswered": true,
                                    "question": "What motivates you at work?<br><br>Please rank the following statements in order of importance <i>(top-to-bottom)</i>.",
                                    "qNumber": 5,
                                    "title": "Motivation"
                                },
                                {
                                    "questionId": "80f1fe8a-30f8-11e3-8e6f-848f69b7f098",
                                    "updated_at": "2017-01-11T12:11:23.629Z",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "REPONSE": "87142356",
                                    "answered": true,
                                    "algo": "null",
                                    "controlType": "cote18",
                                    "choiceType": "exact",
                                    "nbChoices": 8,
                                    "maxChoices": 8,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Specialist",
                                            "selected": "8"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Leader",
                                            "selected": "7"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Comfortable",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Free",
                                            "selected": "4"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Independent",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Influence",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Challenge",
                                            "selected": "5"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Conformist",
                                            "selected": "6"
                                        }
                                    ],
                                    "nbSelected": 8,
                                    "bAnswered": true,
                                    "question": "Which of these characteristics define your ideal type of work?<br><br>Please rank the following statements in order of importance <i>(top-to-bottom)</i>.",
                                    "qNumber": 6,
                                    "title": "Ideal Work"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "updated_at": "2017-01-11T12:11:23.629Z",
                                    "questionId": "944e8632-30f8-11e3-8e6f-848f69b7f098",
                                    "REPONSE": "86432571",
                                    "answered": true,
                                    "algo": "null",
                                    "controlType": "cote18",
                                    "choiceType": "exact",
                                    "nbChoices": 8,
                                    "maxChoices": 8,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "To further my specialty",
                                            "selected": "8"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Must be deserved",
                                            "selected": "6"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Earnt through seniority",
                                            "selected": "4"
                                        },
                                        {
                                            "key": 3,
                                            "value": "To take on more responsibility",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 4,
                                            "value": "I prefer to be a shareholder",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 5,
                                            "value": "To influences others",
                                            "selected": "5"
                                        },
                                        {
                                            "key": 6,
                                            "value": "To take on bigger challenges",
                                            "selected": "7"
                                        },
                                        {
                                            "key": 7,
                                            "value": "A heavy workload",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 8,
                                    "bAnswered": true,
                                    "question": "What is your perspective on promotions? <br><br>Please rank the following statements in order of importance <i>(top-to-bottom)</i>.",
                                    "qNumber": 7,
                                    "title": "Promotions"
                                },
                                {
                                    "updated_at": "2017-01-11T12:11:23.629Z",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "questionId": "a4d31966-30f8-11e3-8e6f-848f69b7f098",
                                    "REPONSE": "62745831",
                                    "answered": true,
                                    "algo": "algo_Ancres",
                                    "controlType": "cote18",
                                    "choiceType": "exact",
                                    "nbChoices": 8,
                                    "maxChoices": 8,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Budgetary, administrative or management constraints",
                                            "selected": "6"
                                        },
                                        {
                                            "key": 1,
                                            "value": "The prospect of staying too long in one place or position",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 2,
                                            "value": "The unexpected and the arbitrary",
                                            "selected": "7"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Constrained by policies, procedures and rules",
                                            "selected": "4"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Unable to act like an entrepreneur",
                                            "selected": "5"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Lack of organizational values or practices that contradict values",
                                            "selected": "8"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Overly stable environment where competition and conflicts are minimized",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Being asked to stay outside working hours",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 8,
                                    "bAnswered": true,
                                    "question": "What do you find most irritating in the workplace? <br></br><br></br>Please rank the following statements in order of importance <i>(top-to-bottom)</i>.",
                                    "qNumber": 8,
                                    "title": "Irritants"
                                },
                                {
                                    "questionId": "427e0b9e-cd3d-11e2-8861-080027001c5f",
                                    "created_at": "2015-12-10T16:10:28.362Z",
                                    "updated_at": "2017-01-11T12:11:23.629Z",
                                    "REPONSE": "10101010100110101010011010100110010101011001101001100101011001011001",
                                    "answered": true,
                                    "algo": "algo_Profil",
                                    "controlType": "checkbox",
                                    "choiceType": "array_pairs",
                                    "nbChoices": 68,
                                    "maxChoices": 68,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "A) I rely on facts.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "B) I trust my intuition.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "A) I am interested in concrete problems.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 3,
                                            "value": "B) I am interested in creative ideas.\n",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "A) I prefer when people are clear and direct.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 5,
                                            "value": "B) I like people who are indirect in their communications, to avoid hurting other's feelings.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "A) I give attention to details.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 7,
                                            "value": "B) I pay attention to the general overview, less to details.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "A) I am rather down-to-earth.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 9,
                                            "value": "B) I am a rather complex.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "A) I focus on the present.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "B) I like to dream of future possibilities.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 12,
                                            "value": "A) I am known for my common sense.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 13,
                                            "value": "B) I am known for my intuition.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "A) I am realistic and pragmatic.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 15,
                                            "value": "B) I am theoretical and creative.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "A) I trust based on facts.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 17,
                                            "value": "B) I trust based on my intuition.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "A) I'm honest and direct.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 19,
                                            "value": "B) I am gentle and diplomatic.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "A) I am septic at first.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "B) I am receptive first.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 22,
                                            "value": "A) In general, I'm not an emotional person.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 23,
                                            "value": "B) In general, I am an emotional person.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "A) I'm analytical.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 25,
                                            "value": "B) I'm empathetic.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "A) I face conflict directly.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 27,
                                            "value": "B) I avoid conflict if possible.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "A) I am guided by principles.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "B) I am a nice person.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 30,
                                            "value": "A) I am always objective when criticized.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 31,
                                            "value": "B) I am likely to take criticism personally.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 32,
                                            "value": "A) I am impartial and objective.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 33,
                                            "value": "B) I have compassion for others.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 34,
                                            "value": "A) I'm a competitive person.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 35,
                                            "value": "B) I am a supporter of others.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 36,
                                            "value": "A) To avoid stress, I complete work before deadlines.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 37,
                                            "value": "B) I complete work for deadlines, even if it's a little more stressful. ",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 38,
                                            "value": "A) I make detailed plans before starting to anticipate problems.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 39,
                                            "value": "B) I like to make high level plans and manage problems as they appear.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 40,
                                            "value": "A) I am always punctual, sometimes in advance.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 41,
                                            "value": "B) I am punctual but sometimes late.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 42,
                                            "value": "A) On vacation, I like all my days to be well scheduled.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 43,
                                            "value": "B) On vacation, I prefer spontaneity.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 44,
                                            "value": "A) I like clear directions to align on expectations.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 45,
                                            "value": "B) I like being free to determine how to reach high level objectives.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 46,
                                            "value": "A) I am a relaxed person.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 47,
                                            "value": "B) I am tireless, I move a lot.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 48,
                                            "value": "A) My workspace is very tidy, I like working 1 file at a time.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 49,
                                            "value": "B) I have several stacks of paper on my desk as I work on many files simultaneously.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 50,
                                            "value": "A) I do things thoughtfully, I tend to avoid risks.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 51,
                                            "value": "B) I don't worry excessively, I like to take risks.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 52,
                                            "value": "A) I like to make detailed project plans, right from the start.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 53,
                                            "value": "B) I like to make high-level plans and manage issues as they come up. ",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 54,
                                            "value": "A) I like to talk and lead the discussions.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 55,
                                            "value": "B) I prefer to listen to people.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 56,
                                            "value": "A) I get bored when I am alone too long.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 57,
                                            "value": "B) I often need time alone to recharge my batteries.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 58,
                                            "value": "A) I prefer to work with a team.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 59,
                                            "value": "B) I prefer to work alone.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 60,
                                            "value": "A) I am often the first person to speak in a group discussion, I like to position myself quickly. ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 61,
                                            "value": "B) I often speak in the middle/end of a group discussion, I reflect first, I speak after.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 62,
                                            "value": "A) I like to interact with others, I have lots of energy.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 63,
                                            "value": "B) I like to take time to reflect and think.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 64,
                                            "value": "A) I have general knowledge in several areas.",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 65,
                                            "value": "B) I have great expertise in restricted areas.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 66,
                                            "value": "A) I go towards others and introduce topics of conversation in gatherings.",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 67,
                                            "value": "B) I prefer to  wait for others to come talk to me at gatherings.",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 34,
                                    "bAnswered": true,
                                    "question": "In order to determine your work personality profile, choose the statement which best represents you from EACH COMBINATION of A and B.<br><br>Take time to read and choose carefully, the resulting report has some very interesting recommendations for you!",
                                    "qNumber": 9,
                                    "title": "Personality Profile"
                                },
                                {
                                    "created_at": "2015-12-10T16:10:28.363Z",
                                    "questionId": "427e0c1c-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.630Z",
                                    "REPONSE": "635421",
                                    "answered": true,
                                    "algo": "algo_FMI",
                                    "controlType": "cote16",
                                    "choiceType": "exact",
                                    "nbChoices": 6,
                                    "maxChoices": 6,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Money, financial and social recognition",
                                            "selected": "6"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Leading and influencing\n",
                                            "selected": "3"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Creation, innovation and personal growth",
                                            "selected": "5"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Service to others, helping, teamwork",
                                            "selected": "4"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Respect of principles, organization and structure",
                                            "selected": "2"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Knowledge, learning and seeking challenge",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 6,
                                    "bAnswered": true,
                                    "question": "What motivates you at work?<br></br><br></br> Please rank the following statements in order of importance from 1 to 6 <i>(top-to-bottom)</i>.",
                                    "qNumber": 10,
                                    "title": "Drivers of Motivation"
                                },
                                {
                                    "questionId": "427e0c9f-cd3d-11e2-8861-080027001c5f",
                                    "updated_at": "2017-01-11T12:11:23.630Z",
                                    "created_at": "2015-12-10T16:10:28.363Z",
                                    "REPONSE": "10000000000010000000011000000010010000001000000101000001",
                                    "answered": true,
                                    "algo": "(S1i == S2i)",
                                    "controlType": "checkbox",
                                    "choiceType": "exact",
                                    "nbChoices": 10,
                                    "maxChoices": 56,
                                    "choices": [
                                        {
                                            "key": 0,
                                            "value": "Precise",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 1,
                                            "value": "Focused on success",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 2,
                                            "value": "Adaptable",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 3,
                                            "value": "Fun",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 4,
                                            "value": "Adventurous",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 5,
                                            "value": "Inspiring & motivating",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 6,
                                            "value": "Assured",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 7,
                                            "value": "Clever",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 8,
                                            "value": "Authoritarian",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 9,
                                            "value": "Calm",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 10,
                                            "value": "Careful",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 11,
                                            "value": "Charismatic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 12,
                                            "value": "Competent",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 13,
                                            "value": "Enthusiastic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 14,
                                            "value": "Cooperative",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 15,
                                            "value": "Courageous",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 16,
                                            "value": "Creative",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 17,
                                            "value": "Decisive",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 18,
                                            "value": "Reliable",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 19,
                                            "value": "Vigilant",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 20,
                                            "value": "Diplomat",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 21,
                                            "value": "Determined & driven",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 22,
                                            "value": "Dynamic",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 23,
                                            "value": "Effective",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 24,
                                            "value": "Efficient",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 25,
                                            "value": "Energetic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 26,
                                            "value": "Experienced",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 27,
                                            "value": "Expert",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 28,
                                            "value": "Firm",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 29,
                                            "value": "Flexible",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 30,
                                            "value": "Human",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 31,
                                            "value": "Independent",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 32,
                                            "value": "Innovative & pioneering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 33,
                                            "value": "Faithful & loyal",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 34,
                                            "value": "Methodical",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 35,
                                            "value": "Objective",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 36,
                                            "value": "Open-minded",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 37,
                                            "value": "Patient",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 38,
                                            "value": "Perceptive",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 39,
                                            "value": "Persevering",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 40,
                                            "value": "Professional",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 41,
                                            "value": "Protective",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 42,
                                            "value": "Punctual",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 43,
                                            "value": "Fast",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 44,
                                            "value": "Rational",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 45,
                                            "value": "Realistic",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 46,
                                            "value": "Resourceful",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 47,
                                            "value": "Responsible",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 48,
                                            "value": "Sensitive",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 49,
                                            "value": "Autonomous",
                                            "selected": "1"
                                        },
                                        {
                                            "key": 50,
                                            "value": "Reactive",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 51,
                                            "value": "Self-sufficient",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 52,
                                            "value": "Sophisticated",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 53,
                                            "value": "Supporting ",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 54,
                                            "value": "Delicate",
                                            "selected": "0"
                                        },
                                        {
                                            "key": 55,
                                            "value": "Conscientious & thorough",
                                            "selected": "1"
                                        }
                                    ],
                                    "nbSelected": 10,
                                    "bAnswered": true,
                                    "question": "From the following list, choose <i>10 characteristics</i> that you believe best describe your personality:",
                                    "qNumber": 11,
                                    "title": "Personality Traits"
                                }
                            ],
                            "name": "Personality Profile"
                        }
                    ]
                },
                "userId": "0003401b-1db8-5393-9814-fc86ba6807e3",
                "requestId": "00000000-0000-0000-0000-000000000000"
            }
      
        }

    }]);

} )( angular );