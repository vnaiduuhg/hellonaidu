(function (angular) {
  function inventoryService($rootScope, storageService, utils, $cookies, $http, authService, $state) {
    return {
        setAgencyMode : function(agencyAccountId) {
          // @agency
          // if( agencyAccountId == window.appConfig.FCCQ_ACCOUNT_ID ) {
          //   storageService.setCookie("mode", "Fccq");
          //   $rootScope.fccqMode = true;
          // }
        },
        checkInventory : function() {
          return authService.getToken().then(
            token => {
              if (token) {
                if (storageService.getItem('account_type') == 'client') {
                  $rootScope.isPremiumClient = false;
                  const clientAccountId = storageService.getItem('account_id');
                  const url = `${window.appConfig.MARKETPLACE_URL}api/v1/account/${clientAccountId}/inventory`;
                  const headers = {
                    Authentication: token,
                  };
                  return $http({
                    method: 'GET',
                    url,
                    headers,
                  }).then((response) => {
                    if(response.data) {
                      angular.forEach(response.data, (item) => {
                        // @agency: have to add checks for other paid products if any
                        // if(item.consumable.reference_code === 'Paid FCCQ Client') {
                        //   $rootScope.isPremiumClient = true;
                        // }                           
                      }) 
                      return response.data;                
                    }
                  })
                } else {
                  return;
                }
              }
            }
          )
        },
        setAgencyCookies : function() {
          if (utils.getUrlParam('iframe')) {
            storageService.setSessionItem('isOpenInIframe', true);
            $rootScope.agencyIframe = true;
            const agencyId = utils.getUrlParam('agency');
            if (agencyId) {
              $rootScope.agencyId = agencyId;
              storageService.setSessionItem('agencyId', $rootScope.agencyId);
            }
          } else if (storageService.getSessionItem('isOpenInIframe')) {
            $rootScope.agencyIframe = true;
            const agencyId = storageService.getSessionItem('agencyId');
            if (agencyId) {
              $rootScope.agencyId = storageService.getSessionItem('agencyId');
            }
          } else {
            $rootScope.agencyIframe = false;
            $rootScope.agencyId = null;
            storageService.removeSessionItem('agencyId');
          }

          // @agency: EmploisQuebec(EQ) or FCCQ mode set-up
          // $rootScope.fccqMode = false;
          // $rootScope.emploisQuebecMode = false;
          // if (['jobsList', 'jobsDescription', 'companyDescription', 'agencyPackages'].includes($state.current.name)) {
          //   $cookies.remove('mode');
          // } else if (/^Eq/g.exec($state.current.name)) {
          //   storageService.setCookie('mode', 'EmploisQuebec');
          //   $rootScope.emploisQuebecMode = true;
          // } else if (/^Fccq/g.exec($state.current.name)) {
          //   storageService.setCookie('mode', 'Fccq');
          //   $rootScope.fccqMode = true;
          // } else if ($cookies.get('mode') === 'EmploisQuebec') {
          //   $rootScope.emploisQuebecMode = true;
          // } else if ($cookies.get('mode') === 'Fccq') {
          //   $rootScope.fccqMode = true;
          // } 
          // else {
          //   $cookies.remove('mode');
          // }
        }
    }
  }
  angular.module('shared-components')
    .service('inventoryService', inventoryService);
  inventoryService.$inject = ['$rootScope', 'storageService', 'utils', '$cookies', '$http', 'authService', '$state'];
}(angular));