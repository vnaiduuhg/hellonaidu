(function (angular) {
    'use strict';

    angular.module('shared-components').service('statService', statService);

    statService.$inject = ['$q', '$http', 'authService', '$window', '$rootScope'];

    function statService($q, $http, authService, $window, $rootScope) {

        var obj = {
            getColorsArray,
            getShortMonthsArray,
            genericPostRequest
        };

        return obj;        

        function getColorsArray(dataLength) {
            let colorsArray = ['#9F76FF', '#2DA3D5', '#FF629A', '#1BC559', '#FF622E', '#FFE028',
                '#DA1CC7', '#3D67FF', '#FF1842', '#008ABF', '#5729C2', '#004569', 
                '#004B1A', '#A00700', '#FFAAA7', '#817B95'];
            if (dataLength && dataLength > 16) {
                for (let i = 0; i < dataLength -16; i += 1) {
                    let randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
                    colorsArray.push(randomColor);
                }
            }
            return colorsArray;
        }

        function getShortMonthsArray() {
            return {
                'en': ['Jan','Feb','Mar','Apr','May','Jun','Jul','Apr','Sept','Oct','Nov','Dec'],
                'fr': ['Janv','F\u00e9vr','Mars','Avr','Mai','Juin','Juil','Ao\u00fbt','Sept','Oct','Nov','D\u00e9c']
            };
        }

        function genericPostRequest(reportKey, reportValue, filter=null, company=null, datesFilter=null) {
            var defer = $q.defer();
            var data = {};
            data[reportKey] = reportValue;
            data.locale = $rootScope.language;
            data.parameters = {};
            if (filter) {                
                data.parameters[filter] = company ? company.company.id : null;
            }
            if (datesFilter) {
                data.parameters = Object.assign(data.parameters, datesFilter);
            }
            return authService.getToken().then(function(token) {
                var config = {headers:{"Authentication": token}};
                $http.post($window.appConfig.REPORTING_URL + 'api/v1/prepared-reports/request', data, config).then(function (res) {
                    defer.resolve(res);
                }, function (err) {
                    defer.reject(err);
                });
                return defer.promise;
            })            
        }

    }

})(angular);
