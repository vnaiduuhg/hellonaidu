( function ( angular ) {

  'use strict';

  angular.module('shared-components')
  .service('marketplaceService', marketplaceService);


  marketplaceService.$inject = ['$q', '$http', '$window'];

  function marketplaceService($q, $http, $window) {
    return {
      createFreeAccount: function(data){
          var defer = $q.defer();
          var url = $window.appConfig.MARKETPLACE_URL + 'api/v1/create-account-by-card';
          $http.post(url, data).then(function(res) {
            defer.resolve(res);
          }, function(err){
            defer.reject(err);
        });
        return defer.promise;
      },
      payByCard: function(data){
          var defer = $q.defer();
          var url = $window.appConfig.MARKETPLACE_URL + 'api/v1/create-account-by-card';
          $http.post(url, data).then(function(res) {
              defer.resolve(res);
          }, function(err){
           defer.reject(err);
        });
        return defer.promise;
      },
      payByCheque: function(data){
        var defer = $q.defer();
        var url = $window.appConfig.MARKETPLACE_URL + 'api/v1/create-account-by-cheque';
        $http.post(url, data).then(function(res) {
          defer.resolve(res);
        }, function(err){
          defer.reject(err);
      });
      return defer.promise;
      },
    };
  }

})(angular);
