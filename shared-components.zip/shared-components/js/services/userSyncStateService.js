(function (angular) {
  function userSyncStateService($rootScope, $http, authService) {
    return {
      getAutomatedSyncedAccounts : function() {
        return authService.getToken().then(
          token => {
            if (token) {
              let showJobAlertTrigger = false;
              const url = `${window.appConfig.MESSAGING_URL}api/v1/users/current-user/email-accounts`;
              const headers = {
                Authentication: token,
              };
              return $http({
                method: 'GET',
                url,
                headers,
              }).then((response) => {
                if(response.status === 200) {
                  const userSyncAccounts = response.data;
                  Object.entries(userSyncAccounts.automated).forEach(account => {
                    const [key, value] = account;
                    switch (key) {
                      case 'nylas':
                        if(value.length && value[0].is_default && value[0].sync_state === 'running') {
                          showJobAlertTrigger = true;
                        }
                        break;
                      case 'email_engine':
                        if(value.length && value[0].is_default && value[0].sync_state === 'connected') {
                          showJobAlertTrigger = true;
                        }
                        break;
                      case 'aws':
                        if(value.length && value[0].is_default && value[0].verification_status === 'Success') {
                          showJobAlertTrigger = true;
                        }
                        break;
                      //no default
                    }
                  });
                  return showJobAlertTrigger;
                }
              })    
            }
          }
        )
      },
      getSyncAccounts : (accountType) => {
        return authService.getToken().then(
          token => {
            if (token) {
              const url = `${window.appConfig.MESSAGING_URL}api/v1/users/current-user/email-accounts`;
              const headers = {
                Authentication: token,
              };
              return $http({
                method: 'GET',
                url,
                headers,
              }).then((response) => {
                if(response.status === 200) {
                  const userSyncAccounts = response.data;                  
                  return accountType ? userSyncAccounts[accountType] : userSyncAccounts;
                }
              }); 
            }
          }
        )
      },
    }
  }

angular.module('shared-components')
    .service('userSyncStateService', userSyncStateService);
  userSyncStateService.$inject = ['$rootScope', '$http', 'authService',];
}(angular));