(function (angular) {
  function userAccountsServiceCtrl(
    $rootScope, $window, $q, $http, $cookies, storageService, authService, tmhDynamicLocale,
    inventoryService, utils, _,
  ) {
    function setCurrentUserAccount(response) {
      storageService.removeItem('duplicated_login');
      const { account } = response.data;
      const tokenData = authService.parseJwt(storageService.getCookieByName('jwtToken'));
      $rootScope.account_type = account.account.type;
      $rootScope.user_email = tokenData.email;
      $rootScope.first_login = response.data.is_first_login;
      storageService.setItem('account_type', account.account.type);
      storageService.setItem('account_id', account.account.id);
      storageService.setItem('account_role', account.role_id);
      storageService.setItem('user_email', tokenData.email);
      storageService.setItem('userId', account.user_id);
    }

    function setCurrentUserPreferences() {
      // language set-up
      const urlParamLanguage = utils.getUrlParam('lang');
      const currentLangage = storageService.getItem('currentLanguage');
      // check browser language
      const browserLanguage = window.navigator.userLanguage || window.navigator.language || window.navigator.browserLanguage || window.navigator.systemLanguage;
      // set language with the following priorities: URL > localstorage > browser > default English
      $rootScope.language = urlParamLanguage || (currentLangage || browserLanguage || 'en');
      // eliminate outliers
      if ($rootScope.language.includes('fr')) {
        $rootScope.language = 'fr';
      } else {
        $rootScope.language = 'en';
      }
      $rootScope.langLabel = $rootScope.language === 'en' ? 'Français' : 'English';
      storageService.setItem('currentLanguage', $rootScope.language);
      tmhDynamicLocale.set($rootScope.language);

      // moved agency set up to inventoryService temp
      inventoryService.setAgencyCookies();
    }

    function setCurrentUserPermissions(userAccountInfo) {
      $rootScope.currentUser.permissions = {
        isCandidate: userAccountInfo.account_role === 70,
        isAgency: userAccountInfo.account_type === 'agency',
        isClient: userAccountInfo.account_type === 'client',
        isEmployer: !!([50, 60].includes(userAccountInfo.account_role) && userAccountInfo.account_type === 'company'),
        isRecruiter: !!([10, 20, 30, 80].includes(userAccountInfo.account_role) && ['company', 'agency'].includes(userAccountInfo.account_type)),
        isDeptMgrRecruiter: userAccountInfo.account_role === 10,
        isRegularRecruiter: userAccountInfo.account_role === 20,
        isAdminRecruiter: userAccountInfo.account_role === 30,
        isSuperUser: userAccountInfo.account_role === 50,
        isUserManager: userAccountInfo.account_role === 80,
        isAdmin: !![30, 50, 60, 100].includes(userAccountInfo.account_role),

        // @todo check
        isATSFull: userAccountInfo.account_role !== 70 ? 'ATS Full' : null,
        atsFullAndAdmin: !![30, 50, 60, 100].includes(userAccountInfo.account_role),
        isWorkland: userAccountInfo.userId === 642,
        isWorklandEmployer: !!(userAccountInfo.userId === 642 && [50, 60, 100].includes(userAccountInfo.account_role)),
        is_workland_employee: !!(userAccountInfo.account_id === 336 && [10, 20, 30, 80].includes(userAccountInfo.account_role)),
        hasCompanyAccess: !!([20, 30, 50].includes(userAccountInfo.account_role) && userAccountInfo.account_type === 'company'),
        isInternalEmployee: +userAccountInfo.account_role === 70 ? !!$rootScope.currentUser.account.detail[0]?.is_internal : false,
      };
    }

    function getCurrentUserData() {
      // @todo add fallback on cookie, and check before to call this
      const userAccountInfo = getAccountInfo();
      setCurrentUserPreferences();

      if (isUserDefined(userAccountInfo)) {
        $rootScope.account_role = userAccountInfo.account_role;
        $rootScope.account_type = userAccountInfo.account_type;
        $rootScope.userId = userAccountInfo.userId;
        $rootScope.account_id = userAccountInfo.account_id;
        $rootScope.currentUser = {
          profile_page: [{}],
          account: {
            detail: [{}],
          },
          account_user: [
            { user: {} },
          ],
        };

        const promises = [];
        promises.push(
          getAccountData(userAccountInfo),
          getUserData(userAccountInfo),
        );
        if (userAccountInfo.account_type === 'client') {
          promises.push(getAgencyAccountId(userAccountInfo));
        }

        if (userAccountInfo.account_type === 'client' || ((userAccountInfo.account_type === 'company' || userAccountInfo.account_type === 'agency') && [10, 20, 30, 80].includes(userAccountInfo.account_role))) {
          promises.push(getOwnerOfAccount());
        }

        const promisesArray = [];
        return $q.all(promises).then((responses) => {
          if (_.findIndex(responses, (res) => !res) < 0) {
            setCurrentUserPermissions(userAccountInfo);
            if (userAccountInfo.account_type === 'client') {
              inventoryService.checkInventory();
            }

            const userPhone = storageService.getItem('user_phone');
            if (userPhone) {
              addPhoneToProfile(userAccountInfo.userId, userPhone);
            }

            const urlParams = storageService.getCookieByName('urlParams');
            if (urlParams) {
              storageService.removeCookieByName('urlParams');
              if (storageService.getCookieByName('microsoftToken')) storageService.removeCookieByName('microsoftToken');
              promisesArray.push(getSocialToken(JSON.parse(urlParams)));
            }

            $rootScope.currentUser.location = null;
            const locationId = storageService.getItem('account_type') === 'candidate'
              ? $rootScope.currentUser.account_user[0].contact.location_id
              : $rootScope.currentUser.profile_page[0].location_id;
            if ($rootScope.currentUser && locationId) {
              const promise = getCurrentUserLocation(locationId).then((response) => {
                if (response.status == 200) {
                  $rootScope.currentUser.location = response.data[locationId];
                }
              });
              promisesArray.push(promise);
            }

            if (promisesArray.length > 0) {
              return $q.all(promisesArray).then(() => {return $rootScope.currentUser});
            } else {
              return $rootScope.currentUser;
            }
          }

          $rootScope.currentUser = null;
          return false;
        });
      }

      $rootScope.currentUser = null;
      return false;
    }

    function getAccountData(userAccountInfo) {
      let urlAction;
      switch (userAccountInfo.account_role) {
        case 70:
          urlAction = 'accounts/candidates/';
          break;
        case 100:
          urlAction = 'accounts/agencies/';
          break;
        case 40:
          urlAction = 'accounts/clients/';
          break;
        default:
          if (userAccountInfo.account_type == 'company') {
            urlAction = 'accounts/companies/';
          } else {
            urlAction = 'accounts/agencies/';
          }
      }

      return userAccountsGet(urlAction + userAccountInfo.account_id).then((res) => {
        const response = res.data;
        if (response.status === 'success') {
          $rootScope.currentUser.account = response.data.account;
          $rootScope.currentUser.account_user = response.data.account_user;
          if (response.data.profile_page) {
            $rootScope.currentUser.profile_page = response.data.profile_page;
          }
          return true;
        }
        return false;
      }).catch(() => false);
    }

    function getUserData(userAccountInfo) {
      return userAccountsGet(`users/${userAccountInfo.userId}`).then((res) => {
        const response = res.data;
        if (response.status === 'success') {
          $rootScope.currentUser.user = response.data;
          return true;
        }
        return false;
      }).catch(() => false);
    }

    function getAgencyAccountId(userAccountInfo) {
      $rootScope.agencyAccountId = null;
      return userAccountsGet(`accounts/clients/${userAccountInfo.account_id}/agency-account-id`).then((res) => {
        const response = res.data;
        if (response.status === 'success') {
          $rootScope.agencyAccountId = response.data;
          inventoryService.setAgencyMode(response.data);
          return true;
        }
        return false;
      }).catch(() => false);
    }

    function getAccountInfo() {
      return {
        userId: +storageService.getItem('userId'),
        account_role: +storageService.getItem('account_role'),
        account_type: storageService.getItem('account_type'),
        account_id: +storageService.getItem('account_id'),
      };
    }

    function getCurrentUserLocation(jobLocationId) {
      // @temp - to be moved on api (we need to get rid of ngUserService before)
      return authService.getToken().then(
        (token) => {
          const config = {};
          if (token) {
            config.headers = {
              Authorization: `Bearer ${token}`,
            };
          }
          return $http.get(`${$window.appConfig.SHARED_APIS_URL}api/v1/location/list-by-key-and-values?key=id&values[]=${jobLocationId}`, config);
        },
        (err) => err,
      );
      // -- temp end
    }

    function isUserDefined(user) {
      return user.userId
          && user.account_id
          && user.account_type
          && user.account_role;
    }

    function userAccountsGet(urlAction, urlParams = null) {
      return authService.getToken().then(
        (token) => {
          let headers = {};
          if (token) {
            headers = {
              Authorization: `Bearer ${token}`,
            };
          }
          return $http({
            method: 'GET',
            url: `${$window.appConfig.USER_ACCOUNTS_URL}api/v1/${urlAction}`,
            headers,
            params: urlParams,
          });
        },
        (err) => err,
      );
    }

    function userAccountsPostOrPut(urlAction, data, update) {
      return authService.getToken().then(
        (token) => {
          const config = {};
          if (token) {
            config.headers = {
              Authorization: `Bearer ${token}`,
            };
          }

          return update
            ? $http.put(`${$window.appConfig.USER_ACCOUNTS_URL}api/v1/${urlAction}`, data, config)
            : $http.post(`${$window.appConfig.USER_ACCOUNTS_URL}api/v1/${urlAction}`, data, config);
        },
        (err) => err,
      );
    }

    function getOwnerOfAccount() {
      const accountId = storageService.getItem('account_id');
      return userAccountsGet(`accounts/owner/${accountId}`).then((res) => {
        const response = res.data;
        if (response.status === 'success') {
          $rootScope.employerId = response.data.user_id;
          return true;
        }
        return false;
      }).catch(() => false);
    }

    function addPhoneToProfile(userId, userPhone) {
      userAccountsPostOrPut(`users/${userId}`, { phone: userPhone }, true).then((response) => {
        if (response.status === 200) {
          $rootScope.currentUser.user.phone = userPhone;
          storageService.removeItem('user_phone');
        }
      });
    }

    function getSocialToken(urlParams) {
      return userAccountsGet('auth/social-login/microsoft/callback', urlParams).then((response) => {
        const loginResponse = response.data;
        if (loginResponse && loginResponse.status == 'success' && loginResponse.data && loginResponse.data.microsoft_token) {
          const microsoftToken = _.pick(loginResponse.data.microsoft_token, 'access_token', 'exp', 'refresh_token', 'scope');
          if (loginResponse.data?.microsoft_organization_account_ids?.length > 0) {
            microsoftToken.microsoft_organization_account_ids = loginResponse.data.microsoft_organization_account_ids;
          }
          storageService.setCookie('microsoftToken', JSON.stringify(microsoftToken));
          return true;
        } else {
          $rootScope.currentUser.socialTokenError = 'fetching_microsoft_token_failed';
          return true;
        }
      }).catch(() => {
        $rootScope.currentUser.socialTokenError = 'fetching_microsoft_token_failed';
        return false;
      });
    }

    // these are the functions that are accessible from outside
    const obj = {
      setCurrentUserAccount,
      getCurrentUserData,
      getAccountInfo,
      getUserData,
    };
    return obj;
  }

  angular.module('shared-components').service('userAccountsService', userAccountsServiceCtrl);

  userAccountsServiceCtrl.$inject = [
    '$rootScope', '$window', '$q', '$http', '$cookies', 'storageService', 'authService', 'tmhDynamicLocale',
    'inventoryService', 'utils', '_'];
// eslint-disable-next-line no-undef
}(angular));
