(function (angular) {
  function apiFactory(
    $rootScope,
    $http,
    $q,
    utils,
    Event,
    worklandLocalize,
    localStorageService,
    authService,
    userAccountsService,
  ) {
    const { ajaxUrl } = worklandLocalize;
    const toolkitUrl = `${window.appConfig.TOOLKIT_URL}api/v1/`;
    const sharedServiceUrl = `${window.appConfig.SHARED_APIS_URL}api/v1/`;
    const workflowUrl = `${window.appConfig.WORKFLOW_URL}api/v1/`;
    const jobsServiceUrl = `${window.appConfig.JOBS_URL}api/v1/`;
    const accountsServiceUrl = `${window.appConfig.USER_ACCOUNTS_URL}api/v1/`;
    const marketplaceApiUrl = `${window.appConfig.MARKETPLACE_URL}api/v1/`;
    const diffusionUrl = `${window.appConfig.DIFFUSION_URL}api/v1/`;
    const reportingUrl = `${window.appConfig.REPORTING_URL}api/v1/`;
    const roleApiUrl = window.appConfig.AUTHORIZATION_URL;
    const indexingApiUrl = `${window.appConfig.INDEXING_URL}api/v1/`;
    const applicationServiceUrl = `${window.appConfig.APPLICATION_URL}api/v1/`;
    const substituteTeacherUrl = `${window.appConfig.SUBSTITUTE_TEACHER_URL}api/v1/`;
    const messagingUrl = `${window.appConfig.MESSAGING_URL}api/v1/`;
    const variablesUrl = `${window.appConfig.VARIABLES_URL}api/v1/`;
    const calendarServiceUrl = `${window.appConfig.CALENDAR_URL}api/v1/`;
    const eSigningUrl = `${window.appConfig.E_SIGNING_URL}api/v1/`;


    const obj = {
      query,
      toolkit_batch,
      toolkit_fileupload,
      messaging_fileupload,
      service_query,
      service_get,
      service_post,
      service_delete,
      tag,
      applyListFilter,
      uploadResumeCRM,
      userAccountsFileUpload,
    };
    return obj;

    // @todo remove this query
    function query(action, data, logged_out) {
      return authService.getToken().then(
        (token) => {
          data = data || {};
          if (!logged_out) {
            // Must always be userId of the owner of the current profile
            if ($rootScope.currentUser && token) {
              if ($rootScope.currentUser.permissions.isRecruiter || $rootScope.currentUser.permissions.isClient) {
                data.userId = $rootScope.employerId;
              } else {
                data.userId = $rootScope.currentUser.user.id;
              }
            }
            data.accounts = {
              account_role: localStorageService.getItem('account_role'),
              account_type: localStorageService.getItem('account_type'),
              account_id: localStorageService.getItem('account_id'),
            };
          }

          if (token) {
            data.token = token;
          }
          const requestBody = utils.buildQueryStr({
            action,
            data: angular.toJson(data),
            worklandNonce: worklandLocalize.worklandNonce,
          });
          const config = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          };
          return $http.post(ajaxUrl, requestBody, config);
        },
      );
    }

    function toolkit_fileupload(url, data) {
      return authService.getToken().then(
        (token) => {
          const apiUrl = toolkitUrl + url;
          const formData = new FormData();
          angular.forEach(data, (value, key) => {
            formData.append(key, value);
          });

          const config = {
            headers: {
              'Content-Type': undefined,
              Accept: 'application/json',
            },
          };
          if (token) {
            data.token = token;
            config.headers.authentication = token;
          }
          return $http.post(apiUrl, formData, config);
        },
      );
    }

    function messaging_fileupload(url, data, emailComposer) {
      return authService.getToken().then(
        (token) => {
          const apiUrl = messagingUrl + url;
          let formData;
          if (emailComposer) {
            formData = data;
          } else {
            formData = new FormData();
            angular.forEach(data, (value, key) => {
              formData.append(key, value);
            });
          }
          const config = {
            headers: {
              'Content-Type': undefined,
              Accept: 'application/json',
            },
          };
          if (token) {
            data.token = token;
            config.headers.authentication = token;
          }
          return $http.post(apiUrl, formData, config);
        },
      );
    }

    function toolkit_batch(url, data, method) {
      return authService.getToken().then(
        (token) => {
          const apiUrl = toolkitUrl + url;
          const config = {
            headers: {
              'Content-Type': 'application/json',
              Accept: 'application/json',
            },
          };

          if (token) {
            config.headers.authentication = token;
          }

          switch (method) {
            case 'PUT':
              return $http.put(apiUrl, data, config);
              break;
            default:
              return $http.post(apiUrl, data, config);
          }
        },
      );
    }

    function getServiceApiUrl(service) {
      const lookup = {
        'jobs': jobsServiceUrl,
        'toolkit': toolkitUrl,
        'shared': sharedServiceUrl,
        'indexing': indexingApiUrl,
        'application': applicationServiceUrl,
        'workflow': workflowUrl,
        'accounts': accountsServiceUrl,
        'marketplace': marketplaceApiUrl,
        'reporting': reportingUrl,
        'diffusion': diffusionUrl,
        'authorization': roleApiUrl,
        'substituteTeacher': substituteTeacherUrl,
        'messaging': messagingUrl,
        'variables': variablesUrl,
        'calendar': calendarServiceUrl,
        'e-signing': eSigningUrl,
      }
      return lookup[service];
    }

    // Added by Sebastian - Start
    function service_query(service, url, action, data) {
      return authService.getToken().then(
        (token) => {
          let apiUrl = getServiceApiUrl(service);
          apiUrl += url;
          let headers = {};
          data = data || {};
          if (token) {
            if(service === 'accounts' || service === 'calendar') {
              headers = {
                'Authorization': 'Bearer ' + token
              };
            } else {
              headers = {
                'Authentication': token
              }
            }
            data.token = token;
          }
          return $http({
            method: action,
            url: apiUrl,
            headers: headers,
            data,
          });
        },
      );
    }

    function service_get(service, url, data) {
      return authService.getToken().then(
        (token) => {
          let apiUrl = getServiceApiUrl(service);
          apiUrl += url;
          let headers = {};
          if (token) {
            if(service === 'accounts' || service === 'calendar') {
              headers = {
                'Authorization': 'Bearer ' + token
              };              
            } else {
              headers = {
                'Authentication': token
              }
            }
          }
          return $http({
            method: 'GET',
            url: apiUrl,
            headers: headers,
            params: data,
          });
        },
      );
    }

    function service_post(service, url, data, update) {
      return authService.getToken().then(
        (token) => {
          let apiUrl = getServiceApiUrl(service);
          apiUrl += url;
          const config = {
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          };
          data = data || {};
          if (token) {
            if(service === 'accounts' || service === 'calendar') {
              config.headers.authorization = 'Bearer ' + token;
            } else {
              config.headers.authentication = token;
            }
            data.token = token;
          }
          if (update) {
            return $http.put(apiUrl, data, config);
          }
          return $http.post(apiUrl, data, config);
        },
      );
    }

    function service_delete(service, url, data) {
      return authService.getToken().then(
        (token) => {
          let apiUrl = getServiceApiUrl(service);
          apiUrl += url;
          const config = {
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            data,
          };
          if (token) {
            if(service === 'accounts' || service === 'calendar') {
              config.headers.authorization = 'Bearer ' + token;
            } else {
              config.headers.authentication = token;
            }
          }
          return $http.delete(apiUrl, config);
        },
      );
    }
    // Added by Sebastian - End

    //* **for making tag list///////////*****************

    // @todo remove this query after tag tests
    function tag(action, data) {
      return authService.getToken().then(
        (token) => {
          // Must always be userId of the owner of the current profile
          /* if ($rootScope.currentUser && token) {
            if ($rootScope.currentUser.user) {
              data.userId = $rootScope.currentUser.user.id;
            } else if ($rootScope.currentUser.employer.employerId) {
              data.userId = $rootScope.currentUser.employer.employerId;
            }
          } */

          if (token) {
            data.token = token;
          }
          const requestBody = utils.buildQueryStr({
            action,
            data: angular.toJson(data),
            worklandNonce: worklandLocalize.worklandNonce,
          });
          const config = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          };
          return $http.post(ajaxUrl, requestBody, config);
        },
      );
    }

    // applyListFilter => filterCandidateId, filterJobId, filterName, filterValue, action
    function applyListFilter(filterCandidateId, filterJobId, filterName, filterValue, action) {
      if (action === 'delete') {
        if (!confirm(utils.strings.confirmDelete)) {
          return;
        }
      }
      const params = {
        type: 'filter',
        action: action || 'update',
        filterName,
        filterValue,
        filterCandidateId,
        filterJobId,
      };
      const promise = query('update_user_data_by_id',
        params)
        .then((res) => {
          Event.broadcast('listFilterApplied', {
            message: res.data.message,
            data: res.data.data,
            filterName,
          });
        });
      return promise;
    }

    // @todo remove this query - used currently by CRM
    function uploadFile(action, files, data, callbacks, loggedOut) {
      return authService.getToken().then(
        (token) => {
          const promises = [];
          const info = {};
          if (!loggedOut && $rootScope.currentUser) {
            // @todo check if this query still needed and if it does, we need employerId and we don't have it - so a solution is needed
            info.userId = $rootScope.currentUser.user.id;
            /* if (token) {
              if ($rootScope.currentUser.permissions.isRecruiter) {
                info.userId = $rootScope.currentUser.employer.employerId;
              } else {
                info.userId = $rootScope.currentUser.user.id;
              }
            } */
          } else {
            info.userId = data.userId;
          }

          if (token) {
            info.token = token;
          }

          if (files && files.length) {
            for (let i = 0; i < files.length; i++) {
              const file = files[i];
              if (token) {
                data.token = token;
              }
              data.userId = info.userId;
              const toJson = JSON.stringify(data);
              const promise = $http({
                method: 'POST',
                url: ajaxUrl,
                headers: { 'Content-Type': undefined },
                data: {
                  action,
                  worklandNonce: worklandLocalize.worklandNonce,
                  file,
                  data: toJson,
                },
                transformRequest(data, headersGetter) {
                  const formData = new FormData();
                  angular.forEach(data, (value, key) => {
                    formData.append(key, value);
                  });
                  return formData;
                },
              }).then((response) => {
                callbacks.success(response);
              }, (response) => {
                callbacks.error(response);
              });
              promises.push(promise);
            }
          }
          return $q.all(promises);
        },
      );
    }

    /* @todo remove this query after tests
    function uploadDocument(action, files, data, callbacks, loggedOut) {
      return authService.getToken().then(
        (token) => {
          const promises = [];
          const info = {};
          if (!loggedOut) {
            if ($rootScope.currentUser && token) {
              if ($rootScope.currentUser.permissions.isRecruiter || $rootScope.currentUser.permissions.isClient) {
                info.userId = $rootScope.currentUser.employer.employerId;
              } else {
                info.userId = $rootScope.currentUser.user.id;
              }
            }
          } else {
            info.userId = data.userId ? data.userId : null;
          }

          if (token) {
            info.token = token;
          }

          if (files && files.length) {
            for (let i = 0; i < files.length; i++) {
              const file = files[i];
              if (token) {
                data.token = token;
              }
              data.userId = info.userId;
              var toJson = JSON.stringify(data);
              var promise = $http({
                method: 'POST',
                url: ajaxUrl,
                headers: { 'Content-Type': undefined },
                data: {
                  action,
                  worklandNonce: worklandLocalize.worklandNonce,
                  file,
                  data: toJson,
                },
                transformRequest(data, headersGetter) {
                  const formData = new FormData();
                  angular.forEach(data, (value, key) => {
                    formData.append(key, value);
                  });
                  return formData;
                },
              }).then((response) => {
                callbacks.success(response);
              }, (response) => {
                callbacks.error(response);
              });
            }
          } else if (files) {
            var toJson = JSON.stringify(data);
            var promise = $http({
              method: 'POST',
              url: ajaxUrl,
              headers: { 'Content-Type': undefined },
              data: {
                action,
                worklandNonce: worklandLocalize.worklandNonce,
                file: files,
                data: toJson,
              },
              transformRequest(data, headersGetter) {
                const formData = new FormData();
                angular.forEach(data, (value, key) => {
                  formData.append(key, value);
                });
                return formData;
              },
            })
              .then((response) => {
                callbacks.success(response);
              }, (response) => {
                callbacks.error(response);
              });
          }
          promises.push(promise);
          return $q.all(promises);
        },
      );
    } */

    function userAccountsFileUpload(url, data) {
      return authService.getToken().then(
        (token) => {
          const apiUrl = accountsServiceUrl + url;

          const formData = new FormData();
          angular.forEach(data, (value, key) => {
            formData.append(key, value);
          });

          const config = {
            headers: {
              'Content-Type': undefined,
              Accept: 'application/json',
            },
          };
          if (token) {
            config.headers.Authorization = 'Bearer ' + token
          }
          return $http.post(apiUrl, formData, config);
        },
      );
    }

    // Adding the Resume for CRM
    function uploadResumeCRM(resumes, data, callbacks, loggedOut) {
      return uploadFile('hh_upload_crm_resume', resumes, data, callbacks, loggedOut);
    }

  }
  apiFactory.$inject = [
    '$rootScope',
    '$http',
    '$q',
    'utils',
    'Event',
    'worklandLocalize',
    'localStorageService',
    'authService',
    'userAccountsService',
  ];
  angular.module('shared-components')
    .factory('api', apiFactory)/* .config() */;
}(angular));
