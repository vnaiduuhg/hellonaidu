(function(angular) {
    function utilsFactory(
        $filter,
        $rootScope,
        $sce,
        $timeout,
        worklandLocalize,        
        _,
        $ngConfirm,
        ){

        var strings = worklandLocalize.strings;
        var obj = {
            strings,
            toDateObj,
            toDateStr,
            toMonthText,
            createDateRageArray,
            buildQueryStr,
            sortMultipleByDate,
            out,
            trustAsHtml,
            language: $rootScope.language,
            themeUrl: worklandLocalize.themeUrl,
            rootUrl: rootUrl(),
            arrayDifference,
            isDateExpired,
            initTimezone,
            utcToTimezone,
            dateObjToUTC,
            datetimeToUTC,
            formatDate,
            RemoveAccents,
            sortArray,
            removeURLParam,
            removeAllURLParam,
            getUrlParam,
            expirationAndValidationDate,
            sentAutoEmailStatus,
            formatDateWithTime,
            getSalaryFormat,
            addCommaForThousands,
            getTimeFormat,
            getDaysDifferenceBetweenDates,
            setLocationObject,
            getSeekingPositions,
            addTranslationsToMomentDate,
            hideClasses,
            clearCVTabMsg,
            showPdfFile,
            showNativePdfFile,
            showOfficeFile,
            showWebUrl,
            showImage,
            showTxtFile,
            resetViewers,
            genericConfirmMessage,
            isFileFormatValid,
            isFileSizeValid,
            translateDocusignEnvelopesStatus,
        };

        obj.months = _.map(strings.months, function(monthName, monthValue) {
            return {
                value: parseInt(monthValue, 10),
                text: monthName
            };
        });

        obj.provinces = _.map(strings.provinces, function(provinceName, provinceValue) {
            return {
                value: provinceValue,
                text: provinceName
            };
        });

        obj.countries = _.map(strings.countries, function(countryName, countryValue) {
            return {
                value: countryValue,
                text: countryName
            };
        });

        obj.years = createYearsArr(1950);

        return obj;

        // function for dynamic sorting
        function sortArray(key, order) {
            if (!order) order = 'asc';
            return function(a, b) {
                if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
                    // property doesn't exist on either object
                    return 0;
                }

                const varA = (typeof a[key] === 'string') ? a[key].toUpperCase() : a[key];
                const varB = (typeof b[key] === 'string') ? b[key].toUpperCase() : b[key];

                let comparison = 0;
                if (varA > varB) {
                    comparison = 1;
                } else if (varA < varB) {
                    comparison = -1;
                }
                return (order == 'desc') ? (comparison * -1) : comparison;
            };
        }

        function out(fr, en, force) {
            var lang = force || $rootScope.language;
            return lang === 'en' ? en : fr;
        }

        function trustAsHtml(string) {
            if (!angular.isString(string)) {
                // console.warn(string);
                return '';
            }
            return $sce.trustAsHtml(string);
        }

        //dataStr format yyyy-MM-dd e.g. 2000-01-31
        function toDateObj(dataStr) {
            var dateTimeSplit = dataStr.split(' ');
            var dateSplit = dateTimeSplit[0].split('-');
            var date = new Date(dateSplit[0], dateSplit[1] - 1, dateSplit[2]);
            if (dateTimeSplit.length > 1) {
                var timeSplit = dateTimeSplit[1].split(':');
                date.setHours(timeSplit[0]);
                date.setMinutes(timeSplit[1]);
                date.setSeconds(timeSplit[2]);
            }
            return date;
        }

        function createYearsArr(min, max) {
            max = max || new Date().getFullYear();
            var yearsArr = [];
            while (max >= min) {
                yearsArr.push({
                    value: max,
                    text: max
                });
                max--;
            }
            return yearsArr;
        }

        function sortMultipleByDate(entry) {
            // if empty means present so we set year to a high value

            var year1 = Number(entry.year1comp) || 1000,
                month1 = Number(entry.month1comp) ? Number(entry.month1comp) - 1 : 0,
                year2 = Number(entry.year2comp) || 3000,
                month2 = Number(entry.month2comp) ? Number(entry.month2comp) - 1 : 11,
                startDate = new Date(year1, month1),
                endDate = new Date(year2, month2);
            var timeOrder = (endDate.getTime() * 10) - startDate.getTime();

            return -timeOrder;
        }

        function createDateRageArray(startDate, endDate, interval, format) {
            startDate = angular.copy(startDate);
            endDate = angular.copy(endDate);
            interval = interval || 1;
            var retVal = [];

            while (startDate <= endDate) {
                retVal.push(angular.copy(startDate));
                startDate.setDate(startDate.getDate() + interval);
            }

            retVal = _.map(retVal, function(date) {
                return toDateStr(date, format);
            });

            return retVal;
        }

        function toDateStr(jsDateObj, format) {
            format = format || 'yyyy-MM-dd';
            if (!_.isDate(jsDateObj)) {
                return false;
            }
            return $filter('date')(jsDateObj, format);
        }

        function toMonthText(month) {

            var monthName = '';

            if (month >= 1 && month <= 12) {

                monthName = obj.months[month - 1].text;
            }
            return monthName;
        }

        function buildQueryStr(obj) {
            return _.reduce(obj,
                function(components, value, key) {
                    components.push(key + '=' + encodeURIComponent(value));
                    return components;
                },
                []
            ).join('&');
        }

        function rootUrl() {
            var idx = worklandLocalize.themeUrl.indexOf('/wp-content');
            return worklandLocalize.themeUrl.substring(0, idx);
        }

        function arrayDifference(first, second, predicate) {
            if (!first) {
                return [];
            } else if (!second || second.length === 0) {
                return first;
            }
            var diff = _.filter(first, function(itemFirst) {
                var indx = _.findIndex(second, function(itemSecond) {
                    return predicate(itemFirst, itemSecond);
                })
                return (indx < 0);
            });
            return diff;
        }

        // @added this function because isDateExpired() doesn't give the right result in all cases
        function expirationAndValidationDate(date, days_offset) {

            var now = new Date();
            // if days offset to add
            var date_offset = days_offset > 0 ? now.setDate(now.getDate() + days_offset) : now.setDate(now.getDate());
            // timezone offset in milliseconds to get raw value
            var timezone_offset = now.getTimezoneOffset() * 60 * 1000;
            if (timezone_offset > 0) {
                date_offset -= timezone_offset;
            } else {
                date_offset += timezone_offset;
            }

            // date that we compare must be timezone raw value
            var expiryDate = new Date(date);

            if (expiryDate != 'Invalid date') {
                if (date_offset < expiryDate.getTime()) {
                    return false;
                }
            }
            return true;
        }

        function isDateExpired(date, localTime) {
            // this function compares the raw timestamp (YYYY-MM-DD hh:mm:ss) with current time
            var now = new Date();
            var expiryDate = new Date(date);
            if (!localTime) {                
                // the now time is local timezone but database time is GMT, so we must adjust for that when comparing
                return ((now.getTime() + now.getTimezoneOffset() * 60000) > expiryDate.getTime());
            } else {
                // when want to know if local timezone date is expired
                return (now.getTime() > expiryDate.getTime());
            }
        }

        /**
         * this function requires momentJS dependencies
         * timzone_value should be raw PHP timezone
         * @return          timezone object
         */
        function initTimezone() {

            moment.locale(out('fr-ca', 'en'));

            let timezone = [];
            const label = moment.tz.guess();
            const currentTime = moment();
            timezone.label = label ? label + ' | ' + moment.tz(currentTime, label).format("z") : out('Défaut', 'Default');

            return timezone;
        }

        /**
         * this function requires momentJS dependencies
         * @param {string} datetime     raw datetime string and a timezone string
         * @param {string} format       format specifies what format the date should be returned in
         * @return                      returns a string or Date obj
         */
        function utcToTimezone(datetime, format) {

            var convertedDate = '';
            var dateTimeMoment = moment.tz(datetime, "UTC");
            convertedDate = moment.utc(dateTimeMoment).local();

            var result = '';
            if (format == 'obj') {
                result = new Date(convertedDate.format('YYYY-MM-DD HH:mm:ss'));
            } else if (format == 'formatted') {
                result = convertedDate.format('LLL');
            } else if (format == 'zoozle') {
                var zoozle = [];
                zoozle['date'] = convertedDate.format('YYYY-MM-DD');
                zoozle['time'] = convertedDate.format('HH:mm:ss');
                return zoozle;
            } else if (format == 'enOrFrWithoutSeconds') {
                result = {
                    'en': convertedDate.format('YYYY-MM-DD HH:mm'),
                    'fr': convertedDate.format('DD-MM-YYYY HH:mm')
                };
            } else {
                result = convertedDate.format('YYYY-MM-DD HH:mm:ss');
            }
            return result;
        }

        /**
         * The function convert a date object into string (current timezone)
         * @param {obj} jsDateObj   Date object which does not take into account timezone
         * @return                  Date string format
         */
        function dateObjToUTC(jsDateObj) {

            // first make sure it's a Date obj
            if (!_.isDate(jsDateObj)) {
                return false;
            }

            // convert Date obj to string of format YYYY-MM-DD HH:mm:ss
            var dateTimeString = toDateStr(jsDateObj) + ' ' + toDateStr(jsDateObj, 'HH:mm:ss');
            // create moment & convert to UTC timezone
            var dateTimeMoment = moment(dateTimeString);
            var convertedDate = dateTimeMoment.utc();

            return convertedDate.format('YYYY-MM-DD HH:mm:ss');
        }

        /**
         * this function should receive a string datetime of the format YYYY-MM-DD HH:mm:ss
         * @param {string}  datetime
         * @param {string}  format
         * @return          Date string format
         */
        function datetimeToUTC(datetime, format) {

            // create moment & convert to UTC timezone
            var dateTimeMoment = moment(datetime);
            var convertedDate = dateTimeMoment.utc();

            // check format and return the string result
            if (format == 'zoozle') {
                var zoozle = [];
                zoozle['date'] = convertedDate.format('YYYY-MM-DD');
                zoozle['time'] = convertedDate.format('HH:mm:ss');
                return zoozle;
            } else {
                return convertedDate.format('YYYY-MM-DD HH:mm:ss');
            }
        }

        function formatDate(date) {
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;

            return [year, month, day].join('-');
        }

        // timeFormat should be HH:mm:ss || HH:mm || HH
        function formatDateWithTime(date, timeFormat) {
            var d = new Date(date),
                seconds = d.getSeconds(),
                minutes = d.getMinutes(),
                hours = d.getHours(),
                day = '' + d.getDate(),
                month = '' + (d.getMonth() + 1),
                year = d.getFullYear();

            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;

            var time = '';
            if (timeFormat.search('HH')) {
                if (hours.length < 2) hours = '0' + hours;
                time = hours;
            }
            if (timeFormat.search('mm')) {
                if (minutes.length < 2) minutes = '0' + minutes;
                time = [time, minutes].join(':');
            }
            if (timeFormat.search('ss')) {
                if (seconds.length < 2) seconds = '0' + seconds;
                time = [time, seconds].join(':');
            }
            var finalDate = {
                'en': [year, month, day].join('-') + ' ' + time,
                'fr': [day, month, year].join('-') + ' ' + time
            }

            return finalDate;
        }

        //removes all the accents of the input string
        function RemoveAccents(strAccentsin) {
            var strAccents = strAccentsin.split('');
            var strAccentsOut = new Array();
            var strAccentsLen = strAccents.length;
            var accents = 'ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž';
            var accentsOut = "AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz";
            for (var y = 0; y < strAccentsLen; y++) {
                if (accents.indexOf(strAccents[y]) !== -1) {
                    strAccentsOut[y] = accentsOut.substr(accents.indexOf(strAccents[y]), 1);
                } else
                    strAccentsOut[y] = strAccents[y];
            }
            strAccentsOut = strAccentsOut.join('');
            return strAccentsOut;
        }

        function removeURLParam(url, parameter) {
            //prefer to use l.search if you have a location/link object
            var urlparts = url.split('?');
            if (urlparts.length >= 2) {

                var prefix = encodeURIComponent(parameter) + '=';
                var pars = urlparts[1].split(/[&;]/g);

                //reverse iteration as may be destructive
                for (var i = pars.length; i-- > 0;) {
                    //idiom for string.startsWith
                    if (pars[i].lastIndexOf(prefix, 0) !== -1) {
                        pars.splice(i, 1);
                    }
                }

                return urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : '');
            }
            return url;
        }

        function removeAllURLParam(oldURL) {
            var index = 0;
            var newURL = oldURL;
            index = oldURL.indexOf('?');
            if (index == -1) {
                index = oldURL.indexOf('#');
            }
            if (index != -1) {
                newURL = oldURL.substring(0, index);
            }
            return newURL;
        }

        function getUrlParam(name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
            if (results == null) {
                return null;
            }
            return decodeURI(results[1]) || 0;

        }

        /*
         * params       msg                 <string>
         * params       candidates_status   <object>
         */
        function sentAutoEmailStatus(msg, candidates_status) {

            var results = {
                msgEn: '',
                msgFr: '',
                sendEmailSuccess: [],
                sendEmailfail: []
            };

            if (msg) {
                switch (msg) {
                    case 'automated_messages_done':
                        _.each(candidates_status, function(value, key) {
                            return !value ? results.sendEmailfail.push(+key) : results.sendEmailSuccess.push(+key);
                        })
                        break;
                    case 'nylas_auto_email_not_sync':
                        results.msgEn = 'Please make sure to synchronise your email with Nylas in order to be able to send automated messages to candidates';
                        results.msgFr = 'Veuillez vous assurer de synchroniser votre courriel avec Nylas afin de pouvoir envoyer des messages automatisés aux candidats';
                        break;
                    case 'template_not_enabled':
                        results.msgEn = 'Please make sure to enable the required automated messages in order to be able to send emails to candidates';
                        results.msgFr = 'Veuillez vous assurer d\’activer les messages automatisés requis afin d\'être en mesure d\'envoyer des messages courriels aux candidats'
                        break;
                    case 'no_email_to_be_sent':
                        // nothing todo
                        break;
                    case 'previous_task_failed':
                        // nothing todo - there is already a msg for this
                        break;
                    case 'error_setting_send_email_config':
                    case 'error_default_nylas_sync':
                    case 'error_fetching_user_account':
                    case 'error_fetching_employer_account':
                    case 'error_fetching_template':
                    default:
                        results.msgEn = 'An error has occurred, no automated messages could be sent. Please try later or contact Workland for Technical Support.';
                        results.msgFr = 'Une erreur est survenue, aucun message automatisé n\'a pu être envoyé. Veuillez réessayer plus tard ou contacter Workland pour le support technique.';
                        break;
                }
            }
            return results;
        }

        /*
         * description      gets an amount, format it with decimals and comma if needed
         * params           salary      <string | int>
         */
        function getSalaryFormat(salary) {
            var salary_formatted = (salary / 100).toFixed(2);
            // check if the amount needs comma (for thousands)
            const regex = /^(\d+)\.?\d{0,2}/g;
            const amount_matched = regex.exec(salary_formatted.toString());
            if (amount_matched[1].length > 3) {
                salary_formatted = addCommaForThousands(salary_formatted);
            }
            return salary_formatted;
        }

        function addCommaForThousands(amount) {
            return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        function genericConfirmMessage(type, title, content) {
          $ngConfirm({
            title: type === 'red' ? out('Erreur', 'Error') : title,
            content,
            type: type,
            buttons: {
              Ok: {
                text: out('Ok', 'Ok'),
                btnClass: 'btn btn-secondary',
                action() {

                },
              },
            },
          });
        }

        function getTimeFormat(date, preset) {
            const _date = {};
            moment.locale('en');
            _date.en = moment(date).format(preset);
            moment.locale('fr-ca');
            _date.fr = moment(date).format(preset);
            return _date;
        }

        function addTranslationsToMomentDate(date, preset) {
            const _date = {};
            const dateObj = moment(date).toDate();
            moment.locale('en');
            _date.en = moment(dateObj).format(preset);
            moment.locale('fr-ca');
            _date.fr = moment(dateObj).format(preset);
            return _date;
        }

        function getDaysDifferenceBetweenDates(firstDate, lastDate) {
            const oneDay = 24 * 60 * 60 * 1000;
            const _firstDate = new Date(firstDate).getTime();
            const _lastDate = new Date(lastDate).getTime();
            return Math.round((_lastDate - _firstDate) / oneDay);
        }

        function setLocationObject(location) {
            const address_components = {
                street_number: '',
                route: '',
                locality: '',
                administrative_area_level_1: '',
                country: '',
                postal_code: '',
            };
            let replacement = '';
            let arrayOfCityReplacement = [];

            const components = location.address_components;
            _.each(components, (c) => {
                switch (c.types[0]) {
                    case 'street_number':
                        address_components.street_number = c.long_name;
                        break;
                    case 'route':
                        address_components.route = c.long_name;
                        break;
                    case 'locality':
                        address_components.locality = c.long_name;
                        break;
                    case 'sublocality_level_1':
                        arrayOfCityReplacement.splice(0, 0, c.long_name);
                        break;
                    case 'sublocality_level_2':
                        arrayOfCityReplacement.push(c.long_name);
                        break;
                    case 'sublocality':
                        arrayOfCityReplacement.push(c.long_name);
                        break;
                    case 'neighborhood':
                        arrayOfCityReplacement.push(c.long_name);
                        break;
                    case 'administrative_area_level_3':
                        arrayOfCityReplacement.push(c.long_name);
                        break;
                    case 'administrative_area_level_1':
                        address_components.administrative_area_level_1 = c.long_name;
                        break;
                    case 'administrative_area_level_2':
                        replacement = c.short_name;
                        break;
                    case 'country':
                        address_components.country = c.long_name;
                        break;
                    case 'postal_code':
                        address_components.postal_code = c.long_name;
                        break;
                    default:
                        // no default case
                }
            });

            if (!address_components.locality) {
                address_components.locality = arrayOfCityReplacement.length ? arrayOfCityReplacement[0] : replacement;
            }
            if (!address_components.administrative_area_level_1) {
                address_components.administrative_area_level_1 = replacement;
            }

            const newLocation = {
                google_place_id: location.place_id ? location.place_id : '',
                latitude: location.geometry && location.geometry.location ? location.geometry.location.lat() : '',
                longitude: location.geometry && location.geometry.location ? location.geometry.location.lng() : '',
                postal_code: address_components.postal_code,
                street_number: address_components.street_number,
                translations: []
            };
            const locationTranslations = {
                street: address_components.route,
                city: address_components.locality,
                region: replacement ? replacement : '',
                province: address_components.administrative_area_level_1,
                country: address_components.country
            };
            newLocation.translations.push(locationTranslations, angular.copy(locationTranslations));
            newLocation.translations[0].locale = 'en';
            newLocation.translations[1].locale = 'fr';

            return newLocation;
        }

        function getSeekingPositions() {
            return [
                { key: 358, titleFr: "Position d'entrée", titleEn: 'Entry-level position' },
                { key: 357, titleFr: 'Professionnel', titleEn: 'Professional' },
                { key: 356, titleFr: 'Gestionnaire', titleEn: 'Manager' },
                { key: 355, titleFr: 'Directeur', titleEn: 'Director' },
                { key: 354, titleFr: 'Vice-président', titleEn: 'Vice-President' },
                { key: 353, titleFr: 'Président', titleEn: 'President' }
            ];
        }

        //Function document viewer
        function hideClasses() {
            for (let element of document.getElementsByClassName("docViewer")) {
                element.style.display = "none";
            }
            for (let element of document.getElementsByClassName("warningToSelectDoc")) {
                element.style.display = "none";
            }
        }

        function clearCVTabMsg() {
            $scope.uploadDocFail = false;
            $scope.noDocument = false;
        }

        function showPdfFile(document, container = window.document) {
            container.querySelector('#canvasContainer').innerHTML = "";
            var loadingTask = pdfjsLib.getDocument(document.url);
            loadingTask.promise.then(function(pdf) {
                var pagePromises = _.range(1, pdf.numPages + 1).map(function(number) {
                    return pdf.getPage(number);
                });
                return Promise.all(pagePromises);
            }).then(function(pages) {
                    var scale = 1.5;
                    var canvases = pages.forEach(function(page) {
                        var viewport = page.getViewport({ scale: scale, });
                        $("#canvasContainer").append("<canvas class='canvasClass' style='width:100%' id='canvas" + page._pageIndex + "'></canvas>");
                        var canvas = $(container).find('#canvas' + page._pageIndex)[0];
                        canvas.height = viewport.height;
                        canvas.width = viewport.width;
                        var canvasContext = canvas.getContext('2d');
                        var renderContext = {
                            canvasContext: canvasContext,
                            viewport: viewport
                        };
                        page.render(renderContext);

                        container.querySelector('#canvasContainer').appendChild(canvas);
                    });

                    container.querySelector('#canvasContainer').style.display = "block";
                },
                function(error) {
                    console.log('failed pdf');
                    container.querySelector('#canvasContainer').style.display = "none";
                    container.querySelector('#Enable-docViewer2').style.display = "block";
                });
                

        }

        function showWebUrl(url, container = window.document) {
            const urlIframe = container.querySelector('#webUrl');
            urlIframe.src = url;
            container.querySelector('#webUrl').style.display = "block";
        }
        
        function showNativePdfFile(document, container = window.document) {
            var docxIframe = container.querySelector('#MSDocx');
            docxIframe.src = document.url + '#toolbar=0&view=FitH';
            container.querySelector('#MSDocx').style.display = "block";
        }

        function showOfficeFile(document, container = window.document) {
            var docxIframe = container.querySelector('#MSDocx');
            var docxUrlCode = encodeURIComponent(document.url);
            docxIframe.src = 'https://view.officeapps.live.com/op/embed.aspx?src=' + docxUrlCode;
            container.querySelector('#MSDocx').style.display = "block";
        }

        function showImage(document, container = window.document) {
            container.querySelector('#image-candidate').src = document.url;
            container.querySelector('#image-candidate').style.display = "block";
        }

        function showTxtFile(document, container = window.document) {
            $('#textViewer').show();
            var output = container.querySelector('#viewerTextarea');
            $("#viewerTextarea").show();
            this.href = document.url;
            $.ajax(this.href).done(function(data) {
                output.textContent = data;
            });
        }

        function resetViewers(container = window.document) {
            container.querySelector('#canvasContainer').style.display = "none";
            container.querySelector('#MSDocx').style.display = "none";
            container.querySelector('#image-candidate').style.display = "none";
            container.querySelector('#viewerTextarea').style.display = "none";
            container.querySelector('#canvasContainer').innerHTML = "";
            container.querySelector('#MSDocx').src = "";
            container.querySelector('#image-candidate').src = "";
            container.querySelector('#viewerTextarea').textContent = "";
        }

        function isFileFormatValid(file, validFormats = ['pdf', 'doc', 'docx', 'rtf', 'txt']) {
            const ext = file.toLowerCase().split('.').pop();
            return validFormats.includes(ext);
        }

        // size in bytes, maxSize in MB
        function isFileSizeValid(size, maxSize = 5) {
            return (size > 0 && size / (1048576) <= maxSize);
        }

        function translateDocusignEnvelopesStatus(status) {
            let translatedStatus = {};
            switch (status) {
                case 'authoritativecopy':
                    translatedStatus = {
                        status: out("Copie autoritaire", "Authoritative copy"),
                        description: out("L'enveloppe est en état d'autorité. Seules les copies des documents seront affichées.",
                            "The envelope is in an authoritative state. Only copy views of the documents will be shown.")
                    };
                    break;
                case 'completed':
                    translatedStatus = {
                        status: out("Terminé", "Completed"),
                        description: out("L'enveloppe a été remplie par tous les destinataires.",
                            "The envelope has been completed by all the recipients.")
                    };
                    break;
                case 'correct':
                    translatedStatus = {
                        status: out("En correction", "In correction"),
                        description: out("L'enveloppe a été ouverte par l'expéditeur pour correction. Le processus de signature est arrêté pour les enveloppes ayant ce statut.",
                            "The envelope has been opened by the sender for correction. The signing process is stopped for envelopes with this status.")
                    };
                    break;
                case 'created':
                    translatedStatus = {
                        status: out("Ébauche", "Draft"),
                        description: out("L'enveloppe est à l'état de projet et n'a pas été envoyée pour être signée.",
                            "The envelope is in a draft state and has not been sent for signing.")
                    };
                    break;
                case 'declined':
                    translatedStatus = {
                        status: out("Refusé", "Declined"),
                        description: out("L'enveloppe a été refusée à la signature par l'un des destinataires.",
                            "The envelope has been declined for signing by one of the recipients.")
                    };
                    break;
                case 'delivered':
                    translatedStatus = {
                        status: out("Livré", "Delivered"),
                        description: out("Tous les destinataires ont visualisé le(s) document(s) dans une enveloppe via le site Web de signature DocuSign. Cela ne signifie pas que les documents ont été envoyés par courrier électronique dans une enveloppe.",
                            "All recipients have viewed the document(s) in an envelope through the DocuSign signing website. This does not indicate an email delivery of the documents in an envelope.")
                    };
                    break;
                case 'sent':
                    translatedStatus = {
                        status: out("Envoyé", "Sent"),
                        description: out("Une notification par courrier électronique contenant un lien vers l'enveloppe a été envoyée à au moins un destinataire.",
                            "An email notification with a link to the envelope has been sent to at least one recipient.")};
                    break;
                case 'signed':
                    translatedStatus = {
                        status: out("Signé", "Signed"),
                        description: out("L'enveloppe a été signée par tous les destinataires. Il s'agit d'un état temporaire pendant le traitement, après quoi l'enveloppe passe automatiquement à l'état terminé.",
                            "The envelope has been signed by all the recipients. This is a temporary state during processing, after which the envelope is automatically moved to completed status.")
                    }
                    break;
                case 'template':
                    translatedStatus = {
                        status: out("Modèle", "Template"),
                        description: out("L'enveloppe est un modèle.",
                            "The envelope is a template.")
                    };
                    break;
                case 'transfercompleted':
                    translatedStatus = {
                        status: out("Transfert effectué", "Transfer completed"),
                        description: out("L'enveloppe a été transférée de DocuSign à une autre autorité.",
                            "The envelope has been transferred out of DocuSign to another authority.")
                    };
                    break;
                case 'voided':
                    translatedStatus = {
                        status: out("Annulé ou expiré", "Voided or expired"),
                        description: out("L'enveloppe a été annulée par l'expéditeur ou a expiré. Le motif d'annulation indique si l'enveloppe a été annulée manuellement ou si elle a expiré.",
                            "The envelope has been voided by the sender or has expired. The void reason indicates whether the envelope was manually voided or expired.")
                    };
                    break;
                default:
                    translatedStatus = {
                        status: null,
                        description: out("Non disponible", "Not available"),
                    };
            }
            return translatedStatus;
        }
    }
    utilsFactory.$inject = [
        '$filter',
        '$rootScope',
        '$sce',
        '$timeout',
        'worklandLocalize',
        '_',
        '$ngConfirm',
    ];
    var app = angular.module( 'shared-components' );
    app.factory( 'utils', utilsFactory );
})(angular);
