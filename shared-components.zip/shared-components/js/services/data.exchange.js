( function ( angular ) {

    'use strict';
    var app = angular.module( 'shared-components' );

    var inject = [
        '$filter',
        'worklandLocalize',
        '_',
        dataExchange];


    app.factory( 'dataExchange', inject );

    function dataExchange(
            $filter,
            worklandLocalize,
            _ ) {


        var strings = worklandLocalize.strings;
        var obj = {
            putData: putData,
            getData: getData
        };

        
        function putData(job, key){
            obj[key] = job;
        }
        
        function getData(key, clean){
            var returningObj = obj[key];
            if(clean){
                obj[key] = null;
            }
            return returningObj;
        }

        return obj;
    }


} )( angular );