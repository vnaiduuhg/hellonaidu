( function ( angular ) {

    'use strict'; 

    angular.module('shared-components')
    .service('localStorageService', ['$window', 'utils', function($window, utils) {
        return {
            setItem: function(key, value){
                try {
                    $window.localStorage.setItem(key, value);
                } catch (e) {
                    if (e == QUOTA_EXCEEDED_ERR || e == NS_ERROR_DOM_QUOTA_REACHED || e == QuotaExceededError) {
                        alert(utils.out('Le quota de stockage est dépassé', 'Storage quota is exceeded'));
                    }
                }
            },
            setSessionItem: (key, value) => {
                $window.sessionStorage.setItem(key, value);
            },
            setCookie: function (key, value) {
                if (window.appConfig.APP_ENV == 'local') {
                    document.cookie = key + "=" + value + ";path=/";
                } else {
                    document.cookie = key + "=" + value + ";path=/;SameSite=Strict;Secure";
                }
            },
            getItem: function(key){
                return $window.localStorage.getItem(key);
            },
            getSessionItem: function(key){
                return $window.sessionStorage.getItem(key);
            },
            removeItem: function(key){
                $window.localStorage.removeItem(key);
            },
            removeSessionItem: function(key){
                $window.sessionStorage.removeItem(key);
            },
            getCookieByName: function(name) {
                return document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')?.pop() || null;
            },
            removeCookieByName: function(name) {
                document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            }
        };
    }]);

})(angular);