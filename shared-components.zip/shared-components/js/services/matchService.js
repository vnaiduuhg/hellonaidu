( function ( angular ) {
'use strict';

    angular.module('shared-components')
    .service('matchService', matchService);


    matchService.$inject = ['$q', '$http', '$window', 'authService'];

	function matchService($q, $http, $window, authService) {

        var obj = {
            getData: getData,
            postData: postData,
            delData: delData,
            updData: updData
        }
        return obj;

        function getData(path, obj){
          
            var defer = $q.defer();
            var url = $window.appConfig.MATCHING_URL + path;
            var data = obj;
            return authService.getToken().then(
                token => {
                    var config = {
                        params: data,
                        headers : {
                            'Authorization': 'Bearer '+token,
                            'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    };
                    $http.get(url, config).then(function(res) {
                        defer.resolve(res);
                    }, function(err){
                        defer.resolve(err);
                    });
                    return defer.promise;
                }, 
                err => {
                    return err
                }
            )
        }
            
        function postData(path, obj){
            var defer = $q.defer();
            var url = $window.appConfig.MATCHING_URL + path;
            var data = obj;
            return authService.getToken().then(
                token => {
                    var config = {
                        headers : {
                          'Authorization': 'Bearer '+token,
                          'Content-Type': 'application/json'
                        }
                    };
                    $http.post(url, data, config).then(function(res) {
                        defer.resolve(res);
                    }, function(err){
                       defer.resolve(err);
                    });
                    return defer.promise;
                }, 
                err => {
                    return err
                }
            )
        }

        function delData(path, obj){

            var defer = $q.defer();
            var url = $window.appConfig.MATCHING_URL + path;
            var data = obj;
            return authService.getToken().then(
                token => {
                    var config = {
                        params: data,
                        headers : {
                          'Authorization': 'Bearer '+token,
                          'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    };
                    $http.delete(url, config).then(function(res) {
                        defer.resolve(res);
                    }, function(err){
                        defer.resolve(err);
                    });
                    return defer.promise;
                }, 
                err => {
                    return err
                }
            )
        }

        function updData(path, obj){

            var defer = $q.defer();
            var url = $window.appConfig.MATCHING_URL + path;
            var data = obj;
            return authService.getToken().then(
                token => {
                    var config = {
                        headers : {
                            'Authorization': 'Bearer '+token,
                            'Content-Type': 'application/json'
                        }
                    };
        
                    $http.put(url, data, config).then(function(res) {
                        defer.resolve(res);
                    }, function(err){
                        defer.resolve(err);
                    });
                    return defer.promise;
                }, 
                err => {
                    return err
                }
            )
        }
    }

})(angular);