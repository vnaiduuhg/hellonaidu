(function (angular) {
    'use strict';
    angular.module('shared-components')
            .service('ngUserService', userService);

    userService.$inject = ['userAccountsService'];

    function userService(userAccountsService) {

        // @temp
        return userAccountsService.getCurrentUserData();
    }
})(angular);
