(function (angular) {

    'use strict';// used to transfer data from a directive/controller to another

    angular.module('shared-components')
    .factory('transferer', function() {
            var data = {};
    
            var transferer = {
                setData: setData,
                getData: getData,
                addProperty : addProperty,
                removeProperty : removeProperty,
                data: data
            };

            return transferer;

            function getData() {
                return transferer.data;
            };

            function setData(p_data) {
                transferer.data = p_data;
            };

            function addProperty(key, value){
                transferer.data[key] = value;
            };

            function removeProperty(key){
                delete transferer.data[key];
            };
            
            function destroy(){
                transferer.data = {};
            }

    });
})(angular);
