( function ( angular ) {
'use strict';

    var app = angular.module( 'shared-components' );

    app.factory('Translation', translationFactory);

    translationFactory.$inject = ['$resource'];

    function translationFactory( $resource ) {
        
        return $resource('./../shared-components/json/translations/:urlName.json', {urlName: 'urlName'}, {  
            query: {
                method: 'GET',
                params: {}
            }
        }); 
    }

    app.service( 'translationService', ['Translation', '$rootScope', '$q', function(Translation, $rootScope, $q) {

        var obj = {
            translate: translate,
            translateReportProfile: translateReportProfile
        }
        return obj;
        

        function translate(fr, en) {
            var lang = $rootScope.language;
            return lang === 'en' ? en : fr;
        }

        function translateReportProfile(reportType) {

            var defer = $q.defer();
            var urlName = {
                'urlName': reportType
            };

            Translation.query(urlName).$promise.then(function(response) {

                defer.resolve(response);
            });
            return defer.promise;
        }

    }]);

})(angular);