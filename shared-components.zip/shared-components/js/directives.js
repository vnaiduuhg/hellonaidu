// workland.js directives
( function ( angular ) {
    'use strict';

    var app = angular.module( 'shared-components' );
    //not used
/*
    app.directive( 'fallbackSrc', function () {
        var fallbackSrc = {
            link: function ( scope, iElement, iAttrs ) {
                iElement.bind( 'error', function () {
                    angular.element( this ).attr( "src", iAttrs.fallbackSrc );
                } );
            }
        };
        return fallbackSrc;
    } );

    app.directive( 'attachHtml', function ( $compile ) {
        return {
            scope: {
                attachHtml: '@'
            },
            link: function ( scope, element, attrs ) {
                scope.$watch( 'attachHtml', function () {
                    //clear
                    element.html( "" );
                    //fill
                    element.html( $compile( scope.attachHtml )( scope.$parent ) );
                } );
            }
        };
    } );*/
    //used to disable button while promise is being sent; 
    //need to return promise in the api call.
    app.directive( 'ajaxButton', function () {
        return {
            restrict: 'EA',
            scope: {
                click: '&'
            },
            link: function ( scope, iElement ) {
                iElement.on( 'click', function () {

                    var promise = scope.click();
                    if ( !promise ) {
                        return;
                    }
                    iElement.prop( 'disabled', true );
                    promise.finally( function () {
                        iElement.prop( 'disabled', false );
                    } );
                } );
            }
        };
    } );
    //used in the hidden part of diffusion settings
    /*
    app.directive( 'ajaxSlider', ['utils', function (utils) {
        var template = "";
        template += "<label class='pull-right switcher-control' ng-style='diffuseAllFlag && {\"margin-bottom\": \"-6px\"}'>";
        template += "<label class='pull-left' style='padding-right: 5px;padding-top: 1px;' ng-if='diffuseAllFlag'>"+utils.out('Tout diffuser','Diffuse All')+":<\/label>";
        template += "<input type='checkbox' ng-model='bindItem' ng-true-value='\"1\"' ng-false-value='\"0\"' ng-disabled='bindItem != 1 && bindLanguages && bindLanguages.fr == 0 && bindLanguages.en == 0' \/>";
        template += "<span>&nbsp;<\/span>";
        template += "<\/label>";
        template += "<\/br ng-if='diffuseAllFlag'>";
        template += "<label class='pull-right' ng-if='bindLanguages' ng-style='diffuseAllFlag && {\"padding-left\": \"5px\",\"padding-top\": \"0px\",\"padding-right\": \"15px\"} || {\"padding-left\": \"5px\", \"padding-top\": \"4px\", \"padding-right\": \"50px\"}'> EN";
        template += "<input type='checkbox' ng-model='bindLanguages.en' ng-true-value='\"1\"' ng-false-value='\"0\"' ng-disabled='!bindLanguages.enAvaiable || (!diffuseAllFlag && bindItem == 1 && bindLanguages.en == 1 && bindLanguages.fr == 0)' ng-click='clickLanguagesEn()' style='vertical-align: sub;' \/>";
        template += "<\/label>";
        template += "<label class='pull-right' ng-if='bindLanguages' ng-style='diffuseAllFlag && {\"padding-left\": \"5px\",\"padding-top\": \"0px\"} || {\"padding-left\": \"5px\", \"padding-top\": \"4px\"}'> FR";
        template += "<input type='checkbox' ng-model='bindLanguages.fr' ng-true-value='\"1\"' ng-false-value='\"0\"' ng-disabled='!bindLanguages.frAvaiable || (!diffuseAllFlag && bindItem == 1 && bindLanguages.fr == 1 && bindLanguages.en == 0)' ng-click='clickLanguagesFr()' style='vertical-align: sub;' \/>";
        template += "<\/label>";

        return {
            scope: {
                bindItem: '=',
                click: '&',
                clickLanguagesEn: '&',
                clickLanguagesFr    : '&',
                bindLanguages: '=',
                diffuseAllFlag: '='
            },
            link: function ( scope, element ) {
                element.find( 'input' ).on( 'click', function () {
                    var input = angular.element( this );
                        scope.$apply( function () {
                        var promise = scope.click();
                        if ( !promise ) {
                            return;
                        }
                        input.prop( "disabled", true );
                        promise.finally( function () {
                            input.prop( "disabled", false );
                        } );
                    } );
                } );
            },
            template: template
        };

    }]);*/
}( angular ) );
