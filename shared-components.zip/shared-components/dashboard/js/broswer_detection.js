// test commit
// // Please leave this notice
// JavaScript Browser and Operating System Detector ver1 build 2014-Mar-8 by Eric Noguchi,  http://www.ericsicons.com/js_browser
function BrowserInfo(ua)
{
    var n = navigator;
    var agt = (ua ? ua : n.userAgent).replace(/_/g, ".");
    var os;
    var osv;
    var bn;
    var bv;
    var bt = 32;
    var a = {};

    var i = function (str)
    {
        var m = new RegExp(str, "i").exec(agt);
        return m ? m[0] : false;
    };
    var gv = function (str)
    {
        var re = new RegExp(str + '[\\s/]*((\\d*\\.*){0,4})', "gi");
        return re.exec(agt)[1];
    };
    if (i("(x86\\.64|wow64|win64|x64|x86\\-64|amd64|ia64){1}"))
    {
        bt = 64;
    }
    if (i("windows"))
    {
        os = "Windows";
        if (i("nt 6.1")) osv = "7";
        else
        if (i("nt 6.3")) osv = "8.1";
        else
        if (i("nt 6.2")) osv = "8";
        else
        if (i('(nt 5.1|windows xp)')) osv = "XP";
        else
        if (i("nt 6.0")) osv = "Vista";
        else
        if (i("nt 5.2")) osv = "XP x64 Edition";
        else
        if (i("windows 95")) osv = "95";
        else
        if (i("windows 98")) osv = "98";
        else
        if (i("windows me")) osv = "Me";
        else
        if (i("nt 5.0")) osv = "2000";
        else if (i("phone")) osv = " Phone OS " + gv("phone[\\s/]?(?:os)?")

    }
    else if (os = i("(iphone|ipad|ipod)"))
    {
        osv = "iOS " + gv("os");
    }
    else if (i("mac"))
    {
        os = "Macintosh ";
        if (i("os x")) osv = "OS X " + gv("os x");
    }
    else if (os = i("android")) osv = " " + gv(os);
    else if (os = i("linux"))
    {
        var lv = i("(fedora|mint|ubuntu|suse|red hat|mandriva|gentoo|mageia|debian|arch|kubuntu)");
        osv = lv ? lv : "";
    }
    else if (os = i("blackberry")) osv = " " + gv("blackberry ")
    else if (os = i("(freebsd|openbsd|netbsd)"))
    {
        osv = "";
    }
    else osv = os = n.platform;

    if (i("(opera|opr)"))
    {
        bv = i("version") ? gv("version") : i("opr") ? gv("opr") : gv("opera");
        bn = "Opera";
    }
    else if ((bn = i("chromium")) || (bn = i("(firefox|chrome|konqueror)")))
    {
        bv = gv(bn);
    }
    else if (bn = i("crios"))
    {
        bv = gv(bn);
        bn = "Chrome iOS";
    }
    else if (i("(trident|msie)"))
    {
        bv = i("msie") ? gv("msie") : gv("rv:");
        bn = "Internet Explorer";
    }
    else if (i("safari") && i("version") && !i("(android|blackberry)"))
    {
        bn = "Safari";
        bv = gv("version");
    }
    else if (i("(mac|android|mobile)"))
    {
        bn = i("mac") ? "Safari" : i("android") ? "Android Browser" : i("blackberry") ? "BlackBerry Browser" : "Mobile Browser";
        bv = i("version") ? gv("version") : "";
    }
    else
    {
        bn = n.appName;
        bv = n.userAgent;
    }

    a['name'] = bn;
    a['version'] = bv;
    a['platformName'] = os;
    a['platformVersion'] = osv;
    a['bits'] = bt;
    a['mobile'] = i("mobile") ? "Yes" : "No"
    return a;
}
