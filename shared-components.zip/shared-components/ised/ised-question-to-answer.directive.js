(function (angular) {
    function IsedQuestionToAnswerController(
        $scope, 
        api, 
        utils, 
        $uibModal, 
        Event, 
        _, 
        $timeout,
        ) {

        var vm = this;
        var vmExtend = {
            out: utils.out,
            range: _.range,
            choicesArray: [],
            rowsColsArray: [],
            answersChanged: answersChanged,
            pushTochoiceList: pushTochoiceList,
            rowsColoumsList: rowsColoumsList,
            errorAddress: false,
        };
        angular.extend(vm, vmExtend);
        

        function setScaleAnswered(sliderId, index, highValue) {
            vm.answers = index;
            updateIfChangesAnswers(vm.question);
        }

        function setUpQuestionForAnswering() {
            if (vm.question.question.type === 'scale') {
                vm.scaleQuestion = {
                    index: Math.floor(vm.question.question.scale_range / 2),
                    options: {
                        floor: 1,
                        ceil: vm.question.question.scale_range,
                        showTicks: true,
                        showTicksValues: true
                    }
                };
                vm.scaleQuestion.options.onChange = setScaleAnswered;
            }
            vm.answers = null;
        }

        function answersChanged() {
            updateIfChangesAnswers(vm.question);
        }

        function pushTochoiceList(choice) {
            var choices = vm.question.question.choices ? vm.question.question.choices : [];
            var data = {};
            data.type = vm.question.question.type;
            data.score_obtained = 0;
            data.choice_id = choice.id;
            data.title = choice.title;

            var index = vm.choicesArray.map(function (item) {
                return item.choice_id;
            }).indexOf(data.choice_id);

            if (index != -1) {
                vm.choicesArray.splice(data, 1);
            } else {
                data.choice = _.find(choices, (choice) => {;
                    return choice.id == data.choice_id;
                });
                vm.choicesArray.push(data);
            }
            vm.answers = vm.choicesArray;
            answersChanged();
        }

        function rowsColoumsList(row, col) {
            var insert = true;
            var data = {};
            data.type = vm.question.question.type;
            data.score_obtained = 0;
            data.row_id = row.id;
            data.column_id = col.id;
            data.row_title = row;
            data.col_title = col;

            if (vm.rowsColsArray.length > 0) {
                for(var i = 0; i < vm.rowsColsArray.length; i++){
                    if (vm.rowsColsArray[i].row_id == data.row_id && vm.rowsColsArray[i].column_id == data.column_id) {
                        insert = false;
                        vm.rowsColsArray.splice(vm.rowsColsArray[i], 1);
                        break;
                    }
                }
                if(insert){
                    vm.rowsColsArray.push(data);
                }
            } else {
                vm.rowsColsArray.push(data);
            }
            vm.answers = vm.rowsColsArray;
            answersChanged();
        }
        let createTimeout;
        function initMap() {
            createTimeout = $timeout(function () {
                var input = document.getElementById('address');
                var autocomplete = new google.maps.places.Autocomplete(input);
                autocomplete.setFields(['formatted_address']);
                autocomplete.addListener('place_changed', function () {
                    var place = autocomplete.getPlace();
                    validateLocation(place);
                });
            }, 1000);
        }

        function validateLocation(place) {
            if(!place.formatted_address) {
                vm.errorAddress = true;
                return;
            }
            vm.answers = place.formatted_address;
            vm.errorAddress = false;
            // $scope.$apply();
            answersChanged();
        }

        function updateIfChangesAnswers(question) {
            var answered = false;
            switch (question.question.type) {
                case 'yes-no':
                    answered = vm.answers && (vm.answers === 'true' || vm.answers === 'false');
                    break;
                case 'mc-ss':
                    answered = vm.answers !== null && vm.answers !== '';
                    break;
                case 'mc-ms':
                    _.each(vm.choicesArray, function (ans) {
                        answered = answered || ans;
                    });
                    break;
                case 'desc':
                    answered = angular.isString(vm.answers) && (vm.answers.trim().length > 0);
                    break;
                case 'format':
                    answered = vm.answers !== null && vm.answers !== '';
                    break;
                case 'scale':
                    answered = vm.answers !== null && vm.answers !== '';
                    break;
                case 'table':
                    _.each(vm.rowsColsArray, function (ans) {
                        answered = answered || ans;
                    });
                    break;
            }
            vm.status.questionAnswered = answered;
            if (vm.status.questionAnswered) {
                vm.question.answers = vm.answers;
            }
        }

        vm.options = {
            date: {
                date: true
            },
            custom: {
                numericOnly: true,
                delimiters: [' (', ') ', '-'],
                blocks: [0, 3, 3, 4]
            }
        };

        $scope.$watch('vm.question', function (nval) {
            if (nval) {
                setUpQuestionForAnswering();
                if (vm.question.question.type == "format" && vm.question.question.format == "address") {
                    initMap();
                }
            }
        });

        function init() {
            setUpQuestionForAnswering();
        }

        init();

        $scope.$on('$destroy', function () {
            $timeout.cancel(createTimeout);
        });

    }
    IsedQuestionToAnswerController.$inject = [
        '$scope', 
        'api', 
        'utils', 
        '$uibModal', 
        'Event', 
        '_', 
        '$timeout',
    ];
    angular.module('shared-components')
        .directive('isedQuestionToAnswer', ['$window', function ($window) {
            return {
                scope: {
                },
                bindToController: {
                    question: '=',
                    update: '&',
                    status: '=',
                    choicesArray: '=',
                    rowsColsArray: '=',
                    hideBadgeTitle: '='
                },
                controller: IsedQuestionToAnswerController,
                controllerAs: 'vm',
                templateUrl: $window.appConfig.ATLAS_UI_URL + 'shared-components/ised/ised-question-to-answer.template.html'
            };
        }]);
})(angular);