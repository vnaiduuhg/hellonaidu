(function (angular) {
  const app = angular.module('shared-components');

  app.controller('IsedQuestionnaireToAnswerController', IsedQuestionnaireToAnswerController);
  IsedQuestionnaireToAnswerController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$timeout', '$window', '_', '$q', 'storageService', '$state'];
  function IsedQuestionnaireToAnswerController($scope, $rootScope, api, utils, $timeout, $window, _, $q, storageService, $state) {
    const vm = this;
    const vmExtend = {
      out: utils.out,
      range: _.range,
      status: {
        disqualified: false,
        questionAnswered: false,
      },
      submit,
      cancel,
      nextQuestion,
      timeRemaining: 5,
      countdown: '',
      questionnaireExpired: false,
      answersCheck: false,
      allQuestionsAlreadyAnswered: false,
      choicesArray: [],
      rowsColsArray: [],
      redirectBack,
      emptyQuestionnaire: false,
    };
    angular.extend(vm, vmExtend);

    let createTimeout1;
    let createTimeout2;
    let createTimeout3;
    let createTimeout4;

    function setUpQuestionnaire(questions) {
      const bundles = [];
      let j = 0;
      for (let i = 0; i < questions.length; i += 1) {
        if (!questions[i].is_tail) {
          questions[i].index = j;
          j += 1;
          const bundle = {
            questionnaire_question_id: questions[i].id,
            question: questions[i].question,
            index: i,
            followups: questions[i].question_branches,
          };
          if (questions[i].answers && questions[i].answers.length) {
            bundle.answers = questions[i].answers;
          }
          bundles.push(bundle);
        }
      }
      $scope.bundles = bundles;
      if (questions.length > 0 && questions[0].answers && questions[0].answers.length) {
        setExistingAnswers(questions);
      } else {
        vm.answersCheck = true;
      }
    }

    function initQuestionnaire() {
      if ((vm.questions && vm.questions.length) || (vm.questionnaire.questionnaire_questions && vm.questionnaire.questionnaire_questions.length)) {
        if (vm.isFromReferee || vm.employerSide) {
          setUpQuestionnaire(vm.questions);
          vm.totalQuestions = vm.questions.length;
        } else {
          setUpQuestionnaire(vm.questionnaire.questionnaire_questions);
          vm.totalQuestions = vm.questionnaire.questionnaire_questions.length;
        }
        vm.pos = 0;
        vm.bundle = $scope.bundles[vm.pos];
        vm.nextQuest = vm.bundle;
        vm.endOfQuestionnaire = false;
        vm.answeredQuestions = [];
      } else {
        vm.endOfQuestionnaire = true;
        vm.statusCompleted = true;
        vm.emptyQuestionnaire = true;
      }
    }

    function loadJobQuestionnaire() {
      let promise;
      if (vm.dispatchedQuestionnaire && vm.dispatchedQuestionnaire.job_id) {
        promise = api.service_post('toolkit', 'questionnaire/questionnaires/get-questionnaire-with-answers-candidate-side', {
          job_id: vm.dispatchedQuestionnaire.job_id,
          questionnaire_id: vm.questionnaireId,
        });
      } else {
        promise = api.service_get('toolkit', `questionnaire/questionnaires/${vm.questionnaireId}`, {
          load_with: 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;',
          sort_by: 'questionnaire_questions:rank',
        });
      }
      promise.then((response) => {
        vm.questionnaire = response.data.data.result;
        vm.questionnaire.questionnaire_questions = _.filter(vm.questionnaire.questionnaire_questions, (question) => !question.is_tail);
        initQuestionnaire();
      });
      return promise;
    }

    function cancel() {
      if (vm.preview) {
        vm.cancelPreview();
        return;
      }
      if (vm.employerSide) {
        vm.cancelFillQuestionnaire();
        return;
      }
      if (vm.jobId) {
        window.location = `${window.appConfig.ATLAS_UI_URL}/work/${vm.jobLink}`;
      } else {
        window.location = `${window.appConfig.ATLAS_UI_URL}/candidate/dashboard`;
      }
    }

    $scope.all_answers = [];
    function nextQuestion() {
      const data = {};
      data.type = vm.nextQuest.question.type;
      if (vm.dispatchedJobId) data.job_id = vm.dispatchedJobId;
      data.questionnaire_question_id = vm.nextQuest.questionnaire_question_id;
      data.score_obtained = 0;
      if (data.type == 'mc-ms') {
        vm.nextQuest.answers.forEach((item) => {
          const result = angular.copy(data);
          result.title = item.title;
          result.choice_id = item.choice_id;
          result.choice = item.choice;
          $scope.all_answers.push(result);
        });
      }
      if (data.type == 'mc-ss') {
        data.choice_id = vm.nextQuest.answers;
        vm.nextQuest.question.choices.forEach((item) => {
          const result = angular.copy(data);
          if (data.choice_id === item.id) {
            result.titleFr = item.translation.fr.title;
            result.titleEn = item.translation.en.title;
            result.choice_id = vm.nextQuest.answers;
            $scope.all_answers.push(result);
          }
        });
      }
      if (data.type == 'desc') {
        data.text = vm.nextQuest.answers;
        $scope.all_answers.push(data);
      }
      if (data.type == 'yes-no') {
        data.boolAnswer = (vm.nextQuest.answers === 'true');
        $scope.all_answers.push(data);
      }
      if (data.type == 'scale') {
        data.scale = vm.nextQuest.answers;
        $scope.all_answers.push(data);
      }
      if (data.type == 'table') {
        vm.nextQuest.answers.forEach((item) => {
          if (vm.dispatchedJobId) item.job_id = vm.dispatchedJobId;
          item.questionnaire_question_id = vm.nextQuest.questionnaire_question_id;
          $scope.all_answers.push(item);
        });
      }
      if (data.type == 'format') {
        if (vm.nextQuest.question.format == 'address') {
          data.location_id = 1;
          data.text = vm.nextQuest.answers;
          $scope.all_answers.push(data);
        } else if (vm.nextQuest.question.format == 'phone-number') {
          data.text = vm.nextQuest.answers;
          $scope.all_answers.push(data);
        } else if (vm.nextQuest.question.format == 'date') {
          const day = vm.nextQuest.answers.slice(0, 2);
          const month = vm.nextQuest.answers.slice(2, 4);
          const year = vm.nextQuest.answers.slice(4, 8);
          data.text = `${day}/${month}/${year}`;
          $scope.all_answers.push(data);
        }
      }

      if (vm.nextQuest.followups.length) {
        showFollowUp();
      } else if (vm.pos < $scope.bundles.length - 1) {
        vm.followupQuestion = false;
        vm.pos += 1;
        vm.bundle = $scope.bundles[vm.pos];
        vm.nextQuest = setNextQuestion(vm.bundle);
        vm.status.questionAnswered = false;
      } else if (vm.pos < $scope.bundles.length) {
        vm.endOfQuestionnaire = true;
        if (vm.employerSide) {
          vm.isConsentAgreed = true;
        }
      }
    }

    function setNextQuestion(question, is_followup_q = false) {
      if (vm.nextQuest) {
        countQuestions(is_followup_q);
        vm.choicesArray = [];
        vm.rowsColsArray = [];
        vm.nextQuest = null;
        createTimeout1 = $timeout(() => {
          vm.nextQuest = question;
        });
      }
    }

    function nextQuestionCall() {
      createTimeout2 = $timeout(() => {
        vm.followupQuestion = false;
        vm.pos += 1;
        vm.bundle = $scope.bundles[vm.pos];
        vm.nextQuest = setNextQuestion(vm.bundle);
        vm.status.questionAnswered = false;
      }, 500);
    }

    function isFollowupQToShow(type, answer) {
      return _.findIndex(vm.nextQuest.followups, (item) => (type == 'yes-no' ? item.bool_condition == answer : item.choice_condition_id == answer));
    }

    function processIsedQuestionnaire() {
      if (vm.jobId) {
        storageService.setItem('qualified', 1);
        vm.callBack();
      } else {
        const data = {};
        data.status = 'complete';
        data.questionnaire_id = vm.dispatchedQuestionnaire.questionnaire.id;
        data.candidate_id = vm.dispatchedQuestionnaire.candidate_id;
        if (vm.dispatchedQuestionnaire.job_id ) data.job_id = vm.dispatchedQuestionnaire.job_id;
        api.service_post('toolkit', `questionnaire/dispatched-questionnaires/${vm.dispatchedQuestionnaire.id}`, data, 'UPDATE').then((response) => {
          $scope.showProcessing = false;
          vm.statusCompleted = true;
          // vm.callBack();
        }).catch(() => {
          $scope.showProcessing = false;
        });
      }
    }

    function isedQuestionnaireDisqualifyCandidate() {
      if (vm.employerSide) {
        vm.endOfQuestionnaire = true;
        vm.isConsentAgreed = true;
        return;
      }
      const data = {};
      data.status = 'complete';
      data.questionnaire_id = vm.dispatchedQuestionnaire.questionnaire.id;
      data.candidate_id = vm.dispatchedQuestionnaire.candidate_id;
      if (vm.dispatchedQuestionnaire.job_id) data.job_id = vm.dispatchedQuestionnaire.job_id;
      api.service_post('toolkit', `questionnaire/dispatched-questionnaires/${vm.dispatchedQuestionnaire.id}`, data, 'UPDATE').then(() => {
        $scope.showProcessing = false;
        vm.statusCompleted = true;
        vm.endOfQuestionnaire = true;
      });
    }

    function processIsedQuestionnaireAnswers() {
      const promises = [];
      $scope.all_answers.forEach((item) => {
        // cal the answer save api
        const promise = api.service_post('toolkit', 'questionnaire/answers', item).then(() => {
        });
        promises.push(promise);
      });
      $q.all(promises).then(() => {
        if (vm.status.disqualified && !vm.pending) {
          isedQuestionnaireDisqualifyCandidate();
        } else if (vm.endOfQuestionnaire) {
          processIsedQuestionnaire();
        }
      });
    }

    function submit() {
      if (vm.isFromReferee) {
        $scope.$parent.parent.answers = $scope.all_answers;
        vm.submitAnswers($scope.all_answers);
        return;
      }
      if (vm.employerSide) {
        vm.isConsentAgreed = false;
        vm.allAnswers = $scope.all_answers;
        createTimeout3 = $timeout(() => {
          vm.sendFilledQuestionnaire();
        }, 750);
        return;
      }
      if ($scope.timeRemaining <= 0) {
        alert(vm.out('Le questionnaire a expiré!', 'Questionnaire has expired!'));
        return;
      }
      if (vm.preview) {
        vm.cancelPreview();
        return;
      }
      if (!vm.status.disqualified || vm.pending) {
        $scope.showProcessing = true;
      }
      if (vm.allQuestionsAlreadyAnswered) {
        processIsedQuestionnaire();
        return;
      }
      processIsedQuestionnaireAnswers();
    }

    function showFollowUp() {
      vm.notfound = true;
      if (vm.nextQuest.followups.length) {
        // eslint-disable-next-line no-nested-ternary
        const followupQindex = vm.nextQuest.question.type === 'yes-no'
          ? isFollowupQToShow(vm.nextQuest.question.type, vm.nextQuest.answers == 'true' ? 1 : 0)
          : vm.nextQuest.question.type === 'mc-ss' ? isFollowupQToShow(vm.nextQuest.question.type, vm.nextQuest.answers) : -1;
        const isFollowUpQtoShow = followupQindex > -1
          ? !!(vm.nextQuest.followups[followupQindex].tail_q_question_id && vm.nextQuest.followups[followupQindex].tail_q_question)
          : false;

        if (followupQindex > -1) {
          vm.notfound = false;
          if (vm.nextQuest.followups[followupQindex].reject_candidate == 1) {
            if (vm.employerSidePreview) {
              vm.endOfQuestionnaire = true;
              alert(vm.out('La condition disqualifié a été appliquée', 'Disqualify condition has been applied'));
            } else {
              vm.statusCompleted = true;
              vm.endOfQuestionnaire = true;
              vm.status.disqualified = true;
              submit();
            }
          } else {
            const bundle = {
              questionnaire_question_id: vm.nextQuest.followups[followupQindex].tail_q_question.id,
              question: vm.nextQuest.followups[followupQindex].tail_q_question.question,
              followups: [],
            };
            setNextQuestion(bundle, isFollowUpQtoShow);
          }
        }
      }
      if (vm.notfound) {
        if (vm.pos < $scope.bundles.length - 1) {
          nextQuestionCall();
        } else {
          vm.endOfQuestionnaire = true;
          if (vm.employerSide) {
            vm.isConsentAgreed = true;
          }
        }
      }
    }

    function setQuestionAnswers(q, isFollowupQ) {
      vm.status.questionAnswered = true;
      const data = {
        type: q.question.type,
        questionnaire_question_id: !isFollowupQ ? q.questionnaire_question_id : q.id,
        score_obtained: 0,
        existing_answer: true,
      };

      if (vm.dispatchedJobId) data.job_id = vm.dispatchedJobId;

      // eslint-disable-next-line default-case
      switch (q.question.type) {
        case 'mc-ms':
          q.answers.forEach((item) => {
            const result = angular.copy(data);
            result.title = item.title;
            result.choice_id = item.choice_id;
            result.choice = _.find(q.question.choices, (choice) => choice.id == item.choice_id);
            $scope.all_answers.push(result);
          });
          break;
        case 'mc-ss':
          data.choice_id = q.answers[0].choice_id;
          $scope.all_answers.push(data);
          break;
        case 'yes-no':
          data.boolAnswer = !!q.answers[0].boolAnswer;
          $scope.all_answers.push(data);
          break;
        case 'scale':
          data.scale = q.answers[0].scale;
          $scope.all_answers.push(data);
          break;
        case 'table':
          q.answers.forEach((item) => {
            const result = angular.copy(data);
            result.column_id = item.column_id;
            result.row_id = item.row_id;
            result.col_title = _.find(q.question.columns, (col) => col.id == item.column_id);
            result.row_title = _.find(q.question.rows, (row) => row.id == item.row_id);
            $scope.all_answers.push(result);
          });
          break;
        case 'desc':
        case 'format':
          data.text = q.answers[0].text;
          if (q.question.format == 'address') {
            data.location_id = 1;
          }
          $scope.all_answers.push(data);
          break;
              // no default case
      }
    }

    function countQuestions(isFollowupQ) {
      if (isFollowupQ) {
        vm.currentQuestion += 0.1;
      } else {
        vm.currentQuestion = Math.floor(vm.currentQuestion) + 1;
      }
    }

    function setCurrentQuestionAnswered(totalQ, isFollowupQ) {
      if (vm.currentQuestion == totalQ) {
        createTimeout4 = $timeout(() => {
          vm.allQuestionsAlreadyAnswered = true;
          vm.answersCheck = true;
          vm.endOfQuestionnaire = true;
        }, 600);
      }
      if (vm.currentQuestion < totalQ) {
        countQuestions(isFollowupQ);
      }
    }

    function getCurrentQuestionAnswer() {
      vm.answersCheck = true;
      vm.bundle = $scope.bundles[vm.pos];
      vm.nextQuest = setNextQuestion(vm.bundle);
      vm.status.questionAnswered = false;
    }

    function setExistingAnswers() {
      _.each($scope.bundles, (item) => {
        if (item.answers && item.answers.length) {
          setQuestionAnswers(item, false);
          setCurrentQuestionAnswered($scope.bundles.length, false);
          vm.pos += 1;
          if (item.followups && item.followups.length) {
            _.each(item.followups, (fq) => {
              if (fq.tail_q_question && fq.tail_q_question.answers && fq.tail_q_question.answers.length) {
                setQuestionAnswers(fq.tail_q_question, true);
                setCurrentQuestionAnswered($scope.bundles.length, true);
              }
            });
          }
        } else {
          getCurrentQuestionAnswer();
        }
      });
    }

    function redirectBack() {
      $state.go('pendingquestionnaires', {currentCandidate: vm.candidateId, jobs: vm.jobId}, {reload:true});
    }

    function init() {
      vm.currentQuestion = 1;
      vm.isConsentAgreed = false;
      vm.consentDesc = {};
      vm.consentDesc.en = 'I confirm that the information provided above is complete, true and correct to the best of my knowledge and belief.';
      vm.consentDesc.fr = "Je certifie que les informations fournies ci-dessus sont, à ma connaissance, complètes, authentiques et exactes.";

      if (vm.dispatchedQuestionnaire) {
        vm.questionnaireId = vm.dispatchedQuestionnaire.questionnaire_id;
      }
      loadJobQuestionnaire();
    }

    init();

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
      $timeout.cancel(createTimeout3);
      $timeout.cancel(createTimeout4);
    });
  }

  app.directive('isedQuestionnaireToAnswer', ['$window', function ($window) {
    return {
      scope: {
      },
      bindToController: {
        dispatchedQuestionnaire: '=',
        questionnaireId: '=?',
        candidateId: '=',
        companyName: '=',
        isFromReferee: '=',
        answers: '=answers',
        submitAnswers: '&',
        questions: '=',
        jobId: '=',
        documentsPersist: '=',
        returnUrl: '=',
        pending: '=',
        preview: '=',
        employerSidePreview: '=',
        dispatchedJobId: '=',
        callBack: '&',
        cancelPreview: '&',
        employerSide: '=',
        sendFilledQuestionnaire: '&',
        cancelFillQuestionnaire: '&',
        allAnswers: '=',
        hideBadgeTitle: '='
      },
      controller: IsedQuestionnaireToAnswerController,
      controllerAs: 'vm',
      templateUrl: `${$window.appConfig.ATLAS_UI_URL}shared-components/ised/ised-questionnaire-to-answer.template.html`,
    };
  }]);
// eslint-disable-next-line no-undef
}(angular));
