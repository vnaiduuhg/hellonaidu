(function (angular) {
  function InterviewController(
    $scope,
    $rootScope,
    api,
    utils,
    _, $filter,
    $uibModal,
    $timeout,
    $ngConfirm,
    worklandLocalize,
    MetaTagsService,
    $state,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
    $scope.isCandidate = $rootScope.currentUser.permissions.isCandidate;

    const scope = {
      imagesUrl: './../assets/images/',
      nocFunction: { selected: {} },
      strings: worklandLocalize.strings,
      profile: $rootScope.currentUser.user,
      utils,
      out: utils.out,
      getCandidateInterviews,
      acceptTimeslot,
      showCancellationModal,
      cancelInterview,
      is_expired,
      timeslotIdApprovedByInterviewee: 0,
      getTimeslot,
      showSetTimezoneModal,
      isLoadingInterviews: true,
      candidateInterviews: [],
      interviewStatuses: [],
      selectedStatus: {
        id: 0
      },
      loadIStatus: false,
      interviews: null,
      noInterviewOnFilter: false,
      interviewIsExpired: {
        checked: false
      },
      timezone: moment.tz.guess()
    };
    angular.extend($scope, scope);

    window.addeventasync = function () {
      addeventatc.settings({
        appleical: { show: true, text: 'Apple Calendar' },
        google: { show: true, text: 'Google <em>(online)</em>' },
        outlook: { show: true, text: 'Outlook' },
        outlookcom: { show: true, text: 'Outlook.com <em>(online)</em>' },
        yahoo: { show: true, text: 'Yahoo <em>(online)</em>' },
      });
      addeventatc.register('button-click', (obj) => {});
    };

    $scope.changeIStatus = () => {
      $scope.loadIStatus = true;
      $scope.noInterviewOnFilter = false;
      $scope.interviews = null;
      if ($scope.selectedStatus.id > 0) {
        const tempArray = _.filter($scope.candidateInterviews, interview => {
          return $scope.interviewIsExpired.checked
            ? interview.status_id == $scope.selectedStatus.id
            : interview.status_id == $scope.selectedStatus.id && !is_expired(interview.interview_expired_at);
        });
        $scope.interviews = tempArray;
      } else {
        $scope.interviews = $scope.interviewIsExpired.checked
          ? angular.copy($scope.candidateInterviews)
          : _.filter($scope.candidateInterviews, interview => !is_expired(interview.interview_expired_at));
      }

      if (!$scope.interviews || !$scope.interviews.length) $scope.noInterviewOnFilter = true;
      $timeout(() => {
        $scope.loadIStatus = false;
      }, 500);
    }

    function getInterviewStatuses() {
      api.service_get('toolkit', 'interview/status').then((response) => {
        if (response.data.status === 'success') {
          const tempStatuses = response.data.data.result;
          _.each(tempStatuses, status => {
            if (status.translation.fr.status === 'Confirmé') status.translation.fr.status = 'Confirmées';
            if (status.translation.fr.status === 'Annulé') status.translation.fr.status = 'Annulées';
          });
          $scope.interviewStatuses = tempStatuses;
        } else {
          $scope.errorMessage = true;
        }
      }).catch(() => {
        $scope.errorMessage = true;
      });
    }

    init();

    function init() {
      $scope.currentUser = $rootScope.currentUser.user;
      getCandidateInterviews();
      getInterviewStatuses();
    }

    function getCandidateInterviews() {
      $scope.isLoadingInterviews = true;
      $scope.candidateInterviews = [];
      $scope.errorMessage = false;

      const url = `interview/interviews`;
      const params = {
        "attendee_confirmed" : 1,
        "sort_by_desc" : "interview_expired_at",
        "filter_by_months" : 6,
        "filter_by_candidate_id[]": +$scope.candidate.id
      };
      api.service_get('toolkit', url, params).then((response) => {
        $scope.isLoadingInterviews = false;

        if (response.data.status === 'success') {
          const interviewList = response.data.data.result;

          _.each(interviewList, (interview) => {
            // Converting UTC time to local time
            _.each(interview.interview_timeslots, (timeslot)=>{
              var interview_start = utils.utcToTimezone(timeslot.date +' '+ timeslot.start_time, 'zoozle');
              timeslot.interview_start_time_local = interview_start['time'];
              timeslot.interview_date_local= interview_start['date'];
              timeslot.interview_end_time_local = utils.utcToTimezone(timeslot.date +' '+ timeslot.end_time, 'zoozle')['time'];
            });
            _.each(interview.interview_interviewees, (interviewee) => {
              if (interview.type[0].type === 'En-Personne') {
                interview.type[0].type = 'En personne';
              }
              if (interviewee.candidate_id === $scope.candidate.id) {
                const candidateInterview = {
                  interview_id: interview.id,
                  interviewee_id: interviewee.id,
                  candidate_id: interviewee.candidate_id,
                  interviewee_timeslot_id: interviewee.approved_interviewee_timeslots,
                  status_id: interview.status_id === 2 ? interview.status_id : interviewee.status_id,
                  status: interview.status_id === 2 ? interview.status : interviewee.status,
                  cancellation_note: interview.cancellation_note ? interview.cancellation_note : interviewee.reply_note,
                  type_id: interview.type_id,
                  type: interview.type,
                  location: interview.location,
                  company_name: interview.company_name,
                  creator_name: interview.creator_name,
                  interview_expired_at: interview.interview_expired_at,
                  interview_attendees: interview.interview_attendees,
                  available_timeslots: interview.interview_timeslots,
                  microsoft_interview_link: interviewee.microsoft_interview_link ? interviewee.microsoft_interview_link : null
                };
                candidateInterview.attendees_confirmed = _.filter(interview.interview_attendees, attendee => attendee.status_id == 3);
                if (interview.job_id) candidateInterview.job_id = interview.job_id;
                if (interview.job_title_fr) candidateInterview.job_title_fr = interview.job_title_fr;
                if (interview.job_title_en) candidateInterview.job_title_en = interview.job_title_en;
                if (candidateInterview.interviewee_timeslot_id && candidateInterview.interviewee_timeslot_id != '') {
                  _.each(interview.interview_timeslots, (timeslot) => {
                    if (candidateInterview.interviewee_timeslot_id === timeslot.id) {
                      candidateInterview.interview_date = timeslot.date;
                      candidateInterview.interview_startsAt = timeslot.start_time;
                      candidateInterview.interview_endsAt = timeslot.end_time;
                      candidateInterview.interview_startsAt_local = timeslot.interview_start_time_local;
                      candidateInterview.interview_endsAt_local = timeslot.interview_end_time_local;
                      candidateInterview.interview_date_local = timeslot.interview_date_local;
                      candidateInterview.calendarStartDate = timeslot.date + ' ' + timeslot.interview_start_time_local.slice(0, -3);
                      candidateInterview.calendarEndDate = timeslot.date + ' ' + timeslot.interview_end_time_local.slice(0, -3);
                    }
                  });
                }
                $scope.candidateInterviews.push(candidateInterview);
              }
            });
          });
          $scope.interviews = _.filter($scope.candidateInterviews, interview => !is_expired(interview.interview_expired_at));
          if (!$scope.interviews.length) $scope.noInterviewOnFilter = true;
          $timeout(() => { addeventatc.refresh(); }, 1000);
        } else {
          $scope.errorMessage = true;
        }
      }).catch(() => {
        $scope.isLoadingInterviews = false;
        $scope.errorMessage = true;
      });
    }

    function userWarning(content) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: $scope.out('Attention', 'Attention'),
        content,
        type: 'red',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function getTimeslot(timeslotId) {
      $scope.timeslotIdApprovedByInterviewee = timeslotId;
    }

    function acceptTimeslot(interviewee_id) {
      let msgEn; let msgFr;
      if ($scope.timeslotIdApprovedByInterviewee == 0) {
        userWarning(utils.out('Veuillez sélectionner un créneau horaire d\’entrevue', 'Please choose the interview timeslot'));
        return false;
      }
      msgEn = 'The request is being sent...';
      msgFr = 'La demande est envoyée...';
      $rootScope.api_status('waiting', msgEn, msgFr);

      const data = {
        interview_interviewee_id: interviewee_id,
        interview_timeslot_id: $scope.timeslotIdApprovedByInterviewee,
      };
      const promise = api.service_post('toolkit', 'interview/interviewee-interview-timeslots', data);
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'The interview has been scheduled successfully!';
          msgFr = "L'entrevue a été programmée avec succès!";
          $rootScope.api_status('alert-success', msgEn, msgFr);
          $scope.timeslotIdApprovedByInterviewee = 0;
          $scope.selectedStatus.id = 3;
          getCandidateInterviews();
        } else {
          $rootScope.api_status('alert-danger', response.data.message, response.data.message);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }


    function showCancellationModal(interview) {
      $scope.interviewToCancel = interview;
      $scope.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: './candidate-profile/directives/interview-module/interview-cancel-modal.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function cancelInterview(interview) {
      let msgEn; let msgFr;
      $scope.modalInstance.close();
      msgEn = 'Interview request is being cancelled...';
      msgFr = "La demande d'entrevue est annulée...";
      $rootScope.api_status('waiting', msgEn, msgFr);

      const data = {
        interview_id: interview.interview_id,
        interviewee_id: interview.interviewee_id,
        status_id: 2,
        candidate_id: interview.candidate_id,
        reply_note: interview.cancellation_note,
        replied_at: utils.toDateStr(new Date()),
        questionnaire_id: interview.questionnaire_id,
      };

      const promise = api.service_post('toolkit', `interview/interviewees/${interview.interviewee_id}`, data, 'update');
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'Interview request has been cancelled successfully.';
          msgFr = "La demande d'entrevue a été annulée avec succès.";
          $rootScope.api_status('alert-success', msgEn, msgFr);
          getCandidateInterviews();
        } else {
          $rootScope.api_status('alert-danger', response.data);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function is_expired(interview_data) {
      const nowdate = new Date();
      const sDate = $filter('date')(nowdate, 'yyyy-MM-dd');
      if (sDate > interview_data) {
        return true;
      }
      return false;
    }

    function showSetTimezoneModal() {
      $ngConfirm({
        title: '',
        contentUrl: './candidate-profile/directives/interview-module/timezone-calendar-helper.template.html',
        scope: $scope,
        columnClass: 'col-12 col-md-6 col-md-offset-3',
        containerFluid: true,
        typeAnimated: true,
        animation: 'scale',
        theme: 'light',
        closeIcon: true,
        buttons: {
          Ok: {
            text: utils.out('Fermer', 'Close'),
            btnClass: 'btn btn-md btn-secondary',
            action() {

            }
          }
        }
      });
    }

  }

  InterviewController.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
    '$filter',
    '$uibModal',
    '$timeout',
    '$ngConfirm',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
  ];
  angular.module('atlas')
    .controller('candidate-interview', InterviewController);
}(angular));
