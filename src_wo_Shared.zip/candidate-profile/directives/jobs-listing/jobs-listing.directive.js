(function (angular) {
  function matchesCtrl(
    $scope,
    $rootScope,
    $uibModal,
    utils,
    api,
    Event,
    _,
    worklandLocalize,
    $window,
    // matchService,
    $state,
    applicationService,
    MetaTagsService,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function loadQuestionnaireCustomSections(jobId) {
      Event.broadcast('questionnaire.loadCustomSections', jobId);
    }

    function openIsedQuestionnaireModal(job) {
      const modal = $uibModal.open(modalParams);
      const params = {
        job,
        candidateId: $rootScope.currentUser.user.id,
        closeModal() {
          modal.close();
        },
      };
      const modalParams = {
        animation: true,
        templateUrl: './../shared-components/ised/ised-questionnaire-to-answer.template.html',
        controller: 'IsedQuestionnaireToAnswerController as vm',
        size: 'lg',
        backdrop: 'static',
        resolve: {
          params() {
            return params;
          },
        },
      };
    }

    let scope = {
      strings: utils.strings,
      out: utils.out,
      utcToTimezone: utils.utcToTimezone,
      showCompletedApplications: false,
      showIncompleteApplications: false,
      isInternalUser: $rootScope.currentUser.permissions.isInternalEmployee,
    };
    angular.extend($scope, scope);

    function initQTab() {
      $state.go('questionnaire', { initQTab: true });
    }

    function jobIdExists(jobId) {
      return $scope.jobs.some((o) => +o.id === +jobId);
    }

    const initOnce = _.once(init);
    $scope.$watch('init', (initVal) => {
      initVal && initOnce();
    });

    function jobTitleTranslation() {
      $scope.jobsAppliedCount = 0;
      $scope.externalJobsAppliedCount = 0;
      $scope.internalJobsAppliedCount = 0;
      $scope.privateJobsAppliedCount = 0;
      $scope.jobsApplicationsPending = 0;
      $scope.externalJobsApplicationsPending = 0;
      $scope.internalJobsApplicationsPending = 0;
      $scope.privateJobsApplicationsPending = 0;
      if ($scope.jobs.length > 0) {
        angular.forEach($scope.jobs, (job) => {
          angular.forEach(job.translations, (translation) => {
            if (translation.locale === 'en') {
              job.titleEn = translation.title ? translation.title : '';
              job.titleEn = unescape(job.titleEn);
            }
            if (translation.locale === 'fr') {
              job.title = translation.title ? translation.title : '';
              job.title = unescape(job.title);
            }
          })

          if (job.published_internal && job.published_external) {
            job.isExternal = true;
            job.isExpiredInternally = utils.isDateExpired(job.internal_expiry_date);
            job.isExpiredExternally = utils.isDateExpired(job.external_expiry_date);
          } else if (job.published_internal) {
            job.isInternal = true;
            job.isExpiredInternally = utils.isDateExpired(job.internal_expiry_date);
          } else if (job.published_external) {
            job.isExternal = true;
            job.isExpiredExternally = utils.isDateExpired(job.external_expiry_date);
          } else {
            job.isPrivate = true;
          }
          job.isExpired = utils.isDateExpired(job.external_expiry_date);
          job.isExpiredExternally = utils.isDateExpired(job.external_expiry_date);
          job.isExpiredInternally = utils.isDateExpired(job.internal_expiry_date);

          if (job.id && $scope.type !== 'matches') {
            // to be sure to take the first application if we have many with same id, we stop the process when we find it.
            // Applications are sorted by newest first
            let i = -1;
            do {
              i += 1;
              if (+$scope.applications[i].job_id === +job.id) {
                job.date = $scope.applications[i].updated_at;
                job.application_status = $scope.applications[i].status;
                job.application_id = $scope.applications[i].id;
                job.isExternalApplication = $scope.applications[i].is_external;
                if ($scope.applications[i].status === 'submitted') {
                  $scope.jobsAppliedCount += 1;
                  if (job.isExternal) {
                    $scope.externalJobsAppliedCount += 1;
                  }
                  if (job.isInternal) {
                    $scope.internalJobsAppliedCount += 1;
                  }
                  if (job.isPrivate) {
                    $scope.privateJobsAppliedCount += 1;
                  }
                } else {
                  $scope.jobsApplicationsPending += 1;
                  if (job.isExternal) {
                    $scope.externalJobsApplicationsPending += 1;
                  }
                  if (job.isInternal) {
                    $scope.internalJobsApplicationsPending += 1;
                  }
                  if (job.isPrivate) {
                    $scope.privateJobsApplicationsPending += 1;
                  }
                }
                // @todo get questionnaire pending
                // job.questionnaire_pending = application.questionnaire_pending;
              }
            } while (+$scope.applications[i].job_id !== +job.id && i < $scope.applications.length - 1);
          }
        });
        $scope.privateJobs = $scope.jobs.filter((job) => job.isPrivate);
        $scope.internalJobs = $scope.jobs.filter((job) => job.isInternal);
        $scope.externalJobs = $scope.jobs.filter((job) => job.isExternal);
      } else {
        $scope.loadingDone = true;
        $scope.jobs = [];
      }
      return $scope.jobs;
    }

    function jobLocationsAdded() {
      const job_location_ids = [];
      angular.forEach($scope.jobs, (job) => {
        if (job.locations.length > 0) {
          job.locations.forEach((item) => {
            job_location_ids.push(item.location_id);
          });
        }
      });
      // Getting all locations with one api call
      if (job_location_ids.length > 0) {
        return api.service_get('shared', 'location/list-by-key-and-values', {
          key: 'id',
          'values[]': job_location_ids,
        }).then((response) => {
          // Associating location information to job based on respecting ids
          angular.forEach($scope.jobs, (job) => {
            if (job.locations.length > 0) {
              angular.forEach(response.data, (location) => {
                if (location.id === job.locations[0].location_id) {
                  job.city = location.city;
                  job.country = location.country;
                  job.province = location.province;
                }
              })
            } else {
              job.noLocationError = true;
            }
          });
        }).catch(() => {
          $scope.loadingDone = true;
        });
      }

      $scope.loadingDone = true;
    }

    function getJobsCompanyNames() {
      const accountIds = [];
      angular.forEach($scope.jobs, (job) => {
        accountIds.push(job.account_id);
      });
      const accountsParams = {
        account_ids: accountIds,
      };
      if (accountIds.length > 0) {
        api.service_post('accounts', 'accounts/default-profiles', accountsParams)
          .then((profilesResponse) => {
            if (profilesResponse.data.status === 'success') {
              const profiles = profilesResponse.data.data;
              for (let i = 0; i < $scope.jobs.length; i += 1) {
                const accountId = $scope.jobs[i].account_id;
                if (accountId in profiles) {
                  $scope.jobs[i].company = profiles[accountId].name;
                }
              }
              $scope.loadingDone = true;
            } else {
              $scope.loadingDone = true;
            }
          }).catch((err) => {
            if (err.data && err.data.error.status_code !== 200) {
              $scope.loadingDone = true;
            }
          });
      }
    }

    $scope.showCompletedApplications = true;
    $scope.showIncompleteApplications = false;

    function changeTabSelector(tab) {
      if (tab === 'firsttab') {
        $scope.showCompletedApplications = true;
        $scope.showIncompleteApplications = false;
      } else {
        $scope.showIncompleteApplications = true;
        $scope.showCompletedApplications = false;
      }
    }

    function getDefaultCandidateJobList() {
      $scope.loadingDone = false;
      if ($scope.applications && $scope.jobs && ($scope.jobs.length > 0 && $scope.applications.length > 0)) {
        jobTitleTranslation();
        getJobsCompanyNames();
        jobLocationsAdded();
      } else {
        $scope.jobApplicationError = false;
        $scope.promise = applicationService.get_query_with_auth('application/current-candidate/applications').then((response) => {
          $scope.applications = [];
          const userApplications = response.data;
          if (userApplications) {
            if (userApplications.length > 0) {
              $scope.applications = userApplications;
              $scope.jobsIds = _.pluck(_.uniq($scope.applications, 'job_id'), 'job_id');
              if ($scope.jobsIds.length > 0) {
                const params = {
                  'ids[]': $scope.jobsIds,
                  get_all: 1,
                };
                api.service_get('jobs', 'job/read-from-id-list', params).then((res) => {
                  $scope.jobs = res.data;
                  $scope.loadingDone = true;
                  jobTitleTranslation();
                }).then(() => {
                  if ($scope.jobs.length > 0) {
                    return jobLocationsAdded();
                  }
                })
                  .then(() => {
                    if ($scope.jobs.length > 0) {
                      return getJobsCompanyNames();
                    }
                  });
              }
            } else {
              $scope.loadingDone = true;
            }
          }
        }).catch(() => {
          $scope.jobApplicationError = true;
          $scope.loadingDone = true;
        });
      }
    }

    function getCandidateJobsList() {
      const type = $scope.type || null;

      $scope.loadingDone = false;
      // if (type === 'matches') {
      //   $scope.jobApplicationError = false;
      //   const path = 'revmatch';
      //   const revmatchResults = [];
      //   const promiseRevMatch = matchService.getData(path);
      //   promiseRevMatch.then((response) => {
      //     if (response.data.status === 'ok') {
      //       const matchedData = response.data.data;
      //       _.each(matchedData, (data) => {
      //         revmatchResults.push(_.pick(data, 'requestId', 'match'));
      //       });
      //       const jobIds = _.pluck(revmatchResults, 'requestId');
      //       if (jobIds.length > 0) {
      //         const params = {
      //           'ids[]': jobIds,
      //           get_all: 1,
      //         };
      //         api.service_get('jobs', 'job/read-from-id-list', params)
      //           .then((response) => {
      //             $scope.jobs = response.data;
      //             $scope.candidateJobMatches = $scope.jobs.length;
      //             _.each(revmatchResults, (revR) => {
      //               if (jobIdExists(revR.requestId)) {
      //                 _.where($scope.jobs, { id: Number(revR.requestId) })[0].match = revR.match;
      //               }
      //             });
      //             $scope.loadingDone = true;
      //             jobTitleTranslation();
      //           })
      //           .then(() => {
      //             if ($scope.jobs.length > 0) {
      //               return jobLocationsAdded();
      //             }
      //           }).then(() => {
      //             if ($scope.jobs.length > 0) {
      //               return getJobsCompanyNames();
      //             }
      //           })
      //           .catch(() => {
      //             $scope.jobs = [];
      //             $scope.loadingDone = true;
      //           });
      //       } else {
      //         $scope.jobs = [];
      //         $scope.loadingDone = true;
      //       }
      //     } else {
      //       getDefaultCandidateJobList();
      //     }
      //   });
      //   return $scope.promise = promiseRevMatch;
      // }
      getDefaultCandidateJobList();
    }

    function redirectToJobDescription(jobId, jobUrl) {
      window.location = `${window.appConfig.ATLAS_UI_URL}work/${jobId}/${jobUrl}`;
    }

    function init() {
      $scope.openQDirective = false;
      getCandidateJobsList();
    }

    scope = {
      loadQuestionnaireCustomSections,
      openIsedQuestionnaireModal,
      initQTab,
      changeTabSelector,
      redirectToJobDescription,
    };
    angular.extend($scope, scope);
  }
  matchesCtrl.$inject = [
    '$scope',
    '$rootScope',
    '$uibModal',
    'utils',
    'api',
    'Event',
    '_',
    'worklandLocalize',
    '$window',
    // 'matchService',
    '$state',
    'applicationService',
    'MetaTagsService',
  ];
  angular.module('atlas')
    .directive('jobsListing', [
      function () {
        return {
          scope: {
            init: '=',
            title: '@',
            type: '@',
            jobsIds: '@',
            applications: '=',
            jobs: '=',
            jobsAppliedCount: '=',
            jobsApplicationsPending: '=',
            // candidateJobMatches: '=',
            jobApplicationError: '=',
          },
          controller: matchesCtrl,
          templateUrl: './candidate-profile/directives/jobs-listing/jobs-listing.template.html',
        };
      },
    ]);
}(angular));
