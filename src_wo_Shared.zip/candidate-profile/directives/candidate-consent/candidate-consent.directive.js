(function (angular) {
  angular.module('atlas')
    .directive('candidateConsent', () => ({
      restrict: 'EA',
      scope: {
        job: '=',
        currentCandidate: '='
      },
      controller: CandidateConsentCtrl,
      templateUrl: './candidate-profile/directives/candidate-consent/candidate-consent.template.html',
    }));

  CandidateConsentCtrl.$inject = [
    '$scope',
    'utils',
    '$rootScope',
    'api',
  ];
  function CandidateConsentCtrl(
    $scope,
    utils,
    $rootScope,
    api,
  ) {
    const scope = {
      out: utils.out,
      language: $rootScope.language,
      isreadyToSubmit: false,
      isConsentAgreed: false,
      isLoading: true,
      consentDesc: {},
      parseMessage,
      getDefaultConsentMessage,
      iscandidateSignedConsent,
      agreeConsent,
    };
    angular.extend($scope, scope);

    function parseMessage() {
      $scope.consentDesc = {};
      $scope.consentDesc.id = $scope.defaultConsent.id;
      const descriptionEn = $scope.defaultConsent.translation.en.description;
      const descriptionFr = $scope.defaultConsent.translation.fr.description;
      $scope.consentDesc.en = descriptionEn.replace(new RegExp('{{company_name}}', 'g'), $scope.job.company);
      $scope.consentDesc.fr = descriptionFr.replace(new RegExp('{{nom_de_la_compagnie}}', 'g'), $scope.job.company);
      $scope.consentDesc.en = $scope.consentDesc.en.replace(new RegExp('{{candidate_full_name}}', 'g'), $scope.candidateFullName);
      $scope.consentDesc.fr = $scope.consentDesc.fr.replace(new RegExp('{{candidat_nom_full}}', 'g'), $scope.candidateFullName);     
    }

    function getCompanyName() {
      if(!$scope.job.company) {
        $scope.job.company = '';
        api.service_post('accounts', 'accounts/default-profiles', {account_ids: [$scope.job.account_id]})
        .then((response) => {
          if (response.data.status === 'success') {
            $scope.job.company = response.data.data && response.data.data[$scope.job.account_id]
                                 ? response.data.data[$scope.job.account_id].name
                                 : '';
          }
          parseMessage();
        })
        .catch(() => {
          parseMessage();
        });
      }
      else {
        parseMessage();
      }
    }

    // when you want to see if the candidate already has a consent msg with a specific employer:
    function iscandidateSignedConsent() {
      $scope.isLoading = true;
      $scope.promise = api.service_get('toolkit', `reference/consents?filter_by_employer_account_id=${$scope.job.account_id}&filter_by_candidate_id=${$scope.currentCandidate.id}`).then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          if (res.data.result.length === 0) {
            $scope.isConsentAgreed = false;
            $scope.$emit('consentSignedEvent', {
              isConsentAgreed: $scope.isConsentAgreed,
            });
          } else {
            $scope.isConsentAgreed = true;
            $scope.$emit('consentSignedEvent', {
              isConsentAgreed: $scope.isConsentAgreed,
            });
          }
        }
        getCompanyName();
        $scope.isLoading = false;
      })
        .catch(() => {
          getCompanyName();
          $scope.isLoading = false;
          $rootScope.api_status('alert-danger');
        });
    }

    function getDefaultConsentMessage() {
      $scope.isLoading = true;
      $scope.promise = api.service_get('toolkit', 'reference/consent-messages').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.defaultConsent = res.data.result[0];
          iscandidateSignedConsent();
        } else {
          $scope.isLoading = false;
          $rootScope.api_status('alert-danger', 'An error occured and your consent message could not be fetched', 'Une erreur s\'est produite et votre message de consentement n\'a pas pu être récupéré');
        }
      })
        .catch(() => {
          $scope.isLoading = false;
          $rootScope.api_status('alert-danger', 'An error occured and your consent message could not be fetched', 'Une erreur s\'est produite et votre message de consentement n\'a pas pu être récupéré');
        });
    }

    function agreeConsent(isConsentAgreed) {
      if (isConsentAgreed) {
        const formData = {
          employer_account_id: $scope.job.account_id,
          candidate_id: $scope.currentCandidate.id,
          consent_message_id: $scope.consentDesc.id
        };
        $scope.promise = api.service_post('toolkit', 'reference/consents', formData).then((response) => {
          const res = response.data;
          if (res.status === 'success') {
            $scope.$emit('consentSignedEvent', {
              isConsentAgreed,
            });
          }
        })
          .catch(() => {
            $rootScope.api_status('alert-danger');
          });
      }
    }

    $scope.$watch('job.company', (newValue, oldValue) => {
      if (newValue !== oldValue) {
        $scope.isLoading = true;
        iscandidateSignedConsent();
      }
    });

    function init() {
      $scope.candidateFullName = `${$scope.currentCandidate.first_name} ${$scope.currentCandidate.last_name}`;
      if($scope.currentCandidate && $scope.job) {
        getDefaultConsentMessage();
      }
    }

    init();
  }
}(angular));
