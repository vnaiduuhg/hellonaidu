(function (angular) {
  function CandReferenceModuleCtrl(
    $scope,
    utils,
    $rootScope,
    api,
    $uibModal,
    _,
    $filter,
    Event,
    applicationService,
    MetaTagsService,
    $state,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
    $scope.currentCandidate = $rootScope.currentUser.user;
    let scope = {
      out: utils.out,
      language: $rootScope.language,
      refereeModel: {
        candidate_user_id: '',
        company: '',
        email: '',
        first_name: '',
        last_name: '',
        phone: null,
        preferred_language: $rootScope.language,
        relation_to_candidate: '',
        job_title: '',
        from_date: null,
        to_date: null,
      },
      isreadyToSubmit: true,
      isConsentAgreed: false,
      // @todo check
      referencesRequested: [],
      references_submitted: [],
      isOpen: false,
      dateOptions: {
        'year-format': "'yy'",
        'starting-day': 1,
      },
      format: 'dd/MM/yyyy',
      requestedJob: [],
      displayRefRequestInfo: false,
    };
    angular.extend($scope, scope);

    const rootModelListener = $rootScope.$watch('language', (l) => {
      $scope.language = l;
    });

    $scope.$on('$destroy', () => {
      // disable the listener
      rootModelListener();
    });

    function validateRefereeForm(formData) {
      if (!formData.candidate_user_id || !formData.company || !formData.email
            || !formData.first_name || !formData.from_date || !formData.job_title
            || !formData.last_name || !formData.phone || !formData.preferred_language
            || !formData.relation_to_candidate || !formData.to_date) {
        return false;
      }
      return true;
      // @todo add validation and html error signs
    }

    function resetRefereeModel() {
      $scope.refereeModel = {
        company: '',
        email: '',
        first_name: '',
        last_name: '',
        phone: null,
        preferred_language: $rootScope.language,
        relation_to_candidate: 'Manager',
        job_title: '',
        from_date: null,
        to_date: null,
      };
    }

    function setEditableReferees() {
      _.each($scope.refereesList, (referee) => {
        referee.editable = !referee.references.length;
        referee.cancelable = !referee.job_application_referee.length;
      });
    }

    function getCandidateReferees() {
      $scope.loadingReferees = true;
      api.service_get('toolkit', 'reference/referees/by-candidate').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.refereesList = res.data.result;
          setEditableReferees();
        } else {
          $rootScope.api_status('alert-danger', 'An error occured and your referees could not be fetched', 'Une erreur est survenue et votre référence n\'a pu être récupérée');
        }
        $scope.loadingReferees = false;
      })
        .catch(() => {
          $scope.loadingReferees = false;
          $rootScope.api_status('alert-danger', 'An error occured and your referees could not be fetched', 'Une erreur est survenue et votre référence n\'a pu être récupérée');
        });
    }

    function addReferee() {
      let msgEn;
      let msgFr;
      const formData = angular.copy($scope.refereeModel);
      formData.candidate_user_id = $scope.currentCandidate.id;
      formData.from_date = moment(new Date(formData.from_date)).format('YYYY-MM-DD');
      formData.to_date = moment(new Date(formData.to_date)).format('YYYY-MM-DD');

      const validate = validateRefereeForm(formData);
      if (!validate) {
        msgEn = 'Please fill in all fields';
        msgFr = 'S\'il-vous-plaît veuillez remplir tous les champs';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
        return;
      }

      $rootScope.api_status('waiting', 'Adding your referee...', 'Ajout de votre référence ...');
      return api.service_post('toolkit', 'reference/referees', formData).then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $rootScope.api_status('alert-success', 'Your referee has been sucessfully added!', 'Votre référence a été ajoutée avec succès !');
          getCandidateReferees();
          resetRefereeModel();
          $scope.refereesFormVisible = false;
        } else {
          $rootScope.api_status('alert-danger', 'An error occured and your reference could not be added', 'Une erreur est survenue et votre référence n\'a pu être ajoutée');
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'An error occured and your reference could not be added', 'Une erreur est survenue et votre référence n\'a pu être ajoutée');
      });
    }

    function deleteReferee(reference) {
      $rootScope.api_status('waiting', 'Deleting your referee...', 'Suppression de votre référence...');
      return api.service_delete('toolkit', `reference/referees/${reference.id}`).then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $rootScope.api_status('alert-success', 'Your referee has been deleted sucessfully', 'Votre référence a été supprimée avec succès');
          $scope.referees = $scope.refereesList.splice($scope.refereesList.indexOf(reference), 1);
        } else {
          $rootScope.api_status('alert-danger', 'An error occured and your referee could not be deleted', 'Une erreur est survenue et votre référence n\'a pu être supprimée');
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'An error occured and your referee could not be deleted', 'Une erreur est survenue et votre référence n\'a pu être supprimée');
      });
    }

    function showRefForm(isAdd) {
      $scope.isOpen = !isAdd;
      if (isAdd) {
        resetRefereeModel();
      }
      $scope.refereesFormVisible = true;
    }

    function editReferee(reference) {
      reference.isOpen = false;
      $scope.isOpen = true;
      showRefForm(false);
      reference.from_date = new Date(reference.from_date);
      reference.to_date = new Date(reference.to_date);
      $scope.refereeModel = reference;
    }

    function saveReferee() {
      const formData = angular.copy($scope.refereeModel);
      formData.candidate_user_id = $scope.currentCandidate.id;
      formData.from_date = $filter('date')(formData.from_date, 'yyyy-MM-dd');
      formData.to_date = $filter('date')(formData.to_date, 'yyyy-MM-dd');

      const validate = validateRefereeForm(formData);
      if (!validate) {
        $rootScope.api_status('alert-danger', 'Please make sure to fill all required fields', 'Veuillez vous assurer de remplir tous les champs');
      }

      $rootScope.api_status('waiting', 'Updating Your Referee...', 'Mise à jour de votre référence...');
      return api.service_post('toolkit', `reference/referees/${$scope.refereeModel.id}`, formData, 'PUT').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $rootScope.api_status('alert-success', 'Your referee has been sucessfully modified!', 'Votre référence a été modifiée avec succès!');
          getCandidateReferees();
          resetRefereeModel();
          $scope.refereesFormVisible = false;
        } else {
          $rootScope.api_status('alert-danger', 'A problem occured and your referee could not be modified', "Un problème est survenu et votre référence n'a pu être mise à jour");
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'A problem occured and your referee could not be modified', "Un problème est survenu et votre référence n'a pu être mise à jour");
      });
    }

    function setJobsToReferences() {
      $scope.referencesRequestedCount = 0;
      $scope.refRequestedRemainingCount = 0;
      if ($scope.requestedJob.length === 0) {
        _.each($scope.referencesRequested, (ref) => {
          _.each($scope.jobs, (job) => {
            if (ref.job_application_id === job.application_id && ref.reference_requested_count) {
              // count of remaining reference requests to send
              let referencesAlreadySent = 0;
              if ($scope.refereesList?.length > 0) {
                _.each($scope.refereesList, (referee) => {
                  if (referee.job_application_referee.find((r) => +r.job_application_id === +ref.job_application_id)) {
                    referencesAlreadySent++;
                  }
                });
              }
              $scope.refRequestedRemainingCount = $scope.refRequestedRemainingCount + (+ref.reference_requested_count - referencesAlreadySent);
              $scope.referencesRequestedCount = $scope.referencesRequestedCount + +ref.reference_requested_count;
              job.references_requested = ref;
              $scope.requestedJob.push(job);
            }
          });
        });
      }
    }

    function jobTitleTranslation() {
      if ($scope.jobs.length > 0) {
        angular.forEach($scope.jobs, (job) => {
          job.titleEn = job.translations['0'] ? (job.translations['0'].title ? job.translations['0'].title : '') : '';
          job.titleEn = unescape(job.titleEn);
          job.title = job.translations['1'] ? (job.translations['1'].title ? job.translations['1'].title : '') : '';
          job.title = unescape(job.title);
        });
      }
    }

    function getReferencesRequested() {
      if ($scope.referencesRequested.length > 0 && $scope.jobs.length > 0) {
        jobTitleTranslation();
        setJobsToReferences();
      } 
      if ($scope.referencesRequested.length === 0) {
        $scope.loadingReferences = true;
        api.service_get('toolkit', 'reference/reference-requests/candidate-side', {}).then((response) => {
          $scope.loadingReferences = false;
          const res = response.data;
          if (res.status === 'success') {
            $scope.referencesRequested = res.data.result;
            if ($scope.jobs.length === 0) {
              $scope.loadingJobs = true;
              applicationService.get_query_with_auth('application/current-candidate/applications').then((result) => {
                $scope.applications = result.data;
                if ($scope.applications?.length > 0) {
                  $scope.jobsIds = _.pluck(_.uniq($scope.applications, 'job_id'), 'job_id');
                  if ($scope.jobsIds.length > 0) {
                    const params = {
                      'ids[]': $scope.jobsIds,
                      get_all: 1,
                    };
                    api.service_get('jobs', 'job/read-from-id-list', params).then((res) => {
                      $scope.jobs = res.data;
                      if ($scope.jobs.length > 0) {
                        angular.forEach($scope.jobs, (job) => {
                          if (job.id) {
                            // to be sure to take the first application if we have many with same id, we stop the process when we find it.
                            // Applications are sorted by newest first
                            let i = -1;
                            do {
                              i += 1;
                              if (+$scope.applications[i].job_id === +job.id) {                   
                                job.application_id = $scope.applications[i].id;
                              }
                            } while (+$scope.applications[i].job_id !== +job.id && i < $scope.applications.length - 1);
                          }
                        });
                      }
                      jobTitleTranslation();
                      setJobsToReferences();
                      $scope.loadingJobs = false;
                    }).catch( () => {
                      $scope.loadingJobs = false;
                      $rootScope.api_status('alert-danger', 'Your requested references could not be fetched', 'Les demandes de références n\'ont pu être récupérées');
                    });
                  }
                }
              }).catch( () => {
                $scope.loadingJobs = false;
                $rootScope.api_status('alert-danger', 'Your requested references could not be retrieved', 'Les demandes de références n\'ont pu être consultées');
              })
            } else {
              jobTitleTranslation();
              setJobsToReferences();
            }
          }
        }).catch(() => {
          $scope.loadingReferences = false;
          $rootScope.api_status('alert-danger', 'A problem occured and your requested references could not be fetched', 'Un problème est survenu et les demandes de références n\'ont pu être récupérées');
        });
      }
    }

    function init() {
      getReferencesRequested();
      getCandidateReferees();
    }

    init();

    function setReferencesSelected(refSelected) {
      const tempId = [];
      _.each(refSelected, (id) => {
        _.each($scope.refereesList, (referee) => {
          if (id === referee.id) {
            referee.selected = true;
            referee.active = true;
            tempId.push(referee.id);
          } else if (!tempId.includes(referee.id)) {
            referee.selected = false;
            referee.active = false;
          }
        });
      });
    }

    function getAttachedRefByApplication(jobApplicationId) {
      $scope.references_submitted = [];
      api.service_get('toolkit', 'reference/job-application-referees', { filter_by_job_application_id: jobApplicationId }).then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.references_submitted = res.data.result.length ? res.data.result : [];
          if ($scope.references_submitted.length) {
            const refSelected = _.pluck($scope.references_submitted, 'referee_id');
            if (refSelected) {
              setReferencesSelected(refSelected);
            }
          } else {
            _.each($scope.refereesList, (referee) => {
              referee.selected = false;
              referee.active = false;
            });
          }
          $scope.isreadyToSubmit = true;
          $scope.displayRefRequestInfo = true;
        } else {
          $rootScope.api_status('alert-danger', 'An error occured and the referees already attached to the reference request could not be fetched', 'Un problèmes est survenu et les référence déjà attachées à la demande de référence n\'ont pu être récupérées');
          $scope.displayRefRequestInfo = true;
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'An error occured and the referees already attached to the reference request could not be fetched', 'Un problèmes est survenu et les référence déjà attachées à la demande de référence n\'ont pu être récupérées');
        $scope.displayRefRequestInfo = true;
      });
    }

    function selectReferenceRequest(request) {
      if (!request) {
        return;
      }
      $scope.isreadyToSubmit = false;
      $scope.displayRefRequestInfo = false;
      $scope.refFilterValue = request;
      // get all the references already attached to this job
      getAttachedRefByApplication($scope.refFilterValue.application_id);
    }

    function validateReferencesSubmition(chosenReferees) {
      let isValid = true;
      if ($scope.references_submitted.length
        >= $scope.refFilterValue.references_requested.reference_requested_count) {
        $rootScope.api_status('alert-danger', 'The number of requested references is already sent', 'Le nombre de références demandées a déjà été envoyée');
        isValid = false;
      }

      if (!chosenReferees.length && $scope.refFilterValue.references_requested) {
        $rootScope.api_status('alert-danger', 'Please choose at least one reference', 'Veuillez choisir au minimum une référence');
        isValid = false;
      }

      if (chosenReferees.length
        > $scope.refFilterValue.references_requested.reference_requested_count
            && chosenReferees.length > $scope.references_submitted.length) {
        $rootScope.api_status('alert-danger', 'You have selected more references than the requested number', 'Vous avez sélectionné plus de références que le nombre demandé');
        isValid = false;
      }
      return isValid;
    }

    function attachNewReferees(chosenReferees) {
      const data = [];
      let refereeData = {};
      _.each(chosenReferees, (referee) => {
        let isAlreadyAttached = null;
        if ($scope.references_submitted.length) {
          isAlreadyAttached = _.find($scope.references_submitted, (ref) => ref.referee_id === referee.id);
        }
        if (!isAlreadyAttached) {
          refereeData = {
            id: 0,
            job_application_id: $scope.refFilterValue.application_id,
            job_id: $scope.refFilterValue.id,
            referee_id: referee.id,
          };
          data.push(refereeData);
        }
      });
      return data;
    }

    function approveReferences() {
      let msgEn;
      let msgFr;
      const chosenReferees = _.filter($scope.refereesList, (ref) => ref.selected === true);
      const isValid = validateReferencesSubmition(chosenReferees);
      if (isValid) {
        $rootScope.api_status('waiting', 'Submitting the referee', 'Envoi votre référence ', 'Loading...', 'Chargement...');
        const allData = {};
        const data = attachNewReferees(chosenReferees);
        if (data.length) {
          allData.data = data;
          allData.company_user_id = $scope.referencesRequested[0].creator_id;
          allData.company_account_id = $scope.refFilterValue.account_id;
          return api.toolkit_batch('reference/job-application-referees/create-batch', allData, 'POST').then((response) => {
            const res = response.data;
            if (res.status === 'success') {
              _.each(chosenReferees, (referee) => {
                if (referee.selected === true) {
                  referee.active = true;
                }
              });
              $scope.refRequestedRemainingCount = $scope.refRequestedRemainingCount - data.length;
            }
            msgEn = chosenReferees.length > 1 ? 'References have been successfully sent!' : 'Reference has been successfully sent!';
            msgFr = chosenReferees.length > 1 ? 'Les références ont été envoyées avec succès!' : 'La référence a été envoyée avec succès!';
            $rootScope.api_status('alert-success', msgEn, msgFr);
          })
            .catch(() => {
              $rootScope.api_status('alert-danger', 'An error occured and no reference could be submitted', 'Un problèmes est survenu et aucune référence n\'a pu être envoyée', "", "", 5000);
            });
        } else {
          msgEn = $scope.references_submitted.length ? 'Please select a reference' : 'Please add a reference';
          msgFr = $scope.references_submitted.length ? 'Veuillez sélectionner une nouvelle référence' : 'Please select a new reference';
          $rootScope.api_status('alert-danger', msgEn, msgFr, "", "", 5000);
        }
      }
    }

    $scope.$on('consentSignedEvent', (event, data) => {
      $scope.isConsentAgreed = data.isConsentAgreed;
    });

    function hideRefForm() {
      $scope.refereesFormVisible = false;
    }

    function clearForm() {
      resetRefereeModel();
    }

    scope = {
      showRefForm,
      hideRefForm,
      clearForm,
      addReferee,
      saveReferee,
      editReferee,
      deleteReferee,
      selectReferenceRequest,
      approveReferences,
    };
    angular.extend($scope, scope);
  }
  CandReferenceModuleCtrl.$inject = [
    '$scope',
    'utils',
    '$rootScope',
    'api',
    '$uibModal',
    '_',
    '$filter',
    'Event',
    'applicationService',
    'MetaTagsService',
    '$state',
  ];
  angular.module('atlas')
    .directive('candReferenceModule', () => ({
      restrict: 'EA',
      scope: {
        active: '@',
        candidate: '=',
        jobs: '=',
        applications: '=',
      },
      controller: CandReferenceModuleCtrl,
      templateUrl: './candidate-profile/directives/references-module/references-module.template.html',
    }));
}(angular));
