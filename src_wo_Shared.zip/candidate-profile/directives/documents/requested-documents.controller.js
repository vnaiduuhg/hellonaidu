/* eslint-disable */
(function (angular) {
  function RequestedDocumentsController(
    $scope,
    $rootScope,
    $compile,
    api,
    utils,
    $uibModal,
    applicationService,
    MetaTagsService,
    $state,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    const MAX_FILE_SIZE = 5; // 5MB
    const VALID_FILE_TYPES = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'odt', 'png', 'jpg', 'jpeg', 'gif', 'txt'];

    const scope = {
      out: utils.out,
      utcToTimezone: utils.utcToTimezone,
      documentRequestsLoading: false,
      jobsLoading: false,
      documentsError: false,
      jobsError: false,
      languageIndex: $rootScope.language === 'en' ? 0 : 1,
      validFileTypes: VALID_FILE_TYPES,
      maxFileSize: MAX_FILE_SIZE,
      searchFilter: '',
      jobs: [],
      documentRequests: [],
      requestsCompletedStats: {},
      downloadDocument,
      markDocumentAsRead,
      filteredJobs,
      openDocumentUploadModel,
      getUploadedFilePath,
      viewUploadedFileModal,
      previewDownloadFileModal,
      manageReceivedDocumentsSection,
      resetViewers: utils.resetViewers,
      documentViewerData: null,
      viewerUrl: null,
      viewerTitle: '', 

      // upload
      fileUploadModel: {},
      fileSelected: null,
      uploadDocTypeError: false,
      uploadFileNameError: false,
      uploadDocLanguageError: false,
      DocumentCollection: [],
      documentsReady: false,
      afterClickOnUpload: false,
      validateFileInfo,
      uploadDoc,
      clearFileValidationErrors
    };
    angular.extend($scope, scope);

    function init() {
      getDocumentRequests();
    }

    function getJobs(jobIds = []) {
      $scope.jobsLoading = true;

      const params = {
        'get_all': 1,
        'ids[]': jobIds,
        "load_with[]": [ 'translations' ]
      };

      api.service_get('jobs', 'job/read-from-id-list', params).then(response => {
        $scope.jobsLoading = false;

        if (response && response.data) {
          $scope.jobs = response.data;
        } else {
          throw new Error('No data returned from jobs API');
        }
      }, () => {
        $scope.jobsError = true;
        $scope.jobsLoading = false;
      });
    }

    function getDocumentRequests() {
      $scope.documentRequestsLoading = true;

      api.service_get('toolkit', 'docutransfer/document-requests').then((response) => {
        $scope.documentRequestsLoading = false;
        
        // TODO: ------------- start remove before production 
        // Debug: remove translations to see worst case scenario
        // response.data.forEach(r => {
        //   delete r.translations[$rootScope.language];

        //   r.read_request_files.forEach(f => {
        //     delete f.translations[$rootScope.language];
        //   });
        //   r.send_request_documents.forEach(f => {
        //     delete f.translations[$rootScope.language];
        //   });
        // });

        // console.log('response.data', response.data);
        // -------------- end remove before production

        // simulate a multi-document upload request for debugging
        // response.data.forEach(r => {
        //   r.send_request_documents.forEach(f => {
        //     f.required_number += 1;
        //   });
        // });

        const documentRequests = response.data;

        if (documentRequests.length === 0) {
          // return out if no document requests
          $scope.documentRequests = documentRequests;
          return;
        } 
        
        const jobIds = [...(new Set(documentRequests.map(documentRequest => documentRequest.application.job_id))).values()];
        getJobs(jobIds);

        setRequestsCompletedStats(documentRequests);
        $scope.documentRequests = documentRequests;        
      }).catch(() => {
        $scope.documentRequestsLoading = false;
        $scope.documentsError = true;
        $scope.documentRequests = [];
      });
    }

    /*
     * Sets the number of requests completed for each job for use by the template.
     * Needs to be called after every request is completed (upload, document viewed and signed).
     */
    function setRequestsCompletedStats(documents = $scope.documentRequests) {
      const stats = {};

      documents.forEach(doc => {
        if (!stats[doc.application.job_id]) {
          stats[doc.application.job_id] = { requested: 0, completed: 0 };
        }

        doc.read_request_files.forEach(f => {
          if (f.pivot.is_read) {
            stats[doc.application.job_id].completed++;
          }

          stats[doc.application.job_id].requested++;
        });

        doc.send_request_documents.forEach(f => {
          stats[doc.application.job_id].completed += f.sent_files.length ? 1 : 0;
          stats[doc.application.job_id].requested += 1;
        });
      });

      $scope.requestsCompletedStats = stats;
    }

    function downloadDocument(doc, type) {
      $rootScope.api_status('waiting', 'Document is being prepared to be downloaded', 'Le document est en préparation pour être téléchargé');

      const fileId = type === 'read-request' ? doc.pivot.read_request_file_id : null;
      const url = type === 'read-request' ? `docutransfer/document-request-templates/read-request-files/${fileId}/url`: null;
      if (!fileId) {
        throw "not yet implemented";
      }

      const errorMsg_EN = 'Failed to download the document.';
      const errorMsg_FR = 'Échec du téléchargement du document.';

      api.service_get('toolkit', url).then((response) => {
        if (response && response.data && response.data.url) {
          saveFileLocally(response.data.url, doc);
        } else {
          $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
        }
        
        // no error handling necessary, silently marks file as downloaded
        api.service_query(
          'toolkit', 
          `docutransfer/document-requests/${doc.pivot.document_request_id}/read-request-files/${fileId}/mark-as-downloaded`,
          'patch', 
        );
      }, () => {
        // handle error
        $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
      });
    }

    function saveFileLocally(url, doc) {
      const errorMsg_EN = 'Failed to download the document.';
      const errorMsg_FR = 'Échec du téléchargement du document.';

      const xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.responseType = 'blob';

      xhr.onload = function () {
        if (this.status === 200) {
          const blobUrl = window.URL.createObjectURL(this.response);

          const a = document.createElement('a');
          document.body.appendChild(a);
          a.style = 'display: none';
          a.href = blobUrl;
          a.download = doc.file_name;
          a.click();
          document.body.removeChild(a);

          $rootScope.api_status(
            'alert-success',
            'Your file has downloaded successfully',
            'Votre fichier est téléchargé avec succès',
            'Download',
            'Téléchargé'
          );
        } else {
          $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
        }
      };

      xhr.onerror = function () {
        $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
      };

      xhr.send();
    }

    function markDocumentAsRead($event, doc) {
      if (!$event.currentTarget.checked) {
        $event.currentTarget.checked = true;
        return;
      }

      api.service_query(
        'toolkit', 
        `docutransfer/document-requests/${doc.pivot.document_request_id}/read-request-files/${doc.pivot.read_request_file_id}/mark-as-read`,
        'patch', 
      ).then(() => {
        setRequestsCompletedStats($scope.documentRequests);
      })
      .catch(() => {
        $rootScope.api_status('alert-danger', 'Failed to mark document as read.', 'Échec de la marque du document comme lu.');
      });
    }

    function filteredJobs() {
      return $scope.jobs
        .filter(job => {
          return job.translations[$scope.languageIndex]?.title
            ? job.translations[$scope.languageIndex].title.toLowerCase().includes($scope.searchFilter.toLowerCase())
            : $scope.languageIndex === 1
              ? job.translations[0].title.toLowerCase().includes($scope.searchFilter.toLowerCase())
              : job.translations[1].title.toLowerCase().includes($scope.searchFilter.toLowerCase());
        }
      );
    }

    
    // start file upload 

    function openDocumentUploadModel(doc) {
      $scope.fileUploadModel = {
        id: doc.id,
        type_id: doc.document_type_id,
      };

      $scope.fileSelected = null;
      clearFileValidationErrors();
      
      documentModalInstance = $uibModal.open({
        animation: true,
        templateUrl: './candidate-profile/views/candidate-modal/upload_document_request_model.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function clearFileValidationErrors() {
      $scope.haveError = false;
      $scope.uploadDocTypeError = false;
      $scope.uploadFileNameError = false;
      $scope.uploadDocLanguageError = false;
      $scope.emptyFile = false;
    }

    function validateFileInfo(file) {
      if (file) $scope.fileSelected = file;
      clearFileValidationErrors();
      $scope.haveError = false;
      
      if (!$scope.fileUploadModel.language) {
        $scope.uploadDocLanguageError = true;
        $scope.haveError = true;
      }
      if (!$scope.fileSelected && !file) {
        $scope.emptyFile = true;
        $scope.haveError = true;
      } else if ((file && (!utils.isFileFormatValid(file.name, VALID_FILE_TYPES) || !utils.isFileSizeValid(file.size, MAX_FILE_SIZE)))
        || ($scope.fileSelected && (!utils.isFileFormatValid($scope.fileSelected.name, VALID_FILE_TYPES) || !utils.isFileSizeValid($scope.fileSelected.size, MAX_FILE_SIZE)))) {
        $scope.haveError = true;
      }
      if ($scope.haveError) {
        return false;
      }
      return true;
    }

    function uploadDoc() {
      if (validateFileInfo()) {
        $scope.afterClickOnUpload = true;
        const file = $scope.fileSelected;
        const formData = angular.copy($scope.fileUploadModel);
        const data = {
          upload_type: 'file',
          file,
          type_id: formData.type_id
        };

        return api.toolkit_fileupload(`docutransfer/document-requests/send-request-documents/${formData.id}/sent-files`, data).then((response) => {
          $scope.status = response.status === 201 || response.status === 200 ? 'success' : 'error';
          $scope.afterClickOnUpload = false;
          documentModalInstance.dismiss('cancel');
          if ($scope.status === 'success') {
            const msgEn = 'Your file uploaded successfully';
            const msgFr = 'Votre fichier a été téléchargé avec succès';
            $rootScope.api_status('alert-success', msgEn, msgFr, 'Uploaded', 'Téléchargé', 3500);
            $scope.fileSelected = null;


            $scope.documentRequests.find(doc => {
              let updatedDocument = doc.send_request_documents.find(file => file.id === formData.id);
              if (updatedDocument) {
                updatedDocument.sent_files.push({...response.data});
                return true;
              } else {
                return false;
              }
            });

            setRequestsCompletedStats();
          }
        }).catch((error) => {
          let msgEn = 'A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance';
          let msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
          if (error.data?.code && error.data.code === 400) {
            if (error.data.message?.file[0] === 'validation.max.file') {
              msgEn = 'Sorry! Your file has a wrong size, please upload a file greater than 0 and smaller than 5 MB';
              msgFr = 'Désolé! Votre fichier a une taille invalide, veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 5 Mo';
            } else if (error.data.message?.file[0] === 'validation.clamav') {
              msgEn = 'Sorry! This file is invalid, please upload a new file';
              msgFr = 'Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier';
            }
          } else if (error.data?.code && error.data.code === 403) {
            msgEn = 'Sorry! Your document library is full. In order to upload a new file, please delete some of your existing files';
            msgFr = 'Désolé! Votre bibliothèque de documents est pleine. Afin de télécharger un nouveau fichier, veuillez supprimer certains de vos fichiers existants';
          }
          $rootScope.api_status('alert-danger', msgEn, msgFr, '', '', 5000);
          $scope.afterClickOnUpload = false;
          documentModalInstance.dismiss('cancel');
        });
      }
      return false;
    }

    // end file upload

    function getUploadedFilePath(file) {
      return api.service_query(
          'toolkit', 
          `docutransfer/document-requests/send-request-documents/sent-files/${file.id}/url`,
          'get'
      ).then((response) => {
        if (response.status === 200 && response.data && typeof response.data.url === 'string') {
          return response.data.url;
        } else {
          throw "Invalid schema or non-200 response: " + response?.status;
        }
      }).catch((error) => {
        if (error.data && error.data.code === 404) {
          $rootScope.api_status('alert-danger', 'File not found', 'Fichier introuvable');
        } else {
          // error 500 and unpredictable
          $rootScope.api_status(
            'alert-danger',
            'Please try again later or contact support@workland.com for assistance',
            'S\'il-vous-plaît veuillez réessayer plus tard ou contactez support@workland.com pour assistance',
            'An error has occurred',
            'Une erreur est survenue',
            7500
          );
        }
        throw error ?? new Error("Failed to get public url");
      });
    }

    function viewUploadedFileModal(file) {
      $scope.documentViewerData = { file, mode: 'uploaded-file' };

      const modal = document.getElementById('document-viewer-modal');
      modal.addEventListener('hidden.bs.modal', function (event) {
        $scope.viewerUrl = null;
        $scope.resetViewers(modal);
      });

      $scope.viewerTitle = file.file_name;

      const viewerModal = new bootstrap.Modal(modal);
      viewerModal.show();
      $scope.viewerUrl = null;

      getUploadedFilePath(file).then((url) => {
        $scope.viewerUrl = url;
      }).catch(() => {
        $scope.viewerUrl = null;
        $scope.resetViewers(modal);
        viewerModal.hide();
      });
    }

    function previewDownloadFileModal(doc) {
      $scope.documentViewerData = { mode: 'download-file' };

      const fileId = doc.pivot.read_request_file_id;
      const errorMsg_EN = 'Failed to download the document.';
      const errorMsg_FR = 'Échec du téléchargement du document.';

      $scope.viewerTitle = doc.file_name;
      const modal = document.getElementById('document-viewer-modal');
      modal.addEventListener('hidden.bs.modal', function (event) {
        $scope.viewerUrl = null;
        $scope.resetViewers(modal);
      });

      const viewerModal = new bootstrap.Modal(modal);
      viewerModal.show();
      $scope.viewerUrl = null;

      api.service_get('toolkit', `docutransfer/document-request-templates/read-request-files/${fileId}/url`).then((response) => {
        if (response && response.data && response.data.url) {
          $scope.viewerUrl = response.data.url;
        } else {
          $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
        }
      }, () => {
        // handle error
        $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
      });
      
    }

    function manageReceivedDocumentsSection(doc) {
      if (!doc.isOpen) {
        doc.isOpen = true;
      } else {
        doc.isOpen = false;
      }
    }

    init();
  }

  RequestedDocumentsController.$inject = [
    '$scope',
    '$rootScope',
    '$compile',
    'api',
    'utils',
    '$uibModal',
    'applicationService',
    'MetaTagsService',
    '$state',
  ];
  angular.module('atlas')
    .controller('requested-documents', RequestedDocumentsController);
}(angular));
