(function (angular) {
  function myDocumentsController(
    $scope,
    api,
    utils,
    MetaTagsService,
    $state,
    $filter,
    $uibModal,
    $sce,
    $ngConfirm,
    $rootScope,
    $stateParams,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    let scope = {
      out: utils.out,
      fileUploadModel: {},
      uploadDocTypeError: false,
      uploadFileNameError: false,
      uploadDocLanguageError: false,
      DocumentCollection: [],
      documentsReady: false,
      errorMsg: false,
    };
    angular.extend($scope, scope);

    function clearFileValidationErrors() {
      $scope.haveError = false;
      $scope.uploadDocTypeError = false;
      $scope.uploadFileNameError = false;
      $scope.uploadDocLanguageError = false;
      $scope.emptyFile = false;
    }

    let documentModalInstance;

    function openDocumentUploadModel() {
      $scope.fileUploadModel = {};
      $scope.fileSelected = null;
      clearFileValidationErrors();
      documentModalInstance = $uibModal.open({
        animation: true,
        templateUrl: './candidate-profile/views/candidate-modal/upload_document_model.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function getDocumentCategories() {
      $scope.documentCategories = [];
      api.service_get('toolkit', 'document-manager/candidate-file-versions/document-types').then((response) => {
        angular.forEach(response.data.message, (value, key) => {
          $scope.documentCategories.push({ id: value.id, fr: { title: value.name_fr }, en: { title: value.name } });
        });
      });
    }

    function showDocument(doc) {
      $scope.openPersonalityReport = false;
      $scope.clickedPersonalityReport = false;
      utils.hideClasses();
      if (doc && doc.id) {
        $scope.clickedDocument = doc.id;
        const extension = doc.file_name.toLowerCase().split('.').pop();
        switch (extension) {
          case 'pdf':
            navigator.pdfViewerEnabled ? utils.showNativePdfFile(doc) : utils.showPdfFile(doc);
            break;
          case 'ppt':
          case 'pptx':
          case 'doc':
          case 'docx':
          case 'xls':
          case 'xlsx':
          case 'odt':
            utils.showOfficeFile(doc);
            break;
          case 'png':
          case 'tif':
          case 'tiff':
          case 'bmp':
          case 'jpg':
          case 'jpeg':
          case 'gif':
            utils.showImage(doc);
            break;
          case 'txt':
            utils.showTxtFile(doc);
            break;
          default:
            window.document.getElementById('Enable-docViewer').style.display = 'block';
        }
      }
    }

    function getCandidateAllDocuments(upload = null) {
      $scope.documentsReady = false;
      return api.service_get('toolkit', 'document-manager/candidate-file-versions/list').then((response) => {
        $scope.DocumentCollection = response.data.data.message;
        $scope.documentsReady = true;
        window.onload = () => {
          if ($scope.DocumentCollection.length > 0) {
            if (upload) {
              showDocument($scope.DocumentCollection[$scope.DocumentCollection.length - 1]);
            } else {
              showDocument($scope.DocumentCollection[0]);
            }
          }
        };
        $scope.cvIsAvailable = $filter('filter')($scope.DocumentCollection, { type_id: 1 }, true);
      }).catch(() => {
        $scope.DocumentCollection = [];
        $scope.errorMsg = true;
        $scope.documentsReady = true;
      });
    }

    function isFileFormatValid(file) {
      const ext = file.toLowerCase().split('.').pop();
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'rtf' || ext === 'txt') {
        return true;
      }
      return false;
    }

    function isFileSizeValid(size) {
      if (size > 0 && size / (1048576) <= 5) {
        return true;
      }
      return false;
    }

    function validateFileInfo(file) {
      if (file) $scope.fileSelected = file;
      clearFileValidationErrors();
      $scope.haveError = false;
      if (!$scope.fileUploadModel.documentCategory) {
        $scope.uploadDocTypeError = true;
        $scope.haveError = true;
      }
      if (!$scope.fileUploadModel.description) {
        $scope.uploadFileNameError = true;
        $scope.haveError = true;
      }
      if (!$scope.fileUploadModel.language) {
        $scope.uploadDocLanguageError = true;
        $scope.haveError = true;
      }
      if (!$scope.fileSelected && !file) {
        $scope.emptyFile = true;
        $scope.haveError = true;
      } else if ((file && (!isFileFormatValid(file.name) || !isFileSizeValid(file.size)))
        || ($scope.fileSelected && (!isFileFormatValid($scope.fileSelected.name) || !isFileSizeValid($scope.fileSelected.size)))) {
        $scope.haveError = true;
      }
      if ($scope.haveError) {
        return false;
      }
      return true;
    }

    function uploadDoc() {
      if (validateFileInfo()) {
        $scope.afterClickOnUpload = true;
        const file = $scope.fileSelected;
        const formData = angular.copy($scope.fileUploadModel);
        const data = {
          upload_type: 'file',
          file_name: formData.description,
          is_deleted: 0,
          file,
          registered_users: 1,
          candidate_id: $rootScope.currentUser.user.id,
          type_id: formData.documentCategory.id,
        };
        return api.toolkit_fileupload('document-manager/candidate-file-versions/create', data).then((response) => {
          $scope.status = response.data.status;
          $scope.afterClickOnUpload = false;
          documentModalInstance.dismiss('cancel');
          if ($scope.status === 'success') {
            getCandidateAllDocuments('upload');
            const msgEn = 'Your file uploaded successfully';
            const msgFr = 'Votre fichier a été téléchargé avec succès';
            $rootScope.api_status('alert-success', msgEn, msgFr, 'Uploaded', 'Téléchargé', 3500);
            $scope.fileSelected = null;
          }
        }).catch((error) => {
          let msgEn = 'A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance';
          let msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
          if (error.data?.code && error.data.code === 400) {
            if (error.data.message?.file[0] === 'validation.max.file') {
              msgEn = 'Sorry! Your file has a wrong size, please upload a file greater than 0 and smaller than 5 MB';
              msgFr = 'Désolé! Votre fichier a une taille invalide, veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 5 Mo';
            } else if (error.data.message?.file[0] === 'validation.clamav') {
              msgEn = 'Sorry! This file is invalid, please upload a new file';
              msgFr = 'Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier';
            }
          } else if (error.data?.code && error.data.code === 403) {
            msgEn = 'Sorry! Your document library is full. In order to upload a new file, please delete some of your existing files';
            msgFr = 'Désolé! Votre bibliothèque de documents est pleine. Afin de télécharger un nouveau fichier, veuillez supprimer certains de vos fichiers existants';
          }
          $rootScope.api_status('alert-danger', msgEn, msgFr, '', '', 5000);
          $scope.afterClickOnUpload = false;
          documentModalInstance.dismiss('cancel');
        });
      }
      return false;
    }

    function removeFile(document) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: $scope.out('Supprimer le document', 'Delete document'),
        content: $scope.out('Êtes-vous sûr de vouloir supprimer?', 'Are you sure you want to delete?'),
        type: 'red',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          yes: {
            text: $scope.out('Oui', 'Yes'),
            btnClass: 'btn btn-danger float-end',
            action() {
              const request = api.service_post('toolkit', `document-manager/candidate-file-versions/temporaryDelete/${document.id}`, {});
              request.then((res) => {
                if (res.status === 200) {
                  $rootScope.api_status('alert-success', 'File deleted!', 'Fichier supprimé!');
                  const index = $scope.DocumentCollection.indexOf(document);
                  $scope.DocumentCollection.splice(index, 1);
                  if ($scope.DocumentCollection.length > 0) {
                    showDocument($scope.DocumentCollection[0]);
                  }
                }
              });
            },
          },
          no: {
            text: $scope.out('Non', 'No'),
            btnClass: 'btn btn-alt-danger',
            action() {},
          },
        },
      });
    }

    function buildCandidateOriginalCVUrl() {
      const baseUrl = 'https://docs.google.com/gview?';
      const params = {
        url: $rootScope.currentUser.originalCvUrl,
        embedded: true,
      };
      return $sce.trustAsResourceUrl(baseUrl + utils.buildQueryStr(params));
    }

    $scope.openPersonalityReport = false;

    function showUploadedFile(document) {
      utils.hideClasses();
      $scope.loadingDoumentSpinner = true;
      if (document === 'PersonalityReport') {
        $scope.openPersonalityReport = true;
        $scope.clickedPersonalityReport = true;
        $scope.loadingDoumentSpinner = false;
      }
    }

    $scope.clearFileModel = () => {
      $scope.fileSelected = null;
    };

    $scope.hoverIn = function () {
      this.hoverEdit = true;
    };

    $scope.hoverOut = function () {
      this.hoverEdit = false;
    };

    function init() {
      getCandidateAllDocuments();
      getDocumentCategories();
      if ($stateParams.upload) {
        openDocumentUploadModel();
      }
    }

    init();

    scope = {
      buildCandidateOriginalCVUrl,
      uploadDoc,
      removeFile,
      showUploadedFile,
      showDocument,
      openDocumentUploadModel,
      validateFileInfo,
      clearFileValidationErrors,
    };
    angular.extend($scope, scope);
  }

  myDocumentsController.$inject = [
    '$scope',
    'api',
    'utils',
    'MetaTagsService',
    '$state',
    '$filter',
    '$uibModal',
    '$sce',
    '$ngConfirm',
    '$rootScope',
    '$stateParams',
  ];
  angular.module('atlas')
    .controller('candidate-documents', myDocumentsController);
}(angular));
