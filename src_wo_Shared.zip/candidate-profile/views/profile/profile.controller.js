// const { utils } = require('rrweb');

(function (angular) {
  function ProfileController(
    $scope,
    $rootScope,
    $sce,
    api,
    utils,
    referencesQuestions,
    Event,
    _,
    $filter,
    $location,
    $anchorScroll,
    $uibModal,
    $timeout,
    $q,
    $ngConfirm,
    MetaTagsService,
    $state,
    // matchService,
    worklandLocalize,
    applicationService,
    userAccountsService,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function createAnObject(key, label, others) {
      const obj = {
        key,
        label,
      };
      if (others) {
        angular.forEach(others, (v, k) => {
          obj[k] = v;
        });
      }
      return obj;
    }

    let scope = {
      nocFunction: { selected: {} },
      seekingPosition: { selected: {} },
      seekingCategory: { selected: {} },
      seekingFunction: { selected: {} },
      defaultSeekingPositions: utils.getSeekingPositions(),
      strings: worklandLocalize.strings,
      profile: $rootScope.currentUser.user,
      inProg: {},
      tabs: {
        _tab_matches: {
          disabled: false,
        },
      },
      profileTabs: {
        'wl-profile-edit': true,
      },
      icons: worklandLocalize.iconsUrl,
      nameFields: [
        createAnObject('first_name', utils.out('Prénom', 'First name')),
        createAnObject('last_name', utils.out('Nom', 'Last name')),
      ],
      socialIcons: [
        createAnObject('facebookUrl', 'Facebook', { icon: 'new-social-icon/facebook_white' }),
        createAnObject('linkedinUrl', 'LinkedIn', { icon: 'new-social-icon/linkedin_white' }),
        createAnObject('twitterUrl', 'Twitter', { icon: 'new-social-icon/twitter_white' }),
        createAnObject('websiteUrl', utils.out('Site web', 'Website'), { icon: 'new-social-icon/website_white' }),
      ],
      forms: {},
      referencesQuestions: referencesQuestions.questions,
      out: utils.out,
      referenceRequest: null,
      refFilterValue: null,
      questionnaire_administration: false,
      all: {},
      errorMsg: false,
      DocumentCollection: [],
      profileCompletionCounted: false,
      // matchingProgressCounted: false,
      autocomplete: null,
      autocompleteInput: null,
      metas: [],
      documentsReady: false,
      gotApplicationsAndJobs: false,
      jobs: [],
      applications: [],
      jobsAppliedCount: 0,
      jobApplicationError: false,
      // candidateJobMatches: 0,
      candidateJobApplied: 0,
      candidateRefernces: 0,
      candidateInterviewRequests: 0,
      candidateInterviews: [],
      firstInitDone: false,
      colours: ['#6948F4', '#e1ecf5'],
      options: {
        percentageInnerCutout: 80,
        segmentShowStroke: true,
        segmentStrokeWidth: 1,
        segmentStrokeColor: '#e1ecf5',
      },
      dashboardProgressLabels: [utils.out('progrès', 'progress'), utils.out('en cours', 'pending')],
    };
    angular.extend($scope, scope);

    $scope.currentUser = $rootScope.currentUser.user;
    $scope.isCandidate = $rootScope.currentUser.permissions.isCandidate;
    $scope.isInternalEmployee = $rootScope.currentUser.permissions.isInternalEmployee;
    const minioUrl = `${window.appConfig.MINIO_URL}media/Profile/Logos/`;

    $(() => {
      $('.fileUploadBox input').on('change', function () {
        $('.fileUploadBox #fileSector').text(`${this.files.length} file(s) selected`);
        $('.fileUploadBox #textSpace').text(document.getElementById('file').value.split(/(\\|\/)/g).pop());
        $('.fileUploadBox #selectButton').text('Select Another File');
      });
    });

    $scope.contactUser = $rootScope.currentUser.account_user[0].contact;

    $scope.tagHandler = function (tag) {
      return null;
    };

    function getProfileLogo() {
      if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].photo) {
        return `${minioUrl}${$rootScope.currentUser.account.detail[0].photo}?cachebuster=${Math.random()}`;
      }
      return `${minioUrl}generic_avatar.jpg`;
    }

    function reloadCandidateData() {
      api.service_get('accounts', `accounts/${$rootScope.currentUser.account.id}`).then((response) => {
        if (response.data.status === 'success' && response.data.data.account.detail.length > 0) {
          if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].photo) {
            $rootScope.currentUser.account.detail[0].photo = response.data.data.account.detail[0].photo;
          } else {
            userAccountsService.getCurrentUserData();
            $rootScope.currentUser.account.detail[0].photo = response.data.data.account.detail[0].photo;
          }
          $scope.candidatePhoto = getProfileLogo();
        }
      });
    }

    function uploadCandidatePhoto(file) {
      if (!file.$error) {
        $scope.loadingPhoto = true;
        const accountId = $rootScope.currentUser.account.id;
        const data = {
          type: 'file',
          file,
        };
        return api.userAccountsFileUpload(`accounts/candidates/${accountId}/upload/photo`, data)
          .then((response) => {
            if (response.data.status === 'success') {
              reloadCandidateData();
            } else {
              $rootScope.api_status(
                'alert-danger',
                'Sorry, upload failed!',
                'Désolé, le téléchargement a échoué!',
                null, null, 2500,
              );
            }
            $scope.loadingPhoto = false;
          }).catch((error) => {
            let msgFr;
            let msgEn;
            if (error.data?.message && error.data.message === 'virus_detected_in_file') {
              msgFr = 'Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier';
              msgEn = 'Sorry! This file is invalid, please upload a new file';
            } else if (error.data?.message && error.data.message === 'file_exceed_maximum_size') {
              msgFr = 'Le fichier excède la taille maximale autorisée de 1Mo';
              msgEn = 'The file exceeds the maximum size allowed of 1Mb';
            } else {
              msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
              msgEn = 'A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance';
            }
            $rootScope.api_status('alert-danger', msgEn, msgFr, 'Upload has failed!', 'Le téléchargement a échoué!', 5000);
            $scope.loadingPhoto = false;
          });
      }
      $scope.loadingPhoto = false;
      if (file.$error === 'pattern') {
        $rootScope.api_status(
          'alert-danger',
          'Accepted Image Formats: .jpg, .jpeg, .png, .gif',
          'Formats d\'images acceptés: .jpg, .jpeg, .png, .gif',
          null, null, 3500,
        );
      }
      if (file.$error === 'maxSize') {
        $rootScope.api_status(
          'alert-danger',
          'The file exceeds the maximum size allowed of 1Mb',
          'Le fichier excède la taille maximale autorisée de 1Mo',
          null, null, 3500,
        );
      }
      if (file.$error === 'minSize') {
        $rootScope.api_status(
          'alert-danger',
          'Please upload a file greater than 0 and smaller than 1Mb',
          'Veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 1 Mo',
          null, null, 3500,
        );
      }
    }

    //* ********
    const { out } = utils;

    // Active questionnaire tab when loading question custome sections
    Event.on('questionnaire.loadCustomSections', ($event, jobId) => {
      const { tabs } = $scope;
      tabs._tab_questionnaire = tabs._tab_questionnaire || {};
      tabs._tab_questionnaire.active = true;
      tabs._tab_questionnaire.customJobId = jobId;
      // @test
      $scope.jobId = jobId; // ????
    });

    Event.on('TabSelected', ($event, tabName) => {
      switch (tabName) {
        case 'interviews':
          // getCandidateInterviewsNew();
          break;
                    // no default
      }
    });

    function checkProfileProgress() {
      let completionPercent = 0;
      if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].photo) {
        completionPercent += 20;
      }
      if ($rootScope.currentUser.account_user && $rootScope.currentUser.account_user[0].user.phone) {
        $scope.currentUser.phone = $rootScope.currentUser.account_user[0].user.phone;
        completionPercent += 30;
      }
      if ($rootScope.currentUser.location) {
        completionPercent += 20;
      }
      if ($scope.DocumentCollection.length > 0) {
        completionPercent += 30;
      }
      $scope.profileCompletion = completionPercent;
      $scope.profileCompletionData = [completionPercent, (100 - completionPercent)];
      $scope.profileCompletionCounted = true;
    }

    function getCandidateAllDocuments() {
      $scope.documentsReady = false;
      $scope.errorMsg = false;
      return api.service_get('toolkit', 'document-manager/candidate-file-versions/list').then((response) => {
        $scope.DocumentCollection = response.data.data.message;
        $scope.documentsReady = true;
        $scope.cvIsAvailable = $filter('filter')($scope.DocumentCollection, { type_id: 1 }, true);
      }).catch(() => {
        $scope.DocumentCollection = [];
        $scope.errorMsg = true;
        $scope.documentsReady = true;
      }).finally(() => {
        checkProfileProgress();
      });
    }

    function tabSelected(tabName, param) {
      $rootScope.activeTab = tabName.replace('candidate', '');
      $anchorScroll();
      switch (tabName) {
        case 'psychometrictest':
          $state.go(tabName, { jobId: $scope.jobId });
          break;
        case 'pendingquestionnaires':
          $state.go(tabName, { currentCandidate: $scope.currentUser, jobs: $scope.jobs });
          break;
        case 'questionnaire':
          $state.go(tabName, { jobId: $scope.jobId });
          break;
        // case 'matches':
        //   break;
        case 'mydocuments':
          $state.go(tabName, { upload: param });
          break;
        default:
          $state.go(tabName);
      }
      $scope.tabs[`_tab_${tabName}`] = $scope.tabs[`_tab_${tabName}`] || {};
      _.each($scope.tabs, (tab, key) => {
        tab.active = false;
      });
      $scope.tabs[`_tab_${tabName}`].active = 'active';
      Event.broadcast('TabSelected', tabName);
    }

    function setUserAddress(userAddress) {
      if (userAddress
                && !_.isEmpty(userAddress)
                && userAddress.formatted_address
                && userAddress.address_components
                && userAddress.address_components.length) {
        $scope.currentUser.fullAddress = userAddress.formatted_address;
        $scope.userLocation = utils.setLocationObject(userAddress);
      } else {
        $rootScope.api_status(
          'error',
          'Invalid address, please make sure to choose one of the autocomplete suggestion',
          'Adresse non valide, veuillez vous assurer de choisir l\'une des suggestions de saisie semi-automatique',
        );
      }
    }

    function loadGoogleApi() {
      $timeout(() => {
        $scope.autocomplete = new google.maps.places.Autocomplete($scope.autocompleteInput);
        $scope.autocomplete.setFields(['address_components', 'formatted_address', 'place_id', 'geometry']);
        $scope.autocomplete.addListener('place_changed', () => {
          const userAddress = $scope.autocomplete.getPlace();
          setUserAddress(userAddress);
        });
      }, document.ready);
    }

    $scope.loadGoogleAutocomplete = function () {
      const autocompleteInput = document.getElementById('google-address');
      if (!$scope.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
        $scope.autocompleteInput = autocompleteInput;
        loadGoogleApi();
      }
    };

    function setFormFieldVal(form, field, val) {
      _.each($scope.forms[form].$editables, (editable) => {
        if (editable.name === field) {
          editable.scope.$data = val;
        }
      });
    }

    function inProg(key) {
      $scope.inProg[key] = true;
      return function () {
        $scope.inProg[key] = false;
      };
    }

    function testSocialLink(userInput) {
      pattern = /^http:\/\//;
      res = pattern.test(userInput);
      return res;
    }

    function updateContactInformationByAccountUserId(key, value) {
      if (['facebook', 'twitter', 'linkedin', 'website'].includes(key)) {
        const prefix= testSocialLink(value);
        if (!prefix) {
          value = 'http://'.concat(value);
          Object.keys($scope.contactUser).forEach( function(k) {
            if (k === key) $scope.contactUser[k] = value; 
          });
        }
      }
      const data = {};
      data[key] = value;
      const accountUserId = $rootScope.currentUser.account_user[0].id;
      const prog = inProg(key);
      const promise = api.service_query('accounts', `account-users/${accountUserId}/contact`, 'PUT', data);
      promise.finally(prog);
      return promise;
    }

    function updateCandidateAccount(key, value) {
      const data = { detail: {} };
      data.detail[key] = value;
      const accountId = $rootScope.currentUser.account.id;
      const prog = inProg(key);
      const promise = api.service_query('accounts', `accounts/candidates/${accountId}`, 'PUT', data);
      promise.finally(prog);
      return promise.then(() => {
        userAccountsService.getCurrentUserData(); // refresh info
      });
    }

    function updateUser(key, value) {
      let pattern;
      let res = true;
      if (key === 'phone' || key === 'mobile') {
        // 1 in the beginning is optional, area code is required, spaces or dashes can be used as optional divider between number groups.
        pattern = /^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4})$/;
        res = pattern.test(value);
      }
      if (key === 'first_name' || key === 'last_name') {
        pattern = /^[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]+(([',. -][áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z ])?[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]*)*$/;
        res = pattern.test(value);
      }

      if (res === false) {
        $ngConfirm({
          icon: 'fa fa-exclamation',
          title: out('Erreur', 'Error'),
          content: key === 'phone' ? out('Mauvais format de numéro de téléphone.',
            'Wrong phone number format.') : out('Désolé, seulement les lettres sont autorisées.',
            'Sorry, only letters are allowed.'),
          type: 'red',
          typeAnimated: true,
          animation: 'RotateX',
          buttons: {
            Ok: {
              text: 'Ok',
              btnClass: 'btn-secondary',
              keys: ['enter', 'shift'],
              action() {

              },
            },
          },
        });
        return false;
      }
      const data = {};
      data[key] = value;
      const prog = inProg(key);
      const promises = [];
      const promiseUser = api.service_query('accounts', `users/${$rootScope.currentUser.user.id}`, 'PUT', data);
      promiseUser.finally(prog);
      if (key === 'phone') {
        promises.push(updateContactInformationByAccountUserId(key, value)); // need to update phone in user and contacts for candidate
      }
      promises.push(promiseUser);
      return $q.all(promises);
    }

    function showRefForm() {
      $scope.referenceFormVisible = true;
    }

    function hideRefForm() {
      $scope.referenceFormVisible = false;
    }

    function toGetInterviewLength() {
      $scope.interviewsError = false;
      $scope.interviewCountLoaded = false;
      const url = 'interview/interviews';
      const promise = $scope.promiseInterviews = api.service_get('toolkit', url, {
        attendee_confirmed: 1,
        expired: 0,
        'filter_by_candidate_id[]': $rootScope.currentUser.user.id,
      });
      return promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.candidateInterviews = response.data.data.result;
          $scope.candidateInterviewRequests = response.data.data.count;
        } else {
          $scope.interviewsError = true;
        }
        $scope.interviewCountLoaded = true;
      }).catch(() => {
        $scope.interviewsError = true;
        $scope.interviewCountLoaded = true;
      });
    }

    function toGetJobsLength() {
      $scope.jobApplicationError = false;
      $scope.jobsAppliedCount = 0;
      $scope.jobsApplicationsPending = 0;
      $scope.applications = [];
      $scope.jobs = [];
      return applicationService.get_query_with_auth('application/current-candidate/applications').then((res) => {
        if (res && res.data) {
          const userApplications = res.data;
          if (userApplications.length > 0) {
            $scope.applications = userApplications;
            $scope.jobs_ids = _.pluck(_.uniq($scope.applications, 'job_id'), 'job_id');
            if ($scope.jobs_ids.length > 0) {
              const params = {
                'ids[]': $scope.jobs_ids,
                get_all: 1,
              };
              api.service_get('jobs', 'job/read-from-id-list', params).then((response) => {
                if (response && response.data) {
                  $scope.gotApplicationsAndJobs = true;
                  $scope.jobs = response.data;
                  if ($scope.jobs.length > 0) {
                    angular.forEach($scope.jobs, (job) => {
                      if (job.id) {
                        // to be sure to take the first application if we have many with same id, we stop the process when we find it.
                        // Applications are sorted by newest first
                        let i = -1;
                        do {
                          i += 1;
                          if (+$scope.applications[i].job_id === +job.id) {
                            job.date = $scope.applications[i].updated_at;
                            job.application_status = $scope.applications[i].status;
                            job.application_id = $scope.applications[i].id;
                            if ($scope.applications[i].status === 'submitted') {
                              $scope.jobsAppliedCount += 1;
                            } else {
                              $scope.jobsApplicationsPending += 1;
                            }
                            // @todo get questionnaire pending
                            // job.questionnaire_pending = application.questionnaire_pending;
                          }
                        } while (+$scope.applications[i].job_id !== +job.id && i < $scope.applications.length - 1);
                      }
                    });
                    $scope.candidateJobApplied = $scope.jobsAppliedCount;
                  }
                } else {
                  $scope.candidateJobApplied = $scope.jobsAppliedCount = -1;
                  $scope.jobApplicationError = true;
                }
              }).catch(() => {
                $scope.candidateJobApplied = $scope.jobsAppliedCount = -1;
                $scope.jobApplicationError = true;
              });
            }
          }
        } else {
          $scope.candidateJobApplied = $scope.jobsAppliedCount = -1;
          $scope.jobApplicationError = true;
        }
      }).catch(() => {
        $scope.candidateJobApplied = $scope.jobsAppliedCount = -1;
        $scope.jobApplicationError = true;
      });
    }

    function toGetMatchesLength() {
      // @temp not called
      if ($scope.isUserId && $scope.loadRevmatchFlag) {
        const path = 'revmatch';
        const revmatchResults = [];
        const promiseRevMatch = matchService.getData(path);
        promiseRevMatch.then((response) => {
          if (response.data.status === 'ok') {
            const matchedData = response.data.data;
            _.each(matchedData, (data) => {
              revmatchResults.push(_.pick(data, 'requestId', 'match'));
            });

            const jobIds = _.pluck(revmatchResults, 'requestId');
            if (jobIds.length > 0) {
              const params = {
                'ids[]': jobIds,
                get_all: 1,
              };
              api.service_get('jobs', 'job/read-from-id-list', params)
                .then((res) => {
                  if (res.data) {
                    $scope.candidateJobMatches = res.data.length;
                    $scope.tabs._tab_matches.disabled = false;
                  }
                });
            } else {
              $scope.candidateJobMatches = 0;
            }
          }
          $scope.matchingCountLoaded = true;
        });
      }
    }

    function toGetQuestinnarieLength() {
      // @temp not called
      $scope.loadRevmatchFlag = false;
      const params = {
        lang: $rootScope.language,
      };
      matchService.getData('answer', params)
        .then((response) => {
          if (response.data.status === 'error') {
            $scope.matchingCountLoaded = true;
            $scope.candidateQuestionnarieLength = 0;
            $scope.matchingErrorMessage = utils.out('Désolé, une erreur s\'est produite lors de la récupération des réponses pour l\'algorithme de match.',
              'Sorry, there was an error while fetching answers for the matching algorithm.');
          } else {
            $scope.Questionnariedata = response.data.data;
            $scope.matchingErrorMessage = '';
            $scope.candidateQuestionnarieLength = Math.ceil(($scope.Questionnariedata._nbMandatoryAnsweredQuestions / $scope.Questionnariedata._nbMandatoryTotalQuestions) * 100);
            $scope.candidateQuestionnarieData = [$scope.candidateQuestionnarieLength, (100 - $scope.candidateQuestionnarieLength)];
            $scope.matchingProgressCounted = true;
            if ($scope.candidateQuestionnarieLength === 100) {
              $scope.loadRevmatchFlag = true;
              return toGetMatchesLength();
            }
            $scope.matchingCountLoaded = true;
          }
          return $scope.candidateQuestionnarieLength;
        });
    }

    function checkUserInMatchDB() {
      // @temp commented
      // $scope.matchingCountLoaded = false;
      // matchService.getData('user')
      //   .then((res) => {
      //     if (res && (res.status === 200 || res.status === 201)) {
      //       if (res.data.data.notFound == true) {
      //         const obj = {
      //           groupId: 'employee',
      //         };
      //         matchService.postData('user', obj)
      //           .then((result) => {
      //             $scope.isUserId = result.data.status === 'ok';
      //             toGetQuestinnarieLength();
      //           });
      //       } else if (res.data.status === 'ok') {
      //         $scope.isUserId = true;
      //         toGetQuestinnarieLength();
      //       }
      //     }
          $scope.dashboardReady = true;
        // }).catch(() => {
        //   $scope.dashboardReady = true;
        // });
    }

    function resetAddressUtil() {
      $scope.metas = [];
    }

    function resetUserAddress() {
      $scope.currentUser.fullAddress = '';
      resetAddressUtil();
    }

    function displayUserAddress(address) {
      const streetNumber = address.street_number ? `${address.street_number} ` : '';
      const street = `${address.street}, `;
      const city = `${address.city}, `;
      const province = address.province ? `${address.province}, ` : '';
      // let country = address.country + ' ';
      const postalCode = address.postal_code;
      const userAddress = streetNumber + street + city + province + postalCode;
      return userAddress;
    }

    function clearRelatedFunction() {
      $scope.seekingFunction.selected = {};
    }

    function getReferenceRequestCount(referenceRequests) {
      return _.filter(referenceRequests, (ref) => _.find($scope.jobs, (job) => +job.id === +ref.job_id));
    }

    function getCandidateReferences() {
      api.service_get('toolkit', 'reference/reference-requests/candidate-side')
        .then((response) => {
          const res = response.data;
          if (res.status === 'success') {
            $scope.candidateRefernces = getReferenceRequestCount(res.data.result).length;
          }
        });
    }

    function getJobCategories() {
      return api.service_get('shared', 'jobCategory').then((response) => {
        if (response.data) {
          $scope.categoryList = response.data;
        } else {
          // @todo handle this error case
          $scope.categoryList = [];
        }
      }).then(() => {
        if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].seeking_id) {
          $scope.currentUser.seeking = $rootScope.currentUser.account.detail[0].seeking_id;
          $scope.seekingPosition.selected = _.find($scope.defaultSeekingPositions, (position) => $scope.currentUser.seeking === position.key);
        }

        $scope.$watch('categoryList', () => {
          if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].category_id) {
            $scope.seekingCategoryId = $rootScope.currentUser.account.detail[0].category_id;
            $scope.seekingCategory.selected = _.find($scope.categoryList, (category) => +$scope.seekingCategoryId === +category.id);
          }
          if ($rootScope.currentUser.account.detail.length > 0 && $rootScope.currentUser.account.detail[0].category_function_id) {
            $scope.currentUser.seekingNocFunctionId = $rootScope.currentUser.account.detail[0].category_function_id;
          }
          if ($scope.seekingCategory.selected) {
            _.find($scope.categoryList, (forCategory) => {
              if (+$scope.seekingCategory.selected.id === +forCategory.id) {
                _.find(forCategory.default_functions, (fnctn) => {
                  if (+$scope.currentUser.seekingNocFunctionId === +fnctn.id) {
                    $scope.seekingFunction.selected = fnctn;
                  }
                });
              }
            });
          }
        });
      }).catch(() => {
        // @todo handle this error case
        $scope.categoryList = [];
      });
    }

    $scope.updatelocation = function () {
      if ($scope.userLocation) {
        if ($scope.currentUser.fullAddress) {
          $scope.all.addressEditMode = false;
          api.service_post('shared', 'location', { locations: [$scope.userLocation] })
            .then((response) => {
              const updatedLocationId = response.data[0].id;
              updateContactInformationByAccountUserId('location_id', updatedLocationId);
              resetAddressUtil();
            }).catch(() => {
              // @todo
            });
        } else {
          $ngConfirm({
            title: out('', ''),
            content: out('Désolé, un problème est survenu. Veuillez actualiser la page pour mettre à jour votre adresse.',
              'Sorry, there is a problem. Please refresh the page to update your address.'),
            type: 'red',
            typeAnimated: true,
            animation: 'RotateX',
            buttons: {
              Ok: {
                text: 'Ok',
                btnClass: 'btn-secondary',
                keys: ['enter', 'shift'],
                action() {
                  window.location.reload();
                },
              },
            },
          });
          $scope.metas = [];
        }
      } else {
        $scope.all.addressEditMode = false;
      }
    };

    function loadDashboard() {
      $scope.matchingCountLoaded = false;
      // @temp added
      $scope.matchingCountLoaded = true;
      $scope.candidateJobMatches = 0;
      // @temp end
      $scope.promise = $q.all([
        toGetJobsLength(),
        getJobCategories(),
      ]).then(() => {
        if (!$scope.firstInitDone) {
          toGetInterviewLength();
          getCandidateReferences();
          $scope.firstInitDone = true;
        }
        checkUserInMatchDB();
      });
    }

    function showSocialEditable(key) {
      $scope[key].$show();
    }

    function toggleSocialLink(item) {      
      angular.forEach($scope.socialIcons, (icon) => {
        if (icon.key !== item.key) icon.visible = false;
      })
      item.visible = !item.visible;
    }

    function init() {
      $scope.dashboardReady = false;
      $scope.worklandAvatar = './../assets/images/lady.svg';
      $scope.mobileSidePanelValue = 'hidden-xs hidden-sm';
      $scope.isSidePanelOpen = false;
      const urlTab = $location.$$url.replace(/\/|-/g, '');
      $state.go(urlTab);
      $scope.currentUser = $rootScope.currentUser.user;
      $scope.candidate = $rootScope.currentUser.user;
      if ($rootScope.currentUser.location) {
        $scope.currentUser.fullAddress = displayUserAddress($rootScope.currentUser.location);
      }
      $scope.candidatePhoto = getProfileLogo();
      getCandidateAllDocuments();
      loadDashboard();
      tabSelected(urlTab);
      if ($rootScope.activeTab) {
        tabSelected($rootScope.activeTab);
        if ($rootScope.activeTab === 'applications') {
          $scope.all.selectJobTab = 'appliedJobs';
        } else if ($rootScope.activeTab === 'references') {
          $scope.all.selectRefernceTab = 'referenceList';
        } else if ($rootScope.activeTab === 'mydocuments' || $rootScope.activeTab === 'requesteddocuments') {
          $scope.all.selectDocumentsTab = $rootScope.activeTab === 'mydocuments' ? 'myDocuments' : 'requestedDocuments';
        }
      }
    }

    init();

    scope = {
       tabSelected,
      setFormFieldVal,
      showRefForm,
      hideRefForm,
      checkProfileProgress,     
      toGetInterviewLength,
      toGetJobsLength,
      // toGetMatchesLength,
      loadDashboard,
      clearRelatedFunction,
      resetUserAddress,
      resetAddressUtil,
      updateUser,
      updateCandidateAccount,
      updateContactInformationByAccountUserId,
      uploadCandidatePhoto,      
      showSocialEditable,
      toggleSocialLink,
    };
    angular.extend($scope, scope);
  }

  ProfileController.$inject = [
    '$scope',
    '$rootScope',
    '$sce',
    'api',
    'utils',
    'referencesQuestions',
    'Event',
    '_',
    '$filter',
    '$location',
    '$anchorScroll',
    '$uibModal',
    '$timeout',
    '$q',
    '$ngConfirm',
    'MetaTagsService',
    '$state',
    // 'matchService',
    'worklandLocalize',
    'applicationService',
    'userAccountsService',
  ];

  angular.module('atlas')
    .controller('profile', ProfileController);
}(angular));
