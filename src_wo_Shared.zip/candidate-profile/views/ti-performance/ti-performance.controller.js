(function (angular) {
    'use strict';
    angular.module('atlas')
            .controller('TiPerformanceCtrl', TiPerformanceCtrl);

    TiPerformanceCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', '$timeout', '$http'];

    function TiPerformanceCtrl($scope,
            $rootScope,
            api,
            utils,
            $timeout,
            $http
            ) {

        var scope = {
            out: utils.out,
//            userId: CandidateProfile.data.ID,
            tiPerformanceGetTest: tiPerformanceGetTest,
            tiPerformance: {selected: '', waiting: true},
            slider_ticks_values: '',
            setupQuizScreen: setupQuizScreen,
            isAttempted: isAttempted,
            startTest: startTest,
            nextQuestionnaire: nextQuestionnaire,
            nextQuestion: nextQuestion,
            previousQuestion:previousQuestion
        };


        angular.extend($scope, scope);

        init();

        $scope.date = new Date();
        $scope.questionnaireee = 0;
        $scope.timelinePanel = 12;
        $scope.timelineContent = false;
        $scope.mainPanel = 0;
        $scope.hideMainPanel = "0 hidden-md hidden-lg";
        //TI Performance actions begin here

        function tiPerformanceGetTest() {
            $http.get("./candidate-profile/views/ti-performance/XMLs/questions.xml",
                    {
                        transformResponse: function (cnv) {
                            var x2js = new X2JS();
                            var aftCnv = x2js.xml_str2json(cnv);
                            return aftCnv;
                        }
                    })
                    .success(function (response) {
                        $scope.tiPerformance = response;
                        $scope.tiPerformance.waiting = false;
                    });

        }

        function setupQuizScreen(quizLanguage)
        {
            var msgEn = "We are fetching the questions.";
            var msgFr = "Nous allons chercher les questions.";
            $rootScope.api_status("waiting", msgEn, msgFr);
            $scope.tcAccepeted = true;
            $timeout(function () {
                $scope.tiPerformance.questions.activeLanguage = quizLanguage === 'en' ? $scope.out("Anglais", "English") : $scope.out("Français", "French");
                angular.forEach($scope.tiPerformance.questions.questionnaire, function (value, key) {
                    value.active = quizLanguage === 'en' ? value.english : value.french;
                });
            }, 1);

            var promise = api.service_get('toolkit', 'tiperformance/answered-questionnaires?filter_by_user_id=' + $rootScope.currentUser.user.id);
            promise.then(function (response) {
                $scope.status = response.data.status;
                if ($scope.status === "success") {
                    $rootScope.api_status('alert-success');
                    $scope.attemptedSections = response.data.data.result;
                    if ($scope.attemptedSections.length > 0) {
                        isAttempted($scope.tiPerformance.questions.questionnaire[0]);
                    }
                    $scope.timelinePanel = 3;
                    $scope.timelineContent = true;
                    $scope.mainPanel = 9;
                    $scope.hideMainPanel = "";
                }
                else {
                    var msgEn = "Sorry! There is Error while starting your test. Please contact our support team.";
                    var msgFr = "Pardon! Il y a une erreur en commençant votre test. Veuillez contacter notre équipe de support.";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);

                }
                $scope.tcAccepeted = false;
            }).catch(function (error) {
                var msgEn = "Sorry! There is Error while starting your test. Please contact our support team.";
                var msgFr = "Pardon! Il y a une erreur en commençant votre test. Veuillez contacter notre équipe de support.";
                $rootScope.api_status('alert-danger', msgEn, msgFr);
                $scope.tcAccepeted = false;
            });
        }

        function isAttempted(questionnaire) {
            angular.forEach($scope.attemptedSections, function (value, key) {
                if (value.section_id === $scope.questionnaireee + 1) {
                    $scope.questionnaireee = $scope.questionnaireee + 1;
                    isAttempted(questionnaire);
                }
            });
            if($scope.tiPerformance.questions.questionnaire.length === $scope.questionnaireee)
                $scope.isTestCompleted=true;
        }

        function startTest(questionnaire) {
            questionnaire.showQuestions = true;
            questionnaire.questionToShow = 0;
            $scope.section = {
                "section_id": $scope.questionnaireee + 1,
                "tianswers": []
            };
            $scope.savingQuestions = false;
        }

        function nextQuestionnaire(questionnaire) {
            $scope.savingQuestions = true;
            var promise = api.service_post('toolkit', 'tiperformance/answered-questionnaires', $scope.section);
            promise.then(function (response) {
                $scope.status = response.data.status;
                if ($scope.status === "success") {
                    $scope.questionnaireee = $scope.questionnaireee + 1;
                    isAttempted(questionnaire);
                }
                else {
                    var msgEn = "Sorry! There is an error while saving your answers. Please contact our support team.";
                    var msgFr = "Pardon! Il y a une erreur lors de l'enregistrement de vos réponses. Veuillez contacter notre équipe de support.";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                    $scope.savingQuestions = false;
                }

            }).catch(function (error) {
                var msgEn = "Sorry! There is an error while saving your answers. Please contact our support team.";
                var msgFr = "Pardon! Il y a une erreur lors de l'enregistrement de vos réponses. Veuillez contacter notre équipe de support.";
                $rootScope.api_status('alert-danger', msgEn, msgFr);
                $scope.savingQuestions = false;
            });

        }

        function nextQuestion(questionnaire, question) {
            var ans = "";

            if (question.choix.length == 4 || question.choix.length == 18 || question.choix.length == 6) {
                angular.forEach(question.choix, function (value, key) {
                    ans = ans + value._No;
                    if (key < question.choix.length - 1) {
                        ans = ans + ",";
                    }
                });
            }
            else if (question.choix.length != 4 && question.choix.length != 18 && question.choix.length != 6) {
                ans = question.value.toString();
            }
            var data = {
                "question_id": question._No,
                "answer": ans
            };
            $scope.section.tianswers.push(data);
            questionnaire.questionToShow = questionnaire.questionToShow + 1;
        }
        
        function previousQuestion(questionnaire){
            $scope.section.tianswers.splice(-1,1);
            questionnaire.questionToShow = questionnaire.questionToShow - 1;
        }

        //TI Performance ends here



        function init() {
            tiPerformanceGetTest();
            $scope.slider_ticks_values = {
                value: 3,
                options: {
                    ceil: 6,
                    floor: 1,
                    showTicksValues: true,
                    translate: function (value) {
                        return value;
                    }
                }
            };
        }

    }

})(angular);
