(function (angular) {
  function IsedPendingQuestionnairesModuleCtrl(
    $scope,
    $rootScope,
    $stateParams,
    api,
    utils,
    _,
    $window,
    $location,
    MetaTagsService,
    $state,
    $interval,
  ) {    
    const vm = this;
    $scope.jobs = $stateParams.jobs;
    let vmExtend = {
      out: utils.out,
      utcToTimezone: utils.utcToTimezone,
      start: false,
      language: $rootScope.language,
    };
    angular.extend(vm, vmExtend);

    const update = function () {
	    $scope.dateNow = utils.datetimeToUTC(new Date());     
    };

    update();

    const interval = $interval(update, 1000);

    function loadQuestionnaires() {
      vm.loadindIsedSpinner = false;
      vm.questionnaires = [];
      vm.pendingQuestionnairePromise = api.service_get('toolkit', 'questionnaire/dispatched-questionnaires', {
        filter_by_candidate_id: $rootScope.currentUser.user.id,
        load_with: 'questionnaire',
      }).then((response) => {
        if (response.data.data.result) {
          vm.questionnaires = response.data.data.result;
        }
        vm.loadindIsedSpinner = true;
      }).catch(() => {
        $rootScope.api_status(
          'alert-danger',
          'Error fetching questionnaire! Please contact our support team.',
          'Erreur de questionnaire! SVP contacter notre équipe de support.',
        );
        vm.loadindIsedSpinner = true;
      });
    }

    function answerQuestionnaire(questionnaire) {
      vm.dispatched_questionnaire = questionnaire;
      vm.start = true;
    }

    function init() {
      loadQuestionnaires();
    }

    init();

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
      $interval.cancel(interval);
    });

    vmExtend = {
      answerQuestionnaire,
      loadQuestionnaires,
    };
    angular.extend(vm, vmExtend);
  }
  IsedPendingQuestionnairesModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    '$stateParams',
    'api',
    'utils',
    '_',
    '$window',
    '$location',
    'MetaTagsService',
    '$state',
    '$interval',
  ];
  angular.module('atlas')
    .directive('isedPendingQuestionnaires', () => ({
      scope: {},
      bindToController: {
        candidate: '=',
      },
      controller: IsedPendingQuestionnairesModuleCtrl,
      controllerAs: 'vm',
      templateUrl: './candidate-profile/ised/ised-pending-questionnaires-module.template.html',
    }));
}(angular));
