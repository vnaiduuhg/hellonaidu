(function (angular) {
  function isedNewQuestionController(
    $scope,
    $rootScope,
    api,
    utils,
    _,
    worklandLocalize,
    $ngConfirm,
  ) {

    const { out } = utils;
    const scope = {
      isAdmin: $rootScope.currentUser.permissions.isAdmin,
      strings: worklandLocalize.strings,
      out,
      questionData: {
        extra: {},
      },
      selected: {},
      forms: {},
      classificationCtrl: {
        isCalssificationCollapsed: false,
        isNewSectionCollapsed: true,
        isNewSubsectionCollapsed: true,
      },
      showSubsectionErrorValidation: false,
      newQuestionData: {},
      selectedQuestionType: { selected: '' },
      questionTypes: [
        {
          id: 'mc-ms',
          translations: {
            fr: 'Choix multiple',
            en: 'Multiple Choice'
          },
        }, {
          id: 'yes-no',
          translations: {
            fr: 'Oui/Non',
            en: 'Yes/No'
          },
        }, {
          id: 'format',
          translations: {
            fr: 'Pré-formaté',
            en: 'Pre-formatted'
          },
        }, {
          id: 'mc-ss',
          translations: {
            fr: 'Choix unique',
            en: 'Single Choice'
          },
        }, {
          id: 'scale',
          translations: {
            fr: 'Échelle',
            en: 'Scale'
          },
        }, {
          id: 'desc',
          translations: {
            fr: 'Descriptif',
            en: 'Descriptive'
          },
        }, {
          id: 'table',
          translations: {
            fr: 'Tableau',
            en: 'Table'
          },
        },
      ],
      selectedQuestionFormat: { selected: '' },
      formatFields: [
        {
          id: 'date',
          translations: {
            fr: 'Date',
            en: 'Date'
          },
        }, {
          id: 'address',
          translations: {
            fr: 'Adresse',
            en: 'Address'
          },
        }, {
          id: 'phone-number',
          translations: {
            fr: 'Téléphone',
            en: 'Phone'
          },
        },
      ],
      loadingSubSections: false,
      mcAddChoices,
      mcAddaChoice,
      mcRemoveChoice,
      setUpTable,
      addTag,
      removeTag,
      toggleClassification,
      toggleNewSection,
      toggleNewSubsection,
      saveQuestion,
      loadSubsections,
    };
    angular.extend($scope, scope);

    init();
    function init() {
      if ($scope.question) {
        $scope.questionData = angular.copy($scope.question);
      }
    }

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    $scope.selectQuestionType = (selectedType) => {
      $scope.questionData.type = selectedType.id;
    }

    $scope.selectQuestionFormat = (selectedFormat) => {
      $scope.questionData.selectedfield = selectedFormat.id;
    }

    function setUpTable() {
      if ($scope.questionData.type !== 'table') {
        return;
      }
      let i;
      if ($scope.questionData.extra.numRows) {
        if (!$scope.questionData.rows) {
          $scope.questionData.rows = [];
          for (i = 0; i < $scope.questionData.extra.numRows; i++) {
            $scope.questionData.rows.push({ question_id: 0, en: { title: '' }, fr: { title: '' } });
          }
        } else if ($scope.questionData.extra.numRows < $scope.questionData.rows.length) {
          $scope.questionData.rows.splice($scope.questionData.extra.numRows);
        } else {
          for (i = $scope.questionData.rows.length; i < $scope.questionData.extra.numRows; i++) {
            $scope.questionData.rows.push({ question_id: 0, en: { title: '' }, fr: { title: '' } });
          }
        }
      }
      if ($scope.questionData.extra.numCols) {
        if (!$scope.questionData.cols) {
          $scope.questionData.cols = [];
          for (i = 0; i < $scope.questionData.extra.numCols; i++) {
            $scope.questionData.cols.push({ question_id: 0, en: { title: '' }, fr: { title: '' } });
          }
        } else if ($scope.questionData.extra.numCols < $scope.questionData.cols.length) {
          $scope.questionData.cols.splice($scope.questionData.extra.numCols);
        } else {
          for (i = $scope.questionData.cols.length; i < $scope.questionData.extra.numCols; i++) {
            $scope.questionData.cols.push({ question_id: 0, en: { title: '' }, fr: { title: '' } });
          }
        }
      }
    }

    function mcAddChoices() {
      if ($scope.questionData.type !== 'mc-ms'
                      && $scope.questionData.type !== 'mc-ss'
                      && !$scope.questionData.extra.numChoices) {
        return;
      }
      $scope.questionData.choices = [];
      for (let i = 0; i < $scope.questionData.extra.numChoices; i++) {
        $scope.questionData.choices.push({ en: { title: '', description: 'null' }, fr: { title: '', description: 'null' } });
      }
    }

    function mcAddaChoice() {
      if ($scope.questionData.type !== 'mc-ms'
                      && $scope.questionData.type !== 'mc-ss'
                      && !$scope.questionData.extra.numChoices) {
        return;
      }
      $scope.questionData.choices.push({ en: { title: '', description: 'null' }, fr: { title: '', description: 'null' } });
      $scope.questionData.extra.numChoices++;
    }

    function mcRemoveChoice(pos) {
      $scope.questionData.choices.splice(pos, 1);
      $scope.questionData.extra.numChoices--;
    }

    function addTag(section, subsection) {
      const indx = _.findIndex($scope.sectionsCtrl.tags, (tag) => (tag.section_id === section.id && tag.subsection_id === subsection.id));
      if (indx >= 0) {
        return;
      }
      const tag = {
        section_id: section.id,
        subsection_id: subsection.id,
        s_name: section.name,
        s_name_fr: section.name_fr,
        ss_name: subsection.name,
        ss_name_fr: subsection.name_fr,
      };
      $scope.sectionsCtrl.tags.push(tag);
      $scope.sectionsCtrl.tagsChanged = true;
    }

    function removeTag(pos) {
      $scope.sectionsCtrl.tags.splice(pos, 1);
      $scope.sectionsCtrl.tagsChanged = true;
    }

    function toggleClassification() {
      $scope.classificationCtrl.isCalssificationCollapsed = !$scope.classificationCtrl.isCalssificationCollapsed;
      $scope.classificationCtrl.isNewSectionCollapsed = true;
      $scope.classificationCtrl.isNewSubsectionCollapsed = true;
      $scope.selected = {
        section: {}
      };
      $scope.sectionsCtrl.subsections = null;
    }

    function toggleNewSection() {
      $scope.classificationCtrl.isNewSectionCollapsed = !$scope.classificationCtrl.isNewSectionCollapsed;
      $scope.selected = {
        section: {}
      };
      $scope.sectionsCtrl.subsections = null;
    }

    function toggleNewSubsection() {
      if (!$scope.selected.section.id) {
        if ($scope.classificationCtrl.isNewSubsectionCollapsed) {
            $scope.showSubsectionErrorValidation = true;
        }
        return;
      }
      $scope.showSubsectionErrorValidation = false;
      $scope.classificationCtrl.isNewSubsectionCollapsed = !$scope.classificationCtrl.isNewSubsectionCollapsed;
      const indx = _.findIndex($scope.sectionsCtrl.sections, (section) => $scope.selected.section.id === section.id);
      if (indx >= 0) {
        $scope.selected.section = $scope.sectionsCtrl.sections[indx];
      }
    }

    function saveQuestion() {
      // if question and selectField
      if ($scope.questionData.type == 'format' && !$scope.questionData.selectedfield) {
        $ngConfirm({
          icon: 'fa fa-exclamation',
          title: $scope.out('Attention', 'Attention'),
          content: utils.out('Veuillez sélectionner le format de la question', 'Please select the format of the question'),
          type: 'blue',
          typeAnimated: true,
          animation: 'RotateX',
          buttons: {
            ok: {
              text: 'ok',
              btnClass: 'btn-blue',
              action() {
              },
            },
          },
        });
        return false;
      }

      $rootScope.api_status('waiting', 'Creating your question...', 'Création de votre question...');
      const question = {};

      // question main attributes
      question.type = $scope.questionData.type;
      question.score_size = $scope.questionData.score_size;
      question.pass_mark = $scope.questionData.pass_mark;

      // title and description of question
      if ($scope.questionData.en.title) {
        const en_object = {
          title: $scope.questionData.en.title,
          description: $scope.questionData.en.description,
        };
        question.en = en_object;
      }
      if ($scope.questionData.fr.title) {
        const fr_object = {
          title: $scope.questionData.fr.title,
          description: $scope.questionData.fr.description,
        };
        question.fr = fr_object;
      }
      // if question and selectField
      if ($scope.questionData.type == 'format' && $scope.questionData.selectedfield) {
        question.format = $scope.questionData.selectedfield;
      }
      // choices of question
      if ($scope.questionData.choices) {
        question.choices = $scope.questionData.choices;
      }
      // if section is selected or subsection is selected
      if ($scope.selected.subsection && !_.isEmpty($scope.selected.subsection)) {
        question.categories = [{ id: $scope.selected.subsection.id }];
      } else if ($scope.selected.section && !_.isEmpty($scope.selected.section)) {
        question.categories = [{ id: $scope.selected.section.id }];
      }
      // if scale question is selected (maximum scale length)
      if ($scope.questionData.scale_range) {
        question.scale_range = $scope.questionData.scale_range;
      }
      // if there is row and cols
      if ($scope.questionData.rows && $scope.questionData.cols) {
        question.rows = $scope.questionData.rows;
        question.columns = $scope.questionData.cols;
      }

      $scope.waitPromise = api.service_post('toolkit', 'questionnaire/questions', question).then((response) => {
        const res = response.data;
        if (res.status == 'success') {
          $scope.newQuestionData.id = res.data.result.id;
          if ($scope.questionnaireData) {
            addQuestion2Questionnaire($scope.newQuestionData.id);
          } else if ($scope.followUp) {
            addFollowUpQuestion($scope.newQuestionData.id);
          } else {
            $scope.callBack($scope.newQuestionData);
            $scope.cancel();
            $rootScope.api_status('alert-success', 'Sucessfully created', 'Créée avec succès');
          }
        } else {
          showNewQuestionsErrorMsg('save');
        }
      }).catch((error) => {
        let errorMsg = '';
        if (error && error.data && error.data.data && error.data.data.result) {
          errorMsg = error.data.data.result;
        }
        switch (errorMsg) {
          case 'Token has expired':
            showNewQuestionsErrorMsg('token_expired');
            break;
          default:
            showNewQuestionsErrorMsg('save');
        }
      });
    }

    function loadSubsections(section) {
      $scope.showSubsectionErrorValidation = false;
      $scope.loadingSubSections = true;
      const promise = api.service_get('toolkit', 'questionnaire/categories', { filter_by_parent_category_id: section.id });
      promise.then((response) => {
        const res = response.data;
        if (res.status == 'success') {
          $scope.sectionsCtrl.subsections = response.data.data.result;
        }
        $scope.loadingSubSections = false;
      }).catch((error) => {
        let errorMsg = '';
        if (error && error.data && error.data.data && error.data.data.result) {
          errorMsg = error.data.data.result;
        }
        switch (errorMsg) {
          case 'Token has expired':
            showNewQuestionsErrorMsg('token_expired');
            break;
          default:
        }
        $scope.loadingSubSections = false;
      });
    }

    function addQuestion2Questionnaire(question_id) {
      const data = {
        questionnaire_id: $scope.questionnaireData.id,
        question_id,
        rank: ++$scope.questionnaireData.questions.length,
      };
      $scope.waitPromise = api.service_post('toolkit', 'questionnaire/questionnaire-questions', data).then((response) => {
        const res = response.data;
        if (res.status == 'success') {
          $scope.callBack();
          $scope.cancel();
          $rootScope.api_status('alert-success', 'Sucessfully created', 'Créée avec succès');
        } else {
          showNewQuestionsErrorMsg('attached_to_questionnaire');
        }
      }).catch((error) => {
        let errorMsg = '';
        if (error && error.data && error.data.data && error.data.data.result) {
          errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
        }
        switch (errorMsg) {
          case 'Token has expired':
            showNewQuestionsErrorMsg('token_expired');
            break;
          case 'the_questionnaire_is_already_used':
            showNewQuestionsErrorMsg('is_used');
            break;
          default:
            showNewQuestionsErrorMsg('attached_to_questionnaire');
        }
      });
    }

    // @todo check
    function addFollowUpQuestion(question_id) {
      let data;
      if ($scope.question.type == 'yes-no') {
        if ($scope.selectedChoice.translation.en.title == 'Yes') {
          data = {
            id: 0,
            choice_condition: 0,
            bool_condition: true,
            reject_candidate: false,
            head_q_question_id: $scope.bundle.question.id,
            tail_q_question_id: question_id,
          };
        } else {
          data = {
            id: 0,
            choice_condition: 0,
            bool_condition: false,
            reject_candidate: false,
            head_q_question_id: $scope.bundle.question.id,
            tail_q_question_id: question_id,
          };
        }
      } else {
        data = {
          id: 0,
          choice_condition: $scope.selectedChoice.id,
          bool_condition: false,
          reject_candidate: false,
          head_q_question_id: $scope.bundle.question.id,
          tail_q_question_id: question_id,
        };
      }
      $scope.waitPromise = api.service_post('toolkit', 'questionnaire/question-branches', data).then((response) => {
        const res = response.data;
        if (res.status == 'success') {
          $scope.callBack($scope.newQuestionData);
          $scope.cancel();
          $rootScope.api_status('alert-success', 'Sucessfully created', 'Créée avec succès');
        } else {
          showNewQuestionsErrorMsg('save_followup');
        }
      }).catch((error) => {
        let errorMsg = '';
        if (error && error.data && error.data.data && error.data.data.result) {
          errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
        }
        switch (errorMsg) {
          case 'Token has expired':
            showNewQuestionsErrorMsg('token_expired');
            break;
          case 'the_questionnaire_is_already_used':
            showNewQuestionsErrorMsg('is_used');
            break;
          default:
            showNewQuestionsErrorMsg('save_followup');
        }
      });
    }

    function showNewQuestionsErrorMsg(action) {
      let msgEn = 'An error has occurred ';
      let msgFr = 'Une erreur est survenue ';
      switch (action) {
        case 'save':
          msgEn = `${msgEn}and the question could not be saved`;
          msgFr = `${msgFr}et la question n'a pu être sauvegardée`;
          break;
        case 'save_followup':
          msgEn = `${msgEn}and the subquestion could not be saved`;
          msgFr = `${msgFr}et la sous-question n'a pu être sauvegardée`;
          break;
        case 'attached_to_questionnaire':
          msgEn = 'The question has been created but could not be attached to questionnaire';
          msgFr = "La question a été créée mais n'a pas pu être jointe au questionnaire";
          break;
        case 'token_expired':
          msgEn = 'Your session has expired, please login again';
          msgFr = 'Votre session est expirée, veuillez vous connecter à nouveau';
          break;
        case 'is_used':
          msgEn = 'This questionnaire is used and cannot be modified, however the question has been saved on questions bank';
          msgFr = 'Ce questionnaire est utilisé et ne peut être modifié, par contre la question a été enregistrée dans la banque de questions';
          break;
        default:
      }
      $rootScope.api_status('alert-danger', msgEn, msgFr);
    }

  }
  isedNewQuestionController.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
    'worklandLocalize',
    '$ngConfirm',
  ];

  angular.module('atlas')
    .directive('isedNewQuestion', () => ({
      scope: {
        question: '=',
        questionId: '=',
        newQuestionData: '=',
        label: '=',
        sectionsCtrl: '=',
        editCtr: '=',
        questionnaireData: '=',
        followUp: '=',
        bundle: '=',
        selectedChoice: '=',
        cancel: '&',
        callBack: '&',
      },
      controller: isedNewQuestionController,
      templateUrl: './employer-profile/ised/questions/ised-new-question.template.html',
    }));
}(angular));
