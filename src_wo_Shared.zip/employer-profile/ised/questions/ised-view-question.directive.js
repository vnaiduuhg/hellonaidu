( function ( angular ) {
    'use strict';

    angular.module( 'atlas' )
    .directive( 'isedViewQuestion', function ( ) {

		return {
		    scope: {
		    },
		    bindToController: {
                question: '=',
                editCtr:'=',
                label: '=',
                edit: '&',
                delete: '&',
                clone: '&',
                cloneQuestionOnly: '&',
                setConditions: '&',
                callBack: '&',
                showButton: '=',
                questionnaireAttachedToJob: '=',
                questionnaireData: '=',
                completeQuestion: '=',
                isFollowupQuestion: '='
		    },
		    controller: IsedViewQuestionController,
		    controllerAs: 'vm',
		    templateUrl: './employer-profile/ised/questions/ised-view-question.template.html'
		};
    } );

    IsedViewQuestionController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$uibModal', 'Event', '_'];

    function IsedViewQuestionController( $scope, $rootScope, api, utils, $uibModal, Event, _ ) {
        var vm = this;
        var vmExtend = {
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: utils.out,
            range: _.range,
            sortableOptions: {
                stop: sortableStop
            },
            readConditions: false
        };
        angular.extend( vm, vmExtend );
        init();

        function init() {
            if(vm.question){
                vm.question.extra ={};
            }
            if(vm.completeQuestion) {
                vm.question.conditions = vm.completeQuestion.question_branches ? vm.completeQuestion.question_branches : false;
                if(vm.question.conditions && vm.question.type == 'mc-ss') {
                    setConditionsTitle(vm.question);
                }
            }
        }

        function setConditionsTitle(question) {
            _.each(question.conditions, function(q) {
                const choice = _.find(question.choices, function(c) {
                    return c.id == q.choice_condition_id;
                });
                q.translation = choice.translation;
            });
        }

        $scope.$watch( 'vm.question', function ( nVal ) {
            if ( nVal.type === 'scale' ) {
                vm.question.extra.slider = {
                    index: Math.floor( vm.question.scale_range / 2 ),
                    options: {
                        floor: 1,
                        ceil: vm.question.scale_range,
                        showTicks: true,
                        showTicksValues: true
                    }
                };
            }
        });

        function sortableStop(e, ui) {
            var sortedChoices = [];
            var newRanks = [];
            _.each(ui.item.sortable.sourceModel, function (item, i) {
                item.rank = i;
                sortedChoices.push(item);
                newRanks.push({"choice_id":item.id, "question_id": vm.question.id});
            });
            api.service_post('toolkit', 'questionnaire/questions/update-rank/' +vm.question.id, {
                choice_question_ids: newRanks
            }, 'update').then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    vm.question.choices = sortedChoices;
                }
                else {
                    $rootScope.api_status(
                        "error",
                        "An error has occurred, and question rank could not be updated",
                        "Une erreur est survenue et le rang de la question n'a pu être mis à jour"
                    );
                }
            }).catch(function (error) {
                $rootScope.api_status(
                    "alert-danger",
                    "An error has occurred, and question rank could not be updated",
                    "Une erreur est survenue et le rang de la question n'a pu être mis à jour"
                );
            });
        }

        vm.toggleReadConditions = () => {
            vm.readConditions = !vm.readConditions;
        }
    }

} )( angular );
