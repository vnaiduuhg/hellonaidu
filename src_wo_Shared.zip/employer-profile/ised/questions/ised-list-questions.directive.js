( function ( angular ) {
    function IsedListQuestionsController( $scope, $rootScope, utils, _) {
        var scope = {
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: utils.out,
            selectedQuestion: null,
            filtering: {
                subsections: [],
                theFilter: {},
                keyword: ''
            },
            selectQuestion: selectQuestion,
            sectionFilterSelected: sectionFilterSelected,
            subsectionFilterSelected: subsectionFilterSelected
        };
        angular.extend( $scope, scope );
        function selectQuestion( question ) {
            $scope.select( {selectedQuestion: question} );
        }

        function sectionFilterSelected( section ) {
            $scope.selectedQuestion = null;
            $scope.filtering.selectedSubsection = null;
            $scope.filtering.subsections = [];
            $scope.filtering.theFilter = {
            };
            if ( section ) {
                $scope.filtering.subsections = section.subsections;
                $scope.filtering.theFilter = {
                    tags: {section_id: section.id}
                };
            }
        }

        function subsectionFilterSelected( subsection ) {
            $scope.selectedQuestion = null;
            if ( subsection ) {
                $scope.filtering.theFilter.tags.subsection_id = subsection.id;
            }
        }
    }

    IsedListQuestionsController.$inject = [
        '$scope', 
        '$rootScope',
        'utils',
        '_',
    ];

    angular.module( 'atlas' )
        .directive( 'isedListQuestions', function ( ) {
        return {
            scope: {
            questions: '=',
            sectionsCtrl: '=',
            select: '&'
            },
            controller: IsedListQuestionsController,
            templateUrl: './employer-profile/ised/questions/ised-list-questions.template.html'
        };
    } );
    
} )( angular );