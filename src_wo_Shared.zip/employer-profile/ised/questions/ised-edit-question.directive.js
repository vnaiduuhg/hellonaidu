( function ( angular ) {
    'use strict';
    angular.module( 'atlas' )
	    .directive( 'isedEditQuestion', function () {
		return {
		    scope: {
                question: '=',
                questionData: '=',
                label: '=',
                sectionsCtrl: '=',
                editCtr:'=',
                questionnaireData:'=',
                cancel: '&',
                callBack: '&',
                replaceQuestionCallBack: '&',
                replaceFollowupQCallBack: '&',
                cloningQuestionAction: '=',
		    },
		    controller: IsedEditQuestionController,
		    templateUrl: './employer-profile/ised/questions/ised-edit-question.template.html'
		};
    } );

    IsedEditQuestionController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$uibModal', 'Event', '_', 'worklandLocalize'];

    function IsedEditQuestionController( $scope, $rootScope, api, utils, $uibModal, Event, _, worklandLocalize ) {

        var out = utils.out;
        var scope = {
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            strings: worklandLocalize.strings,
            out: out,
            range: _.range,
            selected: {
                section: {}
            },
            forms: {},
            classificationCtrl: {
                isCalssificationCollapsed: false,
                isNewSectionCollapsed: true,
                isNewSubsectionCollapsed: true
            },
            showSubsectionErrorValidation: false,
            selectedQuestionType: { selected: '' },
            questionTypes: [
                {
                id: 'mc-ms',
                translations: {
                    fr: 'Choix multiple',
                    en: 'Multiple Choice'
                },
                }, {
                id: 'yes-no',
                translations: {
                    fr: 'Oui/Non',
                    en: 'Yes/No'
                },
                }, {
                id: 'format',
                translations: {
                    fr: 'Pré-formaté',
                    en: 'Pre-formatted'
                },
                }, {
                id: 'mc-ss',
                translations: {
                    fr: 'Choix unique',
                    en: 'Single Choice'
                },
                }, {
                id: 'scale',
                translations: {
                    fr: 'Échelle',
                    en: 'Scale'
                },
                }, {
                id: 'desc',
                translations: {
                    fr: 'Descriptif',
                    en: 'Descriptive'
                },
                }, {
                id: 'table',
                translations: {
                    fr: 'Tableau',
                    en: 'Table'
                },
                },
            ],
            selectedQuestionFormat: { selected: '' },
            formatFields: [
                {
                id: 'date',
                translations: {
                    fr: 'Date',
                    en: 'Date'
                },
                }, {
                id: 'address',
                translations: {
                    fr: 'Adresse',
                    en: 'Address'
                },
                }, {
                id: 'phone-number',
                translations: {
                    fr: 'Téléphone',
                    en: 'Phone'
                },
                },
            ],
            loadingSubSections: false,
            mcAddChoices: mcAddChoices,
            mcAddaChoice: mcAddaChoice,
            mcRemoveChoice: mcRemoveChoice,
            setUpTable: setUpTable,
            addTag: addTag,
            removeTag: removeTag,
            toggleClassification: toggleClassification,
            toggleNewSection: toggleNewSection,
            toggleNewSubsection: toggleNewSubsection,
            updateQuestion:updateQuestion,
            updateOrReplaceQuestion: updateOrReplaceQuestion,
            cloneAndAttachQuestion: cloneAndAttachQuestion,
            loadSubsections:loadSubsections
        };
        angular.extend( $scope, scope );

        init();
        function init() {
            $scope.edited_question = angular.copy( $scope.question ); 
            if($scope.edited_question.extra) {
                $scope.edited_question.extra.numChoices = $scope.edited_question.choices.length;
            }
            else {
                $scope.edited_question.extra = {
                    numChoices: $scope.edited_question.choices.length
                }
            }
            const qType = _.find($scope.questionTypes, (type => type.id === $scope.edited_question.type));
            if (qType) $scope.selectedQuestionType.selected = qType;
            if ($scope.edited_question.format) {
                const qFormat = _.find($scope.formatFields, (format => format.id === $scope.edited_question.format));
                if (qFormat) $scope.selectedQuestionFormat.selected = qFormat;
            }
        }

        $scope.tagHandler = function (tag) {
            return null; // official hack to workaround angular issue
        };

        $scope.selectQuestionType = (selectedType) => {
            $scope.edited_question.type = selectedType.id;
        }

        $scope.selectQuestionFormat = (selectedFormat) => {
            $scope.edited_question.selectedfield = selectedFormat.id;
        }

        function setUpTable() {
            if ( $scope.edited_question.type !== 'table' ) {
                return;
            }
            if ( $scope.edited_question.extra.numRows ) {
                if ( !$scope.edited_question.extra.rows ) {
                    $scope.edited_question.extra.rows = [];
                    for ( var i = 0; i < $scope.edited_question.extra.numRows; i++ ) {
                        $scope.edited_question.extra.rows.push( {'en':{'title':''}, 'fr':{'title':''}} );
                    }
                } else {
                    if ( $scope.edited_question.extra.numRows < $scope.edited_question.extra.rows.length ) {
                        $scope.edited_question.extra.rows.splice( $scope.edited_question.extra.numRows );
                    } else {
                        for ( var i = $scope.edited_question.extra.rows.length; i < $scope.edited_question.extra.numRows; i++ ) {
                            $scope.edited_question.extra.rows.push( {'en':{'title':''}, 'fr':{'title':''}} );
                        }
                    }
                }
            }
            if ( $scope.edited_question.extra.numCols ) {
                if ( !$scope.edited_question.extra.cols ) {
                    $scope.edited_question.extra.cols = [];
                    for ( var i = 0; i < $scope.edited_question.extra.numCols; i++ ) {
                        $scope.edited_question.extra.cols.push( {'en':{'title':''}, 'fr':{'title':''}} );
                    }
                } else {
                    if ( $scope.edited_question.extra.numCols < $scope.edited_question.extra.cols.length ) {
                        $scope.edited_question.extra.cols.splice( $scope.edited_question.extra.numCols );
                    } else {
                        for ( var i = $scope.edited_question.extra.cols.length; i < $scope.edited_question.extra.numCols; i++ ) {
                            $scope.edited_question.extra.cols.push( {'en':{'title':''}, 'fr':{'title':''}} );
                        }
                    }
                }
            }
        }

        function mcAddChoices() {
            if ( $scope.edited_question.type !== 'mc-ms' &&
                    $scope.edited_question.type !== 'mc-ss' &&
                    !$scope.edited_question.extra.numChoices ) {
                return;
            }

            for ( var i = 0; i < $scope.edited_question.extra.numChoices; i++ ) {
                $scope.edited_question.choices.push( {en: {'title':'', 'description':'null'}, fr: {'title':'', 'description':'null'}} );
            }
        }

        function mcAddaChoice() {
            if ( $scope.edited_question.type !== 'mc-ms' &&
                    $scope.edited_question.type !== 'mc-ss' &&
                    !$scope.edited_question.extra.numChoices ) {
                return;
            }                            
            $scope.edited_question.choices.push( { en: {'title':'', 'description':'null'}, fr: {'title':'', 'description':'null'}} );
            $scope.edited_question.extra.numChoices++; 
        }

        function mcRemoveChoice( pos ) {
            $scope.edited_question.choices.splice( pos, 1 );
            $scope.edited_question.extra.numChoices--;
        }

        function addTag( section, subsection ) {
            var indx = _.findIndex( $scope.sectionsCtrl.tags, function ( tag ) {
                return ( tag.section_id === section.id && tag.subsection_id === subsection.id );
            } );
            if ( indx >= 0 ) {
                return;
            }
            var tag = {
                section_id: section.id,
                subsection_id: subsection.id,
                s_name: section.name,
                s_name_fr: section.name_fr,
                ss_name: subsection.name,
                ss_name_fr: subsection.name_fr
            };
            $scope.sectionsCtrl.tags.push( tag );
            $scope.sectionsCtrl.tagsChanged = true;
        }

        function removeTag( pos ) {
            $scope.sectionsCtrl.tags.splice( pos, 1 );
            $scope.sectionsCtrl.tagsChanged = true;
        }

        function toggleClassification() {
            $scope.classificationCtrl.isCalssificationCollapsed = !$scope.classificationCtrl.isCalssificationCollapsed;
            $scope.classificationCtrl.isNewSectionCollapsed = true;
            $scope.classificationCtrl.isNewSubsectionCollapsed = true;
            $scope.selected = {
                section: {}
            };
            $scope.sectionsCtrl.subsections = null;
        }

        function toggleNewSection() {
            $scope.classificationCtrl.isNewSectionCollapsed = !$scope.classificationCtrl.isNewSectionCollapsed;
            $scope.selected = {
                section: {}
            };
            $scope.sectionsCtrl.subsections = null;
        }

        function toggleNewSubsection() {
            if (!$scope.selected.section.id) {
                if ($scope.classificationCtrl.isNewSubsectionCollapsed) {
                    $scope.showSubsectionErrorValidation = true;
                }
                return;
            }
            $scope.showSubsectionErrorValidation = false;
            $scope.classificationCtrl.isNewSubsectionCollapsed = !$scope.classificationCtrl.isNewSubsectionCollapsed;
            var indx = _.findIndex( $scope.sectionsCtrl.sections, function ( section ) {
                return $scope.selected.section.id === section.id;
            } );
            if ( indx >= 0 ) {
                $scope.selected.section = $scope.sectionsCtrl.sections[indx];
            }
        }

        function setDataToUpdateQuestion() {
            var question = {};
            // question main attributes
            question.id = $scope.edited_question.id;
            question.type = $scope.edited_question.type;
            question.score_size = $scope.edited_question.score_size;
            question.pass_mark = $scope.edited_question.pass_mark;

            // title and description of question
            if($scope.edited_question.translation.en.title){
                var en_object = {
                    title: $scope.edited_question.translation.en.title,
                    description: $scope.edited_question.translation.en.description,
                }
                question.en = en_object;
            }
            if($scope.edited_question.translation.fr.title){
                var fr_object = {
                    title: $scope.edited_question.translation.fr.title,
                    description: $scope.edited_question.translation.fr.description,
                }
                question.fr = fr_object;
            }
            // if question and selectField 
            if($scope.edited_question.type=='desc' && $scope.edited_question.selectedfield ){
                question.selectedfield = $scope.edited_question.selectedfield;
            }
            // choices of question & title and description of question
            if($scope.edited_question.choices){
                question.choices = $scope.edited_question.choices;
            }
            // if scale question is selected (maximum scale length)
            if($scope.edited_question.scale_range){
                question.scale_range = $scope.edited_question.scale_range;
            }
            if($scope.edited_question.type == 'table') {
                question.columns = $scope.edited_question.columns;
                question.rows = $scope.edited_question.rows;
            }
            if($scope.edited_question.type == 'format') {
                question.format = $scope.edited_question.format;
            }
            if(!$scope.questionnaireData) {
                // if section or subsection is selected or if we have existing category
                if($scope.selected.subsection && !_.isEmpty($scope.selected.subsection)){
                    question.categories = [{'id':$scope.selected.subsection.id}]
                }
                else if($scope.selected.section && !_.isEmpty($scope.selected.section)){
                    question.categories = [{'id':$scope.selected.section.id}]
                }
                else if($scope.edited_question.categories.length){
                    question.categories = [{'id':$scope.edited_question.categories[0].id}];
                }
            }
            return question;
        }

        function updateOrReplaceQuestion() {

            const question = setDataToUpdateQuestion();
            $scope.questionnaireData ? cloneAndAttachQuestion(question) : updateQuestion(question);
        }

        function updateQuestion(question) {
            $rootScope.api_status("waiting", "Updating your question...", "Mise à jour de votre question ...");
            $scope.waitPromise = api.service_post('toolkit',  'questionnaire/questions/'+$scope.edited_question.id, question, 'update'
            ).then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.$emit('fireSearch', true);
                    $scope.callBack();
                    $scope.cancel();
                    $rootScope.api_status('alert-success', 'The question have been updated successfully!', 'La question a été mise à jour avec succès!');
                }
                else {
                    showEditQuestionsErrorMsg('update');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showEditQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showEditQuestionsErrorMsg('update');
                }
            });
        }

        function cloneAndAttachQuestion(question) {
            var action = !$scope.cloningQuestionAction ? 'clone' : $scope.cloningQuestionAction;
            var msgEn = $scope.cloningQuestionAction == 'replace' ? 'Replacing the question' : 'Cloning the question';
            var msgFr = $scope.cloningQuestionAction == 'replace' ?  'Remplacement de la question' : 'Duplication de la question';
            $rootScope.api_status('waiting', msgEn, msgFr, 'Please wait...', 'Veuillez patientez...');
            question.questionnaire_id = $scope.cloningQuestionAction != 'clone' ? $scope.questionnaireData.id : null;
            question.action = $scope.cloningQuestionAction;
            $scope.waitPromise = api.service_post('toolkit', 'questionnaire/questions/clone-from-ui/'+$scope.edited_question.id, question).then( function(response) {
                const res = response.data;
                if(res.status == 'success') {
                    if($scope.cloningQuestionAction != 'clone') {
                        var successMsgEn = $scope.cloningQuestionAction == 'replace' ? "Question replaced successfully" : "Question cloned and added successfully";
                        var successMsgFr = $scope.cloningQuestionAction == 'replace' ? "Question remplacée avec succès" : "Question dupliquée et ajoutée avec succès";
                        $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
                        $scope.callBack();
                        $scope.replaceQuestionCallBack();
                        $scope.cancel();
                    }
                    else {
                        replaceFollowupQuestion(question, res.data.result.id);
                    }
                }
                else {
                    showEditQuestionsErrorMsg(action);
                }
            }).catch( function(error) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showEditQuestionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showEditQuestionsErrorMsg('is_used');
                        break;
                    default:
                        showEditQuestionsErrorMsg(action);
                }
            });
        }

        function replaceFollowupQuestion(question, new_question_id) {
            const deteled_original_q_branch = deleteFollowupQBranch($scope.questionData.id);
            if(deteled_original_q_branch) {
                const data_to_create = {
                    'questionnaire_id': $scope.questionData.tail_q_question.questionnaire_id,
                    'question_id': new_question_id,
                    'rank': 0,
                    'is_tail': true
                };
                api.service_post('toolkit', 'questionnaire/questionnaire-questions', data_to_create).then((response) => {
                    const res = response.data;
                    if(res.status == 'success') {
                        addFollowupQBranch(res.data.result.id);
                    }
                    else {
                        showEditQuestionsErrorMsg('replace_followup_q');
                    }
                }).catch((error) => {
                    var errorMsg = '';
                    if(error && error.data && error.data.data && error.data.data.result) {
                        errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                    }
                    switch(errorMsg) {
                        case 'Token has expired':
                            showEditQuestionsErrorMsg('token_expired');
                            break;
                        case 'the_questionnaire_is_already_used':
                            showEditQuestionsErrorMsg('is_used');
                            break;
                        default:
                            showEditQuestionsErrorMsg('replace_followup_q');
                    }
                });
            }
        }

        function deleteFollowupQBranch(id) {
            return api.service_delete('toolkit', 'questionnaire/question-branches/' + id).then((response) => {
                const res = response.data;
                if(res.status == 'success') {
                    return true;
                }
                else {
                    showEditQuestionsErrorMsg('replace_followup_q');
                    return false;
                }
            }).catch((error) => {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showEditQuestionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showEditQuestionsErrorMsg('is_used');
                        break;
                    default:
                        showEditQuestionsErrorMsg('replace_followup_q');
                }
                return false;
            });
        }

        function addFollowupQBranch(id) {
            const data_to_save = {
                "id": 0,
                "choice_condition_id": $scope.questionData.choice_condition_id,
                "bool_condition": $scope.questionData.bool_condition,
                "reject_candidate": $scope.questionData.reject_candidate,
                "head_q_question_id": $scope.questionData.head_q_question_id,
                "tail_q_question_id": id
            }
            return api.service_post('toolkit', 'questionnaire/question-branches', data_to_save).then((response) => {
                const res = response.data;
                if(res.status == 'success') {
                    $rootScope.api_status('alert-success', "Question replaced successfully!", "Question remplacée avec succès!");
                    $scope.callBack();
                    $scope.replaceFollowupQCallBack();
                    $scope.cancel();
                }
                else {
                    showEditQuestionsErrorMsg('replace_followup_q');
                }
            }).catch((error) => {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showEditQuestionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showEditQuestionsErrorMsg('is_used');
                        break;
                    default:
                        showEditQuestionsErrorMsg('replace_followup_q');
                }
            });
        }

        function loadSubsections(section) {
            $scope.showSubsectionErrorValidation = false;
            $scope.loadingSubSections = true;
            var promise = api.service_get('toolkit',  'questionnaire/categories', {'filter_by_parent_category_id':section.id} );
            promise.then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.sectionsCtrl.subsections = response.data.data.result;
                }
                else {
                    showEditQuestionsErrorMsg('load_sub_cat');
                }
                $scope.loadingSubSections = false;
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showEditQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showEditQuestionsErrorMsg('load_sub_cat');
                }
                $scope.loadingSubSections = false;
            });
        }

        function showEditQuestionsErrorMsg(action) {
            var msgEn = "An error has occurred ";
            var msgFr = "Une erreur est survenue ";
            switch(action) {
                case 'replace':
                    msgEn = msgEn + "and the question could not be replaced";
                    msgFr = msgFr + "et la question n'a pu être remplacée";
                    break;
                case 'add':
                    msgEn = msgEn + "and the question could not be added";
                    msgFr = msgFr + "et la question n'a pu être ajoutée";
                    break;
                case 'clone':
                    msgEn = msgEn + "and the question could not be cloned";
                    msgFr = msgFr + "et la question n'a pu être dupliquée";
                    break;
                case 'replace_followup_q':
                    msgEn = "Replacing the question failed, you can nevertheless retrieve the question created in the question bank";
                    msgFr = "Le remplacement de la question a échoué, vous pourrez néanmoins récupérer la question créée dans la banque de questions";
                    break;
                case 'update':
                    msgEn = msgEn + "and the question could not be updated; you may not have the required permissions to do so";
                    msgFr = msgFr + "et la question n'a pu être mise à jour; vous n'avez peut-être pas les autorisations requises pour le faire";
                    break;
                case 'is_used':
                    msgEn = "This questionnaire is used and cannot be modified";
                    msgFr = "Ce questionnaire est utilisé et ne peut être modifié";
                    break;
                case 'load_sub_cat':
                    msgEn = msgEn + "and the subcategories data could not be fetched";
                    msgFr = msgFr + "et les sous-catégories n'ont pu être récupérées";
                    break;
                case 'token_expired':
                    msgEn = "Your session has expired, please login again";
                    msgFr = "Votre session est expirée, veuillez vous connecter à nouveau";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msgEn, msgFr);
        }

        function editQuestionInfo(){
            $.confirm({
                title: "",
                theme: 'modern',
                content: $scope.out('Cette question fait partie de la banque de questions. La modification de cette question peut affecter d\'autres questionnaires.', 'This question is part of questions bank. Editing this question may effect other questionnaires.'),
                buttons: {
                    Ok: {
                        text: $scope.out("Ok", "Ok"),
                        btnClass: 'btn-blue',
                    }
                }
            });
        }
    }

} )( angular );