( function ( angular ) {
    'use strict';
    angular.module( 'atlas' ).directive( 'isedQuestions', function ( ) {
		return {
            scope: {
            },
            controller: IsedQuestionsController,
            template: require('./ised-questions.template.html')
		};
    });

    IsedQuestionsController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$uibModal', '$timeout', '_', 'worklandLocalize', '$filter', 'Pager'];

    function IsedQuestionsController( $scope, $rootScope, api, utils, $uibModal, $timeout, _, worklandLocalize, $filter, Pager) {
        var out = utils.out;
        var deleteMsg = out( 'Etes-vous sure?', 'Are you sure you want to proceed?' );
        var scope = {
            strings: worklandLocalize.strings,
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: out,
            activeQuestion: false,
            displayedQuest: null,
            existingQuestion : false,
            newQuestion:false,
            sectionsCtrl: {
                showCalssification: true
            },
            filtering: {
                keyword: '',
                theFilter: {
                }
            },
            newQuestionData: {},
            questionsQueryFailed: false,
            pageQuestionsLoader: false,
            pageSize: { selected: 15 },
            pageSizeSelect: [10, 15, 20, 25, 50],
            searchTimeout: null,
            sectionChanged: sectionChanged,
            subsectionChanged: subsectionChanged,
            keywordChaned: keywordChaned,
            keywordQuestionsQuery: keywordQuestionsQuery,
            createQuestion: createQuestion,
            cancelEditing: cancelEditing,
            deleteQuestion: deleteQuestion,
            editQuestion: editQuestion,
            cloneQuestion: cloneQuestion,
            selectQuestion: selectQuestion,
            deleteCategory:deleteCategory,
            loadSubsections:loadSubsections,
            loadQuestions:loadQuestions,
            editcategory:editcategory,
            openeditcategoryModal:openeditcategoryModal,
            clearQuestionsListSearch: clearQuestionsListSearch,
            getQuestionsListByNumOfPage: getQuestionsListByNumOfPage,
            addSearchByTitle: false,
        };
        angular.extend( $scope, scope );

        $scope.$on('fireSearch', () => {
          $scope.addSearchByTitle = true;
        });

        init();

        function init() {
            $scope.pageQuestionsLoader = true;
            loadQuestions();
            loadSections();
        }

        function setPagination(data) {
            $scope.pager = Pager.GetPager(data.total, data.current_page, $scope.pageSize.selected, false);
        }

        $scope.setPage = function(page) {
            if (page < 1 || page > $scope.pager.totalPages) {
                return;
            }
            $scope.pager.currentPage = page;
            $scope.pageQuestionsLoader = true;
            loadQuestions(false, true);
        }

        function loadQuestions(flag, loadFirstQuestion) {
            $scope.questionsQueryFailed = false;
            $scope.activeQuestion = true;
            const params = {
                page: flag ? ($scope.pager.currentPage +1) : $scope.pager ? $scope.pager.currentPage : 1,
                page_size: $scope.pageSize.selected,
                locale: $rootScope.language,
                sort_by: 'title',
            }
            if($scope.filtering.keyword) { params.search = $scope.filtering.keyword }
            if ($scope.addSearchByTitle) { 
                params.search = $scope.displayedQuest.translation[$rootScope.language].title;
                $scope.filtering.keyword = $scope.displayedQuest.translation[$rootScope.language].title;
                params.page = 1;
            }

            var promise = api.service_get('toolkit',  'questionnaire/questions/list/with-is-used-by-questionnaire-flag', params );
            promise.then( function ( response ) {
                $scope.addSearchByTitle = false;
                const res = response.data;
                if(res.status == 'success') {
                    $scope.questions = response.data.data.result.data;
                    if ($scope.questions.length) {
                        if(!scope.pager ) {
                            setPagination(res.data.result);
                        }
                        $scope.perPage = response.data.data.result.per_page;
                        if (loadFirstQuestion) selectQuestion($scope.questions[0]);
                    } else {
                        $scope.displayedQuest = null;
                    }
                }
                else {
                    $scope.questionsQueryFailed = true;
                    showQuestionsErrorMsg('load_many');
                    $scope.displayedQuest = null;
                }
                $scope.pageQuestionsLoader = false;
            }).catch( function ( error ) {
                $scope.questionsQueryFailed = true;
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionsErrorMsg('load_many');
                }
                $scope.pageQuestionsLoader = false;
                $scope.displayedQuest = null;
            });
        }

        function loadSections() {
            var promise = api.service_get('toolkit',  'questionnaire/categories', {'filter_by_parent_category_id':0} );
            promise.then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.sectionsCtrl.sections = $filter('orderBy')(response.data.data.result, 'translation.en.name');
                }
                else {
                    showQuestionsErrorMsg('load_cat');
                }
            }).catch( function ( error ) {
                showQuestionsErrorMsg('load_cat');
            });
        }

        function loadSubsections(section) {
            $scope.sectionQuestions = null;
            $scope.sectionsCtrl.subsections = null;
            section.isOpen = true;
            section.isloading = true;
            var promise = api.service_get('toolkit', 'questionnaire/categories', { 'filter_by_parent_category_id': section.id });
            promise.then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.sectionsCtrl.subsections = $filter('orderBy')(response.data.data.result, 'translation.en.name');
                    loadSectionQuestions(section);
                }
                else {
                    showQuestionsErrorMsg('load_sub_cat');
                    section.isloading = false;
                }
            }).catch(function (error) {
                section.isloading = false;
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionsErrorMsg('load_sub_cat');
                }
            });
        }

        function createQuestion() {
            $scope.displayedQuest = null;
            $scope.newQuestion = true;
            $scope.existingQuestion = false;
        }

        function selectQuestion( selectedQuestion, flag ) {
            $scope.displayedQuest = null;
            $scope.newQuestion = false;
            $scope.activeQuestion = false;
            $scope.existingQuestion = false;
            var promise = api.service_get('toolkit',  'questionnaire/questions/' + selectedQuestion.id, {'load_with':'choices;columns;rows;question_choices;categories'} );
            promise.then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.displayedQuest = response.data.data.result;
                    loadQuestions(flag);                    
                }
                else {
                    showQuestionsErrorMsg('load');
                }
                $scope.activeQuestion = true;
            }).catch( function ( error ) {
                $scope.activeQuestion = true;
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionsErrorMsg('load');
                }
            });
        }

        function cancelEditing() {
            $scope.newQuestion = false;
            $scope.existingQuestion = false;
        }

        function deleteQuestion() {
            $rootScope.api_status("waiting", "Deleting question...", "Suppression de la question...");
            var promise =  api.service_delete('toolkit', 'questionnaire/questions/'+$scope.displayedQuest.id, {
                    question_id: $scope.displayedQuest.id
                }
            );
            promise.then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    var indx = _.findIndex( $scope.questions, function ( quest ) {
                        return quest.id === $scope.displayedQuest.id;
                    } );
                    if ( indx >= 0 ) {
                        $scope.questions.splice( indx, 1 );
                        $scope.displayedQuest = null;
                    }
                    $rootScope.api_status('alert-success', "Sucessfully deleted", "Supprimée avec succès");
                    if ($scope.questions.length > 0) {
                        selectQuestion($scope.questions[0]);
                    } else {
                        clearQuestionsListSearch();
                    }
                }
                else {
                    showQuestionsErrorMsg('delete');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    case 'attached_to_questionnaire':
                        showQuestionsErrorMsg('delete_denied');
                        break;
                    default:
                        showQuestionsErrorMsg('delete');
                }
            });
        }

        function deleteCategory(category){
            $rootScope.api_status("waiting", "Deleting category...", "Suppression de catégorie...");
            var promise =  api.service_delete('toolkit', 'questionnaire/categories/'+category.id).then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    var indx = _.findIndex( category.parent_category_id == 0 ? $scope.sectionsCtrl.sections : $scope.sectionsCtrl.subsections, function ( cat ) {
                        return cat.id === category.id;
                    } );
                    if ( indx >= 0 ) {
                        if(category.parent_category_id == 0){
                            $scope.sectionsCtrl.sections.splice(indx, 1);
                        }else{
                            $scope.sectionsCtrl.subsections.splice(indx,1);
                        }
                        $rootScope.api_status('alert-success', "Sucessfully deleted", "Supprimée avec succès");
                        $scope.displayedQuest = null;
                    }
                }
                else {
                    showQuestionsErrorMsg('delete_cat');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionsErrorMsg('delete_cat');
                }
            });
        }

        function editQuestion() {
            closeCategories();
            $scope.existingQuestion = true;
        }

        function closeCategories() {
            if($scope.displayedQuest && $scope.displayedQuest.categories && $scope.displayedQuest.categories.length) {
                const cat_id =  $scope.displayedQuest.categories[0].parent_category_id > 0 ?
                                $scope.displayedQuest.categories[0].parent_category_id : $scope.displayedQuest.categories[0].id;
                angular.element(document.getElementById(""+cat_id)).removeClass('in');
            }
        }

        function cloneQuestion() {
            $rootScope.api_status("waiting", "Cloning the question...", "Duplication de la question...");
            closeCategories();
            $scope.newQuestion = false;
            $scope.existingQuestion = false;
            api.service_post('toolkit',  'questionnaire/questions/deep-clone/'+$scope.displayedQuest.id , {}
            ).then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    const index = $scope.questions.findIndex(x => x.id === $scope.displayedQuest.id);
                    let flag = false;
                    if (index === $scope.perPage - 1) {
                        flag = true;
                    }
                    $scope.displayedQuest = null;
                    selectQuestion(response.data.data.result, flag);
                    $rootScope.api_status('alert-success', "Sucessfully cloned", "Dupliquée avec succès");
                }
                else {
                    showQuestionsErrorMsg('clone');
                }
            }).catch( function ( error ) {
                showQuestionsErrorMsg('clone');
            });
        }

        function sectionChanged( section ) {
            $scope.displayedQuest = null;
            $scope.filtering.theFilter = {
            };
            if ( section ) {
                $scope.filtering.theFilter = {
                    tags: {section_id: section.id}
                };
            }
        }

        function subsectionChanged(subsection) {
            if (!subsection.isOpen) {
                subsection.isOpen = true;
                subsection.isloading = true;
                $scope.displayedQuest = null;
                $scope.subsectionQuestions = null;
                var promise = api.service_get('toolkit', 'questionnaire/question-tags', { 'filter_by_category_id': subsection.id, 'load_with': 'question' });
                promise.then(function (response) {
                    const res = response.data;
                    if(res.status == 'success') {
                        $scope.subsectionQuestions = res.data.result;
                    }
                    subsection.isloading = false;
                }).catch(function (error) {
                    subsection.isloading = false;
                });
            }else {
                subsection.isOpen = false;
            }
        }

        function loadSectionQuestions(section) {
            $scope.displayedQuest = null;
            var promise = api.service_get('toolkit', 'questionnaire/question-tags', { 'filter_by_category_id': section.id, 'load_with': 'question' });
            promise.then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.sectionQuestions = res.data.result;
                }
                section.isloading = false;
            }).catch(function (error) {
                section.isloading = false;
            });
        }

        function openeditcategoryModal(category){
            $scope.language = $rootScope.language;
            $scope.selectedSection = category;
            $scope.updateCategory = $uibModal.open({
                animation: true,
                templateUrl: './employer-profile/ised/questionnaires/modals/create-category.template.html',
                scope: $scope,
                size: 'md',
                backdrop: 'static',
                resolve: {
                    section: function () {
                        return category;
                    }
                }
            });
        }

        function editcategory(editedsection) {
            var data = {
                parent_category_id: editedsection.parent_category_id,
                en:editedsection.translation.en,
                fr:editedsection.translation.fr
            };
            var promise = api.service_post('toolkit',  'questionnaire/categories/'+editedsection.id, data, 'update' );
            promise.then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.updateCategory.close();
                }
                else {
                    showQuestionsErrorMsg('update_cat');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionsErrorMsg('update_cat');
                }
            });
        }

        function keywordChaned() {
            $scope.displayedQuest = null;
        }

        function keywordQuestionsQuery(searched_string) {
            $scope.pageQuestionsLoader = true;
            if($scope.searchTimeout) {
                $timeout.cancel($scope.searchTimeout);
            }
            $scope.searchTimeout = $timeout(() => {
                $scope.pager.currentPage = 1;
                loadQuestions();
            }, 600);
        }

        function clearQuestionsListSearch() {
            $scope.pageQuestionsLoader = true;
            $scope.filtering.keyword = '';
            $scope.pager.currentPage = 1;
            $scope.displayedQuest = null;
            loadQuestions();
        }

        function getQuestionsListByNumOfPage() {
            $scope.pageQuestionsLoader = true;
            $scope.pager.currentPage = 1;
            loadQuestions();
        }

        function showQuestionsErrorMsg(action) {
            var msgEn = "An error has occurred ";
            var msgFr = "Une erreur est survenue ";
            switch(action) {
                case 'load':
                    msgEn = msgEn + "and the question could not be retrieved";
                    msgFr = msgFr + "et la question n'a pu être récupérée";
                    break;
                case 'load_many':
                    msgEn = msgEn + "and the questions could not be retrieved";
                    msgFr = msgFr + "et les questions n'ont pu être récupérées";
                    break;
                case 'load_cat':
                    msgEn = msgEn + "and the categories could not be retrieved";
                    msgFr = msgFr + "et les catégories n'ont pu être récupérées";
                    break;
                case 'load_sub_cat':
                    msgEn = msgEn + "and the subcategories could not be retrieved";
                    msgFr = msgFr + "et les sous-catégories n'ont pu être récupérées";
                    break;
                case 'clone':
                    msgEn = msgEn + "and the question could not be cloned";
                    msgFr = msgFr + "et la question n'a pu être dupliquée";
                    break;
                case 'update_cat':
                    msgEn = msgEn + "and the category could not be updated";
                    msgFr = msgFr + "et la catégorie n'a pu être mise à jour";
                    break;
                case 'delete':
                    msgEn = msgEn + "and the question could not be deleted";
                    msgFr = msgFr + "et la question n'a pu être supprimée";
                    break;
                case 'delete_denied':
                    msgEn = "The question is attached to a questionnaire and therefore cannot be deleted";
                    msgFr = "La question est jointe à un questionnaire et ne peut donc pas être supprimée";
                    break;
                case 'delete_cat':
                    msgEn = msgEn + "and the category could not be deleted";
                    msgFr = msgFr + "et la catégorie n'a pu être supprimée";
                    break;
                case 'token_expired':
                    msgEn = "Your session has expired, please login again";
                    msgFr = "Votre session est expirée, veuillez vous connecter à nouveau";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msgEn, msgFr);
        }
    }

} )( angular );