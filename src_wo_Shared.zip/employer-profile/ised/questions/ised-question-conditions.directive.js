(function (angular) {
    'use strict';

    angular.module('atlas')
        .directive('isedQuestionConditions', function () {
            return {
                scope: {
                    question: '=',
                    questionList: '=',
                    sectionsCtrl: '=',
                    bankQuestions: '=',
                    displayedQuestionnaire: '=',
                    bundle: '=',
                    cancel: '&',
                    callBack: '&'
                },
                controller: IsedQuestionConditionsController,
                templateUrl: './employer-profile/ised/questions/ised-question-conditions.template.html'
            };
        });


    IsedQuestionConditionsController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$uibModal', 'Event', '_', 'worklandLocalize'];

    function IsedQuestionConditionsController($scope, $rootScope, api, utils, $uibModal, Event, _, worklandLocalize) {
        var out = utils.out;
        var yesNo = [
            { 'translation': { 'en': { 'title': 'Yes' }, 'fr': { 'title': 'Oui' } }, 'action': '' },
            { 'translation': { 'en': { 'title': 'No' }, 'fr': { 'title': 'Non' } }, 'action': '' },
        ];
        var scope = {
            strings: worklandLocalize.strings,
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: out,
            range: _.range,
            ctrl: {},
            filterCondition: {
                action: ''
            },
            cancelEditConditions: cancelEditConditions,
            actionChanged: actionChanged,
            newFollowUpTypeChanged: newFollowUpTypeChanged,
            addFollowUp2Questionnaire: addFollowUp2Questionnaire,
            addFollowUpCancel: addFollowUpCancel,
            selectFollowUpFromBank: selectFollowUpFromBank,
            addFollowUpFromBank: addFollowUpFromBank,
            setConditionDisqualify: setConditionDisqualify,
            clearConditions: clearConditions
        };
        angular.extend($scope, scope);

        init();

        function init() {
            if ($scope.question.type === 'yes-no') {
                $scope.choices = yesNo;
                $scope.conditionsFormModel = createYesNoModelFromConditions($scope.bundle.question.question_branches);
            } else {
                $scope.choices = $scope.question.choices;
                $scope.conditionsFormModel = createMCSSModelFromConditions($scope.bundle.question.question_branches);
            }
        }

        function createYesNoModelFromConditions(conditions) {
            var model = [];
            _.each($scope.choices, function (v, k) {
                model.push({
                    index: k + '',
                    action: null,
                    followup_ref: null,
                    followup_id: null,
                    condition: null
                });
            });
            var conditionsNotEmpty = conditions && conditions.length;
            if (conditionsNotEmpty) {
                conditions.forEach(function (element) {
                    if (element.bool_condition == 1) {
                        if (element.tail_q_question && element.reject_candidate == 0) {
                            model[0].action = "followup";
                            model[0].followup_ref = element.tail_q_question;
                            model[0].followup_id = element.id;
                        } else if (!element.tail_q_question && element.reject_candidate == 1) {
                            model[0].action = "disqualify";
                            model[0].followup_ref = null;
                            model[0].followup_id = element.id;
                        }
                    } else if (element.bool_condition == 0) {
                        if (element.tail_q_question && element.reject_candidate == 0) {
                            model[1].action = "followup";
                            model[1].followup_ref = element.tail_q_question;
                            model[1].followup_id = element.id;
                        } else if (!element.tail_q_question && element.reject_candidate == 1) {
                            model[1].action = "disqualify";
                            model[1].followup_ref = null;
                            model[1].followup_id = element.id;
                        }
                    }
                });
            }
            return model;
        }

        function createMCSSModelFromConditions(conditions) {
            var model = [];
            _.each($scope.choices, function (v, k) {
                model.push({
                    index:  v.id + '',
                    action: null,
                    followup_ref: null,
                    followup_id: null,
                    condition: null
                });
            });
            var conditionsNotEmpty = conditions && conditions.length;
            if (conditionsNotEmpty) {
                conditions.forEach(function (element) {
                    var indx = _.findIndex(model, function (mod) {
                        return mod.index == element.choice_condition_id;
                    });
                    if(indx >= 0){
                        if (element.tail_q_question && element.reject_candidate == 0) {
                            model[indx].action = "followup";
                            model[indx].followup_ref = element.tail_q_question;
                            model[indx].followup_id = element.id;
                        } else if (!element.tail_q_question && element.reject_candidate == 1) {
                            model[indx].action = "disqualify";
                            model[indx].followup_ref = null;
                            model[indx].followup_id = element.id;
                        }
                    }
                });
            }
            return model;
        }

        function actionChanged(choice, conditionIndex) {
            $scope.filterCondition.action = choice.action
            $scope.selectedChoice = choice.condition;
            if (!choice.action) {
                choice.changed = false;
                $scope.ctrl.conditionIndex = null;
            } else {
                choice.changed = true;
                $scope.ctrl.conditionIndex = conditionIndex;
            }
        }

        function newFollowUpTypeChanged(newFollowUpType) {
            if (+newFollowUpType === 1) {
                $scope.followup = {
                    type: "",
                    extra: {},
                    conditions: []
                };
            }
        }

        function cancelEditConditions() {
            $scope.cancel();
        }

        function addFollowUp2Questionnaire(quest) {
            $scope.ctrl.newFollowUpType = null;
        }

        function addFollowUpCancel() {
            $scope.ctrl.newFollowUpType = null;
            $scope.conditionsFormModel[$scope.ctrl.conditionIndex].action = null;
            $scope.conditionsFormModel[$scope.ctrl.conditionIndex].followup_ref = null;
        }

        function selectFollowUpFromBank(selectedQuestion) {
            $scope.tail_question = selectedQuestion;
            $scope.ctrl.followupIsSelected = true;
            $scope.ctrl.selectedQuestion = angular.copy(selectedQuestion);
            delete $scope.ctrl.selectedQuestion.id;
        }

        function addFollowUpFromBank() {
            var msgEn = "Adding the follow-up question...";
            var msgFr = "Ajout de la question de suivi...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var data = {
                "questionnaire_id": $scope.displayedQuestionnaire.id,
                "question_id": $scope.tail_question.id,
                "is_tail": true,
                "rank": 0
            }
            api.service_post('toolkit', 'questionnaire/questionnaire-questions', data
            ).then(function (response) {
                if ($scope.question.type == 'yes-no') {
                    if ($scope.selectedChoice.translation.en.title == 'Yes') {
                        var data = {
                            "id": 0,
                            "choice_condition_id": null,
                            "bool_condition": true,
                            "reject_candidate": false,
                            "head_q_question_id": $scope.bundle.question.id,
                            "tail_q_question_id": response.data.data.result.id
                        }
                    } else {
                        var data = {
                            "id": 0,
                            "choice_condition_id": null,
                            "bool_condition": false,
                            "reject_candidate": false,
                            "head_q_question_id": $scope.bundle.question.id,
                            "tail_q_question_id": response.data.data.result.id
                        }
                    }
                } else {
                    var data = {
                        "id": 0,
                        "choice_condition_id": $scope.selectedChoice.id,
                        "bool_condition": null,
                        "reject_candidate": false,
                        "head_q_question_id": $scope.bundle.question.id,
                        "tail_q_question_id": response.data.data.result.id
                    }
                }
                api.service_post('toolkit', 'questionnaire/question-branches', data
                ).then(function (response) {
                    const res = response.data;
                    if(res.status == 'success') {
                        $rootScope.api_status(
                            "alert-success",
                            "The question has been added successfully",
                            "La question a été ajoutée avec succès!"
                        );
                        $scope.callBack();
                        $scope.cancel();
                    }
                    else {
                        showQuestionsConditionsErrorMsg('add_followup_q');
                    }
                }).catch(function (error) {
                    showQuestionsConditionsErrorMsg('add_followup_q');
                });

            }).catch(function (error) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsConditionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionsConditionsErrorMsg('is_used');
                        break;
                    default:
                        showQuestionsConditionsErrorMsg('add_followup_q');
                }
            });
        }

        function setConditionDisqualify() {
            var data = {};
            if ($scope.question.type == 'yes-no') {
                if ($scope.selectedChoice.translation.en.title == 'Yes') {
                    data.id = 0;
                    data.choice_condition_id = null;
                    data.bool_condition = true;
                    data.reject_candidate = true;
                    data.head_q_question_id = $scope.bundle.question.id;
                    data.tail_q_question_id = 0;
                } else {
                    data.id = 0;
                    data.choice_condition_id = null;
                    data.bool_condition = false;
                    data.reject_candidate = true;
                    data.head_q_question_id = $scope.bundle.question.id;
                    data.tail_q_question_id = 0;
                }
            } else {
                data.id = 0;
                data.choice_condition_id = $scope.selectedChoice.id;
                data.bool_condition = null;
                data.reject_candidate = true;
                data.head_q_question_id = $scope.bundle.question.id;
                data.tail_q_question_id = 0;
            }
            $rootScope.api_status("waiting", "Adding condition...", "Ajout de la condition...");
            api.service_post('toolkit', 'questionnaire/question-branches', data
            ).then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    $rootScope.api_status('alert-success', "Condition sucessfully added!", "Condition ajoutée avec succès!");
                    $scope.callBack();
                    $scope.cancel();
                }
                else {
                    showQuestionsConditionsErrorMsg('add_disqualifying_q');
                }
            }).catch(function (error) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsConditionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionsConditionsErrorMsg('is_used');
                        break;
                    default:
                        showQuestionsConditionsErrorMsg('add_disqualifying_q');
                }
            });
        }

        function clearConditions(data) {
            $rootScope.api_status("waiting", "Deleting your condition...", "Suppression de votre condition...");
            var promise = api.service_delete('toolkit', 'questionnaire/question-branches/' + data.followup_id);
            promise.then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    $rootScope.api_status('alert-success', "Sucessfully deleted!", "Supprimée avec succès!");
                    $scope.callBack();
                    $scope.cancel();
                }
                else {
                    showQuestionsConditionsErrorMsg('delete_condition');
                }
            }).catch(function (error) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showQuestionsConditionsErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionsConditionsErrorMsg('is_used');
                        break;
                    default:
                        showQuestionsConditionsErrorMsg('delete_condition');
                }
            });
        }

        function showQuestionsConditionsErrorMsg(action) {
            var msgEn = "An error has occurred ";
            var msgFr = "Une erreur est survenue ";
            switch(action) {
                case 'add_followup_q':
                    msgEn = msgEn + " and follow-up question could not be added";
                    msgFr = msgFr + " et la question de suivi n'a pu être ajoutée";
                    break;
                case 'add_disqualifying_q':
                    msgEn = msgEn + " and the condition could not be saved";
                    msgFr = msgFr + " et la condition n'a pas pu être enregistrée";
                    break;
                case 'delete_condition':
                    msgEn = msgEn + " and the condition could not be deleted";
                    msgFr = msgFr + " et la condition n'a pas pu être supprimée";
                    break;
                case 'token_expired':
                    msgEn = msgEn + "Your session has expired, please login again";
                    msgFr = msgFr + "Votre session est expirée, veuillez vous connecter à nouveau";
                    break;
                case 'is_used':
                    msgEn = "This questionnaire is used and cannot be modified";
                    msgFr = "Ce questionnaire est utilisé et ne peut être modifié";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msgEn, msgFr);
        }
    }
})(angular);