(function (angular) {
  function IsedViewSendQuestionnairesAnswerController($scope, $rootScope, api, utils, _, $filter, storageService, $q) {
    const vm = this;
      const vmExtend = {
        isAdmin: $rootScope.currentUser.permissions.isAdmin,
        out: utils.out,
        preSelection: false,
        loadingAnswer: false,
        noDefaultQuestionnaire: false,
        // questionnaires: [], @std by - need to emit so [] must be a change
        selectQuestionnaire,
        enableEditMode,
        allAnswers: [],
        editMode: false,
        showEditQButton: false,
        processAnswersLoader: false,
        switchJob,
        crmJobCandidate: { selected: {} },
        defaultCrmSelectOption: {
          id: null,
          translations: [{ title: 'No job' }, { title: 'Aucun poste' }],
        },
      };
      angular.extend(vm, vmExtend);

      vm.tagHandler = (tag) => null;

      function switchJob(job) {
        if (job) {
          vm.jobId = job.id;
          vm.selectedJob = true;
          vm.questionnaires = [];
          vm.jobQuestionnairs = [];
          vm.noPreSelection = false;
          vm.loadingAnswer = true;
          vm.selectedQuestionnaire = null;
          vm.noDefaultQuestionnaire = false;
          vm.noDispatchedQuestionnaire = false;
          if (job.id) {
            checkJobHasQuestionnarie();
          } else {
            getCandidateDispatchedQuestionarrie();
          }
        }
      }


      function checkIfEditMode() {
        /**
         *  @temp:  check if no answers at all to enable edit questionnaire mode
         *  @todo:  allow answering pending questions if questionnaire is
         *          incomplete && not disqualified
         */
        let editMode = false;
        if (vm.selectedQuestionnaire.private) {
          const hasAnswers = _.find(vm.selectedQuestionnaire.questionnaire_questions, (q) => q.answers && q.answers.length);
          if (!hasAnswers) {
            editMode = true;
          }
        }
        vm.showEditQButton = editMode;
      }

      function selectQuestionnaire(questionnaire) {
        vm.loadingAnswer = true;
        vm.showEditQButton = false;
        vm.activeIsed = questionnaire.id;
        vm.selectedQuestionnaire = null;
        const data = {};
        data.candidate_id = vm.candidateId;
        if (!questionnaire.isDefaultQuestionnaire && vm.jobId) {
          data.job_id = vm.jobId;
        } else {
          data.job_id = null;
        }
        data.questionnaire_id = questionnaire.id;
        api.service_post('toolkit', 'questionnaire/questionnaires/get-questionnaire-with-answers-employer-side', data).then((response) => {
          vm.loadingAnswer = false;
          vm.noPreSelection = false;
          vm.selectedQuestionnaire = response.data.data.result;
          vm.selectedQuestionnaire.date_answered = questionnaire.date_answered ? questionnaire.date_answered : null;
          if (!questionnaire.tag || (questionnaire.tag != 'dispatched')) {
            checkIfEditMode();
          }
        }).catch(() => {
          vm.loadingAnswer = false;
          $rootScope.api_status('alert-danger');
        });
      }

      function fetchQuestionnaireTitles(ques, qLength) {
        const promise = api.service_get('toolkit', `questionnaire/questionnaires/${ques.questionnaire_id}`);
        promise.then((response) => {
          response.data.data.result.rank = ques.rank;
          response.data.data.result.is_questionnaire_completed = ques.is_questionnaire_completed
            ? ques.is_questionnaire_completed : false;
          if (ques.agency_account_id && response.data.data.result) {
            angular.forEach(response.data.data, (defaultQuest) => {
              defaultQuest.isDefaultQuestionnaire = true;
            });
          }
          vm.questionnaires.push(response.data.data.result);
          if (vm.questionnaires.length > 0) {
            if (vm.questionnaires.length >= qLength) {
              vm.questionnaires = $filter('orderBy')(vm.questionnaires, 'rank');
              selectQuestionnaire(vm.questionnaires[0]);
            }
          } else {
            vm.loadingAnswer = false;
            vm.noPreSelection = true;
            vm.noDefaultQuestionnaire = true;
          }
        }).catch(() => {
          vm.loadingAnswer = false;
          $rootScope.api_status('alert-danger');
        });
      }

      function readAllQuestionnairesAttachedToCandidates(agencyAccountId) {
        api.service_post('toolkit', 'questionnaire/agency-candidate-questionnaire/read-all', {
          agency_account_id: [agencyAccountId],
        }).then((response) => {
          angular.forEach(response.data, (questionnaire) => {
            vm.jobQuestionnairs.push(questionnaire);
          });
          if (vm.jobQuestionnairs.length > 0) {
            vm.jobQuestionnairs.forEach((ques) => {
              fetchQuestionnaireTitles(ques, vm.jobQuestionnairs.length);
            });
          } else {
            vm.noDefaultQuestionnaire = true;
            vm.noPreSelection = true;
            vm.loadingAnswer = false;            
          }
        }).catch(() => {
          vm.loadingAnswer = false;
          $rootScope.api_status('alert-danger');
        });
      }

      function checkIfDefaultQuestionnaire() {
        // add default questionnaires for clients and agencies
        let agencyAccountId;
        if (storageService.getItem('account_type') === 'agency') {
          agencyAccountId = storageService.getItem('account_id');
        } else if (storageService.getItem('account_type') === 'client') {
          angular.forEach(storageService.getItem('accounts'), (account) => {
            if (account.id === storageService.getItem('account_id')) {
              agencyAccountId = account.agency_account_id;
            }
          });
        }
        if (agencyAccountId) {
          readAllQuestionnairesAttachedToCandidates(agencyAccountId);
        } else if (vm.jobQuestionnairs && vm.jobQuestionnairs.length > 0) {
          vm.jobQuestionnairs.forEach((ques) => {
            fetchQuestionnaireTitles(ques, vm.jobQuestionnairs.length);
          });
        } else {
          vm.noDefaultQuestionnaire = true;
          vm.noPreSelection = true;
          if (vm.questionnaires && vm.questionnaires.length > 0) {
            vm.questionnaires = $filter('orderBy')(vm.questionnaires, 'rank');
            selectQuestionnaire(vm.questionnaires[0]);
          } else {
            vm.loadingAnswer = false;
          }
        }
      }

      function getCandidateDispatchedQuestionarrie() {
        vm.pendingQuestionnairePromise = api.service_get('toolkit', `questionnaire/dispatched-questionnaires?filter_by_job_id=${vm.jobId}`, {
          filter_by_candidate_id: vm.candidateId,
          load_with: 'questionnaire',
        }).then((response) => {
          const res = response.data.data;
          if (res.result.length > 0) {
            res.result.forEach((item) => {
              // check if the questionnaire is returned
              if (item.questionnaire !== null) {
                if (item.status == 'complete') {
                  item.questionnaire.tag = 'dispatched';
                  item.questionnaire.is_questionnaire_completed = true;
                  item.questionnaire.date_sent = item.created_at ? utils.getTimeFormat(item.created_at, 'LL') : null;
                  item.questionnaire.date_answered = item.updated_at ? utils.getTimeFormat(item.updated_at, 'LL') : null;

                  vm.questionnaires.push(item.questionnaire);
                }
              }
            });
          }
          if (vm.questionnaires.length > 0) {
            vm.noDispatchedQuestionnaire = false;
          } else {
            vm.noDispatchedQuestionnaire = true;
          }
          checkIfDefaultQuestionnaire();
        }).catch(() => {
          $rootScope.api_status('alert-danger');
        });
      }

      function getQuestionnairesStatus(questionnaires) {
        let _questionnaires = [];
        let _temp_questionnaires = [];
        const _questionnaires_ids = _.pluck(questionnaires, 'questionnaire_id');
        const defer = $q.defer();
        const promise = api.service_post('toolkit', 'questionnaire/answers/are-questionnaires-completed', {
          questionnaire_ids: _questionnaires_ids,
          account_id: vm.candidate.account_id,
          job_id: vm.jobId,
        }).then((response) => {
          if (response.data.status == 'success') {
            _temp_questionnaires = response.data.data.result.questionnaires;
          }
          defer.resolve();
        }).catch(() => {
          defer.resolve();
        });

        $q.when(promise).then(() => {
          _.each(questionnaires, (q) => {
            const q_status_properties = _.find(_temp_questionnaires, (v, k) => q.questionnaire_id == k);
            q = Object.assign(q, q_status_properties);
          });
          _questionnaires = _.filter(questionnaires, (questionnaire) => questionnaire.is_active || questionnaire.is_questionnaire_completed);
          vm.jobQuestionnairs = _questionnaires;
          getCandidateDispatchedQuestionarrie();
        });
      }

      function checkJobHasQuestionnarie() {
        vm.jobQuestionnairs = [];
        vm.jobQuestionnairePromise = api.service_get('jobs', `job/${vm.jobId}`).then((response) => {
            vm.jobInfo = response.data;
            if (response.data.questionnaires.length > 0) {
                getQuestionnairesStatus(response.data.questionnaires);
            } else {
                getCandidateDispatchedQuestionarrie();
            }          
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          vm.noDefaultQuestionnaire = true;
          vm.noPreSelection = true;
          vm.loadingAnswer = false;
          vm.noDispatchedQuestionnaire = true;
        });
      }

      function enableEditMode() {
        vm.showEditQButton = false;
        vm.editMode = true;
      }

      function showErrorAnswers() {
        $rootScope.api_status(
          'error',          
          'An error has occurred and the responses could not be saved, please try again or contact support@workland.com for assistance',
          'Une erreur s\'est produite et les réponses n\'ont pu être enregistrées, veuillez réessayer ou contacter support@workland.com pour obtenir de l\'aide',
          'Error',
          'Erreur',
          5500,
        );
      }

      function prepareAnswersData(answers) {
        const _arrayOfData = [];
        const data = {
          email: vm.candidate.email,
          user_id: vm.candidateId ? vm.candidateId : vm.candidate.user_id,
          account_id: vm.candidate.account_id,
          job_id: vm.jobId,
          is_private: vm.selectedQuestionnaire.private,
        };
        _.each(answers, (a) => {
          let _data = angular.copy(data);
          _data.questionnaire_question_id = a.questionnaire_question_id;
          _data.score_obtained = a.score_obtained;
          if (a.location_id) {
            _data.location_id = a.location_id;
          }
          if (a.text) {
            _data.text = a.text;
          }
          if (a.choice_id) {
            _data.choice_id = a.choice_id;
          }
          if (a.row_id) {
            _data.row_id = a.row_id;
          }
          if (a.column_id) {
            _data.column_id = a.column_id;
          }
          if (a.scale) {
            _data.scale = a.scale;
          }
          if (typeof a.boolAnswer === 'boolean') {
            _data.boolAnswer = a.boolAnswer;
          }
          _arrayOfData.push(_data);
          _data = {};
        });
        return _arrayOfData;
      }

      $scope.sendFilledQuestionnaire = () => {
        vm.processAnswersLoader = true;
        vm.editMode = false;
        if (!vm.allAnswers.length) {
          selectQuestionnaire(vm.selectedQuestionnaire);
          showErrorAnswers();
          vm.processAnswersLoader = false;
          return;
        }

        const promisesArray = [];
        let candidateIsQualified = true;
        let hasError = false;
        const arrayOfData = prepareAnswersData(vm.allAnswers);
        arrayOfData.forEach((item) => {
          promisesArray.push(
            api.service_post('toolkit', 'questionnaire/answers/open', item)
              .then((response) => {
                const res = response.data;
                if (res.status == 'success') {
                  if (!res.data.result.qualifies) {
                    candidateIsQualified = false;
                  }
                } else {
                  // @todo get msgs
                  hasError = true;
                }
              })
              .catch(() => {
                // @todo get msgs
                hasError = true;
              }),
          );
        });
        $q.all(promisesArray).then(() => {
          if (hasError) {
            showErrorAnswers();
          } else if (!candidateIsQualified) {
            $rootScope.api_status(
              'alert-danger',              
              'The candidate did not qualify',
              'Le candidat ne s\'est pas qualifié',
              'Fail!',
              'Echec!',
              5500,
            );
          } else {
            $rootScope.api_status(
              'alert-success',              
              'The candidate has qualified',
              'Le candidat s\'est qualifié',
              'Success!',
              'Succès!',
              5500,
            );
          }
          selectQuestionnaire(vm.selectedQuestionnaire);
          vm.processAnswersLoader = false;
        });
      };

      $scope.cancelFillQuestionnaire = () => {
        vm.editMode = false;
        vm.allAnswers = [];
        selectQuestionnaire(vm.selectedQuestionnaire);
      };

      $scope.$watch('vm.candidateId', () => {
        if (vm.isCrmCandidates && vm.isCrmCandidates.state) {   
          const defaultOptionAdded = vm.candidate.jobList.some(job => job.id === null);
            if (!defaultOptionAdded) vm.candidate.jobList.unshift(vm.defaultCrmSelectOption);
            if (!vm.selectedJob) {
              vm.crmJobCandidate.selected = vm.candidate.jobList[vm.candidate.jobList.length > 1 ? 1 : 0];
              vm.jobId = vm.candidate.jobList.length > 1 ? vm.candidate.jobList[1].id : null;
            }
        }
        vm.questionnaires = [];
        vm.noPreSelection = false;
        vm.loadingAnswer = true;
        vm.selectedQuestionnaire = null;
        vm.noDefaultQuestionnaire = false;
        vm.noDispatchedQuestionnaire = false;
        if (vm.jobId) {
          checkJobHasQuestionnarie();
        } else {
          vm.noDefaultQuestionnaire = true;
          vm.noPreSelection = true;
          vm.loadingAnswer = false;
          vm.noDispatchedQuestionnaire = true;
        }
      });

      $scope.$watch('vm.questionnaireClicked', () => {
        if (vm.questionnaireClicked) {
          selectQuestionnaire(JSON.parse(vm.questionnaireClicked));
        }
      });

      $scope.$watch('vm.questionnaires', () => {
        $scope.$emit('questionnairesUp', vm.questionnaires);
      });
  }

  IsedViewSendQuestionnairesAnswerController.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
    '$filter',
    'storageService',
    '$q',
  ];

  angular.module('atlas')
    .directive('isedViewSendQuestionnairesAnswer', () => ({
      scope: {
        
      },
      bindToController: {
        jobId: '=?',
        candidate: '=',
        candidateId: '=',
        workflowStages: '=',
        allStageCandidates: '=',
        isCrmCandidates: '=?',
        questionnaires: '=?',
        questionnaireClicked: '=?',
      },
      controller: IsedViewSendQuestionnairesAnswerController,
      controllerAs: 'vm',
      templateUrl: './employer-profile/ised/questionnaires-answers/ised-view-send-questionnaires-answer.template.html',
    }));
}(angular));
