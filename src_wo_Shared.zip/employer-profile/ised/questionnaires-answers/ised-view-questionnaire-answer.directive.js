( function ( angular ) {
    function IsedViewQuestionnaireAnswerController( 
        $scope, 
        api, 
        utils, 
        Event, 
        _, 
        $rootScope,
        ) {

        var vm = this;
            var vmExtend = {
                out: utils.out,
                range: _.range,
                moveCandidateToStage: moveCandidateToStage,
                queryOn: false,
                stageEvent: false,
            };
            angular.extend( vm, vmExtend );

            init();
            
            $scope.$watch('vm.selectedQuestionnaire',function(newVal,oldVal){
               initQuestionnaire();
            });

            function init() {                    
                initQuestionnaire();
            }

            function initQuestionnaire() {
                vm.allPass = true;   
                if(vm.selectedQuestionnaire)           
                _.each( vm.selectedQuestionnaire.questionnaire_questions, function ( quest ) {
                    vm.allPass = vm.allPass && ( quest.grade !== undefined && +quest.grade >= +quest.passMark );
                } );
                vm.stageEvent = setStageTranslation('preselected');
            }

            function setStageTranslation( stage ) {
                var current_stage = _.find(vm.workflowStages, function( stage_item ) {
                    return stage_item.events.indexOf(stage) > -1;
                });
                return current_stage;
            }

            function moveCandidateToStage( stage ) {
                var msgFr = '';
                var msgEn = '';
                if(vm.queryOn) {
                    return;
                }
                
                var stage_data = setStageTranslation(stage);
                if (stage_data) {
                    vm.queryOn = true;
                }
                msgEn = "Moving candidate to " + stage_data.translations.en.label + " stage";
                msgFr = "Déplacement du candidat vers l'étape " + stage_data.translations.fr.label;
                $rootScope.api_status("waiting", msgEn, msgFr);             
                var data = {
                    "stage_id": stage_data.id,
                    "stage_events": stage_data.events,
                    "workflow_id": stage_data.workflow_id,
                    "job_id": vm.jobId,
                    "user_ids": [vm.candidateId],
                    "language": $rootScope.language,
                    "is_ats": 1, // query only used when !vm.reference && !vm.isCrmCandidates
                };
                var promise = api.service_post('workflow', 'workflows/move-candidate', data);
                promise.then(function (response) {
                    vm.queryOn = false;
                    if (response.data.status === "success") {
                        Event.broadcast('CANDIDATE_MOVED_EVENT', data);
                        msgEn = "Candidate moved successfully to " + stage_data.translations.en.label + " stage";
                        msgFr = "Candidat transféré avec succès à l'étape " + stage_data.translations.fr.label;
                        $rootScope.api_status('alert-success', msgEn, msgFr);
                        var stageIndx = "";
                        _.each(vm.workflowStages, function(candidate_stage) {
                            if(stage_data.id === candidate_stage.id){
                                stageIndx = vm.workflowStages.indexOf(candidate_stage);
                            }               
                        });
                        vm.workflowStages[stageIndx].count += 1;
                        var indexOfCand = '';
                        var previousStage = _.find(vm.workflowStages, function(stage) {
                            return vm.candidate.stage === stage.translations.en.label;
                        });
                        previousStage.count = previousStage.count-1;
                        indexOfCand = vm.allStageCandidates.indexOf(vm.candidate);
                        vm.allStageCandidates.splice(indexOfCand, 1);
                        vm.candidate.stage = stage_data.translations.en.label;
                        vm.candidate.stageFr = stage_data.translations.fr.label;
                    }
                    else {
                        msgEn = "Failed to move candidate";
                        msgFr = "Erreur lors du déplacement du candidat";
                        $rootScope.api_status('alert-danger', msgEn, msgFr);
                    }
                }).catch(function (error) {
                    vm.queryOn = false;
                    msgEn = "Failed to move candidate";
                    msgFr = "Erreur lors du déplacement du candidat";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                });
            }
    }
    IsedViewQuestionnaireAnswerController.$inject = [
        '$scope', 
        'api', 
        'utils', 
        'Event', 
        '_', 
        '$rootScope',
        ];
    angular.module( 'atlas' )
        .directive( 'isedViewQuestionnaireAnswer', function ( ) {
            return {
                scope: {                     
                },
                bindToController: {
                    selectedQuestionnaire: '=',
                    workflowStages:'=',
                    jobId: '=',
                    candidate: '=',
                    candidateId: '=',
                    reference:'=',
                    allStageCandidates: '=',
                    isCrmCandidates: '=',
                },
                controller: IsedViewQuestionnaireAnswerController,
                controllerAs: 'vm',
                templateUrl: './employer-profile/ised/questionnaires-answers/ised-view-questionnaire-answer.template.html'
            };
        } );

} )( angular );