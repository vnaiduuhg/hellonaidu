(function (angular) {
  function IsedViewQuestionAnswerController($scope, $rootScope, $timeout, api, utils, _) {
    const vm = this;
      vm.isNumber = angular.isNumber;
      vm.question = vm.isFollowup ?
                    vm.selectedQuestionnaire[vm.pos].tail_q_question :
                    vm.selectedQuestionnaire.questionnaire_questions[vm.pos];

      function setupAnswerdForDisplay() {
        vm.answersDisplay = {};
        // the questionnaire may be attached to the job after the candidate has applied to it; so there will be no answers
        switch (vm.question.question.type) {
          case 'yes-no':
            vm.answersDisplay.answers = vm.question.answers.length > 0 ? vm.question.answers[0].boolAnswer : null;
            break;
          case 'mc-ss':
            vm.answersDisplay.answers = vm.question.answers.length > 0 ? vm.question.answers[0].choice_id : '';
            break;
          case 'desc':
            vm.answersDisplay.answers = vm.question.answers.length > 0 ? vm.question.answers[0].text : '';
            break;
          case 'format':
            vm.answersDisplay.answers = vm.question.answers.length > 0 ? vm.question.answers[0].text : '';
            break;
          case 'scale':
            vm.answersDisplay.options = {
              floor: 1,
              ceil: vm.question.question.scale_range,
              showTicks: true,
              showTicksValues: true,
            };
            vm.answersDisplay.options.disabled = true;
            vm.answersDisplay.answers = vm.question.answers.length > 0 ? parseInt(vm.question.answers[0].scale, 10) : '';
            break;
          case 'table':
            if (vm.question.answers.length > 0) {
              vm.answersDisplay.answers = new Array(vm.question.question.answers);
              _.each(vm.answersDisplay.answers, (v, k) => {
                if (vm.question.answers[k.toString()]) {
                  vm.answersDisplay.answers[k] = true;
                } else {
                  vm.answersDisplay.answers[k] = false;
                }
              });
            }
            break;
        }
      }
      let createTimeout;
      function init() {
        setupAnswerdForDisplay();
        createTimeout = $timeout(() => {
          $scope.$broadcast('rzSliderForceRender');
        });
      }

      $scope.$watch('vm.selectedQuestionnaire', (newVal, oldVal) => {
        vm.question = vm.isFollowup ?
                      vm.selectedQuestionnaire[vm.pos].tail_q_question :
                      vm.selectedQuestionnaire.questionnaire_questions[vm.pos];
        init();
      });

      function updatePassState() {
        vm.allPass = true;
        _.each(vm.selectedQuestionnaire.questionnaire_questions, (quest) => {
          vm.allPass = vm.allPass && (quest.grade !== undefined && quest.grade >= quest.passMark);
        });
      }

      function updateQuestionnaireAnswers() {
        api.service_post('toolkit', 'questionnaire/answers', {
          job_id: vm.jobId,
          candidate_id: vm.candidateId,
          questionnaire_id: vm.question.questionnaire_id,
          question: vm.question,
        }).then(() => {
          updatePassState();
        });
      }

      function checkTableAns(row, col) {
        for (let i = 0; i < vm.question.answers.length; i++) {
          if (vm.question.answers[i].column_id == col.id && vm.question.answers[i].row_id == row.id) {
            return true;
          }
        }
      }

      function checkMcMs(choice) {
        for (let i = 0; i < vm.question.answers.length; i++) {
          if (vm.question.answers[i].choice_id == choice.id) {
            return true;
          }
        }
      }

      const vmExtend = {
        isAdmin: $rootScope.currentUser.permissions.isAdmin,
        out: utils.out,
        range: _.range,
        answersDisplay: {},
        updateQuestionnaireAnswers,
        checkTableAns,
        checkMcMs,
      };
      angular.extend(vm, vmExtend);

      $scope.$on('$destroy', function () {
        $timeout.cancel(createTimeout);
      });
      
      init();
  }
  angular.module('atlas')
    .directive('isedViewQuestionAnswer', () => ({
      scope: {
      },
      bindToController: {
        jobId: '=',
        candidateId: '=',
        pos: '=',
        selectedQuestionnaire: '=',
        allPass: '=',
        isFollowup: '=',
        choices: '='
      },
      controller: IsedViewQuestionAnswerController,
      controllerAs: 'vm',
      templateUrl: './employer-profile/ised/questionnaires-answers/ised-view-question-answer.template.html',
    }));
  IsedViewQuestionAnswerController.$inject = ['$scope', '$rootScope', '$timeout', 'api', 'utils', '_'];
}(angular));
