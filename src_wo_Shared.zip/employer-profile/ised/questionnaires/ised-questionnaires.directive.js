(function(angular, jsPDF) {
    'use strict';
    angular.module('atlas')
        .directive('isedQuestionnaires', function() {

            return {
                scope: {},
                controller: IsedQuestionnairesController,
                templateUrl: './employer-profile/ised/questionnaires/ised-questionnaires.template.html'
            };
        });

    IsedQuestionnairesController.$inject = ['$scope', '$rootScope', '$q', 'api', 'utils', '$uibModal', '$timeout', '_', 'worklandLocalize', 'Pager'];

    function IsedQuestionnairesController($scope, $rootScope, $q, api, utils, $uibModal, $timeout, _, worklandLocalize, Pager) {
        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            language: utils.language,
            adminAccess: $rootScope.currentUser.permissions.isAdmin,
            questions: [],
            reloadQuestionnarie: false,
            editCtr: {
                questionnaireEditEnabled: false,
                questionEditEnabled: false
            },
            cloning: {
                enabled: false
            },
            sectionsCtrl: {
                showCalssification: false
            },
            confirm: {},
            sortableOptions: {
                stop: sortableStop
            },
            search: {
                keyword: ''
            },
            newQuestionData: {},
            questionnairesQueryFailed: false,
            questionnaireEditFormModel: {},
            pageSize: { selected: 15 },
            pageSizeSelect: [10, 15, 20, 25, 50],
            pageQuestionnairesLoader: false,
            searchTimeout: null,
            questionnaires: [],
            newQuestionnaireId: null,
            createQuestionnaire: createQuestionnaire,
            deleteQuestionnaire: deleteQuestionnaire,
            editQuestionnaire: editQuestionnaire,
            editQuestionnaireCancel: editQuestionnaireCancel,
            cloneQuestionnaire: cloneQuestionnaire,
            loadQuestionnaires: loadQuestionnaires,
            displayQuestionnaire: displayQuestionnaire,
            previewQuestionnaire: previewQuestionnaire,
            attachQuestionnaire2job: attachQuestionnaire2job,
            cloneQuestion: cloneQuestion,
            cloneQuestionOnly: cloneQuestionOnly,
            editQuestion: editQuestion,
            replaceQuestionCallBack: replaceQuestionCallBack,
            replaceFollowupQCallBack: replaceFollowupQCallBack,
            editQuestionCancel: editQuestionCancel,
            addQuestionFromBank: addQuestionFromBank,
            selectQuestionFromBank: selectQuestionFromBank,
            saveFollowUpQuestion: saveFollowUpQuestion,
            addQuestion2Questionnaire: addQuestion2Questionnaire,
            deleteQuestionFromQuestionnaire: deleteQuestionFromQuestionnaire,
            newQuestionActionSelected: newQuestionActionSelected,
            editConditions: editConditions,
            editConditionsCancel: editConditionsCancel,
            reload_questionnarie: reload_questionnarie,
            deleteFollowupQuestionFromQuestionnaire: deleteFollowupQuestionFromQuestionnaire,
            keywordQuestionnairesQuery: keywordQuestionnairesQuery,
            clearQuestionnairesListSearch: clearQuestionnairesListSearch,
            getQuestionnairesListByNumOfPage: getQuestionnairesListByNumOfPage,
            beforeToLoadQuestionnaires: beforeToLoadQuestionnaires,
            viewQuestionnaireHistory: viewQuestionnaireHistory,
        };
        angular.extend($scope, scope);

        var rootModelListener = $rootScope.$watch('language', () => {
            $scope.pageQuestionnairesLoader = true;
            loadQuestionnaires();
        });

        init();

        function beforeToLoadQuestionnaires(id) {
            $scope.newQuestionnaireId = id ? id : null;
            $scope.questionnaireEditFormModel = {};
            $scope.pageQuestionnairesLoader = true;
            loadQuestionnaires();
        }

        function openModal(templateUrl, successCB, failureCB) {
            var modalSize = 'md';
            var modal = $uibModal.open({
                size: modalSize,
                animation: true,
                templateUrl: templateUrl,
                scope: $scope,
                backdrop: 'static'
            });
            modal.result.then(function() {
                if (successCB) {
                    successCB();
                }
            }).catch(function() {
                if (failureCB) {
                    failureCB();
                }
            });
            return modal;
        }

        function init() {
            $q.all([
                loadQuestionnaires(),
                loadQuestions(),
            ]);
        }

        function setPagination(data) {
            $scope.pager = Pager.GetPager(data.total, data.current_page, $scope.pageSize.selected, false);
        }

        $scope.setPage = function(page) {
            if (page < 1 || page > $scope.pager.totalPages) {
                return;
            }
            $scope.pager.currentPage = page;
            $scope.pageQuestionnairesLoader = true;
            loadQuestionnaires();
        }

        function checkNumberOfQuestionnairesListed(action) {
            switch (action) {
                case 'add':
                    if (($scope.pager.endIndex - $scope.pager.startIndex) == $scope.pageSize.selected - 1) {
                        $scope.pager.currentPage++;
                    }
                    break;
                case 'remove':
                    if (($scope.pager.endIndex == $scope.pager.startIndex) && $scope.pager.currentPage > 1) {
                        $scope.pager.currentPage--;
                    }
                    break;
            }
        }

        function keywordQuestionnairesQuery(searched_string) {
            $scope.displayedQuestionnaire = null;
            $scope.pageQuestionnairesLoader = true;
            if ($scope.searchTimeout) {
                $timeout.cancel($scope.searchTimeout);
            }
            $scope.searchTimeout = $timeout(() => {
                $scope.pager.currentPage = 1;
                loadQuestionnaires();
            }, 800);
        }

        function getQuestionnairesListByNumOfPage() {
            $scope.pageQuestionnairesLoader = true;
            $scope.pager.currentPage = 1;
            loadQuestionnaires();
        }

        function clearQuestionnairesListSearch() {
            $scope.search.keyword = '';
            $scope.displayedQuestionnaire = null;
            $scope.pageQuestionnairesLoader = true;
            $scope.pager.currentPage = 1;
            loadQuestionnaires();
        }

        function cloneQuestionnaire() {
            var msgEn = "Cloning Your Questionnaire...";
            var msgFr = "Duplication de votre questionnaire en cours...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            api.service_post('toolkit', 'questionnaire/questionnaires/deep-clone/' + $scope.questionnaireData.id, {}).then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    checkNumberOfQuestionnairesListed('add');
                    $scope.pageQuestionnairesLoader = true;
                    $scope.newQuestionnaireId = res.data.result.id;
                    loadQuestionnaires();
                    /* @std by
                    $scope.questionnaires.unshift($scope.questionnaireData); */
                    $rootScope.api_status('alert-success', "Sucessfully cloned", "Dupliqué avec succès");
                } else {
                    showQuestionnaireErrorMsg('clone');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionnaireErrorMsg('clone');
                }
            });
        }

        function deleteQuestionnaire() {
            var msgEn = "Archiving Your Questionnaire...";
            var msgFr = "Archivage de votre questionnaire en cours...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var promise = api.service_delete('toolkit', 'questionnaire/questionnaires/' + $scope.displayedQuestionnaire.id);
            promise.then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    $scope.displayedQuestionnaire = null;
                    $rootScope.api_status('alert-success', "Sucessfully archived", "Archivé avec succès");
                    checkNumberOfQuestionnairesListed('remove');
                    $scope.pageQuestionnairesLoader = true;
                    loadQuestionnaires();
                } else {
                    showQuestionnaireErrorMsg('archive');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionnaireErrorMsg('is_used');
                        break;
                    default:
                        showQuestionnaireErrorMsg('archive');
                }
            });
        }

        function editQuestionnaire() {
            $scope.editCtr.questionnaireEditEnabled = true;
            $scope.questionnaireEditFormModel = angular.copy($scope.displayedQuestionnaire);
            $scope.newQuestionnaireId = $scope.displayedQuestionnaire.id;
        }

        function editQuestionnaireCancel() {
            $scope.editCtr.questionnaireEditEnabled = false;
            if ($scope.editCtr.newQuestionnaire) {
                $scope.editCtr.newQuestionnaire = false;
                $scope.displayedQuestionnaire = null;
                $scope.questionnaireEditFormModel = {};
            }
        }

        function reload_questionnarie() {
            $scope.reloadQuestionnarie = true;
            api.service_get('toolkit', 'questionnaire/questionnaires/' + $scope.displayedQuestionnaire.id, {
                'load_with': 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;',
                'sort_by': 'questionnaire_questions:rank'
            }).then(function(response) {
                const res = response.data;
                if (res.status == 'success' && res.data.result) {
                    $scope.displayedQuestionnaire = res.data.result;
                    $scope.displayedQuestionnaire.questions = res.data.result.questionnaire_questions;
                    prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                    $scope.questionnaireData = $scope.displayedQuestionnaire;
                    $scope.questionnaireData.is_used = false;
                    $scope.editCtr.questionnaireEditEnabled = false;
                    $scope.editCtr.newQuestionnaire = false;
                    $scope.newQuestionnaireId = null;
                } else {
                    if ($scope.newQuestionnaireId) {
                        $scope.newQuestionnaireId = null;
                        $scope.displayedQuestionnaire = null;
                    }
                    showQuestionnaireErrorMsg('reload');
                }
                $scope.reloadQuestionnarie = false;
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionnaireErrorMsg('reload');
                }
                $scope.reloadQuestionnarie = false;
                if ($scope.newQuestionnaireId) {
                    $scope.newQuestionnaireId = null;
                    $scope.displayedQuestionnaire = null;
                }
            });
        }

        // @todo check if there are functionalities unused on this function
        function displayQuestionnaire(pos) {
            $scope.questionnaireAttachedToJob = null;
            $scope.displayedQuestionnaire = $scope.questionnaires[pos];
            $scope.questionnaireData = $scope.displayedQuestionnaire;
            $scope.questionnaireEditFormModel = angular.copy($scope.displayedQuestionnaire);
            // check first is the questionnarrie attached to a job
            api.service_get('jobs', 'job/questionnaire/' + $scope.questionnaireData.id + '/jobs').then(function(response) {
                $scope.questionnaireAttachedToJob = response.data;
            }).catch(function(error) {});
            // get the data for selected questionnarie
            if (!$scope.displayedQuestionnaire.questions) {
                api.service_get('toolkit', 'questionnaire/questionnaires/' + $scope.questionnaireData.id, {
                    'load_with': 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;',
                    'sort_by': 'questionnaire_questions:rank'
                }).then(function(response) {
                    const res = response.data;
                    if (res.status == 'success') {
                        $scope.displayedQuestionnaire.questions = response.data.data.result.questionnaire_questions;
                        prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                        $scope.editCtr.questionnaireEditEnabled = false;
                        $scope.editCtr.newQuestionnaire = false;
                    } else {
                        showQuestionnaireErrorMsg('load');
                    }
                }).catch(function(error) {
                    var errorMsg = '';
                    if (error && error.data && error.data.data && error.data.data.result) {
                        errorMsg = error.data.data.result;
                    }
                    switch (errorMsg) {
                        case 'Token has expired':
                            showQuestionnaireErrorMsg('token_expired');
                            break;
                        default:
                            showQuestionnaireErrorMsg('load');
                    }
                });
            } else {
                prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                $scope.editCtr.questionnaireEditEnabled = false;
                $scope.editCtr.newQuestionnaire = false;
            }
        }

        function check_if_questionnaire_attached() {
            api.service_get('jobs', 'job/questionnaire/' + $scope.questionnaireData.id + '/jobs').then(function(response) {
                $scope.questionnaireAttachedToJob = response.data;
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                }
            });
        }

        function createQuestionnaire() {
            $scope.editCtr.questionnaireEditEnabled = true;
            $scope.editCtr.newQuestionnaire = true;
            $scope.editCtr.questionEditEnabled = false;
            $scope.editCtr.newQuestion = false;
            $scope.displayedQuestionnaire = {
                questions: []
            };
            prepareQuestionnaire($scope.displayedQuestionnaire.questions);
            $scope.questionnaireEditFormModel = {};
        }

        function attachQuestionnaire2job() {
            var params = {
                closeModal: function() {
                    modal.close();
                },
                reload_attach: function() {
                    check_if_questionnaire_attached();
                    loadQuestions();
                    reload_questionnarie();
                },
                questionnaire_id: $scope.displayedQuestionnaire.id,
                is_private: $scope.displayedQuestionnaire.private,
                questionnaire_attached_to_job: $scope.questionnaireAttachedToJob
            };
            var modalParams = {
                animation: true,
                templateUrl: './employer-profile/ised/questionnaires/modals/add-questionnaire-to-job-modal.template.html',
                controller: "AddQuestionnaireToJobsController as vm",
                size: 'md',
                backdrop: 'static',
                resolve: {
                    params: function() {
                        return params;
                    }
                }
            };
            var modal = $uibModal.open(modalParams);
        }

        function viewQuestionnaireHistory() {
            const questionnaireHistoryModal = openModal('./employer-profile/ised/questionnaires/modals/questionnaire-history-modal.template.html');
            $scope.cancelQuestionnaireHistoryView = questionnaireHistoryModal.close;
        }

        function previewQuestionnaire() {
            var previewQuestionnaireModal = openModal('./employer-profile/ised/questionnaires/modals/preview-questionnaire-modal.template.html');
            $scope.cancelPreviewQuestionnaire = previewQuestionnaireModal.close;
        }

        function editQuestion(quest) {
            $scope.cloningQuestionAction = 'replace';
            $scope.question = quest;
            $scope.editCtr.questionEditEnabled = true;
            $scope.editCtr.newQuestion = false;
            $scope.editCtr.questionConditionsEdit = false;
        }

        function saveFollowUpQuestion(followup) {
            var edited_quest = angular.copy(followup);
            edited_quest.extra = angular.toJson(edited_quest.extra);
            edited_quest.conditions = angular.toJson(edited_quest.conditions);
            var entry = {
                question: edited_quest,
                questionnaire_id: $scope.displayedQuestionnaire.id
            };
            api.service_post('toolkit', 'questionnaire/questionnaire-questions', {
                entry: entry
            }).then(function(response) {
                const res = response.data;
                if (res.status == 'succes') {
                    var indx = _.findIndex($scope.displayedQuestionnaire.questions, function(question) {
                        return question.id === followup.id;
                    });
                    if (indx >= 0) {
                        $scope.displayedQuestionnaire.questions[indx] = followup;
                    }
                    prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                    $scope.editCtr.questionEditEnabled = false;
                } else {
                    showQuestionnaireErrorMsg('save_followup_q');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionnaireErrorMsg('is_used');
                        break;
                    default:
                        showQuestionnaireErrorMsg('save_followup_q');
                }
            });
        }

        function displayFormForNewQuestion() {
            $scope.question = {
                type: "",
                extra: {},
                conditions: []
            };
            $scope.editCtr.questionEditEnabled = true;
            $scope.editCtr.newQuestion = true;
        }

        function cloneQuestion(quest) {
            $scope.cloningQuestionAction = 'add';
            $scope.question = quest;
            $scope.editCtr.questionEditEnabled = true;
            $scope.editCtr.newQuestion = false;
            $scope.editCtr.questionConditionsEdit = false;
        }

        function replaceQuestionCallBack() {
            loadQuestions();
        }

        function cloneQuestionOnly(quest) {
            $scope.cloningQuestionAction = 'clone';
            $scope.question = quest;
            $scope.editCtr.questionEditEnabled = true;
            $scope.editCtr.newQuestion = false;
            $scope.editCtr.questionConditionsEdit = false;
        }

        function replaceFollowupQCallBack(quest) {
            loadQuestions();
            reload_questionnarie();
        }

        function editQuestionCancel() {
            $scope.editCtr.newQuestionAction = null;
            $scope.editCtr.questionEditEnabled = false;
            $scope.editCtr.newQuestion = false;
        }

        function addQuestion2Questionnaire(question) {
            $rootScope.api_status("waiting", "Adding question...", "Ajout de la question en cours...");
            var data = {
                "questionnaire_id": $scope.displayedQuestionnaire.id,
                "question_id": question.id,
                "rank": ++$scope.sortable.length
            }
            api.service_post('toolkit', 'questionnaire/questionnaire-questions', data).then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    $rootScope.api_status('alert-success');
                    reload_questionnarie();
                } else {
                    showQuestionnaireErrorMsg('add_q');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionnaireErrorMsg('is_used');
                        break;
                    default:
                        showQuestionnaireErrorMsg('add_q');
                }
            });
        }

        function deleteFollowupQuestionFromQuestionnaire(followup_q) {
            api.service_delete('toolkit', 'questionnaire/question-branches/' + followup_q.id).then((response) => {
                const res = response.data;
                if (res.status == 'success') {
                    $rootScope.api_status(
                        "ok",
                        "The follow up question has been successfully detached from the questionnaire!",
                        "La question de suivi a été détachée du questionnaire avec succès!"
                    );
                    reload_questionnarie();
                } else {
                    showQuestionnaireErrorMsg('delete_followup_q');
                }
            }).catch((error) => {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionnaireErrorMsg('is_used');
                        break;
                    default:
                        showQuestionnaireErrorMsg('delete_followup_q');
                }
            });
        }

        function deleteQuestionFromQuestionnaire(quest) {
            var msgEn = "Deleting question...";
            var msgFr = "Suppression de la question en cours...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            api.service_delete('toolkit', 'questionnaire/questionnaire-questions/' + quest.id, {
                id: quest.id,
            }).then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    var indx = _.findIndex($scope.displayedQuestionnaire.questions, function(question) {
                        return question.id === quest.id;
                    });
                    if (indx >= 0) {
                        $scope.displayedQuestionnaire.questions.splice(indx, 1);
                    }
                    prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                    var msgEn = "The question has been sucessfully deleted from this questionnaire";
                    var msgFr = "La question a été supprimée du questionnaire avec succès";
                    $rootScope.api_status('alert-success', msgEn, msgFr);
                } else {
                    showQuestionnaireErrorMsg('detach_q');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showQuestionnaireErrorMsg('is_used');
                        break;
                    default:
                        showQuestionnaireErrorMsg('detach_q');
                }
            });
        }

        function selectQuestionFromBank(selectedQuestion) {
            $scope.editCtr.selectedQuestion = angular.copy(selectedQuestion);
        }

        function addQuestionFromBank() {
            if ($scope.editCtr.selectedQuestion.tags) {
                delete $scope.editCtr.selectedQuestion.tags;
            }
            $scope.editCtr.selectedQuestion.conditions = [];
            addQuestion2Questionnaire($scope.editCtr.selectedQuestion);
            $scope.editCtr.newQuestionAction = null;
        }

        function newQuestionActionSelected(selected) {
            if (+selected === 1) {
                displayFormForNewQuestion();
            }
        }

        function editConditions(quest) {
            $scope.question = quest;
            $scope.editCtr.questionConditionsEdit = true;
            $scope.editCtr.questionEditEnabled = false;
            $scope.editCtr.newQuestion = false;
        }

        function editConditionsCancel(quest) {
            $scope.editCtr.questionConditionsEdit = false;
            prepareQuestionnaire($scope.displayedQuestionnaire.questions);
        }

        function prepareQuestionnaire(questions) {
            var sortable = [];
            for (var i = 0; i < questions.length; i++) {
                if (+questions[i].followup) {
                    continue;
                }
                var bundle = {
                    question: questions[i],
                    index: i,
                    followups: questions[i].question_branches
                };
                if (questions[i].question_branches && questions[i].question_branches.length) {
                    _.each(questions[i].question_branches, function(cond) {
                        if (cond.followup_ref) {
                            var indx = _.findIndex(questions, function(quest) {
                                return cond.followup_ref === quest.id;
                            });
                            if (indx >= 0) {
                                bundle.followups.push(questions[indx]);
                            }
                        }
                    });
                }
                sortable.push(bundle);
            }
            $scope.sortable = sortable;
        }

        function sortableStop(e, ui) {
            var followups = [];
            var sortedQuestions = [];
            var newRanks = [];
            _.each(ui.item.sortable.sourceModel, function(item, i) {
                item.question.rank = i;
                sortedQuestions.push(item.question);
                Array.prototype.push.apply(followups, item.followups);
                newRanks.push(item.question.id);
            });
            Array.prototype.push.apply(sortedQuestions, followups);
            api.service_post('toolkit', 'questionnaire/questionnaires/update-rank/' + $scope.questionnaireData.id, {
                questionnaire_question_ids: newRanks
            }, 'update').then(function(response) {
                $scope.displayedQuestionnaire.questions = sortedQuestions;
                prepareQuestionnaire($scope.displayedQuestionnaire.questions);
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                }
            });
        }

        function computeLargestRank(questions) {
            var rank = 0;
            for (var i = 0; i < questions.length; i++) {
                if (+questions[i].followup) {
                    continue;
                }
                if (+questions[i].rank > rank) {
                    rank = +questions[i].rank;
                }
            }
            return rank;
        }

        function firstFollowUp(questions) {
            var pos = questions.length;
            for (var i = 0; i < questions.length; i++) {
                if (+questions[i].followup) {
                    pos = i;
                    break;
                }
            }
            return pos;
        }

        function loadQuestionnaires() {
            $scope.questionnaires = [];
            $scope.displayedQuestionnaire = null;
            $scope.questionnairesQueryFailed = false;
            const params = {
                page: $scope.pager ? $scope.pager.currentPage : 1,
                page_size: $scope.pageSize.selected,
                filter_by_archived: 0,
                locale: $rootScope.language,
            };
            if ($scope.search.keyword) { params.search = $scope.search.keyword }
            var promise = api.service_get('toolkit', 'questionnaire/questionnaires/list/with-is-used-flag', params);
            promise.then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    $scope.questionnaires = res.data.result ? res.data.result.data : [];
                    if ($scope.newQuestionnaireId) {
                        $scope.displayedQuestionnaire = { id: $scope.newQuestionnaireId };
                        reload_questionnarie();
                    }
                    if (!scope.pager) {
                        setPagination(res.data.result);
                    }
                } else {
                    $scope.questionnairesQueryFailed = true;
                    showQuestionnaireErrorMsg('load_many');
                }
                $scope.pageQuestionnairesLoader = false;
            }).catch(function(error) {
                $scope.questionnairesQueryFailed = true;
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionnaireErrorMsg('load_many');
                }
                $scope.pageQuestionnairesLoader = false;
            });
            return promise;
        }

        function loadQuestions() {
            var promise = api.service_get('toolkit', 'questionnaire/questions', { 'load_with': 'choices;question_rows;question_columns;' });
            promise.then(function(response) {
                const res = response.data;
                if (res.status == 'success') {
                    $scope.questions = response.data.data.result;
                } else {
                    showQuestionnaireErrorMsg('load_many_q');
                }
            }).catch(function(error) {
                var errorMsg = '';
                if (error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch (errorMsg) {
                    case 'Token has expired':
                        showQuestionnaireErrorMsg('token_expired');
                        break;
                    default:
                        showQuestionnaireErrorMsg('load_many_q');
                }
            });
            return promise;
        }

        function showQuestionnaireErrorMsg(action) {
            var msg = {
                en: "An error has occurred ",
                fr: "Une erreur est survenue "
            }
            switch (action) {
                case 'clone':
                    msg.en = msg.en + "and the questionnaire could not be cloned";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être dupliqué";
                    break;
                case 'archive':
                    msg.en = msg.en + "and the questionnaire could not be archived";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être archivé";
                    break;
                case 'reload':
                    msg.en = msg.en + "and the questionnaire could not be reloaded";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être rechargé";
                    break;
                case 'load':
                    msg.en = msg.en + "and the questionnaire could not be fetched";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être récupéré";
                    break;
                case 'load_many':
                    msg.en = msg.en + "and the questionnaires could not be fetched";
                    msg.fr = msg.fr + "et les questionnaires n'ont pu être récupérés";
                    break;
                case 'load_many_q':
                    msg.en = msg.en + "and questionnaire questions could not be fetched";
                    msg.fr = msg.fr + "et les questions du questionnaire n'ont pu être récupérées";
                    break;
                case 'save_followup_q':
                    msg.en = msg.en + "and the question could not be saved";
                    msg.fr = msg.fr + "et la question n'a pu être enregistrée";
                    break;
                case 'delete_followup_q':
                    msg.en = msg.en + " and the follow up question could not be detached from the questionnaire";
                    msg.fr = msg.fr + " et la question de suivi n'a pas pu être détachée du questionnaire";
                case 'add_q':
                    msg.en = msg.en + "and the question could not be added to questionnaire";
                    msg.fr = msg.fr + "et la question n'a pu être ajoutée au questionnaire";
                    break;
                case 'detach_q':
                    msg.en = msg.en + "and the question could not be deleted from the questionnaire";
                    msg.fr = msg.fr + "et la question n'a pu être supprimée du questionnaire";
                    break;
                case 'token_expired':
                    msg.en = "Your session has expired, please login again";
                    msg.fr = "Votre session est expirée, veuillez vous connecter à nouveau";
                    break;
                case 'is_used':
                    msg.en = "This questionnaire is used and cannot be modified";
                    msg.fr = "Ce questionnaire est utilisé et ne peut être modifié";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msg.en, msg.fr);
        }

        $scope.$on('$destroy', function() {
            // disable the listener
            rootModelListener();
        })
    }

})(angular, jsPDF);