( function ( angular ) {
    'use strict';
    function AddQuestionnaireToJobsController( api, $scope, $rootScope, utils, $window, params, $animate, $q, storageService ) {
    	// desactivate ngAnimate because conflict with ui-select-choices
        $animate.enabled(false); 

		var vm = this;
		var vmExtend = {
		    out: utils.out,
		    selectedJob: null,
		    update: update,
		    switchAction: switchAction,
		    attachQuestionnaireToCandidates: attachQuestionnaireToCandidates,
		    attachQuestionnaireToClients: attachQuestionnaireToClients,
		    deleteQuestionnaireFromCandidates: deleteQuestionnaireFromCandidates,
		    deleteQuestionnaireFromClients: deleteQuestionnaireFromClients,
		    job : { selected : {}},
		    isAgency: $rootScope.currentUser.permissions.isAgency,		   
		    existCandidateQuest: false,
		    existClientQuest: false,
		    attachToJob: false,
		    attachToClients: false,
		    attachToCandidates: false,
		    listOfAttachedJobs: [],
		    showModalBody: false
		};
		angular.extend( vm, vmExtend );

		function readAllQuestionnairesAttachedToCandidates() {
			const defer = $q.defer();
			api.service_post('toolkit', 'questionnaire/agency-candidate-questionnaire/read-all', {
				'agency_account_id': [storageService.getItem('account_id')],
				'is_active': true
			})
			.then( function ( response ) {
				angular.forEach(response.data, function(questionnaire) {		
					if(questionnaire.questionnaire_id === params.questionnaire_id ){
						vm.existCandidateQuest = true;				
					}
				});
				defer.resolve();
			}).catch( function ( response ) {
				vm.existCandidateQuest = false;
				$rootScope.api_status('alert-danger', "Sorry, there was an error while fetching the questionnaire(s).", "Désolé, une erreur s'est produit lors de la récupération du questionnaire.") ;
				defer.resolve();
			});
			return defer.promise;
		}

		function readAllQuestionnairesAttachedToClients() {
			const defer = $q.defer();
			api.service_post('toolkit', 'questionnaire/agency-client-questionnaire/read-all', {
				'agency_account_id': [storageService.getItem('account_id')],
				'is_active': true
			})
			.then( function ( response ) {
				angular.forEach(response.data, function(questionnaire) {		
					if(questionnaire.questionnaire_id === params.questionnaire_id ){
						vm.existClientQuest = true;					
					}
				});
				defer.resolve();
			}).catch( function ( response ) {
				vm.existClientQuest = false;
				$rootScope.api_status('alert-danger', "Sorry, there was an error while fetching the questionnaire(s).", "Désolé, une erreur s'est produit lors de la récupération du questionnaire.") ;
				defer.resolve();
			});
			return defer.promise;
		}

		function getListOfAllJobs() {
			const defer = $q.defer();
			api.service_get('jobs', 'job/current-account/jobs', {
	          'load_with[]': ['questionnaires', 'translations']
	        }).then( (response) => {
				vm.jobs = response.data;
				if(params.questionnaire_attached_to_job?.length && vm.jobs?.length) {
					getListOfAttachedJobs();
				}				
                defer.resolve();
			}).catch(function () {
				vm.jobs = [];
				$rootScope.api_status('alert-danger', "Sorry, there was an error while fetching the jobs list.", "Désolé, une erreur s'est produit lors de la récupération de la liste des offres d'emploi.") ;
				defer.resolve();
			});
			return defer.promise;
		}

		$scope.tagHandler = function (tag){
            return null; //official hack to workaround angular issue
        }

		function init() {
			const promises = [];
			promises.push(getListOfAllJobs());
			if(vm.isAgency) {
				promises.push(
					readAllQuestionnairesAttachedToCandidates(),
					readAllQuestionnairesAttachedToClients()
				);
			}
			$q.all(promises).then(() => {
				vm.showModalBody = true;
			});
		}

		init();

		function getListOfAttachedJobs() {
			_.each(params.questionnaire_attached_to_job, (item) => {
				 _.each(vm.jobs, (job) => {
					if(job.id == item) {
						vm.listOfAttachedJobs.push(job);
					}
				});
			});
		}

		function update() {
		    if ( vm.selectedJob ) {
				const questionnaireAlreadyAttached = validateIfQuestionnaireAttached();
				if(questionnaireAlreadyAttached) {
					$rootScope.api_status(
						'error',
						'This questionnaire is already attached to this job',
						'Ce questionnaire est déjà attaché à ce poste'
					);
					return;
				}
				const rank = vm.selectedJob.selected.questionnaires.length ?
							(_.max(vm.selectedJob.selected.questionnaires, (q) => { return q.rank; }).rank + 1) : 0;
				var data = {
					is_active: 1,
					is_private: params.is_private,
					rank: rank
				};
				var waitPromise = api.service_post('jobs', 'job/'+vm.selectedJob.selected.id+'/questionnaire/'+params.questionnaire_id, data, false
				).then( function ( response ) {
					$rootScope.api_status('alert-success', "Questionnaire attached successfully", "Questionnaire joint avec succès" );
				}).catch( function ( response ) {
					$rootScope.api_status('alert-danger', 'Sorry, there was an error while attaching the questionnaire to the job', 'Désolé, une erreur s\'est produite et le questionnaire n\'a pu être joint');
				}).finally(function(){
					params.closeModal();
					params.reload_attach();
				});
		    }
		}

		function validateIfQuestionnaireAttached() {
			if(!vm.selectedJob.selected.questionnaires.length) {
				return false;
			}
			const isAttached = _.find(vm.selectedJob.selected.questionnaires, (q) => {
				return q.questionnaire_id == params.questionnaire_id;
			});
			return isAttached ? true : false;
		}
		
		function switchAction(action) {			
			vm.attachToJob = action === 'attachJob' ? true : false;
			vm.attachToCandidates = action === 'attachCandidates' ? true : false;
			vm.attachToClients = action === 'attachClients' ? true : false;
		}

		function attachQuestionnaireToCandidates() {
			api.service_query('toolkit', 'questionnaire/agency-candidate-questionnaire/'+params.questionnaire_id, 'PUT', {'is_active': true})
				.then( function ( response ) {
					$rootScope.api_status('alert-success', "Questionnaire attached successfully", "Questionnaire joint avec succès" );
				}).catch( function ( response ) {
					$rootScope.api_status('alert-danger', 'Sorry, there was an error while attaching the questionnaire to the job', 'Désolé, une erreur s\'est produite et le questionnaire n\'a pu être joint');
				}).finally(function(){
					params.closeModal();
				});
		}

		function attachQuestionnaireToClients() {
			api.service_query('toolkit', 'questionnaire/agency-client-questionnaire/'+params.questionnaire_id, 'PUT', {'is_active': true})
				.then( function ( response ) {
					$rootScope.api_status('alert-success', "Questionnaire attached successfully", "Questionnaire joint avec succès" );
				}).catch( function ( response ) {
					$rootScope.api_status('alert-danger', 'Sorry, there was an error while attaching the questionnaire to the job', 'Désolé, une erreur s\'est produite et le questionnaire n\'a pu être joint');
				}).finally(function(){
					params.closeModal();
				});
		}

		//Remove a questionnaire from the agency's list of candidate questionnaires
		function deleteQuestionnaireFromCandidates() {
			api.service_query('toolkit', 'questionnaire/agency-candidate-questionnaire/'+params.questionnaire_id, 'PUT', {'is_active': false})
				.then( function ( response ) {
					$rootScope.api_status('alert-success', 'Questionnaire removed successfully' , 'Questionnaire enlevé avec succès');
				}).catch( function ( response ) {
					$rootScope.api_status('alert-danger', 'Sorry, there was an error while removing the questionnaire from the job', 'Désolé, une erreur s\'est produite et le questionnaire n\'a pu être enlevé');
				}).finally(function(){
					params.closeModal();
				});
		}

		//Remove a questionnaire from the agency's list of client questionnaires
		function deleteQuestionnaireFromClients() {
			api.service_query('toolkit', 'questionnaire/agency-client-questionnaire/'+params.questionnaire_id, 'PUT', {'is_active': false})
				.then( function ( response ) {
					$rootScope.api_status('alert-success', 'Questionnaire removed successfully' , 'Questionnaire enlevé avec succès');
				}).catch( function ( response ) {
					$rootScope.api_status('alert-danger', 'Sorry, there was an error while removing the questionnaire from the job', 'Désolé, une erreur s\'est produite et le questionnaire n\'a pu être enlevé');
				}).finally(function(){
					params.closeModal();
				});
		}
    }
    AddQuestionnaireToJobsController.$inject = ['api', '$scope', '$rootScope', 'utils', '$window', 'params', '$animate', '$q', 'storageService'];
    angular.module( 'atlas' )
    	.controller( 'AddQuestionnaireToJobsController', AddQuestionnaireToJobsController );

} )( angular );