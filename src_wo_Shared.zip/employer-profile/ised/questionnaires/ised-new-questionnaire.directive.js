( function ( angular, jsPDF ) {
    'use strict';
    angular.module( 'atlas' )
	    .directive( 'isedNewQuestionnaire', function () {
            return {
                scope: {
                    displayedQuestionnaire:'=',
                    editCtr:'=',
                    questionnaireEditFormModel:'=',
                    cancel: '&',
                    edit: '&',
                    callBack: '&'
                },
                controller: IsedNewQuestionnaireController,
                templateUrl: './employer-profile/ised/questionnaires/ised-new-questionnaire.template.html'
            };
        });

        IsedNewQuestionnaireController.$inject = ['$scope', '$rootScope', 'api', 'utils'];

    function IsedNewQuestionnaireController( $scope, $rootScope, api, utils) {

        var scope = {
            out: utils.out,
            createQuestionnaire:createQuestionnaire,
            updateQuestionnaireData:updateQuestionnaireData
        };
        angular.extend( $scope, scope );

        function createQuestionnaire() {
            var msgEn = "Creating your questionnaire...";
            var msgFr = "Création de votre questionnaire...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var questionnaireData = {};
            if($scope.questionnaireEditFormModel.translation.en.title){
                var en_object = {
                    title: $scope.questionnaireEditFormModel.translation.en.title,
                }
                questionnaireData.en = en_object;
            }
            if($scope.questionnaireEditFormModel.translation.fr.title){
                var fr_object = {
                    title: $scope.questionnaireEditFormModel.translation.fr.title,
                }
                questionnaireData.fr = fr_object;
            }
            questionnaireData.private = $scope.questionnaireEditFormModel.private;
            questionnaireData.enable= false;
            
            $scope.waitPromise = $scope.waitPromise = api.service_post('toolkit',  'questionnaire/questionnaires', questionnaireData ).then( function ( response ) {
                const res = response.data;
                if(res.status == 'success' && res.data.result) {
                    $scope.callBack({id:res.data.result.id});
                    $scope.cancel();
                    $rootScope.api_status('alert-success', "Sucessfully created", "Créé avec succès");
                }
                else {
                    showNewQuestionnairesErrorMsg('create');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showNewQuestionnairesErrorMsg('token_expired');
                        break;
                    default:
                        showNewQuestionnairesErrorMsg('create');
                }
            });
        }

        function updateQuestionnaireData() {
            var msgEn = "Updating your questionnaire...";
            var msgFr = "Mise à jour de votre questionnaire...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var data = {};
            data.id = $scope.questionnaireEditFormModel.id;
            data.en = {'title':$scope.questionnaireEditFormModel.translation.en.title};
            data.fr = {'title':$scope.questionnaireEditFormModel.translation.fr.title};
            data.private = $scope.questionnaireEditFormModel.private;
            $scope.waitPromise = $scope.waitPromise = api.service_post('toolkit',  'questionnaire/questionnaires/'+$scope.questionnaireEditFormModel.id, data, 'update'
            ).then( function ( response ) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.cancel();
                    $rootScope.api_status('alert-success', "Sucessfully updated", "Mis à jour avec succès");
                    data = null;
                }
                else {
                    showNewQuestionnairesErrorMsg('update');
                }
            }).catch( function ( error ) {
                var errorMsg = '';
                if(error && error.data && error.data.data && error.data.data.result) {
                    errorMsg = error.data.data.result.message ? error.data.data.result.message : error.data.data.result;
                }
                switch(errorMsg) {
                    case 'Token has expired':
                        showNewQuestionnairesErrorMsg('token_expired');
                        break;
                    case 'the_questionnaire_is_already_used':
                        showNewQuestionnairesErrorMsg('is_used');
                        break;
                    default:
                        showNewQuestionnairesErrorMsg('update');
                }
            });
        }

        function showNewQuestionnairesErrorMsg(action) {
            var msg = {
                en: "An error has occurred ",
                fr: "Une erreur est survenue "
            }
            switch(action) {
                case 'create':
                    msg.en = msg.en + "and the questionnaire could not be created";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être créé";
                    break;
                case 'update':
                    msg.en = msg.en + "and the questionnaire could not be updated; you may not have the required permissions to do so";
                    msg.fr = msg.fr + "et le questionnaire n'a pu être modifié; vous n'avez peut-être pas les autorisations requises pour le faire";
                    break;
                case 'is_used':
                    msg.en = "This questionnaire is used and cannot be modified";
                    msg.fr = "Ce questionnaire est utilisé et ne peut être modifié";
                    break;
                case 'token_expired':
                    msg.en = "Your session has expired, please login again";
                    msg.fr = "Votre session est expirée, veuillez vous connecter à nouveau";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msg.en, msg.fr);
        }
    }

} )( angular, jsPDF );