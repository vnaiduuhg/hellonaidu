( function ( angular ) {
    'use strict';
    angular.module( 'atlas' ).directive( 'isedSendQuestionnaireResultsModule', function() {

        IsedSendQuestionnaireResultsController.$inject = ['$scope', '$rootScope', 'utils', '$timeout'];
        
        function IsedSendQuestionnaireResultsController( $scope, $rootScope, utils, $timeout ) {

            var scope = {
                out: utils.out
            };
            angular.extend( $scope, scope );

            let createTimeout1;
            let createTimeout2;
            let createTimeout3;

            init();

            function init() {

                var timespan = $scope.regularPsqSuccessMsg ? 3000 : 0;
                // general succes msg - preselection questionnaires are created and updated successfully
                if($scope.regularPsqSuccessMsg) {
                    var titleEn = "Success !";
                    var titleFr = "Succès !";
                    var msgFr = "Le questionnaire des candidats a été créé avec succès!"; 
                    var msgEn = "Candidates questionnaire has been created successfully!";
                    $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr, 4000);
                }
                // general succes msg - automated email sent for notification and/or reminder
                if($scope.regularEmailSentSuccessMsg || $scope.reminderEmailSentSuccessMsg) {
                    displayEmailSentSuccessMsg(timespan);
                }
                // general fail msg - automated email sent for notification and/or reminder (gets to Pubsub step)
                if($scope.regularEmailSentFailAndSuccessMsg || $scope.reminderEmailSentFailAndSuccessMsg || $scope.regularEmailSentFailMsg || $scope.reminderEmailSentFailMsg) {
                    displayEmailSentFailMsg(timespan);
                }
                // general fail msg - automated email sent for notification and/or reminder (fail before Pubsub step)
                if($scope.regularEmailSentErrorMsg.message || $scope.reminderEmailSentErrorMsg.message) {
                    displayEmailSentErrorMsg(timespan);
                }
            }

            function displayEmailSentSuccessMsg(timespan) {
                var titleEn = "";
                var titleFr = "";
                var msgEn = "An email has been sent successfully to all selected candidates";
                var msgFr = "Un email a été envoyé à tous les candidats sélectionnés avec succès"; 
                if($scope.regularEmailSentSuccessMsg) {
                    titleEn = $scope.reminderEmailSentSuccessMsg ? "Notification and Reminder emails sent!" : "Notification emails sent!";
                    titleFr = $scope.reminderEmailSentSuccessMsg ? "Courriels de notification et de rappel envoyés!" : "Courriels de notification envoyés!";
                }
                else if($scope.reminderEmailSentSuccessMsg) {
                    titleEn = "Reminder emails sent!";
                    titleFr = "Courriels de rappel envoyés!";
                }
                createTimeout1 = $timeout( function() {
                    $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr, 6000);
                }, timespan)
            }

            function displayEmailSentFailMsg(timespan) {
                var titleEn = "An error has occurred !";
                var titleFr = "Une erreur est survenue !";
                var msgEn = "Please refer to each candidate form for the status of sending these automated emails: ";
                var msgFr = "Veuillez vous reporter à chaque fiche candidat pour connaître le statut de l'envoi de ces courriels automatisés: "; 
                if($scope.regularEmailSentFailAndSuccessMsg || $scope.regularEmailSentFailMsg) {
                    msgEn = "Notification"
                    msgFr = "Courriels de Notification";
                }
                msgEn += $scope.reminderEmailSentFailAndSuccessMsg || $scope.reminderEmailSentFailMsg ? " and Reminder Emails" : "Reminder Emails";
                msgFr += $scope.reminderEmailSentFailAndSuccessMsg || $scope.reminderEmailSentFailMsg ? " et de Rappel" : "Courriels de Rappel";
                createTimeout2 = $timeout( function() {
                    $rootScope.api_status('alert-danger', msgEn, msgFr, titleEn, titleFr, 6000);
                }, timespan)
            }

            function displayEmailSentErrorMsg(timespan) {
                var titleEn = "Warning !";
                var titleFr = "Attention !";
                var msgEn = $scope.regularEmailSentErrorMsg.en ? $scope.regularEmailSentErrorMsg.en : $scope.reminderEmailSentErrorMsg.en;
                var msgFr = $scope.regularEmailSentErrorMsg.fr ? $scope.regularEmailSentErrorMsg.fr : $scope.reminderEmailSentErrorMsg.fr; 
                var enumTemplate = false;
                if($scope.regularEmailSentErrorMsg.message == 'template_not_enabled') {
                    msgEn += ": Questionnaire de pré-sélection envoyé au candidat";
                    msgFr += ": Pre-Selection Questionnaire Sent To Candidate";
                    enumTemplate = true;
                }
                if($scope.reminderEmailSentErrorMsg.message == 'template_not_enabled') {
                    msgEn += enumTemplate ? " and Rappel au candidat de remplir un questionnaire de présélection" : ": Rappel au candidat de remplir un questionnaire de présélection";
                    msgFr += enumTemplate ? " et Pre-Selection Questionnaire Reminder For Candidate" : ": Pre-Selection Questionnaire Reminder For Candidate";
                }
                createTimeout3 = $timeout( function() {
                    $rootScope.api_status('alert-danger', msgEn, msgFr, titleEn, titleFr, 6000);
                }, timespan)
            }

            $scope.$on('$destroy', function () {
              $timeout.cancel(createTimeout1);
              $timeout.cancel(createTimeout2);
              $timeout.cancel(createTimeout3);
            });

        }

        return {
            scope: {
                candResultsPsq: '=',
                regularPsqSuccessMsg: '=',
                regularEmailSentErrorMsg: '=',
                regularEmailSentFailMsg: '=',
                regularEmailSentSuccessMsg: '=',
                regularEmailSentFailAndSuccessMsg: '=',
                reminderEmailSentErrorMsg: '=',
                reminderEmailSentFailMsg: '=',
                reminderEmailSentSuccessMsg: '=',
                reminderEmailSentFailAndSuccessMsg: '='
            },
            controller: IsedSendQuestionnaireResultsController,
            templateUrl: './employer-profile/ised/questionnaires/ised-send-questionnaire-results/ised-send-questionnaire-results.template.html'
        };

    } );

} )( angular );