(function (angular) {
  function IsedSendQuestionnaireModuleCtrl($scope, $rootScope, api, utils, _, $timeout, $q) {
    const d = new Date();
    $scope.formModel = {
      startDate: new Date(),
      endDate: new Date(),
      questionnaire_id: { selected: {} },
    };
    $scope.formModel.startDate.setMinutes(d.getMinutes() + 15);
    $scope.formModel.endDate.setDate(d.getDate() + 7);
    $scope.formModel.endDate.setHours(0, 0, 0, 0);
    let scope = {
      out: utils.out,
      timezone: utils.initTimezone(),
      utcToTimezone: utils.utcToTimezone,
      datePickers: {
        startDate: false,
        endDate: false,
      },
      dateOptions: {
        formatDay: 'dd',
        formatMonth: 'M',
        formatYear: 'yyyy',
        startingDay: 1,
      },
      dispatches: null,
      dispatched_results_array: [],
      candidateToUnselect: [],
      am_pm_start_date: null,
      am_pm_end_date: null,
      loading: false,
      loadingdispatches: false,
      first_init: true,
      firstInitTimeout: null,
      timeoutPromise: null,
      existingCandidatesQDispatch: [],
      cand_results_psq: [],
      regular_psq_success_msg: false,
      regular_email_sent_error_msg: {},
      regular_email_sent_fail_msg: false,
      regular_email_sent_success_msg: false,
      regular_email_sent_fail_and_success_msg: false,
      reminder_email_sent_error_msg: {},
      reminder_email_sent_fail_msg: false,
      reminder_email_sent_success_msg: false,
      reminder_email_sent_fail_and_success_msg: false,
      openBulkCandidatesResults: false,
      initData: true,
      crmJobCandidate: {
        selected: {
          translations: [
            { title: 'Select job' },
            { title: 'Choisir un poste' },
          ],
          id: -1,
        },
      },
      defaultCrmSelectOption: {
        id: null,
        translations: [{ title: 'No job' }, { title: 'Aucun poste' }],
      },
    };
    angular.extend($scope, scope);

    let createTimeout1;
    let createTimeout2;
    let createTimeout3;

    $scope.tagHandler = function tagHandler(tag) {
      return null;
    };

    $scope.$watch('formModel.startDate', (date) => {
      $scope.am_pm_start_date = date.getHours() < 12 ? 'AM' : 'PM';
    });
    $scope.$watch('formModel.endDate', (endDate) => {
      $scope.am_pm_end_date = endDate.getHours() < 12 ? 'AM' : 'PM';
    });

    function openDatePicker(event, picker) {
      event.preventDefault();
      event.stopPropagation();
      $scope.datePickers[picker] = true;
    }

    function setStatusTranslation(dispatches) {
      _.each(dispatches, (disp) => {
        switch (disp.status) {
          case 'pending':
            disp.statusFr = 'En attente';
            break;
          case 'complete':
            disp.statusFr = 'Complété';
            break;
          case 'incomplete':
            disp.statusFr = 'Non complété';
            break;
        }
      });
    }

    function processDispatchedAndUpdateQuestionaireList(data) {
      if ($scope.selectedCandidates.length === 1) {
        [$scope.dispatches] = data;
        setStatusTranslation(data[0]);

        $scope.questionnairesForCandidate = [];
        _.each($scope.allquestionnaires, (questionnaire) => {
          const indx = _.findIndex($scope.dispatches, (disp) => disp.questionnaire_id === questionnaire.id);
          if (indx >= 0) {
            $scope.dispatches[indx].title = questionnaire.translation.en.title;
            $scope.dispatches[indx].title_fr = questionnaire.translation.fr.title;
          } else {
            $scope.questionnairesForCandidate.push(questionnaire);
          }
        });

        if ($scope.isCrmCandidates && $scope.crmJobCandidate.selected.id !== null) {
          const appliedJobIds = $scope.candidate.jobList.map((element) => element.id).filter((e) => typeof e === 'number');
          const sentJobIds = $scope.dispatches.map((element) => +element.job_id);
          const difference = sentJobIds.filter((e) => appliedJobIds.indexOf(e) === -1);
          if (difference.length > 0) {
            const params = {
              'ids[]': difference,
              get_all: 1,
            };
            api.service_get('jobs', 'job/read-from-id-list', params)
              .then((response) => {
                angular.forEach($scope.dispatches, (questionnaire) => {
                  angular.forEach(response.data, (job) => {
                    if (questionnaire.job_id === job.id) {
                      questionnaire.jobTitleEn = job.translations.filter((e) => e.locale === 'en');
                      questionnaire.jobTitleFr = job.translations.filter((e) => e.locale === 'fr');
                    }
                  });
                });
              });
          }
          angular.forEach($scope.allquestionnaires, (questionnaire) => {
            angular.forEach($scope.dispatches, (disp) => {
              if (disp.questionnaire_id === questionnaire.id && !disp.title) {
                disp.title = questionnaire.translation.en.title;
                disp.title_fr = questionnaire.translation.fr.title;
              }
            });
          });
        }
      }
      if ($scope.selectedCandidates.length > 1) {
        $scope.questionnairesForCandidate = [];
        _.each($scope.filteredQuestionnaireList, (questionnaire) => {
          $scope.questionnairesForCandidate.push(questionnaire);
        });
      }
      $scope.loading = true;
      $scope.loadingdispatches = true;
      $scope.formModel.questionnaire_id.selected = {};
    }

    function getDispatches() {
      if ($scope.selectedCandidates) {
        $scope.dispatches = null;
        $scope.loadingdispatches = false;
        const dispatchedResultsPromise = [];
        const dispatchedResultsArray = [];
        let params = {};
        _.each($scope.selectedCandidates, (cand) => {
          params = {
            load_with: 'questionnaire',
            filter_by_candidate_id: cand.user_id,
          };
          const dispatchedQpromises = api.service_get('toolkit', `questionnaire/dispatched-questionnaires?filter_by_job_id=${$scope.jobId}`, params).then((response) => {
            const res = response.data.data;
            if (res) {
              const data = angular.copy(res.result);
              data.first_name = cand.first_name;
              data.last_name = cand.last_name;
              dispatchedResultsArray.push(data);
            }
          });
          dispatchedResultsPromise.push(dispatchedQpromises);
        });
        $q.all(dispatchedResultsPromise).then(() => {
          $scope.dispatched_results_array = dispatchedResultsArray;
          processDispatchedAndUpdateQuestionaireList(dispatchedResultsArray);
        });
      } else {
        const msgEn = 'Please select a candidate';
        const msgFr = 'Veuillez sélectionner un candidat';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
      }
    }

    function getAllQuestionarries() {
      const promise = api.service_get('toolkit', 'questionnaire/questionnaires', {
        // filter_by_archived: 0,
      });
      promise.then((response) => {
        $scope.allquestionnaires = response.data.data.result;
        $scope.filteredQuestionnaireList = _.filter(response.data.data.result, (quest) => quest.archived === 0);
        getDispatches();
      })
        .catch(() => {
          const msgEn = 'An error has occurred and the list of questionnaires could not be retrieved';
          const msgFr = "Une erreur est survenue et la list des questionnaires n'a pu être récupérée";
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        });
      return promise;
    }

    function switchJob(job) {
      if (job) {
        $scope.jobId = job.id;
        $scope.selectedJob = true;
        cleanPreSelectionQResults();
        getDispatches();
      }
    }

    /**
     * In this function:
     *      get the candidates to splice - those who have already filled the questionnaire
     *      get the candidates to which send a reminder to fill it
     *      get the candidates that needs an update of their questionnaire
     */
    function checkIfQuestionnaireSent(questId) {
      const results = [];
      const candsToSplice = [];
      const candsToSendReminder = [];
      const candsToUpdateQuestionnaire = [];
      _.each($scope.dispatched_results_array, (candDispatches) => {
        _.each(candDispatches, (item) => {
          if (+item.questionnaire_id === +questId) {
            item.first_name = candDispatches.first_name; // not returned
            item.last_name = candDispatches.last_name; // not returned
            if (item.status !== 'complete') {
              if (!utils.expirationAndValidationDate(item.end_time, 0)) {
                candsToSendReminder.push(item);
              } else {
                candsToUpdateQuestionnaire.push(item);
              }
            } else {
              $scope.existingCandidatesQDispatch.push(item);
            }
            candsToSplice.push(item);
          }
        });
      });
      results.candsToSendReminder = candsToSendReminder.length ? _.uniq(candsToSendReminder, 'candidate_id') : candsToSendReminder;
      results.candsToSplice = candsToSplice.length ? _.uniq(candsToSplice, 'candidate_id') : candsToSplice;
      results.candsToUpdateQuestionnaire = candsToUpdateQuestionnaire.length ? _.uniq(candsToUpdateQuestionnaire, 'candidate_id') : candsToUpdateQuestionnaire;
      return results;
    }

    function deleteDispatchedQuestionnarie(disp) {
      let msgEn;
      let msgFr;
      $scope.loadingdispatches = false;
      msgEn = 'Deleting your questionnaire...';
      msgFr = 'Suppression de votre questionnaire en cours ...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const promise = api.service_delete('toolkit', `questionnaire/dispatched-questionnaires/${disp.id}`);
      promise.then(() => {
        const indx = _.findIndex($scope.dispatches, (dispatch) => dispatch.id === disp.id);
        $scope.dispatches.splice(indx);
        getAllQuestionarries();
        msgEn = 'Sucessfully deleted...';
        msgFr = 'Supprimé avec succès ...';
        $rootScope.api_status('alert-success', msgEn, msgFr);
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function deleteQuestionnaireConfirm(disp) {
      let msgFr;
      let msgEn;
      if (disp.status !== 'pending') {
        msgFr = disp.status === 'complete' ? 'Le candidat a déjà rempli le questionnaire' : 'Le candidat a déjà commencé à remplir le questionnaire';
        msgEn = disp.status === 'complete' ? 'The candidate has already completed the questionnaire' : 'The candidate has already began to fill the questionnaire';
      }
      $.confirm({
        title: $scope.out('Êtes-vous sûr de vouloir supprimer ce questionnaire?', 'Are you sure you want to delete the questionnaire?'),
        theme: 'modern',
        content: $scope.out(msgFr, msgEn),
        buttons: {
          Cancel: {
            text: $scope.out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            keys: ['enter', 'shift'],
            action() {

            },
          },
          Ok: {
            text: $scope.out('Oui', 'Yes'),
            btnClass: 'btn btn-primary',
            action() {
              deleteDispatchedQuestionnarie(disp);
            },
          },
        },
      });
    }

    function validateDates() {
      let msgEn;
      let msgFr;
      if (d > $scope.formModel.startDate) {
        msgEn = 'Please enter a valid starting date';
        msgFr = 'Veuillez entrer une date de début valide.';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
        return false;
      }
      if ($scope.formModel.startDate > $scope.formModel.endDate) {
        msgEn = 'The end date must be after the start date';
        msgFr = 'La date de fin doit être postérieure à la date de début.';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
        return false;
      }
      return true;
    }

    function spliceCandidates(candidatesToSplice) {
      const candsToSendPreSelectionQ = angular.copy($scope.selectedCandidates);
      _.each(candidatesToSplice, (cand) => {
        const index = _.findIndex(candsToSendPreSelectionQ, (selectCand) => +cand.candidate_id === +selectCand.user_id);
        if (parseInt(index, 10) >= 0) {
          candsToSendPreSelectionQ.splice(index, 1);
        }
      });
      return candsToSendPreSelectionQ;
    }

    function setResultsPSQCandidatesData(responseData, candidates, action) {
      const date = new Date();
      const now = utils.formatDate(date);
      switch (action) {
        case 'regular_psq':
          _.each(candidates, (cand) => {
            const emailSentSuccess = _.find(responseData.sendEmailSuccess, (item) => +cand.user_id === +item);
            $scope.cand_results_psq.push({
              first_name: cand.first_name,
              last_name: cand.last_name,
              creation_date: now,
              start_date: utils.formatDateWithTime($scope.formModel.startDate, 'HH:mm'),
              end_date: utils.formatDateWithTime($scope.formModel.endDate, 'HH:mm'),
              email_send: !!emailSentSuccess,
              email_type: 'regular_psq',
              status: 'pending',
              photo: cand.photo,
            });
          });
          break;
        case 'reminder_psq':
          _.each(candidates, (cand) => {
            const emailSentSuccess = _.find(responseData.sendEmailSuccess, (item) => +cand.candidate_id === +item);
            $scope.cand_results_psq.push({
              first_name: cand.first_name,
              last_name: cand.last_name,
              creation_date: utils.utcToTimezone(cand.questionnaire.created_at, 'enOrFrWithoutSeconds'),
              start_date: utils.utcToTimezone(cand.start_time, 'enOrFrWithoutSeconds'),
              end_date: utils.utcToTimezone(cand.end_time, 'enOrFrWithoutSeconds'),
              email_send: !!emailSentSuccess,
              email_type: 'reminder_psq',
              status: cand.status,
              photo: cand.photo,
            });
          });
          break;
        case 'no_psq':
          _.each($scope.existingCandidatesQDispatch, (cand) => {
            $scope.cand_results_psq.push({
              first_name: cand.first_name,
              last_name: cand.last_name,
              creation_date: utils.utcToTimezone(cand.questionnaire.created_at, 'enOrFrWithoutSeconds'),
              start_date: utils.utcToTimezone(cand.start_time, 'enOrFrWithoutSeconds'),
              end_date: utils.utcToTimezone(cand.end_time, 'enOrFrWithoutSeconds'),
              email_send: false,
              email_type: 'no_psq',
              status: cand.status,
              photo: cand.photo,
            });
          });
          break;
        default:
                    // no default case
      }
    }

    function openPreSelectionQResults() {
      $scope.openBulkCandidatesResults = true;
    }

    function cleanPreSelectionQResults() {
      $scope.cand_results_psq = [];
      $scope.regular_psq_success_msg = false;
      $scope.regular_email_sent_error_msg = {};
      $scope.regular_email_sent_fail_msg = false;
      $scope.regular_email_sent_success_msg = false;
      $scope.regular_email_sent_fail_and_success_msg = false;
      $scope.reminder_email_sent_error_msg = {};
      $scope.reminder_email_sent_fail_msg = false;
      $scope.reminder_email_sent_success_msg = false;
      $scope.reminder_email_sent_fail_and_success_msg = false;
      $scope.openBulkCandidatesResults = false;
      $scope.existingCandidatesQDispatch = [];
    }

    /*
         *  this function is called when we need to send reminder emails, but only IF
         *      - there is only reminder emails to be sent
         *      - we have created pre-selection-questionnaire(s) successfully
         */
    function sendReminderToFillQuestionnaire(candsToSendReminder, questId) {
      const candIds = _.pluck(candsToSendReminder, 'candidate_id');
      const data = {
        questionnaire_id: +questId,
        candidates_ids: candIds,
      };
      if ($scope.jobId) data.job_id = $scope.jobId;
      api.toolkit_batch('questionnaire/dispatched-questionnaires/questionnaire-reminder', data, 'POST').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          const message = _.find(res.email_message, (v) => typeof v === 'string');
          const sentEmailResult = utils.sentAutoEmailStatus(message, res.email_sent);
          // if general send_email error msg to show
          if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
            $scope.reminder_email_sent_error_msg = {
              en: sentEmailResult.msgEn,
              fr: sentEmailResult.msgFr,
              message,
            };
          } else if (message === 'automated_messages_done') {
            if (sentEmailResult.sendEmailSuccess.length && !sentEmailResult.sendEmailfail.length) {
              $scope.reminder_email_sent_success_msg = true;
            } else if (!sentEmailResult.sendEmailSuccess.length) {
              $scope.reminder_email_sent_fail_msg = true;
            } else {
              // this case is when we have both success && fail msgs for send_email
              $scope.reminder_email_sent_fail_and_success_msg = true;
            }
          }
          // we set results for this batch of candidates
          setResultsPSQCandidatesData(sentEmailResult, candsToSendReminder, 'reminder_psq');
        } else {
          $scope.reminder_email_sent_fail_msg = true;
        }
        $rootScope.closeCurrentAlert('waiting');
        openPreSelectionQResults();
      }).catch(() => {
        $scope.reminder_email_sent_fail_msg = true;
        $rootScope.closeCurrentAlert('waiting');
        openPreSelectionQResults();
      });
    }

    function sendQuestionnaire(questId, candsToSendPreSelectQ, candsToSendReminder, candsToUpdateQuestionnaire) {
      let msgEn;
      let msgFr;
      let data;
      $scope.formModel.questionnaire_id.selected = {};
      // if we have update questionnaires to do, we add these on candsToSendPreSelectQ array
      if (candsToUpdateQuestionnaire.length) {
        _.each(candsToUpdateQuestionnaire, (cand) => {
          const copyCand = angular.copy(cand);
          copyCand.user_id = cand.candidate_id;
          copyCand.existing_q_id = cand.id;
          candsToSendPreSelectQ.push(copyCand);
        });
      }

      // if we have some candidates that have completed the questionnaire, we first add them into result
      if ($scope.existingCandidatesQDispatch.length) {
        setResultsPSQCandidatesData([], [], 'no_psq');
      }

      // no questionnaire to create case
      if (!candsToSendPreSelectQ.length) {
        if (candsToSendReminder.length) {
          msgEn = 'Sending your request...';
          msgFr = 'Envoi de la requête en cours ...';
          $rootScope.api_status('waiting', msgEn, msgFr);
          sendReminderToFillQuestionnaire(candsToSendReminder, questId);
          return;
        }
        // if we get there, we have neither new questionnaire nor reminder to send, so all selected candidates filled their questionnaires
        if ($scope.selectedCandidates.length > 1) {
          msgEn = 'The selected candidates have already filled this questionnaire';
          msgFr = 'Les candidats sélectionnés ont déjà rempli ce questionnaire.';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }

        return;
      }

      msgEn = 'Sending your questionnaire...';
      msgFr = 'Envoi de votre questionnaire en cours ...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      let candidates = candsToSendPreSelectQ;
      data = null;
      const tempData = {

        start_time: utils.datetimeToUTC($scope.formModel.startDate, 'formatted'),
        end_time: utils.datetimeToUTC($scope.formModel.endDate, 'formatted'),
        questionnaire_id: questId,
        status: 'pending',
      };

      if ($scope.jobId) tempData.job_id = $scope.jobId;

      // setting data and query depending of number of candidates
      if (candidates.length === 1) {
        tempData.candidate_id = +candidates[0].user_id;
        tempData.language = $rootScope.language;
        data = tempData;
        $scope.sendQuestionnairePromise = api.service_post('toolkit', 'questionnaire/dispatched-questionnaires', data);
      } else if (candidates.length > 1) {
        data = [];
        _.each(candidates, (cand) => {
          const obj = angular.copy(tempData);
          obj.candidate_id = +cand.user_id;
          obj.id = cand.existing_q_id ? cand.existing_q_id : 0;
          data.push(obj);
        });
        $scope.sendQuestionnairePromise = api.toolkit_batch('questionnaire/dispatched-questionnaires/create-or-update-batch', data, 'POST');
      }

      $scope.sendQuestionnairePromise.then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          const message = _.find(res.email_message, (v) => typeof v === 'string');
          const sentEmailResult = utils.sentAutoEmailStatus(message, res.email_sent);

          // if only 1 candidate, we are sure not to send any reminder (already filtered)
          if ($scope.selectedCandidates.length === 1) {
            msgEn = 'Candidate questionnaire has been created successfully!';
            msgFr = 'Le questionnaire du candidat a été créé avec succès !';
            $rootScope.api_status('alert-success', msgEn, msgFr);
            if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
              createTimeout1 = $timeout(() => {
                $rootScope.api_status('alert-danger', sentEmailResult.msgEn, sentEmailResult.msgFr);
              }, 3000);
            } else if (message === 'automated_messages_done') {
              if (sentEmailResult.sendEmailSuccess.length) {
                msgEn = 'An email has been sent successfully to the candidate';
                msgFr = 'Un email a été envoyé au candidat avec succès.';
                createTimeout2 = $timeout(() => {
                  $rootScope.api_status('alert-success', msgEn, msgFr);
                }, 3000);
              } else {
                msgEn = 'An error has occurred, no automated messages could be sent. Please try later or contact Workland for Technical Support.';
                msgFr = 'Une erreur est survenue, aucun message automatisé n\'a pu été envoyé . Veuillez réessayer plus tard ou contacter Workland pour le support technique .';
                createTimeout3 = $timeout(() => {
                  $rootScope.api_status('alert-danger', msgEn, msgFr);
                }, 6000);
              }
            }
            getDispatches();
            return;
          }
          // success msg for questionnaire creation
          $scope.regular_psq_success_msg = true;

          // if general send_email error msg to show
          if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
            $scope.regular_email_sent_error_msg = {
              en: sentEmailResult.msgEn,
              fr: sentEmailResult.msgFr,
              message,
            };
          } else if (message === 'automated_messages_done') {
            if (sentEmailResult.sendEmailSuccess.length && !sentEmailResult.sendEmailfail.length) {
              $scope.regular_email_sent_success_msg = true;
            } else if (!sentEmailResult.sendEmailSuccess.length) {
              $scope.regular_email_sent_fail_msg = true;
            } else {
              // this case is when we have both success && fail msgs for send_email
              $scope.regular_email_sent_fail_and_success_msg = true;
            }
          }
          // after general msg, we set results for all candidates this batch of candidates
          setResultsPSQCandidatesData(sentEmailResult, candsToSendPreSelectQ, 'regular_psq');

          // then if no reminder to send, we display general msgs and results for each candidates
          if (!candsToSendReminder.length) {
            $rootScope.closeCurrentAlert('waiting');
            openPreSelectionQResults();
          } else {
            // when both reminder and new questionnaire
            sendReminderToFillQuestionnaire(candsToSendReminder, questId);
          }
        } else {
          // @revision - creation of questionnaire step failed
          msgEn = `An error has occurred and the questionnaire${candidates.length == 1 ? ' has ' : 's have '}not been created. Please try later or contact Workland for Technical Support`;
          msgFr = `Une erreur est survenue et le${candidates.length == 1 ? " questionnaire n'a pu être créé. " : "s questionnaires n'ont pu être créés. "}Veuillez réessayer plus tard ou contacter Workland pour le support technique.`;
          $rootScope.api_status('alert-danger', msgEn, msgFr, null, null, 5000);
        }
        candidates = [];
      }).catch((response) => {
        // @revision
        if (response.data.status === 'fail') {
          msgEn = 'Questionnaire start date must be later than current date...';
          msgFr = 'La date de début du questionnaire doit être postérieure à la date actuelle ...';
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        } else {
          msgEn = 'An error has occurred, please try later or contact Workland for technical support';
          msgFr = 'Une erreur est survenue . Veuillez réessayer plus tard ou contacter Workland pour le support technique .';
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        }
        candidates = [];
      });
    }

    function preSendQuestionnaire(questionnaireId) {
      // see validation with sagar or manan, something is wrong on template
      const validDate = validateDates();
      if (!validDate) {
        return;
      }
      if (!questionnaireId || questionnaireId < 1) {
        const msgEn = 'Please choose a questionnaire';
        const msgFr = 'Veuillez choisir un questionnaire.';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
        return;
      }

      if ($scope.selectedCandidates.length > 1) {
        const qAlreadySent = checkIfQuestionnaireSent(questionnaireId);
        if (qAlreadySent.candsToSplice.length) {
          const candsToSendPreSelectionQ = spliceCandidates(qAlreadySent.candsToSplice);
          sendQuestionnaire(questionnaireId, candsToSendPreSelectionQ, qAlreadySent.candsToSendReminder, qAlreadySent.candsToUpdateQuestionnaire);
        } else {
          sendQuestionnaire(questionnaireId, $scope.selectedCandidates, [], qAlreadySent.candsToUpdateQuestionnaire);
        }
      } else {
        sendQuestionnaire(questionnaireId, $scope.selectedCandidates, [], []);
      }
    }

    function init() {
      $scope.loading = false;
      $scope.formModel.startDate.setMinutes(d.getMinutes() + 15);
      $scope.formModel.endDate.setDate(d.getDate() + 7);
      $scope.formModel.endDate.setHours(0, 0, 0, 0);
      $scope.questionnairesForCandidate = [];
      $scope.formModel.questionnaire_id.selected = {};
      getAllQuestionarries();
      $scope.minStartDate = d;
      $scope.minEndDate = new Date(
        $scope.minStartDate.getFullYear(),
        $scope.minStartDate.getMonth(),
        $scope.minStartDate.getDate() + 1,
      );
      $scope.initData = true;
      cleanPreSelectionQResults();
    }

    if ($scope.isCrmCandidates) {
      $scope.$watchCollection('selectedCandidates', (selectedCandidates) => {
        if (selectedCandidates.length === 1) {
          $scope.candidate = selectedCandidates[0];
          const defaultOptionAdded = $scope.candidate.jobList.length > 0 ? $scope.candidate.jobList.some((job) => job.id === null) : null;
          if (!defaultOptionAdded) $scope.candidate.jobList.unshift($scope.defaultCrmSelectOption);
          if (!$scope.selectedJob) {
            $scope.crmJobCandidate.selected = $scope.candidate.jobList[$scope.candidate.jobList.length > 1 ? 1 : 0];
            $scope.jobId = $scope.candidate.jobList.length > 1 ? $scope.candidate.jobList[1].id : null;
          }
          init();
        } else if (selectedCandidates.length > 1) {
          const defaultOptionAdded = $scope.commonJobList.length ? $scope.commonJobList.some((job) => job.id === null) : null;
          if (!defaultOptionAdded) $scope.commonJobList.unshift($scope.defaultCrmSelectOption);
          $scope.crmJobCandidate.selected = $scope.commonJobList[$scope.commonJobList.length > 1 ? 1 : 0];
          $scope.jobId = $scope.commonJobList.length > 1 ? $scope.commonJobList[1].id : null;
          init();
        } else {
          $scope.crmJobCandidate.selected = '';
          $scope.selectedCandidates = [];
        }
      });
    } else {
      $scope.$watch('selectedCandidatesList', () => {
        if ($scope.selectedCandidates && $scope.first_init) {
          if (!$scope.firstInitTimeout) {
            init();
          } else {
            $scope.firstInitTimeout = $timeout(() => {
              $scope.first_init = false;
            }, 3000);
          }
          return;
        }
        /**
        * If already on the pre-selection module:
        * this prevent init to be called each time we change the selection of candidates
        * we wait 2 seconds then consider that the user has selected all candidates he wanted
        */
        if (!$scope.first_init) {
          $scope.loading = false;
          if ($scope.timeoutPromise) {
            $timeout.cancel($scope.timeoutPromise);
          }
          $scope.timeoutPromise = $timeout(() => {
            init();
          }, 2000);
        }

        if ($scope.firstInitTimeout) {
          $timeout.cancel($scope.firstInitTimeout);
          $scope.firstInitTimeout = null;
        }
      });
    }
    scope = {
      openDatePicker,
      sendQuestionnaire,
      preSendQuestionnaire,
      deleteQuestionnaireConfirm,
      switchJob,
    };
    angular.extend($scope, scope);

    $scope.$on('$destroy', () => {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
      $timeout.cancel(createTimeout3);
    });
  }
  IsedSendQuestionnaireModuleCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', '_', '$timeout', '$q'];
  angular.module('atlas')
    .directive('isedSendQuestionnairesModule', () => ({
      scope: {
        candidate: '=',
        bulk: '=',
        selectedCandidates: '=',
        selectedCandidatesList: '@',
        jobId: '@',
        filterName: '@',
        questionnaires: '=',
        commonJobList: '=?',
        isCrmCandidates: '=',
      },
      controller: IsedSendQuestionnaireModuleCtrl,
      templateUrl: './employer-profile/ised/questionnaires/ised-send-questionnaires-module.template.html',
    }));
}(angular));
