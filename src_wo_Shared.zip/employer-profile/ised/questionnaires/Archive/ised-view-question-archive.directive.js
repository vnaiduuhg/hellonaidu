( function ( angular ) {
    'use strict';

    angular.module( 'atlas' )
    .directive( 'isedViewQuestionArchive', function ( ) {

		return {
		    scope: {
		    },
		    bindToController: {
                question: '=',
                completeQuestion: '=?',
                label: '=',
		    },
		    controller: IsedViewQuestionArchiveController,
		    controllerAs: 'vm',
		    templateUrl: './employer-profile/ised/questionnaires/Archive/ised-view-question-archive.template.html'
		};
    } );

    IsedViewQuestionArchiveController.$inject = ['$scope', '$rootScope', 'utils', '_'];

    function IsedViewQuestionArchiveController( $scope, $rootScope, utils, _ ) {
        var vm = this;
        var vmExtend = {
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: utils.out,
            range: _.range
        };
        angular.extend( vm, vmExtend );

        function setConditionsTitle(question) {
            _.each(question.conditions, function(q) {
                const choice = _.find(question.choices, function(c) {
                    return c.id == q.choice_condition_id;
                });
                q.translation = choice.translation;
            });
        }

        (() => {
            if(vm.question){
                vm.question.extra ={};
                vm.question.conditions = vm.completeQuestion?.question_branches ?? [];
                if(vm.question.conditions && vm.question.type == 'mc-ss') {
                    setConditionsTitle(vm.question);
                }
            }
        })();

        $scope.$watch( 'vm.question', function ( nVal ) {
            if ( nVal.type === 'scale' ) {
                vm.question.extra.slider = {
                    index: Math.floor( vm.question.scale_range / 2 ),
                    options: {
                        floor: 1,
                        ceil: vm.question.scale_range,
                        showTicks: true,
                        showTicksValues: true
                    }
                };
            }
        });
    }

} )( angular );