(function (angular, jsPDF) {
    'use strict';
    angular.module('atlas')
        .directive('isedQuestionnairesArchive', function () {

            return {
                scope: {},
                controller: IsedQuestionnairesArchiveController,
                templateUrl: './employer-profile/ised/questionnaires/Archive/ised-questionnaires-archive.template.html'
            };
        });

    IsedQuestionnairesArchiveController.$inject = ['$scope', '$rootScope', 'api', 'utils', '_', 'worklandLocalize', '$filter', '$timeout'];

    function IsedQuestionnairesArchiveController($scope, $rootScope, api, utils, _, worklandLocalize, $filter, $timeout) {
        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            language: utils.language,
            adminAccess: $rootScope.currentUser.permissions.isAdmin,
            questionnaires: null,
            questionnairesList: [],
            loadingQuestionnaires: true,
            filteringQuestionnaire: false,
            search: {
                keyword: ''
            },
            searchTimeout: null,
            displayQuestionnaire:displayQuestionnaire,
            archivedQuestionnairesQueryFail: false
        };
        angular.extend($scope, scope);

        init();

        function init() {
            loadQuestionnaires();
        }

        $scope.keywordQuestionnairesQuery = (searchedString) => {
            $scope.questionnairesList = [];
            $scope.filteringQuestionnaire = true;
            if ($scope.searchTimeout) {
                $timeout.cancel($scope.searchTimeout);
            }
            $scope.searchTimeout = $timeout(() => {
                const regExp = new RegExp(searchedString, i);
                const newList = _.filter($scope.questionnaires, (questionnaire) => regExp.test(questionnaire.translation.fr.title) || regExp.test(questionnaire.translation.en.title))
                $scope.questionnairesList = newList
                $scope.filteringQuestionnaire = false;
            }, 800);
        }

        $scope.clearQuestionnairesListSearch = () => {
            $scope.search.keyword = '';
            $scope.questionnairesList = angular.copy($scope.questionnaires);
            $scope.filteringQuestionnaire = false;
        }

        function displayQuestionnaire(pos) {
            $scope.archivedQuestionnairesQueryFail = false;
            $scope.questionnaireAttachedToJob = null;
            $scope.displayedQuestionnaire = $scope.questionnaires[pos];
            $scope.questionnaireData = $scope.displayedQuestionnaire;
            $scope.questionnaireEditFormModel = angular.copy($scope.displayedQuestionnaire);
            // get the data for selected questionnarie
            if (!$scope.displayedQuestionnaire.questions) {
                api.service_get('toolkit', 'questionnaire/questionnaires/' + $scope.questionnaireData.id,
                    {
                        'load_with': 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;',
                        'sort_by':'questionnaire_questions:rank'
                    }).then(function (response) {
                        const res = response.data;
                        if(res.status == 'success') {
                            $scope.displayedQuestionnaire.questions = response.data.data.result.questionnaire_questions;
                            prepareQuestionnaire($scope.displayedQuestionnaire.questions);
                        }
                        else {
                            $scope.archivedQuestionnairesQueryFail = true;
                            showQuestionnairesArchiveErrorMsg('load_with_data');
                        }
                    }).catch(function (error) {
                        $scope.archivedQuestionnairesQueryFail = true;
                        showQuestionnairesArchiveErrorMsg('load_with_data');
                    });
            } else {
                prepareQuestionnaire($scope.displayedQuestionnaire.questions);
            }
        }

        function prepareQuestionnaire(questions) {
            var sortable = [];
            for (var i = 0; i < questions.length; i++) {
                if (+questions[i].followup) {
                    continue;
                }
                var bundle = {
                    question: questions[i],
                    index: i,
                    followups: questions[i].question_branches
                };
                if (questions[i].question_branches && questions[i].question_branches.length) {
                    _.each(questions[i].question_branches, function (cond) {
                        if (cond.followup_ref) {
                            var indx = _.findIndex(questions, function (quest) {
                                return cond.followup_ref === quest.id;
                            });
                            if (indx >= 0) {
                                bundle.followups.push(questions[indx]);
                            }
                        }
                    });
                }
                sortable.push(bundle);
            }
            $scope.sortable = sortable;
        }

        function loadQuestionnaires() {
            $scope.archivedQuestionnairesQueryFail = false;
            var promise = api.service_get('toolkit', 'questionnaire/questionnaires', {'filter_by_archived':1});
            promise.then(function (response) {
                const res = response.data;
                if(res.status == 'success') {
                    $scope.questionnaires = $filter('orderBy')(response.data.data.result, 'translation.en.title');
                    $scope.questionnairesList = angular.copy($scope.questionnaires);
                }
                else {
                    $scope.archivedQuestionnairesQueryFail = true;
                    showQuestionnairesArchiveErrorMsg('list');
                }
                $scope.loadingQuestionnaires = false;
            }).catch(function (response) {
                $scope.archivedQuestionnairesQueryFail = true;
                showQuestionnairesArchiveErrorMsg('list');
                $scope.loadingQuestionnaires = false;
            });
            return promise;
        }

        function showQuestionnairesArchiveErrorMsg(action) {
            var msg = {
                en: "An error has occurred ",
                fr: "Une erreur est survenue "
            }
            switch(action) {
                case 'list':
                    msg.en = msg.en + "and the archived questionnaires could not be retrieved";
                    msg.fr = msg.fr + "et les questionnaires archivés n'ont pas pu être récupérés";
                    break;
                case 'load_with_data':
                    msg.en = msg.en + "and the questionnaire data could not be retrieved";
                    msg.fr = msg.fr + "et les données du questionnaire n'ont pas pu être récupérées";
                    break;
                default:
            }
            $rootScope.api_status('alert-danger', msg.en, msg.fr);
        }
    }

})(angular, jsPDF);
