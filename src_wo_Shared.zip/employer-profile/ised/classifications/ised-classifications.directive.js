( function ( angular ) {
    'use strict';
    angular.module( 'atlas' )
	    .directive( 'isedClassifications', function ( ) {
        return {
          scope: {},
          bindToController: {
            classificationType: '=type',
            close: '&',
            sectionsCtrl: '=',
            section: '='
          },
          controller: IsedClassificationsController,
          controllerAs: 'vm',
          templateUrl: './employer-profile/ised/classifications/ised-classifications.template.html'
        };
	    } );

    IsedClassificationsController.$inject = ['$scope', '$rootScope', 'api', 'utils', '$uibModal', 'Event', '_'];

    function IsedClassificationsController( $scope, $rootScope, api, utils, $uibModal, Event, _) {
            
        var vm = this;        
        var vmExtend = {
            isAdmin: $rootScope.currentUser.permissions.isAdmin,
            out: utils.out,
            sectionForm: {},
            subsectionForm: {},
            createNewSection: createNewSection,
            createNewSubsection: createNewSubsection
        };
        angular.extend( vm, vmExtend );

        function createNewSection() {
            var msgEn = "Creating new section...";
            var msgFr = "Créer une nouvelle section...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var data = {
                parent_category_id: 0,
                en:{'name': vm.sectionForm.name},
                fr:{'name': vm.sectionForm.name_fr}
            };
            api.service_post('toolkit',  'questionnaire/categories', data ).then( function ( response ) {
                loadSections();
                vm.sectionForm = {};
                vm.createSectionForm.$setPristine();
                vm.close();
                var msgEn = "Sucessfully created...";
                var msgFr = "Créé avec succès...";
                $rootScope.api_status('alert-success', msgEn, msgFr);
            } ).catch( function () {
            $rootScope.api_status('alert-danger');
            } );
        }

        function createNewSubsection() {
            var msgEn = "Creating new section...";
            var msgFr = "Créer une nouvelle section...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var data = {
                parent_category_id: vm.section.id,
                en:{'name': vm.subsectionForm.name},
                fr:{'name': vm.subsectionForm.name_fr}
            };
            api.service_post('toolkit',  'questionnaire/categories',data).then( function ( response ) {
                loadSubsections(vm.section);
                vm.subsectionForm = {};
                vm.createSubsectionForm.$setPristine();
                vm.close();
                var msgEn = "Sucessfully created...";
                var msgFr = "Créé avec succès...";
                $rootScope.api_status('alert-success', msgEn, msgFr);
            } ).catch( function () {
                $rootScope.api_status('alert-danger');
            } );
        }

        function loadSections() {
            var promise = api.service_get('toolkit',  'questionnaire/categories', {'filter_by_parent_category_id':0} );
            promise.then( function ( response ) {
                vm.sectionsCtrl.sections = response.data.data.result;
            } ).catch( function () {
                $rootScope.api_status('alert-danger');
            } );
        }
        
        function loadSubsections(section) {
            var promise = api.service_get('toolkit',  'questionnaire/categories', {'filter_by_parent_category_id':section.id} );
            promise.then( function ( response ) {
                vm.sectionsCtrl.subsections = response.data.data.result;
            } ).catch( function () {
                $rootScope.api_status('alert-danger');
            } );
        }
    }

} )( angular );