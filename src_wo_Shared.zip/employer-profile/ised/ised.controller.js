(function (angular) {
    'use strict';

    angular.module('atlas')
            .controller('isedController', IsedController);

    IsedController.$inject = ['$scope', '_', 'utils', 'worklandLocalize', 'MetaTagsService', '$state'];

    function IsedController($scope, _, utils, worklandLocalize, MetaTagsService, $state) {

        MetaTagsService.getMetatags($state.current.name);
        var deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on("$destroy", function() {
            deregisterFns.forEach(function(deregisterFn) {
                deregisterFn();
            });
        });
        
        $scope.tabs = {
            questionnaires: true,
            questions: false,
            archive: false
        };

        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            _: _,
            selectTab: selectTab
        };
        angular.extend($scope, scope);

        function selectTab(tab) {
            _.each($scope.tabs, function (v, k) {
                $scope.tabs[k] = false;
            });
            $scope.tabs[tab] = true;
        }
    }
})(angular);