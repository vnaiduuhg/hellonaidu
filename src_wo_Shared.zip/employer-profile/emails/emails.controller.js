(function (angular) {

    'use strict';
    var app = angular.module('atlas')
            .controller('EmailController', EmailController);
    EmailController.$inject = [
        '$scope',
        '$rootScope',
        'api',
        'utils',
        'MetaTagsService',
        '$state'];

    function EmailController(
            $scope,
            $rootScope,
            api,
            utils,
            MetaTagsService,
            $state) {


        MetaTagsService.getMetatags($state.current.name);
        var deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on("$destroy", function () {
            deregisterFns.forEach(function (deregisterFn) {
                deregisterFn();
            });
        });

        var scope = {
            out: utils.out,
            currentTab: {},
            currentSubTab: {},
            openTab: openTab,
            sentTab: sentTab,
            getUserPreference: getUserPreference,
            user: {token: '', account_id: '', status: '', check: false},
            preferenceError: false,
        };

        angular.extend($scope, scope);

        init();

        function init() {
            $scope.sideTabs = [
                {nameEn: "Compose Email", nameFr: "Écrire un courriel", icon: "fa-plus-circle", type: "compose"},
                {nameEn: "Inbox", nameFr: "Boîte de réception", icon: "fa-inbox", type: "inbox"},
                {nameEn: "Sent", nameFr: "Envoyé", icon: "fa-paper-plane", type: "sent"},
                {nameEn: "Trash", nameFr: "Corbeille", icon: "fa-trash", type: "trash"},
                {nameEn: "Spam", nameFr: "Pourriels", icon: "fa-exclamation-circle", type: "spam"},
                {nameEn: "Email Templates", nameFr: "Modèles de messages", icon: "fa-file-text", type: "template", subTabs: [
                        {nameEn: "My Templates", nameFr: "Mes modèles", type: "myTemplate"},
                        {nameEn: "Create Template", nameFr: "Créer un modèle", type: "createTemplate"}
                    ]
                },
                {nameEn: "Signature", nameFr: "Signature", icon: "fa-pencil", type: "signature"},
                {nameEn: "Category", nameFr: "Catégorie", icon: "fa-list-ul", type: "category"}
            ];
            $scope.currentTab.active = (utils.getUrlParam('body') && utils.getUrlParam('subject') ) ? $scope.sideTabs[0].type : $scope.sideTabs[1].type;

            $scope.availableKeys = "";
            $scope.userKeys = [{id: 1, key: "nylas_email_regular"}];
            getUserPreference();
        }

        function openTab(tab, subTab) {
            $scope.currentTab.active = tab.type;
            if (tab.subTabs && !subTab) {
                var subTab = tab.subTabs[0];
            }
            if (subTab) {
                $scope.currentSubTab.active = subTab.type;
            }
            else {
                $scope.currentSubTab.active = {};
            }
        }

        function  sentTab() {
            $scope.sentTab.type = "sent";
            openTab($scope.sentTab);
        }

        function getUserPreference() {
            $scope.preferenceError = false;
            var promise = api.service_get('shared', 'preference/preferences');
            promise.then(function (response) {
                $scope.status = response.data.status;
                if ($scope.status === "success") {
                    $scope.availableKeys = true;
                    angular.forEach(response.data.data.result.user, function (userPref) {
                        if (userPref.key == $scope.userKeys[0].key) {
                            $scope.userKeys[0].value = userPref.value;
                            $scope.userKeys[0].email_type = "regular";
                            $scope.userKeys[0].email_owner = "user";
                            getNylasDetails($scope.userKeys[0]);
                        }
                    });
                    $scope.user.check = true;

                    if(response.data.data.result.user.length == 0){
                        $scope.preferenceError = true;
                        $scope.availableKeys = "empty";
                        var msgEn = "Your preferences are not working. Please report this issue to our Support Team.";
                        var msgFr = "Vos préférences ne fonctionnent pas. Veuillez signaler ce problème à notre équipe d'assistance.";
                        $rootScope.api_status('alert-danger', msgEn, msgFr);
                    }
                }
            }).catch(function (error) {
                $scope.user.check = true;
                $scope.preferenceError = true;
                $scope.availableKeys = "empty";
                var msgEn = "Your preferences are not working. Please report this issue to our Support Team.";
                var msgFr = "Vos préférences ne fonctionnent pas. Veuillez signaler ce problème à notre équipe d'assistance.";
                $rootScope.api_status('alert-danger', msgEn, msgFr);

            });
        }

        //NYLAS sync

        function getNylasDetails(user) {
            if(!user.value){
                $scope.user.check = true;
                return;
            }
            $scope.user.check = false;
            var data = {email_address: user.value};
            var promise = api.service_post('toolkit', 'mailer/nylas/account-info', data);
            promise.then(function (response) {
                if (response.data.status === "success") {
                    var account = response.data.data.account_info;
                    $scope.user.token = account.access_token;
                    $scope.user.account_id = account.account_id;
                    $scope.user.status = account.billing_status;
                    $scope.user.email = account.email_address;
                    $scope.user.synced = account.sync_status;
                    $scope.user.active = null;
                    angular.forEach(account.sync_types, function (syncType) {
                        if (syncType.email_type == user.email_type) {
                            $scope.user.active = !!syncType.active
                        }
                    });
                    $scope.nylasConfig = {
                        synced: $scope.user.status == "paid" && $scope.user.synced && $scope.user.active == true,
                        token: $scope.user.token
                    };
                }
                $scope.user.check = true;
            }).catch(function (error) {
                $scope.user.check = true;
            });
        }
    }
})(angular);