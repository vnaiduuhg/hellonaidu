(function (angular) {
  function EmailComposerCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    api,
    $uibModal,
    $filter,
    $q,
    storageService,
    Event,
  ) {
    const vm = this;
    let vmExtend = {
      out: utils.out,
      strings: worklandLocalize.strings,
      error: {},
      emailFormat: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
      attachedDocName: [],
      attachedDocId: [],
      awsAttachedFiles: [],
      attachedDoc: {},
      attachedDocs: [],
      userSignature: {},
      attachedSignaturesCount: 0,
      attachedToMessageSignatures: [],
      totalSizeOfAttachements: 0,
      crmJobCandidate: { selected: {} },
      userEmailToUse: { selected: {} },
      defaultCrmSelectOption: {
        id: null,
        translations: [{ title: 'No job' }, { title: 'Aucun poste' }],
      },
      userId: $rootScope.currentUser.user.id,
      filesToAddToEmail: [],
      currentLanguage: $rootScope.language,
      userData: {},
    };
    angular.extend(vm, vmExtend);

    let msgEn;
    let msgFr;
    let titleEn;
    let titleFr;

    vm.tagHandler = function (tag) {
      return null;
    };

    $scope.updateModel = () => {
      vm.email.message = vm.email.message;
    };

    function attachSignature(signature) {
      let wrapperDiv;
      if (signature.signatureId) {
        wrapperDiv = new CKEDITOR.dom.element('div');
        wrapperDiv.setAttribute('id', `signature-${signature.id}`);
        wrapperDiv.setHtml(signature.body);
        vm.email.message = vm.email.message
          ? vm.email.message + wrapperDiv.getOuterHtml()
          :  "<p>&nbsp;</p>" + wrapperDiv.getOuterHtml();
        vm.attachedSignaturesCount += 1;
        if (!vm.attachedToMessageSignatures.includes(wrapperDiv.getOuterHtml())) vm.attachedToMessageSignatures.push(wrapperDiv.getOuterHtml());
      } else {
        const signatureDiv = CKEDITOR.instances['message-body-fr-id'].document.getById(`signature-${signature.id}`);
        if (signatureDiv) signatureDiv.remove();
        Event.broadcast('ckeditor.manualChange');
        vm.attachedSignaturesCount -= 1;
        for (let i = 0; i < vm.attachedToMessageSignatures.length; i += 1) {
          const myRegexp = /signature-(\d)/;
          const match = vm.attachedToMessageSignatures[i].match(myRegexp);
          const result = match[1];
          if (result == signature.id) {
            vm.attachedToMessageSignatures.splice(i, 1);
          }
        }
      }
    }

    function openSignaturesModal() {
      /* if signature is on the list but the div is empty or doesn't exist: we remove the div from the body, the signature from the attached list and unselect the signature */
      vm.userSignatures.forEach(signature => {
        signature.translations.forEach(t => {
          const divId = new RegExp(`signature-${t.id}`);
          const signatureIndex = vm.attachedToMessageSignatures.findIndex(div => divId.test(div));
          if (signatureIndex > -1) {
            const div = CKEDITOR.instances['message-body-fr-id'].document.getById(`signature-${t.id}`);
            if (div && (!div.$.innerHTML || div.$.innerHTML === "<br>")) {
              div.remove();
              vm.attachedToMessageSignatures.splice(vm.attachedToMessageSignatures, 1);
              t.signatureId = false;
            } else if (!div) {
              vm.attachedToMessageSignatures.splice(vm.attachedToMessageSignatures, 1);
              t.signatureId = false;
            }
          }
        });
      });

      const signatureModal = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/emails/email-composer/signatures-modal.template.html',
        scope: $scope,
        size: 'md',
        windowClass: 'show z-index-999',
      });
      signatureModal.result.then((signature) => {
        if (signature) {
          attachSignature(signature);
        }
      });
    }

    function shareJobByEmail() {
      if (utils.getUrlParam('subject')) {
        vm.email.subject = utils.getUrlParam('subject');
      }
      if (utils.getUrlParam('body')) {
        vm.email.message = utils.getUrlParam('body');
      }
    }

    function fetchVariables(labels) {      
      let data = {};
      if (labels) {
        data = { 'label_ids[]': labels };
      }
      const promise = api.service_get('variables', 'variables', data);
      promise.then((response) => {
        if (response.status === 200) {
          vm.variables = response.data;
        }
      }).catch(() => {
        msgEn = 'Sorry, there was an error while fetching variables.';
        msgFr = "Désolé, une erreur s'est produite lors de la récupération des variables .";
        $rootScope.api_status('alert-danger', msgEn, msgFr);
        vm.userSignature = {};
      });
    }

    function fetchVariablesLabels() {
      let labelIds = [];
      api.service_get('variables', 'variables/labels').then((response) => {
        if (response.status === 200) {
          if (vm.mode === 'crm-leads') {
            labelIds = response.data.filter((label) => label.name === 'crm-lead').map((elt) => elt.id);
          } else {
            labelIds = response.data.filter((label) => label.name === 'candidate').map((elt) => elt.id);
          }
        }
      }).finally(() => {
        fetchVariables(labelIds);
      });
    }

    function fetchEmailTemplates() {
      vm.emailTemplates = null;      
      const data = {
        sort_by: 'name',
        locale: $rootScope.language,
      };
      const accountId = $rootScope.currentUser.account.id;
      const promise = api.service_get('messaging', `accounts/${accountId}/email-templates`, data);
      promise
        .then((response) => {
          if (response.status === 200) {
            vm.emailTemplates = response.data;
            angular.forEach(vm.emailTemplates, (template) => {
              angular.forEach(template.translations, (translation) => {
                if (translation.locale === 'en') {
                  template.nameEn = translation.name;
                  template.subjectEn = translation.subject;
                  template.bodyEn = translation.body;
                }
                if (translation.locale === 'fr') {
                  template.nameFr = translation.name;
                  template.subjectFr = translation.subject;
                  template.bodyFr = translation.body;
                }
              });
            });
          }
        }).catch(() => {
          $scope.emailTemplates = [];
          msgEn = 'Sorry, there was an error while fetching email templates.';
          msgFr = "Désolé, une erreur s'est produite lors de la récupération des modèles de messages .";
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        });
    }

    function fetchSignature() {      
      const userId = $rootScope.currentUser.user.id;
      const promise = api.service_get('messaging', `users/${userId}/email-signatures`);
      promise.then((response) => {
        if (response.status === 200 && response.data.length > 0) {
          vm.userSignatures = response.data;
        }
      }).catch(() => {
        vm.userSignatures = [];
        msgEn = 'Sorry, there was an error while fetching your signatures.';
        msgFr = "Désolé, une erreur s'est produite lors de la récupération de vos signatures .";
        $rootScope.api_status('alert-danger', msgEn, msgFr);
      });
    }

    function setUserDataValues(account) {
      vm.userEmailToUse.selected = account;      
      vm.userData.email = account.email;
      vm.userData.emailName = account.name;
      vm.userData.synced = account.status;
      vm.userData.provider = account.provider;
      vm.userData.emailId = account.id;
      switch(account.provider) {
        case 'nylas':
          vm.userData.nylas_account_id = account.id;
          break;
        case 'aws':
          vm.userData.aws_email_identity_id = account.id;
          break;
        case 'email_engine':
          vm.userData.email_engine_account_id = account.id;
          break;
        //no default
      }     
    }

    // NYLAS sync
    function switchEmail(email) {
      if (email.id !== vm.userData.emailId) {
        if (storageService.getItem('sync_email_type')) storageService.removeItem('sync_email_type');
        // when user selects a new email, his previously attached docs have to be removed
        // from the previous nylas account. Only vm.fileToBeAttached (candidate docs that are shared by email)
        // can be re-attached to a current account - it happens by calling $watch; docs uploaded by user from PC
        // or Atlas drive have to be re-attached by the user manually.        
        if (vm.attachedDocId.length > 0) {
          const deletePromises = [];
          angular.forEach(vm.attachedDocId, (fileId) => {
            const deletePromise = api.service_delete('messaging', `nylas/regular-emails/attachments/${fileId}`, {
              nylas_account_id: vm.userData.nylas_account_id,
            });
            deletePromises.push(deletePromise);
          });
          $q.all(deletePromises).then(() => {
            resetAttachments();
          });
        }        
        if(vm.awsAttachedFiles.length > 0 && email.provider === 'nylas') {
          resetAttachments();
        }
        if (vm.email?.file?.$error) {
          vm.email.file.$error = '';
          vm.email.file = null;
        }
        angular.forEach(vm.userEmails, (account) => {
          if (account.id === email.id) {              
            setUserDataValues(account);
          }
        });        
      }
    }

    function translateNylasStatus(account) {
      const msg = {};
      switch (account.status) {
        case 'connected':
          msg.fr = 'Actif';
          msg.en = 'Active';
          break;
        case 'Success':
          msg.fr = 'Actif';
          msg.en = 'Active';
          break;
        case 'running':
          msg.fr = 'Actif';
          msg.en = 'Active';
          break;
        case 'initializing':
          msg.fr = 'Actif';
          msg.en = 'Active';
          break;
        case 'downloading':
          msg.fr = 'Actif';
          msg.en = 'Active';
          break;
        case 'partial':
          msg.fr = 'Partiellement actif';
          msg.en = 'Partially active';
          break;
        case 'stopped':
          msg.fr = 'Inactif';
          msg.en = 'Inactive';
          break;
        case 'invalid_credentials':
          msg.fr = "Informations d'identification invalide";
          msg.en = 'Invalid credentials';
          break;
        case 'exception':
          msg.fr = 'Échec de la synchronisation';
          msg.en = 'Synchronization failed';
          break;
        case 'sync_error':
          msg.fr = 'Échec de la synchronisation';
          msg.en = 'Synchronization failed';
          break;
        default:
          msg.fr = 'N/A';
          msg.en = 'N/A';
      }
      return msg;
    }

    function translateProviderName(name) {
      let label = '';
      switch(name) {
        case 'email_engine':
          label = 'Email Engine';
          break;
        case 'aws':
          label = 'Amazon Web Services (AWS)';
          break;
        case 'nylas':
          label = 'Nylas';
          break;
        //no default
      }
      return label;
    }

    function getSyncDetails() {
      vm.checkingSyncedEmails = true;
      vm.loadingErrorMsg = '';
      vm.userEmails = [];
      api.service_get('messaging', 'users/current-user/email-accounts').then((response) => {                
        vm.syncedEmailAccounts = response.data;
        if (response.status === 200) {
          // select regular email as default, if no regular then select automated, if none - show sync
          for (key in vm.syncedEmailAccounts.regular) {
            if (vm.syncedEmailAccounts.regular[key].length) {
              vm.syncedEmailAccounts.regular[key][0].status = vm.syncedEmailAccounts.regular[key][0].sync_state ? vm.syncedEmailAccounts.regular[key][0].sync_state : vm.syncedEmailAccounts.regular[key][0].verification_status;
              if (['running', 'downloading', 'initializing', 'partial', 'Success', 'connected'].includes(vm.syncedEmailAccounts.regular[key][0].status)) {
                vm.syncedEmailAccounts.regular[key][0].emailAccountStatus = translateNylasStatus(vm.syncedEmailAccounts.regular[key][0]);
                vm.syncedEmailAccounts.regular[key][0].account_type = `${key}-regular`;
                vm.syncedEmailAccounts.regular[key][0].provider = key;
                vm.syncedEmailAccounts.regular[key][0].id = vm.syncedEmailAccounts.regular[key][0].id;
                vm.syncedEmailAccounts.regular[key][0].providerLabel = translateProviderName(key);
                vm.userEmails.push(vm.syncedEmailAccounts.regular[key][0]);
              }
            }
          }
          for (key in vm.syncedEmailAccounts.automated) {
            if (vm.syncedEmailAccounts.automated[key].length) {
              vm.syncedEmailAccounts.automated[key][0].status = vm.syncedEmailAccounts.automated[key][0].sync_state ? vm.syncedEmailAccounts.automated[key][0].sync_state : vm.syncedEmailAccounts.automated[key][0].verification_status;
              if (['running', 'downloading', 'initializing', 'partial', 'Success', 'connected'].includes(vm.syncedEmailAccounts.automated[key][0].status)) {
                vm.syncedEmailAccounts.automated[key][0].emailAccountStatus = translateNylasStatus(vm.syncedEmailAccounts.automated[key][0]);
                vm.syncedEmailAccounts.automated[key][0].account_type = `${key}-automated`;
                vm.syncedEmailAccounts.automated[key][0].provider = key;
                vm.syncedEmailAccounts.automated[key][0].id = vm.syncedEmailAccounts.automated[key][0].id;
                vm.syncedEmailAccounts.automated[key][0].providerLabel = translateProviderName(key);
                vm.userEmails.push(vm.syncedEmailAccounts.automated[key][0]);
              }
            }
          }
          if (vm.userEmails.length > 0) {
            const ids = vm.userEmails.map(o => o.id);
            vm.userEmails = vm.userEmails.filter(({id}, index) => !ids.includes(id, index + 1))
            // email selected will be regular default if exists
            const defaultEmail = vm.userEmails.find(email => email.is_default === 1);
            if (defaultEmail) {
              setUserDataValues(defaultEmail);
            } else {
              setUserDataValues(vm.userEmails[0]);
            }
          }
        }
        vm.checkingSyncedEmails = false;
      }).catch(() => {
        vm.checkingSyncedEmails = false;
        vm.userEmails = null;
        vm.loadingErrorMsg = vm.out('Échec de récupération des informations du compte. Veuillez essayer plus tard ou contacter Workland pour un support technique.',
          'Failed to fetch account information. Please try later or contact Workland for technical support');
      });
    }

    function init() {
      if (storageService.getItem('sync_email_type')) storageService.removeItem('sync_email_type');
      vm.currentUserName = `${$rootScope.currentUser.user.first_name} ${$rootScope.currentUser.user.last_name}`;
      vm.email = {};
      getSyncDetails();
      shareJobByEmail();
      fetchVariablesLabels();
      fetchEmailTemplates();
      fetchSignature();
      vm.selectedLanguage = $rootScope.language;
      vm.frenchMode = vm.selectedLanguage === 'fr';

      if (vm.mode === 'crm-leads' || vm.mode === 'crm-candidates') {
        vm.showDiv = true;
      }

      if (vm.mode === 'crm-leads') {
        vm.commonJobList.unshift(vm.defaultCrmSelectOption);
        vm.crmJobCandidate.selected = vm.defaultCrmSelectOption;
      }
    }

    init();

    if (vm.mode === 'crm-candidates') {
      $scope.$watchCollection('vm.selectedCandidates', (selectedCandidates) => {
        if (selectedCandidates.length === 1) {
          const defaultOptionAdded = vm.candidate.jobList.some((job) => job.id === null);
          if (!defaultOptionAdded) vm.candidate.jobList.unshift(vm.defaultCrmSelectOption);
        } else if (selectedCandidates.length > 1) {
          const defaultOptionAdded = vm.commonJobList.some((job) => job.id === null);
          if (!defaultOptionAdded) vm.commonJobList.unshift(vm.defaultCrmSelectOption);
        } else {
          vm.crmJobCandidate.selected = '';
          vm.selectedCandidates = [];
        }
        if (!vm.selectedJob) {
          vm.crmJobCandidate.selected = vm.candidate.jobList[vm.candidate.jobList.length > 1 ? 1 : 0];
          vm.jobId = vm.candidate.jobList.length > 1 ? vm.candidate.jobList[1].id : null;            
        }
      });
    }

    function onTemplateChange() {
      vm.frenchMode = vm.selectedLanguage === 'fr';
      vm.email.subject = vm.frenchMode
        ? vm.selectedTemplate.subjectFr
        : vm.selectedTemplate.subjectEn;
      vm.email.message = (vm.frenchMode
        ? vm.selectedTemplate.bodyFr
        : vm.selectedTemplate.bodyEn)
                + (vm.attachedSignaturesCount > 0 ? vm.attachedToMessageSignatures : '');
    }

    // Change email subject and message when switch between language
    const rootModelListener = $rootScope.$watch('language', () => {
      if (vm.selectedTemplate) {
        vm.selectedLanguage = $rootScope.language;
        onTemplateChange();
      }
    });

    function onLanguageChange() {
      vm.frenchMode = vm.selectedLanguage === 'fr';
      vm.receiverDetails.forEach((rec) => {
        rec.variable.language = vm.selectedLanguage;
      });
      if (vm.selectedTemplate) {
        onTemplateChange();
      }
    }

    function importVariable(variable) {
      vm.email.message = vm.email.message ? `${vm.email.message}{{${variable}}}` : `{{${variable}}}`;
    }

    function createVariableSet(leadOrCandidateId) {
      const userKey = (vm.mode === 'crm-leads') ? 'lead_id' : 'candidate_id';
      const variable = {
        language: vm.selectedLanguage,
        ids: {
          job_id: vm.jobId
            ? parseInt(vm.jobId, 10)
            : '',
          user_id: $rootScope.currentUser.user.id,
        },
        links: {
          login_link: '',
          activation_link: '',
        },
      };
      variable.ids[userKey] = leadOrCandidateId;
      if (vm.jobAccountId) {
        variable.ids.job_account_id = +vm.jobAccountId;
        variable.ids.employer_account_id = +vm.jobAccountId ? +vm.jobAccountId : $rootScope.account_id;
      } else {
        variable.ids.employer_account_id = +vm.employerAccountId ? +vm.employerAccountId : $rootScope.account_id;
      }
      return variable;
    }

    function receiverList() {
      if (vm.selectedCandidates && vm.selectedCandidates.length > 1) {
        _.each(vm.selectedCandidates, (selectedCandidate) => {
          const data = {
            name: `${selectedCandidate.first_name} ${selectedCandidate.last_name}`,
            email: selectedCandidate.email,
          };
          if (selectedCandidate.id) {
            data.variable = createVariableSet(selectedCandidate.id);
          }
          if (selectedCandidate.user_id) {
            data.variable = createVariableSet(selectedCandidate.user_id);
          }
          if (!data.name && selectedCandidate.name) {
            data.name = selectedCandidate.name;
          }
          vm.receiverDetails.push(data);
          if (selectedCandidate.id) {
            vm.receiverIds.push(selectedCandidate.id);
          } else if (selectedCandidate.user_id) {
            vm.receiverIds.push(selectedCandidate.user_id);
          }
        });
      } else if (!vm.isShare) {
        if (vm.candidate) {
          const data = {
            name: vm.candidate.name ? vm.candidate.name : `${vm.candidate.first_name} ${vm.candidate.last_name}`,
            email: vm.candidate.email,
            variable: createVariableSet(vm.mode === 'crm-leads' ? vm.candidate.id : vm.candidate.user_id),
          };
          vm.receiverDetails.push(data);
          vm.mode === 'crm-leads'
            ? vm.receiverIds.push(vm.candidate.id)
            : vm.receiverIds.push(vm.candidate.user_id);
        }
      }
    }

    $scope.$watchCollection('vm.selectedCandidates', () => {
      vm.receiverDetails = [];
      vm.receiverDetailsBcc = [];
      vm.receiverDetailsCc = [];
      vm.receiverIds = [];
      receiverList();
    });

    function switchJob(job) {
      if (job) {
        vm.jobId = job.id;
        vm.jobAccountId = job.id && job.account_id ? job.account_id : null;
        vm.selectedJob = true;
        vm.receiverDetails = [];
        vm.receiverDetailsBcc = [];
        vm.receiverDetailsCc = [];
        vm.receiverIds = [];
        receiverList();
      }
    }

    function handleReceivers() {
      vm.receiverDetailsBcc = [];
      vm.receiverDetailsCc = [];
      let data = {};
      if (!vm.receiverDetails || vm.receiverDetails.length === 0) {
        _.each(vm.email.to, (receiverEmail) => {
          data = {
            name: receiverEmail.trim(),
            email: receiverEmail.trim(),
            variable: createVariableSet(vm.receiverIds.length ? vm.receiverIds : ''),
          };
          vm.receiverDetails.push(data);
        });
      }
      _.each(vm.email.toBcc, (receiverEmail) => {
        data = {
          name: receiverEmail.trim(),
          email: receiverEmail.trim(),
        };
        vm.receiverDetailsBcc.push(data);
      });

      _.each(vm.email.toCc, (receiverEmail) => {
        data = {
          name: receiverEmail.trim(),
          email: receiverEmail.trim(),
        };
        vm.receiverDetailsCc.push(data);
      });
    }

    function resetReceivers() {
      // have to reinitialize, otherwise if you send 2nd email to the same candidate, it fails
      vm.receiverDetails = [];
      vm.receiverIds = [];
      vm.receiverDetailsBcc = [];
      vm.receiverDetailsCc = [];
      vm.selectedTemplate = null;
      receiverList();
    }

    function resetAttachments() {    
      vm.attachedDocName = [];
      vm.attachedDocId = [];
      vm.attachedDoc = {};
      vm.attachedDocs = [];
      vm.awsAttachedFiles = [];
      vm.totalSizeOfAttachements = 0;      
    }

    function resetEmail() {
      vm.email = {};
      resetAttachments();
      vm.attachedSignaturesCount = 0;
      vm.attachedToMessageSignatures = [];                
      if (!vm.selectedCandidates || vm.isShare) {
        vm.sentTab();
      }
    }

    function constructPayload() {
      const formData = new FormData();
      if (vm.userData.provider === 'aws') {
        formData.append('aws_email_identity_id', vm.userData.aws_email_identity_id);
      } else {
        formData.append(`email_engine_account_id`, vm.userData.email_engine_account_id);
      }
      for (let i = 0; i < vm.receiverDetails.length; i++) {
        if (vm.receiverDetails.length > 0) {
          formData.append(`messages[${i}][to][0][name]`, vm.receiverDetails[i].name);
          formData.append(`messages[${i}][to][0][email]`, vm.receiverDetails[i].email);
          angular.forEach(vm.receiverDetails[i].variable, (v, k) => {
            if (k === 'language') {
              formData.append(`messages[${i}][to][0][variable][${k}]`, v);
            } else {  
              Object.keys(v).forEach(key1 => formData.append(`messages[${i}][to][0][variable][${k}][${key1}]`, v[key1]));
            }              
          })
        }
        if (vm.receiverDetailsCc.length > 0) {
          for (let k = 0; k < vm.receiverDetailsCc.length; k++) {
            formData.append(`messages[${i}][cc][${k}][email]`, vm.receiverDetailsCc[k].email);
            formData.append(`messages[${i}][cc][${k}][name]`, vm.receiverDetailsCc[k].name);
          }
        }
        if (vm.receiverDetailsBcc.length > 0) {
          for (let l = 0; l < vm.receiverDetailsBcc.length; l++) {
            formData.append(`messages[${i}][bcc][${l}][name]`, vm.receiverDetailsBcc[l].name);
            formData.append(`messages[${i}][bcc][${l}][email]`, vm.receiverDetailsBcc[l].email);
          }
        }
        formData.append(`messages[${i}][subject]`, vm.email.subject);
        formData.append(`messages[${i}][body]`, vm.email.message);
        if (vm.awsAttachedFiles.length > 0) {
          for (let m = 0; m < vm.awsAttachedFiles.length; m++) {
            angular.forEach(vm.awsAttachedFiles, (value, key) => {
              if (key === m) {
                Object.keys(value).forEach(key2 => formData.append(`messages[${i}][attachments][${m}][${key2}]`, value[key2]));
              }
            });
          }
        }
      }
      return formData;
    }

    function sendEmailWithAwsOrEmailEngine() {      
      if (vm.isFormValid()) {
        handleReceivers();  
        $rootScope.api_status('waiting', 'Sending your email...', 'Envoi de votre courriel...');
        let promise = '';
        const formData = constructPayload();
        if (vm.userData.provider === 'aws') {
          promise = api.messaging_fileupload('aws/regular-emails', formData, 'emailComposer');
        } else {
          promise = api.messaging_fileupload('email-engine/regular-emails', formData, 'emailComposer');
        }
        return promise.then((response) => {
          if (response.status === 200) {
            titleEn = 'Sent';
            titleFr = 'Courriel envoyé';
            msgEn = 'Your email sent successfully.';
            msgFr = 'Votre courriel envoyé avec succès .';
            $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
            resetEmail();
          } else {
            $rootScope.api_status('alert-danger');
          }
          resetReceivers();
        }).catch((error) => {
          //@tocheck unify error codes for file size limit
          switch (error.status) {
            case '400':
              if(error.data === "virus_detected_in_file") {
                msgEn = "Sorry! This file is invalid, please upload a new file";
                msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
              }
              break;
            case '422':
              if (vm.userData.provider === 'aws') {
                msgEn = 'The total size of the message and attachments should not exceed 10Mb';
                msgFr = "La taille totale du message et des pièces jointes ne doit pas dépasser 10 Mo.";
              } else {
                msgEn = 'The total size of the message and attachments should not exceed 25Mb';
                msgFr = "La taille totale du message et des pièces jointes ne doit pas dépasser 25 Mo.";
              }
              break;
            case '403':
              if (vm.userData.provider === 'email_engine') {
                msgEn = 'The total size of the message and attachments should not exceed 25Mb';
                msgFr = "La taille totale du message et des pièces jointes ne doit pas dépasser 25 Mo.";
              }
              break;
            default:
              msgEn = 'Your email could not be sent.';
              msgFr = "Votre courriel n'a pu être envoyé ."; 
          }
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        });
      }
    }

    function sendEmailWithNylas() {
      if (vm.isFormValid()) {
        if (vm.email.file) {
          msgEn = 'Document uploading in progress...';
          msgFr = 'Téléversement de document en cours ...';
          $rootScope.api_status('waiting', msgEn, msgFr);
          vm.triggerSendEmail = true;
        } else {
          handleReceivers();
          vm.triggerSendEmail = false;
          msgEn = 'Sending your email...';
          msgFr = 'Envoi de votre courriel ...';
          $rootScope.api_status('waiting', msgEn, msgFr);
          vm.data = {messages: []};
          angular.forEach(vm.receiverDetails, (recepient) => {
            vm.data.messages.push({
                to: [recepient],
                cc: vm.receiverDetailsCc,
                bcc: vm.receiverDetailsBcc,
                subject: vm.email.subject,
                body: vm.email.message,
                file_ids: vm.attachedDocId ? vm.attachedDocId : [],                
            })
          })
          vm.data.nylas_account_id = vm.userData.nylas_account_id;
          return api.service_post('messaging', 'nylas/regular-emails/send-email', vm.data)
            .then((response) => {
              if (response.data === 'success') {
                titleEn = 'Sent';
                titleFr = 'Courriel envoyé';
                msgEn = 'Your email sent successfully.';
                msgFr = 'Votre courriel envoyé avec succès .';
                $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
                resetEmail();
              } else {
                $rootScope.api_status('alert-danger');
              }
              resetReceivers();
            })
            .catch(() => {
              msgEn = 'Your email could not be sent.';
              msgFr = "Votre courriel n'a pu être envoyé .";
              $rootScope.api_status('alert-danger', msgEn, msgFr);
            });
        }
      }
    }

    function sendEmail() {
      if (vm.userData.provider === 'nylas') {
        return sendEmailWithNylas();
      } else {
        return sendEmailWithAwsOrEmailEngine();
      }
    }

    // upload multiple Email Docs OR upload candidate applications documents from job or crm (cv-module) or from leads (view-doc)
    function uploadEmailDocsWithNylas(type) {      
      const promiseArray = [];

      if (type === 'atlas') {
        angular.forEach(vm.filesToAddToEmail, (atlasFile) => {
          if (atlasFile) {
            vm.email.file = [
              { name: atlasFile.file_name, fileVersion: atlasFile.id },
            ];
          }
          if (vm.email.file.length > 0) {
            vm.data = { };
            vm.data.minio_file_name = atlasFile.file_name;
            vm.data.minio_file_path = `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`;
            vm.data.nylas_account_id = vm.userData.nylas_account_id;
            const promise = api.messaging_fileupload('nylas/regular-emails/attachments', vm.data);
            promiseArray.push(promise);
          }
        });
      } else {
        angular.forEach(vm.fileToBeAttached, (atlasFile) => {
          if (atlasFile) {
            vm.email.file = [
              { name: atlasFile.file_name, fileVersion: atlasFile.id },
            ];
          }
          if (vm.email.file.length > 0) {
            vm.data = { };
            vm.data.minio_file_name = atlasFile.file_name;

            if (vm.fileToBeAttached.leadsDocuments) {
              vm.data.lead_document_id = vm.email.file[0].fileVersion;
              vm.data.minio_file_path = atlasFile.original_file;
            } else if (atlasFile.isSendRequest) {
              vm.data.minio_file_path = atlasFile.original_file;
            } else {
              const candidateUserId = atlasFile.candidate_id;
              vm.data.minio_file_path = `Candidates/${candidateUserId}/${atlasFile.original_file}`;
            }
            vm.data.nylas_account_id = vm.userData.nylas_account_id;
            const promise = api.messaging_fileupload('nylas/regular-emails/attachments', vm.data);
            promiseArray.push(promise);
          }
        });
      }
      $q.all(promiseArray).then((combinedResponse) => {
        for (let i = 0; i < combinedResponse.length; i += 1) {
          vm.response = combinedResponse[i].data[0];
          vm.status = combinedResponse[i].status;
          if (vm.status === 200) {
            vm.totalSizeOfAttachements += vm.response.size;
            if (vm.totalSizeOfAttachements / 1048576 < 25) {
              vm.attachedDocName.push(vm.response.filename);
              vm.attachedDocId.push(
                vm.response.id,
              );
              vm.attachedDoc = {
                id: vm.response.id,
                name: vm.response.filename,
                size: vm.response.size,
              };
              vm.attachedDocs.push(vm.attachedDoc);
              if (vm.triggerSendEmail) {
                sendEmail();
              }
            } else {
              vm.totalSizeOfAttachements -= vm.email.file[0].size;
              vm.triggerSendEmail = false;
              msgEn = 'Sorry! You can send only 25 MBs in total.';
              msgFr = 'Désolé ! Vous pouvez envoyer seulement 25 Mo au total .';
              $rootScope.api_status('alert-danger', msgEn, msgFr);
            }
          } else {
            vm.triggerSendEmail = false;
          }
          vm.email.file = null;
        }
      }).catch((error) => {
        vm.email.file = null;
        if (error.status === 400 && error.data === "virus_detected_in_file") {
          msgEn = "Sorry! A file is invalid, please upload a new file";
          msgFr = "Désolé! Un fichier est invalide, veuillez télécharger un nouveau fichier";
        } else if (error.status === 422 && error.data?.file) {
          msgEn = 'The format or size of one or more files is invalid';
          msgFr = "Le format ou la taille d\'un ou plusieurs fichiers n'est pas valide";
        } else {
          msgEn = 'An error has occurred with documents upload, please try again';
          msgFr = 'Une erreur s\'est produite lors du téléchargement des documents, veuillez réessayer';
        }
        $rootScope.api_status('alert-danger', msgEn, msgFr, "Upload fail", "Échec du téléchargement", 4000);
      });
    }

    $scope.$watch('vm.userData.nylas_account_id', (newValue, oldValue) => {
      if (newValue === oldValue) { return; }
      if (vm.fileToBeAttached && vm.userData.nylas_account_id) {
        uploadEmailDocsWithNylas();
      }
    });    

    function uploadEmailDocsWithAwsOrEmailEngine(type) {
      if (type === 'atlas') {
        vm.duplicates = [];
        angular.forEach(vm.filesToAddToEmail, (atlasFile) => {
          const duplicate = _.find(vm.awsAttachedFiles, (file) => {
            return file.minio_file_path === `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`;
          })
          if (duplicate) vm.duplicates.push(duplicate);          
          if (atlasFile) {
            vm.email.file = [
              { name: atlasFile.file_name, fileVersion: atlasFile.id },
            ];
          }
          if (vm.email.file.length > 0) {
            vm.data = { };
            vm.data.minio_file_name = atlasFile.file_name;
            vm.data.minio_file_path = `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`;
            vm.awsAttachedFiles.push(vm.data);
             angular.forEach(vm.email.file, (file) => {
              vm.attachedDocName.push(file.name);
              vm.attachedDoc = {              
                name: file.name,
              };
              vm.attachedDocs.push(vm.attachedDoc);
            })
          }
        });
      } else {
        angular.forEach(vm.fileToBeAttached, (atlasFile) => {
          if (atlasFile) {
            vm.email.file = [
              { name: atlasFile.file_name, fileVersion: atlasFile.id },
            ];
          }
          if (vm.email.file.length > 0) {
            vm.data = { };
            vm.data.minio_file_name = atlasFile.file_name;
            if (vm.fileToBeAttached.leadsDocuments) {
              vm.data.lead_document_id = vm.email.file[0].fileVersion;
              vm.data.minio_file_path = atlasFile.original_file;
            } else if (atlasFile.isSendRequest) {
              vm.data.minio_file_path = atlasFile.original_file;
            } else {
              const candidateUserId = atlasFile.candidate_id;
              vm.data.minio_file_path = `Candidates/${candidateUserId}/${atlasFile.original_file}`;
            }
            vm.awsAttachedFiles.push(vm.data);
            angular.forEach(vm.email.file, (file) => {
              vm.attachedDocName.push(file.name);
              vm.attachedDoc = {              
                name: file.name,
              };
              vm.attachedDocs.push(vm.attachedDoc);
            })
          }
        });
      }      
    }

    $scope.$watch('vm.userData.aws_email_identity_id', (newValue, oldValue) => {
      if (newValue === oldValue) { return; }
      if (vm.fileToBeAttached && vm.userData.aws_email_identity_id) {
        uploadEmailDocsWithAwsOrEmailEngine();
      }
    });

    $scope.$watch('vm.userData.email_engine_account_id', (newValue, oldValue) => {
      if (newValue === oldValue) { return; }
      if (vm.fileToBeAttached && vm.userData.email_engine_account_id) {
        uploadEmailDocsWithAwsOrEmailEngine();
      }
    });

    function parseEmails(type) {
      vm.error.email = false;
      vm.error.emailBcc = false;
      vm.error.emailCc = false;
      let emailsArray = [];
      if (type === 'bcc') {
        emailsArray = vm.email.toBcc.split(',');
        vm.email.toBcc = emailsArray;
        if (vm.email.toBcc.length === 1 && vm.email.toBcc[0] == '') {
          vm.error.emailBcc = false;          
        } else {
          _.each(vm.email.toBcc, (receiverEmail) => {
            receiverEmail = receiverEmail.trim();
            if (!vm.emailFormat.test(receiverEmail)) {
              vm.error.emailBcc = true;
            }
          });
        }
      } else if (type === 'cc') {
        emailsArray = vm.email.toCc.split(',');
        vm.email.toCc = emailsArray;
        if (vm.email.toCc.length === 1 && vm.email.toCc[0] == '') {
          vm.error.emailCc = false;          
        } else {
          _.each(vm.email.toCc, (receiverEmail) => {
            receiverEmail = receiverEmail.trim();
            if (!vm.emailFormat.test(receiverEmail)) {
              vm.error.emailCc = true;
            }
          });
        }
      } else {
        emailsArray = vm.email.to.split(',');
        vm.email.to = emailsArray;
        _.each(vm.email.to, (receiverEmail) => {
          receiverEmail = receiverEmail.trim();
          if (!vm.emailFormat.test(receiverEmail)) {
            vm.error.email = true;
          }
        });
      }
    }

    function isFormValid() {
      vm.formHasError = false;
      if (vm.receiverDetails.length !== 0) {
        vm.email.to = _.pluck(vm.receiverDetails, 'email');
      }
      if (!vm.email.to || vm.email.to.length === 0) {
        vm.error.to = vm.out('Champs obligatoires', 'Required');
        vm.formHasError = true;
      } else {
        _.each(vm.email.to, (receiverEmail) => {
          if (!vm.emailFormat.test(receiverEmail.trim())) {
            vm.formHasError = true;
            vm.error.to = vm.out('Invalide', 'Invalid');
          }
        });
      }
      if (!vm.email.subject) {
        vm.error.subject = true;
        vm.formHasError = true;
      }
      if (!vm.email.message) {
        vm.error.message = true;
        vm.formHasError = true;
      }
      if (vm.formHasError || (vm.email.file && vm.email.file.$error)) {
        return false;
      }

      return true;
    }

    // attach single document from Atlas OR from the PC
    function uploadAttachmentWithNylas(type, atlasFile, files, file) {     
      // from atlas drive
      if (atlasFile) {
        vm.email.file = { name: atlasFile.file_name, fileVersion: atlasFile.id };
        vm.email.file.size = atlasFile.size;
      }
      if (file) vm.email.file = file;
      if (vm.email.file) {
        if (!vm.email.file.$error) {
          vm.totalSizeOfAttachements += vm.email.file.size;
          vm.data = {};
          if (type === 'atlas') { // from Atlas Drive
            vm.data = {
              minio_file_name: atlasFile.file_name,
              minio_file_path: `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`,
            };
          } else {
            vm.data.file = vm.email.file; // from PC
          }
          vm.data.nylas_account_id = vm.userData.nylas_account_id;
          const promise = api.messaging_fileupload('nylas/regular-emails/attachments', vm.data);
          promise.then((response) => {
            [vm.response] = response.data;
            vm.status = response.status;
            if (vm.status === 200) {
              if (vm.totalSizeOfAttachements / 1048576 <= 25) {
                vm.attachedDocName.push(vm.email.file.name);
                vm.attachedDoc = {
                  size: vm.response.size,
                  id: vm.response.id,
                  name: vm.response.filename,
                };
                vm.attachedDocs.push(vm.attachedDoc);
                vm.attachedDocId.push(vm.response.id);
                vm.email.file = null;
                if (vm.triggerSendEmail) {
                  sendEmail();
                }
              } else {
                vm.totalSizeOfAttachements -= vm.response.size;
                vm.triggerSendEmail = false;
                vm.email.file = null;
                msgEn = 'Sorry! You can send only 25 MBs in total.';
                msgFr = 'Désolé ! Vous pouvez envoyer seulement 25 Mo au total .';
                $rootScope.api_status('alert-danger', msgEn, msgFr);
              }
            }
          }).catch((error) => {
            vm.totalSizeOfAttachements -= vm.email.file.size;
            vm.triggerSendEmail = false;
            vm.email.file = null;
            if (error.status === 400 && error.data === "virus_detected_in_file") {
              msgEn = "Sorry! This file is invalid, please upload a new file";
              msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
            } else if (error.status === 422 && error.data?.file) {
              msgEn = 'File format or size is invalid';
              msgFr = "Le format ou la taille du fichier n'est pas valide";
            } else {
              msgEn = 'An error has occurred with the document upload, please try again';
              msgFr = 'Une erreur s\'est produite lors du téléchargement du document, veuillez réessayer';
            }
            $rootScope.api_status('alert-danger', msgEn, msgFr, "Upload fail", "Échec du téléchargement", 4000);
          });
        } else {
          vm.email.file = [];
        }
      } else {
        vm.email.file = null;
      }
    }
    
    function removeAttachedFileNylas(file, fileIndex) {
      vm.attachedDocName.splice(fileIndex, 1);
      vm.attachedDocId.splice(fileIndex, 1);
      vm.attachedDocs.splice(fileIndex, 1);
      vm.totalSizeOfAttachements -= file.size;
      if (vm.fileToBeAttached && vm.fileToBeAttached.length > 0) {
        vm.fileToBeAttached.splice(fileIndex, 1);
      }
      api.service_delete('messaging', `nylas/regular-emails/attachments/${file.id}`, {
        nylas_account_id: vm.userData.nylas_account_id,
      });
    }

    function removeAttachedFileAwsOrEmailEngine(file, fileIndex) {
      vm.attachedDocName.splice(fileIndex, 1);
      vm.awsAttachedFiles.splice(fileIndex, 1);
      vm.attachedDocs.splice(fileIndex, 1);
      if (vm.fileToBeAttached?.length > 0) {
        vm.fileToBeAttached.splice(fileIndex, 1);
      }
      let index;
      if (vm.duplicates?.length > 0) {
        angular.forEach(vm.duplicates, (dupe) => {
          if (dupe.minio_file_name === file.name) {
            index = vm.duplicates.indexOf(dupe);
            if (index >=0 ) vm.duplicates.splice(index, 1);
          }
        })
      }
      if (vm.moreDuplicateFiles?.length > 0) {
        angular.forEach(vm.moreDuplicateFiles, (duplicate) => {
          if (duplicate.minio_file_name === file.name) {
            index = vm.moreDuplicateFiles.indexOf(duplicate);
            if (index >=0 ) vm.moreDuplicateFiles.splice(index, 1);
          }
        })
      }
    }

    function removeAttachedFile(file, fileIndex) {
      if (vm.userData.provider === 'nylas') {
        removeAttachedFileNylas(file, fileIndex);
      } else  {
        removeAttachedFileAwsOrEmailEngine(file, fileIndex);
      }      
    }

    // attach single document from Atlas OR from the PC AWS
    function uploadAttachmentWithAwsOrEmailEngine(type, atlasFile, files, file) {
      // from atlas drive      
      vm.moreDuplicateFiles = [];
      if (atlasFile) {
        angular.forEach(vm.filesToAddToEmail, (atlasFile) => {
          let duplicate = _.find(vm.awsAttachedFiles, (file) => {
            return file.minio_file_path === `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`;
          })
          if(duplicate) {
            vm.moreDuplicateFiles.push(duplicate);
          } 
        })
        vm.email.file = { name: atlasFile.file_name, fileVersion: atlasFile.id };
        vm.email.file.size = atlasFile.size;
      }
      //from PC
      if (file) vm.email.file = file;
      if (vm.email.file) {
        if (!vm.email.file.$error) {
          vm.data = {};
          if (type === 'atlas') { // from Atlas Drive
            vm.data = {
              minio_file_name: atlasFile.file_name,
              minio_file_path: `DocumentManager/${atlasFile.user_id}/${atlasFile.original_file}`,
            };
          } else {            
            vm.data.file = file; // from PC
          }    
          vm.attachedDocName.push(vm.email.file.name);
          vm.attachedDoc = {              
            name: vm.email.file.name,
          };
          vm.attachedDocs.push(vm.attachedDoc);
          vm.awsAttachedFiles.push(vm.data);
          vm.email.file = null;
        } else {
          vm.email.file = [];
        }
      } else {
        vm.email.file = null;
      }
    }

    function enableNylas() {
      window.location = `${window.appConfig.ATLAS_UI_URL}sync`;
    }

    function uploadEmailDocs(type) {
      if (vm.userData.provider === 'nylas') {
        uploadEmailDocsWithNylas(type);
      } else {      
        uploadEmailDocsWithAwsOrEmailEngine(type);
      }     
    }

    function uploadAttachment(type, atlasFile, files, file) {
      if (vm.userData.provider === 'nylas') {
        uploadAttachmentWithNylas(type, atlasFile, files, file);
      } else {
        uploadAttachmentWithAwsOrEmailEngine(type, atlasFile, files, file);
      }      
    }

    function openAtlasDrive() {
      vm.directoryTrack = [];
      vm.openDirectory(1, 'home');
      const atlasDrive = $uibModal.open({
        animation: true,
        templateUrl:
                    './employer-profile/emails/modal-templates/choose-atlas-drive-file.html',
        scope: $scope,
        size: 'lg',
        windowClass: 'show z-index-999',
      });
      vm.filesToAddToEmail = [];
      atlasDrive.result.then(() => {
        if (!vm.filesToAddToEmail.length) return;
        if (vm.filesToAddToEmail.length > 1) {
          uploadEmailDocs('atlas');
        } else if (vm.filesToAddToEmail.length === 1) {
          vm.uploadAttachment('atlas', vm.filesToAddToEmail[0]);
        }       
      });
    }

    vm.addFileToUpload = (file) => {
      if (!file.selected) {
        file.selected = true;
        vm.filesToAddToEmail.push(file);
      } else {
        file.selected = false;
        const fileIndex = _.findIndex(vm.filesToAddToEmail, (item) => file.id == item.id);
        vm.filesToAddToEmail.splice(fileIndex, 1);
      }
    };

    function switchDirectory(id, name, index) {
      vm.directoryTrack.splice(index);
      vm.openDirectory(id, name);
    }

    function fetchDirectories(id) {
      vm.dirLoaded = false;
      const promise = api.service_get('toolkit',
        `document-manager/directories?filter_by_parent_id=${id}`);
      promise.then((response) => {
        vm.dirLoaded = true;
        if (response.data.status === 'success') {
          vm.directories = response.data.data.result;
        }
      }).catch(() => {
        vm.dirLoaded = true;
      });
    }

    function fetchFiles(id) {
      vm.fileLoaded = false;
      const promise = api.service_post('toolkit', `document-manager/files/file_type_data?filter_by_dm_directory_id=${id}`, {});
      promise.then((response) => {
        if (response.data.status === 'success') {
          vm.files = response.data.data.result;
          if (vm.filesToAddToEmail.length) {
            const selectedFilesId = _.pluck(vm.filesToAddToEmail, 'dm_file_id');
            _.each(selectedFilesId, (fileId) => {
              const selectedFile = _.find(vm.files, (file) => file.id === fileId);
              if (selectedFile) selectedFile.file_version[0].selected = true;
            });
          }
        }
        vm.fileLoaded = true;
      }).catch(() => {
        vm.fileLoaded = true;
      });
    }

    function openDirectory(id, name) {
      vm.directoryTrack.push({ id, name });
      vm.currentDirectory = id;
      fetchDirectories(vm.currentDirectory);
      fetchFiles(vm.currentDirectory);
    }

    // Get type of file for icon
    vm.getTypeOfFile = function getTypeOfFile(name) {
      const noExtention = 'file';
      const ext = name.toLowerCase().split('.').pop();
      if (
        ext === 'pdf'
                || ext === 'docx'
                || ext === 'doc'
                || ext === 'odt'
                || ext === 'txt'
                || ext === 'png'
                || ext === 'jpg'
                || ext === 'jpeg'
                || ext === 'gif'
                || ext === 'xlsx'
                || ext === 'xls'
                || ext === 'pptx'
                || ext === 'ppt'
      ) {
        return ext;
      }
      return noExtention;
    };

    function formatDate(insertDate) {
      return $filter('date')(
        new Date(insertDate.split('-').join('/')),
        'y/MM/d',
      );
    }

    // display jobs in the select for CRM
    vm.jobDisplayName = function jobDisplayName(job) {
      job.location = job.location ? job.location : '';
      if ($rootScope.language === 'en') {
        if (job.titleEn) {
          return `${job.titleEn} - ${job.location} ( ${formatDate(
            job.created_at,
          )} )`;
        }

        return `ID: ${job.id} - ${job.location} ( ${formatDate(
          job.created_at,
        )} )`;
      }
      if ($rootScope.language === 'fr') {
        if (job.titleFr) {
          return `${job.titleFr} - ${job.location} ( ${formatDate(
            job.created_at,
          )} )`;
        }

        return `ID: ${job.id} - ${job.location} ( ${formatDate(
          job.created_at,
        )} )`;
      }
    };

    vmExtend = {
      isFormValid,
      sendEmail,
      uploadAttachment,
      uploadEmailDocs,
      removeAttachedFile,
      enableNylas,
      receiverList,
      switchDirectory,
      openAtlasDrive,
      openDirectory,
      fetchDirectories,
      fetchFiles,
      fetchEmailTemplates,
      fetchSignature,
      fetchVariables,
      importVariable,
      onTemplateChange,
      attachSignature,
      parseEmails,
      onLanguageChange,
      switchJob,
      openSignaturesModal,
      switchEmail,
    };
    angular.extend(vm, vmExtend);
    $scope.$on('$destroy', () => {
      // disable the listener
      rootModelListener();
    });
  }
  EmailComposerCtrl.$inject = [
    '$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    'api',
    '$uibModal',
    '$filter',
    '$q',
    'storageService',
    'Event',
  ];
  const app = angular.module('atlas');
  app.directive('emailComposer', () => ({
    scope: {},
    bindToController: {
      sentTab: '&',
      userData: '=?',
      jobId: '@',
      employerAccountId: '@',
      hasData: '=?',
      selectedCandidates: '=?',
      // bulk: '=?',
      candidate: '=?',
      openOptions: '=?',
      allowSelectEmail: '=?',
      isShare: '=?',
      fileToBeAttached: '=?',
      commonJobList: '=?',
      mode: '@',
    },
    controller: EmailComposerCtrl,
    controllerAs: 'vm',
    template: require('./email-composer.template.html'),
  }));
}(angular));
