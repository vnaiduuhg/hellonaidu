(function (angular) {
  function EmailSignatureCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    MetaTagsService,
    $state,
    api,
    $ngConfirm,
    storageService,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    const scope = {
      strings: worklandLocalize.strings,
      out: utils.out,
      trustAsHtml: utils.trustAsHtml,
      defaultSignature,
      fetchSignature,
      customizeSignature,
      cancel,
      loadDefaultSignature,
      saveSignature,
      validateSignature,
      ourDefaultSignature: {},
      isDefaultSignature: false,
      userSignature: {},
      isAgency: !!((storageService.getItem('account_role') === '100' && storageService.getItem('account_type') === 'agency'))
    };
    angular.extend($scope, scope);

    function defaultSignature() {
      let data = '';
      /* if ($rootScope.currentUser.permissions.isEmployer || $scope.isAgency) {
        data = $rootScope.currentUser.user;
      } else {
        data = $rootScope.currentUser.employer;
      } */
      const logo = $rootScope.currentUser.profile_page[0].logo
                  ? window.appConfig.MINIO_URL + 'media/Profile/Logos/' + $rootScope.currentUser.profile_page[0].logo
                  : '../../../assets/images/fallback_images/generic_logo.png';
      const name = `${$rootScope.currentUser.user.first_name} ${$rootScope.currentUser.user.last_name}`;
      // @todo replace $rootScope.currentUser.user.dashboard_permissions for title
      const title = '';
      const { email } = $rootScope.currentUser.user;
      let { phone } = $rootScope.currentUser.profile_page[0];
      if ($rootScope.currentUser.profile_page[0].phone_extension) {
        phone = +' ext.: ';
      }
      // @todo replace the address
      let address = '';
      if($rootScope.currentUser.location) {
        const data = $rootScope.currentUser.location;
        if (data.street_number && data.street) {
          address = data.street_number + ' ' + data.street;
        }
        if (data.city) {
          address += address != '' ? `, ${data.city}` : data.city;
        }
        if (data.province) {
          address += address != '' ? `, ${data.province}` : data.province;
        }
        if (data.country) {
          address += address != '' ? `, ${data.country}` : data.country;
        }
        if (data.postal_code) {
          address += address != '' ? ` ${data.postal_code}` : data.postal_code;
        }
      }

      let company = $rootScope.currentUser.account.name.toLowerCase();
      company = company.replace(/\s+/g, '');
      const socialIcon = `${worklandLocalize.iconsUrl}/new-social-icon/`;
      $scope.ourDefaultSignature.id = 0;
      $scope.ourDefaultSignature.body = `${'<table cellpadding="0" cellspacing="0">'
                  + '<tbody>'
                      + '<tr>'
                          + '<td style="width:140px; padding:0; text-align:center; vertical-align:middle;" valign="middle" width="140">'
                              + '<img alt="logo" border="0" style="max-width:100px; max-height:100px; padding:4px;" class = "img img-fluid" src="'}${logo}">`
                          + '</td>'
                          + '<td style="border-bottom:2px solid; border-bottom-color:#005a87; padding:0; vertical-align:top;" valign="top">'
                              + '<table cellpadding="0" cellspacing="0">'
                                  + '<tbody>'
                                      + '<tr>'
                                          + '<td style="color:#005a87; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; vertical-align:top;" valign="top">'
                                              + `<strong><span style="font-family:Verdana, sans-serif; color:#005a87; font-size:14pt; font-style:italic;">${name}</span></strong><br>`
                                              + `<span style="font-family:Verdana, sans-serif; color:#005a87; font-size:10pt;">${title}</span>`
                                          + '</td>'
                                      + '</tr>'
                                      + '<tr>'
                                          + '<td style="font-family:Verdana, sans-serif; color:#444444; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; line-height:18px; vertical-align:top;" valign="top">'
                                              + `<img src="https://img.icons8.com/small/16/000000/email.png"/> : <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${email}<br></span>`
                                              + `<img src="https://img.icons8.com/small/16/000000/phone.png"/> : <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${phone}
                                              <span style="font-family:Verdana, sans-serif; font-size:10pt;"> | </span>`
                                              + '</span>'
                                              + `<img src="https://img.icons8.com/small/16/000000/touchscreen-smartphone.png"/> : <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${phone}</span>`
                                          + '</td>'
                                      + '</tr>'
                                      + '<tr>'
                                          + '<td style="font-family:Verdana, sans-serif; color:#444444; padding-bottom:6px; padding-top:0; padding-left:0; padding-right:0; line-height:18px; vertical-align:top;" valign="top">'
                                              + `<img src="https://img.icons8.com/ios/16/000000/marker.png"/> : <span style="font-family:Verdana, sans-serif; color:#444444; font-size:10pt;">${address}</span>`
                                          + '</td>'
                                      + '</tr>'
                                  + '</tbody>'
                              + '</table>'
                          + '</td>'
                      + '</tr>'
                      + '<tr>'
                          + '<td style="font-family:Verdana, sans-serif; width:140px; padding-top:6px; padding-left:0; padding-right:0; text-align:center; vertical-align:middle;" valign="middle" width="140">'
                              + `<span><a href="https://www.facebook.com" target="_blank" rel="noopener"><img border="0" width="16" alt="facebook icon" style="border:0; height:16px; width:16px" src="${socialIcon}facebook.png"></a>&nbsp;</span>`
                              + `<span><a href="https://twitter.com/" target="_blank" rel="noopener"><img border="0" width="16" alt="twitter icon" style="border:0; height:16px; width:16px" src="${socialIcon}twitter.png"></a>&nbsp;</span>`
                              + `<span><a href="https://www.youtube.com" target="_blank" rel="noopener"><img border="0" width="16" alt="youtube icon" style="border:0; height:16px; width:16px" src="${socialIcon}youtube.png"></a>&nbsp;</span>`
                              + `<span><a href="https://www.linkedin.com" target="_blank" rel="noopener"><img border="0" width="16" alt="linkedin icon" style="border:0; height:16px; width:16px" src="${socialIcon}linkedin.png"></a>&nbsp;</span>`
                          + '</td>'
                          + '<td style="padding-top:6px; padding-bottom:0; padding-left:0; padding-right:0; vertical-align:middle;" valign="middle">'
                              + `<a href="http://www.${company}.com" target="_blank" rel="noopener" style=" text-decoration:none;">`
                                  + '<span style="color:#005a87; font-family:Verdana, sans-serif; font-size:10pt">'
                                      + `<span style="color:#005a87; font-family:Verdana, sans-serif; font-size:10pt">www.${company}.com</span>`
                                  + '</span>'
                              + '</a>'
                          + '</td>'
                      + '</tr>'
                  + '</tbody>'
              + '</table>';
    }

    function fetchSignature() {
      $scope.loadingMsg = utils.out('Nous allons chercher votre signature', 'We are fetching your signature');

      const promise = api.service_get('toolkit', 'mail-template/signatures');
      promise.then((response) => {
        if (response.data.status === 'success') {
          if (response.data.data.result.length > 0) {
            $scope.userSignature.id = response.data.data.result[0].id;
            $scope.userSignature.body = response.data.data.result[0].translation.en.body;
          } else {
            $scope.loadingMsg = utils.out('Il semble que vous visitez la première fois. Nous créons votre signature par défaut', 'It seems you visit the first time. We are creating your default signature');
            $scope.isDefaultSignature = true;
            $scope.editSignature = $scope.ourDefaultSignature;
          }
        }
      }).catch(() => {
        $scope.userSignature = {};
        $rootScope.api_status('alert-danger');
      });
    }

    function init() {
      defaultSignature();
      fetchSignature();
    }

    init();

    function customizeSignature() {
      $scope.isEditMode = true;
      $scope.editSignature = $scope.userSignature;
    }

    function cancel() {
      $scope.editSignature = '';
      $scope.isEditMode = false;
    }

    function validateSignature(signature) {
      if (signature.body === undefined || signature.body === '') {
        return false;
      }
      return true;
    }

    function saveSignature() {
      let msgEn = '';
      let msgFr = '';
      if ($scope.isResetMode) {
        defaultSignature();
        $scope.editSignature = $scope.ourDefaultSignature;
        $scope.editSignature.id = $scope.userSignature.id;
      }

      if (validateSignature($scope.editSignature)) {
        if ($scope.isResetMode) {
          msgEn = 'Resetting your signature...';
          msgFr = 'Réinitialisation de votre signature ...';
          $rootScope.api_status('waiting', msgEn, msgFr);
        } else {
          msgEn = 'Saving your signature...';
          msgFr = 'Nous sauvegardons votre signature ...';
          $rootScope.api_status('waiting', msgEn, msgFr);
        }
        const data = {
          en: {
            body: $scope.editSignature.body,
          },
          fr: {
            body: $scope.editSignature.body,
          },
        };

        let promise;
        if ($scope.isEditMode || $scope.isResetMode) {
          promise = api.service_post('toolkit', `mail-template/signatures/${$scope.editSignature.id}`, data, 'update');
        } else {
          promise = api.service_post('toolkit', 'mail-template/signatures', data);
        }

        promise.then((response) => {
          $scope.status = response.data.status;
          if ($scope.status === 'success') {
            if ($scope.isResetMode) {
              msgEn = 'Your signature has been reset successfully.';
              msgFr = 'Votre signature a été réinitialisée avec succès.';
              $rootScope.api_status('alert-success', msgEn, msgFr);
            } else {
              msgEn = 'Your signature has been saved successfully.';
              msgFr = 'Votre signature a été enregistrée avec succès.';
              $rootScope.api_status('alert-success', msgEn, msgFr);
            }

            $scope.userSignature = $scope.editSignature;
            if (!$scope.isEditMode && !$scope.isResetMode) {
              $scope.userSignature.id = response.data.data.result.id;
            }
            $scope.loadingMsg = '';
            $scope.editSignature = '';
            $scope.isEditMode = false;
            $scope.isResetMode = false;
            $scope.isDefaultSignature = false;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
        });
      } else {
        msgEn = 'Signature should not be empty.';
        msgFr = 'La signature ne doit pas être vide.';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
      }
    }

    function loadDefaultSignature() {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: utils.out('Réinitialiser par défaut', 'Reset default'),
        content: utils.out('Vous perdrez votre signature personnalisée.<br>Êtes-vous sûr de vouloir réinitialiser?', 'You will lose your customized signature.<br>Are you sure you want to reset?'),
        type: 'blue',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          yes: {
            text: utils.out('Oui', 'Yes'),
            btnClass: 'btn-blue',
            action() {
              $scope.isResetMode = true;
              saveSignature();
            },
          },
          no: {
            text: utils.out('Non', 'No'),
            action() {
            },
          },
        },
      });
    }

  }
  EmailSignatureCtrl.$inject = ['$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
    'api',
    '$ngConfirm',
    'storageService'
  ];
  angular.module('atlas')
    .directive('emailSignature', () => ({
      scope: {
      },
      controller: EmailSignatureCtrl,
      templateUrl: './employer-profile/emails/email-signature/email-signature.template.html',
    }));
}(angular));
