(function (angular) {

    'use strict';
    angular.module('atlas')
            .directive('emailTemplates', function () {

                return {
                    scope: {
                        viewMode: '@',
                        formName: '@'
                    },
                    controller: EmailTemplatesCtrl,
                    templateUrl: './employer-profile/emails/email-templates/email-templates.template.html'
                };
            });
    EmailTemplatesCtrl.$inject = ['$scope',
        '$rootScope',
        'utils',
        '_',
        'worklandLocalize',
        'MetaTagsService',
        '$state',
        'api',
        '$uibModal'
    ];
    function EmailTemplatesCtrl(
            $scope,
            $rootScope,
            utils,
            _,
            worklandLocalize,
            MetaTagsService,
            $state,
            api,
            $uibModal
            ) {

        MetaTagsService.getMetatags($state.current.name);
        var deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on("$destroy", function () {
            deregisterFns.forEach(function (deregisterFn) {
                deregisterFn();
            });
        });

        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            trustAsHtml: utils.trustAsHtml,
            checkEmailService: checkEmailService,
            fetchEmailTemplates: fetchEmailTemplates,
            fetchCategories: fetchCategories,
            fetchVariables: fetchVariables,
            showVariables: showVariables,
            importVariable: importVariable,
            saveEmailTemplate: saveEmailTemplate,
            editEmailTemplate: editEmailTemplate,
            deleteEmailTemplate: deleteEmailTemplate,
            cancel: cancel,
            template: {},
            error: {},
            isEdit: false,
            validateFields: validateFields
        };
        angular.extend($scope, scope);
        $scope.$watch('formName', function (newValue, oldValue) {
            $scope.template = {};
            $scope.error = {};
            fetchCategories();
            fetchEmailTemplates();
        });

        init();
        function init() {
            fetchCategories();
            fetchVariables();
            fetchEmailTemplates();
        }

        $scope.tagHandler = function (tag) {
            return null;
        };

        function checkEmailService() {
            $scope.emailService = "nylas";
        }

        function fetchEmailTemplates() {
            $scope.emailTemplates = null;
            var data = {
                "sort_by":"title",
                "locale": $rootScope.language 
            }
            var promise = api.service_get('toolkit', 'mail-template/templates', data);
            promise.then(function (response) {
                $scope.status = response.data.status;
                if ($scope.status === "success") {
                    $scope.emailTemplates = response.data.data.result;
                }
            }).catch(function () {
                $scope.emailTemplates = [];
            });
        }

        function fetchCategories() {
            var promise = api.service_get('toolkit', 'mail-template/categories');
            promise.then(function (response) {
                if (response.data.status === "success") {
                    $scope.categories = response.data.data.result;
                } else {
                    $scope.categories = [];
                }
            }).catch(function () {
                $scope.categories = [];
            });
        }

        function fetchVariables() {
            var promise = api.service_get('toolkit', 'variable');
            promise.then(function (response) {
                if (response.status === 200) {
                    $scope.variables = response.data;
                }
            }).catch(function () {
                $scope.userSignature = {};
            });
        }

        function showVariables(language){
            $scope.variablesLanguage = language;
            var showVariablesInstance = $uibModal.open({
                animation: true,
                templateUrl: './employer-profile/emails/modal-templates/show-variables.template.html',
                scope: $scope,
                size: 'sm'
            });
        }

        function importVariable(variable) {
            if($scope.variablesLanguage == "english") {
                $scope.template.translation.en.body = $scope.template.translation.en.body ? $scope.template.translation.en.body + "{{" + variable + "}}" : "{{" + variable + "}}";
            }
            else{
                $scope.template.translation.fr.body = $scope.template.translation.fr.body ? $scope.template.translation.fr.body + "{{" + variable + "}}" : "{{" + variable + "}}";
            }

        }

        function saveEmailTemplate() {
            if (validateFields()) {
                var msgEn = "Saving Your Email Template...";
                var msgFr = "Enregistrement de votre modèle de courrier électronique...";
                $rootScope.api_status("waiting", msgEn, msgFr);
                var templateData = {
                    "en": {
                        "title": $scope.template.translation.en.title,
                        "subject": $scope.template.translation.en.subject,
                        "body": $scope.template.translation.en.body
                    },
                    "fr": {
                        "title": $scope.template.translation.fr.title,
                        "subject": $scope.template.translation.fr.subject,
                        "body": $scope.template.translation.fr.body
                    },
                    "is_default": $scope.isEdit ? $scope.template.is_default : 0,
                    "mail_template_category_id": $scope.template.mail_template_category_id
                };

                var promise;
                if ($scope.isEdit) {
                    promise = api.service_post('toolkit', 'mail-template/templates/' + $scope.template.id, templateData, 'update');
                } else {
                    promise = api.service_post('toolkit', 'mail-template/templates', templateData);
                }

                promise.then(function (response) {
                    if (response.data.status === "success") {
                        var msgEn = "Your email template has been saved successfully.";
                        var msgFr = "Votre modèle de courrier électronique a été enregistré avec succès.";
                        $rootScope.api_status('alert-success', msgEn, msgFr);
                        $scope.template = {};
                        if ($scope.isEdit) {
                            $scope.viewMode = "true";
                            $scope.isEdit = false;
                        }
                        fetchEmailTemplates();
                    } else {
                        $rootScope.api_status('alert-danger', response.data);
                    }
                }).catch(function () {
                    $rootScope.api_status('alert-danger');
                });
            }
        }

        function editEmailTemplate(template) {
            $scope.template = template;
            $scope.viewMode = "false";
            $scope.isEdit = true;
        }

        function deleteEmailTemplate(templateId) {
            var msgEn = "Deleting your email template...";
            var msgFr = "Suppression de votre modèle de courrier électronique ...";
            $rootScope.api_status("waiting", msgEn, msgFr);

            var promise = api.service_delete('toolkit', 'mail-template/templates/' + templateId);
            promise.then(function (response) {
                if (response.data.status === "success") {
                    var msgEn = "Your email template has been deleted successfully.";
                    var msgFr = "Votre modèle de courrier électronique a été supprimé avec succès.";
                    $rootScope.api_status('alert-success', msgEn, msgFr);
                    fetchEmailTemplates();
                } else {
                    $rootScope.api_status('alert-danger', response.data);
                }
            }).catch(function () {
                $rootScope.api_status('alert-danger');
            });
        }

        function cancel() {
            $scope.template = {};
            $scope.viewMode = "true";
            $scope.isEdit = false;
        }

        function validateFields() {
            var isValid = true;

            if (!$scope.template.mail_template_category_id) {
                $scope.error.category = true;
                isValid = false;
            }

            if (!$scope.template.translation.en.title) {
                $scope.error.titleEn = true;
                isValid = false;
            }
            if (!$scope.template.translation.fr.title) {
                $scope.error.titleFr = true;
                isValid = false;
            }

            if (!$scope.template.translation.en.subject) {
                $scope.error.subjectEn = true;
                isValid = false;
            }
            if (!$scope.template.translation.fr.subject) {
                $scope.error.subjectFr = true;
                isValid = false;
            }

            if (!$scope.template.translation.en.body) {
                $scope.error.messageEn = true;
                isValid = false;
            }
            if (!$scope.template.translation.fr.body) {
                $scope.error.messageFr = true;
                isValid = false;
            }

            return isValid;
        }

    }
})(angular);
