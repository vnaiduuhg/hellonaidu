(function (angular) {
    function EmailViewCtrl(
            $scope,
            $rootScope,
            utils,
            _,
            worklandLocalize,
            MetaTagsService,
            $state,
            api,
            ) {

        MetaTagsService.getMetatags($state.current.name);
        var deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on("$destroy", function () {
            deregisterFns.forEach(function (deregisterFn) {
                deregisterFn();
            });
        });

        $scope.userEmail = $rootScope.currentUser.user.email;
        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            trustAsHtml: utils.trustAsHtml,
            fetchEmails: fetchEmails,
            getEmailDate: getEmailDate,
            showEmail: showEmail,
            goBack: goBack,
            changePage: changePage,
            enableNylas:enableNylas,
            utcToTimezone: utils.utcToTimezone
        };
        angular.extend($scope, scope);

        $scope.$watch('viewType', function () {
            init();
        });
        $scope.$watch('nylasConfig', function () {
            init();
        });
        init();
        function init() {

            $scope.currentPage = 1;
            $scope.openEmail = "";
            if ($scope.nylasConfig && $scope.nylasConfig.synced) {
                fetchEmails($scope.currentPage);
            }
        }

        function fetchEmails(page) {
            $scope.emails = null;
            var url = 'email-client/nylas/email/' + $scope.viewType + '?access_token=' + $scope.nylasConfig.token + '&page_no=' + page;
            var promise = api.service_post('toolkit', url);
            promise.then(function (response) {
                if (response.data.status === "success") {
                    $scope.emails = response.data.data.response;
                    if ($scope.emails.length == 0 && $scope.currentPage > 1) {
                        changePage('prev');
                    }
                }
            }).catch(function (error) {
                $scope.emails = [];
            });
        }
        function getEmailDate(dateCode) {
            var localDateCode = utils.utcToTimezone(dateCode, '');
            return new Date(localDateCode);
        }
        function showEmail(email) {
            $scope.openEmail = email;
        }
        function goBack() {
            $scope.openEmail = "";
        }
        function changePage(type) {
            if (type == 'prev') {
                $scope.currentPage = $scope.currentPage - 1;
            }
            else if (type == 'next') {
                $scope.currentPage = $scope.currentPage + 1;
            }
            fetchEmails($scope.currentPage)
        }
        function enableNylas() {
            $rootScope.api_status("waiting");
            var data = {login_hint: $scope.userEmail};
            var promise = api.service_post('toolkit', 'mailer/nylas/authorize-address', data);
            promise.then(function (response) {
                if (response.data.status === "success") {
                    var titleEn = "Please wait";
                    var titleFr = "S'il vous plaît, attendez";
                    var msgEn = "We are redirecting you to NYLAS for verification purpose.";
                    var msgFr = "Nous vous redirigeons vers NYLAS à des fins de vérification.";
                    $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
                    location.href = response.data.data.authorize_address;
                }
            }).catch(function () {
                $rootScope.api_status('alert-danger');
            });
        }

    }

    EmailViewCtrl.$inject = [
        '$scope',
        '$rootScope',
        'utils',
        '_',
        'worklandLocalize',
        'MetaTagsService',
        '$state',
        'api',
    ];
    angular.module('atlas')
        .directive('emailView', function () {
            return {
                scope: {
                    viewType: '@',
                    nylasConfig: '=',
                },
                controller: EmailViewCtrl,
                templateUrl: './employer-profile/emails/email-view/email-view.template.html'
            };
        });
})(angular);