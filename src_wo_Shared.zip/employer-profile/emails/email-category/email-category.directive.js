(function (angular) {

    'use strict';
    angular.module('atlas')
            .directive('emailCategory', function () {

                return {
                    scope: {
                    },
                    controller: EmailCategoryCtrl,
                    templateUrl: './employer-profile/emails/email-category/email-category.template.html'
                };
            });
    EmailCategoryCtrl.$inject = ['$scope',
        '$rootScope',
        'utils',
        '_',
        'worklandLocalize',
        'MetaTagsService',
        '$state',
        'api'
    ];
    function EmailCategoryCtrl(
            $scope,
            $rootScope,
            utils,
            _,
            worklandLocalize,
            MetaTagsService,
            $state,
            api
            ) {

        MetaTagsService.getMetatags($state.current.name);
        var deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on("$destroy", function () {
            deregisterFns.forEach(function (deregisterFn) {
                deregisterFn();
            });
        });

        var scope = {
            strings: worklandLocalize.strings,
            out: utils.out,
            trustAsHtml: utils.trustAsHtml,
            category:{en:"",fr:""},
            updated:{en:"",fr:""},
            fetchCategories: fetchCategories,
            createCategory:createCategory,
            deleteCategory:deleteCategory,
            editModeOn: editModeOn,
            editModeOff: editModeOff
        };
        angular.extend($scope, scope);

        function init() {
            fetchCategories();
        }

        function fetchCategories() {
            $scope.categories = false;
            var promise = api.service_get('toolkit', 'mail-template/categories');
            promise.then(function (response) {
                if (response.data.status === "success") {
                    $scope.categories = response.data.data.result;
                }
            }).catch(function (error) {
                $scope.categories = [];
            });
        }

        function createCategory(currentCat,isUpdate) {
            $scope.hasEnError=false;
            $scope.hasFrError=false;
            $scope.updated.frError=false;
            $scope.updated.enError=false;

            if(isUpdate){
                if(!$scope.updated.en){
                    $scope.updated.enError=true;
                }
                else{
                    $scope.updated.enError=false;
                }
                if(!$scope.updated.fr){
                    $scope.updated.frError=true;
                }
                else{
                    $scope.updated.frError=false;
                }
            }
            else{
                if(!$scope.category.en){
                    $scope.hasEnError=true;
                }
                else{
                    $scope.hasEnError=false;
                }
                if(!$scope.category.fr){
                    $scope.hasFrError=true;
                }
                else{
                    $scope.hasFrError=false;
                }
            }

            if(!$scope.hasEnError && !$scope.hasFrError && !$scope.updated.enError && !$scope.updated.frError){

                if(isUpdate){
                    var msgEn = "Updating your category...";
                    var msgFr = "Mise à jour de votre categorie...";
                    $rootScope.api_status("waiting", msgEn, msgFr);

                    var data = {
                        "en": {
                            "name": $scope.updated.en
                        },
                        "fr": {
                            "name": $scope.updated.fr
                        }
                    };
                    var url='mail-template/categories/'+currentCat.id;
                }
                else{
                    var msgEn = "Created a new category";
                    var msgFr = "Créé une nouvelle catégorie";
                    $rootScope.api_status("waiting", msgEn, msgFr);
                    var data = {
                        "en": {
                            "name": $scope.category.en
                        },
                        "fr": {
                            "name": $scope.category.fr
                        }
                    };
                    var url='mail-template/categories';
                }
                var promise = api.service_post('toolkit', url, data, isUpdate);
                promise.then(function (response) {
                    if (response.data.status === "success") {
                        $scope.category=null;
                        if(isUpdate == 'updated'){
                            var msgEn = "Category is succesfully updated";
                            var msgFr = "La catégorie est mis à jour avec succès";
                        }
                        else{
                            var msgEn = "Category is succesfully created";
                            var msgFr = "La catégorie est créée avec succès";
                        }
                        $rootScope.api_status('alert-success', msgEn, msgFr);
                        editModeOff();
                        fetchCategories();
                    }
                }).catch(function (error) {
                    $rootScope.api_status('alert-danger');
                });
            }
        }

        function deleteCategory(id) {
            var msgEn = "Deleting your category...";
            var msgFr = "Suppression de votre dossier...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var promise = api.service_delete('toolkit', 'mail-template/categories/' + id);
            promise.then(function (response) {
                if (response.data.status === "success") {
                    fetchCategories();
                    var titleEn = "Category deleted";
                    var titleFr = "Dossier supprimé";
                    var msgEn = "";
                    var msgFr = "";
                    $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
                }
            }).catch(function (error) {
                $rootScope.api_status('alert-danger');
            });
        }
//--------------edit-------------

        function editModeOn(category) {
            $scope.editMode = {};
            $scope.editMode.id = category.id;
            $scope.updated.en=category.translation.en.name;
            $scope.updated.fr=category.translation.fr.name;
            $scope.updated.frError=false;
            $scope.updated.enError=false;
        }

        function editModeOff() {
            $scope.updated={en:"",fr:""};
            $scope.editMode = {};
        }

        init();

    }
})(angular);

