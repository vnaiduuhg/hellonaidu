(function (angular) {
  function AtlasDriveCtrl(
    $scope,
    utils,
    _,
    worklandLocalize,
  ) {
    const scope = {
      strings: worklandLocalize.strings,
      out: utils.out,
      trustAsHtml: utils.trustAsHtml,
      currentTab: {},
      openTab,
    };
    angular.extend($scope, scope);


    function init() {
      $scope.sideTabs = [
        {
          nameEn: 'My Drive', nameFr: 'Mon classeur', icon: 'fa-database', type: 'drive',
        },
        {
          nameEn: 'Category', nameFr: 'Catégorie', icon: 'fa-list-ul', type: 'category',
        },
        {
          nameEn: 'Tags', nameFr: 'Étiquettes', icon: 'fa-tags', type: 'tags',
        },
      ];
      $scope.currentTab.active = $scope.sideTabs[0].type;
    }

    function openTab(tab) {
      $scope.currentTab.active = tab.type;
    }

    $scope.openTabWithAnimation = function($event, tab, subTab) {
      $event.preventDefault();

      openTab(tab, subTab);

      if (!subTab) {
        design.sidebar.openDropdown($event.currentTarget);
      }
    }

    init();
    design.sidebar.ngInit('atlas-drive');

  }
  AtlasDriveCtrl.$inject = [
    '$scope',
    'utils',
    '_',
    'worklandLocalize',
  ];
  angular.module('atlas')
    .controller('AtlasDriveCtrl', AtlasDriveCtrl);
}(angular));
