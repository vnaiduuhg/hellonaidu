(function (angular) {
  function AtlasDriveTagsCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    MetaTagsService,
    $state,
    api,
    $uibModalStack,
    $ngConfirm,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
      const scope = {
        strings: worklandLocalize.strings,
        out: utils.out,
        trustAsHtml: utils.trustAsHtml,
        tag: {},
        updated: {},
        fetchTags,
        createTag,
        deleteTag,
        editModeOn,
        editModeOff,
        assignTag,
        closeModal,
      };
      angular.extend($scope, scope);

      let msgEn; let msgFr;

      $scope.divStyle = {
        'background-color': 'white',
      };
      $scope.$watch('mycolor', (val) => {
        $scope.divStyle = {
          'background-color': val,
        };
      });

      function init() {
        fetchTags();
        $scope.tag.colour = 'white';
      }

      function fetchTags() {
        $scope.tags = [];
        $scope.loading = true;
        const promise = api.service_get('toolkit', 'document-manager/tags');
        promise.then((response) => {
          if (response.data.status === 'success') {
            $scope.tags = response.data.data.result;
          }
          $scope.loading = false;
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loading = false;
        });
      }

      // --------------edit-------------

      function editModeOn(tag) {
        $scope.editMode = {};
        $scope.editMode.id = tag.id;
        $scope.updated.en = tag.translation.en.title;
        $scope.updated.fr = tag.translation.fr.title;
        $scope.updated.colour = tag.colour;
        $scope.updated.frError = false;
        $scope.updated.enError = false;
      }

      function editModeOff() {
        $scope.updated = {};
        $scope.tag = {};
        $scope.editMode = {};
        $scope.tag.colour = 'white';
      }

      function createTag(currentTag, isUpdate) {
        let data = {};
        let url = '';       
        $scope.hasEnError = false;
        $scope.hasFrError = false;
        $scope.updated.frError = false;
        $scope.updated.enError = false;
        $scope.updated.colourError = false;
        $scope.tagError = false;
        if (isUpdate) {
          if (!$scope.updated.en) {
            $scope.updated.enError = true;
          } else {
            $scope.updated.enError = false;
          }
          if (!$scope.updated.fr) {
            $scope.updated.frError = true;
          } else {
            $scope.updated.frError = false;
          }
          if ($scope.updated.colour === 'rgb(255,255,255)') {
            $scope.updated.colourError = true;
          } else {
            $scope.updated.colourError = false;
          }
        } else {
          if (!$scope.tag.en) {
            $scope.hasEnError = true;
          } else {
            $scope.hasEnError = false;
          }
          if (!$scope.tag.fr) {
            $scope.hasFrError = true;
          } else {
            $scope.hasFrError = false;
          }
          if ($scope.tag.colour === 'white' || $scope.tag.colour === 'rgb(255,255,255)') {
            $scope.tagError = true;
          } else {
            $scope.tagError = false;
          }
        }

        if (!$scope.hasEnError && !$scope.hasFrError && !$scope.updated.enError
            && !$scope.updated.frError && !$scope.tagError && !$scope.updated.colourError) {
          if (isUpdate) {
            msgEn = 'Updating your tag...';
            msgFr = 'Mise à jour de votre étiquette...';
            $rootScope.api_status('waiting', msgEn, msgFr);
            data = {
              en: {
                title: $scope.updated.en,
                description: $scope.updated.en,
              },
              fr: {
                title: $scope.updated.fr,
                description: $scope.updated.fr,
              },
              colour: $scope.updated.colour,
              is_system: 0,
            };
            url = `document-manager/tags/${currentTag.id}`;
          } else {
            msgEn = 'Creating a new tag...';
            msgFr = 'Création d\'une nouvelle étiquette...';
            $rootScope.api_status('waiting', msgEn, msgFr);
            data = {
              en: {
                title: $scope.tag.en,
                description: $scope.tag.en,
              },
              fr: {
                title: $scope.tag.fr,
                description: $scope.tag.fr,
              },
              colour: $scope.tag.colour,
              is_system: 0,
            };
            url = 'document-manager/tags';
          }

          const promise = api.service_post('toolkit', url, data, isUpdate);
          promise.then((response) => {
            if (response.data.status === 'success') {
              if (isUpdate) {
                msgEn = 'Tag is successfully updated';
                msgFr = 'L\'étiquette est mise à jour avec succès';
              } else {
                msgEn = 'Tag is successfully created';
                msgFr = 'L\'étiquette est créée avec succès';
              }

              $rootScope.api_status('alert-success', msgEn, msgFr);
              editModeOff();
              fetchTags();
            }
          }).catch(() => {
            $rootScope.api_status('alert-danger');
          });
        }
      }

      function deleteTag(id) {
        $ngConfirm({
          icon: 'fa fa-exclamation',
          title:  $scope.out('Suppression de l\'étiquette', 'Delete tag'),
          content: $scope.out('Êtes-vous sûr de vouloir supprimer?', 'Are you sure you want to delete?'),
          type: 'red',
          typeAnimated: true,
          animation: 'RotateX',
          buttons: {
            yes: {
              text: $scope.out('Oui', 'Yes'),
              btnClass: 'btn btn-danger float-end',
              action() {
                msgEn = 'Deleting your tag...';
                msgFr = 'Suppression de votre étiquette...';
                $rootScope.api_status('waiting', msgEn, msgFr);
                const promise = api.service_delete('toolkit', `document-manager/tags/${id}`);
                promise.then((response) => {
                  if (response.data.status === 'success') {
                    fetchTags();
                    msgEn = 'Tag deleted';
                    msgFr = 'Étiquette supprimée';
                    $rootScope.api_status('alert-success', msgEn, msgFr);
                  }
                }).catch(() => {
                  $rootScope.api_status('alert-danger');
                });
              },
            },
            no: {
              text: $scope.out('Non', 'No'),
              btnClass: 'btn btn-alt-danger',
              action() {},
            },
          },
        });
      }

      // --------------assign Tag-------------
      function assignTag() {
        $scope.selectedTags = [];
        msgEn = 'Assign tag';
        msgFr = 'Ajouter une étiquette';
        $rootScope.api_status('waiting', msgEn, msgFr);
        const modal = $uibModalStack.getTop();
        modal.key.dismiss();
        angular.forEach($scope.tags, (t) => {
          if (t.selected) {
            $scope.selectedTags.push(t.id);
          }
        });
        const data = {
          dm_file_id: $scope.fileId,
          dm_tag_id: $scope.selectedTags,
        };
        const promise = api.service_post('toolkit', 'document-manager/tag-files', data);
        promise.then((response) => {
          if (response.data.status === 'success') {
            msgEn = 'Tag assigned successfully';
            msgFr = 'Étiquette attribuée avec succès';
            $rootScope.api_status('alert-success', msgEn, msgFr);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
        });
      }
      function closeModal() {
        const modal = $uibModalStack.getTop();
        modal.key.dismiss();
      }

      init();
  }
  AtlasDriveTagsCtrl.$inject = ['$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
    'api',
    '$uibModalStack',
    '$ngConfirm',
  ];
  angular.module('atlas')
    .controller('AtlasDriveTagsCtrl', AtlasDriveTagsCtrl)
    .directive('atlasDriveTags', () => ({
      scope: {

      },
      controller: AtlasDriveTagsCtrl,
      templateUrl: './employer-profile/atlas-drive/atlas-drive-tags/atlas-drive-tags.template.html',
    }));
}(angular));
