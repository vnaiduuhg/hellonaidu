(function (angular) {
  function AtlasDriveViewCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    $sce,
    worklandLocalize,
    MetaTagsService,
    $state,
    api,
    $uibModal,
    $ngConfirm,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
    let scope = {
      strings: worklandLocalize.strings,
      out: utils.out,
      trustAsHtml: utils.trustAsHtml,
      fileUpload: { file: {} },
      categoriesList: [{
        id: 0,
        translation: {
          en: { title: 'All' },
          fr: { title: 'Tous' },
        },
      }],
      tagList: [{
        id: 0,
        colour: '#dee2e6',
        translation: {
          en: { title: 'All' },
          fr: { title: 'Tous' },
        },
      }],
      selectedCategory: {},
      selectedTag: {},
      directoryTrack: [{
        id: 1,
        name: utils.out('Accueil', 'Home'),
      }],
      reverse: false,
      counter: 0,
      currentDirectory: 1,
      currentDirectoryName: '',
      iconFolder: './../assets/images/icon-folder.png',
      iconFolderHover: './../assets/images/icon-folder-hover.png',
    };
    angular.extend($scope, scope);

    let msgEn; let msgFr;
    let titleEn; let titleFr;

    $scope.tagHandler = function (tag) {
      return null;
    };

    function filterByTagCategory() {
      const filesArray = $scope.originalFilesArray;
      const { selectedCategory } = $scope;
      const { selectedTag } = $scope;
      const filteredSet = [];

      // if category === "All" and Tag === "All" or a placeholder is shown (no option) for both
      if (!(selectedCategory.info?.id || selectedTag.info?.id) || (selectedCategory.info?.id === 0 && selectedTag.info?.id === 0)) {
        return filesArray;
      }
      angular.forEach(filesArray, (file) => {
        if ((file.categoryId === selectedCategory.info?.id || selectedCategory.info?.id === 0 || !selectedCategory.info?.id)
                    && (_.findIndex(file.file_tags, (tag) => tag.dm_tag_id === selectedTag.info?.id) !== -1 || selectedTag.info?.id === 0 || !selectedTag.info?.id)) {
          filteredSet.push(file);
        }
      });

      return filteredSet;
    }

    function fetchCategories() {
      $scope.loadingCategories = true;
      const promise = api.service_get('toolkit', 'document-manager/categories');
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.categoriesList = $scope.categoriesList.concat(response.data.data.result);
        }
        $scope.loadingCategories = false;
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        $scope.categoriesList = [];
        $scope.loadingCategories = false;
      });
    }

    // Drag &Drop file
    function getTempFoldersArray() {
      $scope.foldersArray = [];
      _.each($scope.directories, (folder) => {
        const getFolder = {
          id: folder.id,
          name: folder.name,
        };
        $scope.foldersArray.push(getFolder);
      });
    }

    function fetchDirectories(id) {
      $scope.dirLoaded = false;
      const promise = api.service_get('toolkit', `document-manager/directories?filter_by_parent_id=${id}`);
      promise.then((response) => {
        $scope.dirLoaded = true;
        if (response.data.status === 'success') {
          $scope.directories = response.data.data.result.sort((a, b) => a.name.localeCompare(b.name, 'fr'));
          // $scope.directoriesDrop = angular.copy($scope.directories); //not used yet
          if (id !== 1) {
            $scope.selectDirectories = angular.copy($scope.directories); // used when uploading files
            $scope.selectDirectories.push({
              id: 1,
              name: $scope.out('Accueil', 'Home'),
            });
          } else {
            $scope.selectDirectories = angular.copy($scope.directories);
          }
        }
      }).then(() => {
        getTempFoldersArray();
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        $scope.dirLoaded = true;
      });
    }

    // Fetch all created tags
    function fetchAllTags() {
      const promise = api.service_get('toolkit', 'document-manager/tags');
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.tags = response.data.data.result;
          $scope.counter += 1;
          if ($scope.counter === 1) {
            angular.forEach($scope.tags, (tag) => {
              $scope.tagList.push(tag);
            });
          }
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function injectAssignedTagIds() {
      const { filesArray } = $scope;
      angular.forEach(filesArray, (file) => {
        const fileTags = [];
        angular.forEach($scope.assignedTags, (tag) => {
          if (file.dm_file_id === tag.dm_file_id) {
            const dm_tag_id = { dm_tag_id: tag.dm_tag_id };
            fileTags.push(dm_tag_id);
          }
        });
        file.file_tags = fileTags;
      });
      // $scope.filesArray = filesArray;
      $scope.originalFilesArray = filesArray;
      $scope.filesArray = filterByTagCategory();
    }

    // Fetch all tags assinged to files
    function fetchAssignedTags() {
      fetchAllTags();
      const promise = api.service_get('toolkit', 'document-manager/tag-files');
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.assignedTags = response.data.data.result;
          injectAssignedTagIds();
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        $scope.assignedTags = [];
      });
    }

    function getTempFilesArray() {
      $scope.filesArray = [];
      angular.forEach($scope.files, (file) => {
        if (file.file_version.length > 0) {
          const tempfile = {
            id: file.file_version[0].id,
            dm_file_id: file.id,
            name: file.file_version[0].file_name,
            originalFile: file.file_version[0].original_file,
            directoryId: file.dm_directory_id,
            categoryId: file.dm_category_id,
          };
          $scope.filesArray.push(tempfile);
        }
      });
      $scope.filesArray.sort((a, b) => a.name.localeCompare(b.name, 'fr'));
      $scope.filesArrayDrop = angular.copy($scope.filesArray);
      fetchAssignedTags();
    }

    function fetchFiles(id) {
      $scope.fileLoaded = false;
      const promise = api.service_post('toolkit', `document-manager/files/file_type_data?filter_by_dm_directory_id=${id}`);
      promise.then((response) => {
        $scope.fileLoaded = true;
        if (response.data.status === 'success') {
          $scope.files = response.data.data.result;
        }
      }).then(() => {
        getTempFilesArray();
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        $scope.fileLoaded = true;
      });
    }

    function createFolder(folderName) {
      msgEn = 'Creating your folder...';
      msgFr = 'Création de votre dossier en cours...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const data = {
        name: folderName,
        description: 'null',
        parent_id: $scope.currentDirectory,
        is_system: 0,
      };
      const promise = api.service_post('toolkit', 'document-manager/directories', data);
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchDirectories($scope.currentDirectory);
          msgEn = 'Folder created';
          msgFr = 'Dossier créé';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function createDirectoryModal() {
      $scope.folderTitle = '';
      const createDirectoryInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/atlas-drive/modal-templates/create-directory.template.html',
        scope: $scope,
        size: 'md',
      });
      createDirectoryInstance.result.then((folderName) => {
        if (!folderName) {
          $scope.emptyFolderName = true;
          createDirectoryModal();
        } else {
          $scope.promise = createFolder(folderName);
        }
      });
    }

    function renameFolder(folderName, folderId) {
      msgEn = 'Renaming your folder...';
      msgFr = 'Mise à jour de votre dossier en cours...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const data = {
        name: folderName,
        description: 'null',
        parent_id: $scope.currentDirectory,
        is_system: 0,
      };
      const promise = api.service_post('toolkit', `document-manager/directories/${folderId}`, data, 'update');
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchDirectories($scope.currentDirectory);
          msgEn = 'Folder updated';
          msgFr = 'Dossier mis à jour';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function renameDirectoryModel(folderName, folderId) {
      $scope.editMode = true;
      $scope.folderTitle = folderName;
      const renameDirectoryInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/atlas-drive/modal-templates/create-directory.template.html',
        scope: $scope,
        size: 'sm',
      });
      renameDirectoryInstance.result.then((folderName) => {
        if (!folderName) {
          $scope.emptyFolderName = true;
          renameDirectoryModel(folderName, folderId);
        } else {
          $scope.editMode = false;
          $scope.promise = renameFolder(folderName, folderId);
        }
      });
    }

    function validateFileName() {     
      if ($scope.fileTitle) {
        $scope.emptyFileName = false;
        return true; 
      } else  {
        $scope.emptyFileName = true;
        return false;
      }
    }

    function renameFile() {
      if (validateFileName()) {
        renameFileInstance.dismiss('cancel');                    
        msgEn = 'Renaming your file...';
        msgFr = 'Mise à jour de votre fichier en cours...';
        $rootScope.api_status('waiting', msgEn, msgFr);
        const promise = api.service_post('toolkit', `document-manager/file-versions/${$scope.fileId}?file_name=${$scope.fileTitle}`, {}, 'update');
        promise.then((response) => {
          if (response.data.status === 'success') {
            fetchDirectories($scope.currentDirectory);
            msgEn = 'File updated';
            msgFr = 'Fichier mis à jour';
            $rootScope.api_status('alert-success', msgEn, msgFr);
            fetchFiles($scope.currentDirectory);
            fetchAssignedTags();
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
        });
      }
    }

    let renameFileInstance;
    function renameFileModal(fileName, fileId) {
      $scope.fileTitle = fileName;
      $scope.fileId = fileId;
      $scope.emptyFileName = false;
      renameFileInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/atlas-drive/modal-templates/rename-file.template.html',
        scope: $scope,
        size: 'sm',
      });     
    }

    function openDirectory(id, name) {
      $scope.directoryTrack.push({ id, name });
      $scope.currentDirectory = id;
      $scope.currentDirectoryName = name;
      fetchDirectories($scope.currentDirectory);
      fetchFiles($scope.currentDirectory);
    }

    function ShowContextMenu(evt, type, isFile) {
      if (!type.openOptions) {
        switch (evt.which) {
          case 1:
            if (!isFile) {
              openDirectory(type.id, type.name);
            }

            // this is left click
            break;
          case 2:

            // in case you need some middle click things
            break;
          case 3:
            type.openOptions = true; // this is right click
            break;
          default:
            // alert('you have a strange mouse!');
            break;
        }
      }
    }

    function showConfirmDeletion(title, action, id) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: title,
        content: $scope.out('Êtes-vous sûr de vouloir supprimer?', 'Are you sure you want to delete?'),
        type: 'red',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          yes: {
            text: $scope.out('Oui', 'Yes'),
            btnClass: 'btn btn-danger float-end',
            action() {
             switch (action) {
              case 'folder':
                deleteDirective(id);
                break;
              case 'file':
                deleteFile(id);
                break;
             }
            },
          },
          no: {
            text: $scope.out('Non', 'No'),
            btnClass: 'btn btn-alt-danger',
            action() {},
          },
        },
      });
    }

    function deleteDirective(id) {      
      msgEn = 'Deleting your folder...';
      msgFr = 'Suppression de votre dossier en cours...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const promise = api.service_delete('toolkit', `document-manager/directories/${id}`);
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchDirectories($scope.currentDirectory);
          msgEn = 'Folder deleted';
          msgFr = 'Dossier supprimé';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });          
    }

    function deleteFile(file) {
      msgEn = 'Deleting your file...';
      msgFr = 'Suppression de votre fichier en cours...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const promise = api.service_delete('toolkit', `document-manager/file-versions/${file.id}`);
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchFiles($scope.currentDirectory);
          msgEn = 'File deleted';
          msgFr = 'Fichier supprimé';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function confirmDeletion(type, id) {
      if (type === 'file') showConfirmDeletion($scope.out('Suppression du fichier', 'Delete file'), type, id);
      if (type === 'folder') showConfirmDeletion( $scope.out('Suppression du dossier', 'Delete folder'), type, id);
    }

    function openFile(id) {
      $scope.showDocLoadingError = false;
      $scope.showPdfLoadingError = false;
      msgEn = 'Opening your file...';
      msgFr = 'Ouvrir votre fichier...';
      $rootScope.api_status('waiting', msgEn, msgFr);           
      const promise = api.service_post('toolkit', `document-manager/file-versions/download/${id}`, {});
      promise.then((response) => {
        
        const index = $scope.filesArray.map((file) => file.id).indexOf(id);
        const extension = $scope.filesArray[index].name.toLowerCase().split('.').pop();
        const docUrl = response.data;

        switch (extension) {
          case 'pdf':
            $scope.loadingDoc = true;           
            $scope.openFileUrl = '';
            $scope.imgUrl = '';
            $scope.textUrl = '';
            const loadingTask = pdfjsLib.getDocument(docUrl);
            loadingTask.promise.then((pdf) => {
              const pagePromises = _.range(1, pdf.numPages + 1).map((number) => pdf.getPage(number));
              return Promise.all(pagePromises);
            }).then((pages) => {
              const scale = 1.5;
              pages.forEach((page) => {
                const viewport = page.getViewport({ scale });
                const canvasContainer = window.document.getElementById('canvasContainer');

                $('#canvasContainer').append(`<canvas class='canvasClass' style='width:100%;' id='canvas${page._pageIndex}'></canvas>`);
                const canvas = window.document.getElementById(`canvas${page._pageIndex}`);
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                const canvasContext = canvas.getContext('2d');
                const renderContext = {
                  canvasContext,
                  viewport,
                };
                page.render(renderContext);
                window.document.getElementById('canvasContainer').appendChild(canvas);
                $scope.canvasContainer = canvasContainer;
              });
              $scope.loadingDoc = false;
            },
            (error) => {
              $scope.showPdfLoadingError = true;
              $scope.loadingDoc = false;
            });
            break;
          case 'ppt':
          case 'pptx':
          case 'doc':
          case 'docx':
          case 'xls':
          case 'xlsx':
          case 'odt':

            $scope.imgUrl = '';
            $scope.textUrl = '';
            const docxUrlCode = encodeURIComponent(docUrl);
            const baseUrl = 'https://view.officeapps.live.com/op/embed.aspx?&src=';
            // const params = {
            //   url: docxUrlCode,
            //   embedded: true,
            // };
            $scope.openFileUrl = $sce.trustAsResourceUrl(baseUrl + docxUrlCode);

            break;
          case 'png':
          case 'tif':
          case 'tiff':
          case 'bmp':
          case 'jpg':
          case 'jpeg':
          case 'gif':
            $scope.openFileUrl = '';
            $scope.textUrl = '';
            $scope.imgUrl = docUrl;
            break;
          case 'txt':
            $scope.openFileUrl = '';
            $scope.imgUrl = '';
            const output = document.createElement('TEXTAREA');
            this.href = docUrl;
            $.ajax(this.href).done((data) => {
              output.textContent = data;
              $scope.textUrl = output.textContent;
            });
            break;
          // no default
        }
        $uibModal.open({
          animation: true,
          templateUrl: './employer-profile/atlas-drive/modal-templates/view-file.template.html',
          scope: $scope,
          size: 'lg',
        });
        $rootScope.api_status('alert-success');
      }).catch(() => {
        $scope.showDocLoadingError = true;
        $rootScope.api_status('alert-danger');
      });
    }

    function switchDirectory(id, name, index) {
      $scope.directoryTrack.splice(index);
      $scope.directoryTrack.push({ id, name });
      $scope.currentDirectory = id;
      $scope.currentDirectoryName = name;
      fetchDirectories($scope.currentDirectory);
      fetchFiles($scope.currentDirectory);
    }

    let createFileInstance;

    function uploadFileModal() {
      $scope.fileUpload = {};
      $scope.fileSelected = null;
      $scope.emptyCategory = false;
      $scope.dateError = false;
      createFileInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/atlas-drive/modal-templates/upload-file.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function validateExpiryDate() {
      const date = new Date();
      const fromDate = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
      const minDate = utils.formatDate(fromDate);
      if (!$scope.fileUpload.expiryDate || $scope.fileUpload.expiryDate >= minDate) {
        return true;
      }
      $scope.dateError = true;
      return false;
    }

    function isFileFormatValid(file) {
      const ext = file.toLowerCase().split('.').pop();
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'odt' || ext === 'txt'
                || ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'xlsx'
                || ext === 'xls' || ext === 'pptx' || ext === 'ppt') {
        return true;
      }
      return false;
    }

    function isFileSizeValid(size) {
      if (size > 0 && size / (1048576) <= 5) {
        return true;
      }
      return false;
    }

    function isFileFormatImage(file) {
      const ext = file.toLowerCase().split('.').pop();
      if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif') {
        return true;
      }

      return false;
    }

    function clearFileValidationErrors() {
      $scope.haveError = false;
      $scope.emptyCategory = false;
      $scope.emptyFileName = false;
      $scope.emptyFileUrl = false;
      $scope.emptyFile = false;
    }

    function validateFileInfo(file) {
      if (file) $scope.fileSelected = file;
      clearFileValidationErrors();
      $scope.haveError = false;
      if (!$scope.fileUpload.categoryId) {
        $scope.emptyCategory = true;
        $scope.haveError = true;
      }
      if ($scope.fileUpload.source === 'url') {
        if (!$scope.fileUpload.fileName) {
          $scope.emptyFileName = true;
          $scope.haveError = true;
        }
        if (!$scope.fileUpload.url) {
          $scope.emptyFileUrl = true;
          $scope.haveError = true;
        }
      } else if (!$scope.fileSelected && !file) {
        $scope.emptyFile = true;
        $scope.haveError = true;
      } else if ((file && (!isFileFormatValid(file.name) || !isFileSizeValid(file.size)))
                || ($scope.fileSelected && (!isFileFormatValid($scope.fileSelected.name) || !isFileSizeValid($scope.fileSelected.size)))) {
        $scope.haveError = true;
      }
      if ($scope.haveError) {
        return false;
      }
      return true;
    }

    function uploadFile(file, id) {
      const data = {
        dm_file_id: id,
        upload_type: file.source,
        file_name: file.source === 'url' ? file.fileName : $scope.fileSelected.name.split('.')[0],
        url_link: file.source === 'url' ? file.url : '',
        watermark: 0,
        is_deleted: 0,
        file: file.source === 'file' ? $scope.fileSelected : '',
      };
      let promise = '';
      if (file.source === 'url') {
        promise = api.service_post('toolkit', 'document-manager/file-versions', data);
      } else {
        promise = api.toolkit_fileupload('document-manager/file-versions', data);
      }
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchFiles($scope.currentDirectory);
          titleEn = 'Uploaded';
          titleFr = 'Téléchargé';
          msgEn = 'Your file uploaded successfully';
          msgFr = 'Votre fichier téléversé avec succès';
          $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
          $scope.fileSelected = null;
        }
      }).catch((error) => {
        msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
        msgEn = "A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance";
        if(error.status === 400) {
          if(error.data?.data?.message?.file && error.data.data.message.file[0] === 'validation.max.file') {
              msgEn = "Sorry! Your file has a wrong size, please upload a file greater than 0 and smaller than 5 MB";
              msgFr = "Désolé! Votre fichier a une taille invalide, veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 5 Mo";
          }
          else if (error.data?.message?.file && error.data.message.file[0] === 'validation.clamav') {
              msgEn = "Sorry! This file is invalid, please upload a new file";
              msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
          }
        }
        $rootScope.api_status('alert-danger', msgEn, msgFr, "", "", 5000);
      });
    }

    function createFile() {
      if (validateFileInfo() && validateExpiryDate()) {
        createFileInstance.dismiss('cancel');
        msgEn = 'Uploading your file...';
        msgFr = 'Téléversement de votre fichier en cours...';
        $rootScope.api_status('waiting', msgEn, msgFr);
        const data = {
          comment: $scope.fileUpload.commentText ? $scope.fileUpload.commentText : ($scope.fileUpload.source === 'url' ? $scope.fileUpload.fileName : $scope.fileSelected.name),
          dm_category_id: $scope.fileUpload.categoryId,
          dm_directory_id: $scope.fileUpload.directoryId ? $scope.fileUpload.directoryId : $scope.currentDirectory,
          is_deleted: 0,
          password: '',
        };
        if ($scope.fileUpload.expiryDate) data.expiry_date = $scope.fileUpload.expiryDate;
        const promise = api.service_post('toolkit', 'document-manager/files', data);
        promise.then((response) => {
          if (response.data.status === 'success') {
            uploadFile($scope.fileUpload, response.data.data.result.id);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
        });
      }
    }

    $scope.clearFileModel = () => {
      $scope.fileSelected = null;
    };

    // Open the "Manage Tag" modal
    function openManageTagModal(fileName, fileId) {
      $scope.fileTitle = fileName;
      $scope.manageTagMode = true;
      $scope.fileName = fileName;
      $scope.fileId = fileId;
      $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/atlas-drive/modal-templates/manage-tags.template.html',
        scope: $scope,
        size: 'sm',
      });
    }

    // Assign the selected tag to the file
    function assignTag(fileId, tagId) {
      msgEn = 'Assign tag';
      msgFr = 'Ajouter une étiquette';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const data = {
        dm_file_id: fileId,
        dm_tag_ids: [tagId],
      };
      const promise = api.service_post('toolkit', 'document-manager/tag-files', data);
      promise.then((response) => {
        if (response.data.status === 'success') {
          fetchFiles($scope.currentDirectory);
          msgEn = 'Tag assigned successfully';
          msgFr = 'Étiquette attribuée avec succès';
          $rootScope.api_status('alert-success', msgEn, msgFr);
          fetchFiles($scope.currentDirectory);
          fetchAssignedTags();
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    // unassign tag
    function removeTag(fileId, tagId) {
      msgEn = 'Deleting tag';
      msgFr = 'Suppression de l\'étiquette';
      // Find the tag file id to remove
      for (let i = 0; i < $scope.assignedTags.length; i += 1) {
        if ($scope.assignedTags[i].dm_file_id == fileId && $scope.assignedTags[i].dm_tag_id == tagId) {
          $scope.tagFileIdToRemove = $scope.assignedTags[i].id;
          break;
        }
      }
      $rootScope.api_status('waiting', msgEn, msgFr);
      const promise = api.service_delete('toolkit', `document-manager/tag-files/${$scope.tagFileIdToRemove}`);
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'Tag removed successfully';
          msgFr = 'Étiquette supprimée avec succès';
          $rootScope.api_status('alert-success', msgEn, msgFr);
          fetchFiles($scope.currentDirectory);
          fetchAssignedTags();
        }
      }).catch(() => {
        msgEn = 'An error has occurred while removing the tag.';
        msgFr = 'Une erreur est survenue lors de la suppression de l\'étiquette.';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
      });
    }

    // UManage tag-id of the file
    function manageTags(fileId) {
      // fetch old assigned tags of file id
      $scope.oldAssignetTagsOfFile = [];
      for (let i = 0; i < $scope.assignedTags.length; i += 1) {
        if ($scope.assignedTags[i].dm_file_id == fileId) {
          $scope.oldAssignetTagsOfFile.push($scope.assignedTags[i].dm_tag_id);
        }
      }

      // check if tag already assign than return if not add new assign Tag
      for (let i = 0; i < $scope.tagIdOfFiles.length; i += 1) {
        const addTagId = $scope.tagIdOfFiles[i];
        if ($scope.oldAssignetTagsOfFile.indexOf(addTagId) === -1) {
          assignTag(fileId, addTagId);
          fetchAssignedTags();
        }
      }

      // check if old tag have in new assigned tag than return if not remove it
      for (let i = 0; i < $scope.oldAssignetTagsOfFile.length; i += 1) {
        const remTagId = $scope.oldAssignetTagsOfFile[i];
        if ($scope.tagIdOfFiles.indexOf(remTagId) === -1) {
          removeTag(fileId, remTagId);
          fetchAssignedTags();
        }
      }
    }

    // Get the tag corresponds to the file
    function getTagsInfo(fileId) {
      let i;
      $scope.tagIdOfFiles = [];
      for (i = 0; i < $scope.assignedTags.length; i += 1) {
        if ($scope.assignedTags[i].dm_file_id == fileId) {
          $scope.tagIdOfFiles.push($scope.assignedTags[i].dm_tag_id);
        }
      }
    }

    // AngularJS ng-sortable function
    // $scope.sortableOptions = {
    //   itemMoved(event) {
    //     if (event.dest.index >= 0) {}
    //   },
    //   containment: 'conteiner-list-files',
    //   clone: false,
    //   allowDuplicates: false,
    // };
    // Sort files and folders by name
    function sortBy() {
      $scope.reverse = !$scope.reverse;
    }

    // Get type of file for icon
    function getTypeOfFile(name) {
      const noExtention = 'file';
      const ext = name.toLowerCase().split('.').pop();
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'odt' || ext === 'txt'
                || ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'xlsx'
                || ext === 'xls' || ext === 'pptx' || ext === 'ppt') {
        return ext;
      }
      return noExtention;
    }

    function selectTag(tagId) {
      $scope.limitOfTags = false;     
      const index = $scope.tagIdOfFiles.indexOf(tagId);
      if (index < 0) {
        $scope.tagIdOfFiles.push(tagId);       
      } else {
        $scope.tagIdOfFiles.splice(index, 1);
      }
      // Validate for tags of one files
      if ($scope.tagIdOfFiles.length > 10) {
        $scope.limitOfTags = true;
      }
    }

    // Check whether the current tag corresponds to the file(in the 'Edit Tag' modal)
    function getAssignedTag(fileId, tagId) {
      // Get the tagid of the selected file:
      for (let i = 0; i < $scope.assignedTags.length; i += 1) {
        if ($scope.assignedTags[i].dm_file_id == fileId && $scope.assignedTags[i].dm_tag_id == tagId) {
          return true;
        }
      }
    }

    $('#closemodal').click(() => {
      $('#modalwindow').modal('hide');
    });

    $scope.$watch('selectedCategory', (newValue, oldValue) => {
      if (newValue !== oldValue) {
        $scope.filesArray = filterByTagCategory();
      }
    }, true);

    $scope.$watch('selectedTag.info', (newValue, oldValue) => {
      if (newValue !== oldValue) {
        $scope.filesArray = filterByTagCategory();
      }
    });

    function init() {
      fetchCategories();
      fetchDirectories(1);
      fetchFiles(1);
    }

    init();

    scope = {
      fetchCategories,
      fetchDirectories,
      fetchFiles,
      createDirectoryModal,
      createFolder,
      uploadFileModal,
      createFile,
      uploadFile,
      ShowContextMenu,
      confirmDeletion,
      renameDirectoryModel,
      renameFolder,
      renameFileModal,
      renameFile,
      openDirectory,
      fetchAllTags,
      assignTag,
      manageTags,
      fetchAssignedTags,
      openManageTagModal,
      selectTag,
      getTagsInfo,
      getTypeOfFile,
      openFile,
      switchDirectory,
      removeTag,
      getAssignedTag,
      validateExpiryDate,
      getTempFoldersArray,
      getTempFilesArray,
      sortBy,
      isFileFormatImage,
      injectAssignedTagIds,
      filterByTagCategory,
      validateFileInfo,
      validateFileName,
    };
    angular.extend($scope, scope);
  }
  AtlasDriveViewCtrl.$inject = ['$scope',
    '$rootScope',
    'utils',
    '_',
    '$sce',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
    'api',
    '$uibModal',
    '$ngConfirm',
  ];
  angular.module('atlas').directive('atlasDriveView', () => ({
    scope: {},
    controller: AtlasDriveViewCtrl,
    templateUrl: './employer-profile/atlas-drive/atlas-drive-view/atlas-drive-view.template.html',
  }));
}(angular));
