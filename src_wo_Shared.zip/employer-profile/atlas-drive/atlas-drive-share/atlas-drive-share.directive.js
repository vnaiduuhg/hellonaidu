(function (angular) {
  function AtlasDriveShareCtrl(
    $scope,
    utils,
    _,
    worklandLocalize,
    MetaTagsService,
    $state,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
      const scope = {
        strings: worklandLocalize.strings,
        out: utils.out,
        trustAsHtml: utils.trustAsHtml,
      };
      angular.extend($scope, scope);

      function init() {

      }

      init();
  }
  AtlasDriveShareCtrl.$inject = [
    '$scope',
    'utils',
    '_',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
  ];
  angular.module('atlas')
    .directive('atlasDriveShare', () => ({
      scope: {
      },
      controller: AtlasDriveShareCtrl,
      templateUrl: './employer-profile/atlas-drive/atlas-drive-share/atlas-drive-share.template.html',
    }));
}(angular));
