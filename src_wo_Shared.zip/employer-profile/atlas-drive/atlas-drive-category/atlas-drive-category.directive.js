(function (angular) {
  function AtlasDriveCategoryCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    MetaTagsService,
    $state,
    api,
    $ngConfirm,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
      const scope = {
        strings: worklandLocalize.strings,
        out: utils.out,
        trustAsHtml: utils.trustAsHtml,
        category: { en: '', fr: '' },
        updated: { en: '', fr: '' },
        fetchCategories,
        createCategory,
        deleteCategory,
        editModeOn,
        editModeOff,
        categories: [],
      };
      angular.extend($scope, scope);

      let msgEn; let msgFr;

      function editModeOn(category) {
        $scope.editMode = {};
        $scope.editMode.id = category.id;
        $scope.updated.en = category.translation.en.title;
        $scope.updated.fr = category.translation.fr.title;
        $scope.updated.frError = false;
        $scope.updated.enError = false;
      }

      function editModeOff() {
        $scope.updated = { en: '', fr: '' };
        $scope.editMode = {};
      }

      function fetchCategories() {
        $scope.loadingCategories = true;
        const promise = api.service_get('toolkit', 'document-manager/categories');
        promise.then((response) => {
          $scope.loadingCategories = false;
          if (response.data.status === 'success') {
            $scope.categories = response.data.data.result;
          }
        }).catch(() => {
          $scope.loadingCategories = false;
        });
      }

      function createCategory(currentCat, isUpdate) {
        let data = {};
        let url = '';
        $scope.hasEnError = false;
        $scope.hasFrError = false;
        $scope.updated.frError = false;
        $scope.updated.enError = false;
        if (isUpdate) {
          if (!$scope.updated.en) {
            $scope.updated.enError = true;
          } else {
            $scope.updated.enError = false;
          }
          if (!$scope.updated.fr) {
            $scope.updated.frError = true;
          } else {
            $scope.updated.frError = false;
          }
        } else {
          if (!$scope.category.en) {
            $scope.hasEnError = true;
          } else {
            $scope.hasEnError = false;
          }
          if (!$scope.category.fr) {
            $scope.hasFrError = true;
          } else {
            $scope.hasFrError = false;
          }
        }

        if (!$scope.hasEnError && !$scope.hasFrError && !$scope.updated.enError && !$scope.updated.frError) {
          if (isUpdate) {
            msgEn = 'Updating your category...';
            msgFr = 'Mise à jour de votre categorie...';
            $rootScope.api_status('waiting', msgEn, msgFr);

            data = {
              en: {
                title: $scope.updated.en,
                description: $scope.updated.en,
              },
              fr: {
                title: $scope.updated.fr,
                description: $scope.updated.fr,
              },
              is_system: 0,
              parent_id: 0,

            };
            url = `document-manager/categories/${currentCat.id}`;
          } else {
            msgEn = 'Created a new category';
            msgFr = 'Créé une nouvelle catégorie';
            $rootScope.api_status('waiting', msgEn, msgFr);
            data = {
              en: {
                title: $scope.category.en,
                description: $scope.category.en,
              },
              fr: {
                title: $scope.category.fr,
                description: $scope.category.fr,
              },
              is_system: 0,
              parent_id: 0,

            };
            url = 'document-manager/categories';
          }
          const promise = api.service_post('toolkit', url, data, isUpdate);
          promise.then((response) => {
            if (response.data.status === 'success') {
              $scope.category = { en: '', fr: '' };
              if (isUpdate) {
                msgEn = 'Category is successfully updated';
                msgFr = 'La catégorie a été mise à jour avec succès';
              } else {
                msgEn = 'Category is successfully created';
                msgFr = 'La catégorie a été créée avec succès';
              }
              $rootScope.api_status('alert-success', msgEn, msgFr);
              editModeOff();
              fetchCategories();
            }
          }).catch(() => {
            $rootScope.api_status('alert-danger');
          });
        }
      }

      function deleteCategory(id) {
        $ngConfirm({
          icon: 'fa fa-exclamation',
          title:  $scope.out('Suppression de la catégorie', 'Delete category'),
          content: $scope.out('Êtes-vous sûr de vouloir supprimer?', 'Are you sure you want to delete?'),
          type: 'red',
          typeAnimated: true,
          animation: 'RotateX',
          buttons: {
            yes: {
              text: $scope.out('Oui', 'Yes'),
              btnClass: 'btn btn-danger float-end',
              action() {
                msgEn = 'We are deleting your category...';
                msgFr = 'Supression de votre catégorie...';
                $rootScope.api_status('waiting', msgEn, msgFr);
                const promise = api.service_delete('toolkit', `document-manager/categories/${id}`);
                promise.then((response) => {
                  if (response.data.status === 'success') {
                    fetchCategories();
                    msgEn = 'Category is successfully deleted';
                    msgFr = 'La catégorie a été supprimée avec succès';
                    $rootScope.api_status('alert-success', msgEn, msgFr);
                  }
                }).catch(() => {
                  $rootScope.api_status('alert-danger');
                });
              },
            },
            no: {
              text: $scope.out('Non', 'No'),
              btnClass: 'btn btn-alt-danger',
              action() {},
            },
          },
        });
      }
     
      function init() {
        fetchCategories();
      }

      init();
  }
  AtlasDriveCategoryCtrl.$inject = ['$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
    'api',
    '$ngConfirm',
  ];
  angular.module('atlas')
    .directive('atlasDriveCategory', () => ({
      scope: {
      },
      controller: AtlasDriveCategoryCtrl,
      templateUrl: './employer-profile/atlas-drive/atlas-drive-category/atlas-drive-category.template.html',
    }));
}(angular));
