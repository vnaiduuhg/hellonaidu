(function (angular) {
  function HistoryModuleCtrl($scope, $rootScope, api, utils, _) {
    const scope = {
      out: utils.out,
      language: $rootScope.language,
      jobFlag: false,
      defaultJobListOptionHistory: {
        id: -1,
        titleFr: 'Historique complet',
        titleEn: 'Entire history',
        locations: []
      },
      filterJob: { selected: {} },
      currentAccountJobsList: [],
      locationIdsList: [],
    };
    angular.extend($scope, scope);

    $scope.tagHandler = (tag) => null;

    function prepareHistoryData() {
      const hitsArr = [];
      if ($scope.source !== 'questionnaire') {
        if ($scope.currentAccountJobsList.length > 0) {
          const jobListIds = _.pluck($scope.currentAccountJobsList, 'id');
          _.each($scope.searchResults, (hit) => {
            if (jobListIds.includes(parseInt(hit._source.context.actionOn, 10))) {
              hitsArr.push(hit);
            }
          });
          return hitsArr;
        } else {
          return [];
        }
      }
      if ($scope.source === 'questionnaire') {
        _.each($scope.searchResults, (hit) => {
          if (['Question added', 'Question removed'].includes(hit._source.context.action)) {
            hit._source.context.details.question = _.find($scope.questionsList, (q) => q.id === (hit._source.context.action === 'Question added'
              ? hit._source.context.details.request_data.question_id
              : hit._source.context.details.response_data.data.result.object.question_id));
          }
          if (hit._source.context.action === 'Questionnaire updated') {
            hit._source.context.details.questionnaire = hit._source.context.details.response_data.data.result.object;
          }
        });
      }
      return $scope.searchResults;
    }

    function loadLogs(url, data) {
      api.service_post('shared', url, data).then((response) => {
        $scope.searchResults = response.data.hits;
        $scope.logs = prepareHistoryData();
      }).catch(() => {
        $scope.logs = [];
      });
    }

    function beforeToLoadLogs(hasJobSelected) {
      $scope.logs = null;
      $scope.jobFlag = false;
      let url = 'history/search';
      let data = {};
      switch ($scope.source) {
        case 'questionnaire':
          url = 'history/questionnaire/search';
          data = { id: $scope.currentQuestionnaire.id };
          break;
        // crm & candidate enter default case
        default:
          if (!hasJobSelected) {
            $scope.filterJob.selected = $scope.defaultJobListOptionHistory;
          }
          data = { candidate_id: $scope.candidate.user_id };
          if ($scope.filterJob.selected.id && $scope.filterJob.selected.id > -1) {
            $scope.jobFlag = true;
            data.job_id = $scope.filterJob.selected.id;
          }
      }
      loadLogs(url, data);
    }

    function loadLogsWithJob(job) {
      $scope.filterJob.selected = job;
      beforeToLoadLogs(true);
    }

    function setLocationsToJobList() {
      _.each($scope.currentAccountJobsList, (job) => {
          if (job.locations.length) {
              const jobLocation = _.find($scope.locationIdsList, (location) => +job.locations[0].location_id === +location.id);
              if (jobLocation) {
                  job.address = ` ${jobLocation.street_number && jobLocation.street ? `${jobLocation.street_number} ${jobLocation.street}` : ''
                  }${jobLocation.city ? (jobLocation.street_number && jobLocation.street ? ', ' : '')
                      + jobLocation.city : (jobLocation.street_number && jobLocation.street ? ', ' : '') + jobLocation.region
                  }${jobLocation.country ? `, ${jobLocation.country}` : ''} `;
              }
          }
      });
    }

    fetchLocations = (locationIdsArray) => {
      api.service_get('shared', 'location/list-by-key-and-values', {
          key: 'id',
          'values[]': locationIdsArray,
        }).then((response) => {
        if (response.status === 200) {
          $scope.locationIdsList = response.data;
          if (Object.keys($scope.locationIdsList).length > 0) {
            setLocationsToJobList();
          }
        } else {
          $rootScope.api_status(
            'alert-danger',
            'A problem occurred and the list of jobs locations could not be retrieved',
            'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
          );
        }
      }).catch(() => {
        $rootScope.api_status(
          'error',
          'A problem occurred and the list of jobs locations could not be retrieved',
          'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
        );
      });
    }

    function getJobsList() {
      $scope.jobsListLoading = true;
      api.service_get('jobs', `job/accounts/${$rootScope.currentUser.account.id}/job-titles`).then((res) => {
        if (res.data && res.data.length > 0) {
          const tempArrayOfJobs = res.data;
          let privateJobs = [];
          let publishedJobs = [];
          tempArrayOfJobs.forEach(job => {
            job.titleFr = job.translations?.fr?.title ? job.translations.fr.title : (job.translations?.en?.title ? job.translations.en.title : "") + " -- Français non disponible --";
            job.titleEn = job.translations?.en?.title ? job.translations.en.title : (job.translations?.fr?.title ? job.translations.fr.title : "") + " -- English not available --";
            if (job.published_internal < 1 && job.published_outsourced < 1 && job.published_external < 1) {
              job.titleFr += ' ( privé )';
              job.titleEn += ' ( private )';
              privateJobs.push(job);
            } else {
              publishedJobs.push(job);
            }
          });
          // sorting of lists before to concatenate them
          privateJobs = privateJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          publishedJobs = publishedJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          $scope.currentAccountJobsList = publishedJobs.concat(privateJobs);
          $scope.currentAccountJobsList.unshift($scope.defaultJobListOptionHistory);
          $scope.filterJob.selected = $scope.defaultJobListOptionHistory;
        }
      }).then(() => {
        if ($scope.currentAccountJobsList.length) {
          const locationIdsArray = [];
          _.each($scope.currentAccountJobsList, (item) => {
            _.each(item.locations, (itemLocation) => {
              locationIdsArray.push(itemLocation.location_id);
            });
          });
          fetchLocations(_.uniq(locationIdsArray));
        }
      }).then(() => {
        beforeToLoadLogs(true);
        $scope.jobsListLoading = false;
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        $scope.jobsListLoading = false;
      });
    }

    (() => {
      if ($scope.source !== 'questionnaire') {
        getJobsList();
        $scope.$watch('candidate', () => {
          if (!$scope.jobsListLoading) beforeToLoadLogs(false);
        });
      } else {
        $scope.$watch('currentQuestionnaire', () => {
          beforeToLoadLogs(false);
        });
      }
    })();

    const scopeMethods = {
      loadLogsWithJob,
    };
    angular.extend($scope, scopeMethods);
  }

  HistoryModuleCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', '_'];
  angular.module('atlas')
    .directive('historyModule', () => ({
      scope: {
        source: '=',
        candidate: '=?',
        jobId: '@',
        currentQuestionnaire: '=?',
        questionsList: '=?',
      },
      controller: HistoryModuleCtrl,
      templateUrl: './employer-profile/directives/history-module/history-module.template.html',
    }));
/* eslint no-underscore-dangle: ["error", { "allow": ["_source"] }] */
// eslint-disable-next-line no-undef
}(angular));
