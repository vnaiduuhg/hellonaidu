( function ( angular ) {

    'use strict';
    var app = angular.module( 'atlas' );

    app.directive( 'crudQuestionsModule', function () {

        var inject = [
            '$scope',
            '$rootScope',
            '_',
            'api',
            'utils',
            'worklandLocalize',
            'MetaTagsService',
            '$state',
            'matchService',
            crudQuestionsModuleModuleCtrl
        ];

        function crudQuestionsModuleModuleCtrl(
            $scope,
            $rootScope,
            _,
            api,
            utils,
            worklandLocalize,
            MetaTagsService,
            $state,
            matchService
        ) {
        
            MetaTagsService.getMetatags($state.current.name);
            var deregisterFns = MetaTagsService.magageTransitions();
            $scope.$on("$destroy", function() {
                deregisterFns.forEach(function(deregisterFn) {
                    deregisterFn();
                });
            });

            var API_ROUTE = 'questionnaire_web_api';
            var mirrorChoices = false;
            var employerIndex = 1;
            var candidateIndex = 0;
            var strings = worklandLocalize.strings;
            var stringsSpecfic = strings.crudQuestionnaireModule;
            var stringFr = strings.french;
            var stringEn = strings.english;

            var formModel = {
                settings: {
                    editMode: false,
                    viewQuestions: true,
                    viewForm: false,
                    numChoices: 1
                },
                title: [],
                question: [],
                choices: [],
                choiceType: [],
                controlType: ['checkbox', 'checkbox']
            };
            
            //Keep a clean copy of initial settings
            var formModelInitial = angular.copy( formModel );

            function createkeyLableObj( key, label ) {
                return {
                    key: key,
                    label: label
                };
            }
            var dealBreaker = [
                createkeyLableObj( 'null', 'No' ),
                createkeyLableObj( 'exclude', 'Yes' )
            ];
            var algos = [
                createkeyLableObj( 'S1i == S2i', stringsSpecfic.atLeastOneInCommon ),
                createkeyLableObj( '(S1i == S2i)', 'At least 1 in common count common' ),
                createkeyLableObj( 'S1i >= S2i', utils.out('Candidat >= Employeur','Candidate >= Employer') ),
                createkeyLableObj( 'S1i <= S2i', utils.out('Candidat <= Employeur','Candidate <= Employer') ),
                createkeyLableObj( 'n(S1i == S2i)', utils.out('Candidat = Employeur','Candidate = Employer') )
            ];

            var choiceTypes = [
                createkeyLableObj( 'multiple',
                        stringsSpecfic.multipleChoice + ' [' + stringsSpecfic.checkbox + ']' ),
                createkeyLableObj( 'unique',
                        stringsSpecfic.singleChoice + ' [' + stringsSpecfic.radioButton + ']' ),
                createkeyLableObj( 'exact',
                        stringsSpecfic.exactNbChoices + ' [' + stringsSpecfic.checkbox + ' ' +
                        stringsSpecfic.limited + ']' )
            ];

            var choiceTypesLabels = [
                stringsSpecfic.candidateInterface, //'Candidate Interface',
                stringsSpecfic.employerInterface
            ];
            var titleLabels = [
                strings.title + ' ' + stringFr,
                strings.title + ' ' + stringEn
            ];
            var choicesLabels = [
                stringFr,
                stringEn
            ];
            var questionLabels = [
                strings.candidate + ' ' + stringFr,
                strings.employer + ' ' + stringFr,
                strings.candidate + ' ' + stringEn,
                strings.employer + ' ' + stringEn
            ];
            if ( !mirrorChoices ) {
                choicesLabels = questionLabels;
            }

            var scope = {
                strings: worklandLocalize.strings,
                images:  worklandLocalize.imagesUrlEmployer,
                out: utils.out,
                language: utils.language,
                // @std by - this need to be fetched from match service. All questionnaires are owned by the same id
                originalQuestionnaireOwnerId: '87480290-9f58-11e5-b9f6-5df0885e86d6',
                editQuestion: editQuestion,
                choiceTypes: choiceTypes,
                _: _,
                canEditQuestion: canEditQuestion,
                canDeleteQuestion: canDeleteQuestion,
                closeEditForm: closeEditForm,
                getQuestions: getQuestions,
                deleteQuestion: deleteQuestion,
                updateQuestion: updateQuestion,
                algos: algos,
                dealBreaker: dealBreaker,
                choiceTypesLabels: choiceTypesLabels,
                titleLabels: titleLabels,
                questionLabels: questionLabels,
                choicesLabels: choicesLabels,
                formModel: formModel
            };
            angular.extend( $scope, scope );
            
            init();

            function init() {
                return getQuestions();
            }
        
            $scope.$watch( 'formModel.settings.numChoices', function ( nbChoices ) {
                if ( !angular.isUndefined( nbChoices ) ) {
                    $scope.formModel.choices = _.first( $scope.formModel.choices, nbChoices );
                }
            } );

            $scope.$watchCollection( 'formModel.choiceType', function ( newChoiceTypes, oldChoiceTypes ) {

                var exact = "exact";

                // sync dropdowns to exact if either is changed to exact
                if (
                    newChoiceTypes[1] === exact && oldChoiceTypes[0] !== exact || newChoiceTypes[0] === exact && oldChoiceTypes[1] !== exact ) {
                    newChoiceTypes[0] = newChoiceTypes[1] = exact;
                } else {
                    formModel.settings.nbExact = null;
                }

                // deselect exact option if either dropdown is not exact
                newChoiceTypes[1] !== exact && oldChoiceTypes[0] === exact && ( newChoiceTypes[0] = newChoiceTypes[1] );
                newChoiceTypes[0] !== exact && oldChoiceTypes[1] === exact && ( newChoiceTypes[1] = newChoiceTypes[0] );

            } );

            //Only workland employees can edit the original sections
            function canEditQuestion( question ) {
                var ownerId = question.ownerId;
                if ( ownerId === $scope.originalQuestionnaireOwnerId && !$scope.isRealUserWorklandEmployee ) {
                    return false;
                }

                return true;
            }

            //we should not allow the deletion of original sections.
            function canDeleteQuestion( question ) {
                return question.ownerId !== $scope.originalQuestionnaireOwnerId;
            }

            function editQuestion( question ) {
                // we will modify question object so make a copy
                var questionCopy = angular.copy( question );
                questionCopy.settings = {
                    numChoices: question.choices.length,
                    viewForm: true,
                    editMode: true
                };
                questionCopy.if_fct = questionCopy.if_fct[0];
                if ( mirrorChoices ) {
                    _.each( questionCopy.choices, function ( choice ) {
                        // Since we are mirroing emloyer and candidate choice labels
                        // then we select only one en/fr pair for modification
                        var candidateFr = choice.text[0];
                        var candidateEn = choice.text[2];
                        choice.text = [candidateFr, candidateEn];
                    } );
                }
                $scope.formModel = questionCopy;
            }

            // Reset Form
            function closeEditForm() {
                $scope.inputForm.$setPristine();
                $scope.formModel = angular.copy( formModelInitial );

            }


            function getQuestions() {
                var promise = matchService.getData('question');

                promise.then( function ( response ) {
                    $scope.questions = response.data.data;
                } );

                return promise;
            }

            function choicesTextToArray( question ) {

                var text = null;

                _.each( question.choices, function ( choice, index ) {

                    // safely convert text object into array
                    var textArray = [];
                    _.each( choice.text, function ( text, key ) {
                        textArray[key] = text;
                    } );


                    choice.text = mirrorChoices ? [textArray[0], textArray[0], textArray[1], textArray[1]] : textArray;
                    choice.key = index;
                } );
            }

            function prepareQuestionForSending( question ) {
                question = angular.copy( question );
                var choices = question.choices;
                var max = choices.length;

                choicesTextToArray( question );

                // Updating an exisiting question if questionId
                if ( question.questionId ) {

                    question = _.pick( question,
                            'ownerId',
                            'questionId',
                            'title',
                            'question',
                            'choices'
                            );

                } else {

                    var maxChoices = [max, max];
                    var nbChoicesExact = question.settings.nbExact;

                    var questionExtend = {
                        nbChoices: nbChoicesExact ? [nbChoicesExact, nbChoicesExact] : maxChoices,
                        maxChoices: maxChoices,
                        if_fct: [question.if_fct, question.if_fct]
                    };

                    angular.extend( question, questionExtend );
                    delete question.settings;
                }
                return question;
            }

            function updateQuestion() {
                var question = prepareQuestionForSending( $scope.formModel );
                if(question.questionId) {
                    var promise = matchService.updData('question', {
                        questionId: question.questionId,
                        title: question.title,
                        question: question.question,
                        choices: question.choices
                    });
                } else {
                    var promise = matchService.postData('question', {
                        title: question.title,
                        if_fct: question.if_fct,
                        controlType: question.controlType,
                        choiceType: question.choiceType,
                        nbChoices: question.nbChoices,
                        maxChoices: question.maxChoices,
                        question: question.question,
                        choices: question.choices
                    });
                }

                promise.then( function () {
                    if ( formModel.settings.editMode == false ) {
                        closeEditForm();
                    }
                    init();
                } );
                return promise;
            }

            function deleteQuestion( question ) {

                if ( !confirm( strings.confirmDelete ) ) {
                    return;
                }

                var promise = matchService.delData('question', {
                    questionId: question.questionId
                });

                return promise.then( init );
            }       
        }
        return {
            scope: {},
            controller: inject,
            templateUrl: './employer-profile/directives/crud-questions-module/crud-questions-module.template.html'
        };
           
    } );
} )( angular );