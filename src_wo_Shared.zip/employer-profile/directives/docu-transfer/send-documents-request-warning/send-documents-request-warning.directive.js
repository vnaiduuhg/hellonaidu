(function (angular) {
	function sendDocumentsRequestWarningCtrl($scope, utils) {
    const scope = {
		  out: utils.out,
	  };
	  angular.extend($scope, scope);
  }

  sendDocumentsRequestWarningCtrl.$inject = ['$scope', 'utils'];

  angular.module('atlas').directive('sendDocumentsRequestWarning', () => {
    return {
      scope: {
        documentsRequestWarning: '=',
        resendTemplates: '=',
        templates: '=',
        selectedCandidatesCount: '=',
        documentsRequest: '=',
        setResendTemplates: '&',
        notification: '=',
        notificationReminder: '=',
      },
      controller: sendDocumentsRequestWarningCtrl,
      templateUrl: './employer-profile/directives/docu-transfer/send-documents-request-warning/send-documents-request-warning.template.html',
    }
  });

}(angular));
  