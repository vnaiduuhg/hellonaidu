import 'regenerator-runtime';

(function (angular) {
  function docuTransferCtrl(
	  $scope,
    $rootScope,
    $uibModal,
    $ngConfirm,
	  utils,
    api,
    _,
    $compile,
    $timeout,
    Event,
  ) {
    const MAX_FILE_SIZE = 5; // 5MB
    const VALID_FILE_TYPES = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'odt', 'png', 'jpg', 'jpeg', 'gif', 'txt'];
	  const scope = {
      isNumber: angular.isNumber,
		  out: utils.out,
      templateLanguage: $rootScope.language,
      isAdmin: $rootScope.currentUser.permissions.isAdmin,
      userAccountId: $rootScope.currentUser.account?.id ?? null,
      firstInit: true,
      docuTransferTemplates: [],
      docuTransferTemplatesLoading: true,
      docuTransferTemplatesError: false,
      documentsRequest: [],
      documentsRequestLoading: !$scope.isCrm,
      documentsRequestError: false,
      templates: {
        selected: [],
        documentsCount: 0,
      },
      previewDRModal: null,
      showTemplate: {
        email: false,
        sms: false,
      },
      resendTemplates: null,
      documentsRequestWarning: {
        candidatesCount: 0,
        templatesCount: 0,
        notificationEnabled: -1,
        notifReminderEnabled: -1,
        autoMsgMissingCount: 0,
      },
      receivedDocumentsListId: 0,
      candidateIsOpen: 0,
      processingFile: false,
      fileUpload: {
        source: null,
        typeId: null,
        url: null,
        file: null,
        id: null,
      },
      urlHasError: {
        empty: false,
        pattern: false,
        format: false,
      },
      fileHasError: {
        empty: false,
        size: false,
        format: false,
      },
      notification: null,
      notificationReminder: null,
      notificationLoading: true,
      notificationSlugs: ['send-document-request', 'resend-document-request'],
      crmJobCandidate: {
        selected: {},
      },
      jobId: null,
      candidatesWOApplication: [],
      // preview modal
      resetViewers: utils.resetViewers,
      documentViewerData: null,
      viewerUrl: null,
      viewerTitle: '',
      addDocusignTemplateDirective,
      sendDocusignCallback,
      docusignCallbackData: { data: [] },
      attachedDocusignTemplates: [],
      docusignTemplatesToSend: [],
      docusignTemplatesList: [],
      clearDocusignTemplatesData,
      attachDocusignTemplate: { check: false },
      switchTabs,
      showDocReq: true,
      sendDocusignEnvelopes,
      isDocusignError: false,
      isExpiredAccount: false,
	  };
	  angular.extend($scope, scope);

    function displayTokenExpiredMsg() {
      $rootScope.api_status(
        'alert-danger',
        'Your session has expired, please login again',
        'Votre session est expirée, veuillez vous connecter à nouveau',
      );
    }

    function switchTabs(tab) {
      if (tab === 'docR') {
        $scope.showDocReq = true;
        $scope.showDocS = false;
      } else {
        $scope.showDocReq = false;
        $scope.showDocS = true;
      }
    }

    function prepareDocusignEnvelopes(dsEnvelopes) {
      const candidateDocusignEnvelopes = {};
      angular.forEach($scope.selectedCandidates, (candidate) => {
        let candidateEnvelopes = [];
        if (candidate.application_id) {
          candidateEnvelopes = dsEnvelopes[candidate.application_id].docusign_envelopes.map((elmt) => ({
            emailSubject: elmt.emailSubject,
            status: utils.translateDocusignEnvelopesStatus(elmt.status),
            senderEmail: elmt.sender?.email,
            senderUserName: elmt.sender?.userName,
            sent_on: utils.addTranslationsToMomentDate(elmt.sentDateTime, 'LLL'),
          }));
          const appId = candidate.application_id;
          candidateDocusignEnvelopes[appId] = candidateEnvelopes;
        }
      });
      return candidateDocusignEnvelopes;
    }

    function prepareDocumentsRequest(documentsRequest) {
      const candidatesDocumentsrequests = [];
      const candidatesWOApplication = [];
      $scope.candidatesWOApplication = [];
      angular.forEach($scope.selectedCandidates, (candidate) => {
        let docsCount = 0;
        let docsUploaded = 0;
        let docsRead = 0;
        const candidateTemplates = _.filter(documentsRequest, (docReq) => {
          if (+docReq.application_id === +candidate.application_id) {
            docsCount += docReq.read_request_files.length + docReq.send_request_documents.length;
            docsUploaded += _.filter(docReq.send_request_documents, (doc) => doc.sent_files.length > 0).length;
            docsRead += _.filter(docReq.read_request_files, (doc) => doc.pivot.is_read).length;
            return docReq;
          }
        });
        if (candidate.application_id) {
          candidatesDocumentsrequests.push({
            applicationId: candidate.application_id,
            name: `${candidate.first_name} ${candidate.last_name}`,
            docsCount,
            docsUploaded,
            docsRead,
            templates: candidateTemplates,
            isOpen: +$scope.candidateIsOpen === +candidate.application_id,
          });
        } else {
          // CRM
          candidatesWOApplication.push(candidate);
        }
      });

      if (candidatesWOApplication.length > 0) $scope.candidatesWOApplication = candidatesWOApplication;
      return candidatesDocumentsrequests;
    }

    function activatedMessageDisabledCount() {
      let count = 0;
      if ($scope.documentsRequestWarning.candidatesCount > 0
        && $scope.documentsRequestWarning.templatesCount > 0
        && $scope.notificationReminder
        && $scope.documentsRequestWarning.notifReminderEnabled === 0) {
        count++;
      }
      if ($scope.notification && $scope.documentsRequestWarning.notificationEnabled === 0
        && ($scope.documentsRequestWarning.templatesCount < $scope.templates.selected.length || $scope.documentsRequestWarning.candidatesCount < $scope.documentsRequest.length)
      ) {
        count++;
      }
      $scope.documentsRequestWarning.autoMsgMissingCount = count;
    }

    $scope.checkIfCandidatesHasTemplates = () => {
      const candidatesCount = [];
      const templatesCount = [];
      angular.forEach($scope.documentsRequest, (candidate) => {
        candidate.hasTemplates = [];
        angular.forEach($scope.templates.selected, (template) => {
          const hasTemplate = _.find(candidate.templates, (t) => +t.document_request_template_id === +template.id);
          if (hasTemplate) {
            candidate.hasTemplates.push(hasTemplate);
            candidatesCount.push(+candidate.applicationId);
            templatesCount.push(+template.id);
          }
        });
      });

      $scope.documentsRequestWarning.candidatesCount = _.uniq(candidatesCount).length;
      $scope.documentsRequestWarning.templatesCount = _.uniq(templatesCount).length;
      activatedMessageDisabledCount();
    };

    $scope.getDocusignEnvelopes = () => {
      $scope.loadingDocusignEnvelopes = true;
      $scope.docusignEnvelopesError = false;
      const arrayOfApplicationIds = _.pluck($scope.selectedCandidates, 'application_id').filter((a) => !!a);
      if (arrayOfApplicationIds.length > 0) {
        api.service_get('e-signing', 'docusign/envelopes', { 'application_ids[]': arrayOfApplicationIds }).then((response) => {
          if (response.status === 200) {
            $scope.docusignEnvelopes = prepareDocusignEnvelopes(response.data.data);
          }
          $scope.loadingDocusignEnvelopes = false;
        }).catch((error) => {
          $scope.loadingDocusignEnvelopes = false;          
          switch (error.status) {
            case 401:
              displayTokenExpiredMsg('token_expired');
              break;
            default:
              $scope.docusignEnvelopesError = true;
          }
        });
      } else {
        $scope.loadingDocusignEnvelopes = false;
      }
    };

    $scope.getDocumentsRequest = () => {
      if ($scope.candidatesWOApplication.length > 0) $scope.candidatesWOApplication = [];
      const arrayOfApplicationIds = _.pluck($scope.selectedCandidates, 'application_id').filter((a) => !!a);
      return api.service_post(
        'toolkit',
        'docutransfer/document-requests/search',
        { application_ids: arrayOfApplicationIds },
      ).then((response) => {
        if (response.status === 200 && Array.isArray(response.data)) {
          $scope.documentsRequest = prepareDocumentsRequest(response.data);
          if ($scope.templates.selected.length > 0) $scope.checkIfCandidatesHasTemplates();
          $scope.documentsRequestLoading = false;
          $scope.candidateIsOpen = 0;
        } else {
          $scope.documentsRequestError = true;
          $scope.documentsRequestLoading = false;
          $scope.candidateIsOpen = 0;
        }
        if ($scope.firstInit) $scope.firstInit = false;
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 403:
            $rootScope.api_status(
              'alert-danger',
              'You do not have the required permissions to get documents requests',
              "Vous n'avez pas les permissions nécessaires pour récupérer les demandes de documents",
            );
            break;
          default:
            // no need on get query -> general msg is shown on an alert-box
        }
        $scope.candidateIsOpen = 0;
        $scope.documentsRequestLoading = false;
        $scope.documentsRequestError = true;
        if ($scope.firstInit) $scope.firstInit = false;
      })
    };

    function getDocumentsRequestTemplates() {
      api.service_get(
        'toolkit',
        'docutransfer/document-request-templates', {
          filter_by_draft: 0,
          load_email_template: 1,
          load_sms_template: 1,
        },
      ).then((response) => {
        if (response.status === 200 && Array.isArray(response.data)) {
          $scope.docuTransferTemplates = response.data; // make sure that I receive an empty array when no data
        } else {
          $scope.docuTransferTemplatesError = true;
        }
        $scope.docuTransferTemplatesLoading = false;
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 403:
            $rootScope.api_status(
              'alert-danger',
              'You do not have the required permissions to get documents request list',
              "Vous n'avez pas les permissions nécessaires pour récupérer la liste de demande de documents",
            );
            break;
          default:
            // no need on get query -> general msg is shown on an alert-box
        }
        $scope.docuTransferTemplatesError = true;
        $scope.docuTransferTemplatesLoading = false;
      });
    }

    $scope.$watch('fileUpload.source', (value) => {
      if (value === 'file') {
        resetUrlErrors();
        $scope.fileUpload.url = null;
      } else if (value === 'url') {
        $scope.clearFileModel();
      }
    });

    function countNumberOfDocuments() {
      if ($scope.templates.selected.length > 0) {
        let count = 0;
        angular.forEach($scope.templates.selected, (template) => {
          count += (template.send_request_template_documents?.length ?? 0) + (template.read_request_files?.length ?? 0);
        });
        $scope.templates.documentsCount = count;
      }
    }

    $scope.pushTemplateToList = () => {
      countNumberOfDocuments();
      $scope.checkIfCandidatesHasTemplates();
    };

    $scope.removeTemplateFromList = () => {
      countNumberOfDocuments();
      if ($scope.templates.selected.length > 0) $scope.checkIfCandidatesHasTemplates();
    };

    function openDocumentRequestPreviewModal() {
      const modalParams = {
        animation: true,
        templateUrl: './employer-profile/directives/docu-transfer/docu-transfer-preview-modal.template.html',
        size: 'lg',
        scope: $scope,
        backdrop: 'static',
      };
      $scope.previewDRModal = $uibModal.open(modalParams);
    }

    $scope.showDocumentRequestPreview = () => {
      if ($scope.selectedCandidates?.length > 0 && $scope.templates.selected.length > 0) {
        openDocumentRequestPreviewModal();
      }
    };

    $scope.hideDocumentRequestPreview = (clearResendTemplates = null) => {
      $scope.previewDRModal.close();
      if (Number.isInteger($scope.resendTemplates)) $scope.resendTemplates = null;
    };

    $scope.showTemplate = (type) => {
      $scope.showTemplate[type] = !$scope.showTemplate[type];
    };

    $scope.displaytemplateLanguage = (l) => {
      $scope.templateLanguage = l;
    };

    function openSendRequestWarningModal() {
      const modalParams = {
        animation: true,
        templateUrl: './employer-profile/directives/docu-transfer/send-documents-request-warning-modal.template.html',
        size: 'lg',
        scope: $scope,
        backdrop: 'static',
      };
      $scope.sendDRWarningModal = $uibModal.open(modalParams);
    }

    $scope.hideSendRequestWarningModal = (clear) => {
      $scope.sendDRWarningModal.close();
    };

    function deleteFile(file, apllicationId) {
      $scope.processingFile = true;
      $scope.candidateIsOpen = apllicationId;
      $rootScope.api_status(
        'waiting',
        'The document is being deleted...',
        'Suppression du document en cours...',
      );
      api.service_delete('toolkit', `docutransfer/document-requests/send-request-documents/sent-files/${file.id}`).then((response) => {
        if (response.status === 204) {
          $rootScope.api_status(
            'alert-success',
            'The document has been deleted successfully!',
            'Le document a été supprimé avec succès!',
          );
          $scope.documentsRequestLoading = true;
          $scope.getDocumentsRequest();
        } else {
          $rootScope.api_status(
            'alert-danger',
            'An error has occured and the document could not be deleted',
            "Une erreur est survenue et le document n'a pu être supprimé",
          );
          $scope.candidateIsOpen = 0;
        }
        $scope.processingFile = false;
      }).catch((error) => {
        $scope.processingFile = false;
        $scope.candidateIsOpen = 0;
        if (error.status && error.status === 403) {
          $rootScope.api_status(
            'alert-danger',
            'You do not have the required permissions to delete this document',
            "Vous n'avez pas les permissions nécessaires pour supprimer ce document",
          );
        } else {
          $rootScope.api_status(
            'alert-danger',
            'An error has occured and the document could not be deleted',
            "Une erreur est survenue et le document n'a pu être supprimé",
          );
        }
      });
    }

    $scope.openDeleteCandidateFileConfirm = (file, apllicationId) => {
      $ngConfirm({
        title: $scope.out("Confirmation de suppression d'un document", 'Document Deletion Confirmation'),
        content: $scope.out(`Êtes-vous sûr de vouloir supprimer ${file.file_name}?`, `Are you sure you want to delete ${file.file_name}?`),
        type: 'red',
        buttons: {
          cancel: {
            text: $scope.out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            action() {},
          },
          yes: {
            text: $scope.out('Supprimer', 'Delete'),
            btnClass: 'btn btn-primary',
            action() {
              deleteFile(file, apllicationId);
            },
          },
        },
      });
    };

    function resetFileErrors() {
      $scope.fileHasError.empty = false;
      $scope.fileHasError.size = false;
      $scope.fileHasError.format = false;
    }

    function resetUrlErrors() {
      $scope.urlHasError.empty = false;
      $scope.urlHasError.pattern = false;
      $scope.urlHasError.format = false;
    }

    $scope.validateFile = (file) => {
      resetFileErrors();
      if (!file) {
        $scope.fileHasError.empty = true;
        return false;
      }
      if (!file.size || file.size / (1048576) > MAX_FILE_SIZE) {
        $scope.fileHasError.size = true;
        return false;
      }

      const format = file.name.split('.').pop();
      if (!VALID_FILE_TYPES.includes(format)) {
        $scope.fileHasError.format = true;
        return false;
      }

      return true;
    };

    $scope.validateUrlInput = () => {
      resetUrlErrors();
      const regExp = /http(s)?:\/\//gi;
      if (!$scope.fileUpload.url) {
        $scope.urlHasError.empty = true;
        return false;
      }
      if (!regExp.test($scope.fileUpload.url)) {
        $scope.urlHasError.pattern = true;
        return false;
      }
      const format = $scope.fileUpload.url.split('.').pop();
      if (!VALID_FILE_TYPES.includes(format)) {
        $scope.urlHasError.format = true;
        return false;
      }

      return true;
    };

    $scope.clearFileModel = () => {
      resetFileErrors();
      $scope.fileUpload.file = null;
    };

    function validateUploadData() {
      let isValid = false;
      const typeIdValidated = Number.isInteger($scope.fileUpload.typeId) && $scope.fileUpload.typeId > 0;
      const IdValidated = Number.isInteger($scope.fileUpload.id) && $scope.fileUpload.id > 0;

      if ($scope.fileUpload.source === 'url') {
        const urlInputValidated = $scope.validateUrlInput();
        isValid = urlInputValidated && typeIdValidated && IdValidated;
      }
      if ($scope.fileUpload.source === 'file') {
        const fileInputValidated = $scope.validateFile($scope.fileUpload.file);
        isValid = fileInputValidated && typeIdValidated && IdValidated;
      }

      return isValid;
    }

    function resetFileUploadModel() {
      $scope.fileUpload = {
        source: null,
        typeId: null,
        url: null,
        file: null,
        id: null,
      };
    }

    $scope.uploadSendRequestFile = () => {
      const dataValidated = validateUploadData();
      if (dataValidated) {
        $scope.closeUploadFileModal();
        $scope.processingFile = true;
        $rootScope.api_status(
          'waiting',
          'The request is being sent...',
          'Requête en cours...',
        );

        const data = {
          upload_type: $scope.fileUpload.source,
          type_id: $scope.fileUpload.typeId,
        };
        if ($scope.fileUpload.source === 'file') {
          data.file = $scope.fileUpload.file;
        } else if ($scope.fileUpload.source === 'url') {
          data.url_link = $scope.fileUpload.url;
        }

        api.toolkit_fileupload(
          `docutransfer/document-requests/send-request-documents/${$scope.fileUpload.id}/sent-files`,
          data,
        ).then((response) => {
          if (response.status === 201) {
            $rootScope.api_status(
              'alert-success',
              'The document has been uploaded successfully!',
              'Le document a été téléversé avec succès!',
            );
            $scope.documentsRequestLoading = true;
            resetFileUploadModel();
            $scope.getDocumentsRequest();
          } else {
            $rootScope.api_status(
              'alert-danger',
              'An error has occured and the document could not be uploaded',
              "Une erreur est survenue et le document n'a pu être téléversé",
            );
            $scope.candidateIsOpen = 0;
          }
          $scope.processingFile = false;
        }).catch((error) => {
          if (error.status === 403) {
            if (error.data && error.data === 'exceeded_required_number_of_documents') {
              $rootScope.api_status(
                'alert-danger',
                'The number of required documents is exceeded',
                'Le nombre de documents requis est dépassé',
              );
            } else {
              $rootScope.api_status(
                'alert-danger',
                'You do not have the required permissions to upload a document on behalf of a candidate',
                "Vous ne disposez pas des autorisations requises pour télécharger un document au nom d'un candidat",
              );
            }
          } else {
            $rootScope.api_status(
              'alert-danger',
              'An error has occured and the document could not be uploaded',
              "Une erreur est survenue et le document n'a pu être téléversé",
            );
          }
          $scope.candidateIsOpen = 0;
          resetFileUploadModel();
          $scope.processingFile = false;
        });
      }
    };

    $scope.closeUploadFileModal = (fromModal = null) => {
      $scope.uploadDocumentModal.close();
      if (fromModal) {
        $scope.candidateIsOpen = 0;
        resetFileUploadModel();
      }
    };

    function uploadFileModal() {
      $scope.uploadDocumentModal = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/docu-transfer/upload-send-documents-modal.template.html',
        scope: $scope,
        size: 'md',
        backdrop: 'static',
        keyboard: false,
      });
    }

    $scope.openUploadFileModal = (file, applicationId) => {
      if (file.sent_files.length < file.required_number) {
        $scope.candidateIsOpen = applicationId;
        $scope.fileUpload.typeId = file.document_type_id;
        $scope.fileUpload.id = file.id;
        if (file.requiredFileNumSent) file.requiredFileNumSent = false;
        uploadFileModal();
      } else {
        file.requiredFileNumSent = true;
      }
    };

    $scope.openViewDocumentModal = async (file, type) => {
      $scope.viewerTitle = file.file_name;

      const modal = document.getElementById('document-viewer-modal');
      modal.addEventListener('hidden.bs.modal', (event) => {
        $scope.viewerUrl = null;
        $scope.resetViewers(modal);
      });
      $scope.viewerUrl = null;

      const viewerModal = new bootstrap.Modal(modal);
      viewerModal.show();

      api.service_query(
        'toolkit',
        type === 'send request'
          ? `docutransfer/document-requests/send-request-documents/sent-files/${file.id}/url`
          : `docutransfer/document-request-templates/read-request-files/${file.pivot.read_request_file_id}/url`,
        'get',
      ).then((response) => {
        if (response.status === 200 && response.data && typeof response.data.url === 'string') {
          $scope.viewerUrl = response.data.url;
        } else {
          throw `Invalid send request schema or non-200 response: ${response?.status}`;
        }
      }).catch((error) => {
        if (error.data && error.data.code === 404) {
          $rootScope.api_status('alert-danger', 'File not found', 'Fichier introuvable');
        } else {
          // error 500 and unpredictable
          $rootScope.api_status(
            'alert-danger',
            'Please try again later or contact support@workland.com for assistance',
            'S\'il-vous-plaît veuillez réessayer plus tard ou contactez support@workland.com pour assistance',
            'An error has occurred',
            'Une erreur est survenue',
            7500,
          );
        }
      });
    };

    $scope.manageReceivedDocumentsSection = (file) => {
      if (!file.isOpen) {
        file.isOpen = true;
      } else {
        file.isOpen = false;
        if (file.requiredFileNumSent) file.requiredFileNumSent = false;
      }
    };

    $scope.setResendTemplates = (value) => {
      $scope.resendTemplates = value;
    };

    function resetSelectValues() {
      $scope.templates.selected = [];
      $scope.templates.documentsCount = 0;
      $scope.resendTemplates = null;
    }

    function sendDocusignEnvelopes() {
      $rootScope.api_status(
        'waiting',
        'Sending DocuSign envelopes...',
        'Envoi des enveloppes DocuSign...',
      );
      const data = { applications: [] };
      angular.forEach($scope.selectedCandidates, (candidate) => {
        if (candidate.application_id) {
          let candidateRecipient = {};          
          if (candidate.uuid) {
            candidateRecipient.user_uuid = candidate.uuid;
          } else {
            candidateRecipient =  {
              email: candidate.email,
              full_name: candidate.first_name + ' ' + candidate.last_name, 
            };
          }
          data.applications.push({
            application_id: candidate.application_id,
            templates:
              $scope.docusignTemplatesToSend.map((template) => {
                const allRecipients = template.atlasRecipients.map((elmt) => {
                  if (elmt.atlasRoleName === 'candidate') {
                    elmt = {...elmt, ...candidateRecipient};                    
                  }
                  return elmt;
                }).filter(( element ) => {
                    return element !== undefined;
                });
                return {
                  template_id: template.templateId,
                  recipients: allRecipients,
                }
              }),
          });
        }
      });
      api.service_post('e-signing', 'docusign/envelopes', data).then((response) => {
        if (response.status === 201) {
          $rootScope.api_status(
            'alert-success',
            'Docusign templates have been sent successfully!',
            'Les modèles Docusign ont été envoyés avec succès !',
          );
          const envelopesFailed = response.data.data.failed;
          if (envelopesFailed.length > 0) {
            $rootScope.api_status(
              'alert-danger',
              'An error has occurred, and one or more templates were not sent. Please check status of the sent Docusign templates.',
              "Une erreur s'est produite, et un ou plusieurs modèles n'ont pas été envoyés. Veuillez vérifier le statut des modèles Docusign envoyés.",
            );
          }
          $scope.attachDocusignTemplate.check = false;
          clearDocusignTemplatesData();
          // preview modal will be closed, so need to show it on main page after getting envelopes
          $scope.getDocusignEnvelopes();
        }
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 403:
            $rootScope.api_status(
              'alert-danger',
              'You do not have the required permissions to view applications',
              "Vous n'avez pas les permissions nécessaires pour visualiser les candidatures.",
            );
            break;
          default:
            $rootScope.api_status(
              'alert-danger',
              'An error has occurred while sending DocuSign templates.',
              "Une erreur est survenue lors de l'envoi des modèles DocuSign.",
            );
        }
      });
    }

    $scope.sendDocumentsRequestToCandidates = () => {
      $rootScope.api_status(
        'waiting',
        'The request is being sent...',
        'Requête en cours...',
      );

      const data = { document_requests: [] };
      const candidates = [];
      angular.forEach($scope.selectedCandidates, (candidate) => {
        if (candidate.application_id) {
          candidates.push({
            application_id: candidate.application_id,
            recipient_user_id: candidate.user_id,
          });
        }
      });
      angular.forEach($scope.templates.selected, (template) => {
        data.document_requests.push({
          document_request_template_id: template.id,
          applications: candidates,
        });
      });
      if (Number.isInteger($scope.resendTemplates)) data.should_resend = $scope.resendTemplates;

      api.service_post('toolkit', 'docutransfer/document-requests', data).then((response) => {
        if (response.status === 201) {
          resetSelectValues();
          $scope.documentsRequestLoading = true;
          $rootScope.api_status(
            'alert-success',
            'Documents request has been sent successfully!',
            'La demande de documents a été envoyée avec succès!',
          );
          $scope.getDocumentsRequest().then(() => {
            if ($scope.docusignTemplatesToSend.length > 0) sendDocusignEnvelopes();
          });         
        } else {
          $rootScope.api_status(
            'alert-danger',
            'An error has occured and the documents request could not be sent',
            "Une erreur est survenue et la demande de documents n'a pu être envoyée",
          );
        }
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 403:
            $rootScope.api_status(
              'alert-danger',
              'You do not have the required permissions to send a documents request',
              "Vous n'avez pas les permissions nécessaires pour envoyer une demande de documents",
            );
            break;
          default:
            $rootScope.api_status(
              'alert-danger',
              'An error has occured and the documents request could not be sent',
              "Une erreur est survenue et la demande de documents n'a pu être envoyée",
            );
        }
      });      
    };

    $scope.validateSendDocumentsRequestToCandidates = () => {
      if ($scope.documentsRequestWarning.candidatesCount > 0
        || $scope.documentsRequestWarning.templatesCount > 0
        || $scope.documentsRequestWarning.notificationEnabled === 0) {
        openSendRequestWarningModal();
      } else {
        $scope.sendDocumentsRequestToCandidates();
      }
    };

    function getNotificationByEvent(slugName) {
      api.service_get(
        'messaging',
        `accounts/${$scope.userAccountId}/notification-settings`,
        { event_slug: slugName },
      ).then((response) => {
        if (response.status === 200 && response.data.length > 0) {
          if (slugName === 'send-document-request') {
            $scope.notification = response.data[0];
            $scope.documentsRequestWarning.notificationEnabled = response.data[0].is_email_enabled || response.data[0].is_sms_enabled ? 1 : 0;
          } else {
            $scope.notificationReminder = response.data[0];
            $scope.documentsRequestWarning.notifReminderEnabled = response.data[0].is_email_enabled || response.data[0].is_sms_enabled ? 1 : 0;
          }
        }
        $scope.notificationLoading = false;
      }).catch(() => {
        $scope.notificationLoading = false;
      });
    }

    // CRM
    $scope.filterSelectedCandidates = () => {
      if ($scope.selectedCandidates.length === 1 && $scope.selectedCandidates[0].applicationList.length) {
        if (!$scope.selectedJob) {
            $scope.crmJobCandidate.selected = $scope.selectedCandidates[0].jobList[0];
            $scope.jobId = $scope.selectedCandidates[0].jobList[0].id;
          }
        const application = $scope.selectedCandidates[0].applicationList.find(((application) => +application.job_id === +$scope.jobId));
        $scope.selectedCandidates[0].application_id = application?.id ?? null;
      } else if ($scope.selectedCandidates.length > 1) {       
        $scope.selectedCandidates.forEach((candidate) => {
          const application = $scope.commonApplications.find(((application) => +application.job_id === +$scope.jobId && +application.candidate_user_id === +candidate.user_id));
          candidate.application_id = application?.id ?? null;
        });
      }
      $scope.documentsRequestLoading = true;
      $scope.getDocumentsRequest().then(() => {
        $scope.getDocusignEnvelopes();
      })
    };

    // CRM
    $scope.switchJob = (jobSelected) => {
      $scope.jobId = jobSelected?.id ?? null;
      $scope.selectedJob = true;
      if (Number.isInteger($scope.jobId) && $scope.jobId > 0) {
        $scope.filterSelectedCandidates();
      }
    };

    function fetchAccountMembers() {
      const accountUsers = angular.copy($rootScope.currentUser.account_user).filter((user) => !![10, 20, 30, 50, 80, 100].includes(user.role_id));
      angular.forEach(accountUsers, (accountUser) => {
        accountUser.name = `${accountUser.user.first_name} ${accountUser.user.last_name}`;
        accountUser.email = `${accountUser.user.email}`;
        accountUser.user_id = `${accountUser.user_id}`;
      });

      $scope.accountMembers = accountUsers;
      $scope.noMembersFound = !(Array.isArray(accountUsers) && accountUsers.length);
    }

    Event.on('DOCUSIGN_TEMPLATE_REMOVED', ($event, params) => {
      if (scope.attachedDocusignTemplates.length > 0) {
        const indexToBeRemoved = $scope.attachedDocusignTemplates.findIndex((templ) => templ.data[0]?.templateId === params.removedTemplate.templateId);
        $scope.attachedDocusignTemplates.splice(indexToBeRemoved, 1);
      }
    });

    function clearDocusignTemplatesData() {
      if (!$scope.attachDocusignTemplate.check) {
        $scope.attachedDocusignTemplates = [];
        $scope.docusignTemplatesToSend = [];
        $scope.docusignCallbackData = { data: [] };
        // destroy docusign directives dom elements
        const childDirectives = angular.element('#docusignListDiv').children();
        angular.forEach(childDirectives, (child) => {
          child.remove();
        });
      }
      // restore dropdown data
      sendDocusignCallback();
    }

    function sendDocusignCallback() {
      $timeout(() => {
        $scope.attachedDocusignTemplates.push(angular.copy($scope.docusignCallbackData));
        $scope.docusignTemplatesToSend = $scope.attachedDocusignTemplates.map((template) => template.data[0]).filter((element) => element !== undefined);
        // filter out of dropdown already attached templates
        $scope.docusignTemplatesListNew = $scope.docusignTemplatesList.filter((template) => $scope.docusignTemplatesToSend.every((attached) => template.templateId !== attached.templateId));
      }, 10);
    }

    let counterDocusignDirective = 1;

    function addDocusignTemplateDirective() {
      counterDocusignDirective = counterDocusignDirective += 1;
      const newDirective = angular.element(`<docusign-module id="docusignDirective_${counterDocusignDirective}"`
                            + 'docusign-templates-list="docusignTemplatesListNew" '
                            + 'selected-candidates="selectedCandidates" '
                            + 'account-members="accountMembers" '
                            + 'send-docusign-callback="sendDocusignCallback()"'
                            + 'docusign-callback-data="docusignCallbackData"'
                            + `is-child-module="true"`
                            + `is-crm="isCrm"`
                            + `no-application-found="noApplicationFound"`
                            + `common-applications="commonApplications"`
                            + `common-jobList="commonJobList"`
                            + `ready-jobs="readyJobs">`
                       + '</docusign-module>');
      if (angular.element('#docusignListDiv') ) angular.element('#docusignListDiv').append(newDirective);    
      $compile(newDirective)($scope);
    }

    function fetchDocusignTemplates() {
      api.service_get('e-signing', 'docusign/templates').then((response) => {
        if (response?.data?.data !== null) {
          $scope.docusignTemplatesList = response.data.data.map((tmpl) => {
            if (!tmpl.name || tmpl.name == '') tmpl.name = $scope.out('Modèle sans titre', 'Untitled template');
            if (!tmpl.emailSubject || tmpl.emailSubject == '') tmpl.emailSubject = $scope.out('Pas de sujet du courriel', 'No email subject');
            return {
              name: tmpl.name,
              templateId: tmpl.templateId,
              emailSubject: tmpl.emailSubject,
              recipients: {
                signers: tmpl.recipients?.signers.length > 0 ? tmpl.recipients.signers.map((signer) => ({ 
                  roleName: signer.roleName, 
                  email: signer.email, 
                  routingOrder: signer.routingOrder, 
                }))
                  : [],
              },
            };
          });
        }
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          default:
            $rootScope.api_status(
              'alert-danger',
              'No list of document templates retrieved.',
              'Aucune liste de modèles de documents récupérée.',
            );
        }
      });
    }

    function getDocusignAccount() {
      api.service_get('e-signing', 'docusign/auth/accounts/my-account').then((response) => {
        if (response?.data?.data !== null) {
          $scope.hasDocusignAccount = true;
        } else {
          $scope.hasDocusignAccount = false;
        }
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 400:
            $scope.hasDocusignAccount = false;
            $scope.isExpiredAccount = true;
            break;
          default:
            $scope.isDocusignError = true;
        }
      }).finally(() => {
        if ($scope.hasDocusignAccount) fetchDocusignTemplates();
      });
    }

    $scope.$on('templateAttachedChanged', (event, value) => {
      $scope.templateAttached = value;
    });

    // on init
    (() => {
      $scope.notificationSlugs.forEach((slug) => {
        getNotificationByEvent(slug);
      });
      getDocumentsRequestTemplates();
      getDocusignAccount();
      fetchAccountMembers();
      if (!$scope.isCrm) {
        $scope.getDocumentsRequest().then(() => {
          $scope.getDocusignEnvelopes();
        });
      } else {
        if ($scope.selectedCandidates.length === 1 && $scope.selectedCandidates[0].applicationList.length && !$scope.selectedJob) {
            $scope.crmJobCandidate.selected = $scope.selectedCandidates[0].jobList[0];
            $scope.jobId = $scope.selectedCandidates[0].jobList[0].id;               
        } else if ($scope.selectedCandidates.length > 1) {
            $scope.crmJobCandidate.selected = $scope.commonJobList[0];
            $scope.jobId = $scope.commonJobList[0].id;                  
        } else {
          //this is case when we unselect and reselect the same candidate, the applicationList is empty but will be refilled
          //when data arrives
          $scope.jobId = null;
          $scope.crmJobCandidate.selected = {};
        }
      }
    })();
  }

  docuTransferCtrl.$inject = ['$scope', '$rootScope', '$uibModal', '$ngConfirm', 'utils', 'api', '_', '$compile', '$timeout', 'Event'];

  angular.module('atlas').directive('docuTransfer', () => ({
    scope: {
      selectedCandidates: '=',
      noApplicationFound: '=?',
      commonApplications: '=?',
      commonJobList: '=?',
      isCrm: '=?',
      readyJobs: '=?',
    },
    link(scope) {
      scope.$watch('selectedCandidates', (currentValue, oldValue) => {
        if (!scope.isCrm) {
          if (!scope.firstInit || (oldValue.length !== currentValue.length) || (oldValue.length === currentValue.length && currentValue.length === 1 && +currentValue[0].user_id !== +oldValue[0].user_id)) {
            scope.documentsRequestLoading = true;
            scope.getDocumentsRequest().then(() => {
              scope.getDocusignEnvelopes();
            });
          }
        }
      }, true);
      scope.$watch('readyJobs', (dataReady) => {
        // on CRM, we need to wait for the data to be ready
        if (dataReady) {
          scope.filterSelectedCandidates();
        }
      }, true);
    },
    controller: docuTransferCtrl,
    templateUrl: './employer-profile/directives/docu-transfer/docu-transfer.template.html',
  }));
}(angular));
