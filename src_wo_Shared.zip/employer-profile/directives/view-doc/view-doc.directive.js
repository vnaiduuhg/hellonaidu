// eslint-disable-next-line func-names
(function (angular) {
  function viewDocCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    $ngConfirm,
    $timeout,
    $uibModal,
  ) {
    let scope = {
      out: utils.out,
      loading: {
        fileCategories: false,
        doc: false,
      },
      error: {
        noDoc: false,
      },
      allSelectedDocuments: [],
    };
    angular.extend($scope, scope);

    function addDocumentToList(document) {
      let index = -1;
      for (let i = 0; i < $scope.allSelectedDocuments.length; i++) {
        if (angular.equals($scope.allSelectedDocuments[i], document)) {
          index = i; 
          break;
        }          
      }  
      if (index === -1) {
        $scope.allSelectedDocuments.push(document);
      } else {
        $scope.allSelectedDocuments.splice(index, 1);
      }      
    }

    function openMdMenu($mdMenu, ev) {
      const originatorEv = ev;
      $mdMenu.open(ev);
    }

    function getSrcUrl(response, doc) {
      const fileType = doc.file_name.substring(doc.file_name.lastIndexOf('.') + 1);
      let srcUrl = doc.url;
      switch (fileType) {
        case 'pdf':
        case 'txt':
        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'gif':
        case 'docx':
        case 'odt':
        case 'xls':
        case 'xlsx':
          srcUrl = window.URL.createObjectURL(response);
          break;
      }
      return srcUrl;
    }

    function download(response, doc) {
      if (navigator.msSaveBlob) {
        navigator.msSaveBlob(response, doc.file_name); // OK for IE10+
      } else {
        const blobUrl = window.URL.createObjectURL(response);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.style = 'display: none';
        a.href = blobUrl;
        a.download = doc.file_name;
        a.click();
        document.body.removeChild(a);
      }
    }

    function print(response, doc) {
      const iframe = document.createElement('iframe');
      document.body.appendChild(iframe);
      iframe.style.display = 'none';

      iframe.onload = function () {
        createIframeTimeout = $timeout(() => {
          iframe.focus();
          iframe.contentWindow.print();
        }, 1);
      };
      iframe.src = getSrcUrl(response, doc);
    }

    function print_or_download_doc(action, document) {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', document.url, true);
      xhr.responseType = 'blob';

      const errorMsg_EN = action === 'print' ? 'Failed to print the document.' : 'Failed to download the document.';
      const errorMsg_FR = action === 'print' ? "Impossible d'imprimer le document." : 'Échec du téléchargement du document.';

      xhr.onload = function (event) {
        if (this.status === 200) {
          $rootScope.api_status('', '', '');
          if (action === 'print') {
            print(this.response, document);
          } else {
            download(this.response, document);
          }
        } else {
          $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
        }
      };

      xhr.onerror = function (event) {
        $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
      };

      xhr.send();
    }

    function printDoc(action) {
      $rootScope.api_status('waiting', 'Document is being prepared to be printed', 'Le document est en préparation pour être imprimé');
      if (action === 'all') {
        angular.forEach($scope.allSelectedDocuments, (document) => {
          print_or_download_doc('print', document);
        });
      } else {
        print_or_download_doc('print', $scope.file);
      }
    }

    function downloadDoc(action) {
      $rootScope.api_status('waiting', 'Document is being prepared to be downloaded', 'Le document est en préparation pour être téléchargé');
      if (action === 'all') {
        angular.forEach($scope.allSelectedDocuments, (document) => {
          print_or_download_doc('download', document);
        });
      } else {
        print_or_download_doc('download', $scope.file);
      }
    }

    function shareDocs(action) {
      $scope.fileToBeAttached = [];
      let tempData = {};      
      if (action === 'all') {
        angular.forEach($scope.allSelectedDocuments, (document) => {
          tempData = {
            file_name: document.file_name,
            id: $scope.mode === 'crm-leads' ? document.id : `${document.file_version_id}_candidate`,
            original_file: document.original_file,
          };         
          $scope.fileToBeAttached.push(tempData);
        });
      } else {
          tempData = {
            file_name: $scope.file.file_name,
            id: $scope.mode === 'crm-leads' ? $scope.file.id : `${$scope.file.file_version_id}_candidate`,
            original_file: $scope.file.original_file,
          };          
          $scope.fileToBeAttached.push(tempData);
      }
      if ($scope.mode === 'crm-leads') $scope.fileToBeAttached['leadsDocuments'] = true;

      $scope.shareDocModalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/views/modal-templates/email-composer-modal.template.html',
        scope: $scope,
        size: 'lg',
        backdrop: 'static',
      });
    }

    function closeShareDocModal() {
      $scope.shareDocModalInstance.close();
    }

    function getFileCategories() {
      $scope.loading.fileCategories = true;
      api.service_get('toolkit', 'document-manager/candidate-file-versions/document-types').then((response) => {
        if (response.data.message) {
          $scope.fileCategories = response.data.message;
        }
        $scope.loading.fileCategories = false;
      }).catch(() => {
        $scope.loading.fileCategories = false;
        $rootScope.api_status('alert-danger');
      });
    }

    function clearCVTabMsg() {
      $scope.error.noDoc = false;
    }

    function selectDocument(document) {
      clearCVTabMsg();
      utils.hideClasses();
      if (document) {
        $scope.loading.file = true;
        $scope.file = document;
        // const url = $scope.file;
        const extension = document.file_name.toLowerCase().split('.').pop();
        switch (extension) {
          case 'pdf':
            navigator.pdfViewerEnabled ? utils.showNativePdfFile(document) : utils.showPdfFile(document);
            break;
          case 'ppt':
          case 'pptx':
          case 'doc':
          case 'docx':
          case 'xls':
          case 'xlsx':
          case 'odt':
            utils.showOfficeFile(document);
            break;
          case 'png':
          case 'tif':
          case 'tiff':
          case 'bmp':
          case 'jpg':
          case 'jpeg':
          case 'gif':
            utils.showImage(document);
            break;
          case 'txt':
            utils.showTxtFile(document);
            break;
          default:

            window.document.getElementById('Enable-docViewer').style.display = 'block';
        }
        // Button Events
        $scope.error.noDoc = false;
        $scope.loading.file = false;
      } else {
        $scope.error.noDoc = true;
        $scope.file = [];
        $scope.loading.file = false;
        window.document.getElementById('Enable-docViewer2').style.display = 'block';
      }
    }

    function getDocuments(leadID) {
      $scope.loading.documents = true;
      let promise = {};
      if (leadID) {
        promise = api.service_get('toolkit', `document-manager/leads/${leadID}/lead-documents`);
      } else {
        promise = api.service_get('toolkit', `document-manager/leads/${$scope.candidate.id}/lead-documents`);
      }
      promise.then((response) => {
        $scope.loading.documents = false;
        if (response.status === 200) {
          $scope.documents = response.data;
          if ($scope.documents[0]) {
            selectDocument($scope.documents[0]);
          }
        } else {
          $rootScope.api_status('alert-danger');
        }
      }).catch(() => {
        $scope.loading.documents = false;
        $scope.documents = [];
      });
    }

    $scope.$on('ReloadDocuments', (evt, leadID) => {
      // Note: do NOT remove the 'evt' paramer, as that will break the function
      getDocuments(leadID);
    });

    function deleteDocument(document) {
      $scope.loading.documents = true;
      let promise = {};
      promise = api.service_delete('toolkit', `document-manager/lead-documents/${document.id}`);
      promise.then((response) => {
        $scope.loading.documents = false;
        if (response.status === 200 || response.status === 204) {
          $scope.documents.splice($scope.documents.indexOf(document), 1);
          selectDocument($scope.documents[0]);
        } else {
          $rootScope.api_status('alert-danger');
        }
      }).catch(() => {
        $scope.loading.documents = false;
        $scope.documents = [];
      });
    }

    function confirmDeleteDocument(document) {
      $ngConfirm({
        title: utils.out('Êtes-vous sûr?', 'Are you sure?'),
        content: utils.out("Une fois qu'un fichier est supprimé, cette action ne peut pas être annulée.", 'Once a file is deleted, this action cannot be reversed.'),
        scope: $scope,
        buttons: {
          Delete: {
            text: utils.out('Supprimer', 'Delete'),
            btnClass: 'btn btn-danger',
            action: () => {
              deleteDocument(document);
            },
          },
          Cancel: {
            text: utils.out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            // keys: ['enter', 'shift'],
          },
        },
      });
    }

    function init() {
      if (!$scope.candidate && !$scope.documents) {
        $rootScope.api_status('alert-danger', 'Missing candidate data.', 'Données de candidat manquantes.', 'ERROR', 'ERREUR', 5000);
      } else if (!$scope.documents) {
        getDocuments();
      }
      if (!$scope.fileCategories || !$scope.fileCategories.length) {
        getFileCategories();
      }
    }
    init();

    scope = {
      selectDocument,
      confirmDeleteDocument,
      shareDocs,
      printDoc,
      downloadDoc,
      openMdMenu,
      closeShareDocModal,
      addDocumentToList,
    };
    angular.extend($scope, scope);
  }

  viewDocCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '$ngConfirm',
    '$timeout',
    '$uibModal',
  ];

  angular.module('atlas').directive('viewDoc', () => ({
    scope: {
      mode: '=',
      documents: '@',
      candidate: '=',
      fileCategories: '=',
    },
    controller: viewDocCtrl,
    templateUrl: './employer-profile/directives/view-doc/view-doc.template.html',
  }));
  // eslint-disable-next-line no-undef
}(angular));
