(function (angular) {
  function CandidatesListingController(
    $scope,
    $rootScope,
    api,
    _,
    Event,
    utils,
    $timeout,
    worklandLocalize,
    $uibModal,
    // matchService,
    $ngConfirm,
    applicationService,
    $q,
    $filter,
    Pager,
    storageService,
  ) {
      function createModuleTab(
        module,
        labelEn,
        labelFr,
        icon,
        filterName,
        disabled,
      ) {
        return {
          module,
          labelEn,
          labelFr,
          icon,
          filterName,
          disabled,
        };
      }

      $scope.candidateModuleTabs = [
        createModuleTab('cv', 'CV', 'CV', '', 'file', true),
        createModuleTab('notes-module', 'Notes', 'Remarques', 'list-alt', 'notes', true),
        createModuleTab('history-module', 'History', 'Historique', 'time', 'History', true),
        createModuleTab('email-composer', 'Emails', 'Courriels', 'envelope', 'emailed', false),
        createModuleTab('interview-module', 'Schedule Interview', 'Planifier une entrevue', 'calendar-plus', 'interviews', false),
        createModuleTab('reference-module', 'Reference Request', 'Demande de référence', 'clipboard-check', 'referencesRequested', false),
        // createModuleTab('backcheck-module', 'Background Check', 'Vérification des antécédents', 'eye-open', 'backcheck', false),
        createModuleTab('ised-send-questionnaires-module', 'Send Questionnaire', 'Envoyer le questionnaire', 'clipboard-question', 'questionnaires', false),
        createModuleTab('psychometric-test-module', 'Psychometric Test', 'Test psychométrique', 'send', 'psychometric-test', true),
        createModuleTab('rejection-module', 'Reject', 'Rejet', 'thumbs-down', 'rejected', false),
        createModuleTab('tag-module', 'Tags', 'Étiquettes', 'tags', 'tags', false),
        createModuleTab('application-clone-module', 'Move to Job', 'Déplacer', 'arrow-right-from-bracket', 'move', false),
        createModuleTab('substitutus-module', 'Replacement', 'Remplacement', 'arrow-right-arrow-left', 'substitute', false),
        createModuleTab('docu-transfer', 'DocuSecur', 'DocuSecur', 'file-shield', 'docu-transfer', false),
        createModuleTab('docusign-module', 'DocuSign', 'DocuSign', 'file-signature', 'docusign', false),
      ];

      function combinedActions(cand, tab) {
        markCandidateSelected(cand, false);
        setTab(tab);
        addCandidateBulk(cand, false);
      }

      function activateEntry(entry, collection) {
        if (!$scope.isClient) {
          _.each(collection, (_entry) => {
            _entry.active = false;
          });
          entry.active = true;
        } else {
          if (entry.module) {
            if (entry.module != 'tag-module' && entry.module != 'rejection-module' && entry.module != 'notes-module' && entry.module != 'history-module') {
              entry.active = false;
              entry.disableTabStyle = true;
            }
          }
          if (entry.events) {
            _.each(collection, (_entry) => {
              if (_entry.events[0] === entry.events[0]) {
                _entry.active = true;
              } else {
                _entry.active = false;
              }
              if (_entry.events.indexOf('matches') < 0 && _entry.events.indexOf('applied') < 0 && _entry.events.indexOf('hired') < 0 && _entry.events.indexOf('rejected') < 0) {
                _entry.active = false;
                _entry.disabled = true;
              }
            });
          }
          if (!entry.module && !entry.events) {
            _.each(collection, (_entry) => {
              _entry.active = false;
            });
            entry.active = true;
          }
        }
      }

      function getListCandidateTags(candidates) {
        $scope.assignedTags = [];
        $scope.loadingTagsDone = false;
        const empAccountId = storageService.getItem('account_id');
        if (candidates.length > 0) {
          const account_ids = [];
          angular.forEach(candidates, (cand) => {
            if (cand.account_id !== '') {
              account_ids.push(cand.account_id);
            }
          });
          if (account_ids.length > 0) {
            const promise = api.service_post('indexing', 'indexing/candidates/read-from-account-id-list', { account_ids });
            promise.then((response) => {
              if (response.data.status === 'success') {
                for (let i = 0; i < response.data.data.length; i++) {
                  const canTags = {};
                  canTags.candidate_id = response.data.data[i]._source.user_id;
                  canTags.tags_list = [];
                  const cndTags = response.data.data[i]._source.tags_list;
                  if (cndTags !== null) {
                    angular.forEach(cndTags, (candTag) => {
                      const index = _.findIndex($scope.employerTags, (empTag) => empTag.id === candTag.id && +empAccountId === +candTag.employer_accountId);
                      if (index >= 0) {
                        canTags.tags_list.push($scope.employerTags[index]);
                      }
                    });
                  }
                  $scope.assignedTags.push(canTags);
                }
              } else {
                $rootScope.api_status('alert-danger');
              }
              $scope.loadingTagsDone = true;
            }).catch(() => {
              $rootScope.api_status('alert-danger');
              $scope.loadingTagsDone = true;
            });
          } else {
            $scope.loadingTagsDone = true;
          }
        } else {
          $scope.loadingTagsDone = true;
        }
      }

      function resetBulkParams() {
        $scope.selectedCandidateList = [];
        $scope.candidatesChecked = [];
        $scope.bulk.bulkAction = false;
      }

      function translateLabels() {
        _.each($scope.candidates, (cand) => {
          _.each($scope.workflowStages, (stages) => {
            if (cand.stage === 'Sourced' && stages.translations.en.label === 'Sourced') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Applied' && stages.translations.en.label === 'Applied') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Matched' && stages.translations.en.label === 'Matched') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Prescreen' && stages.translations.en.label === 'Prescreen') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Interview' && stages.translations.en.label === 'Interview') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Test' && stages.translations.en.label === 'Test') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Reference checks' && stages.translations.en.label === 'Reference checks') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Backcheck' && stages.translations.en.label === 'Backcheck') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Offer' && stages.translations.en.label === 'Offer') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Hired' && stages.translations.en.label === 'Hired') {
              cand.stageFr = stages.translations.fr.label;
            }
            else if (cand.stage === 'Rejected' && stages.translations.en.label === 'Rejected') {
              cand.stageFr = stages.translations.fr.label;
            }
          });
        });

      }

      function updateListOfTags() {
        _.each($scope.filterTags, (filterTag) => {
          const indx = _.findIndex($scope.filteredTags, (empTag) => empTag.id === filterTag.id);
          if (indx >= 0) {
            $scope.filteredTags.splice(indx, 1);
          }
        });
      }

      function resetSearchParams() {
        $scope.searchWithCurrentFilter = false;
        $scope.searchWithSavedFilter = false;
      }

      function clearPreselectionFilter(typeOfCandidateFilter, modalFilters) {
        $scope.filterQuestions = [];
        $scope.filterTags = [];
        if (!modalFilters) {
          $scope.advanceFilterOn = false;
          $scope.activeSavedFilter = false;
          $scope.saveFilterTab = false;
          $scope.activeFilterId = false;
          $scope.isCandidateNull = false;
          $scope.filteredTags = angular.copy($scope.employerTags);
        }
        updateListOfTags();
        if (typeOfCandidateFilter) {
          $scope.preSelectionFilterData = [];
          $scope.filterActiveTags = [];
          $scope.filterActiveQuestions = [];
        }
      }

      function getSavedFilters() {
        $scope.savedFiltersLoaded = false;
        $scope.savedFilters = {};
        $scope.waitPromise = api.service_post('indexing', 'indexing/predefined-filters/read-by-current-account', { categories: ['job_candidate_filter'] })
          .then((response) => {
            if (response.data.status === 'success') {
              if (response.data.data.length > 0) {
                $scope.savedFilters = response.data.data;
              } else {
                $scope.savedFilters = [];
              }
            } else {
              $rootScope.api_status('alert-danger');
              $scope.savedFilters = [];
            }
            $scope.savedFiltersLoaded = true;
          }).catch(() => {
            $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your saved filters', 'Désolé, une erreur s\'est produite lors de la récupération de vos filtres enregistrés');
            $scope.savedFilters = [];
            $scope.savedFiltersLoaded = true;
          });
      }

      function cancel() {
        $scope.preselectionFilterModalInstance.close();
        $scope.modalOpened = false;
        $scope.filterTags = $scope.filterActiveTags;
        $scope.filterQuestions = $scope.filterActiveQuestions;
        $scope.preSelectionFilterData = [];
        angular.forEach($scope.filterQuestions, (item) => {
          if (item.question.type === 'mc-ms') {
            angular.forEach(item.answer, (ans) => {
              $scope.preSelectionFilterData.push(ans);
            });
          } else {
            $scope.preSelectionFilterData.push(item.answer);
          }
        });
      }

      function fetchQuestionnaries(ised) {
        api.service_get('toolkit', `questionnaire/questionnaires/${ised.questionnaire_id}`,
          { load_with: 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;' }).then((response) => {
          ised.questions = response.data.data.result.questionnaire_questions;
          $scope.callPreSection = true;
        }).catch(() => {
          $scope.callPreSection = true;
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your questionnaires', 'Désolé, une erreur s\'est produite lors de la récupération de vos questionnaires');
        });
      }

      function openAdvanceSearchPanel() {
        $scope.search.text = ''; // should be regular search or advanced
        $scope.isedQuestionnaire = $scope.isedQuestionnaireId;
        if (!$scope.callPreSection) {
          if ($scope.isedQuestionnaire.length) {
            angular.forEach($scope.isedQuestionnaire, (item, key) => {
              fetchQuestionnaries(item);
            });
          } else {
            $scope.callPreSection = true;
          }
          getSavedFilters();
        }
        $scope.preselectionFilterModalInstance = $uibModal.open({
          animation: true,
          templateUrl: './employer-profile/views/modal-templates/preselection-filter-model.template.html',
          scope: $scope,
          size: 'lg',
          backdrop: 'static',
          keyboard: false,
        });
        $scope.modalOpened = true;
        if ($scope.filterActiveTags) {
          $scope.filterTags = angular.copy($scope.filterActiveTags);
        }
        if ($scope.filterActiveQuestions) {
          $scope.filterQuestions = angular.copy($scope.filterActiveQuestions);
        }
      }

      function reloadDataInModal() {
        $scope.saveFilter.en = "";
        $scope.saveFilter.fr = "";
        getSavedFilters();
        $scope.saveFilterTab = true;
        $scope.preselectionFilterModalInstance.close();
        $scope.modalOpened = false;
        openAdvanceSearchPanel();
      }

      function revealMatchedInfoForAgency() {
        // @agency: this feature is for agency
          $scope.userIdsToCheck = [];
          angular.forEach($scope.candidates, (c) => {
            if (c.match && c.stage == "Matched") {
              $scope.userIdsToCheck.push(c.user_id);
            }
          })
          api.service_post('indexing', 'indexing/candidates/ownership/filter', {
            user_ids: $scope.userIdsToCheck
          }).then( (response) => {
            if (response.data.status === 'success') {
              angular.forEach($scope.candidates, (candidate) => {
                candidate.registeredAgencyCandidate = false;
                angular.forEach(response.data.data.user_ids, (user, key) => {
                  if (candidate.user_id === user) {
                    candidate.registeredAgencyCandidate = true;
                  } 
                })
              })                
            } else {
              $rootScope.api_status('alert-danger', 'Sorry, due to an error we will not be able to display matched candidates information.', 'Désolé, une erreur s\'est produite. Nous ne pourrons pas afficher les informations des candidats.');
            }
          }).catch( () => {
            $rootScope.api_status('alert-danger', 'Sorry, due to an error we will not be able to display matched candidates information.', 'Désolé, une erreur s\'est produite. Nous ne pourrons pas afficher les informations des candidats.');
          })
      }

      function matching() {
        return matchService.getData('getmatch', { 
          requestId: $scope.jobId 
        }).then( (response) => {
          if (response && "data" in response && response.data.status === 'ok') {
            const matchObj = response.data.data;
            function userIdExists(userId) {
              return matchObj.data.results.some((o) => o.canUserId === userId);
            }
            if (matchObj) {
              _.each($scope.candidates, (c) => {
                if (userIdExists(c.user_id)) {
                  c.match = _.where(matchObj.data.results, { canUserId: c.user_id })[0].match;
                  c.account_id = _.where(matchObj.data.results, { canUserId: c.user_id })[0].userId;
                  c.progressBar = `${Math.round(c.match)}%`;
                }               
              });   
              if (storageService.getItem('account_type') === 'agency' && $scope.currentStage.translations.en.label == "Matched") {
                revealMatchedInfoForAgency();
              }
            }
          }         
        }).catch( () => {
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching the matched results! Please report this issue to our support team.', 'Désolé, une erreur s\'est produite lors de la récupération des résultats de match. Veuillez signaler ce problème à notre équipe d\'assistance.')
        })
      }

      function disableTabsForClient() {
        _.each($scope.candidateModuleTabs, (tab) => {
          if (tab.module === 'rejection-module' || tab.module === 'tag-module' || tab.module === 'notes-module' || tab.module === 'history-module') {
            tab.disable = false;
            tab.disableTabStyle = false;
          } else {
            tab.active = false;
            tab.disableTabStyle = true;
          }          
        });
      }

      function disableTabsForManager() {        
          _.each($scope.candidateModuleTabs, (tab) => {
            if (tab.module === 'cv' || tab.module === 'interview-module' || tab.module === 'rejection-module' || tab.module === 'tag-module' || tab.module === 'docu-transfer') {
              tab.disable = false;
              tab.disableTabStyle = false;
            } else {
              tab.active = false;
              tab.disableTabStyle = true;
            }
          })
      }

      function disableTabsForAgency() {
        _.find($scope.candidateModuleTabs, (tab) => {
          if (tab.module === "substitutus-module") {
            tab.disabled = true;
            tab.active = false;
          }
        });
      }

      function disableAllCandidateModuleTabs(disable) {
        if (disable) {
          _.each($scope.candidateModuleTabs, (tab) => {
            if (tab.module === 'cv' || tab.module === 'notes-module' || tab.module === 'history-module') {
              tab.disable = false;
            } else {
              tab.active = false;
              tab.disableTabStyle = true;
            }
          });
        } else {
          _.each($scope.candidateModuleTabs, (tab) => {
            tab.active = true;
            tab.disableTabStyle = false;
          });
          if ($scope.isClient) {
            disableTabsForClient();
          }
          if ( $rootScope.currentUser.permissions.isDeptMgrRecruiter ) {
            disableTabsForManager();
          }
          if ($rootScope.currentUser.permissions.isAgency) {
            disableTabsForAgency();
          }
        }
      }

      function disableTabsForMatchedStage(stage) {
        if (stage) {
          if (stage.events.indexOf('matches') > -1) {
            disableAllCandidateModuleTabs(true); // no actions for matched candidates
          } else {
            // Enabled all tabs
            disableAllCandidateModuleTabs();
          }
        } else {
          // Enabled all tabs
          disableAllCandidateModuleTabs();
        }
      }

      function splitWorkflowStages() {
        $scope.stages = {
          firstList: [],
          secondList: [],
          thirdList: [],
        }
        _.each($scope.workflowStages, (stage) => {
          if (['Sourced', 'Applied', 'Matched'].includes(stage.translations.en.label)) {
            $scope.stages.firstList.push(stage);
          } else if (['Rejected', 'Hired'].includes(stage.translations.en.label)) {
            $scope.stages.thirdList.push(stage);
          } else {
            $scope.stages.secondList.push(stage);
          }
        });
      };

      function getCandidates(page, userIds) {
        $('html, body').animate({ scrollTop: 0 }, 500);
        $scope.loadingDone = false;
        $scope.candidates = [];
        $scope.candidate = null;
        $scope.isCandidateNull = false;
        $scope.bulk.allSelected = false;
        resetBulkParams();

        const param = {
          page,
          page_size: $scope.pageInfo.pageSize
        };
        if($scope.search.text) {
          param.search = $scope.search.text;
        }
        if ($scope.isSelectedFilter) {
          param.stage_id = [$scope.selectedFilter.id];
        }
        if (userIds) {
          param.user_id = userIds;
        }
        if ($scope.isExternalCandidate) {
          param.is_external = +$scope.isExternalCandidate;
        } 

        const promise = api.service_post('workflow', `workflows/jobs/${$scope.jobId}/candidates`, param);
        return promise.then((response) => {          
          $scope.candidates = response.data.data;
          $scope.pager = Pager.GetPager(response.data.total, page, $scope.pageInfo.pageSize);
          $scope.candidatesFound = response.data.total;

          if ($scope.candidates.length === 0) {
            $scope.isCandidateNull = true;
          }

          angular.forEach($scope.candidates, (cand) => {
            if (cand.photo) {
              cand.photo = `${window.appConfig.MINIO_URL}media/Profile/Logos/${cand.photo}`;
            }
          })
          const cndts = $scope.candidates;
          getListCandidateTags(cndts);

          const newCandidateCount = _.countBy($scope.candidates, (cand) => cand.stage === 'Applied' && cand.new_applicant === 1);
          $scope.newCandidateCount = newCandidateCount.true ? newCandidateCount.true : 0;

          $scope.candidatesMatched = _.filter($scope.candidates, (cand) => cand.stage == 'Matched');
          if (!$scope.isSelectedFilter) {
            // Exclude matched candidates out of all
            $scope.candidates = _.filter($scope.candidates, (cand) => cand.stage != 'Matched');
            //Exclude candidates from disabled stages 
            if($scope.isClient || $scope.isDeptMgrRecruiter) {
              $scope.candidatesFiltered = [];
              angular.forEach($scope.workflowStages, (stage) => {
                if(stage.active != false) {
                  angular.forEach($scope.candidates, (candidate) => {
                    if (candidate.stage == stage.translations.en.label) {
                      $scope.candidatesFiltered.push(candidate);
                    }
                  })
                }
              })
              $scope.candidates = $scope.candidatesFiltered;
            }

            if ($scope.candidates.length === 0) {
              $scope.isCandidateNull = true;
            }
            disableTabsForMatchedStage();            
          }

          angular.forEach($scope.candidates, (candidate) => {
            candidate.visible = false;
            candidate.indeedApply = false;
            candidate.indeedSponsored = false;
            candidate.indeedTargeted = false;
            candidate.indeedOrganic = false;
            if(candidate.indeed_application && Object.keys(candidate.indeed_application).length > 0) {
              candidate.indeedApply = true;              
              if(candidate.indeed_application.sponsored == 1) {
                candidate.indeedSponsored = true;
              }
              if(candidate.indeed_application.targeted_apply_ad == 1) {
                candidate.indeedTargeted = true;
              }
              if (candidate.indeed_application.sponsored == 0 && candidate.indeed_application.targeted_apply_ad == 0) {
                candidate.indeedOrganic = true;
              }
            }            
          });
          if ($scope.showCandidateProfile && $scope.candidates.length > 0) {
            markCandidateSelected($scope.candidates[0], false);
          }
          translateLabels();
          splitWorkflowStages();
          $scope.loadingDone = true;
        // }).then( () => {
        //   return matching();
        }).catch(() => {
          $scope.loadingDone = true;
        });
      }

      function reloadCandidatesWithNoFilters() {
        $scope.filterQuestions = [];
        $scope.preSelectionFilterData = [];
        $scope.filterTags = [];
        $scope.filterActiveTags = [];
        $scope.filterActiveQuestions = [];
        $scope.advanceFilterOn = false;
        $scope.activeSavedFilter = false;
        $scope.saveFilterTab = false;
        $scope.activeFilterId = false;
        $scope.isCandidateNull = false;
        $scope.filteredTags = angular.copy($scope.employerTags);
        updateListOfTags();
        resetSearchParams();
        getCandidates(1);
        if ($scope.modalOpened) {
          reloadDataInModal();
        }
      }

      function setPage(page) {
        if (page < 1 || page > $scope.pager.totalPages) {
          return;
        }
        getCandidates(page);
      }

      function getJobWorkflowStages() {
        $scope.pager = {};
        $scope.loadingDone = false;
        $scope.workflowStages = [];

        const promise = api.service_post('workflow', `workflows/${$scope.jobWorkflowId}/jobs/${$scope.jobId}/stages`, {});
        promise.then((response) => {
          if (response.data.status !== 'fail') {
            $scope.workflowStages = $filter('orderBy')(response.data.stages, 'order');
            // Disable stages for clients
            if ($scope.isClient) {           
              // @agency: can add conditions here
               _.each($scope.workflowStages, (_entry) => {
                if (_entry.events.indexOf('matches') < 0 && _entry.events.indexOf('applied') < 0 && _entry.events.indexOf('hired') < 0 && _entry.events.indexOf('rejected') < 0) {
                  _entry.active = false;
                  _entry.disabled = true;
                }
              }); 
            }
            if ($scope.isDeptMgrRecruiter) {
              _.each($scope.workflowStages, (_entry) => {
                if (_entry.events.indexOf('matches') > -1 || _entry.events.indexOf('applied') > -1 || _entry.events.indexOf('sourced') > -1 || _entry.events.indexOf('rejected') > -1) {
                  _entry.active = false;
                  _entry.disabled = true;
                } else {
                  _entry.disabled = false;
                }
              });
            }
            if ($scope.isSelectedFilter) {
              $scope.workflowStages.forEach((stage) => {
                if (!$scope.isDeptMgrRecruiter ) {
                  if (stage.translations.en.label === 'Applied') {
                    stage.active = true;
                    $scope.selectedFilter = stage;
                  } else {
                    stage.active = false;
                  }
                } 
              });
              if ($scope.isDeptMgrRecruiter ) {
                var index = $scope.workflowStages.findIndex( (stage )=> {
                  return stage.disabled == false;
                })
                $scope.workflowStages[index].active = true;
                $scope.selectedFilter = $scope.workflowStages[index]; 
              }
              $scope.currentStage = $scope.selectedFilter;
            }
            setPage(1);
          } else {
            $scope.loadingDone = true;
            $scope.loadingTagsDone = true;
            return;
          }
        }).catch(() => {
            $scope.loadingDone = true;
            $scope.loadingTagsDone = true;
          });
      }

      function changeStage(selectedStage) {
        $scope.isSelectedFilter = true;
        $scope.selectedFilter = selectedStage;
        $scope.currentStage = selectedStage;
        if ($scope.isClient) {
          if (selectedStage.events.indexOf('matches') < 0 && selectedStage.events.indexOf('applied') < 0 && selectedStage.events.indexOf('hired') < 0 && selectedStage.events.indexOf('rejected') < 0) {
            return;
          }
        }
        $scope.selectFunelLabel = utils.out(selectedStage.translations.fr.label, selectedStage.translations.en.label);
        $scope.isExternalCandidate = 'null';
        $scope.selectFunelCount = selectedStage.count;
        $scope.showAllCandidateActive = false;
        activateEntry(selectedStage, $scope.workflowStages);
        reloadCandidatesWithNoFilters();
        disableTabsForMatchedStage(selectedStage);       
      }
      // reload counters for filtered lists
      Event.on('listFilterApplied', ($event, filterParams) => {
        $scope.candidates = [];
        if (filterParams.message
          && (filterParams.message === 'Success' || filterParams.message === 'Update')) {
          $scope.feedBack.isFailure = false;
          $scope.feedBack.isSuccess = true;
          $scope.feedBack.message = $scope.out('Réussite', 'Success');
        } else {
          $scope.feedBack.isFailure = true;
          $scope.feedBack.isSuccess = false;
          $scope.feedBack.message = $scope.out('Échec', 'Failure');
        }
        activateEntry({}, $scope.workflowStages);
        getJobWorkflowStages();
      });

      $scope.feedBack = {};
      $scope.feedBack.close = function () {
        $scope.feedBack.isFailure = false;
        $scope.feedBack.isSuccess = false;
        $scope.feedBack.message = '';
      };

      // assignTags for Card candidate
      function employerTags() {
        $scope.employerTags = [];
        $scope.filteredTags = [];
        const promise = api.service_get('toolkit', 'document-manager/tags');
        promise.then((response) => {
          const status = response.data.status;
          if (status === 'success') {
            $scope.employerTags = response.data.data.result;
            $scope.filteredTags = angular.copy($scope.employerTags);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.employerTags = [];
        });
      }

      function disableTab(moduleName, enable) {
        if (!enable) {
          _.each($scope.candidateModuleTabs, (tab) => {
            if (tab.module === moduleName) {
              tab.active = false;
              tab.disable = true;
              tab.disableTabStyle = true;
            }
          });
        } else {
          _.each($scope.candidateModuleTabs, (tab) => {
            if (tab.module === moduleName) {
              tab.disable = false;
              tab.disableTabStyle = false;
            }
          });
        }
      }

      function setTab(tab) {
        $scope.selectedTab = tab;
        $('ul.action-tabs li').parent().find('li.active').removeClass('active');
        $(`#${tab}`).addClass('active');        
      }

      $scope.$watch('selectedTab', (tab) => {
        if (tab === 'email-composer' && $scope.isDeptMgrRecruiter ) {
          setTab('showDocuments');
        }
      })

      let createTimeout;
      let createTimeout1;

      function loadCandidateData(candidate) {
        // chosen candidate is active
        if (!candidate.match && candidate.stage !== "Matched") {
          activateEntry(candidate, $scope.candidates);
        } else {
          activateEntry(candidate, $scope.candidatesMatched);
        }
        // timeout needed for matched candidates
        createTimeout = $timeout(() => {
          if (!candidate.visible || !$scope.isATSFull) {
            activateEntry($scope.candidateModuleTabs[0], $scope.candidateModuleTabs); // only CV module is active
          } else if (candidate.match && candidate.stage === "Matched") {
            disableAllCandidateModuleTabs(true); // no actions for matched candidates
            setTab('showDocuments');
          } else {
            // Enabled all tabs
            disableAllCandidateModuleTabs();
            if ($scope.isClient && !$scope.isPremiumClient) {
              disableTabsForClient();
              setTab('showHistory');
            }
            if($rootScope.currentUser.permissions.isDeptMgrRecruiter) {
              disableTabsForManager();
            }
            if ($rootScope.currentUser.permissions.isAgency) {
              disableTabsForAgency();
            }
          }
        }, 100);

        candidate.visible = true;
        _.each($scope.candidates, (cand) => {
          if (cand.user_id === candidate.user_id) {
            cand.visible = true;
          }
        });
        $scope.candidate = candidate;
        if ($scope.selectedTab === 'showInternalMetadata' && !$scope.candidate.employee_details) {
          setTab('showDocuments');
        }
        // scroll to the top to see candidate menu and details
        $('html, body').animate({ scrollTop: 0 }, 500);
      }

      function changeApplicantViewStatus(candidate, value) {
        applicationService.patch_query('application', +candidate.application_id, 'is-new', { is_new: +value }).then((response) => {
          if (response.status == 200 || response.status == 201) {
            if (!candidate.new_applicant_viewing) {
              if (candidate.new_applicant == 1) {
                candidate.new_applicant_viewing = true;
                $scope.newCandidateCount--;
              } else {
                candidate.new_applicant = 1;
                $scope.newCandidateCount++;
              }
            } else if (candidate.new_applicant == 1 && value == 1) {
              candidate.new_applicant_viewing = false;
              $scope.newCandidateCount++;
            }
          }
          _.each($scope.workflowStages, (stage) => {
            _.each(stage.candidates, (cand) => {
              if (cand.user_id == candidate.userId) {
                cand.new_applicant = candidate.new_applicant;
              }
            });
          });
        }).catch(() => {
          // @todo - message to user
          $rootScope.api_status('alert-danger');
        });
      }

      function selectCandidate(candidate) {
        const idx = _.findIndex($scope.selectedCandidateList, (cand) => cand.user_id === candidate.user_id);
        if ($scope.candidatesChecked[candidate.user_id] && idx === -1) {
          $scope.selectedCandidateList.push(candidate);
        } else if (!$scope.candidatesChecked[candidate.user_id] && idx >= 0) {
          $scope.selectedCandidateList[idx].active = false;
          $scope.selectedCandidateList.splice(idx, 1);
          if ($scope.bulk.allSelected) {
            $scope.bulk.allSelected = false;
          }
        }
        $scope.bulk.bulkAction = $scope.selectedCandidateList.length > 1;
        if ($scope.bulk.bulkAction) {
          $scope.candidate = null;
        }

        angular.forEach($scope.candidates, (candidateNotSelected) => {
          candidateNotSelected.visible = false;
        });
        if ($scope.selectedCandidateList.length === 1) {
          loadCandidateData($scope.selectedCandidateList[0]);
        }
      }

      function uncheckOtherCandidates(candidate) {
        for (let i = $scope.selectedCandidateList.length - 1; i >= 0; i--) {
          if ($scope.selectedCandidateList[i].user_id !== candidate.user_id) {
            $scope.candidatesChecked[$scope.selectedCandidateList[i].user_id] = false;
            $scope.selectedCandidateList[i].active = false;
            $scope.selectedCandidateList.splice(i, 1);
          }
        }
        if ($scope.bulk.allSelected) {
          $scope.bulk.allSelected = false;
        }
      }

      function markedCandidate(candidate, isDetailPage) {
        if ($scope.selectedCandidateList.length <= 1 && isDetailPage) {
          resetBulkParams();
          if ($scope.selectedTab === 'showInternalMetadata' && !candidate.employee_details) {
            setTab('showDocuments');
          }
        }
        $scope.showCandidateProfile = true;
        if (!$scope.selectedTab) {
          if (!$scope.isClient || ($scope.isClient && $scope.isPremiumClient)) {
            setTab('showDocuments');
          } else {
            setTab('showNotes');
          }
        } else if ($scope.selectedCandidateList.length > 1 && $scope.selectedTab === 'showInternalMetadata') {
          setTab('showDocuments');
        }

        if (angular.isUndefined($scope.candidatesChecked[candidate.user_id])
                        || !$scope.candidatesChecked[candidate.user_id]) {
          $scope.candidatesChecked[candidate.user_id] = true;
        }

        if (isDetailPage) {
          uncheckOtherCandidates(candidate);
        }

        selectCandidate(candidate);
        // call to change the candidate view status
        if (candidate.new_applicant == 1 && candidate.application_id) {
          changeApplicantViewStatus(candidate, 0);
        }
      }

      function markCandidateSelected(cand, isDetailPage) {
        $scope.job_application_id = cand.application_id;
        const index = _.findIndex($scope.detailedCanidatesList, (detailedcandidate) => detailedcandidate.user_id === cand.user_id);
        if (index == -1) {
          cand.userId = cand.user_id; //@todo has to be eliminated from the code, use user_id only
          cand.name = cand.first_name + " " + cand.last_name;
          $scope.detailedCanidatesList.push(cand);
          markedCandidate(cand, isDetailPage);
        } else {
          cand = $scope.detailedCanidatesList[index];
          markedCandidate(cand, isDetailPage);
        }
        $scope.candListEvent = !$scope.candListEvent;
      }

      function init() {
        $scope.search = { text: '' };
        $scope.callPreSection = false;
        $scope.isSelectedFilter = true;
        $scope.cardsListToggle = false;
        getJobWorkflowStages();
        employerTags();
      }

      const initOnce = _.once(init);
      $scope.$watch('init', (initVal) => {
        if (initVal) {
          initOnce();
        }
      });

      Event.on('CANDIDATE_MOVED_EVENT', ($event, data) => {
        if ($scope.isSelectedFilter) {
          $scope.workflowStages.forEach((list) => {
            if (list.translations.en.label == $scope.selectedFilter.translations.en.label) {
              list.active = true;
            } else {
              list.active = false;
            }
          });
          if (data.user_ids.length === 1) {
            $scope.candidates.forEach((candidate) => {
              if (candidate.user_id === data.user_ids[0]) {
                const index = _.findIndex($scope.candidates, (cand) => cand.user_id === candidate.user_id);
                if ($scope.candidates.length > 1) {
                  if (index < ($scope.candidates.length - 1)) {
                    markCandidateSelected($scope.candidates[index + 1], true);
                  } else {
                    markCandidateSelected($scope.candidates[index - 1], true);
                  }
                }
              }
            });
          } else { // bulk moving, need to open the next candidate profile in the current stage or the previous one if he was the last in the list
            const indexes = [];
            // previous stage
            $scope.candidates.forEach((candidate) => {
              data.user_ids.forEach((id) => {
                if (candidate.user_id === id) {
                  indexes.push($scope.candidates.indexOf(candidate));
                }
              });
            });
            const lastIndex = indexes[indexes.length - 1];
            if ($scope.candidates.length > indexes.length) {
              if (lastIndex < ($scope.candidates.length - 1)) {
                for (let i = 1; i <= indexes.length; i++) {
                  const inArray = indexes.indexOf(lastIndex + i);
                  if (inArray === -1) {
                    markCandidateSelected($scope.candidates[lastIndex + i], true);
                    break;
                  }
                }
              } else {
                for (let i = 1; i <= indexes.length; i++) {
                  const inArray = indexes.indexOf(lastIndex - i);
                  if (inArray === -1) {
                    markCandidateSelected($scope.candidates[lastIndex - i], true);
                    break;
                  }
                }
              }
            }
          }
        }
      });

      Event.on('CANDIDATE_TAGS_EVENT', ($event, params) => {
        angular.forEach($scope.assignedTags, (old_tagged_cand) => {          
          angular.forEach(params, (newly_tagged_cand) => {
            // replace with new tags
            if (old_tagged_cand.candidate_id == newly_tagged_cand.candidate_id) {
              old_tagged_cand.tags_list = newly_tagged_cand.tags_list;
            }            
          })
        })
        // if tags did not exist yet add them to $scope.assignedTags
        angular.forEach(params, (newly_tagged_cand) => {
          const indx = _.findIndex($scope.assignedTags, (tag) => tag.candidate_id == newly_tagged_cand.candidate_id);
          if (indx < 0) {
            $scope.assignedTags.push(newly_tagged_cand);
          }
        })  
      });

      function toggleView(cardsListToggle) {
        $scope.cardsListToggle = cardsListToggle;
      }

      function activeActionTab(action) {
        activateEntry(action, $scope.candidateModuleTabs);
      }

      // Preselection Filter Start
      function rzsliderForQuestion(ques) {
        $scope.question = ques;
        if (!$scope.question.slider) {
          $scope.question.slider = {
            minValue: 1,
            maxValue: ques.question.scale_range,
          };
        }
        $scope.question.slider.options = {
          showTicksValues: true,
          showTicks: true,
          floor: 1,
          ceil: ques.question.scale_range,
          step: 1,
          minRange: 1,
          maxRange: ques.question.scale_range,
        };
      }

      function rzsliderForsavedQuestion(ques) {
        $scope.question = ques;
        if (!$scope.question.slider) {
          $scope.question.slider = {
            minValue: 0,
            maxValue: 0,
          };
        }
        $scope.question.slider.options = {
          showTicksValues: true,
          showTicks: true,
          floor: ques.scale_min,
          ceil: ques.scale_max,
          step: 1,
          minRange: 0,
          maxRange: 0,
        };
      }

      function toolkitRequest() {
        $scope.preselectedCandidatesIds = [];
        return $scope.promiseToolkit = api.service_post('toolkit', 'questionnaire/answers/filter-candidates-by-answers', {
          answers: $scope.preSelectionFilterData,
        }).then((response) => {
          if (response.data.status === 'success') {
            $scope.advanceFilterOn = true;
            $scope.preselectedCandidatesIds = response.data.data.result;
          } else {
            $rootScope.api_status('alert-danger');
            $scope.loadingDone = true;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loadingDone = true;
        });
      }

      function indexingRequest(searchTags) {
        $scope.taggedCandidatesIds = [];
        const tagIds = [];
        angular.forEach(searchTags, (tag) => {
          tagIds.push(tag.id);
        });
        return $scope.promiseIndexing = api.service_post('indexing', 'indexing/candidates/read-from-tag-id-list', {
          tag_ids: tagIds,
        }).then((response) => {
          if (response.data.status === 'success') {
            $scope.advanceFilterOn = true;
            $scope.taggedCandidatesIds = response.data.data.candidate_user_ids;
          } else {
            $rootScope.api_status('alert-danger');
            $scope.loadingDone = true;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loadingDone = true;
        });
      }

      function searchWithCurrentFilters(page) {
        if ($scope.activeSavedFilter) {
          $ngConfirm({
            type: 'blue', 
            title: null, 
            content: $scope.out("L'un de vos filtres enregistrés est actuellement actif. Veuillez d'abord le désactiver", 
              'One of your saved filters is currently active. Please deactivate it at first'),
            buttons: {
              Ok: {
                text: $scope.out('Désactiver', 'Deactivate'),
                btnClass: 'btn btn-secondary',
                action() {
                  reloadCandidatesWithNoFilters();
                },
              },
              cancel: {
                text: $scope.out('Fermer', 'Close'),
                btnClass: 'btn btn-alt-secondary',
                action() {
                  
                },
              }
            },
          });
          return;
        }
        $scope.saveFilterTab = false;
        $scope.isCandidateNull = false;
        $scope.combinedCandidates = [];
        $scope.searchWithCurrentFilter = true;
        $scope.loadingDone = false;
        $scope.preselectionFilterModalInstance.close();
        $scope.modalOpened = false;
        let searchTags;
        if ($scope.modalOpened) {
          searchTags = $scope.filterTags;
        } else {
          $scope.filterActiveTags = $scope.filterTags;
          searchTags = $scope.filterActiveTags;
          $scope.filterActiveQuestions = $scope.filterQuestions;
        }
        // have Questions don't have Tags
        if ($scope.preSelectionFilterData.length && searchTags.length === 0) {
          return toolkitRequest().then(() => {
            getCandidates(page, $scope.preselectedCandidatesIds);
          });
          // don't have Questions have Tags
        } if ($scope.preSelectionFilterData.length === 0 && searchTags.length) {
          return indexingRequest(searchTags).then(() => {
            getCandidates(page, $scope.taggedCandidatesIds);
          });
          // have Questions have Tags
        } if ($scope.preSelectionFilterData.length && searchTags.length) {
          const promises = [];
          toolkitRequest();
          indexingRequest(searchTags);
          promises.push($scope.promiseToolkit, $scope.promiseIndexing);
          $q.all(promises).then(() => {
            angular.forEach($scope.preselectedCandidatesIds, (filteredCand) => {
              angular.forEach($scope.taggedCandidatesIds, (taggedCand) => {
                if (filteredCand === taggedCand) {
                  $scope.combinedCandidates.push(filteredCand);
                }
              });
            });
            getCandidates(page, $scope.combinedCandidates);
          });
        } else {
          reloadCandidatesWithNoFilters();
        }
      }

      function saveFilterRequest(nameEn, namefr) {
        $scope.advanceFilterOn = true;
        let msgEn = '';
        let msgFr = '';
        if (nameEn && namefr) {
          $scope.saveFilterSection = false;
          msgEn = 'Saving your filter';
          msgFr = 'Nous sauvegardons votre filtre';
          $rootScope.api_status('waiting', msgEn, msgFr);
          const data = {
            translations: {
              en: {
                name: nameEn,
                description: nameEn,
              },
              fr: {
                name: namefr,
                description: namefr,
              },
            },
            category: 'job_candidate_filter',
            requests: [],
          };
          $scope.questionRequest = {
            type: 'POST',
            service: 'toolkit',
            route: 'questionnaire/answers/filter-candidates-by-answers',
            authenticated: true,
            payload: '',
            missing_body_params: ['answers.*.job_id'],
          };
          $scope.tagRequest = {
            type: 'POST',
            service: 'indexing',
            route: 'indexing/candidates/read-from-tag-id-list',
            authenticated: true,
            payload: '',
          };
          const promise = api.service_post('indexing', 'indexing/predefined-filters', data);
          // have Questions don't have Tags
          if ($scope.preSelectionFilterData.length && $scope.filterTags.length === 0) {
            $scope.questionRequest.payload = JSON.stringify({
              answers: $scope.preSelectionFilterData,
            });
            data.requests.push($scope.questionRequest);
            promise.then((response) => {
              if (response.data.status === 'success') {
                $rootScope.api_status('alert-success', 'The filter is saved', 'Le filtre est enregistré');
                $scope.preSelectionFilterData = [];
                $timeout(() => {
                  reloadDataInModal();
                }, 1000);              
              } else {
                $rootScope.api_status('alert-danger', 'Sorry, an error has occurred', 'Désolé, une erreur s\'est produite');
              }
            }).catch(() => {
              $rootScope.api_status('alert-danger', 'The filter was not saved', 'Le filtre n\'a pu être enregistré');
            });
          // don't have Questions have Tags
          } else if ($scope.preSelectionFilterData.length === 0 && $scope.filterTags.length) {
            const tagIds = [];
            angular.forEach($scope.filterTags, (tag) => {
              tagIds.push(tag.id);
            });
            $scope.tagRequest.payload = JSON.stringify({
              tag_ids: tagIds,
            });
            data.requests.push($scope.tagRequest);
            promise.then((response) => {
              if (response.data.status === 'success') {
                $rootScope.api_status('alert-success', 'The filter is saved', 'Le filtre est enregistré');
                $scope.filterTags = [];
                $scope.filteredTags = angular.copy($scope.employerTags);
                $scope.tag = null;
                $timeout(() => {
                  reloadDataInModal();
                }, 1000);
              } else {
                $rootScope.api_status('alert-danger', 'Sorry, an error has occurred', 'Désolé, une erreur s\'est produite');
              }
            }).catch(() => {
              $rootScope.api_status('alert-danger', 'The filter was not saved', 'Le filtre n\'a pu être enregistré');
            });
            // have Questions have Tags
          } else if ($scope.preSelectionFilterData.length && $scope.filterTags.length) {
            $scope.questionRequest.payload = JSON.stringify({
              answers: $scope.preSelectionFilterData,
            });
            const tagIds = [];
            angular.forEach($scope.filterTags, (tag) => {
              tagIds.push(tag.id);
            });
            $scope.tagRequest.payload = JSON.stringify({
              tag_ids: tagIds,
            });
            data.requests.push($scope.tagRequest);
            data.requests.push($scope.questionRequest);
            promise.then((response) => {
              if (response.data.status === 'success') {
                $rootScope.api_status('alert-success', 'The filter is saved', 'Le filtre est enregistré');
                $scope.preSelectionFilterData = [];
                $scope.filterTags = [];
                $scope.tag = null;
                $scope.filteredTags = angular.copy($scope.employerTags);
                $timeout(() => {
                  reloadDataInModal();
                }, 1000);
              } else {
                $rootScope.api_status('alert-danger', 'Sorry, an error has occurred', 'Désolé, une erreur s\'est produite');
              }
            }).catch(() => {
              $rootScope.api_status('alert-danger', 'The filter was not saved', 'Le filtre n\'a pu être enregistré');
            });
          }
        }
      }

      function deleteSavedFilter(filter) {
        let msgEn; let
          msgFr;
        msgEn = 'Deleting your saved filter';
        msgFr = 'Suppression de votre filtre enregistré';
        $rootScope.api_status('waiting', msgEn, msgFr);
        const promise = api.service_delete('indexing', `indexing/predefined-filters/${filter._id}`);
        promise.then((response) => {
          if (response.data.status === 'success') {
            $scope.tag = null;
            msgEn = 'Filter deleted';
            msgFr = 'Filtre supprimé';
            $rootScope.api_status('alert-success', msgEn, msgFr);
            if ($scope.activeFilterId == filter._id) {
              reloadCandidatesWithNoFilters();
            }
            $timeout(() => {
              reloadDataInModal();
            }, 1000);
          } else {
            $rootScope.api_status('alert-danger', 'The filter was not deleted', 'Le filtre n\'a pu être supprimé');
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', 'The filter was not deleted', 'Le filtre n\'a pu être supprimé');
        });
      }

      function toolkitSavedRequest(route, payload, filter) {
        return $scope.promiseSavedToolkit = api.service_post('toolkit', route, payload).then((response) => {
          if (response.data.status === 'success') {
            $scope.preselectedCandidatesIds = response.data.data.result;
            $scope.advanceFilterOn = true;
            $scope.activeFilterId = filter._id;
          } else {
            $rootScope.api_status('alert-danger');
            $scope.loadingDone = true;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loadingDone = true;
        });
      }

      function indexingSavedRequest(route, payload, filter) {
        return $scope.promiseSavedIndexing = api.service_post('indexing', route, payload).then((response) => {
          if (response.data.status === 'success') {
            $scope.taggedCandidatesIds = response.data.data.candidate_user_ids;
            $scope.advanceFilterOn = true;
            $scope.activeFilterId = filter._id;
          } else {
            $rootScope.api_status('alert-danger');
            $scope.loadingDone = true;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loadingDone = true;
        });
      }

      function activateSavedFilter(filter, page) {
        if ($scope.searchWithCurrentFilter) {
          $ngConfirm({
            icon: 'fa fa-check-circle-o',
            title: '',
            content: $scope.out('Veuillez fermer cette fenêtre et supprimer les filtres actuels', 'Please close this window and delete current filters'),
            type: 'blue',
            typeAnimated: true,
            animation: 'RotateX',
            buttons: {
              ok: {
                text: 'ok',
                btnClass: 'btn-blue',
                action() {
                  $scope.preselectionFilterModalInstance.close();
                  $scope.modalOpened = false;
                },
              },
            },
          });
          return;
        }
        $scope.activeSavedFilter = $scope.out(filter._source.translations.fr.name, filter._source.translations.en.name);
        $scope.saveFilterTab = true;
        $scope.preselectedCandidatesIds = [];
        $scope.combinedCandidates = [];
        $scope.taggedCandidatesIds = [];
        const promises = [];
        $scope.isCandidateNull = false;
        $scope.preselectionFilterModalInstance.close();
        $scope.modalOpened = false;
        $scope.candidates = [];
        $scope.loadingDone = false;
        $scope.searchWithSavedFilter = true;
        $scope.activeFilter = filter;

        if (filter._source.requests.length === 1) {
          if (filter._source.requests[0].service === 'toolkit') {
            toolkitSavedRequest(filter._source.requests[0].route, JSON.parse(filter._source.requests[0].payload), filter).then(() => {
              getCandidates(page, $scope.preselectedCandidatesIds);
            });
          } if (filter._source.requests[0].service === 'indexing') {
            indexingSavedRequest(filter._source.requests[0].route, JSON.parse(filter._source.requests[0].payload), filter).then(() => {
              getCandidates(page, $scope.taggedCandidatesIds);
            });
          }
        } else if (filter._source.requests.length > 1) {
          angular.forEach(filter._source.requests, (request) => {
            if (request.service === 'toolkit') {
              toolkitSavedRequest(request.route, JSON.parse(request.payload), filter);
            }
            if (request.service === 'indexing') {
              indexingSavedRequest(request.route, JSON.parse(request.payload), filter);
            }
          });
          promises.push($scope.promiseSavedToolkit, $scope.promiseSavedIndexing);
          $q.all(promises).then(() => {
            angular.forEach($scope.preselectedCandidatesIds, (filteredCand) => {
              angular.forEach($scope.taggedCandidatesIds, (taggedCand) => {
                if (filteredCand === taggedCand) {
                  $scope.combinedCandidates.push(filteredCand);
                }
              });
            });
            getCandidates(page, $scope.combinedCandidates);
          });
        }
      }

      function checkAnsBeforeAdd(checkQuestion) {
        if (checkQuestion.question.type === 'yes-no' && checkQuestion.yesNo) {
          return false;
        } if (checkQuestion.question.type === 'scale' && checkQuestion.slider.maxValue > 0) {
          return false;
        } if (checkQuestion.question.type === 'mc-ms' && !angular.equals(checkQuestion.ms, {})) {
          return false;
        } if (checkQuestion.question.type === 'mc-ss' && checkQuestion.ss) {
          return false;
        } if (checkQuestion.question.type === 'desc' && checkQuestion.desc) {
          return false;
        }
        return true;
      }

      function pushTochoiceList(choice, question) {
        const data = {};
        data.questionnaire_question_id = question.id;
        data.job_id = $scope.jobId;
        data.choice_id = choice.id;

        const index = $scope.choicesArray.map((item) => item.choice_id).indexOf(data.choice_id);

        if (index !== -1) {
          $scope.choicesArray.splice(data, 1);
        } else {
          $scope.choicesArray.push(data);
        }
      }

      function createQuestionsForFilter(answer) {
        $scope.answer = answer;
        if (answer.question.type === 'yes-no') {
          $scope.saveAns = { questionnaire_question_id: answer.id, job_id: $scope.jobId, boolAnswer: (answer.yesNo == 'true') };
        } else if (answer.question.type === 'scale') {
          $scope.saveAns = {
            questionnaire_question_id: answer.id,
            job_id: $scope.jobId,
            scale_min: parseInt($scope.answer.slider.minValue, 10),
            scale_max: parseInt($scope.answer.slider.maxValue, 10),
          };
        } else if (answer.question.type === 'mc-ms') {
          $scope.saveAns = $scope.choicesArray;
        } else if (answer.question.type === 'mc-ss') {
          $scope.saveAns = { questionnaire_question_id: answer.id, job_id: $scope.jobId, choice_id: answer.ss };
        } else if (answer.question.type === 'desc') {
          $scope.saveAns = { questionnaire_question_id: answer.id, job_id: $scope.jobId, text: answer.desc };
        }
        // pushQuestionInFilter;
        if ($scope.answer.insideFilter === $scope.answer.id) {
          // spliceQuestionsFromFilter;
          const removeIndex1 = $scope.filterQuestions.map((item) => (item.answer.length ? item.answer[0].questionnaire_question_id : item.answer.questionnaire_question_id)).indexOf(answer.id);
          const removeIndex2 = $scope.preSelectionFilterData.map((item) => item.questionnaire_question_id == answer.id);

          if (removeIndex1 > -1) {
            $scope.filterQuestions.splice(removeIndex1, 1);
          }
          for (let i = removeIndex2.length - 1; i >= 0; i--) {
            if (removeIndex2[i]) {
              $scope.preSelectionFilterData.splice(i, 1);
            }
          }
          answer.insideFilter = '';
          answer.open = false;
          // end of spliceQuestionsFromFilter;
          $scope.filterQuestions.push({ question: answer.question, answer: $scope.saveAns });
          if (answer.question.type === 'mc-ms') {
            $scope.saveAns.forEach((item) => {
              $scope.preSelectionFilterData.push(item);
            });
          } else {
            $scope.preSelectionFilterData.push($scope.saveAns);
          }
        } else {
          $scope.filterQuestions.push({ question: answer.question, answer: $scope.saveAns });
          if (answer.question.type === 'mc-ms') {
            $scope.saveAns.forEach((item) => {
              $scope.preSelectionFilterData.push(item);
            });
          } else {
            $scope.preSelectionFilterData.push($scope.saveAns);
          }
        }
        $scope.answer.insideFilter = $scope.answer.id;
        // end of pushQuestionInFilter
        $scope.answer.open = false;
      }

      function removeQuestionsFromFilter(answerToRemove) {
        const answer_id = answerToRemove.answer.length ? answerToRemove.answer[0].questionnaire_question_id : answerToRemove.answer.questionnaire_question_id;
        const removeIndex1 = $scope.filterQuestions.map((item) => (item.answer.length ? item.answer[0].questionnaire_question_id : item.answer.questionnaire_question_id)).indexOf(answer_id);
        const removeIndex2 = $scope.preSelectionFilterData.map((item) => item.questionnaire_question_id == answer_id);

        if (removeIndex1 > -1) {
          $scope.filterQuestions.splice(removeIndex1, 1);
        }
        for (let i = removeIndex2.length - 1; i >= 0; i--) {
          if (removeIndex2[i]) {
            $scope.preSelectionFilterData.splice(i, 1);
          }
        }
        answerToRemove.insideFilter = '';
        answerToRemove.open = false;
        if (answerToRemove.answer.length && $scope.saveAns) {
          for (let i = answerToRemove.answer.length - 1; i >= 0; i--) {
            if (answerToRemove.answer[i].questionnaire_question_id == answer_id) {
              $scope.saveAns.splice(i, 1);
            }
          }
          answerToRemove.answer = [];
        }
      }

      // TODO check tag that tag selected not null
      function checkTagBeforeAdd(checkTag) {
        if (checkTag == null) {
          return false;
        }
        return true;
      }

      // Filter by tags
      function addTagForFilter(selectedTag) {
        if (selectedTag.selected) {
          $scope.filterTags.push(selectedTag.selected);
          $scope.selectedTag.selected = "";
          updateListOfTags();
        }
      }

      function removeTagsFromFilter(removeTag) {
        if (removeTag !== null) {
          const index = _.findIndex($scope.filterTags, (filterTag) => filterTag.id === removeTag.id);
          if (index >= 0) {
            $scope.filterTags.splice(index, 1);
          }
        }
        $scope.filteredTags = [];
        $scope.filteredTags = angular.copy($scope.employerTags);
        updateListOfTags();
      }
      // Preselection Filter End

      function loadAllCandidates() {
        if ($scope.filterQuestions || $scope.activeFilterId || $scope.activeSavedFilter) {
          clearPreselectionFilter();
        }
        $scope.isSelectedFilter = false;
        $scope.candidate = null;
        $scope.candidates = [];
        $scope.selectFunelLabel = false;
        $scope.selectFunelCount = false;
        resetBulkParams();
        $scope.bulk.allSelected = false;
        getJobWorkflowStages();
        $scope.showAllCandidateActive = true;
      }

      function setListFilters(list) {
        _.each(list, (_entry) => {
          if (_entry.module !== 'notes-module' && _entry.module !== 'history-module' && _entry.module !== 'tag-module' && _entry.module !== 'rejection-module') {
            _entry.active = false;
            _entry.disabled = true;
          }
        });
      }

      function showLandingPage() {
        $scope.showCandidateProfile = false;
      }

      function addCandidateBulk(candidate, addManyCandidates) {
        const idx = _.findIndex($scope.selectedCandidateList, (cand) => cand.user_id === candidate.user_id);
        if ($scope.candidatesChecked[candidate.user_id] && idx === -1) {
          $scope.selectedCandidateList.push(candidate);
        } else if (!$scope.candidatesChecked[candidate.user_id] && idx >= 0) {
          $scope.selectedCandidateList[idx].active = false;
          $scope.selectedCandidateList.splice(idx, 1);
          if ($scope.bulk.allSelected) {
            $scope.bulk.allSelected = false;
          }
        }
        $scope.bulk.bulkAction = $scope.selectedCandidateList.length > 1;
        $scope.candidate = null;
        angular.forEach($scope.candidates, (candidateInBulk) => {
          candidateInBulk.visible = false;
        });
        if ($scope.selectedCandidateList.length === 1) {
          loadCandidateData($scope.selectedCandidateList[0]);
        } else if ($scope.selectedCandidateList.length > 1) {
          if (candidate.match && candidate.stage === "Matched") {
            setTab('showDocuments');
          }
          if (!$scope.isClient || ($scope.isClient && $scope.isPremiumClient)) {
            if ($scope.selectedTab === 'showHistory' || $scope.selectedTab === 'showNotes' || $scope.selectedTab === 'showInternalMetadata') {
              setTab('showDocuments');
            }
          } else if ($scope.isClient && !$scope.isPremiumClient) {
            setTab('rejection-module');
          }
          disableTab('backcheck-module');
          $scope.bulk.bulkAction = true;
          activateEntry({}, $scope.candidates);
        }
        if (!addManyCandidates) $scope.candListEvent = !$scope.candListEvent;
      }

      function addAllCandidateBulk() {
        resetBulkParams();
        $scope.candidate = null;
        if ($scope.bulk.allSelected) {
          angular.forEach($scope.candidates, (candidate) => {
            if (angular.isUndefined($scope.candidatesChecked[candidate.user_id])
                                || !$scope.candidatesChecked[candidate.user_id]) {
              $scope.candidatesChecked[candidate.user_id] = true;
            }
            addCandidateBulk(candidate, true);
          });
          $scope.candListEvent = !$scope.candListEvent;
        }
      }

      function nextPage() {
        event.preventDefault();
        $('.action-tabs-wrapper').animate({
          scrollLeft: '+=200px',
        }, 800);
      }

      function previousPage() {
        event.preventDefault();
        $('.action-tabs-wrapper').animate({
          scrollLeft: '-=200px',
        }, 800);
      }

      // function to slide up/down candidate details
      $scope.slideDetails = function (candidate) {
        candidate.visible = !candidate.visible;
      };

      function slideToTop(candidate, index) {
        createTimeout1 = $timeout( ()=> {
          var candidateCardDiv = document.getElementById(`candidateCard_${index}`);
          var topPos = candidateCardDiv.offsetTop;
          document.getElementById('candidateCardsListWrapperDiv').scrollTop = topPos;
        }, 500)       
      }

      //used in application clone module
      function callBackAfterCandidateMoved(cand) {
        const cand_id_searched = +cand.user_id;
        const idx = _.findIndex($scope.candidates, (c) => {
          return cand_id_searched === +c.user_id;
        });
        if(idx > -1) {
          $scope.candidates.splice(idx, 1);
          if($scope.candidates.length) {
            markCandidateSelected($scope.candidates[0], true);
          }
          else {
            $scope.isCandidateNull = true;
          }
        }
        changeStageCount('decrement', cand.stage);
      }

      function changeStageCount(action, cand_stage) {
        _.find($scope.workflowStages, (stage) => {
          if(stage.translations.en.label == cand_stage) {
            stage.count = action == 'decrement' ? stage.count - 1 : stage.count + 1;
          }
        });
      }

      $scope.saveFilterSectionHandler = (e) => {
        $scope.saveFilterSection = e;
        if (!e) {
          $scope.saveFilter.en = "";
          $scope.saveFilter.fr = "";
        }
      }

      const scope = {
        isExternalCandidate: "null",
        isATSFull: $rootScope.currentUser.permissions.isATSFull,
        isClient: $rootScope.currentUser.permissions.isClient,
        isPremiumClient: $rootScope.isPremiumClient ? $rootScope.isPremiumClient : null,
        isDeptMgrRecruiter: $rootScope.currentUser.permissions.isDeptMgrRecruiter,
        strings: worklandLocalize.strings,
        out: utils.out,
        _,
        tag: {},
        bulk: {
          bulkAction: false,
          allSelected: false,
        },
        candidatesPerPage: [25, 50, 75, 100],
        pageInfo: { pageSize: 25 },
        setPage,
        getJobWorkflowStages,
        getCandidates,
        changeStage,
        candidatesChecked: [],
        selectedCandidateList: [],
        detailedCanidatesList: [],
        filterQuestions: [],
        filterActiveQuestions: [],
        preSelectionFilterData: [],
        filterTags: [],
        filterActiveTags: [],
        choicesArray: [],
        loadAllCandidates,
        loadCandidateData,
        activeActionTab,
        uncheckOtherCandidates,
        addCandidateBulk,
        addAllCandidateBulk,
        markCandidateSelected,
        isDisabled: false,
        successExport: false,
        errorExport: false,
        failedExport: false,
        successExportMessage: '',
        newCandidateCount: 0,
        changeApplicantViewStatus,
        openAdvanceSearchPanel,
        rzsliderForQuestion,
        rzsliderForsavedQuestion,
        createQuestionsForFilter,
        removeQuestionsFromFilter,
        pushTochoiceList,
        checkAnsBeforeAdd,
        saveFilterRequest,
        deleteSavedFilter,
        activateSavedFilter,
        clearPreselectionFilter,
        searchWithCurrentFilters,
        getSavedFilters,
        showLandingPage,
        setListFilters,
        utcToTimezone: utils.utcToTimezone,
        setTab,
        previousPage,
        nextPage,
        toggleView,
        sourcesList: {},
        employerTags,
        getListCandidateTags,
        addTagForFilter,
        checkTagBeforeAdd,
        updateListOfTags,
        removeTagsFromFilter,
        cancel,
        reloadCandidatesWithNoFilters,
        callBackAfterCandidateMoved,
        changeStageCount,        
        combinedActions,
        candListEvent: false,
        selectedTag: { selected: "" },
        saveFilterSection: false,
        emptySaveFilterEn: false,
        emptySaveFilterFr: false,
        saveFilter: {
          en: "",
          fr: "",
        },
        savedFiltersLoaded: false,
        stages: {
          firstList: [],
          secondList: [],
          thirdList: [],
        },
        slideToTop,
      };
      angular.extend($scope, scope);

      $scope.$on('$destroy', function () {
        $timeout.cancel(createTimeout);
        $timeout.cancel(createTimeout1);
      });
  }
  CandidatesListingController.$inject = [
    '$scope',
    '$rootScope',
    'api',
    '_',
    'Event',
    'utils',
    '$timeout',
    'worklandLocalize',
    '$uibModal',
    // 'matchService',
    '$ngConfirm',
    'applicationService',
    '$q',
    '$filter',
    'Pager',
    'storageService',
  ];
  angular.module('atlas')
    .directive('candidates', () => ({
      scope: {
        init: '=',
        isedQuestionnairesData: '=',
        isedQuestionnaireId: '=',
        jobId: '@',
        jobAccountId: '@',
        jobWorkflowId: '@',
        jobAccountId: '@',
        jobOwnerId: '@',
        jobTitle: '@',
        jobTitleEn: '@',
      },
      templateUrl: './employer-profile/directives/candidates/candidates.template.html',
      controller: CandidatesListingController,
    }));
  angular.module('atlas')
    .directive('preventPropagation', () => ({
      link($scope, element) {
        element.on('click', (e) => {
          e.stopPropagation();
        });
      },
    }));
}(angular));
