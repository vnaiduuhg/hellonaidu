( function ( angular ) {

    'use strict';
    angular.module( 'atlas' )
            .directive( 'rejectionModule', function () {
                return {
                    scope: {
                        candidate: '=',
                        bulk: '=',
                        selectedCandidates: '=',
                        jobId: '@',
                        filterName: '@',
                        loadJobStats: '&',
                        loadAllCandidates: '&',
                        workflowStages: '=',
                        rejectionStageCandidates: '=' 
                    },
                    controller: RejectionModuleCtrl,
                    templateUrl: './employer-profile/directives/rejection-module/rejection-module.template.html'
                };
            } );

    RejectionModuleCtrl.$inject = ['$rootScope','$scope', 'api', 'utils'];
    function RejectionModuleCtrl( $rootScope, $scope, api, utils ) {

        var out = utils.out;
        $scope.$watch( 'candidate.userId', candidateChanged );

        var scope = {
            out: out,
            reasonsOptions: true,
            rejectionReason: {fr: "", en: ""},
            utcToTimezone: utils.utcToTimezone,
            language: $rootScope.language,
            firstCandidate: true,
            option_msg: {
                fr: '',
                en: ''
            },
            activeCat: {},
            selectedReason: { selected: {} },
        };
        angular.extend( $scope, scope );

        $scope.tagHandler = function (tag) {
          return null;
        };

        init();

        function init(){
            if($scope.firstCandidate || !$scope.rejectionCategories.length) {
                fetch_categories();
            }
            if ( !$scope.bulk ) {
                getRejectCandidate();
            }
        }

        var rootModelListener = $rootScope.$watch('language', function() {
            $scope.language = $rootScope.language;
        })

        function getCategoryReasons( category ) {
            $scope.activeCat = category;
            $scope.categoryReasons = null;
            if(category.text == 'Custom reasons'){
                var promise = api.service_get('toolkit',  'rejection/user_reasons');
            }else{
                var promise = api.service_get('toolkit',  'rejection/reasons' , {'filter_by_reason_cat_id':category.id});
            }    
            promise.then( function ( response ) {
                if(response.data.status === 'success') {
                    const tempArrayOfReasons = removeUndefinedValues(response.data.data.result);
                    $scope.categoryReasons = sortByAlphabeticText(tempArrayOfReasons);
                } else {                    
                    var msgEn = "An error has occurred while loading reasons for rejection";
                    var msgFr = "Une erreur s'est produite lors du chargement des motifs de rejet";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                    $scope.categoryReasons = [];
                }
                $scope.reasonsOptions = true;
            } ).catch( function ( response ) {
                var msgEn = "An error has occurred while loading reasons for rejection";
                var msgFr = "Une erreur s'est produite lors du chargement des motifs de rejet";
                $rootScope.api_status('alert-danger', msgEn, msgFr);
                $scope.categoryReasons = [];
                $scope.reasonsOptions = true;
            } );
        }

        function fetch_categories(){
            var promise = api.service_get('toolkit',  'rejection/reason_cats' );
                promise.then( function ( response ) {
                    if(response.data.status === 'success') {
                        $scope.rejectionCategories = response.data.data.result;
                    } else {
                        var msgEn = "An error has occurred while loading categories of reasons for rejection";
                        var msgFr = "Une erreur s'est produite lors du chargement des catégories de motifs de rejet";
                        $rootScope.api_status('alert-danger', msgEn, msgFr);
                        $scope.rejectionCategories = [];                        
                    }    
                } ).catch( function ( response ) {
                    var msgEn = "An error has occurred while loading categories of reasons for rejection";
                    var msgFr = "Une erreur s'est produite lors du chargement des catégories de motifs de rejet";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                    $scope.rejectionCategories = [];
                } );
        }

        function rejectCandidate(selectedReason) {
            $scope.selectedReason.selected = {};
            $scope.moveRejectedCandidate = false;
            var array = [];
            if ( $scope.bulk ) {
                angular.forEach( $scope.selectedCandidates, function ( selectedCandidate ) {
                    var data ={};
                    data.job_id =  $scope.jobId;
                    data.reason_id= selectedReason.id;
                    data.reason_cat_id = selectedReason.reason_cat_id;
                    data.candidate_id = selectedCandidate.userId ? selectedCandidate.userId : selectedCandidate.user_id;
                    array.push(data);
                } );
            } else {
                var data ={};
                data.job_id =  $scope.jobId;
                data.reason_id= selectedReason.id;
                data.reason_cat_id = selectedReason.reason_cat_id;
                data.candidate_id = $scope.candidate.userId ? $scope.candidate.userId : $scope.candidate.user_id;
                array.push( data );
            }
            var promise = api.service_post('toolkit',  'rejection/rejections', array );
                promise.then( function ( response ) {
                    if(response.data.status === 'success') {
                        getRejectCandidate();
                        $scope.moveRejectedCandidate = true;  
                    } else {                       
                        var msgEn = $scope.bulk ? "An error has occurred while rejecting the candidates" : "An error has occurred while rejecting the candidate";
                        var msgFr = $scope.bulk ? "Une erreur est survenue lors du rejet des candidats" : "Une erreur est survenue lors du rejet du candidat";
                        $rootScope.api_status('alert-danger', msgEn, msgFr);
                    } 
                } ).catch( function ( response ) {                    
                    var msgEn = $scope.bulk ? "An error has occurred while rejecting the candidates" : "An error has occurred while rejecting the candidate";
                    var msgFr = $scope.bulk ? "Une erreur est survenue lors du rejet des candidats" : "Une erreur est survenue lors du rejet du candidat";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                } );
            return promise;
        }

        function getRejectCandidate(){
            var data={};
            if($scope.bulk) {
                data.filter_by_candidate_id = $scope.selectedCandidates['0'].userId;
                $scope.moveRejectedCandidate = false;  
            } else {                
                data.filter_by_candidate_id = $scope.candidate.userId;                
            }
            data.filter_by_job_id = $scope.jobId;
            data.load_with = 'reason;user_reason';
            var promise = api.service_get('toolkit',  'rejection/rejections', data );
                promise.then( function ( response ) {
                    if(response.data.status === 'success') {
                        $scope.rejectionFilterData = response.data.data.result;              
                    } else {                       
                        var msgEn = "An error has occurred while loading reasons for rejection";
                        var msgFr = "Une erreur s'est produite lors du chargement des motifs de rejet";
                        $rootScope.api_status('alert-danger', msgEn, msgFr);                    }                          
                } ).catch( function ( response ) {
                    var msgEn = "An error has occurred while loading reasons for rejection";
                    var msgFr = "Une erreur s'est produite lors du chargement des motifs de rejet";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                } );
        }

        function createNewReason(){
            const newReasonValidated = validateCustomReason();
            if(!newReasonValidated) {
                $rootScope.api_status(
                    "alert-danger",
                    "Please fill in the required fields",
                    "Veuillez remplir les champs requis"
                );
                return;
            }

            const data = {
                fr: {
                    text: $scope.rejectionReason.fr
                },
                en: {
                    text: $scope.rejectionReason.en
                },
                reason_cat_id: 1
            };
            var promise = api.service_post('toolkit',  'rejection/user_reasons', data );
            promise.then( function ( response ) {
                if(response.data.status === 'success') {
                    $scope.reasonsOptions = true;
                    if($scope.activeCat && $scope.activeCat.id == 1) {
                        getCategoryReasons( $scope.rejectionCategories[0] );
                    }
                    resetNewReasonTranslations();
                } else {                    
                    var msgEn = "An error has occurred while creating the custom rejection reason";
                    var msgFr = "Une erreur s'est produite lors de la création du motif de rejet personnalisé";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                } 
            } ).catch( function ( response ) {
                var msgEn = "An error has occurred while creating the custom rejection reason";
                var msgFr = "Une erreur s'est produite lors de la création du motif de rejet personnalisé";
                $rootScope.api_status('alert-danger', msgEn, msgFr);
            } );
            return promise;
        }
        
        function deleteRejectCandidate(item) {
            var promise =  api.service_delete('toolkit', 'rejection/rejections/'+item.id );
            promise.then( function ( response ) {
                if(response.data.status === 'success') {
                    $scope.rejectionFilterData.splice($scope.rejectionFilterData.indexOf(item), 1);
                } else {
                    var msgEn = "An error has occurred while deleting the custom rejection reason";
                    var msgFr = "Une erreur s'est produite lors de la suppression du motif de rejet";
                    $rootScope.api_status('alert-danger', msgEn, msgFr);
                }                 
            } ).catch( function ( response ) {
                var msgEn = "An error has occurred while deleting the custom rejection reason";
                var msgFr = "Une erreur s'est produite lors de la suppression du motif du rejet";
                $rootScope.api_status('alert-danger', msgEn, msgFr);
            } );
        }

        function openTextarea(){
            resetNewReasonTranslations();
            $scope.reasonsOptions = false;
        }
        function closeTextarea(){
            resetNewReasonTranslations();
            $scope.reasonsOptions = true;
        }

        function candidateChanged( candidateId ) {
            if ( candidateId ) {
                $scope.rejectionFilterData = [];
                if(!$scope.firstCandidate) {
                    init();
                }
                else {
                    $scope.firstCandidate = false;
                }
            }
        }

        function sortByAlphabeticText(currentArrayOfReasons) {
            const currentArray = $rootScope.language === "fr" ? currentArrayOfReasons.temp_array_fr : currentArrayOfReasons.temp_array_en;
            const newArray = currentArray.sort((a, b) => a.translation[$rootScope.language].text.localeCompare(b.translation[$rootScope.language].text, $rootScope.language));
            return {
                temp_array_fr: $rootScope.language === "fr" ? newArray : currentArrayOfReasons.temp_array_fr,
                temp_array_en: $rootScope.language === "en" ? newArray : currentArrayOfReasons.temp_array_en
            };
        }

        function removeUndefinedValues(items_array) {
            var result = {
                temp_array_en: [],
                temp_array_fr: []
            }
            _.each(items_array, function(item) {
                if(item.translation && item.translation.en) {
                    result.temp_array_en.push(item);
                }
                if(item.translation && item.translation.fr) {
                    result.temp_array_fr.push(item);
                }
            })
            $scope.option_msg = {
                fr: result.temp_array_fr.length ? 'Sélectionner une option' : 'Aucune option disponible',
                en: result.temp_array_en.length ? 'Select an option' : 'No option available'
            }
            return result;
        }

        function validateCustomReason() {
            if(!$scope.rejectionReason.fr || !$scope.rejectionReason.en) {
                return false;
            }
            return true;
        }

        function resetNewReasonTranslations() {
            $scope.rejectionReason.fr = '';
            $scope.rejectionReason.en = '';
        }

        const scopeMethods = {
            getCategoryReasons,
            fetch_categories,
            rejectCandidate,
            getRejectCandidate,
            createNewReason,
            deleteRejectCandidate,
            openTextarea,
            closeTextarea,
            candidateChanged,
            removeUndefinedValues,
            validateCustomReason,
            resetNewReasonTranslations,
        };
        angular.extend($scope, scopeMethods);

        $scope.$on('$destroy', function () {
          // disable the listener
          rootModelListener();
        })
    }

} )( angular );
