(function (angular) {
  function calenderModuleCtrl(
    $filter,
    api,
    utils,
    $uibModal,
    $scope,
    $rootScope,
    MetaTagsService,
    $state,
    moment,
    calendarConfig,
    $timeout,
    $ngConfirm,
    $q,
  ) {
    const vm = this;

    calendarConfig.i18nStrings = {
      weekNumber: `${utils.out('semaine', 'week')} {week}`,
    };

    calendarConfig.allDateFormats.angular.title = {
      week: `${utils.out('Semaine', 'Week')} {week} ${utils.out('de', 'of')} {year}`,
    };

    let scope = {
      out: utils.out,
      fetchedCalendarCount: 0,
      calendars: [],
      autocomplete: null,
      infoMessage: true,
      hasAccessToken: false,
    };
    angular.extend(vm, scope);

    let waitMsgEn;
    let waitMsgFr;
    let successMsgEn;
    let successMsgFr;
    let errorMsgEn;
    let errorMsgFr;    

    const actions = [{
      label: '<span><i class=\'fa fa-eye\' style="color: #004569 !important"></i></span>',
      onClick(args) {
        vm.show('View', args.calendarEvent);
      },
    }, {
      label: '<span><i class=\'fa fa-trash\' style="color: #004569 !important"></i></span>',
      onClick(args) {
        const eventToDelete = args.calendarEvent;
        vm.deleteEvent(eventToDelete);
      },
    }];

    function importEvents(eventObjects, calendar) {      
      // $scope.loadedCalendar = false;
      $scope.loadingError = false;
      $scope.loadingMsg = utils.out('Ouverture de votre calendrier', 'Opening your calendar');
      angular.forEach(eventObjects, (value, key) => {
        const startDateUTC = new Date(value.start * 1000);
        const endDateUTC = new Date(value.end * 1000);
        const startDate = utils.utcToTimezone(startDateUTC, 'obj');
        const endDate = utils.utcToTimezone(endDateUTC, 'obj');
        const tempEvent = {
          id: value.id,
          calendar_id: calendar.id,
          title: value.title,
          description: value.description,
          location: value.location ? value.location : '',
          participants: value.participants,
          color: {
            primary: '#2DA3D5',
            secondary: '#9FE3FF',
          },
          startsAt: startDate,
          endsAt: endDate,
          notify_participants: true,
          busy: false,
          draggable: true,
          resizable: true,
          actions,
          readOnly: calendar.read_only,
        };
        if (calendar.isChecked) vm.events.push(tempEvent);
        calendar.events.push(tempEvent);
      });
      $scope.fetchedCalendarCount += 1;
    }

    function getCalendarEvents(firstDay, lastDay, calendar) {
      api.service_get('calendar', 'calendar-events', {
        'calendar_id' : calendar.id,
        'start_date' : firstDay,
        'end_date' : lastDay,
      })
      .then((response) => {
        if (response?.data) {
          importEvents(response.data, calendar);
        }
        $scope.isDisabled = false;
      }).catch((error) => {
        $scope.isDisabled = false;
        $scope.loadingError = true;
        if (error.status === 404) {
          $rootScope.api_status('alert-danger', 'Your calendar account is not synced.', 'Votre compte de calendrier n\'est pas synchronisé.' );
        } else {
          $scope.loadingMsg = vm.out("Une erreur s'est produite et les événements de votre calendrier n'ont pas pu être récupérés. Veuillez essayer plus tard ou contacter Workland pour un support technique.",
          "An error has occurred and your calendar events could not be fetched. Please try later or contact Workland for technical support" );
        }       
      });
    }

    function listEvents(firstDay, lastDay, clndr) {
      if (clndr) {
        getCalendarEvents(firstDay, lastDay, clndr);          
      } else {
        angular.forEach($scope.calendars, (calendar, key) => {
          if (calendar.isChecked) {
            calendar.events = [];
            $scope.fetchedCalendarCount -=1;
            getCalendarEvents(firstDay, lastDay, calendar);
          }
          if(calendar.is_primary) {
            $scope.calendarId = calendar.id;
          }
        });          
      }
    }

    function loadCalendarData(calendar) {
      vm.viewDate = new Date();
      vm.previousDate = new Date();
      vm.calendarView = 'month';
      let firstDay = new Date(vm.viewDate.getFullYear(), vm.viewDate.getMonth(), 1);
      firstDay = $filter('date')(firstDay, 'yyyy-MM-dd');
      let lastDay = new Date(vm.viewDate.getFullYear(), vm.viewDate.getMonth() + 1, 0);
      lastDay = $filter('date')(lastDay, 'yyyy-MM-dd');
      listEvents(firstDay, lastDay, calendar)
    }

    function listCalendars() {
      api.service_get('calendar', 'calendars', {}).then((response) => {
        if (response?.data) {
          $scope.calendars = response.data;
          $scope.fetchedCalendarCount = 0;
          angular.forEach($scope.calendars, (calendar, key) => {
            calendar.events = [];         
            if (calendar.is_primary) {
              calendar.isChecked = true;
              $scope.calendar = calendar;
              $scope.calendarId = calendar.id;
            }              
            loadCalendarData(calendar);
          });
        }
      }).catch(() => {
        $scope.loadingError = true;
        $scope.loadingMsg = vm.out("Une erreur s'est produite et votre calendrier n'a pas pu être récupéré. Veuillez essayer plus tard ou contacter Workland pour un support technique.", 
        "An error has occurred and your calendar could not be fetched. Please try later or contact Workland for technical support");
      });    
    }

    function getCalendarAccount() {
      api.service_get('calendar', 'calendar-accounts').then((response) => {
        if (response?.data) {
          $scope.hasAccessToken = true;          
          listCalendars();
        }
      }).catch((error) => {
        $scope.hasAccessToken = false;
        $scope.loadingError = true;
        $scope.infoMessage = false;
        switch (error.status) {          
          case 401:            
            if (error.data.message === 'invalid_refresh_token') {
              $scope.loadingMsg = utils.out('Votre jeton a expiré, veuillez resynchroniser votre compte de calendrier.', 
                'Your token has expired, please resync your calendar account.')
            } else {
              $scope.loadingMsg = utils.out('Votre jeton a expiré, veuillez vous reconnecter.', 'Your token has expired, please login again.');
            }
            break;
          case 404:
            $scope.infoMessage = true;
            $scope.loadingMsg = utils.out('Veuillez synchroniser votre compte de calendrier.', 'Please sync your calendar account.');            
            break;
          default:
            $scope.loadingMsg = utils.out('Erreur! Veuillez contacter le support pour signaler ce problème.', 'Uh Oh! An error occurred. Please contact support to report the issue.')
        }
      })
    }

    function init() {
      vm.events = [];
      $scope.loadedCalendar = false;
      $scope.loadingError = false;
      $scope.loadingMsg = utils.out('Récupération de votre compte', 'Fetching your account details');      
      getCalendarAccount();      
    }

    $scope.$watch('fetchedCalendarCount', () => {
      if ($scope.calendars && $scope.fetchedCalendarCount === $scope.calendars.length) {
        // These variables MUST be set as a minimum for the calendar to work
        vm.cellIsOpen = false;
        $scope.loadedCalendar = true;
      }
    });

    init();

    let createTimeout;
    
    function initMap() {
      createTimeout = $timeout(() => {
        const input = document.getElementById('pac-input');
        vm.autocomplete = new google.maps.places.Autocomplete(input);
        vm.autocomplete.setFields(['formatted_address']);
        vm.autocomplete.addListener('place_changed', () => {
          const place = vm.autocomplete.getPlace();
          if (place?.formatted_address) {
            $scope.event.location = place.formatted_address;
          }
        });
      }, 1000);
    }

    vm.toggle = function ($event, field, event) {
      $event.preventDefault();
      $event.stopPropagation();
      event[field] = !event[field];
    };

    vm.changeMonth = function (showEvents) {
      $scope.isDisabled = true;
      vm.events = [];
      vm.cellIsOpen = false;
      const currentMonth = vm.viewDate.getMonth();
      const previousMonth = vm.previousDate.getMonth();
      let firstDay = new Date(vm.viewDate.getFullYear(), vm.viewDate.getMonth(), 1);
      firstDay = $filter('date')(firstDay, 'yyyy-MM-dd');
      let lastDay = new Date(vm.viewDate.getFullYear(), vm.viewDate.getMonth() + 1, 0);
      lastDay = $filter('date')(lastDay, 'yyyy-MM-dd');
      if ( (currentMonth !== previousMonth) || showEvents) {
        // $scope.loadedCalendar = false;
        listEvents(firstDay, lastDay); 
      }
      vm.previousDate = vm.viewDate;
    };

    vm.timespanClicked = function (date, cell) {
      if (vm.calendarView === 'month') {
        if ((vm.cellIsOpen && moment(date).startOf('day').isSame(moment(vm.viewDate).startOf('day'))) || cell.events.length === 0 || !cell.inMonth) {
          vm.cellIsOpen = false;
          if (cell.events.length === 0) {
            vm.show('Add', vm.newEvent(date));
          }
        } else {
          vm.cellIsOpen = true;
          vm.viewDate = date;
        }
      } else if (vm.calendarView === 'year') {
        if ((vm.cellIsOpen && moment(date).startOf('month').isSame(moment(vm.viewDate).startOf('month'))) || cell.events.length === 0) {
          vm.cellIsOpen = false;
        } else {
          vm.cellIsOpen = true;
          vm.viewDate = date;
        }
      } else if (vm.calendarView === 'day') {
        vm.show('Add', vm.newEvent(date._d));
      }
    };

    vm.newEvent = function (date) {
      const event = {
        id: '',
        calendar_id: $scope.calendarId,
        title: vm.out('Nouvel événement', 'New event'),
        description: '',
        location: '',
        participants: [],
        startsAt: moment(date).toDate(),
        endsAt: moment(date).toDate(),
        notify_participants: true,
        busy: false,
        color: calendarConfig.colorTypes.important,
        draggable: true,
        resizable: true,
        actions,
      };
      return event;
    };

    vm.show = function (action, event) {
      $scope.action = action;
      $scope.event = angular.copy(event);
      $scope.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/calender-module/calender-modal-content.template.html',
        scope: $scope,
        size: 'md',
      });
      initMap();
    };

    function validateDates(startDate, endDate) {      
      if (endDate <= startDate) {
        return false;
      }
      return true;
    }

    vm.saveEvent = function (action, event) {
      let promise;
      const eventObj = angular.copy(event);          
      if (!eventObj.startsAt || !eventObj.endsAt) {
        $rootScope.api_status(
          'alert-danger',
          'Date is missing!',
          'La date est manquante!',
        );
        return;
      }
      if (!validateDates(eventObj.startsAt, eventObj.endsAt) ) {
        $rootScope.api_status(
          'alert-danger',
          'The event end date should be after its start date.',
          'La date de fin de l\'événement doit être postérieure à sa date de début.',
        );
        return;
      }
      eventObj.start_event = event.startsAt;
      eventObj.end_event = event.endsAt;
      if (eventObj.description === null) eventObj.description = '';
      if (action === 'Add') {
        waitMsgEn = 'Event is being added...';
        waitMsgFr = "Ajout de l'événement...";

        successMsgEn = 'Event has been added successfully.';
        successMsgFr = "L'événement a été ajouté avec succès.";

        errorMsgEn = 'Failed to add the event.';
        errorMsgFr = "Échec de l'ajout de l'événement.";

        promise = api.service_post('calendar', 'calendar-events', eventObj);
      } else {
        eventObj.event_id = eventObj.id;
        eventObj.calendar_id = $scope.calendarId;
        waitMsgEn = 'Event is being updated...';
        waitMsgFr = "Mise à jour de l'événement...";

        successMsgEn = 'Event has been updated successfully.';
        successMsgFr = "L'événement a été mis à jour avec succès.";

        errorMsgEn = 'Failed to update the event.';
        errorMsgFr = "Échec de la mise à jour de l'événement.";

        promise = api.service_post('calendar', 'calendar-events', eventObj, 'update');
      }
      $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);

      promise.then((response) => {
        if (response.data) {
          let i = 0;
          let j = 0;
          if (event.id === '') {
            event.id = response.data.id;
            for (i = 0; i < $scope.calendars.length; i += 1) {
              if (event.calendar_id === $scope.calendars[i].id) {                  
                $scope.calendars[i].events.push(event);
                if ($scope.calendars[i].isChecked) {
                  vm.events.push(event);
                }
                break;
              }
            }
          } else {
            for (i = 0; i < vm.events.length; i += 1) {
              if (vm.events[i].id === event.id) {
                vm.events[i] = event;
                break;
              }
            }
            for (i = 0; i < $scope.calendars.length; i += 1) {
              if (event.calendar_id === $scope.calendars[i].id) {
                for (j = 0; j < $scope.calendars[i].events.length; j += 1) {
                  if ($scope.calendars[i].events[j].id === event.id) {
                    $scope.calendars[i].events[j] = event;
                    break;
                  }
                }
                break;
              }
            }
          }
          $scope.modalInstance.close();
          $scope.event = vm.newEvent();
          // vm.autocomplete = null;
          $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
        }
      }).catch((error) => {
        if (error.status === 404) {
          $rootScope.api_status('alert-danger', 'Your calendar account is not synced.', 'Votre compte de calendrier n\'est pas synchronisé.' );
        } else {
          $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
        }
      });
    };

    vm.deleteEvent = function (eventToDelete) {
      if (eventToDelete.readOnly) {
        return $ngConfirm({
          title: vm.out('Attention', 'Warning'),
          type: 'red',
          content: vm.out('Vous ne pouvez supprimer ou modifier des événements de ce calendrier.', 'You cannot delete or modify events from this calendar.'),
        })
      }
      $ngConfirm({
        title: vm.out('Attention', 'Warning'),
        type: 'red',
        content: vm.out('Êtes-vous sûr de vouloir supprimer cet événement?', 'Are you sure you want to delete this event?'),
        buttons: {
          Yes: {
            text: vm.out('Oui', 'Yes'),
            btnClass: 'btn btn-danger',
            action() {
              if ($scope.modalInstance) {
                $scope.modalInstance.close();
              }
              waitMsgEn = 'Event is being deleted...';
              waitMsgFr = "Suppression de l'événement...";
              $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);

              errorMsgEn = 'Failed to delete the event.';
              errorMsgFr = "Échec de la suppression de l'événement.";
              const promise = api.service_delete('calendar', 
                `calendar-events?event_id=${eventToDelete.id}&calendar_id=${$scope.calendarId}`, {});
              promise.then((response) => {
                if (response.status === 200) {
                  const index = vm.events.findIndex(event => event.id === eventToDelete.id);
                  if (index >-1) vm.events.splice(index, 1);
                  let indexInCalendar = -1;
                  for (let i = 0; i < $scope.calendars.length; i += 1) {
                    if (eventToDelete.calendar_id === $scope.calendars[i].id) {
                      indexInCalendar = $scope.calendars[i].events.findIndex(calendarEvent => calendarEvent.id === eventToDelete.id);
                      if (indexInCalendar >-1) $scope.calendars[i].events.splice(indexInCalendar, 1);
                      break;
                    }
                  }
                  const msgEn = 'Event has been deleted successfully.';
                  const msgFr = "L'événement a été supprimé avec succès.";
                  $rootScope.api_status('alert-success', msgEn, msgFr);
                  vm.cellIsOpen = false;
                } else {
                  $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
                }
               }).catch((error) => {
                if (error.status === 404) {
                  $rootScope.api_status('alert-danger', 'Your calendar account is not synced.', 'Votre compte de calendrier n\'est pas synchronisé.' );
                } else {
                  $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
                }
              });             
            },
          },
          Cancel: {
            text: vm.out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            keys: ['enter', 'shift'],
          },
        },
      });
    };

    function createNewEvent() {
      vm.show('Add', vm.newEvent(new Date()));
    }

    function changeAction(action) {
      $scope.action = action;
    }

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
      $timeout.cancel(createTimeout);
    });

    scope = {
      importEvents,
      createNewEvent,
      initMap,
      changeAction,
    };
    angular.extend(vm, scope);
  }
  calenderModuleCtrl.$inject = [
    '$filter',
    'api',
    'utils',
    '$uibModal',
    '$scope',
    '$rootScope',
    'MetaTagsService',
    '$state',
    'moment',
    'calendarConfig',
    '$timeout',
    '$ngConfirm',
    '$q',
  ];
  angular.module('atlas')
    .directive('calenderModule', () => ({
      scope: {},
      controllerAs: 'vm',
      controller: calenderModuleCtrl,
      templateUrl: './employer-profile/directives/calender-module/calender-module.template.html',
    }));
}(angular));
