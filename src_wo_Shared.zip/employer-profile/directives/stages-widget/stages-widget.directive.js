// eslint-disable-next-line func-names
(function (angular) {
  function StagesWidgetCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    _,
    $timeout,
    Event,
  ) {
    const vm = this;

    const formModel = {};

    let createTimeout1;
    let createTimeout2;
    let createTimeout3;

    function getStage(stageName) {
      return _.find(vm.workflowStages, (workflowStage) => workflowStage.events.indexOf(stageName) > -1);
    }

    function changeCandidatesStageHandler(candidatesBeingMoved) {
      arrayOfIndexToSplice = [];
      _.each(candidatesBeingMoved, (candidate) => {
        candidate.stage = vm.stage.translations.en.label;
        candidate.stageFr = vm.stage.translations.fr.label;
        // retrieve all indexes to splice from old stages
        const indexOfCand = _.findIndex(vm.allStageCandidates, (cand) => {
          return candidate.user_id === cand.user_id;
        });
        if(indexOfCand > -1) {
          arrayOfIndexToSplice.push(indexOfCand);
        }
      });

      // splice each candidates from stage list
      arrayOfIndexToSplice = arrayOfIndexToSplice.sort().reverse();
      _.each(arrayOfIndexToSplice, (indexOfCand) => {
        vm.allStageCandidates.splice(indexOfCand, 1);
      });
      vm.stage = null;
      vm.canMoveCandidate = true;
    }

    function changeStage(stage) {
      vm.canMoveCandidate = false;
      if (stage) {
        vm.stage = stage;
      }
      let msgEn = vm.bulk ? 'Moving candidates to ' : 'Moving candidate to ';
      msgEn = `${msgEn + vm.stage.translations.en.label} Stage`;
      let msgFr = vm.bulk ? "Déplacement des candidats vers l'étape " : "Déplacement du candidat vers l'étape ";
      msgFr += vm.stage.translations.fr.label;
      $rootScope.api_status('waiting', msgEn, msgFr);
      const ids = [];
      const candidatesBeingMoved = [];
      if (vm.bulk) {
        angular.forEach(vm.selectedCandidates, (selectedCandidate) => {
          ids.push(selectedCandidate.user_id);
          candidatesBeingMoved.push(selectedCandidate);
        });
      } else {
        ids.push(vm.candidate.user_id);
        candidatesBeingMoved.push(vm.candidate);
      }
      const data = {
        stage_id: vm.stage.id,
        stage_events: vm.stage.events,
        workflow_id: vm.stage.workflow_id,
        job_id: vm.moveRejectedCandidate ? vm.rejectedJobId : vm.moveSubstituteCandidate ? vm.substituteJobId : vm.jobId,
        user_ids: ids,
        language: $rootScope.language,
        is_ats: +vm.isAts,
      };
      if (vm.fromModule && vm.fromModule === "rejection") data.event_slug = "create-rejection";
      const promise = api.service_post('workflow', 'workflows/move-candidate', data);
      promise.then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          Event.broadcast('CANDIDATE_MOVED_EVENT', data);
          msgEn = vm.bulk ? 'Candidates moved successfully to ' : 'Candidate moved successfully to ';
          msgEn = `${msgEn + vm.stage.translations.en.label} Stage`;
          msgFr = vm.bulk ? "Candidats transférés avec succès à l'étape " : "Candidat transféré avec succès à l'étape ";
          msgFr += vm.stage.translations.fr.label;
          $rootScope.api_status('alert-success', msgEn, msgFr);
          const sentEmailResult = utils.sentAutoEmailStatus(res.email_message, res.email_sent);
          if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
            createTimeout1 = $timeout(() => {
              $rootScope.api_status('alert-danger', sentEmailResult.msgEn, sentEmailResult.msgFr);
            }, 3000);
          }
          // when we got to send_email final step
          if (sentEmailResult.sendEmailSuccess.length) {
            msgEn = sentEmailResult.sendEmailSuccess.length == 1 ? 'An email has been sent successfully to the candidate' : 'An email has been sent successfully to all selected candidates';
            msgFr = sentEmailResult.sendEmailSuccess.length == 1 ? 'Un email a été envoyé au candidat avec succès' : 'Un email a été envoyé aux candidats avec succès';
            createTimeout2 = $timeout(() => {
              $rootScope.api_status('alert-success', msgEn, msgFr);
            }, 3000);
          } else if (sentEmailResult.sendEmailfail.length) {
            msgEn = 'An error has occurred, no automated messages could be sent. Please try later or contact Workland for Technical Support.';
            msgFr = 'Une erreur est survenue, aucun message automatisé n\'a pu été envoyé. Veuillez réessayer plus tard ou contacter Workland pour le support technique.';
            createTimeout3 = $timeout(() => {
              $rootScope.api_status('alert-danger', msgEn, msgFr);
            }, 3000);
          }        
          const jobId = vm.moveRejectedCandidate ? vm.rejectedJobId : vm.moveSubstituteCandidate ? vm.substituteJobId : vm.jobId;
           api.service_get('workflow', `workflows/${vm.stage.workflow_id}/jobs/${jobId}/stage-counts`).then((response) => {
            if (response?.data) {              
              angular.forEach(response.data, (resStage) => {
                angular.forEach(vm.workflowStages, (stage) => {
                  if (resStage.stage_id === stage.id) {
                    stage.count = resStage.count;
                  }
                })
              });
              changeCandidatesStageHandler(candidatesBeingMoved);
            }
           })
        } else {
          vm.canMoveCandidate = true;
          msgEn = vm.bulk ? 'Failed to move candidates' : 'Failed to move candidate';
          msgFr = vm.bulk ? 'Erreur lors du déplacement des candidats' : 'Erreur lors du déplacement du candidat';
          $rootScope.api_status('alert-danger', msgEn, msgFr);
        }
      }).catch(() => {
        vm.canMoveCandidate = true;
        msgEn = vm.bulk ? 'Failed to move candidates' : 'Failed to move candidate';
        msgFr = vm.bulk ? 'Erreur lors du déplacement des candidats' : 'Erreur lors du déplacement du candidat';
        $rootScope.api_status('alert-danger', msgEn, msgFr);
      });
    }

    function refreshStage(stage) {
      if (stage) {
        vm.stage = stage;
      }
      let msgEn = vm.bulk ? 'Moving candidates to ' : 'Moving candidate to ';
      msgEn = `${msgEn + vm.stage.translations.en.label} Stage`;
      let msgFr = vm.bulk ? "Déplacement des candidats vers l'étape " : "Déplacement du candidat vers l'étape ";
      msgFr += vm.stage.translations.fr.label;
      $rootScope.api_status('waiting', msgEn, msgFr);
      const ids = [];
      const candidatesBeingMoved = [];
      if (vm.bulk) {
        angular.forEach(vm.selectedCandidates, (selectedCandidate) => {
          ids.push(selectedCandidate.user_id);
          candidatesBeingMoved.push(selectedCandidate);
        });
      } else {
        ids.push(vm.candidate.user_id);
        candidatesBeingMoved.push(vm.candidate);
      }
      const data = {
        stage_id: vm.stage.id,
        stage_events: vm.stage.events,
        workflow_id: vm.stage.workflow_id,
        job_id: vm.moveRejectedCandidate ? vm.rejectedJobId : vm.moveSubstituteCandidate ? vm.substituteJobId : vm.jobId,
        user_ids: ids,
        language: $rootScope.language,
        is_ats: +vm.isAts,
      };
      Event.broadcast('CANDIDATE_MOVED_EVENT', data);
      msgEn = vm.bulk ? 'Candidates moved successfully to ' : 'Candidate moved successfully to ';
      msgEn = `${msgEn + vm.stage.translations.en.label} Stage`;
      msgFr = vm.bulk ? "Candidats transférés avec succès à l'étape " : "Candidat transféré avec succès à l'étape ";
      msgFr += vm.stage.translations.fr.label;
      $rootScope.api_status('alert-success', msgEn, msgFr);
      const jobId = vm.moveRejectedCandidate ? vm.rejectedJobId : vm.moveSubstituteCandidate ? vm.substituteJobId : vm.jobId;
       api.service_post('workflow', `workflows/${vm.stage.workflow_id}/jobs/${jobId}/stages`, {}).then((response) => {
        if (response.data.status !== 'fail') {
          angular.forEach(vm.workflowStages, (stage) => {
            angular.forEach(response.data.stages, (resStage) => {
              if (stage.id === resStage.id) {
                stage.count = resStage.count;
              }
            })
          });
          changeCandidatesStageHandler(candidatesBeingMoved);
        }
       });
    }

    const vmExtends = {
      out: utils.out,
      changeStage,
      formModel,
      selectedStage: {},
      canMoveCandidate: true,
    };
    angular.extend(vm, vmExtends);

    function init() {
      if ($rootScope.currentUser.permissions.isClient) {
        vm.clientCandidateListSources = [];
        _.each(vm.workflowStages, (list) => {
          if (list.events[0] === 'applied' || list.events[0] === 'hired' || list.events[0] === 'rejected') {
            vm.clientCandidateListSources.push(list);
          }
        });
        vm.workflowStages = vm.clientCandidateListSources;
      }
      if (vm.moveRejectedCandidate) {
        const workflowRejectedStage = getStage('rejected');
        vm.stage = workflowRejectedStage;
        changeStage();
      }
      if (vm.moveSubstituteCandidate) {
        const workflowSubstituteStage = getStage('create-candidate-substitutus-profile');
        vm.stage = workflowSubstituteStage;
        refreshStage();
      }
    }
    init();
    
    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
      $timeout.cancel(createTimeout3);
    });
  }

  StagesWidgetCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
    '$timeout',
    'Event',
  ];

  angular.module('atlas')
    .directive('stagesWidget', () => ({
      scope: {},
      bindToController: {
        candidate: '=',
        bulk: '=',
        selectedCandidates: '=',
        jobId: '@',
        isAts: '@',
        workflowStages: '=',
        loadJobStats: '&',
        moveRejectedCandidate: '@',
        rejectedJobId: '=',
        allStageCandidates: '=',
        moveSubstituteCandidate: '@',
        substituteJobId: '=',
        fromModule: '@?'
      },
      controllerAs: 'vm',
      controller: StagesWidgetCtrl,
      templateUrl: './employer-profile/directives/stages-widget/stages-widget.template.html',
    }))
    .filter('Exclude', () => function (items) {
      const filtered = [];
      angular.forEach(items, (item) => {
        if (item.restricted == 0) {
          filtered.push(item);
        }
      });
      return filtered;
    });
  // eslint-disable-next-line no-undef
}(angular));
