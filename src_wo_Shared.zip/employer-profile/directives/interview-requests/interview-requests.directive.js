(function (angular) {
  function InterviewRequestsController(
    $scope,
    $rootScope,
    api,
    utils,
    _, $filter,
    $uibModal,
    $timeout,
    worklandLocalize,
  ) {
    $scope.isCandidate = $rootScope.currentUser.permissions.isCandidate;

    const scope = {
      imagesUrl: './../assets/images/',
      nocFunction: { selected: {} },
      strings: worklandLocalize.strings,
      profile: $rootScope.currentUser.user,
      utils,
      out: utils.out,
      selectedStatus: {
        id: 0
      },
      interivewStatuses: [],
      fetchAllStatuses,
      getCandidateInterviews,
      confirmTimeslots,
      showCancellationModal,
      cancelInterview,
      is_expired,
      isLoadingInterviews: true,
      candidateInterviews: [],
      loadIStatus: false,
      interviews: null,
      noInterviewOnFilter: false,
      interviewIsExpired: {
        checked: false
      },
      numberOfTimeslotsSelected: 0,
    };
    angular.extend($scope, scope);

    let createTimeout; let createRefreshTimeout;

    window.addeventasync = function () {
      addeventatc.settings({
        appleical: { show: true, text: 'Apple Calendar' },
        google: { show: true, text: 'Google <em>(online)</em>' },
        outlook: { show: true, text: 'Outlook' },
        outlookcom: { show: true, text: 'Outlook.com <em>(online)</em>' },
        yahoo: { show: true, text: 'Yahoo <em>(online)</em>' },
      });

      addeventatc.register('button-click', (obj) => {

      });
    };

    function showUnexpiredInterviews(interviews) {
      const resultInterviews = [];
      let interviewsToFilter = interviews ?  angular.copy(interviews) :  angular.copy($scope.candidateInterviews);
      angular.forEach(interviewsToFilter, (candidateInterview) => {
        //exclude intervieews and attendee confirmed slots info from candidate interview object 
        //when the timeslot has expired
        angular.forEach(candidateInterview.interview_timeslots, (timeslot) => {
          if (is_expired(timeslot.date)) {
            angular.forEach(candidateInterview.interview_interviewees, (interviewee, index) => {
              if (+timeslot.id === +interviewee.approved_interviewee_timeslots) {
                candidateInterview.interview_interviewees.splice(index, 1);
              }
            });
            angular.forEach(candidateInterview.approved_attendee_timeslots, (approvedTimeslot, index) => {
              if (+timeslot.id === +approvedTimeslot.timeslot_id) {
                candidateInterview.approved_attendee_timeslots.splice(index, 1);
              }
            })
          }
        });
        let filteredInterviews = [];
        filteredInterviews = _.filter(candidateInterview.interview_timeslots, timeslot => !is_expired(timeslot.date));        
        if (filteredInterviews.length > 0) resultInterviews.push(candidateInterview);
      });
      return resultInterviews;
    }

    $scope.changeIStatus = () => {
      $scope.loadIStatus = true;
      $scope.noInterviewOnFilter = false;
      $scope.interviews = null;
      if ($scope.selectedStatus.id > 0) {
        let tempArray = [];
        tempArray = _.filter($scope.candidateInterviews, interview => interview.status_id == $scope.selectedStatus.id);
        if ($scope.interviewIsExpired.checked) {
          $scope.interviews = tempArray;
        } else {
          tempArray = showUnexpiredInterviews();
         $scope.interviews = _.filter(tempArray, interview => interview.status_id == $scope.selectedStatus.id);
        }
      } else {
        $scope.interviews = $scope.interviewIsExpired.checked
          ? angular.copy($scope.candidateInterviews)
          : showUnexpiredInterviews();
      }

      if (!$scope.interviews || !$scope.interviews.length) $scope.noInterviewOnFilter = true;
      createTimeout = $timeout(() => {
        $scope.loadIStatus = false;
      }, 500);
    }

    function fetchAllStatuses() {
      const promise = api.service_get('toolkit', 'interview/status');
      promise.then((response) => {
        if (response.data.status === 'success') {
          const tempStatuses = response.data.data.result;
          _.each(tempStatuses, status => {
            if (status.translation.fr.status === 'Confirmé') status.translation.fr.status = 'Confirmées';
            if (status.translation.fr.status === 'Annulé') status.translation.fr.status = 'Annulées';
          });
          $scope.interivewStatuses = tempStatuses;

        } else {
          $scope.interivewStatuses = [];
        }
      }).catch(() => {
        $scope.interivewStatuses = [];
      });
    }

    function countMinimumToConfirm(interview) {
      return (interview.is_mandatory && !interview.attendees_either_or)
        ? interview.minimum_confirm
        : (interview.is_mandatory && !interview.interviewEitherOrConfirmed)
          ? interview.minimum_confirm
          : -1;
    }

    function handleSelectedTimeslots(attendeesList, interview) {
      let selectedTimeslots = [];
      _.each(attendeesList, attendee => {
        _.each(attendee.approved_attendee_timeslots, timeslot => {
          selectedTimeslots.push(timeslot.interview_timeslot_id);
        });
      });
      selectedTimeslots = _.uniq(selectedTimeslots);
      if (selectedTimeslots.length) {
        _.each(selectedTimeslots, selected => {
          _.find(interview.interview_timeslots, timeslot => {
            if (selected == timeslot.id) {
              timeslot.isAlreadySelected = true;
              interview.selectedTimeslotsByAttendees = true
            }
          });
        });
      }
    }

    function getCandidateInterviews() {
      $scope.isLoadingInterviews = true;
      $scope.candidateInterviews = [];

      const url = `interview/interviews?filter_by_attendee_id=${$scope.currentUser.id}&sort_by_desc=interview_expired_at`;
      const promise = $scope.promiseInterviews = api.service_get('toolkit', url);
      promise.then((response) => {
        $scope.isLoadingInterviews = false;

        if (response.data.status === 'success') {
          const interviewList = response.data.data.result;

          _.each(interviewList, (interview) => {
            // Converting all timeslots from UTC to Local Time
            _.each(interview.interview_timeslots, (timeslot) => {
              var local_start = utils.utcToTimezone(timeslot.date +' '+ timeslot.start_time, 'zoozle');
              timeslot.start_time = local_start['time'];
              timeslot.date = local_start['date'];
              timeslot.end_time = utils.utcToTimezone(timeslot.date +' '+ timeslot.end_time, 'zoozle')['time'];
            });
            const mandatorySharedAttendees = [];
            let eitherOrConfirmed;
            let candidateInterview = {};
            _.each(interview.interview_attendees, (attendee) => {
              if (+attendee.user_id === +$scope.currentUser.id) {
                candidateInterview = {
                  interview_id: interview.id,
                  attendee_id: attendee.id,
                  status_id: attendee.status_id,
                  status: attendee.status,
                  user_id: attendee.user_id,
                  attendees_either_or: attendee.attendees_either_or,
                  is_interview_owner: attendee.is_interview_owner,
                  is_mandatory: attendee.is_mandatory,
                  reply_note: attendee.reply_note,
                  replied_at: attendee.replied_at,
                  questionnaire_id: attendee.questionnaire_id,
                  type_id: interview.type_id,
                  type: interview.type,                 
                  location: interview.location,
                  company_name: interview.company_name,
                  creator_name: interview.creator_name,
                  confirm_expiry_date: interview.attendee_expired_at,
                  interview_interviewees: interview.interview_interviewees,
                  interview_timeslots: interview.interview_timeslots,
                  approved_attendee_timeslots: [],
                  interview_expired_at: interview.interview_expired_at,
                  minimum_confirm: interview.minimum_confirm,
                  has_event_in_calendar: attendee.has_event_in_calendar
                };
                if (interview.job_id) candidateInterview.job_id = interview.job_id;
                if (interview.job_title_fr) candidateInterview.job_title_fr = interview.job_title_fr;
                if (interview.job_title_en) candidateInterview.job_title_en = interview.job_title_en;
                if (attendee.approved_attendee_timeslots && attendee.approved_attendee_timeslots.length > 0) {
                  _.each(attendee.approved_attendee_timeslots, (approved_timeslot) => {
                    _.each(interview.interview_timeslots, (timeslot) => {
                      if (approved_timeslot.interview_timeslot_id === timeslot.id) {
                        const approvedTimeslot = {
                          timeslot_id: timeslot.id,
                          interview_id: timeslot.interview_id,
                          interview_date: timeslot.date,
                          interview_startsAt: timeslot.start_time,
                          interview_endsAt: timeslot.end_time,
                        };
                        candidateInterview.approved_attendee_timeslots.push(approvedTimeslot);
                      }
                    });
                  });
                }

                _.each(candidateInterview.interview_timeslots, (timeslot) => {
                  timeslot.selected = false;
                });

                _.each(candidateInterview.interview_interviewees, (interviewee) => {
                  if (interviewee.approved_interviewee_timeslots) {
                    if (!interviewee.microsoft_interview_link) interviewee.microsoft_interview_link = null;
                    _.each(interview.interview_timeslots, (timeslot) => {
                      if (interviewee.approved_interviewee_timeslots === timeslot.id) {
                        interviewee.interview_date = timeslot.date;
                        interviewee.timeslot = `${timeslot.start_time} - ${timeslot.end_time}`;
                      }
                    });
                  }
                });
              } else {
                if (!attendee.attendees_either_or && attendee.is_mandatory) mandatorySharedAttendees.push(attendee);
                if (attendee.attendees_either_or && attendee.is_mandatory && attendee.approved_attendee_timeslots.length == interview.minimum_confirm) {
                  eitherOrConfirmed = true;
                }
              }
            });
            if ( mandatorySharedAttendees.length && candidateInterview.is_mandatory && !candidateInterview.attendees_either_or ) {
              handleSelectedTimeslots(mandatorySharedAttendees, candidateInterview);
            }
            candidateInterview.interviewEitherOrConfirmed = eitherOrConfirmed ? true : false;
            candidateInterview.countOfTimeslotsToConfirm = countMinimumToConfirm(candidateInterview);
            $scope.candidateInterviews.push(candidateInterview);
          });

          $scope.interviews = showUnexpiredInterviews();

          if (!$scope.interviews.length) $scope.noInterviewOnFilter = true;
          createRefreshTimeout = $timeout(() => { addeventatc.refresh(); }, 1000);
        }
      }).catch(() => {
        $scope.isLoadingInterviews = false;
      });
    }

    function init() {
      $scope.currentUser = $rootScope.currentUser.user;
      fetchAllStatuses();
      getCandidateInterviews();
    }

    init();

    function saveTimeslots(selectedTimeslots) {
      $rootScope.api_status(
        'waiting',
        selectedTimeslots.length > 1 ? 'Saving selected timeslots...' : 'Saving timeslot...',
        selectedTimeslots.length > 1 ? 'Sauvegarde des plages horaires sélectionnées...' : 'Sauvegarde de la plage horaire...'
      );
      api.service_post('toolkit', 'interview/attendee-interview-timeslots', selectedTimeslots).then((response) => {
        if (response.data.status === 'success') {
          $rootScope.api_status('alert-success', 'Timeslots has been confirmed successfully!', 'Les créneaux horaires ont été confirmés avec succès!');
          $scope.selectedStatus.id = 3;
          getCandidateInterviews();
        } else {
          $rootScope.api_status(
            "error",
            "An error occurred and the selected timeslots could not be saved, please try again or contact support@workland.com for assistance",
            "Une erreur est survenue et les palges horaires sélectionnées n'ont pu être sauvegardées, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide"
          );
        }
      }).catch(() => {
        $rootScope.api_status(
          "error",
          "An error occurred and the selected timeslots could not be saved, please try again or contact support@workland.com for assistance",
          "Une erreur est survenue et les palges horaires sélectionnées n'ont pu être sauvegardées, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide"
        );
        $scope.isLoadingInterviews = false;
      });
    }

    function saveTimeslotsErrorHandler(isMandatoryAndNotEitherOr, minOfTimeslotsToSelect) {
      const amongUnselected = {
        en: isMandatoryAndNotEitherOr ? 'among available timeslots ' : '',
        fr: isMandatoryAndNotEitherOr ? 'parmis les plages horaires disponibles ' : ''
      };
      const msg = {
        en: `Please select a minimum of ${minOfTimeslotsToSelect} timeslot` + (minOfTimeslotsToSelect > 1 ? 's ' : ' ') + amongUnselected.en + `for the interview`,
        fr: `Veuillez sélectionner un minimum de ${minOfTimeslotsToSelect} plage` + (minOfTimeslotsToSelect > 1 ? 's ' : ' ') + `horaire ` + amongUnselected.fr + `pour l'entrevue`
      }
      $rootScope.api_status('alert-danger', msg.en, msg.fr, "", "", 4000 );
    }

    function confirmTimeslots(interview) {
      const selectedTimeslots = [];
      for (let i = 0; i < interview.interview_timeslots.length; i++) {
        const timeslot = interview.interview_timeslots[i];
        if (timeslot.selected) {
          const data = {
            interview_attendee_id: interview.attendee_id,
            interview_timeslot_id: timeslot.id,
            taken_by_user_id: 0,
          };
          selectedTimeslots.push(data);
        }
      }

      if (interview.is_mandatory && !interview.attendees_either_or) {
        const allTimeslots = _.countBy(interview.interview_timeslots, timeslot => timeslot.isAlreadySelected ? 'alreadySelected': 'unselected');
        const selectedAmongsUnselected = _.filter(interview.interview_timeslots, timeslot => timeslot.selected && !timeslot.isAlreadySelected).length;
        let minimumToSelect = interview.minimum_confirm;
        if (allTimeslots.unselected < minimumToSelect) minimumToSelect = allTimeslots.unselected;
        if (selectedTimeslots.length && selectedAmongsUnselected >= minimumToSelect) {
          saveTimeslots(selectedTimeslots);
        } else {
          saveTimeslotsErrorHandler(allTimeslots.unselected != interview.interview_timeslots.length, minimumToSelect);
        }
      } else {
        const minimumToSelect = interview.is_mandatory && !interview.interviewEitherOrConfirmed ? interview.minimum_confirm : 1;
        if (selectedTimeslots.length && (selectedTimeslots.length >= minimumToSelect)) {
          saveTimeslots(selectedTimeslots);
        } else {
          saveTimeslotsErrorHandler(false, minimumToSelect);
        }
      }
    }

    function showCancellationModal(interview) {
      $scope.interviewToCancel = interview;
      $scope.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/interview-requests/interview-cancel-modal.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function cancelInterview(interview) {
      $scope.modalInstance.close();
      let msgFr; let msgEn;
      msgEn = 'Interview request is being cancelled...';
      msgFr = "La demande d'entrevue est annulée ...";
      $rootScope.api_status('waiting', msgEn, msgFr);

      const data = {
        interview_id: interview.interview_id,
        attendee_id: interview.attendee_id,
        status_id: 2,
        user_id: interview.user_id,
        attendees_either_or: interview.attendees_either_or,
        is_interview_owner: interview.is_interview_owner,
        is_mandatory: interview.is_mandatory,
        reply_note: interview.cancellation_note,
        replied_at: utils.toDateStr(new Date()),
        questionnaire_id: interview.questionnaire_id,
        has_event_in_calendar: interview.has_event_in_calendar
      };

      const promise = api.service_post('toolkit', `interview/attendees/${interview.attendee_id}`, data, 'update');
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'Interview request has been cancelled successfully.';
          msgFr = "La demande d'entrevue a été annulée avec succès.";
          $rootScope.api_status('alert-success', msgEn, msgFr);
          getCandidateInterviews();
        } else {
          $rootScope.api_status('alert-danger', response.data);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function is_expired(interview_data) {
      const nowdate = new Date();
      const sDate = $filter('date')(nowdate, 'yyyy-MM-dd');
      if (sDate > interview_data) {
        return true;
      }
      return false;
    }

    $scope.numberOfTimesotsCheckedHandler = (interviewTimeslots) => {
      const numberOfTimeslotsSelected = _.filter(interviewTimeslots, (timeslot) => timeslot.selected);
      $scope.numberOfTimeslotsSelected = numberOfTimeslotsSelected.length;
    };

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout);
      $timeout.cancel(createRefreshTimeout);
    });
    
  }

  InterviewRequestsController.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
    '$filter',
    '$uibModal',
    '$timeout',
    'worklandLocalize',
  ];

  angular.module('atlas')
    .controller('InterviewRequestsController', InterviewRequestsController);
}(angular));
