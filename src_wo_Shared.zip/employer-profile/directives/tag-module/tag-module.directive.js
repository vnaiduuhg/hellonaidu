(function (angular) {
  function TagModuleCtrl(
    $scope,
    $rootScope,
    $timeout,
    api,
    utils,
    Event,
    _,
    storageService
  ) {
    const errorMsgs = {
      delete: { fr: "Une erreur est survenue et l'étiquette n'a pu être supprimée", en: 'An error occurred and the tag could not be deleted' },
      create: { fr: "Une erreur est survenue et l'étiquette n'a pu être ajoutée", en: 'An error occurred and the tag could not be added' },
      read: { fr: "Une erreur est survenue et la liste des étiquettes n'a pu être récupérée", en: 'An error occurred and the tags list could not be retrieved' },
    };
    const scope = {
      out: utils.out,
      firstInitDone: false,
      action: null,
      tagAlreadyAssigned: false,
      employerTags: [],
      selectedTag: {
        selected: {},
      },
      employerHasTags: false,
    };
    angular.extend($scope, scope);

    let createTimeout1;
    let createTimeout2;

    $scope.tagHandler = (tag) => null;

    function onTagSelection() {
      $scope.tagAlreadyAssigned = false;
    };

    function stopLoader() {
      $scope.action = null;
      $scope.loading = false;
    }

    function preparedata() {
      const data = [];
      const empAccountId = storageService.getItem('account_id');
      _.each($scope.selectedCandidateList, (candidate) => {
        candidate.assignedTags = [];
        if (candidate.tagsList.length) {
          _.each(candidate.tagsList, (candTag) => {
            const indx = _.findIndex($scope.employerTags, (empTag) => empTag.id === candTag.id && +empAccountId === +candTag.employer_accountId);
            if (indx >= 0) {
              candidate.assignedTags.push($scope.employerTags[indx]);
            }
          });
        }
        candidate.tags_list = candidate.assignedTags;
        if (!$scope.isCrm) data.push({ candidate_id: candidate.user_id, tags_list: candidate.tags_list });
      });
      createTimeout1 = $timeout(() => {
        stopLoader();
        if (!$scope.isCrm) Event.broadcast('CANDIDATE_TAGS_EVENT', data);
      }, 1000);
    }

    function addTagsListToCandidate(taggedCandidatesList) {
      _.each($scope.selectedCandidateList, (candidate) => {
        candidate.tagsList = [];
        _.find(taggedCandidatesList, (taggedCandidate) => {
          if (candidate.user_id == taggedCandidate._source.user_id && taggedCandidate._source.tags_list) {
            candidate.tagsList = taggedCandidate._source.tags_list;
          }
          return candidate.user_id == taggedCandidate._source.user_id;
        });
      });
      preparedata();
    }

    function candidateTags() {
      const accountList = _.pluck($scope.selectedCandidateList, 'account_id');
      api.service_post('indexing', 'indexing/candidates/read-from-account-id-list', { account_ids: accountList }).then((response) => {
        if (response.data.status === 'success') {
          addTagsListToCandidate(response.data.data);
        } else {
          $rootScope.api_status('alert-danger', errorMsgs.read.en, errorMsgs.read.fr);
          stopLoader();
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', errorMsgs.read.en, errorMsgs.read.fr);
        stopLoader();
      });
    }

    function init() {
      $scope.loading = true;
      api.service_get('toolkit', 'document-manager/tags').then((response) => {
        if (response.data.status === 'success') {
          if (response.data.data.result.length) {
            $scope.employerTags = response.data.data.result;
            $scope.employerHasTags = true;
          }
        } else {
          $rootScope.api_status('alert-danger', errorMsgs.read.en, errorMsgs.read.fr);
        }
      }).then(() => {
        if ($scope.employerTags.length) {
          candidateTags();
        } else {
          $scope.loading = false;
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', errorMsgs.read.en, errorMsgs.read.fr);
        $scope.loading = false;
      });
    }

    function prepareTagsAssigment(tagToAssign) {
      const candidateIds = [];
      _.each($scope.selectedCandidateList, (candidate) => {
        const hasTag = _.find(candidate.assignedTags, (tag) => tag.id == tagToAssign.id);
        if (!hasTag) candidateIds.push(+candidate.user_id);
      });
      return candidateIds;
    }

    function assignTag(tag) {
      $('html, body').animate({ scrollTop: 100 }, 500);
      $scope.action = 'create';
      $scope.loading = true;
      const candidateIdsList = prepareTagsAssigment(tag);
      const data = {
        user_ids: candidateIdsList,
        tag_ids: [+tag.id],
      };
      if (candidateIdsList.length) {
        return api.service_post('indexing', 'indexing/candidates/tags', data).then((response) => {
          if (response.status === 201) {              
            candidateTags();
            $scope.selectedTag.selected = {};
          } else {
            $rootScope.api_status('alert-danger', errorMsgs.create.en, errorMsgs.create.fr);
            stopLoader();
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', errorMsgs.create.en, errorMsgs.create.fr);
          stopLoader();
        });
      } else {
        $scope.tagAlreadyAssigned = true;
        stopLoader();
      }
    }

    function spliceTagFromCandidate(tag, candidateId) {
      const data = [];
      const candIndex = _.findIndex($scope.selectedCandidateList, (candidate) => candidate.user_id == candidateId);
      const tagIndex = _.findIndex($scope.selectedCandidateList[candIndex].assignedTags, (tagItem) => tagItem.id == tag.id);
      $scope.selectedCandidateList[candIndex].assignedTags.splice(tagIndex, 1);
      $scope.selectedCandidateList[candIndex].tags_list = $scope.selectedCandidateList[candIndex].assignedTags;
      if (!$scope.isCrm) {
        data.push({ candidate_id: candidateId, tags_list: $scope.selectedCandidateList[candIndex].tags_list });
      }
      createTimeout2 = $timeout(() => {
        stopLoader();
        if (!$scope.isCrm) Event.broadcast('CANDIDATE_TAGS_EVENT', data);
      }, 1000);
    }

    function deleteTag(tag, candidateId) {
      $('html, body').animate({ scrollTop: 100 }, 500);
      $scope.action = 'delete';
      $scope.loading = true;
      const data = {
        user_ids: [+candidateId],
        tag_ids: [+tag.id],
      };
      api.service_delete('indexing', 'indexing/candidates/tags', data).then((response) => {
        if (response.status === 200) {
          spliceTagFromCandidate(tag, candidateId);
        } else {
          $rootScope.api_status('alert-danger', errorMsgs.delete.en, errorMsgs.delete.fr);
          stopLoader();
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', errorMsgs.delete.en, errorMsgs.delete.fr);
        stopLoader();
      });
    }

    $scope.$watch('candListEvent', () => {
      if ($scope.firstInitDone) {
        $scope.tagAlreadyAssigned = false;
        $scope.loading = true;
        if ($scope.employerTags.length) candidateTags();
      } else {
        $scope.firstInitDone = true;
        init();
      }
    });

    const methods = {
      onTagSelection,
      assignTag,
      deleteTag,
    };
    angular.extend($scope, methods);

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
    });
  }

  TagModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    '$timeout',
    'api',
    'utils',
    'Event',
    '_',
    'storageService'
  ];

  angular.module('atlas')
    .directive('tagModule', () => ({
      scope: {
        candidate: '=',
        selectedCandidateList: '=',
        candListEvent: '=',
        isCrm: '=',
      },
      controller: TagModuleCtrl,
      templateUrl: './employer-profile/directives/tag-module/tag-module.template.html',
    })).controller('TagModuleCtrl', TagModuleCtrl);
}(angular));
