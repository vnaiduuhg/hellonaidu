( function ( angular ) {

    'use strict';
    angular.module( 'atlas' )
            .directive( 'crudAddQuestionsModule', function () {
                return {
                    scope: true,
                    bindToController: {
                        section: '='
                    },
                    controllerAs: 'questionsIVAR',
                    controller: CrudAddQuestionsModuleCtrl,
                    templateUrl: './employer-profile/directives/crud-add-questions-module/crud-add-questions-module.template.html'
                };
            } );

    CrudAddQuestionsModuleCtrl.$inject = ['$scope', '_', 'api', 'utils', 'matchService'];

    function CrudAddQuestionsModuleCtrl( $scope, _, api, utils, matchService ) {

        CrudAddQuestionsModuleCtrl.questions = [];
        var questionsIVAR = this;
        var sectionsCtrl = $scope.sectionsCtrl;

        var API_ROUTE = 'questionnaire_web_api';
        var formModel = {
            ponderation: 1,
            settings: {
                editMode: false,
                viewCollection: true,
                viewForm: false
            }
        };
        //Keep a clean copy of initial settings
        var formModelInitial = angular.copy( formModel );

        var out = utils.out;

        
        var matchedOptions = [
            {
                key: "continue_add",
                label: out( 'Ajouter la pondération au score', 'Add weight to score' )
            },
            
            {
                key: "continue",
                label: out( 'N\'ajouter pas la pondération au score', 'Do not add the weight to score' )
            }
        ];

        var notMatchedOptions = [{
                key: 'exclude',
                label: out( 'Exclure le candidat', 'Exclude candidate' )
            }, {
                key: 'null',
                label: out( 'Continuer le matching', 'Continue matching' )
            }];

        var questionsIVARExtend = {
            out: out,
            crudAddQuestionsModuleCtrl: CrudAddQuestionsModuleCtrl,
            closeEditForm: closeEditForm,
            deleteQuestionFromSection: deleteQuestionFromSection,
            editQuestionSettings: editQuestionSettings,
            updateQuestionSettings: updateQuestionSettings,
            matchedOptions: matchedOptions,
            notMatchedOptions: notMatchedOptions,
            formModel: formModel,
            getQuestions: getQuestions
        };
        angular.extend( questionsIVAR, questionsIVARExtend );


        function getQuestions() {

            if ( CrudAddQuestionsModuleCtrl.questions.length || questionsIVAR.formModel.settings.editMode ) {
                return;
            }

            var promise = matchService.getData('question')
            .then( function ( response ) {
                // Save questions as a static variable so we dont reload it
                // every time
                CrudAddQuestionsModuleCtrl.questions = response.data.data;
            } );
            return promise;
        }

        
        function updateQuestionSettings() {
            var updating = questionsIVAR.formModel.settings.editMode;

            var questionSettings = angular.copy( questionsIVAR.formModel );
            questionSettings.pond_fct_true = [questionSettings.pond_fct_true, questionSettings.pond_fct_true];
            questionSettings.pond_fct_false = [questionSettings.pond_fct_false, questionSettings.pond_fct_false];
            questionSettings.sectionId = questionsIVAR.section.sectionId;
            delete questionSettings.settings;

            var path = updating ? 'sections/updQuestion' : 'sections/addQuestion';

            var promise = matchService.updData(path, {
                questionId: questionSettings.questionId,
                sectionId: questionSettings.sectionId,
                ponderation: questionSettings.ponderation,
                pond_fct_true: questionSettings.pond_fct_true,
                pond_fct_false: questionSettings.pond_fct_false
            });

            promise.then( function () {
                if ( !updating ) {
                    closeEditForm();
                }
                sectionsCtrl.getSections();
            } );
            return promise;
        }

        function editQuestionSettings( question ) {
            var questionCopy = _.pick( question,
                    'pond_fct_false',
                    'pond_fct_true',
                    'ponderation',
                    'questionId' );
            questionCopy.settings = {
                viewForm: true,
                editMode: true
            };
            questionCopy.pond_fct_false = questionCopy.pond_fct_false[0];
            questionCopy.pond_fct_true = questionCopy.pond_fct_true[0];
            questionsIVAR.formModel = questionCopy;
        }

        function closeEditForm() {
            questionsIVAR.formModel = angular.copy( formModelInitial );
            questionsIVAR.inputForm.$setPristine();
        }

        function deleteQuestionFromSection( question ) {
            var promise = matchService.updData('sections/delQuestion', {
                sectionId: questionsIVAR.section.sectionId,
                questionId: question.questionId
            });
            return promise.then( sectionsCtrl.getSections );
        }
    }

} )( angular );