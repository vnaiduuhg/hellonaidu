(function (angular) {
	function docusignDocViewerCtrl($scope, utils) {

	  const scope = {
		  out: utils.out,
	  };
	  angular.extend($scope, scope);
    
  }
  
	docusignDocViewerCtrl.$inject = ['$scope', 'utils'];

  angular.module('atlas').directive('docusignDocViewer', () => {
    return {
      scope: {
        selectedCandidates: '=',
        docusignApplications: '=',
        isLoading: '=',
        envelopeIdClicked: '=',
        docusignEnvelopesDisplay: '=',
        isCrm: '=',
        commonJobList: '=?',
      },
      controller: docusignDocViewerCtrl,
      templateUrl: './employer-profile/directives/docusign-doc-viewer/docusign-doc-viewer.template.html',
    }
  });

}(angular));
