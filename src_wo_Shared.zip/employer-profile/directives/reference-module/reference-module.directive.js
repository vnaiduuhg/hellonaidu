(function (angular) {
  function ReferenceModuleCtrl(
    $scope,
    api,
    utils,
    $uibModal,
    _,
    $rootScope,
    $timeout,
    $q,
  ) {
    let scope = {
      out: utils.out,
      filterData: {
        value: {
          reference_requested_count: 0,
        },
      },
      existing_questionnaire: [],
      bunch_referees_requested: false,
      loadingReferencesData: true,
      isReadyToSendRequest: false,
      isReadyToSendRequestLoading: true,
      first_init: true,
      timeoutPromise: null,
      errorMsgTitleEn: 'An error has occurred',
      errorMsgTitleFr: 'Une erreur est survenue',
      crmJobCandidate: { selected: {} },
    };
    angular.extend($scope, scope);

    let createTimeout1;
    let createTimeout2;
    let createTimeout3;
    let createTimeout4;
    let createTimeout5;
    let createTimeout6;

    $scope.tagHandler = (tag) => null;

    function updateReferencerequestsCount() {
      _.each($scope.selectedCandidates, (selectedcand) => {
        if (selectedcand.referees_requested != null) {
          selectedcand.referees_requested.reference_requested_count = $scope.filterData.value.reference_requested_count;
        }
      });
    }

    function getReferenceRequest() {
      if (!$scope.bulk) {
        $scope.referees_requested = {};
        const promise = api.service_get('toolkit', 'reference/reference-requests', { filter_by_job_application_id: $scope.candidate.application_id });
        promise.then((response) => {
          const res = response.data;
          if (res.status === 'success') {
            if (res.data.result.length > 0) {
              [$scope.referees_requested] = res.data.result;
              $scope.candidate.referees_requested = $scope.referees_requested;
              $scope.candidate.references_requested_id = res.data.result[0].id;
            } else {
              $scope.referees_requested = {
                reference_requested_count: null,
                id: null,
              };
              $scope.candidate.referees_requested = $scope.referees_requested;
            }
          } else {
            $rootScope.api_status('alert-danger', 'The reference request could not be fetched', 'La demande de référence n\'a pu être récupérée', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
          }
          $scope.loadingReferencesData = false;
          $scope.isReadyToSendRequestLoading = false;
          $scope.isReadyToSendRequest = true;
        }).catch(() => {
          $scope.loadingReferencesData = false;
          $scope.isReadyToSendRequestLoading = false;
          $rootScope.api_status('alert-danger', 'The reference request could not be fetched', 'La demande de référence n\'a pu être récupérée', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
        });
      } else {
        $scope.bunch_referees_requested = true;
        const promises = [];
        _.each($scope.selectedCandidates, (cand) => {
          promises.push(api.service_get('toolkit', 'reference/reference-requests', { filter_by_job_application_id: cand.application_id }).then((response) => {
            const res = response.data.data;
            if (res.result.length > 0) {
              cand.references_requested_id = res.result[0].id;
              [cand.referees_requested] = res.result;
            } else {
              cand.references_requested_id = null;
              cand.referees_requested = null;
            }
            $scope.loadingReferencesData = false;
          }).catch(() => {
            $scope.loadingReferencesData = false;
            $scope.isReadyToSendRequestLoading = false;
            cand.references_requested_id = null;
            cand.referees_requested = null;
          }));
        });

        $q.all(promises).then(() => {
          $scope.isReadyToSendRequest = true;
          $scope.isReadyToSendRequestLoading = false;
        }).catch(() => {
          $scope.isReadyToSendRequestLoading = false;
          $rootScope.api_status('alert-danger', 'Reference requests could not be fetched', 'Les demandes de référence n\'ont pu être récupérées', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
        });
      }
    }

    function createReferencesRequest(data) {
      let msgEn;
      let msgFr;
      $rootScope.api_status('waiting', 'Sending your request...', 'Envoi de la demande ...');
      const promise = api.service_post('toolkit', 'reference/reference-requests/create-or-update-batch', data);
      promise.then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          const message = _.find(res.email_message, (v) => typeof v === 'string');
          const sentEmailResult = utils.sentAutoEmailStatus(message, res.email_sent);
          $rootScope.api_status('alert-success', 'The references request has been created successfully', 'La demande de références a été créée avec succès', 'Done', 'Terminé');
          if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
            createTimeout1 = $timeout(() => {
              $rootScope.api_status('alert-danger', sentEmailResult.msgEn, sentEmailResult.msgFr, 'No automated email sent', 'Aucun courriel automatisé envoyé');
            }, 4500);
          } else if (sentEmailResult.sendEmailSuccess.length) {
            msgEn = 'An email has been sent successfully to the candidate';
            msgFr = 'Un email a été envoyé au candidat avec succès';
           createTimeout2 = $timeout(() => {
              $rootScope.api_status('alert-success', msgEn, msgFr);
            }, 3000);
          } else {
            msgEn = 'An error has occurred, no automated messages could be sent. However, the candidate can access the reference request via their profile.';
            msgFr = 'Une erreur est survenue, aucun message automatisé n\'a pu été envoyé. Le candidat peut toutefois accéder à la demande de référence via son profil.';
            createTimeout3 = $timeout(() => {
              $rootScope.api_status('alert-danger', msgEn, msgFr, 'Automated email failed', 'Échec du courriel automatisé', 6000);
            }, 3000);
          }
          updateReferencerequestsCount();
          getReferenceRequest();
          $scope.filterData.value.reference_requested_count = 0;
        } else {
          $rootScope.api_status(
            'alert-danger',
            'Your references request could not be sent. Please contact our support team at support@workland.com for further assistance.',
            'Votre demande de références n\'a pu être envoyée. Veuillez contacter support@workland.com pour de l\'aide.', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr,
          );
        }
      }).catch(() => {
        $rootScope.api_status(
          'error',
          'Your references request could not be sent. Please contact our support team at support@workland.com for further assistance.',
          'Votre demande de références n\'a pu être envoyée. Veuillez contacter support@workland.com pour de l\'aide.', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr,
        );
      });
    }

    function warningReferenceRequestExist(data, existingReferencesCount) {
      const titleEn = existingReferencesCount > 1 ? 'Reference requests already exist!' : 'A reference request already exist!';
      const titleFr = existingReferencesCount > 1 ? 'Des demandes de référence existent déjà !' : 'Une demande de référence existe déjà !';
      const textEn = existingReferencesCount > 1 ? 'Are you sure you want to update them?' : 'Are you sure you want to update it?';
      const textFr = existingReferencesCount > 1 ? 'Êtes-vous certain de vouloir les modifier ?' : 'Êtes-vous certain de vouloir la modifier ?';

      $.confirm({
        title: utils.out(titleFr, titleEn),
        content: utils.out(textFr, textEn),
        theme: 'modern',
        buttons: {
          cancel: {
            text: utils.out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            action() {

            },
          },
          ok: {
            text: utils.out('Oui', 'Yes'),
            btnClass: 'btn btn-secondary', // @bug - btn-primary doesn't work in here
            action() {
              createReferencesRequest(data);
            },
          },
        },
      });
    }

    function requestReferences() {
      if ($scope.filterData.value.reference_requested_count < 1) {
        $rootScope.api_status('alert-danger', 'Please enter the number of references you wish to receive', 'Veuillez entrer le nombre de références que vous souhaitez recevoir', 'Error!', 'Erreur!');
        return;
      }

      let data = [];

      if ($scope.bulk) {
        angular.forEach($scope.selectedCandidates, (selectedCandidate) => {
          const dynamicsParams = {
            job_application_id: selectedCandidate.application_id,
            candidate_id: selectedCandidate.user_id,
            is_accepted: true,
            reference_requested_count: $scope.filterData.value.reference_requested_count,
            consent_message_id: 1,
            job_id: $scope.jobId,
          };
          dynamicsParams.id = selectedCandidate.references_requested_id
            ? selectedCandidate.references_requested_id : 0;
          data.push(dynamicsParams);
        });
        let idsExist = [];
        idsExist = _.filter(data, (item) => item.id > 0);
        if (idsExist.length > 0) {
          warningReferenceRequestExist(data, idsExist.length);
        } else {
          createReferencesRequest(data);
        }
        $scope.referees_requested.reference_requested_count = $scope.filterData.value.reference_requested_count;
      } else {
        data = {
          job_application_id: $scope.candidate.application_id,
          is_accepted: true,
          reference_requested_count: $scope.filterData.value.reference_requested_count,
          candidate_id: $scope.candidate.user_id,
          consent_message_id: 1,
          job_id: $scope.jobId,
        };

        data.id = $scope.referees_requested.id ? $scope.referees_requested.id : 0;
        if (data.id > 0) {
          warningReferenceRequestExist([data], 1);
        } else {
          createReferencesRequest([data]);
        }
      }
    }

    function fetchQuestionarrie() {
      const promise = api.service_get('toolkit', 'questionnaire/questionnaires', { filter_by_archived: 0 });
      return promise.then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.questionnaires = res.data.result;
        } else {
          $rootScope.api_status('alert-danger', 'La liste des questionnaires n\'a pu être récupérée', 'The questionnaire\'s list could not be fetched', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'La liste des questionnaires n\'a pu être récupérée', 'The questionnaire\'s list could not be fetched', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
      });
    }

    function getQuestionnaireAnswers(reference, candUserId) {
      const data = {
        reference_id: reference.id,
        questionnaire_id: reference.questionnaire_id,
      };
      api.service_post('toolkit', 'reference/reference-answers/get-questionnaire-with-answers-employer-side', data)
        .then((response) => {
          const res = response.data;
          if (res.status === 'success') {
            reference.selectedQuestionnaire = { id: res.data.result.id };
            reference.selectedQuestionnaire.questionnaire_questions = res.data.result.questionnaire_questions;
            _.each(reference.selectedQuestionnaire.questionnaire_questions, (question) => {
              question.answers = question.reference_answers;
            });
            reference.questionnaireAnswers = true;
            reference.questionnaireAccess = true;
            reference.questionnaireIsReady = true;
          } else if (($scope.selectedCandidates.length === 1) && (+$scope.selectedCandidates[0].user_id === +candUserId)) {
            if (res.message === 'Access denied for this account') {
              reference.questionnaireAccess = false;
              reference.questionnaireAnswers = true;
            }
            if (res.message === 'No questionnaire found') {
              reference.questionnaireAccess = true;
              reference.questionnaireAnswers = false;
            }
          }
        })
        .catch(() => {
          if (($scope.selectedCandidates.length === 1) && (+$scope.selectedCandidates[0].user_id === +candUserId)) {
            reference.questionnaireAccess = true;
            reference.questionnaireAnswers = false;
          }
        });
    }

    function findQuestionnaireTitle(questionnaireId) {
      const qTitle = _.find($scope.questionnaires, (questionnaire) => +questionnaire.id === +questionnaireId);
      const result = { en: { title: '' }, fr: { title: '' } };
      return qTitle ? qTitle.translation : result;
    }

    function getReferencesSentToReferees(isOpen, refree, candidate) {
      api.service_get('toolkit', `reference/references?filter_by_referee_id=${refree.referee_id}&filter_by_job_application_id=${candidate.application_id}`).then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          refree.references_requested = res.data.result;
          if (refree.references_requested.length) {
            _.each(refree.references_requested, (ref) => {
              ref.questionnaire_title = findQuestionnaireTitle(ref.questionnaire_id);
              if (ref.status === 'approved') {
                getQuestionnaireAnswers(ref, candidate.user_id);
              }
            });
          }
        } else {
          // @todo revise this
          $rootScope.api_status(
            'alert-danger',
            'The questionnaires sent could not be fetched',
            'Les questionnaires envoyés n\'ont pu être récupérés',
            $scope.errorMsgTitleEn,
            $scope.errorMsgTitleFr,
          );
        }
      }).catch(() => {
        // @todo revise this
        $rootScope.api_status(
          'alert-danger',
          'The questionnaires sent could not be fetched',
          'Les questionnaires envoyés n\'ont pu être récupérés',
          $scope.errorMsgTitleEn,
          $scope.errorMsgTitleFr,
        );
      });
    }

    function availableRefereesOfCandidate() {
      const promises = [];
      _.each($scope.selectedCandidates, (candidate) => {
        if ($scope.isCrmCandidates && $scope.selectedCandidates.length === 1) {
	        if($scope.jobApplicationId) {
	        	candidate.application_id =  $scope.jobApplicationId;
	        } else if (candidate.applicationList.length > 0 ) {
	        	const application = candidate.applicationList.find(element => element.job_id === $scope.crmJobCandidate.selected.id);
	        	candidate.application_id = application.id;
	        } else {
	        	candidate.application_id = null;
	        }
      	}

        candidate.availableReferees = [];
        if (candidate.application_id) {
          promises.push(
            api.service_get(
              'toolkit',
              'reference/job-application-referees',
              { filter_by_job_application_id: candidate.application_id, load_with: 'referee' }
            ).then((response) => {
              const res = response.data;
              if (res.status === 'success') {
                if (res.data.result.length) {
                  candidate.availableReferees = res.data.result;
                  _.each(res.data.result, (referee) => {
                    getReferencesSentToReferees(true, referee, candidate);
                  });
                }
              }
            }),
          );
        }
      });

      if (promises.length > 0) {
        $q.all(promises).then(() => {
          getReferenceRequest();
        }).catch(() => {
          $scope.loadingReferencesData = false;
          $scope.isReadyToSendRequestLoading = false;
          $rootScope.api_status('alert-danger', 'All referees could not be fetched', 'Toutes les références n\'ont pu être récupérées', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr);
        });
      }
    }

    function openQuestionnaireModal(reference) {
      const modalParams = {
        animation: true,
        templateUrl: './employer-profile/views/modal-templates/send-questionnarie-to-refree.template.html',
        size: 'md',
        scope: $scope,
        backdrop: 'static',
      };
      $scope.modal = $uibModal.open(modalParams);
    }

    function spliceSelectedReferencesAlreadySent(allData) {
      _.each($scope.existing_questionnaire, (refereeIdSearched) => {
        const index = _.findIndex(allData, (refereeToSplice) => +refereeIdSearched === +refereeToSplice.referee_id);
        if (index > -1) {
          allData.splice(index, 1);
        }
      });
    }

    function resetData() {
      $scope.existing_questionnaire = [];
      _.each($scope.selectedCandidates[0].availableReferees, (referee) => {
        if (referee.selected) {
          referee.selected = false;
        }
      });
    }

    function sendReferenceForm(data) {
      let msgEn;
      let msgFr;
      $rootScope.api_status('waiting', 'Sending the questionnaire...', ' Envoi du questionnaire ...', 'Please wait', 'Veuillez patienter');
      api.toolkit_batch('reference/references/send', data, 'POST').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.modal.close();
          resetData();
          const message = _.find(res.email_message, (v) => typeof v === 'string');
          const sentEmailResult = utils.sentAutoEmailStatus(message, res.email_sent);
          $rootScope.api_status('alert-success', 'The reference request has been created successfully', 'La demande de référence a été créée avec succès', 'Done', 'Terminé');
          availableRefereesOfCandidate();
          if (sentEmailResult.msgEn && sentEmailResult.msgFr) {
            createTimeout4 = $timeout(() => {
              $rootScope.api_status('alert-danger', sentEmailResult.msgEn, sentEmailResult.msgFr);
            }, 4500);
          } else if (sentEmailResult.sendEmailSuccess.length) {
            msgEn = 'An email has been sent successfully to the candidate';
            msgFr = 'Un email a été envoyé au candidat avec succès';
            createTimeout5 = $timeout(() => {
              $rootScope.api_status('alert-success', msgEn, msgFr);
            }, 3000);
          } else {
            msgEn = 'An error has occurred, no automated messages could be sent. Please try again or contact our support team at support@workland.com for further assistance.';
            msgFr = 'Une erreur est survenue, aucun message automatisé n\'a pu été envoyé. Veuillez réessayer ou contacter support@workland.com pour de l\'aide.';
            createTimeout6 = $timeout(() => {
              $rootScope.api_status('alert-danger', msgEn, msgFr, 'Automated email failed', 'Échec du courriel automatisé', 6000);
            }, 3000);
          }
        } else {
          $rootScope.api_status(
            'alert-danger',
            'The questionnaire could not be sent. Please try again or contact our support team at support@workland.com for further assistance.',
            'Le questionnaire n\'a pu être envoyé. Veuillez réessayer ou contacter support@workland.com pour de l\'aide.', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr,
          );
        }
      }).catch(() => {
        $rootScope.api_status(
          'error',
          'The questionnaire could not be sent. Please try again or contact our support team at support@workland.com for further assistance.',

          'Le questionnaire n\'a pu être envoyé. Veuillez réessayer ou contacter support@workland.com pour de l\'aide.', $scope.errorMsgTitleEn, $scope.errorMsgTitleFr,
        );
      });
    }

    function warningIfQuestionnaireAlreadySent(existingQuestionnairesCount, allData) {
      const textEn = existingQuestionnairesCount > 1
        ? 'Some of the selected references already have received this questionnaire, do you want to send it again?'
        : 'One selected reference already has received this questionnaire, do you want to send it again?';
      const textFr = existingQuestionnairesCount > 1
        ? 'Quelques unes des références sélectionnées ont déjà reçu ce questionnaire, voulez-vous l\'envoyer à nouveau?'
        : 'Une référence sélectionnée a déjà reçu ce questionnaire, voulez-vous l\'envoyer à nouveau?';
      $.confirm({
        title: utils.out('Attention!', 'Warning!'),
        content: utils.out(textFr, textEn),
        theme: 'modern',
        buttons: {
          ok: {
            text: utils.out('Ok', 'Ok'),
            btnClass: 'btn btn-primary',
            action() {
              sendReferenceForm(allData);
            },
          },
          cancel: {
            text: utils.out('Non', 'No'),
            btnClass: 'btn btn-secondary',
            action() {
              spliceSelectedReferencesAlreadySent(allData);
            },
          },
        },
      });
    }

    function checkIfQuestionnaireIsSent(referee, questionnaireId) {
      let data = null;
      if (referee.references_requested.length) {
        _.each(referee.references_requested, (reference) => {
          if (+reference.questionnaire_id === +questionnaireId) {
            data = {
              id: reference.id,
              status: reference.status,
              questionnaire_id: reference.questionnaire_id,
              job_application_id: reference.job_application_id,
              referee_id: referee.referee_id,
              token: reference.token,
            };
          }
        });
      }
      return data;
    }

    function prepareSendReferenceFormData(questionnaireId) {
      const allData = [];
      const chosenReferees = _.filter($scope.selectedCandidates[0].availableReferees, (referee) => {
        if (referee.selected) {
          let data = {};
          const existingReference = checkIfQuestionnaireIsSent(referee, questionnaireId);
          if (existingReference) {
            data = existingReference;
            $scope.existing_questionnaire.push(referee.referee_id);
          } else {
            data.id = 0;
            data.status = 'pending';
            data.questionnaire_id = questionnaireId;
            data.job_application_id = $scope.selectedCandidates[0].application_id;
            data.referee_id = referee.referee_id;
          }
          allData.push(data);
        }
        return referee.selected;
      });

      if (chosenReferees.length) {
        if ($scope.existing_questionnaire.length) {
          warningIfQuestionnaireAlreadySent($scope.existing_questionnaire.length, allData);
        } else {
          sendReferenceForm(allData);
        }
      } else {
        $rootScope.api_status('alert-danger', 'Please select a referee', 'Veuillez sélectionner une référence');
      }
    }

    $scope.minus = function minus() {
      $scope.filterData.value.reference_requested_count -= 1;
    };

    $scope.plus = function plus() {
      $scope.filterData.value.reference_requested_count += 1;
    };

    function init() {
      if ($scope.first_init) {
        $scope.first_init = false;
      }
      $q.when(fetchQuestionarrie()).then(() => {
        availableRefereesOfCandidate();
      });
    }

    function switchJob(job) {
      if (job) {
        $scope.jobId = job.id;
        $scope.selectedJob = true;
        $scope.jobApplicationId = job.job_application_id;
        init();
      }
    }

    $scope.getRequiredData = function getRequiredData() {
      if ($scope.bulk) {
        $scope.isReadyToSendRequest = false;
        $scope.loadingReferencesData = true;
        $scope.isReadyToSendRequestLoading = true;

        if ($scope.first_init) {
          init();
          return;
        }

        // If already on the reference-request module:
        // this prevent init to be called each time we change the selection of candidates
        // we wait 1 second then consider that the user has selected all candidates he wanted
        if (!$scope.first_init) {
          if ($scope.timeoutPromise) {
            $timeout.cancel($scope.timeoutPromise);
          }

          $scope.timeoutPromise = $timeout(() => {
            init();
          }, 1000);
        }
      }
    };

    $scope.$watch('candidate', (cand) => {
    	if ($scope.isCrmCandidates) {
    		const nullJobOption = $scope.candidate.jobList.find(element => element.id == null);
        const removeNullJobIndex = $scope.candidate.jobList.indexOf(nullJobOption);
        if(removeNullJobIndex >=0) { $scope.candidate.jobList.splice(removeNullJobIndex, 1); }
        if (!$scope.selectedJob && cand.jobList?.length > 0) {
          $scope.crmJobCandidate.selected = cand.jobList[0];
          $scope.jobId = cand.jobList[0].id;
        }
	    }
	    if (!$scope.bulk) {
	        $scope.isReadyToSendRequest = false;
	        $scope.loadingReferencesData = true;
	        $scope.isReadyToSendRequestLoading = true;
	        init();
	    }
    });

    scope = {
      init,
      requestReferences,
      createReferencesRequest,
      fetchQuestionarrie,
      getReferenceRequest,
      availableRefereesOfCandidate,
      openQuestionnaireModal,
      prepareSendReferenceFormData,
      checkIfQuestionnaireIsSent,
      spliceSelectedReferencesAlreadySent,
      warningIfQuestionnaireAlreadySent,
      sendReferenceForm,
      getQuestionnaireAnswers,
      getReferencesSentToReferees,
      switchJob,
    };
    angular.extend($scope, scope);

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
      $timeout.cancel(createTimeout3);
      $timeout.cancel(createTimeout4);
      $timeout.cancel(createTimeout5);
      $timeout.cancel(createTimeout6);
    });
  }
  ReferenceModuleCtrl.$inject = [
    '$scope',
    'api',
    'utils',
    '$uibModal',
    '_',
    '$rootScope',
    '$timeout',
    '$q',
  ];
  angular.module('atlas')
    .directive('referenceModule', () => ({
      restrict: 'EA',
      scope: {
        candidate: '=',
        bulk: '=',
        selectedCandidates: '=',
        jobId: '@',
        filterName: '@',
        selectedCandidatesList: '@',
        isCrmCandidates: '=',
      },
      link(scope) {
        scope.$watch('selectedCandidates', (currentValue, oldValue) => {
          if (scope.first_init || (oldValue.length !== currentValue.length)) {
            scope.getRequiredData();
          }
        }, true);
      },
      controller: ReferenceModuleCtrl,
      templateUrl: './employer-profile/directives/reference-module/reference-module.template.html',
    }));
}(angular));
