import { inherits } from 'util';

(function (angular) {
  function ApplicationCloneModuleCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    _,
  ) {

    let scope = {
      out: utils.out,
      jobList: [],
      jobsListLoaded: false,
      locationIdsList: [],
      keepOriginal: true,     
      selectedJob: { selected: {} },
      selectedStage: { selected: {} },    
      crmJobCandidate: { selected: {} },
    };
    angular.extend($scope, scope);

    $scope.tagHandler = function tagHandler(tag) {
      return null;
    };

    function setLocationsToJobList() {
      _.each($scope.jobList, (job) => {
        if (job.locations.length) {
          const jobLocation = _.find($scope.locationIdsList, (location) => +job.locations[0].location_id === +location.id);
          if (jobLocation) {
            job.address = ` ${jobLocation.street_number && jobLocation.street ? `${jobLocation.street_number} ${jobLocation.street}` : ''
            }${jobLocation.city ? (jobLocation.street_number && jobLocation.street ? ', ' : '')
                + jobLocation.city : (jobLocation.street_number && jobLocation.street ? ', ' : '') + jobLocation.region
            }${jobLocation.country ? `, ${jobLocation.country}` : ''} `;
          }
        }
      });
      $scope.jobsListLoaded = true;
    }

    function fetchLocations(locationIdsArray) {
      api.service_get('shared',
        'location/list-by-key-and-values',
        {
          key: 'id',
          'values[]': locationIdsArray,
        }).then((response) => {
        if (response.status === 200) {
          $scope.locationIdsList = response.data;
          if (Object.keys($scope.locationIdsList).length > 0) {
            setLocationsToJobList();
          } else {
            $scope.jobsListLoaded = true;
          }
        } else {
          $rootScope.api_status(
            'alert-danger',
            'A problem occurred and the list of jobs locations could not be retrieved',
            'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
          );
          $scope.jobsListLoaded = true;
        }
      }).catch(() => {
        $rootScope.api_status(
          'error',
          'A problem occurred and the list of jobs locations could not be retrieved',
          'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
        );
        $scope.jobsListLoaded = true;
      });
    }

    function init() {
      api.service_get('jobs', `job/accounts/${$rootScope.currentUser.account.id}/job-titles`).then((res) => {
        if (res.data && res.data.length > 0) {
          const tempArrayOfJobs = res.data;
          let privateJobs = [];
          let publishedJobs = [];
          angular.forEach(tempArrayOfJobs, (job) => {
            if (!$scope.jobId || +job.id !== +$scope.jobId) {
              job.titleFr = job.translations?.fr?.title ? job.translations.fr.title : (job.translations?.en?.title ? job.translations.en.title : "") + " -- Français non disponible --";
              job.titleEn = job.translations?.en?.title ? job.translations.en.title : (job.translations?.fr?.title ? job.translations.fr.title : "") + " -- English not available --";
              if (job.published_internal < 1 && job.published_outsourced < 1 && job.published_external < 1) {
                job.titleFr += ' ( privé )';
                job.titleEn += ' ( private )';
                privateJobs.push(job);
              } else {
                publishedJobs.push(job);
              }
            }
          });
          privateJobs = privateJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          publishedJobs = publishedJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          $scope.jobList = publishedJobs.concat(privateJobs);
        }
      }).then(() => {
        if ($scope.jobList.length) {
          const locationIdsArray = [];
          _.each($scope.jobList, (item) => {
            _.each(item.locations, (itemLocation) => {
              locationIdsArray.push(itemLocation.location_id);
            });
          });
          fetchLocations(_.uniq(locationIdsArray));
        } else {
          $scope.jobsListLoaded = true;
        }
      }).catch(() => {
        $rootScope.api_status(
          'error',
          'A problem occurred and the list of jobs could not be retrieved',
          'Un problème est survenu et la liste des postes n\'a pu être récupérée',
        );
        $scope.jobsListLoaded = true;
      });
    }

    init();

    function handleKeepOriginal(value) {
      $scope.keepOriginal = value;
    }

    $scope.$watch('candidate', (cand) => {
      $scope.keepOriginal = true;
      $scope.selectedStage.selected = {};
      $scope.selectedJob.selected = {};
      if ($scope.isCrmCandidates) {
        const nullJobOption = $scope.candidate.jobList.find(element => element.id == null);
        const removeNullJobIndex = $scope.candidate.jobList.indexOf(nullJobOption);
        if(removeNullJobIndex >=0) { $scope.candidate.jobList.splice(removeNullJobIndex, 1); }
        if (!$scope.selectedAppliedJob) {
          $scope.crmJobCandidate.selected = cand.jobList[0];
        }
        if($scope.jobApplicationId) {
          $scope.candidate.application_id =  $scope.jobApplicationId;
        } else if ($scope.candidate.applicationList.length > 0 ) {
          const application = $scope.candidate.applicationList.find(element => element.job_id === $scope.crmJobCandidate.selected.id);
          $scope.candidate.application_id = application.id;
        } else {
          $scope.candidate.application_id = null;
        }
      }
    });

    function getJobWorkflowStages(job) {
      $scope.loadingDone = false;
      api.service_get('workflow', `workflows/${job.workflow_id}/stages`).then((res) => {
        $scope.stageList = res.data;
        $scope.loadingDone = true;
      }).catch(() => {
        $scope.loadingDone = true;
      });
    }

    function clearRelatedStage() {
      $scope.selectedStage.selected = {};
    }

    function emptyInputs() {
      const stageEmpty = _.isEmpty($scope.selectedStage.selected);
      const jobEmpty = _.isEmpty($scope.selectedJob.selected);
      if (jobEmpty || stageEmpty) {
        return true;
      }
      return false;
    }

    function cloneApplication() {
      const areInputsEmpty = emptyInputs();
      if (areInputsEmpty) {
        $rootScope.api_status(
          'error',
          'Please make sure to fill all required inputs',
          'Veuillez vous assurer de remplir tous les champs requis',
          'Required field',
          'Champs requis',
        );
        return;
      }
      if (!$scope.candidate) {
        $rootScope.api_status(
          'error',
          'Please ensure that you only select one candidate at a time',
          'Veuillez vous assurer de ne sélectionner qu\'un seul candidat à la fois',
          'Warning',
          'Attention',
        );
        return;
      }
      let msgEn = '';
      let msgFr = '';
      if ($scope.selectedJob.selected && $scope.selectedStage.selected) {
        msgEn = 'Moving candidate';
        msgFr = 'Déplacement du candidat en cours';
        $rootScope.api_status('waiting', msgEn, msgFr);

        let appId;
        if ($scope.isCrmCandidates) {
          appId = $scope.jobApplicationId ? $scope.jobApplicationId : $scope.candidate.application_id;
        } else {
          appId = $scope.candidate.application_id;
        }

        return api.service_post('application', `application/${appId}/clone`,
          {
            keep_original: $scope.keepOriginal,
            new_job_id: $scope.selectedJob.selected.id,
            event_id: $scope.selectedStage.selected.id,
            new_workflow_id: $scope.selectedJob.selected.workflow_id,
          }).then((response) => {
          if (response.status === 201) {
            msgEn = 'Candidate moved successfully';
            msgFr = 'Candidat déplacé avec succès';
            $rootScope.api_status('alert-success', msgEn, msgFr);
            if (!$scope.keepOriginal && !$scope.isCrmCandidates) {
              $scope.callBackAfterCandidateMoved($scope.candidate);
            }
          } else if (response.status === 200) {
            $rootScope.api_status(
              'alert-danger', 
              'Unable to move the candidate. The candidate has already applied for this position.', 
              'Impossible de déplacer le candidat. Le candidat a déjà appliqué sur ce poste.',
              null, null, 3000);
          } else {
            $rootScope.api_status('alert-danger', 'Failed to move candidate', 'Erreur lors du déplacement du candidat');
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', 'Failed to move candidate', 'Erreur lors du déplacement du candidat');
        });
      }
    }

    function switchJob(job) {
      if (job) {
        $scope.selectedAppliedJob = true;
        $scope.jobId = job.id;
        $scope.jobApplicationId = job.job_application_id;
      }
    }

    scope = {     
      getJobWorkflowStages,
      cloneApplication,     
      clearRelatedStage,
      handleKeepOriginal,    
      switchJob,
    };
    angular.extend($scope, scope);
  }

  ApplicationCloneModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
  ];

  angular.module('atlas')
    .directive('applicationCloneModule', () => ({
      scope: {
        candidate: '=',
        callBackAfterCandidateMoved: '&?',
        jobId: '@?',
        isCrmCandidates: '=',
      },
      controller: ApplicationCloneModuleCtrl,
      templateUrl: './employer-profile/directives/application-clone-module/application-clone-module.template.html',
    }))
// eslint-disable-next-line no-undef
}(angular));
