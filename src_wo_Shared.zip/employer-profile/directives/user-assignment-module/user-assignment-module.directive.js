(function (angular) {
  angular.module('atlas')
    .directive('userAssignmentModule', () =>
      // http://blog.thoughtram.io/angularjs/2015/01/02/exploring-angular-1.3-bindToController.html
      ({
        scope: {},
        controllerAs: 'vm',
        bindToController: true,
        controller: UserAssignmentModuleCtrl,
        templateUrl: './employer-profile/directives/user-assignment-module/user-assignment-module.template.html',
      }));

  UserAssignmentModuleCtrl.$inject = [
    '$filter',
    'api',
    '_',
    'utils',
    '$scope',
    '$rootScope',
    'worklandLocalize',
    'MetaTagsService',
    '$state',
    'authService',
    'storageService',
    '$ngConfirm',
  ];

  function UserAssignmentModuleCtrl(
    $filter,
    api,
    _,
    utils,
    $scope,
    $rootScope,
    worklandLocalize,
    MetaTagsService,
    $state,
    authService,
    storageService,
    $ngConfirm,
  ) {
    const vm = this;

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    const formModel = {
      settings: {
        editMode: false,
        viewCollection: true,
        viewForm: false,
      },
      templateLang: null,
    };
    const formModelInitial = angular.copy(formModel);

    const { out } = utils;
    const vmExtend = {
      formModel,
      out,
      isAdmin: $rootScope.currentUser.permissions.isAdmin,
      closeEditForm,
      assignUser,
      editUser,
      deleteUserConfirmation,
      successUserAsignment,
      failUserAsignment,
      failNylasSyncMissing,
      failUserPermission,
      toggleView,
    };
    angular.extend(vm, vmExtend);
    init();

    function toggleView() {
      vm.formModel.settings.viewCollection = !vm.formModel.settings.viewCollection;
      vm.formModel.settings.viewForm = !vm.formModel.settings.viewForm;
    }

    vm.sortRecruiters = function (recruiter) {
      return recruiter.value.recruiterName || recruiter.value.recruiterEmail;
    };

    function updateUserPermission() {
      const newPermission = _.find(vm.allRecruiterPermissions, (permission) => permission.id == vm.formModel.permissions.id);
      const userIndex = _.findIndex(vm.assignedUsers, (user) => user.user_id == vm.formModel.user_id);
      if (newPermission && userIndex > -1) {
        vm.assignedUsers[userIndex].role_id = newPermission.id;
        vm.assignedUsers[userIndex].value.permissionName = newPermission.name;
        vm.assignedUsers[userIndex].value.permissionNameTranslated = utils.out(newPermission.translation.fr.name, newPermission.translation.en.name);
        vm.assignedUsers[userIndex].value.permissions = newPermission.id;
      }
    }

    function updateMemberRole() {
      api.service_query('accounts', `account-users/${vm.formModel.recruiterUserAccountId}/update-role`, 'PUT', {
        role_id: vm.formModel.permissions.id,
      }).then((response) => {
        if (response.data.status == 'success') {
          successRoleChanged();
          updateUserPermission();
          closeEditForm();
        } else {
          failRoleChanged();
        }
      }).catch(() => {
        failRoleChanged();
      });
    }

    function getAccountUser(accountId, userId) {
      return api.service_get('accounts', `account-users/${accountId}/${userId}`).then((res) => {
        if (res.data.status == 'success') {
          return res.data.data;
        }
        return [];
      });
    }

    function assignUser() {
      if (vm.formModel.settings.editMode) {
        updateMemberRole();
        return;
      }

      const accountId = storageService.getItem('account_id');
      authService.find({ email: vm.formModel.recruiterEmail, type: 'candidate' }).then((res) => {
        if (res.data.status != 'success') {
          return [];
        }
        if (!res.data.data.user_id) {
          return [];
        }
        return getAccountUser(accountId, res.data.data.user_id);
      }).then((accountUsers) => {
        if (accountUsers.length > 0) {
          const user = _.find(vm.assignedUsers, (u) => u.value.recruiterEmail == vm.formModel.recruiterEmail);
          changeRecruiterPermissions(user);
          return;
        }

        const data = {
          account_id: accountId,
          role_id: +vm.formModel.permissions.id,
          email: vm.formModel.recruiterEmail,
          language: vm.formModel.templateLang ? vm.formModel.templateLang : $rootScope.language,
        };
        vm.promiseAssign = authService.invite(accountId, data).then((res) => {
          if (res.data.status == 'success') {
            // message to user - invitation success
            successUserAsignment();
          } else {
            switch (res.data.message) {
              case 'nylas sync missing':
                failNylasSyncMissing();
                break;
              case 'user is not authorized':
                failUserPermission();
                break;
            }
          }
        }).catch((err) => {
          // message to user - invitation fail
          failUserAsignment();
        });
      }).catch((error) => {
        // message to user - find user fail
        failUserAsignment();
      });
    }

    function changeRecruiterPermissions(user) {
      $ngConfirm({
        title: out('Utilisateur existant!', 'Existing user!'),
        type: 'blue',
        content: out('L\'utilisateur invité est déjà actif dans votre plateforme. Désirez-vous modifier son rôle?', 'The user you invited already has an access to your platform. Do you want to modify is role?'),
        buttons: {
          Ok: {
            text: out('Ok', 'Ok'),
            btnClass: 'btn btn-primary',
            action() {
              $scope.$apply(() => {
                vm.formModel.settings.editMode = true;
                vm.formModel.account_id = user.account_id;
                editUser(user, -1);
              });
            },
          },
          Cancel: {
            text: out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            action() {

            },
          },
        },
      });
    }

    function genericConfirmMessage(title, content) {
      $ngConfirm({
        title,
        content,
        type: 'blue',
        buttons: {
          Ok: {
            text: out('Ok', 'Ok'),
            btnClass: 'btn btn-secondary',
            action() {

            },
          },
        },
      });
    }

    function successRoleChanged() {
      genericConfirmMessage('', out('Le rôle du membre a été changé avec succès.', 'The member\'s role was changed successfully.'));
    }

    function failRoleChanged() {
      genericConfirmMessage('', out('Le changement de rôle du membre a échoué.', 'The role change of the member has failed.'));
    }

    function successUserAsignment() {
      genericConfirmMessage(
        out('Invitation envoyée', 'Invitation sent'),
        out('Le nouveau membre apparaîtra dans la liste lorsqu\'il ou elle s\'inscrira et activera le compte.', 'The new member will appear in the list when he or she registers and activates the account.'),
      );
    }

    function failUserPermission() {
      genericConfirmMessage(
        out('Non autorisé', 'Not allowed'),
        out('Vous n\'avez pas les permissions nécessaires pour inviter un nouveau membre.', 'You have not the permissions to invite a new member.'),
      );
    }

    function failUserAsignment() {
      genericConfirmMessage(
        out('Un problème est survenu!', 'A problem occured!'),
        out('L\'invitation du nouveau membre a échouée, veuillez contacter Workland pour le support technique.', 'The account member invitation failed, contact Workland for Technical Support.'),
      );
    }

    function failNylasSyncMissing() {
      genericConfirmMessage(
        out('Courriel non synchronisé!', 'Email not synchronized!'),
        out('Veuillez d\'abord synchroniser votre courriel avec Nylas. Vous retrouverez cette fonctionnalité sous l\'onglet Paramètres, Synchronisation Courriel.', 'The account member invitation has not been sent. Please synchronize your email with Nylas first. You will find this functionality under Settings, Sync Email Client.'),
      );
    }

    function failDeleteMember() {
      genericConfirmMessage(
        out('Un problème est survenu!', 'A problem occurred!'),
        out('La suppression du membre a échoué.', 'The removal of the member failed.'),
      );
    }

    function spliceUserFromList(userId) {
      const userIndex = _.findIndex(vm.assignedUsers, (user) => user.id == userId);
      vm.assignedUsers.splice(userIndex, 1);
    }

    function deleteUser(user) {
      closeEditForm();
      return api.service_delete('accounts', `account-users/${user.id}`).then((response) => {
        if (response.data.status === 'success') {
          spliceUserFromList(user.id);
        } else {
          failDeleteMember();
        }
      }).catch(() => {
        failDeleteMember();
      });
    }

    function deleteUserConfirmation(user) {
      $ngConfirm({
        type: 'red',
        title: 'Attention',
        content: out('Voulez-vous supprimer cet utilisateur ?', 'Would you like to delete this user?'),
        buttons: {
          Ok: {
            text: out('Supprimer', 'Delete'),
            btnClass: 'btn btn-danger',
            action() {
              deleteUser(user);
            },
          },
          cancel: {
            text: out('Annuler', 'Cancel'),
            btnClass: 'btn btn-alt-secondary',
            action() {
              return;
            }
          }
        },
      });
    }

    function editUser(user, index) {
      vm.currentUserIndex = index;
      vm.formModel = angular.copy(user.value);
      vm.formModel._id = user._id;
      vm.formModel.permissions = +vm.formModel.permissions;
      vm.formModel.settings = {
        viewForm: true,
        editMode: true,
      };
      vm.formModel.user_id = user.user_id;
      vm.formModel.account_id = user.account_id;
    }

    function closeEditForm() {
      vm.formModel = angular.copy(formModelInitial);
      vm.promiseAssign = null;
      if (vm.inputForm) vm.inputForm.$setPristine();
    }

    function init() {
      getRoles();
    }

    function loadData() {
      vm.loadingDone = false;
      let recruiterId = null;
      let theFilter = '';
      vm.userAssign = true;
      vm.jobAssign = true;
      let permissions = null;
      // @todo check - not tested
      if (angular.isDefined($rootScope.currentUser.permissions.isRecruiter)) {
        recruiterId = $rootScope.currentUser.user.id;
        permissions = vm.currentUserPermissions = +storageService.getItem('account_role');

        if (!$rootScope.currentUser.permissions.isAdmin) {
          if (permissions !== 80 && permissions !== 30) {
            theFilter = { user_id: recruiterId };
            vm.jobAssign = false;
            vm.userAssign = false;
          }
        }
      }

      const allMembersOfAccount = $filter('filter')(angular.copy($rootScope.currentUser.account_user), theFilter);
      // @todo check values for role
      vm.assignedUsers = [];
      angular.forEach(allMembersOfAccount, (member) => {
        if (![10, 20, 30, 80].includes(member.role_id)) {
          return;
        }
        member.value = {};
        const perm = vm.allRecruiterPermissions[member.role_id];
        member.value.permissionName = perm.name;
        member.value.permissionNameTranslated = utils.out(perm.translation.fr.name, perm.translation.en.name);
        member.value.permissions = perm.id;

        member.value.recruiterEmail = member.user.email;
        member.value.recruiterName = `${member.user.first_name} ${member.user.last_name}`;
        member.value.recruiterId = member.user.id;
        member.value.recruiterUserAccountId = member.id;
        vm.assignedUsers.push(member);
      });
      vm.loadingDone = true;
      vm.noMembersFound = !(Array.isArray(vm.assignedUsers) && vm.assignedUsers.length);
      if (vm.noMembersFound) {
        vm.messageError = vm.out("Vous n'avez actuellement aucun membre de compte.", 'You do not have any members.');
      }
    }

    function getRoles() {
      const currentUserRole = storageService.getItem('account_role');
      api.service_get('authorization', 'roles').then((response) => {
        const res = response.data;
        if (res.status == 'success') {
          vm.permissionsObj = [];
          vm.allRecruiterPermissions = {};
          _.each(res.data.roles, (role) => {
            if (role.description == 'Recruiter') {
              vm.permissionsObj.push(role);
              vm.allRecruiterPermissions[role.id] = role;
            }
          });
          // If current user is a administrator recruiter, he has no permission to assign another admin
          if (currentUserRole == 30) {
            vm.permissionsObj = _.reject(vm.permissionsObj, (elm) => elm.id == 30);
          }
        } else {
          // handle error case - static data?
        }
      }).then((response) => loadData()).catch((error) => {
        // handle error case - static data?
      });
    }
  }
}(angular));
