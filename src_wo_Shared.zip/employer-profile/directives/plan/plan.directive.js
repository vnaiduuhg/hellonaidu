(function (angular) {
  function UserPlanCtrl(
    $scope,
    utils,
    MetaTagsService,
    $state,
    inventoryService,
  ) {
    $scope.out = utils.out;
    const scope = {
      loadingPlan: false,
      errorMessage: false,
    };
    angular.extend($scope, scope);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function init() {
      $scope.loadingPlan = true;
      $scope.currentPlans = [];
      $scope.availablePlans = [];
      inventoryService.checkInventory().then( (productsInfo) => {
        $scope.loadingPlan = false;
        const productsInfoUnique = _.uniq(productsInfo, 'product_id');
        angular.forEach(productsInfoUnique, (productInfo) => {
          if (productInfo.active && productInfo.product && productInfo.product !== null ) {
            $scope.currentPlans.push(productInfo.product);
            if (productInfo.product.product_groups.length > 0) {
              angular.forEach(productInfo.product.product_groups, (product_group) => {
                $scope.availablePlans = _.filter(product_group.products, (product) => {
                  return product.id !== productInfo.product.id;
                })
              })
            }
          }          
        })
      }).catch( () => {
        $scope.loadingPlan = false;
        $scope.errorMessage = true;
      })            
    }

    init();

    $scope.redirectToMarketplace = function () {
      window.open(
        window.appConfig.MARKETPLACE_UI_URL,
        '_blank'
      );
    }
  }

  UserPlanCtrl.$inject = [
    '$scope',
    'utils',
    'MetaTagsService',
    '$state',
    'inventoryService',
  ];
  const app = angular.module('atlas');
  app.controller('UserPlanCtrl', UserPlanCtrl);
}(angular));
