// eslint-disable-next-line func-names
(function (angular) {
  function InterviewModuleCtrl(
    $scope,
    $rootScope,
    _,
    api,
    utils,
    $filter,
    worklandLocalize,
    $uibModal,
    moment,
    calendarConfig,
    storageService,
    $ngConfirm,
    $cookies,
    statService,
    userSyncStateService,
  ) {

    let scope = {
      strings: worklandLocalize.strings,
      out: utils.out,
      rootUrl: worklandLocalize.rootUrl,
      imagesUrl: './../assets/images/',
      minDate: new Date(),
      status: {
        opened: false
      },
      dateOptions: {
        formatYear: 'yy',
        startingDay: 1
      },
      formControl: {
        isSelected: false,
      },
      confirm_date: {
        opened: false,
      },
      interviewFormModel: {},
      selectedStatus: {},
      onedayTimes: ['07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'],
      onehourTime_Options: [{ value: 15, label: '15min' }, { value: 30, label: '30min' }, { value: 45, label: '45min' }, { value: 60, label: '60min' }],
      onehourTimes: ['00', '15', '30', '45'],
      attendees: [],
      originalColorlist: statService.getColorsArray(),
      error: {},
      showSyncEmail: true,
      interviewTypes: [],
      interivewStatuses: [],
      events: [],
      isLoadingInterviews: false,
      autocomplete: null,
      isDeptMgrRecruiter: $rootScope.currentUser.permissions.isDeptMgrRecruiter,
      crmJobCandidate: { selected: {} },
      defaultCrmSelectOption: {
        id: null,
        translations: [{ title: 'No job' }, { title: 'Aucun poste' }],
      },
      hasMicrosoftToken: null,
      showAddressField: false,
      isAllowedToSyncAutomatedAccount: $rootScope.currentUser.permissions.atsFullAndAdmin,
    };
    angular.extend($scope, scope);

    $scope.open = function open($event) {
      $scope.status.opened = true;
    };

    // This will set the week number hover label on the month view
    calendarConfig.i18nStrings.weekNumber = utils.out('Semaine', 'Week' )+ " {week}";

    $scope.tagHandler = (tag) => null;

    function fetchInterviewTypes() {
      const promise = api.service_get('toolkit', 'interview/types');
      promise.then((response) => {
        if (response.data.status === 'success') {
          _.each(response.data.data.result, (interviewType) => {
            if (interviewType.translation.fr.type === 'En-Personne') {
              interviewType.translation.fr.type = 'En personne';
            }
          });
          $scope.interviewTypes = response.data.data.result;
        } else {
          $scope.interviewTypes = [];
        }
      }).catch(() => {
        $scope.interviewTypes = [];
      });
    }

    function fetchAllStatuses() {
      const promise = api.service_get('toolkit', 'interview/status');
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.interivewStatuses = response.data.data.result;
        } else {
          $scope.interivewStatuses = [];
        }
      }).catch(() => {
        $scope.interivewStatuses = [];
      });
    }

    function getRoles() {
      $scope.allPermissions = {};
      api.service_get('authorization', 'roles').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          _.each(res.data.roles, (role) => {
            $scope.allPermissions[role.id] = role;
          });
        } else {
          // handle error case - static data?
        }
      }).catch(() => {
        // handle error case - static data?
      });
    }

    function userWarning(content) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: $scope.out('Attention', 'Attention'),
        content,
        type: 'blue',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn-blue',
            action() {

            },
          },
        },
      });
    }

    function setAttendee(user, roleId) {
      const perm = $scope.allPermissions[roleId];
      return {
        permissionName: perm.name,
        permissionNameTranslated: $scope.out(perm.translation.fr.name, perm.translation.en.name),
        permissions: perm.id,
        recruiterEmail: user.user.email,
        recruiterName: `${user.user.first_name} ${user.user.last_name}`,
        recruiterId: user.user.id,
        user_id: user.user.id,
      };
    }

    function getRecruiters() {
      $scope.loadingDone = false;
      $scope.attendees = [];
      $scope.assignedUsers = angular.copy($rootScope.currentUser.account_user);
      angular.forEach($scope.assignedUsers, (assignedUser) => {
        if (![10, 20, 30, 80].includes(assignedUser.role_id)) {
          return;
        }
        assignedUser.attendee = setAttendee(assignedUser, assignedUser.role_id);
        $scope.attendees.push(assignedUser.attendee);
      });

      $scope.loadingDone = true;
      $scope.noMembersFound = !(Array.isArray($scope.assignedUsers) && $scope.assignedUsers.length);
      if ($scope.noMembersFound) {
        $scope.messageError = $scope.out("Vous n'avez actuellement aucun membre de compte.", 'You do not have any members.');
      }
    }

    function getLocationJson(place) {
      if (place && place.formatted_address && place.address_components && place.place_id && place.geometry) {
        const arrayOfCityReplacement = [];
        let street_number;
        let street_name;
        let city;
        let region;
        let province;
        let country;
        let postalCode;
        $scope.interviewFormModel.interview_address = place.formatted_address;
        for (let ac = 0; ac < place.address_components.length; ac += 1) {
          const component = place.address_components[ac];
          switch (component.types[0]) {
            case 'street_number':
              street_number = component.long_name;
              break;
            case 'route':
              street_name = component.long_name;
              break;
            case 'locality':
              city = component.long_name;
              break;
            case 'sublocality_level_1':
              arrayOfCityReplacement.splice(0, 0, component.long_name);
              break;
            case 'sublocality_level_2':
              arrayOfCityReplacement.push(component.long_name);
              break;
            case 'sublocality':
              arrayOfCityReplacement.push(component.long_name);
              break;
            case 'neighborhood':
              arrayOfCityReplacement.push(component.long_name);
              break;
            case 'administrative_area_level_3':
              arrayOfCityReplacement.push(component.long_name);
              break;
            case 'administrative_area_level_2':
              region = component.long_name;
              break;
            case 'administrative_area_level_1':
              province = component.long_name;
              break;
            case 'country':
              country = component.long_name;
              break;
            case 'postal_code':
              postalCode = component.long_name;
              break;
            // no default
          }
        }

        if (!city) {
          city = arrayOfCityReplacement.length ? arrayOfCityReplacement[0] : region;
        }
        if (!region) {
          region = province;
        }
        if (!province) {
          province = region;
        }

        const location = {
          locations: [{
            google_place_id: place.place_id,
            street_number,
            postal_code: postalCode,
            latitude: place.geometry ? place.geometry.location.lat() : '',
            longitude: place.geometry ? place.geometry.location.lng() : '',
            translations: [{
              locale: 'en',
              street: street_name,
              city,
              region,
              province,
              country,
            },
            {
              locale: 'fr',
              street: street_name,
              city,
              region,
              province,
              country,
            },
            ],
          }],
        };
        return location;
      }
      $rootScope.api_status(
        'alert-danger',
        'Invalid address, please make sure to enter a valid address or choose an option among the auto-complete suggestions',
        'Adresse invalide, veuillez vous assurer d\'entrer une adresse valide ou de choisir une option parmi les suggestions de saisie semi-automatique',
      );
      return false;
    }

    function saveLocation(place) {
      const addressValidated = getLocationJson(place);
      if (addressValidated) {
        api.service_post('shared', 'location', addressValidated)
          .then((response) => {
            if (response.data[0] && response.data[0].id) {
              $scope.interviewFormModel.location_id = response.data[0].id;
            } else {
              $rootScope.api_status(
                'alert-danger',
                'An error occured and the address could not be saved',
                'Une erreur s\'est produite et l\'adresse n\'a pu être sauvergardée',
              );
            }
          })
          .catch(() => {
            $rootScope.api_status(
              'alert-danger',
              'An error occured and the address could not be saved',
              'Une erreur s\'est produite et l\'adresse n\'a pu être sauvergardée',
            );
          });
      }
    }

    function initMap() {
      const autocompleteInput =  document.getElementById('map-interview');
      // google api is only instanciated when doesn't exist or when it is expired
      if($scope.autocomplete && angular.element(autocompleteInput).hasClass('pac-target-input')) {
        return;
      }
      $scope.autocomplete = new google.maps.places.Autocomplete(autocompleteInput);
      $scope.autocomplete.setFields(['address_components', 'formatted_address', 'geometry', 'place_id']);
      $scope.autocomplete.addListener('place_changed', () => {
        $scope.interviewFormModel.detial_address = '';
        const place = $scope.autocomplete.getPlace();
        saveLocation(place);
      });
    }

    function resetInterviewForm() {
      $scope.interviewFormModel = {};
      $scope.interviewFormModel.send_flg = true;
      $scope.showAddressField = false;
      $scope.colorlist = angular.copy($scope.originalColorlist);
    }

    function initializeCalender() {
      // These variables MUST be set as a minimum for the calendar to work
      $scope.calendarView = 'day';
      $scope.viewDate = new Date();
      $scope.cellIsOpen = false;
      $scope.events = [];
    }

    function scheduleInterview() {
      getRecruiters();
      $scope.formControl.isSelected = true;
      initializeCalender();
      resetInterviewForm();
    }

    function getCandidateInterviews() {
      $scope.hasPermission = !!((storageService.getItem('account_role') == '50'
                || storageService.getItem('account_role') == '100'
                || storageService.getItem('account_role') == '30'
                || storageService.getItem('account_role') == '20'));
      // In bulk mode, candidate is set to null.
      if (!$scope.bulk && !$scope.candidate) {
        return;
      }

      if ($scope.bulk && !$scope.hasPermission) {
        $scope.candidateInterviews = [];
        $scope.isLoadingInterviews = false;
        return;
      }

      $scope.isLoadingInterviews = true;

      let url; let params = {};

      if ($scope.bulk && $scope.hasPermission) {
        if (!$scope.isCrmCandidates) {
          url = `interview/interviews?filter_by_job_id=${$scope.jobId}`;
        } else {
          const candidateIds = $scope.selectedCandidates.map((element) => element.user_id);
          params = {
            'filter_by_candidate_id[]': candidateIds,
          };
          url = `interview/interviews?filter_by_job_id=${$scope.jobId}`;
        }
      } else {
        params = {
          'filter_by_candidate_id[]': $scope.candidate.user_id,
        };
        url = `interview/interviews?filter_by_job_id=${$scope.jobId}`; // job_id can be null
      }

      const promise = api.service_get('toolkit', url, params);
      promise.then((response) => {
        $scope.isLoadingInterviews = false;
        if (response.data.status === 'success') {
          $scope.candidateInterviews = response.data.data.result.sort((interview1, interview2) => interview1.interview_interviewees[0].candidate_id - interview2.interview_interviewees[0].candidate_id);

          // $scope.candidateInterviews = response.data.data.result;

          _.each($scope.candidateInterviews, (candidateInterview) => {
            if (candidateInterview.type[0].type === 'En-Personne') {
              candidateInterview.type[0].type = 'En personne';
            }

            candidateInterview.candidateNames = [];
            candidateInterview.candidateNamesDisplay = '';

            // Converting all timeslots from UTC to Local Time
            _.each(candidateInterview.interview_timeslots, (timeslot) => {
              const localStart = utils.utcToTimezone(`${timeslot.date} ${timeslot.start_time}`, 'zoozle');
              timeslot.start_time = localStart.time;
              timeslot.date = localStart.date;
              timeslot.end_time = utils.utcToTimezone(`${timeslot.date} ${timeslot.end_time}`, 'zoozle').time;
            });
            _.each(candidateInterview.interview_interviewees, (interviewee) => {
              if (interviewee.approved_interviewee_timeslots && interviewee.approved_interviewee_timeslots != '') {
                _.each(candidateInterview.interview_timeslots, (timeslot) => {
                  if (interviewee.approved_interviewee_timeslots === timeslot.id) {
                    interviewee.interview_date = timeslot.date;
                    interviewee.timeslot = `${timeslot.start_time} - ${timeslot.end_time}`;
                  }
                });
              }
              candidateInterview.candidateNames.push(interviewee.candidate_name);
              candidateInterview.candidateNamesDisplay = candidateInterview.candidateNames.join(', ');
            });
          });
        } else {
          $scope.candidateInterviews = [];
        }
        if ($scope.candidateInterviews.length === 0 && !$rootScope.currentUser.permissions.isDeptMgrRecruiter) {
          scheduleInterview();
        }
      }).catch(() => {
        $scope.isLoadingInterviews = false;
        $scope.candidateInterviews = [];
      });
      $scope.formControl.isSelected = false;
    }

    function handleSyncStatus(status) {
      $scope.statusCheckMessage = false;
      switch(status) {
        case 'running':
        case 'connected':
        case 'Success':
          getCandidateInterviews();
          break;
        default:
          $scope.showSyncEmail = true;
          $scope.loadingError = false;
          $scope.isLoadingInterviews = false;
          $scope.statusCheckMessage = true;
        }
    }

    function getSyncDetails() {      
      $scope.isLoadingInterviews = true;
      $scope.loadingError = false;
      $scope.showSyncEmail = false;      
      userSyncStateService.getSyncAccounts('automated').then((userSyncAutomatedAccounts) => {
        if (userSyncAutomatedAccounts) {
          const isEmpty = Object.values(userSyncAutomatedAccounts).every(x => x.length === 0);
          if (isEmpty) {
            $scope.showSyncEmail = true;
            $scope.isLoadingInterviews = false;
          } else {
            Object.entries(userSyncAutomatedAccounts).forEach(account => {
              const [key, value] = account;
              switch (key) {
                case 'nylas':
                  if(value.length && value[0].is_default) {
                    $scope.userData.email = userSyncAutomatedAccounts.nylas[0].email;
                    handleSyncStatus(userSyncAutomatedAccounts.nylas[0].sync_state);
                  }
                  break;
                case 'email_engine':
                  if(value.length && value[0].is_default) {
                    $scope.userData.email = userSyncAutomatedAccounts.email_engine[0].email;
                    handleSyncStatus(userSyncAutomatedAccounts.email_engine[0].sync_state);
                  }
                  break;
                case 'aws':
                  if(value.length && value[0].is_default) {
                    $scope.userData.email = userSyncAutomatedAccounts.aws[0].email;
                    handleSyncStatus(userSyncAutomatedAccounts.aws[0].verification_status);
                  }
                  break;
                default:
                  $scope.showSyncEmail = true;
                  $scope.isLoadingInterviews = false;
              }
            })
          }
        }
      }).catch(() => {
        $scope.loadingMsg = $scope.out('Échec de récupération des informations du compte. Veuillez essayer plus tard ou contacter Workland pour un support technique.',
          'Failed to fetch account information. Please try later or contact Workland for technical support');
        $rootScope.api_status('alert-danger');
        $scope.showSyncEmail = false;
        $scope.loadingError = true;
        $scope.isLoadingInterviews = false;
      })
    }

    function showTimeSlotModal(action, event) {
      $scope.action = action;
      $scope.event = event;
      $scope.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/interview-module/timeslot-modal-content.template.html',
        scope: $scope,
        size: 'lg',
      });
    }

    function enableNylas() {
      window.location = `${window.appConfig.ATLAS_UI_URL}sync`;            
    }

    const actions = [{
      label: '<span style="padding: 2px;"><i class=\'fa fa-pencil\'></i></span>',
      onClick(args) {
        showTimeSlotModal('Update', args.calendarEvent);
      },
    }, {
      label: '<span><i class=\'fa fa-remove\'></i></span>',
      onClick(args) {
        const index = $scope.events.indexOf(args.calendarEvent);
        $scope.events.splice(index, 1);
      },
    }];

    function eventClicked(event) {
      // showTimeSlotModal('Clicked', event);
    }

    function eventEdited(event) {
      // showTimeSlotModal('Edited', event);
    }

    function eventDeleted(event) {
      // showTimeSlotModal('Deleted', event);
    }

    function eventTimesChanged(event) {
      // showTimeSlotModal('Dropped or resized', event);
    }

    function toggle($event, field, event) {
      $event.preventDefault();
      $event.stopPropagation();
      event[field] = !event[field];
    }

    function createNewTimeSlot(date) {
      const event = {
        id: 0,
        title: $scope.out('Nouveau créneau horaire', 'New timeslot'),
        startsAt: moment(date).toDate(),
        endsAt: moment(date).add(30, 'minutes').toDate(),
        color: calendarConfig.colorTypes.important,
        draggable: true,
        resizable: true,
        actions,
      };    
      return event;
    }

    function timespanClicked(date, cell) {
      if ($scope.calendarView === 'month') {
        if (($scope.cellIsOpen && moment(date).startOf('day').isSame(moment($scope.viewDate).startOf('day'))) || cell.events.length === 0 || !cell.inMonth) {
          $scope.cellIsOpen = false;
          if (cell.events.length === 0) {
            showTimeSlotModal('Add', createNewTimeSlot(date));
          }
        } else {
          $scope.cellIsOpen = true;
          $scope.viewDate = date;
        }
      } else if ($scope.calendarView === 'year') {
        if (($scope.cellIsOpen && moment(date).startOf('month').isSame(moment($scope.viewDate).startOf('month'))) || cell.events.length === 0) {
          $scope.cellIsOpen = false;
        } else {
          $scope.cellIsOpen = true;
          $scope.viewDate = date;
        }
      } else if ($scope.calendarView === 'day') {
        showTimeSlotModal('Add', createNewTimeSlot(date._d));
      }
    }

    function changeCalenderView(view) {
      $scope.calendarView = view;
      $scope.cellIsOpen = false;
    }

    function saveTimeslot(action, event) {
      const startDate = $scope.event.startsAt;
      const endDate = $scope.event.endsAt;
      if (startDate > endDate) {
        userWarning(utils.out('Veuillez vérifier les dates', 'Please check the dates'));
        return false;
      }

      $scope.modalInstance.close();
      const index = $scope.events.indexOf(event);
      if (index === -1) {
        $scope.events.push(event);
      }
    }

    function cancel() {
      $scope.formControl.isSelected = false;
      resetInterviewForm();
    }

    function existsAttendee() {
      let exists = false;
      const attendeeUserId = $scope.interviewFormModel.attendee.user_id;
      const attendees = $scope.interviewFormModel.interview_attendees;
      if (attendees) {
        for (let idx = 0; idx < attendees.length; idx += 1) {
          if (attendeeUserId === attendees[idx].user_id) {
            exists = true;
            break;
          }
        }
      }
      return exists;
    }

    function addAttendee(isCreator) {
      let attendee;
      if (isCreator) {
        const account_role_id = +localStorage.getItem('account_role');
        if ([10, 20, 30, 80].includes(account_role_id)) {
          attendee = _.find($scope.attendees, attendee => attendee.user_id  == $rootScope.currentUser.user.id);
        } else {
          const tempAttendee = angular.copy(_.find($rootScope.currentUser.account_user, attendee => attendee.user_id == $rootScope.currentUser.user.id));
          attendee = setAttendee(tempAttendee, account_role_id);
        }
        attendee.is_mandatory = true;
      } else {
        attendee = $scope.interviewFormModel.attendee;
        attendee.is_mandatory = $scope.interviewFormModel.is_mandatory ? $scope.interviewFormModel.is_mandatory : false;
        if (attendee.user_id == $rootScope.currentUser.user.id) $scope.interviewFormModel.creatorIsCkecked = true;
      }
      // add a random color to attendee
      const randomColorIndex = _.random($scope.colorlist.length - 1);
      attendee.color = $scope.colorlist[randomColorIndex];
      $scope.colorlist.splice(randomColorIndex, 1);
      // remove selected attendee from dropdown list
      if ([10, 20, 30, 80].includes(attendee.permissions)) {
        const deleteAttendee = $scope.attendees.indexOf(attendee);
        if (deleteAttendee > -1) $scope.attendees.splice(deleteAttendee, 1);
      }

      $scope.interviewFormModel.attendee = null;
      const key = 'interview_attendees';
      const attendees = angular.isArray($scope.interviewFormModel[key]) ? $scope.interviewFormModel[key] : [];
      attendees.push(attendee);
      $scope.interviewFormModel[key] = attendees;
    }

    function checkMandatory(interviewAttendees) {
      if (!interviewAttendees) {
        interviewAttendees = $scope.interviewFormModel.interview_attendees;
      }
      let noMandatory = true;
      for (let idx = 0; idx < interviewAttendees.length; idx += 1) {
        if (interviewAttendees[idx].is_mandatory) {
          noMandatory = false;
          break;
        }
      }

      if (noMandatory) {
        $scope.interviewFormModel.send_flg = true;
      }
    }

    function removeAttendee($index) {
      if ($index < 0) {
        $index = _.findIndex($scope.interviewFormModel.interview_attendees, attendee => attendee.user_id == $rootScope.currentUser.user.id);
      }
      const attendee = $scope.interviewFormModel.interview_attendees[$index];
      // re-add color and attendee to dropdown lists
      const { color } = attendee;
      $scope.colorlist.push(color);
      // if attendee is the creator - unselect him
      if (attendee.user_id == $rootScope.currentUser.user.id) $scope.interviewFormModel.creatorIsCkecked = false;
      // if attendee is a recruiter, we re add him on the recruiter list
      if ([10, 20, 30, 80].includes(attendee.permissions)) $scope.attendees.splice($index, 0, attendee);
      // splice attendee from selected attendees list
      $scope.interviewFormModel.interview_attendees.splice($index, 1);
      checkMandatory($scope.interviewFormModel.interview_attendees);
    }

    function getDateRange() {
      const returndata = {};
      const nowdate = new Date();
      returndata.nowdate = $filter('date')(nowdate, 'yyyy-MM-dd');
      returndata.startdate = $filter('date')(nowdate, 'yyyy-MM-dd');
      nowdate.setDate(nowdate.getDate() + 83);
      returndata.enddate = $filter('date')(nowdate, 'yyyy-MM-dd');
      return returndata;
    }

    function checkExpireDate(expireDate) {
      const sdate = utils.toDateStr(expireDate);
      const dateRange = getDateRange();
      const today = new Date();
      const todayFormatted = moment(today).toDate();
      const startDateEvent = utils.toDateStr($scope.event.startsAt);
      const index = $scope.events.indexOf($scope.event);
      if (index !== -1 && sdate > startDateEvent) {
        userWarning(utils.out('La date d’expiration est postérieure à la date d’entrevue', 'Expiration date is past the interview date'));
        return false;
      }
      if (sdate < dateRange.nowdate) {
        userWarning(utils.out('La date d’expiration est passée', 'Expiration date has already passed'));
        return false;
      }
      if (index !== -1 && $scope.event.startsAt < todayFormatted) {
        userWarning(utils.out('Veuillez entrer une date et temps valides de l\'entrevue', 'Please input valid date and time of the interview'));
        return false;
      }
      return true;
    }

    // Check ExpireDate and confirm ExpireDate
    function checkExpireDate2() {
      const { interviewExpiredAt } = $scope.interviewFormModel; // candidate expire date
      const { attendeeExpiredAt } = $scope.interviewFormModel; // participant expire date
      if (attendeeExpiredAt !== '' && interviewExpiredAt !== '') {
        if (attendeeExpiredAt >= interviewExpiredAt) {
          userWarning(utils.out('Veuillez entrer une date après aujourd\'hui, mais avant la date d\'expiration.', 'Please input a date after today, but before the expiry date.'));
          return false;
        }
        return true;
      }
      return true;
    }

    function validateFormData() {
      if (!$scope.interviewFormModel.location_id && $scope.interviewFormModel.interview_location) {
        $rootScope.api_status(
          'alert-danger',
          'Invalid address, please make sure to enter a valid address or choose an option among the auto-complete suggestions',
          'Adresse invalide, veuillez vous assurer d\'entrer une adresse valide ou de choisir une option parmi les suggestions de saisie semi-automatique',
        );
        return false;
      }
      // @todo add more validation...
      return true;
    }

    function getInterviewRequestData(candidate) {
      let recruiterId = 0;
      if ($rootScope.currentUser.user) {
        recruiterId = $rootScope.currentUser.user.id;
      }

      const validatedFormData = validateFormData();
      if (!validatedFormData) {
        return false;
      }

      const interviewFormData = {
        status_id: 1,
        type_id: $scope.interviewFormModel.type_id,
        is_direct_invitation: $scope.interviewFormModel.send_flg,
        attendees_either_or: $scope.interviewFormModel.attendees_either_or ? 1 : 0,
        attendee_expired_at: $scope.interviewFormModel.send_flg ? '' : utils.toDateStr($scope.interviewFormModel.attendee_expired_at),
        note: $scope.interviewFormModel.note,
        interview_address: $scope.interviewFormModel.interview_address,
        confirmed_at: '',
        interview_expired_at: utils.toDateStr($scope.interviewFormModel.interview_expired_at),
        cancellation_note: '',
      };
      if ($scope.jobId) interviewFormData.job_id = $scope.jobId;
      if ($scope.interviewFormModel.location_id) interviewFormData.location_id = $scope.interviewFormModel.location_id;

      interviewFormData.interview_timeslots = [];
      _.each($scope.events, (event) => {
        let date = event.startsAt.toJSON().split('T')[0];
        // Getting time as is.
        const localStartTime = event.startsAt.toLocaleTimeString('en-GB');
        const localEndTime = event.endsAt.toLocaleTimeString('en-GB');
        // Converting time from the timezone set by the user, else from local time zone, To UTC.
        const utcStart = utils.datetimeToUTC(`${date} ${localStartTime}`, 'zoozle');
        const utcStartTime = utcStart.time;
        date = utcStart.date;
        const utcEndTime = utils.datetimeToUTC(`${date} ${localEndTime}`, 'zoozle').time;
        const localDate = utils.toDateStr( event.startsAt ) + ' ' + utils.toDateStr( event.startsAt , 'HH:mm:ss') + ' (' + moment.tz.guess() + ')';
        const timeslot = {
          interview_id: 0,
          date,
          start_time: utcStartTime,
          end_time: utcEndTime,
          local_start_time: localDate,
        };
        interviewFormData.interview_timeslots.push(timeslot);
      });
      if ($scope.hasMicrosoftToken) interviewFormData.microsoft_token = $scope.hasMicrosoftToken.access_token;

      const attendees = [];
      if ($scope.interviewFormModel.interview_attendees) {
        _.each($scope.interviewFormModel.interview_attendees, (interviewAttendee) => {
          const attendee = {
            interview_id: 0,
            status_id: 1,
            user_id: interviewAttendee.user_id,
            is_interview_owner: interviewAttendee.user_id === recruiterId ? 1 : 0,
            is_mandatory: interviewAttendee.is_mandatory ? 1 : 0,
            reply_note: '',
            replied_at: '',
            questionnaire_id: 0,
          };
          attendees.push(attendee);
        });
      }
      interviewFormData.interview_attendees = attendees;

      const interviewees = [];
      if ($scope.bulk) {
        _.each($scope.selectedCandidates, (selectedCandidate) => {
          const interviewee = {
            interview_id: 0,
            status_id: 1,
            candidate_id: selectedCandidate.user_id,
            reply_note: '',
            questionnaire_id: 0,
          };
          interviewees.push(interviewee);
        });
      } else {
        const interviewee = {
          interview_id: 0,
          status_id: 1,
          candidate_id: candidate.user_id,
          reply_note: '',
          questionnaire_id: 0,
        };
        interviewees.push(interviewee);
      }
      interviewFormData.interview_interviewees = interviewees;

      interviewFormData.minimum_confirm = $scope.interviewFormModel.minimum_confirm ? $scope.interviewFormModel.minimum_confirm : interviewees.length;

      return interviewFormData;
    }

    function requestInterviewNew(candidate) {
      const interviewFormData = getInterviewRequestData(candidate);
      $scope.sendingInterviewRequest = true;
      if (interviewFormData) {
        $rootScope.api_status('waiting', 'Interview is being scheduled...', "Réservation de l'entrevue...");
        const promise = api.service_post('toolkit', 'interview/interviews', interviewFormData);
        promise.then((response) => {
          if (response.data.status === 'success') {
            $rootScope.api_status(
              'alert-success',
              "Interview has been scheduled successfully!",
              "L'entrevue a été planifiée avec succès!"
            );
            resetInterviewForm();
            getCandidateInterviews();
          } else {
            errorHandler('interview_create_fail');
          }
          $scope.sendingInterviewRequest = false;
        }).catch(() => {
          errorHandler('interview_create_fail');
          $scope.sendingInterviewRequest = false;
        });
        return promise;
      }
    }

    $scope.statusFilter = function statusFilter(row) {
      if (!$scope.selectedStatus.name || $scope.selectedStatus.name === '') {
        return true;
      }
      return row.status[1].status === $scope.selectedStatus.name;
    };

    function resendInvitation(interviewId) {
      let msgEn;
      let msgFr;
      msgEn = 'Invitation is being resent...';
      msgFr = "Envoi de l'invitation en cours ...";
      $rootScope.api_status('waiting', msgEn, msgFr);

      const data = {};
      const promise = api.service_post('toolkit', `interview/resend-invitation?interview_id=${interviewId}`, data);
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'Invitation has been resent successfully.';
          msgFr = "L'invitation a été renvoyée avec succès .";
          $rootScope.api_status('alert-success', msgEn, msgFr);
        } else {
          $rootScope.api_status('alert-danger');
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function showCancellationModal(interivew) {
      $scope.interivewToCancel = interivew;
      $scope.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/interview-module/interview-cancel-modal.template.html',
        scope: $scope,
        size: 'md',
      });
    }

    function cancelInterview(interivew) {
      $scope.modalInstance.close();
      let msgEn;
      let msgFr;
      msgEn = 'Interview is being cancelled...';
      msgFr = "Annulation de l'entrevue en cours ...";
      $rootScope.api_status('waiting', msgEn, msgFr);

      interivew.status_id = 2;

      const promise = api.service_post('toolkit', `interview/interviews/${interivew.id}`, interivew, 'update');
      promise.then((response) => {
        if (response.data.status === 'success') {
          msgEn = 'Interview has been cancelled successfully.';
          msgFr = "L'entrevue a été annulée avec succès .";
          $rootScope.api_status('alert-success', msgEn, msgFr);
          getCandidateInterviews();
        } else {
          $rootScope.api_status('alert-danger', response.data);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    $scope.confirm_date_open = function confirm_date_open($event) {
      $scope.confirm_date.opened = true;
    };

    $scope.directChang = function directChang() {
      if (!$scope.interviewFormModel.send_flg) {
        $scope.interviewFormModel.attendee_expired_at = '';
      }
    };

    function noExistMandatory(param) {
      let noexists = true;
      const { interviewFormModel } = $scope;
      const attendees = interviewFormModel.interview_attendees;

      let mandatoryNum = 0;
      if (attendees) {
        for (let idx = 0; idx < attendees.length; idx += 1) {
          if (attendees[idx].is_mandatory === true) {
            mandatoryNum += 1;
            if (mandatoryNum === param) {
              noexists = false;
              break;
            }
          }
        }
      }

      if ((param === 2) && (mandatoryNum < 2)) {
        interviewFormModel.attendees_either_or = false;
      }
      return noexists;
    }

    function errorHandler(msg) {
      switch(msg) {
        case 'connection_timeout':
          $rootScope.api_status(
            "alert-danger",
            "La connexion avec votre compte Microsoft est expirée et n'a pu être réinitialisée, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
            "The connection with your Microsoft account has timed out and could not be reset, please try again or contact support@workland.com for assistance",
            "Session expirée!",
            "Expired session!",
            5000
          );
          break;
        case 'connection_fail':
          $rootScope.api_status(
            "alert-danger",
            "La connexion avec votre compte Microsoft a échoué, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
            "Login with your Microsoft account failed, please try again or contact support@workland.com for assistance",
            "La connexion a échouée!",
            "Connection failed!",
            5000
          );
          break;
        case 'interview_create_fail':
          $rootScope.api_status(
            "alert-danger",
            "An error occurred and the interview could not be created, please try again or contact support@workland.com for assistance",
            "Une erreur est survenue et l'entrevue n'a pu être crée, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
            "Attention!",
            "Attention!",
            5000
          );
          break;
      }
    }

    function resetInterviewType() {
      $scope.interviewFormModel.type_id = null;
    }

    function socialLogin() {
      storageService.setItem('connection_action', 'login');
      api.service_get('accounts', 'auth/social-login/microsoft').then(response => {
        if (response.data.status === 'success') {
          window.location = response.data.data.link;
        }
        else {
          errorHandler('connection_fail');
        }
      }).catch(err => {
        errorHandler('connection_fail');
      });
    }

    function socialLoginPopup(message) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: $scope.out('Attention', 'Attention'),
        content: message,
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          ok: {
            text: '<img src="./../assets/images/social_logos/ms-symbollockup_mssymbol_19.svg">&nbsp;&nbsp;&nbsp;'
                  + $scope.out("S'identifier avec Microsoft", "Sign in with Microsoft"),
            btnClass: 'btn interview-social-btn',
            action() {
              socialLogin();
            }
          },
          cancel: {
            text: $scope.out('Annuler', 'Cancel'),
            btnClass: 'btn interview-social-btn-cancel button-black',
            action() {
              resetInterviewType();
            }
          }
        }
      });
    }

    function interviewTypeChanged() {
      const regExp = /OnlineMeetings\.ReadWrite/g;
      if ($scope.interviewFormModel.type_id === 6 && (!$scope.hasMicrosoftToken || !regExp.test($scope.hasMicrosoftToken.scope))) {
        const message = $rootScope.currentUser.socialTokenError && $rootScope.currentUser.socialTokenError == 'fetching_microsoft_token_failed'
          ? $scope.out(
            "Un problème est survenu et nous n'avons pu vous identifier avec votre compte Microsoft, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide",
            "A problem occured and we couldn't identify you with your Microsoft account, please try again or contact support@workland.com for assistance"
          )
          : $scope.out(
            "Vous devez vous connecter avec un compte Microsoft professionnel ou scolaire pour créer une entrevue Microsoft Teams",
            "You must sign in with a business or school Microsoft account to create a Microsoft Teams interview"
          );
        socialLoginPopup(message);
      }

      if ($scope.interviewFormModel.type_id === 1) {
        initMap();
        $scope.showAddressField = true;
      } else {
        $scope.interviewFormModel.interview_location = '';
        $scope.interviewFormModel.location_id = null;
        $scope.showAddressField = false;
      }
    }

    function getRefreshSocialToken(provider) {
      const data = {
        refresh_token: $scope.hasMicrosoftToken.refresh_token,
        scope: $scope.hasMicrosoftToken.scope
      };
      api.service_post('accounts', `auth/social-login/${provider}/refresh`, data).then((response) => {
        const refreshResponse = response.data;
        if (refreshResponse.status === 'success' && refreshResponse.data) {
          const microsoftToken = _.pick(refreshResponse.data, 'access_token', 'exp', 'refresh_token', 'scope');
          if ($scope.hasMicrosoftToken.microsoft_organization_account_ids) {
            microsoftToken.microsoft_organization_account_ids = $scope.hasMicrosoftToken.microsoft_organization_account_ids;
          }
          storageService.setCookie('microsoftToken', JSON.stringify(microsoftToken));
          requestInterviewNew($scope.candidate);
        }
        else {
          errorHandler('connection_timeout');
        }
      }).catch(() => {
        errorHandler('connection_timeout');
      });
    }

    function calculMinTimeslotsToSelect() {
      const mandatoryAttendees = _.filter($scope.interviewFormModel.interview_attendees, attendee => attendee.is_mandatory);
      if (mandatoryAttendees.length) {
        const minimumToConfirm = $scope.interviewFormModel.attendees_either_or
          ? $scope.events.length
          : Math.ceil($scope.events.length / mandatoryAttendees.length);
          return minimumToConfirm;
      }
    }

    function checkall() {
      let socialTokenToRefresh = null;
      if ($scope.interviewFormModel.type_id === 6)  {
        const regExp = /OnlineMeetings\.ReadWrite/g;
        if (!$scope.hasMicrosoftToken || !regExp.test($scope.hasMicrosoftToken.scope)) {
          userWarning(utils.out(
            "Vous devez vous connecter avec un compte Microsoft professionnel ou scolaire pour créer une entrevue Microsoft Teams",
            "You must sign in with a business or school Microsoft account to create a Microsoft Teams interview")
          );
          return false;
        }
        if (+$scope.hasMicrosoftToken.exp < (new Date().getTime() / 1000) - 15) {
          socialTokenToRefresh = 'microsoft';
        }
      }

      if (!$scope.interviewFormModel.interview_attendees || !$scope.interviewFormModel.interview_attendees.length) {
        userWarning(utils.out(
          "Vous devez choisir au moins un participant",
          "You must choose at least one attendee"
        ));
        return false;
      }

      if ($scope.interviewFormModel.interview_attendees.length) {
        const hayMandatoryAttendee = _.findIndex($scope.interviewFormModel.interview_attendees, attendee => attendee.is_mandatory);
        if (hayMandatoryAttendee < 0) {
          userWarning(utils.out(
            "Vous devez sélectionner au moins un participant obligatoire",
            "You must select at least one mandatory attendee"
          ));
          return false;
        }
      }

      if (!$scope.interviewFormModel.interview_expired_at) {
        userWarning(utils.out('Date d\'expiration pour le candidat est obligatoire', 'Expiration date for the candidate is a mandatory field'));
        return false;
      }

      if (!$scope.interviewFormModel.interview_location && +$scope.interviewFormModel.type_id === 1) {
        userWarning(utils.out('L\'adresse est un champ obligatoire', 'Address is a mandatory field'));
        return false;
      }

      if (!$scope.events.length) {
        userWarning(utils.out('Veuillez choisir les plages horaire de l\'entrevue', 'Please choose interview timeslots'));
        return false;
      } else if ($scope.events.length < (1 * $scope.selectedCandidates.length)) {
        userWarning( utils.out('Veuillez choisir au moins une plage horaire par candidat', 'Please choose at least one timeslot per candidate'));
        return false;
      } else if ($scope.events.length > (4 * $scope.selectedCandidates.length)) {
        userWarning( utils.out('4 plages horaires maximum par candidat', '4 timeslots per candidate maximum'));
        return false;
      }

      if (!checkExpireDate($scope.interviewFormModel.interview_expired_at)) {
        return false;
      }

      if ($scope.interviewFormModel.attendee_expired_at) {
        if (!checkExpireDate($scope.interviewFormModel.attendee_expired_at)) {
          return false;
        }
      }

      if (!noExistMandatory(1)) {
        const minimumToConfirm = calculMinTimeslotsToSelect();
        if (minimumToConfirm && $scope.interviewFormModel.minimum_confirm < minimumToConfirm) {
          userWarning(utils.out(
            'Le nombre de plages horaires à confirmer doit être d\'au moins ' + minimumToConfirm,
            'The number of timeslots to be confirmed must be at least ' + minimumToConfirm
          ));
          return false;
        }
        if (!$scope.interviewFormModel.minimum_confirm && !$scope.interviewFormModel.send_flg) {
          userWarning(utils.out(
            'Veuillez entrer un nombre minimum de plages horaires à confirmer',
            'Please enter a minimum number of timeslots to be confirmed'
          ));
          return false;
        }
        if ($scope.interviewFormModel.minimum_confirm > $scope.events.length) {
          userWarning(utils.out(
            'Le nombre de plages horaires à confirmer ne doit pas dépasser ' + $scope.events.length,
            'The number of timeslots to be confirmed must not exceed ' + $scope.events.length
          ));
          return false;
        }
      }

      if (!checkExpireDate2()) {
        return false;
      }
      !socialTokenToRefresh ? requestInterviewNew($scope.candidate) : getRefreshSocialToken(socialTokenToRefresh);
    }

    function isExpired(interviewData) {
      const nowdate = new Date();
      const sDate = $filter('date')(nowdate, 'yyyy-MM-dd');
      if (sDate > interviewData) {
        return true;
      }
      return false;
    }

    function switchJob(job) {
      if (job) {
        $scope.jobId = job.id;
        $scope.selectedJob = true;
        getCandidateInterviews();
      }
    }

    function init() {
      $scope.userData = {
        name: '',
        token: '',
        account_id: '',
        status: '',
        email: '',
        check: false,
      };
      getRoles();
      fetchInterviewTypes();
      fetchAllStatuses();
      const microsoftToken = $cookies.get('microsoftToken');
      if (microsoftToken) $scope.hasMicrosoftToken = JSON.parse(microsoftToken);
      $scope.colorlist = angular.copy($scope.originalColorlist);
      if (storageService.getItem('sync_email_type') ) storageService.removeItem('sync_email_type');
    }

    init();

    $scope.$watch('candidate.user_id', () => {
      if (!$rootScope.currentUser.permissions.isDeptMgrRecruiter) {
        getSyncDetails();
      } else {
        $scope.showSyncEmail = false;
        getCandidateInterviews();
      }
      if ($scope.isCrmCandidates) {
        let defaultOptionAdded;
        if ($scope.selectedCandidates.length === 1 && $scope.candidate.jobList?.length > 0) {
          defaultOptionAdded = $scope.candidate.jobList.some((job) => job.id === null);
          if (!defaultOptionAdded) $scope.candidate.jobList.unshift($scope.defaultCrmSelectOption);
          if (!$scope.selectedJob) {
            $scope.crmJobCandidate.selected = $scope.candidate.jobList[1];
            $scope.jobId = $scope.candidate.jobList[1].id;
          }
        } else if ($scope.commonJobList) {
          defaultOptionAdded = $scope.commonJobList.some((job) => job.id === null);
          if (!defaultOptionAdded) $scope.commonJobList.unshift($scope.defaultCrmSelectOption);
          $scope.crmJobCandidate.selected = $scope.commonJobList[1];
          $scope.jobId = $scope.commonJobList[1].id;
        } else {
          // if no common list && no application case
        }
      }
    });

    scope = {
      enableNylas,
      scheduleInterview,
      cancel,
      addAttendee,
      removeAttendee,
      existsAttendee,
      resetInterviewForm,
      requestInterviewNew,
      noExistMandatory,
      initMap,
      checkExpireDate,
      checkExpireDate2,
      checkall,
      checkMandatory,
      fetchInterviewTypes,
      fetchAllStatuses,
      initializeCalender,
      eventClicked,
      eventEdited,
      eventDeleted,
      eventTimesChanged,
      toggle,
      timespanClicked,
      changeCalenderView,
      createNewTimeSlot,
      showTimeSlotModal,
      saveTimeslot,
      resendInvitation,
      showCancellationModal,
      cancelInterview,
      saveLocation,
      validateFormData,
      isExpired,
      switchJob,
      interviewTypeChanged,
    };
    angular.extend($scope, scope);
  }
  InterviewModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    '_',
    'api',
    'utils',
    '$filter',
    'worklandLocalize',
    '$uibModal',
    'moment',
    'calendarConfig',
    'storageService',
    '$ngConfirm',
    '$cookies',
    'statService',
    'userSyncStateService',
  ];
  angular.module('atlas')
    .directive('interviewModule', () => ({
      restrict: 'EA',
      scope: {
        candidate: '=',
        bulk: '=',
        selectedCandidates: '=',
        jobId: '@',
        commonJobList: '=?',
        isCrmCandidates: '=',
      },
      controller: InterviewModuleCtrl,
      templateUrl: './employer-profile/directives/interview-module/interview-module.template.html',
    }));
// eslint-disable-next-line no-undef
}(angular));
