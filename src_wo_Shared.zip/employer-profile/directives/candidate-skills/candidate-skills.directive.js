(function (angular) {
  function CandidateSkillsController(
    $scope,
    $rootScope,
    utils,
    api,
    storageService,
  ) {
    const scopeVariables = {
      out: utils.out,
      skillName: {},
      skillDesc: {},
      updated: {},
      candidate_skills: { translations: [] },
      creatingSkill: false,
    };
    angular.extend($scope, scopeVariables);

    function fetchSkills() {
      $scope.cand_skills = false;
      const promise = api.service_get('jobs', `skill/account/${$scope.current_user_account_id}/skills`);
      promise.then((response) => {
        if (response.status === 200) {
          $scope.cand_skills = response.data;
        } else {
          $scope.cand_skills = [];
          $rootScope.api_status('alert-danger', 'Failed to load skills', 'Échec du chargement de la compétence');
        }
      }).catch((error) => {
        $scope.cand_skills = [];
        if (error.status === 404) {
          $rootScope.api_status('alert-success', 'Create your first skill here', 'Créez votre première compétence ici');
        } else {
          $rootScope.api_status('alert-danger', 'Failed to load skills', 'Échec du chargement de la compétence');
        }        
      });
    }

    function addSkill() {
      if($scope.creatingSkill) {
        return;
      }

      $scope.hasFrError = !$scope.skillName.fr ? true : false;
      $scope.hasEnError = !$scope.skillName.en ? true : false;
      $scope.hasEnDescError = !$scope.skillDesc.en ? true : false;
      $scope.hasFrDescError = !$scope.skillDesc.fr ? true : false;
      if (!$scope.hasFrError && !$scope.hasEnError && !$scope.hasEnDescError && !$scope.hasFrDescError) {
        if(!$scope.creatingSkill) {
          $scope.creatingSkill = true;
        }
        $scope.candidate_skills.translations.push({
          locale: 'en',
          name: $scope.skillName.en,
          definition: $scope.skillDesc.en,
        });
        $scope.candidate_skills.translations.push({
          locale: 'fr',
          name: $scope.skillName.fr,
          definition: $scope.skillDesc.fr,
        });
        const waitMsgEn = 'Adding skill...';
        const waitMsgFr = 'Ajout de compétence en cours...';
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
        const promise = api.service_post('jobs', 'skill', $scope.candidate_skills);
        promise.then((response) => {
          if (response.status === 200 || response.status === 201) {
            const { data } = response;
            api.service_query('jobs', `skill/${data.id}/account/${$scope.current_user_account_id}`, 'PUT', {}).then((res) => {
              if (res.status === 200 || res.status === 201) {
                const msgEn = 'Skill has been added';
                const msgFr = 'La compétence a été ajoutée';
                $rootScope.api_status('alert-success', msgEn, msgFr);
                $scope.skillName = {};
                $scope.skillDesc = {};
                fetchSkills();
                $scope.creatingSkill = false;
              } else {
                $rootScope.api_status('alert-danger', 'Failed to add a skill', 'Échec de l\'ajout d\'une compétence');
                $scope.creatingSkill = false;
              }
            }).catch(() => {
              $rootScope.api_status('alert-danger', 'Failed to add a skill', 'Échec de l\'ajout d\'une compétence');
              $scope.creatingSkill = false;
            });
          } else {
            $scope.creatingSkill = false;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.creatingSkill = false;
        });
      }
    }

    function editModeOn(skills) {
      $scope.editMode = {};
      $scope.editMode.id = skills.id;
      $scope.updated.SkillName_en = skills.translations[0].name;
      $scope.updated.SkillName_fr = skills.translations[1].name;
      $scope.updated.SkillDesc_en = skills.translations[0].definition;
      $scope.updated.SkillDesc_fr = skills.translations[1].definition;     
    }

    function editModeOff() {
      $scope.updated = {};
      $scope.editMode = {};
    }

    function updateSkill(skillId) {

      $scope.updated.SkillName_enError = !$scope.updated.SkillName_en;
      $scope.updated.SkillName_frError = !$scope.updated.SkillName_fr;
      $scope.updated.SkillDesc_frError = !$scope.updated.SkillDesc_fr;
      $scope.updated.SkillDesc_enError = !$scope.updated.SkillDesc_en;
      if (!$scope.updated.SkillName_enError && !$scope.updated.SkillName_frError && !$scope.updated.SkillDesc_frError && !$scope.updated.SkillDesc_enError) {
        $scope.candidate_skills.translations.push({
          locale: 'en',
          name: $scope.updated.SkillName_en,
          definition: $scope.updated.SkillDesc_en,
        });
        $scope.candidate_skills.translations.push({
          locale: 'fr',
          name: $scope.updated.SkillName_fr,
          definition: $scope.updated.SkillDesc_fr,
        });
        const waitMsgEn = 'Updating skill...';
        const waitMsgFr = 'Mise à jour de la compétence en cours...';
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
        const promise = api.service_post('jobs', `skill/${skillId}`, $scope.candidate_skills, 'update');
        promise.then((response) => {
          if (response.status === 201 || response.status === 200) {
            editModeOff();
            fetchSkills();
            const msgEn = 'Skill has been updated';
            const msgFr = 'La compétence a été mise à jour';
            $rootScope.api_status('alert-success', msgEn, msgFr);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', 'Failed to update the skill', 'Échec de la mise à jour de la compétence');
        });
      }
    }

    function deleteSkill(id) {
      const waitMsgEn = 'Deleting skill...';
      const waitMsgFr = 'Suppression de compétence en cours...';
      $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
      const promise = api.service_delete('jobs', `skill/${id}`);
      promise.then((response) => {
        if (response.status === 200) {
          fetchSkills();
          const msgEn = 'Skill has been deleted';
          const msgFr = 'La compétence a été supprimée';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'Failed to delete the skill', 'Échec de la suppression de la compétence');
      });
    }

    function init() {
      $scope.current_user_account_id = JSON.parse(storageService.getItem('account_id'));
      fetchSkills();
    }

    init();

    const scopeMethods = {
      addSkill,
      fetchSkills,
      editModeOn,
      editModeOff,
      updateSkill,
      deleteSkill,
    };
    angular.extend($scope, scopeMethods);
  }

  CandidateSkillsController.$inject = ['$scope',
    '$rootScope',
    'utils',
    'api',
    'storageService',
  ];

  angular.module('atlas').controller('CandidateSkillsController', CandidateSkillsController);
}(angular));
