(function (angular) {
  function statisticsCostsCtrl() {

  }
  statisticsCostsCtrl.$inject = [];
  angular.module('atlas').directive('statisticsCosts', () => ({
    scope: {},
    controller: statisticsCostsCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-costs/statistics-costs.template.html',
  }));
}(angular));
