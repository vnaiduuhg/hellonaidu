(function (angular) {
  function hiringSummarySourceJobCtrl($scope, utils, $rootScope, Event, statService) {
    // initialize scope variables here
    const date = new Date();
    const scope = {
      out: utils.out,
      barLabel: utils.out('Nombre de candidats embauchés', 'Number of hires'),
      barLabel1: utils.out('Nombre d\'applicants', 'Number of applicants'),
      labels: [],
      NumberOfApplied: [],
      NumberOfHired: [],
      userJobs: [],
      reportName: utils.out('Statistiques par source et poste', 'Statistics by source and job'),
      hiringSummaryReportLoaded: false,
      jobSelected: { selected: '' },
      language: $rootScope.language,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      jobsLoadingDone: false,
      promiseSuccess: false,
    };
    angular.extend($scope, scope);

    function loadhiringSummaryReportByJob(job) {
      $scope.hiringSummaryReportLoaded = false;
      $scope.NumberOfApplied = [];
      $scope.NumberOfHired = [];
      $scope.labels = [];
      angular.forEach($scope.hiringSummaryReportData, (jobReport) => {
        if (job.id === jobReport.job_id) {
          $scope.hiringSummaryReportLoaded = true;
          $scope.NumberOfApplied.push(jobReport.NumberOfApplied);
          $scope.NumberOfHired.push(jobReport.NumberOfHired);
          $scope.labels.push(jobReport.source_name);
        }
      });
    }

    Event.on('companySelected', ($event, company) => {
      postReports(company);
    });

    function postReports(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.jobsLoadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_source_job', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job', null, null, dates);
      }
      promise.then((response) => {
        $scope.jobsLoadingDone = true;
        if (response.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.hiringSummaryReportData = response.data.data.result;
          let counter = 0;
          angular.forEach($scope.hiringSummaryReportData, (jobReport) => {
            const job = {};
            job.id = jobReport.job_id;
            job.titleEn = jobReport.job_title_en;             
            job.titleFr = jobReport.job_title_fr;
            
            $scope.userJobs.push(job);
            counter++;
          });
          if (counter > 0) {
            $scope.jobSelected.selected = $scope.userJobs[0];
            loadhiringSummaryReportByJob($scope.userJobs[0]);
          }          
        } else {
          $scope.hiringSummaryReportData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
      }).catch(() => {
        $scope.jobsLoadingDone = true;
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com'); // function used to show status of request: waiting, success, error
      });
    }

    function init() {
      $scope.jobSelected.selected = '';
      $scope.userJobs = [];
      $scope.hiringSummaryReportLoaded = false;
      postReports();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    // add methods that will be called from template by user
    const scopeMethods = {
      loadhiringSummaryReportByJob,
    };
    angular.extend($scope, scopeMethods);
  }
  hiringSummarySourceJobCtrl.$inject = ['$scope', 'utils', '$rootScope', 'Event', 'statService'];
  angular.module('atlas')
    .directive('hiringSummarySourceJob', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: hiringSummarySourceJobCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-candidates/hiring-summary-source-job/hiring-summary-source-job.template.html',
    }));
}(angular));
