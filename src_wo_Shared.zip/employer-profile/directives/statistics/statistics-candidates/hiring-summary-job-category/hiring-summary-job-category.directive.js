(function (angular) {
  function hiringSummaryJobCategoryCtrl(
    $scope,
    $rootScope,
    utils,
    Event,
    statService
  ) {
    const date = new Date();
    const scope = {
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      categorySelected: { selected: '' },
      out: utils.out,
      labels: [utils.out('Candidats', 'Applied'), utils.out('Embauches', 'Hired')],
      barLabel: utils.out('Nombre de candidats', 'Number of applicants'),
      candidates: [],
      averageHiringTime: 0,
      categories: [],
      reportName: utils.out('Statistiques par catégorie d\'emploi', 'Statistics by job category'),
      reportLabel: 'hiring_summary_job_category',
      hiringSummaryJobCategoryReportLoaded: false,
      categoriesLoadingDone: false,
      promiseSuccess: false,
      hiringSummaryJobCategoryReport: [],
    };

    angular.extend($scope, scope);

    function fetchHiringSummaryJobCategoryReportByCategory(category) {
      $scope.hiringSummaryJobCategoryReportLoaded = false;
      $scope.candidates = [];
      angular.forEach($scope.hiringSummaryJobCategoryReport, (report) => {
        if (category.id === report.category_id) {
          $scope.hiringSummaryJobCategoryReportLoaded = true;
          $scope.candidates.push(report.NumberOfApplication);
          $scope.candidates.push(report.NumberOfHired);
          $scope.averageHiringTime = report.averHiringTimeInDays != null ? report.averHiringTimeInDays + utils.out(' jour(s)', ' day(s)') : utils.out('aucune embauche', 'no one hired');
        }
      });
    }

    Event.on('companySelected', ($event, company) => {
      fetchHiringSummaryJobCategoryReport(company);
    });

    function fetchHiringSummaryJobCategoryReport(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.categoriesLoadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_job_category', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_job_category', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_job_category', null, null, dates);
      }
      promise.then((res) => {
        if (res.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.hiringSummaryJobCategoryReport = res.data.data.result;
          let counter = 0;
          angular.forEach($scope.hiringSummaryJobCategoryReport, (jobReport) => {
            const category = {
              id: jobReport.category_id,
              titleEn: jobReport.category_name_en ? jobReport.category_name_en : 'None',
              titleFr: jobReport.category_name_fr ? jobReport.category_name_fr : 'Aucune',
            };
            $scope.categories.push(category);
            counter++;
          });
          if (counter > 0) {
            $scope.categorySelected.selected = $scope.categories[0];
            fetchHiringSummaryJobCategoryReportByCategory($scope.categories[0]);
          }
        } else {
          $scope.hiringSummaryJobCategoryReport = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
        $scope.categoriesLoadingDone = true;
      }).catch(() => {
        $scope.categoriesLoadingDone = true;
        $scope.hiringSummaryJobCategoryReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      $scope.categories = [];
      $scope.categorySelected.selected = '';
      $scope.categoriesLoadingDone = false;
      $scope.hiringSummaryJobCategoryReportLoaded = false;
      fetchHiringSummaryJobCategoryReport();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    const scopeMethods = {
      fetchHiringSummaryJobCategoryReportByCategory,
    };
    angular.extend($scope, scopeMethods);
  }

  hiringSummaryJobCategoryCtrl.$inject = ['$scope', '$rootScope', 'utils', 'Event', 'statService'];
  angular.module('atlas')
    .directive('hiringSummaryJobCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: hiringSummaryJobCategoryCtrl,
      templateUrl:
            './employer-profile/directives/statistics/statistics-candidates/hiring-summary-job-category/hiring-summary-job-category.template.html',
    }));
}(angular));
