(function (angular) {
  function hiringSummaryCtrl(
    $scope,
    $rootScope,
    utils,
    Event,
    statService,
  ) {
    const date = new Date();
    const scope = {
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      jobSelected: { selected: '' },
      out: utils.out,
      labels: [utils.out('Candidats', 'Applied'), utils.out('Embauches', 'Hired')],
      barLabel: utils.out('Nombre de candidats', 'Number of candidates'),
      candidates: [],
      averageHiringTime: 0,
      userJobs: [],
      reportName: utils.out('Statistiques du poste', 'Statistics by job'),
      reportLabel: 'hiring_summary',
      hiringSummaryReportLoaded: false,
      jobsLoadingDone: false,
      language: $rootScope.language,
      promiseSuccess: false,
      hiringSummaryReport: [],
    };

    angular.extend($scope, scope);

    function fetchHiringSummaryReportByJob(job) {
      $scope.hiringSummaryReportLoaded = false;
      $scope.candidates = [];
      angular.forEach($scope.hiringSummaryReport, (report) => {
        if (job.id === report.job_id) {
          $scope.hiringSummaryReportLoaded = true;
          $scope.candidates.push(report.NumberOfApplication);
          $scope.candidates.push(report.NumberOfHired);
          $scope.averageHiringTime = report.averHiringTimeInDays != null ? report.averHiringTimeInDays + utils.out(' jour(s)', ' day(s)') : utils.out('aucune embauche', 'no one hired');
        }
      });
    }

    Event.on('companySelected', ($event, company) => {
      fetchHiringSummaryReport(company);
    });

    function fetchHiringSummaryReport(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      }
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary', null, null, dates);
      }
      promise.then((res) => {
        if (res.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.hiringSummaryReport = res.data.data.result;
          let counter = 0;
          angular.forEach($scope.hiringSummaryReport, (jobReport) => {
            const job = { id: jobReport.job_id, titleEn: jobReport.job_title_en, titleFr: jobReport.job_title_fr };
            $scope.userJobs.push(job);
            counter++;
          });
          if (counter > 0) {
            $scope.jobSelected.selected = $scope.userJobs[0];
            fetchHiringSummaryReportByJob($scope.userJobs[0]);
          }
        } else {
          $scope.hiringSummaryReport = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
        $scope.jobsLoadingDone = true;
      }).catch(() => {
        $scope.jobsLoadingDone = true;
        $scope.hiringSummaryReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      $scope.userJobs = [];
      $scope.jobSelected.selected = '';
      $scope.jobsLoadingDone = false;
      $scope.hiringSummaryReportLoaded = false;
      fetchHiringSummaryReport();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    const scopeMethods = {
      fetchHiringSummaryReportByJob,
    };
    angular.extend($scope, scopeMethods);
  }
  hiringSummaryCtrl.$inject = ['$scope', '$rootScope', 'utils', 'Event', 'statService'];

  angular.module('atlas').directive('hiringSummary', () => ({
    scope: {
      currentUserAccountId: '=',
      companies: '=',
      isAgency: '=',
      isAgencyAdminRecruiter: '=',
      isConfidentiel: '=',
      validateDates: '=',
    },
    controller: hiringSummaryCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-candidates/hiring-summary/hiring-summary.template.html',
  }));
}(angular));
