(function (angular) {
  function statisticsRejectionCandidatesCtrl($scope, utils, $rootScope, Event, statService) {
    // initialize scope variables here
    const date = new Date();
    const scope = {
      out: utils.out,
      barLabel: utils.out('Nombre de candidats rejetés', 'Number of rejected candidates'),
      labels: [],
      numberOfCandidates: [],
      userJobs: [],
      reportName: utils.out('Sommaire par poste', 'Statistics by job'),
      rejectionSummaryReportLoaded: false,
      jobSelected: { selected: '' },
      language: $rootScope.language,
      jobsLoadingDone: false,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(), // today
      promiseSuccess: false,
    };
    angular.extend($scope, scope);

    function loadRejectionSummaryReportByJob(job) {
      $scope.numberOfCandidates = [];
      $scope.labels = [];
      $scope.rejectionSummaryReportLoaded = false;
      angular.forEach($scope.rejectionSummaryReportData, (jobReport) => {
        if (job.id === jobReport.job_id) {
          $scope.rejectionSummaryReportLoaded = true;
          $scope.numberOfCandidates.push(jobReport.num_of_reject);
          $scope.labels.push(utils.out(jobReport.qualification_type_fr, jobReport.qualification_type_en));
        }
      });
    }

    Event.on('companySelected', ($event, company) => {
      postReports(company);
    });

    function postReports(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      }
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|rejection_summary', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'rejection_summary', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'rejection_summary', null, null, dates);
      }
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.rejectionSummaryReportData = response.data.data.result;
          let counter = 0;
          angular.forEach($scope.rejectionSummaryReportData, (jobReport) => {
            const job = { id: jobReport.job_id, titleEn: jobReport.job_title_en, titleFr: jobReport.job_title_fr };
            $scope.userJobs.push(job);
            counter++;
          });
          if (counter > 0) {
            $scope.jobSelected.selected = $scope.userJobs[0];
            loadRejectionSummaryReportByJob($scope.userJobs[0]);
          }
          $scope.jobsLoadingDone = true;
        } else {
          $scope.jobsLoadingDone = true;
          $scope.rejectionSummaryReportData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
      }).catch(() => {
        $scope.jobsLoadingDone = true;
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com'); // function used to show status of request: waiting, success, error
      });
    }

    function init() {
      $scope.jobSelected.selected = '';
      $scope.userJobs = [];
      $scope.rejectionSummaryReportLoaded = false;
      postReports();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    // add methods that will be called from template by user
    const scopeMethods = {
      loadRejectionSummaryReportByJob,
    };
    angular.extend($scope, scopeMethods);
  }
  statisticsRejectionCandidatesCtrl.$inject = ['$scope', 'utils', '$rootScope', 'Event', 'statService'];
  angular.module('atlas')
    .directive('statisticsRejectionCandidates', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: statisticsRejectionCandidatesCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-candidates/rejection-candidates/statistics-rejection-candidates.template.html',
    }));
}(angular));
