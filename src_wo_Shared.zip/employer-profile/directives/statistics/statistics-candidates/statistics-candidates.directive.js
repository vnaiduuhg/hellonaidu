(function (angular) {
  function statisticsCandidatesCtrl(
    $scope,
    utils,
  ) {
    // initialize scope variables here
    const scope = {
      out: utils.out, // to translate variables to French/English
    };
    angular.extend($scope, scope);

    // add methods that will be called from template by user
    const scopeMethods = {};
    angular.extend($scope, scopeMethods);
  }

  statisticsCandidatesCtrl.$inject = ['$scope', 'utils'];
  angular.module('atlas')
    .directive('statisticsCandidates', () => ({
      scope: {
        newAppliantsStat: '=',
        currentUserAccountId: '=',
        companies: '=',
        isAgencyAdminRecruiter: '=',
        isAgency: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: statisticsCandidatesCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-candidates/statistics-candidates.template.html',
    }));
}(angular));
