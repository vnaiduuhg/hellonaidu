(function (angular) {
  function statisticsOverviewAppliantsCtrl($scope, utils, _) {
    const scope = {
      toDateStr: utils.toDateStr,
      out: utils.out,
      isNumber: angular.isNumber,
      dates: {},
      statPeriods: {
        day: {
          en: 'today',
          fr: 'aujourd\'hui',
        },
        week: {
          en: 'week',
          fr: 'semaine',
        },
        month: {
          en: 'month',
          fr: 'mois',
        },
        year: {
          en: 'year',
          fr: 'année',
        },
      },
      activePeriod: 'week',
      StatisticsOverviewFormModel: {},
      statCandidatesOverviewReady: false,
    };
    angular.extend($scope, scope);

    function setPeriodDates() {
      const date = new Date();
      const tempDateWeek = angular.copy(date).setDate(date.getDate() - 7);
      const tempDateMonth = angular.copy(date).setMonth(date.getMonth() - 1);
      const tempDateYear = angular.copy(date).setFullYear(date.getFullYear() - 1);
      $scope.dates = {
        today: utils.getTimeFormat(date, 'LL'),
        oneWeekAgo: utils.getTimeFormat(tempDateWeek, 'LL'),
        oneMonthAgo: utils.getTimeFormat(tempDateMonth, 'LL'),
        oneYearAgo: utils.getTimeFormat(tempDateYear, 'LL'),
      };
    }

    function init() {
      setPeriodDates();
      $scope.statCandidatesOverviewReady = true;
    }

    init();

    function getNextSlide(currentPeriod, action) {
      switch (currentPeriod) {
        case 'day':
          $scope.activePeriod = action != 'next' ? 'year' : 'week';
          break;
        case 'week':
          $scope.activePeriod = action != 'next' ? 'day' : 'month';
          break;
        case 'month':
          $scope.activePeriod = action != 'next' ? 'week' : 'year';
          break;
        case 'year':
          $scope.activePeriod = action != 'next' ? 'month' : 'day';
          break;
      }
    }

    function getCurrentSlide(currentPeriod) {
      $scope.activePeriod = currentPeriod;
    }

    const scopeMethods = {
      getNextSlide,
      getCurrentSlide,
      setPeriodDates,
    };
    angular.extend($scope, scopeMethods);
  }

  statisticsOverviewAppliantsCtrl.$inject = ['$scope', 'utils', '_'];

  angular.module('atlas')
    .directive('statisticsOverviewAppliants', () => ({
      scope: {
        newAppliantsStat: '=',
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
      },
      controller: statisticsOverviewAppliantsCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-candidates/statistics-overview-appliants/statistics-overview-appliants.template.html',
    }));
}(angular));
