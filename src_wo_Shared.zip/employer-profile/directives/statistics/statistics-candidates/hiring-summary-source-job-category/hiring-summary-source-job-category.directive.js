(function (angular) {
  function hiringSummarySourceJobCategoryCtrl($scope, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      out: utils.out,
      appliedLabel: utils.out('Nombre d\'applicants', 'Number of applicants'),
      hiredLabel: utils.out('Nombre de candidats embauchés', 'Number of hires'),
      labels: [],
      numberOfAppliedCandidates: [],
      userCategories: [],
      numberOfHiredCandidates: [],
      reportLoaded: false,
      categorySelected: { selected: '' },
      language: $rootScope.language,
      categoriesLoadingDone: false,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(), // today
      reportName: utils.out('Statistiques par source et catégorie d\'emploi', 'Statistics by source and job category'),
      promiseSuccess: false,
    };
    angular.extend($scope, scope);

    function loadHiringSummaryByJobCategory(category) {
      $scope.reportLoaded = false;
      $scope.numberOfAppliedCandidates = [];
      $scope.numberOfHiredCandidates = [];
      $scope.labels = [];
      angular.forEach($scope.hiringSummarySourceJobCategoryReport, (jobCategory) => {
        if (category.id === jobCategory.category_id) {
          $scope.reportLoaded = true;
          $scope.numberOfAppliedCandidates.push(jobCategory.Applied_Candidates);
          $scope.numberOfHiredCandidates.push(jobCategory.hired_candidates);
          $scope.labels.push(jobCategory.source_name);
        }
      });
    }

    Event.on('companySelected', ($event, company) => {
      loadHiringSummaryJobCategory(company);
    });

    function loadHiringSummaryJobCategory(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.categoriesLoadingDone = false;;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_source_job_category', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job_category', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job_category', null, null, dates);
      }
      promise.then((response) => {
        $scope.categoriesLoadingDone = true;
        if (response.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.hiringSummarySourceJobCategoryReport = response.data.data.result;
          let counter = 0;
          angular.forEach($scope.hiringSummarySourceJobCategoryReport, (jobCategory) => {
            const category = {};
            category.id = jobCategory.category_id;
            category.titleEn = jobCategory.category_name_en !== null ? jobCategory.category_name_en : 'None';
            category.titleFr = jobCategory.category_name_fr !== null ? jobCategory.category_name_fr : 'Aucune';
            $scope.userCategories.push(category);
            counter++;
          });
          if (counter > 0) {
            $scope.categorySelected.selected = $scope.userCategories[0];
            loadHiringSummaryByJobCategory($scope.userCategories[0]);
          }          
        } else {
          $scope.hiringSummarySourceJobCategoryReport = [];          
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
      }).catch(() => {
        $scope.categoriesLoadingDone = true;
        $scope.hiringSummarySourceJobCategoryReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }
    function init() {
      $scope.categorySelected.selected = '';
      $scope.userCategories = [];
      $scope.reportLoaded = false;
      loadHiringSummaryJobCategory();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    const scopeMethods = {
      loadHiringSummaryByJobCategory,
    };
    angular.extend($scope, scopeMethods);
  }
  hiringSummarySourceJobCategoryCtrl.$inject = ['$scope', 'utils', '$rootScope', 'Event', 'statService'];

  angular.module('atlas')
    .directive('hiringSummarySourceJobCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: hiringSummarySourceJobCategoryCtrl,
      templateUrl:
                './employer-profile/directives/statistics/statistics-candidates/hiring-summary-source-job-category/hiring-summary-source-job-category.template.html',
    }));
}(angular));
