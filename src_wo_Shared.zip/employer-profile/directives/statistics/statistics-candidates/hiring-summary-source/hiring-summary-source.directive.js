(function (angular) {
  function hiringSummarySourceCtrl($scope, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      out: utils.out,
      appliedBarLabel: utils.out('Nombre d\'applicants', 'Number of applicants'),
      hiredBarLabel: utils.out('Nombre de candidats embauchés', 'Number of hires'),
      labels: [],
      appliedCandidates: [],
      hiredCandidates: [],
      responseLoaded: false,
      language: $rootScope.language,
      getCandidatesJobSource,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      reportName: utils.out('Statistiques par source de candidats', 'Statistics by source'),
      promiseSuccess: false,
      hiringSummmarySourceData: [],
    };
    angular.extend($scope, scope);

    Event.on('companySelected', ($event, company) => {
      getCandidatesJobSource(company);
    });

    function getCandidatesJobSource(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.responseLoaded = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_source', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source', null, null, dates);
      }
      promise.then((response) => {
        $scope.responseLoaded = true;        
        if (response.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.hiringSummmarySourceData = response.data.data.result;          
          angular.forEach($scope.hiringSummmarySourceData, (el) => {
            $scope.appliedCandidates.push(el.NumberOfApplication);
            $scope.hiredCandidates.push(el.NumberOfHired);
            $scope.labels.push(el.source_name);
          });
        } else {          
          $scope.hiringSummmarySourceData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
      }).catch(() => {
        $scope.responseLoaded = true;
        $scope.hiringSummmarySourceData = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      $scope.appliedCandidates = [];
      $scope.hiredCandidates = [];
      $scope.labels = [];
      $scope.responseLoaded = false;
      getCandidatesJobSource();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });
  }
  hiringSummarySourceCtrl.$inject = ['$scope', 'utils', '$rootScope', 'Event', 'statService'];
  angular.module('atlas')
    .directive('hiringSummarySource', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: hiringSummarySourceCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-candidates/hiring-summary-source/hiring-summary-source.template.html',
    }));
}(angular));
