(function (angular) {
  function statisticsJobsCtrl($scope, utils) {
    // initialize scope variables here
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);

    // add methods that will be called from template by user
    const scopeMethods = {

    };
    angular.extend($scope, scopeMethods);
  }

  statisticsJobsCtrl.$inject = ['$scope', 'utils'];
  angular.module('atlas').directive('statisticsJobs', () => ({
    scope: {
      filledJobsStat: '=',
      currentUserAccountId: '=',
      companies: '=',
      isAgencyAdminRecruiter: '=',
      isAgency: '=',
      isConfidentiel: '=',
    },
    controller: statisticsJobsCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-jobs/statistics-jobs.template.html',
  }));
}(angular));
