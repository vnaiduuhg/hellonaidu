(function (angular) {
  function filledJobsCtrl($scope, utils) {
    const scope = {
      toDateStr: utils.toDateStr,
      out: utils.out,
      isNumber: angular.isNumber,
      dates: {},
      statPeriods: {
        day: {
          en: 'today',
          fr: 'aujourd\'hui',
        },
        week: {
          en: 'week',
          fr: 'semaine',
        },
        month: {
          en: 'month',
          fr: 'mois',
        },
        year: {
          en: 'year',
          fr: 'année',
        },
      },
      activePeriod: 'week',
      statJobFilledDataReady: false,
      FilledJobsOverviewFormModel: {},
    };
    angular.extend($scope, scope);

    function setPeriodDates() {
      const date = new Date();
      const tempDateWeek = angular.copy(date).setDate(date.getDate() - 7);
      const tempDateMonth = angular.copy(date).setMonth(date.getMonth() - 1);
      const tempDateYear = angular.copy(date).setFullYear(date.getFullYear() - 1);
      $scope.dates = {
        today: utils.getTimeFormat(date, 'LL'),
        oneWeekAgo: utils.getTimeFormat(tempDateWeek, 'LL'),
        oneMonthAgo: utils.getTimeFormat(tempDateMonth, 'LL'),
        oneYearAgo: utils.getTimeFormat(tempDateYear, 'LL'),
      };
    }

    function init() {
      setPeriodDates();
      $scope.statJobFilledDataReady = true;
    }

    init();

    function getNextSlide(currentPeriod, action) {
      switch (currentPeriod) {
        case 'day':
          $scope.activePeriod = action != 'next' ? 'year' : 'week';
          break;
        case 'week':
          $scope.activePeriod = action != 'next' ? 'day' : 'month';
          break;
        case 'month':
          $scope.activePeriod = action != 'next' ? 'week' : 'year';
          break;
        case 'year':
          $scope.activePeriod = action != 'next' ? 'month' : 'day';
          break;
      }
    }

    function getCurrentSlide(currentPeriod) {
      $scope.activePeriod = currentPeriod;
    }

    const scopeMethods = {
      getNextSlide,
      getCurrentSlide,
      setPeriodDates,
    };
    angular.extend($scope, scopeMethods);
  }

  filledJobsCtrl.$inject = ['$scope', 'utils'];
  angular.module('atlas').directive('filledJobs', () => ({
    scope: {
      filledJobsStat: '=',
      currentUserAccountId: '=',
      companies: '=',
      isAgency: '=',
      isAgencyAdminRecruiter: '=',
      isConfidentiel: '=',
    },
    controller: filledJobsCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-jobs/filled-jobs/filled-jobs.template.html',
  }));
}(angular));
