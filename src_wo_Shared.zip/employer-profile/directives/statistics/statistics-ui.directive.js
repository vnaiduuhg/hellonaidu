(function (angular) {
  function StatisticsCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    $sce,
    worklandLocalize,
    $q,
    api,
    storageService,
    Event,
    statService,
  ) {
    const scope = {
      strings: worklandLocalize.strings,
      out: utils.out,
      trustAsHtml,
      currentTab: {},
      currentSubTab: {},
      currentUser: $rootScope.currentUser,
      currentUserAccountId: storageService.getItem('account_id'),
      currentUserRoleId: JSON.parse(storageService.getItem('account_role')),
      sideTabs: [
        {
          nameEn: 'Dashboard',
          nameFr: 'Tableau de bord',
          icon: 'fa-dashboard',
          type: 'statistics-dash',
        },
        {
          nameEn: 'Reports',
          nameFr: 'Rapports',
          icon: 'fa-file-text',
          type: 'reports',
          subTabs: [
            { nameEn: 'Workflow', nameFr: 'Flux de travail', type: 'workflowReport' },
            { nameEn: 'Hiring summary', nameFr: 'Sommaire d\'embauche', type: 'hiringReport' },
            { nameEn: 'Jobs report', nameFr: 'Rapport de postes', type: 'jobsReport' },
            { nameEn: 'Exclusion report', nameFr: 'Rapport d\'exclusion', type: 'rejectionReport' },
            { nameEn: 'Candidates summary', nameFr: 'Sommaire de candidats', type: 'candidatesReport' },
          ],
        },
        {
          nameEn: 'Candidates',
          nameFr: 'Candidats',
          icon: 'fa-users',
          type: 'candidates',
        },
        {
          nameEn: 'Workflow',
          nameFr: 'Flux de travail',
          icon: 'fa-cogs',
          type: 'workflow',
        },
        {
          nameEn: 'Jobs',
          nameFr: 'Emplois',
          icon: 'fa-briefcase',
          type: 'jobs',
        },
        // {
        //     nameEn: 'Return on investment',
        //     nameFr: 'Retour sur investissement',
        //     icon: 'fa-usd',
        //     type: 'costs'
        // }
      ],
      translations: {
        new_candidates: {
          en: 'new candidates',
          fr: 'nouveaux candidats',
        },
        filled_jobs: {
          en: 'filled jobs',
          fr: 'postes comblés',
        },
      },
      statDataReady: false,
      newAppliantsStat: {},
      openTab,
      companies: [],
      isAgencyAdminRecruiter: !!((storageService.getItem('account_role') === '30' && storageService.getItem('account_type') === 'agency')),
      isAgency: !!((storageService.getItem('account_role') === '100' && storageService.getItem('account_type') === 'agency')),
      isConfidentiel: $rootScope.currentUser.user.id === 642,
      defaultCompanySelectOption: {
        id: null,
        company_name: utils.out('Agence et toutes les entreprises', 'Agency and all companies'),
      },
    };
    angular.extend($scope, scope);

    function fetchCompaniesAccounts() {
      let url = '';
      if ($scope.isConfidentiel) {
        url = 'workland/all-company-names';
      }
      if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        url = 'agency-reports/client-company-names';
      }
      api.service_get('reporting', url).then((response) => {
        if (response.data.status === 'success') {
          $scope.companies = response.data.data.result;
          $scope.companies.unshift($scope.defaultCompanySelectOption);
        } else {
          $scope.companies = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching the list of companies', 'Désolé, une erreur s\'est produite lors de la récupération de la liste des entreprises.');
        }
        const loggedInCompany = {
          id: +storageService.getItem('account_id'),
          company_name: $rootScope.currentUser.profile_page[0].name
        }
        $scope.companies.push(loggedInCompany);
      }).catch(() => {
        $scope.companies = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching the list of companies. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite lors de la récupération de la liste des entreprises. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      $scope.hasAccessToExtractionData = !![30, 50, 60, 100].includes($scope.currentUserRoleId);
      if ($scope.hasAccessToExtractionData || $scope.currentUser.permissions.isRegularRecruiter || $scope.currentUser.permissions.isDeptMgrRecruiter) {
        $scope.sideTabs[1].subTabs.push(
          { nameEn: 'Interviews report', nameFr: 'Rapport d\'entrevues', type: 'interviewsReport' },
        );
        if (!$scope.currentUser.permissions.isDeptMgrRecruiter) {
          $scope.sideTabs[1].subTabs.push(
            { nameEn: 'Leads report', nameFr: 'Rapport sur les potentiels', type: 'leadsReport'},
            { nameEn: 'Internal candidates seniority', nameFr: 'L\'ancienneté de candidats internes', type: 'internalCandidatesReport' },
          );
        }
      }
      if ($scope.hasAccessToExtractionData && $scope.isAgency) {
        $scope.sideTabs[1].subTabs.push(
          { nameEn: 'Clients summary', nameFr: 'Sommaire de clients', type: 'clientsReport' },
        );
      }
      $scope.currentTab.active = $scope.sideTabs[0].type;
      if ($scope.currentTab.active === 'reports') {
        openTab($scope.sideTabs[1], $scope.sideTabs[1].subTabs[0]);
      }

      loadJobsApplicantsStat();

      if ($scope.isConfidentiel || $scope.isAgency || $scope.isAgencyAdminRecruiter) {
        fetchCompaniesAccounts();
      }
    }

    function openTab(tab, subTab) {
      $scope.currentTab.active = tab.type;
      $scope.currentSubTab.active = '';
      if (subTab) {
        $scope.currentSubTab.active = subTab.type;
      } else if (tab.subTabs) {
        $scope.currentSubTab.active = tab.subTabs[0].type;
      }
    }

    $scope.openTabWithAnimation = function($event, tab, subTab) {
      $event.preventDefault();

      openTab(tab, subTab);

      if (!subTab) {
        design.sidebar.openDropdown($event.currentTarget);
      }
    }

    function loadJobsApplicantsStat(company=null) {
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      const promises = [];
      promises.push(
        getReport('newAppliantsStat', 'new_candidates', 'NewApplication', company),
        getReport('filledJobsStat', 'filled_jobs', 'NumOfJobFilled', company),
      );
      $q.all(promises).then(() => {
        $scope.statDataReady = true;
        return $scope.reportPromise = promises;
      });
    }

    init();
    design.sidebar.ngInit('statistics');

    Event.on('companySelected', ($event, company) => {
      loadJobsApplicantsStat(company);
    });

    function getReport(scope_key, report_key, data_key, company=null) {
      const defer = $q.defer();
      let promise;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', `admin|workland|${report_key}`, 'company_account_id', company);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', report_key, 'client_account_id', company);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', report_key);
      }
      promise.then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          if (res.data.result.length) {
            $scope[scope_key] = prepareReportData(res.data.result, data_key);
          } else {
            $scope.statDataReady = true;
            $rootScope.api_status(
              'alert-danger',
              `There are no statistics available for ${$scope.translations[report_key].en}`,
              `Il n'y a pas de statistiques disponibles pour les ${$scope.translations[report_key].fr}`,
            );
          }
        } else {
          $scope.statDataReady = true;
          $rootScope.api_status(
            'alert-danger',
            `An error has occurred and statistics for ${$scope.translations[report_key].en} could not be retrieved`,
            `Une erreur s'est produite et les statistiques des ${$scope.translations[report_key].fr} n'ont pas pu être récupérées`,
          );
        }
        defer.resolve();
      }).catch(() => {
        $scope.statDataReady = true;
        defer.resolve();
        $rootScope.api_status(
          'alert-danger',
          `An error has occurred and statistics for${$scope.translations[report_key].en}could not be retrieved`,
          `Une erreur s'est produite et les statistiques des ${$scope.translations[report_key].fr} n'ont pas pu être récupérées`,
        );
      });
      return defer.promise;
    }

    function prepareReportData(data, key) {
      const _dataObj = {};
      _.each(data, (item) => {
        switch (item.TimePeriod) {
          case 'Today':
            _dataObj.today = item[key];
            break;
          case 'This week':
            _dataObj.thisWeek = item[key];
            break;
          case 'This month':
            _dataObj.thisMonth = item[key];
            break;
          case 'This year':
            _dataObj.thisYear = item[key];
            break;
        }
      });
      return _dataObj;
    }

    function getExtractionDataReport(selectedReport, startDate = null, endDate = null, jobIds = null, tagIds = null, recruiterIds = null, groupIds = null, categoryIds = null, functionIds = null ) {
      $rootScope.api_status('waiting', 'Extracting data', 'Extraction des données en cours');
      let promise;
      let params = {};
      params.locale = $rootScope.language;
      let data = {};
      data.locale = $rootScope.language;
      switch (selectedReport) {
        case 'candidates-account-info':
        case 'clients-account-info':
          params.start_date = startDate;
          params.end_date = endDate;
          promise = api.service_get('reporting', `agency-reports/${selectedReport}`, params);
          break;
        case 'company-candidate-accounts':
          params.start_date = startDate;
          params.end_date = endDate;
          params.job_ids = jobIds;
          promise = api.service_post('reporting', `company-reports/${selectedReport}`, params);
          break;
        case 'internal-candidates':
          params.job_ids = jobIds;
          promise = api.service_post('reporting', `internal-reports/internal-candidates`, params);
          break;
        case 'candidate-by-tags':
          data.tag_ids = tagIds;
          if (jobIds?.length) data.job_ids = jobIds;
          promise = api.service_post('reporting', `candidates-by-tag`, data);
          break;
        case 'leads-report':
          if (jobIds?.length > 0) data.job_ids = jobIds;
          if (recruiterIds?.length > 0) data.recruiter_ids = recruiterIds;
          promise = api.service_post('reporting', `leads-reports/leads`, data);
          break;
        case 'leads-interested-report' :
          data.start_date = startDate;
          data.end_date = endDate;
          promise = api.service_post('reporting', `leads-reports/assigned-jobs`, data);
          break;
        case 'leads-summary-report':
          data.start_date = startDate;
          data.end_date = endDate;
          if (jobIds?.length > 0) data.job_ids = jobIds;
          if (recruiterIds?.length > 0) data.recruiter_ids = recruiterIds;
          promise = api.service_post('reporting', `leads-reports/recruiters-summary`, data);
          break;
        case 'job-application-report':
          // @todo confirm
          data.start_date = startDate;
          data.end_date = endDate;
          if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
            promise = api.service_post('reporting', `agency-reports/agency-job-application-statistics-report`, data);
          } else {
            promise = api.service_post('reporting', `job-statistics/job-application-report`, data);
          }
          break;
        case 'interviews_statistics':
          promise = api.service_post('reporting', 'prepared-reports/request', {
            prepared_report_category_key: selectedReport,
            locale: $rootScope.language,
            parameters: {
              start_date: startDate,
              end_date: endDate,
              job_ids: jobIds
            }
          });
          break;
        case 'job-recruiters-report':
          if (jobIds?.length) data.job_ids = jobIds;
          if (recruiterIds?.length) data.recruiter_ids = recruiterIds;
          if (groupIds?.length) data.group_names = groupIds;
          if (categoryIds?.length) data.category_ids = categoryIds;
          if (functionIds?.length) data.function_ids = functionIds;
          promise = api.service_post('reporting', `job-recruiter-statistics`, data);
          break;
        default:
          promise = api.service_post('reporting', 'prepared-reports/request', {
            prepared_report_category_key: selectedReport,
            locale: $rootScope.language,
            parameters: {
              start_date: startDate,
              end_date: endDate
            }
          });
          break;
      }

      return promise.then((response) => {
        $rootScope.api_status('alert-success', 'Data extraction complete', "L'extraction des données a été effectuée avec succès");
        return response.data.data.result;
      }).catch((response) => {
        if (response.status === 401 || response.status === 403){
          $rootScope.api_status('alert-danger', 'Access denied', "Vous n'avez pas accès à ces données", null, null, 3500);
        } else if (response.status === 422) {
          $rootScope.api_status(
            'alert-danger',
            "Please select a filter for which you would like to get the report",
            'Veuillez sélectionner le filtre pour lequel vous souhaitez obtenir le rapport',
            null, null, 5000);
        } else {
          $rootScope.api_status('alert-danger', 'The data extraction failed', "Erreur lors de l'extraction des données");
        }
        return null;
      });
    }

    function validateDates(start_date, end_date) {
      if (!start_date || !end_date) {
        $rootScope.api_status(
          'alert-danger',
          'Please choose a start date as well as an end date',
          'Veuillez choisir une date de début ainsi qu\'une date de fin',
          'Missing date!',
          'Date manquante!',
        );
        return false;
      }
      const dates_diff = utils.getDaysDifferenceBetweenDates(start_date, end_date);
      if (dates_diff <= 0) {
        $rootScope.api_status(
          'alert-danger',
          'Please choose a start date earlier than the end date',
          'Veuillez choisir une date de début antérieure à la date de fin',
          'Invalid dates!',
          'Dates invalides!',
        );
        return false;
      }
      return true;
    }

    function trustAsHtml(string) {
      if (!angular.isString(string)) {
        return '';
      }
      return $sce.trustAsHtml(string);
    }

    const scopeMethods = {
      getReport,
      prepareReportData,
      getExtractionDataReport,
      validateDates,
    };
    angular.extend($scope, scopeMethods);
  }
  StatisticsCtrl.$inject = [
    '$scope',
    '$rootScope',
    'utils',
    '_',
    '$sce',
    'worklandLocalize',
    '$q',
    'api',
    'storageService',
    'Event',
    'statService',
  ];

  angular.module('atlas')
    .directive('statisticsUi', () => ({
      scope: {

      },
      controller: StatisticsCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-ui.template.html',
    }));
  angular.module('atlas').controller('StatisticsCtrl', StatisticsCtrl);
}(angular));
