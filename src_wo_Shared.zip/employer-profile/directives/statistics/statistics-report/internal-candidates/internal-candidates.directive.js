(function (angular) {
  function internalCandidatesCtrl($scope, api, utils, $rootScope) {
      const date = new Date();
      const scope = {
        out: utils.out,
        currentUser: $rootScope.currentUser,        
        jobIds: [],
        jobsData: [],
        job: { selected: '' },
        reportList: {
          internalCandidatesInfo: {
            key: "internal-candidates",
            fr: {
                title:"Rapport de l'ancienneté de candidats internes",
                name: "rapport-ancienneté-candidats-internes",
                description: "Rapport sur l'ancienneté des candidats internes"
            },
            en: {
                title:"Internal candidates seniority",
                name: "internal-candidates-seniority-report",
                description: "Report of internal candidates seniority"
            }
          }
        },
        language: $rootScope.language,
        jobsDataError: false,
      };
      angular.extend($scope, scope);

      function getUserJobs() {
        // employer and his admin see public and private jobs of this account
        $scope.loading = true;
        const url = $scope.currentUser.permissions.isAdmin ? 'job/current-account/jobs' : 'job/current-user/jobs';
        api.service_get('jobs', url, {
          'load_with[]': ['translations'],
        }).then( (response) => {
          if (response.data) {
            $scope.jobsData = response.data;
          }
          $scope.loading = false;
        }).catch( ()=> {
          $scope.loading = false;
          $scope.jobsDataError = true;
        })
      }

      (() => {
        getUserJobs();
      })();

      function addUserJobsForReport(jobs) {
        angular.forEach(jobs, (j) => {
          if (!$scope.jobIds.find(i => +i === +j.id)) {
            $scope.jobIds.push(j.id);
          }
        });
      }

      function removeUserJobsForReport(job) {
        const index = $scope.jobIds.indexOf(job.id);
        if (index >= 0) {
          $scope.jobIds.splice(index, 1);
        }
      }

      $scope.tagHandler = function (tag) {
        return null; // official hack to workaround angular issue
      };

      const scopeMethods = {
        addUserJobsForReport,
        removeUserJobsForReport,
      };
      angular.extend($scope, scopeMethods);
  }

  internalCandidatesCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope'];
  angular.module('atlas').directive('internalCandidates', () => ({
    scope: {
      getExtractionDataReport: '=',
      jobIds: '=?'
    },
    controller: internalCandidatesCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/internal-candidates/internal-candidates.template.html',
  }));
}(angular));
