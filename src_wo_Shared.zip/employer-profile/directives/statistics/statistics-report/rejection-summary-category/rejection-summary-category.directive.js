(function (angular) {
  function rejectionSummaryCategoryCtrl($scope, utils) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);


    const scopeMethods = {

    };
    angular.extend($scope, scopeMethods);
  }
  rejectionSummaryCategoryCtrl.$inject = ['$scope', 'utils'];

  angular.module('atlas')
    .directive('rejectionSummaryCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: rejectionSummaryCategoryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/rejection-summary-category/rejection-summary-category.template.html',
    }));
}(angular));