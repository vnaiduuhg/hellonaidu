(function (angular) {
  function workflowSummaryReportCtrl($scope, api, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      out: utils.out,
      // currentUser: userData.user,  -  this doesn't seems to be used
      reportName: utils.out('Rapport_sommaire_du_flux_de_travail', 'Workflow_summary_report'),
      loadingDone: false,
    };
    angular.extend($scope, scope);

    function loadWorkflowSummaryReport(company=null) {
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.loadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|workflow_summary', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary', null, null, dates);
      }
      return promise.then((response) => {
        $scope.loadingDone = true;
        if (response.data.status === 'success') {
          $scope.workflowSummaryReportData = response.data.data.result;
        } else {
          $scope.workflowSummaryReportData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
        return $scope.workflowSummaryReportData;
      }).catch(() => {
        $scope.loadingDone = true;
        $scope.workflowSummaryReportData = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    $scope.$watchGroup(['startDate','endDate'], () => {
      let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if(validatedDates) {
        loadWorkflowSummaryReport();
      }
    });

    Event.on('companySelected', ($event, company) => {
      loadWorkflowSummaryReport(company);
    });

    function init() {
      loadWorkflowSummaryReport();
    }

    const scopeMethods = {
      loadWorkflowSummaryReport,
      init
    };
    angular.extend($scope, scopeMethods);
  }
  workflowSummaryReportCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', 'Event', 'statService'];

  angular.module('atlas')
    .directive('workflowSummaryReport', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: workflowSummaryReportCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/workflow-summary-category/workflow-summary-report/workflow-summary-report.template.html',
    }));
}(angular));
