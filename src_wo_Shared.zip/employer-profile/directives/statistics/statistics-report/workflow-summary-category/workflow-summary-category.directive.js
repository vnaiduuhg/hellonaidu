(function (angular) {
  function workflowSummaryCategoryCtrl($scope, api, utils, $rootScope) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);


    const scopeMethods = {

    };
    angular.extend($scope, scopeMethods);
  }
  workflowSummaryCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope'];

  angular.module('atlas')
    .directive('workflowSummaryCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: workflowSummaryCategoryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/workflow-summary-category/workflow-summary-category.template.html',
    }));
}(angular));
