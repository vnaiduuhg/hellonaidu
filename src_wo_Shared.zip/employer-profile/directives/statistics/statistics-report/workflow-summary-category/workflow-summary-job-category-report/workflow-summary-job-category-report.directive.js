(function (angular) {
  function workflowSummaryJobCategoryReportCtrl($scope, api, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      out: utils.out,
      reportName: utils.out('Rapport_sommaire_du_flux_de_travail_categorie_de_poste', 'Workflow_summary_job_category_report'),
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(), // today
      loadingDone: false,
    };
    angular.extend($scope, scope);

    function loadWorkflowSummaryJobCategoryReport(company=null) {
      $scope.workflowSummaryJobCategoryReportData = [];
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.loadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|workflow_summary_job_category', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary_job_category', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary_job_category', null, null, dates);
      }
      return promise.then((response) => {
        $scope.loadingDone = true;
        if (response.data.status === 'success') {
          $scope.workflowSummaryJobCategoryReportData = response.data.data.result;
        } else {
          $scope.workflowSummaryJobCategoryReportData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
        return $scope.workflowSummaryJobCategoryReportData;
      }).catch(() => {
        $scope.loadingDone = true;
        $scope.workflowSummaryJobCategoryReportData = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    Event.on('companySelected', ($event, company) => {
      loadWorkflowSummaryJobCategoryReport(company);
    });

    function init() {
      loadWorkflowSummaryJobCategoryReport();
    }

    $scope.$watchGroup(['startDate','endDate'], () => {
      let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if(validatedDates) {
        init();
      }
    });

    const scopeMethods = {
      loadWorkflowSummaryJobCategoryReport,
    };
    angular.extend($scope, scopeMethods);
  }
  workflowSummaryJobCategoryReportCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', 'Event', 'statService'];

  angular.module('atlas')
    .directive('workflowSummaryJobCategoryReport', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: workflowSummaryJobCategoryReportCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/workflow-summary-category/workflow-summary-job-category-report/workflow-summary-job-category-report.template.html',
    }));
}(angular));
