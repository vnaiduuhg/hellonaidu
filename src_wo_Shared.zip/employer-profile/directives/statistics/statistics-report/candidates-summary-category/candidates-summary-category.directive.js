(function (angular) {
  function candidatesSummaryCategoryCtrl($scope, api, utils, $rootScope, $q) {
    const date = new Date();
    const scope = {
      out: utils.out,
      currentUser: $rootScope.currentUser,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      startDateCompany: new Date(new Date().setFullYear(new Date().getFullYear() - 1)),
      endDateCompany: new Date(),
      jobIds: [],
      jobIdsForTags: [],
      jobsData: [],
      tagIds: [],
      tagsData: [],
      reportList: {
        candidatesAccountInfo: {
          key: 'candidates-account-info',
          fr: {
            title: 'Rapport des comptes candidats',
            name: 'rapport-comptes-candidats',
            description: 'Rapport détaillé portant sur les informations des comptes des candidats',
          },
          en: {
            title: 'Candidate accounts report',
            name: 'candidates-account-report',
            description: 'Detailed report on candidate account information',
          },
        },
        companyCandidatesAccountInfo: {
          key: 'company-candidate-accounts',
          fr: {
            title: 'Rapport des comptes candidats',
            name: 'rapport-comptes-candidats',
            description: 'Rapport détaillé portant sur les informations des comptes des candidats',
          },
          en: {
            title: 'Candidate accounts report',
            name: 'candidates-account-report',
            description: 'Detailed report on candidate account information',
          },
        },
        candidatesApplications: {
          key: 'candidates_applications',
          fr: {
            title: 'Rapport de candidatures',
            name: 'rapport-applications-candidats',
            description: 'Rapport détaillé portant sur les candidatures soumises',
          },
          en: {
            title: 'Candidate applications report',
            name: 'candidates-applications-report',
            description: 'Detailed report on applications submitted by candidates',
          },
        },
        candidatesApplicationAnswers: {
          key: 'candidates_application_answers',
          fr: {
            title: "Rapport des questionnaires",
            name: 'rapport-questionnaires-candidats',
            description: "Rapport détaillé portant sur les questionnaires d'inscription des candidats",
          },
          en: {
            title: 'Candidate questionnaires report',
            name: 'candidates-questionnaires-report',
            description: 'Detailed report on candidate registration questionnaires',
          },
        },
        candidatesByTags: {
          key: 'candidate-by-tags',
          fr: {
            title: "Rapport des candidats par étiquettes",
            name: 'rapport-etiquettes-candidats',
            description: "Rapport détaillé portant sur les candidats filtrés par étiquettes",
          },
          en: {
            title: 'Candidate tags report',
            name: 'candidates-tags-report',
            description: 'Detailed report of candidates filtered by tags',
          },
        },
      },
      jobs: { selected: '' },
      jobsForTags: { selected: '' },
      tags: { selected: '' },
      jobsDataError: false,
      tagsDataError: false,
    };
    angular.extend($scope, scope);

    function getUserJobs() {
      // employer and his admin see public and private jobs of this account
      const url = $scope.currentUser.permissions.isAdmin ? 'job/current-account/jobs' : 'job/current-user/jobs';
      return api.service_get('jobs', url, {
        'load_with[]': ['translations'],
      }).then( (response) => {
          if (response.data) {
            $scope.jobsData = response.data;
          }
      }).catch(()=> {
        $scope.jobsDataError = true;
      });
    }

    function getTags() {
      return api.service_get('toolkit', 'document-manager/tags').then( (response) => {
        if (response.status === 200 && response.data?.data?.result) {
          $scope.tagsData = response.data.data.result;
        }
      }).catch(()=> {
        $scope.tagsDataError = true;
      });
    }

    function addUserJobsForReport(jobs, typeIds) {
      angular.forEach(jobs, (job) => {
        const index = $scope[typeIds].indexOf(job.id);
        if (index === -1) {
          $scope[typeIds].push(job.id);
        }
      });
    }

    function removeUserJobsForReport(job, typeIds) {
      const index = $scope[typeIds].indexOf(job.id);
      if (index >= 0) {
        $scope[typeIds].splice(index, 1);
      }
    }

    function addUserTagsForReport(tags) {
      angular.forEach(tags, (tag) => {
        const index = $scope.tagIds.indexOf(tag.id);
        if (index === -1) {
          $scope.tagIds.push(tag.id);
        }
      });
    }

    function removeUserTagsForReport(tag) {
      const index = $scope.tagIds.indexOf(tag.id);
      if (index >= 0) {
        $scope.tagIds.splice(index, 1);
      }
    }

    (() => {
      $scope.loading = true;
      const promises = [];
        promises.push(
          getUserJobs(),
          getTags()
        );
        $q.all(promises).then(() => {
          $scope.loading = false;
        });
    })();

    const scopeMethods = {
      addUserJobsForReport,
      removeUserJobsForReport,
      addUserTagsForReport,
      removeUserTagsForReport
    };
    angular.extend($scope, scopeMethods);
  }

  candidatesSummaryCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', '$q'];
  angular.module('atlas').directive('candidatesSummaryCategory', () => ({
    scope: {
      getExtractionDataReport: '=',
    },
    controller: candidatesSummaryCategoryCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/candidates-summary-category/candidates-summary-category.template.html',
  }));
}(angular));
