(function(angular) {
    function statisticsReportCtrl($scope, utils) {
        // initialize scope variables here
        const scope = {
            out: utils.out, //to translate variables to French/English
        };
        angular.extend($scope, scope);

        // add methods that will be called from template by user
        const scopeMethods = {
        };
        angular.extend($scope, scopeMethods);
    }

    statisticsReportCtrl.$inject = ['$scope', 'utils'];
    angular.module('atlas')
        .directive('statisticsReport', () => ({
            scope: {},
            controller: statisticsReportCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/statistics-report.template.html',
        }));
}(angular));