// eslint-disable-next-line func-names
(function (angular) {
  function leadsReportCtrl($scope, api, utils, $rootScope, $q) {
    const date = new Date();
    const scope = {
      out: utils.out,
      currentUser: $rootScope.currentUser,
      jobIds: [],
      jobsData: [],
      jobs: { selected: '' },
      recruiterIds: [],
      accountRecruiters: [],
      recruiters: { selected: '' },
      sumReportJobIds: [],
      sumReportJobs: { selected: '' },
      sumReportrecruiterIds: [],
      sumReportRecruiters: { selected: '' },
      reportList: {
        leadsInfo: {
          key: 'leads-report',
          fr: {
            title: 'Rapport de potentiels / candidatures',
            name: 'rapport-potentiels',
            description: 'Rapport détaillé des candidats potentiels ayant appliqués sur un poste',
          },
          en: {
            title: 'Report of leads / applications',
            name: 'leads-report',
            description: 'Detailed report of number of leads that have applied to a job',
          },
        },
        leadsInterestedReport: {
          key: 'leads-interested-report',
          fr: {
            title: 'Rapport de potentiels et statut d\’intérêt au poste attribué',
            name: 'rapport-intéressé-potentiels',
            description: 'Rapport détaillé sur les candidats potentiels ayant été attribués à un poste, ainsi que le statut de leur intérêt',
          },
          en: {
            title: 'Report on leads and status of interest for an assigned position',
            name: 'leads-interested-report',
            description: 'Detailed report on leads that have been assigned to a position and the status of their interest',
          },
        },
        leadsSummaryReport: {
          key: 'leads-summary-report',
          fr: {
            title: 'Rapport sommaire des potentiels par postes',
            name: 'rapport-sommaire-potentiels',
            description: 'Rapport le sommaire des potentiels par postes',
          },
          en: {
            title: 'Leads summary by jobs report',
            name: 'leads-summary-report',
            description: 'Leads summary report by jobs',
          },
        }
      },
      language: $rootScope.language,
      jobsDataError: false,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      sumReportStartDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      sumReportEndDate: new Date(),
    };
    angular.extend($scope, scope);

    $scope.setInputFocus = function(){
      $scope.$broadcast('SetFocus');
    }

    function getUserJobs() {
      // employer and his admin see public and private jobs of this account
      const url = $scope.currentUser.permissions.isAdmin ? 'job/current-account/jobs' : 'job/current-user/jobs';
      return api.service_get('jobs', url, {
        'load_with[]': ['translations'],
      }).then((response) => {
        if (response.data) {
          $scope.jobsData = response.data;
        }
      }).catch(() => {
        $scope.jobsDataError = true;
      });
    }

    function getRecruiters() {
      const allMembersOfAccount = $rootScope.currentUser.account_user;
      if ($scope.currentUser.permissions.isAdmin) {
        angular.forEach(allMembersOfAccount, (member) => {
          if (![10, 20, 30, 80].includes(member.role_id)) {
            return;
          }
          const recruiter = {};
          recruiter.name = `${member.user.first_name} ${member.user.last_name}`;
          recruiter.id = member.user.id;
          $scope.accountRecruiters.push(recruiter);
        });
      }
    }

    function addJobsToReport(jobs, idsVar) {
      angular.forEach(jobs, (job) => {
        const index = $scope[idsVar].indexOf(job.id);
        if (index === -1) {
          $scope[idsVar].push(job.id);
        }
      });
    }

    function removeJobFromReport(job, idsVar) {
      const index = $scope[idsVar].indexOf(job.id);
      if (index >= 0) {
        $scope[idsVar].splice(index, 1);
      }
    }

    function addRecruitersToReport(recruiters, idsVar) {
      angular.forEach(recruiters, (recruiter) => {
        const index = $scope[idsVar].indexOf(recruiter.id);
        if (index === -1) {
          $scope[idsVar].push(recruiter.id);
        }
      });
    }

    function removeRecruiterFromReport(recruiter, idsVar) {
      const index = $scope[idsVar].indexOf(recruiter.id);
      if (index >= 0) {
        $scope[idsVar].splice(index, 1);
      }
    }

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    (() => {
      $scope.loading = true;
      const promises = [];
      promises.push(
        getUserJobs(),
        getRecruiters(),
      );
      $q.all(promises).then(() => {
        $scope.loading = false;
      });
    })();

    const scopeMethods = {
      addJobsToReport,
      removeJobFromReport,
      addRecruitersToReport,
      removeRecruiterFromReport,
    };
    angular.extend($scope, scopeMethods);
  }

  leadsReportCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', '$q'];
  angular.module('atlas').directive('leadsReport', () => ({
    scope: {
      getExtractionDataReport: '=',
    },
    controller: leadsReportCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/leads-report/leads-report.template.html',
  }));
// eslint-disable-next-line no-undef
}(angular));
