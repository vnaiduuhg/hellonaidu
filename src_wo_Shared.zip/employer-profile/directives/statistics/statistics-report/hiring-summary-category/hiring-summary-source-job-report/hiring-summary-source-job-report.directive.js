(function (angular) {
    function hiringSummarySourceJobReportCtrl(
        $scope,
        $rootScope,
        api,
        utils,
        Event,
        statService,
    ) {     
      const date = new Date();
      const scope = {
          out: utils.out,
          reportName: utils.out('Rapport_sommaire_de_recrutement_source_poste','Hiring_summary_source_job_report'),
          startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
          endDate: new Date(), // today,
          loadingDone: false
        };
        angular.extend($scope, scope);

        function fetchHiringSummarySourceJobReport(company=null) {
          $scope.loadingDone = false;
          $scope.hiringSummarySourceJobReport = [];
          let promise;
          const dates = {
            start_date: $scope.startDate,
            end_date: $scope.endDate
          }
          var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
          if ($scope.isConfidentiel) {
            promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_source_job', 'company_account_id', company, dates);
          } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job', 'client_account_id', company, dates);
          } else {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source_job', null, null, dates);
          }
          return promise.then((response) => {
            $scope.loadingDone = true;
            if (response.data.status === 'success') {
              $scope.hiringSummarySourceJobReport = response.data.data.result;
            } else {
              $scope.hiringSummarySourceJobReport = [];
                $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
            }          
            return $scope.hiringSummarySourceJobReport;
          }).catch(() => {
            $scope.loadingDone = true;
            $scope.hiringSummarySourceJobReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
          });
        }

        function init() {
          fetchHiringSummarySourceJobReport();
        }

        Event.on('companySelected', ($event, company) => {
          fetchHiringSummarySourceJobReport(company);
        });

        $scope.$watchGroup(['startDate','endDate'], () => {
          let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
          if(validatedDates) {
            init();
          }
        });

        const scopeMethods = {
          fetchHiringSummarySourceJobReport,
        };
        angular.extend($scope, scopeMethods);
    }
    hiringSummarySourceJobReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
    
    angular.module('atlas').directive('hiringSummarySourceJobReport', function () {
        return {
            scope: {
              currentUserAccountId: '=',
              companies: '=',
              isAgency: '=',
              isAgencyAdminRecruiter: '=',
              isConfidentiel: '=',
              validateDates: '='
            },
            controller: hiringSummarySourceJobReportCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/hiring-summary-source-job-report/hiring-summary-source-job-report.template.html',
        };
    });
})(angular);