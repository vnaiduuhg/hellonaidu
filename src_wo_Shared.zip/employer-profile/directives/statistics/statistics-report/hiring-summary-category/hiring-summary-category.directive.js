(function (angular) {
  function hiringSummaryCategoryCtrl($scope, utils) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);


    const scopeMethods = {

    };
    angular.extend($scope, scopeMethods);
  }
  hiringSummaryCategoryCtrl.$inject = ['$scope', 'utils'];

  angular.module('atlas')
    .directive('hiringSummaryCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '='
      },
      controller: hiringSummaryCategoryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/hiring-summary-category.template.html',
    }));
}(angular));