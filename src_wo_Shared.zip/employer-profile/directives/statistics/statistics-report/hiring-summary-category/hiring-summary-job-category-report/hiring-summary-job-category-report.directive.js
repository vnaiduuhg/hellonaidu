(function (angular) {
    function hiringSummaryJobCategoryReportCtrl(
        $scope,
        $rootScope,
        api,
        utils,
        Event,
        statService,
    ) {
      const date = new Date();
      const scope = {
          out: utils.out,
          reportName: utils.out('Rapport_sommaire_de_recrutement_categorie_de_poste','Hiring_summary_job_category_report'),
          startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
          endDate: new Date(),
          loadingDone: false
        };
        angular.extend($scope, scope);

        function fetchHiringSummaryJobCategoryReport(company=null) {
          $scope.loadingDone = false;
          $scope.hiringSummaryJobCategoryReport = [];
          let promise;
          const dates = {
            start_date: $scope.startDate,
            end_date: $scope.endDate
          }
          var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
          if ($scope.isConfidentiel) {
            promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_job_category', 'company_account_id', company, dates);
          } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_job_category', 'client_account_id', company, dates);
          } else {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_job_category', null, null, dates);
          }
          return promise.then((response) => {
            $scope.loadingDone = true;
            if (response.data.status === 'success') {
              $scope.hiringSummaryJobCategoryReport = response.data.data.result;
            } else {
              $scope.hiringSummaryJobCategoryReport = [];
                $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
            }          
            return $scope.hiringSummaryJobCategoryReport;
          }).catch(() => {
            $scope.loadingDone = true;
            $scope.hiringSummaryJobCategoryReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
          });
        }

        function init() {
          fetchHiringSummaryJobCategoryReport();
        }

        Event.on('companySelected', ($event, company) => {
          fetchHiringSummaryJobCategoryReport(company);
        });

        $scope.$watchGroup(['startDate','endDate'], () => {
          let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
          if(validatedDates) {
            init();
          }
        });

        const scopeMethods = {
          fetchHiringSummaryJobCategoryReport,
        };
        angular.extend($scope, scopeMethods);
;
    }
    hiringSummaryJobCategoryReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
    
    angular.module('atlas').directive('hiringSummaryJobCategoryReport', function () {
        return {
            scope: {
              currentUserAccountId: '=',
              companies: '=',
              isAgency: '=',
              isAgencyAdminRecruiter: '=',
              isConfidentiel: '=',
              validateDates: '='
            },
            controller: hiringSummaryJobCategoryReportCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/hiring-summary-job-category-report/hiring-summary-job-category-report.template.html',
        };
    });
})(angular);