(function (angular) {
    function hiringSummaryReportCtrl(
        $scope,
        $rootScope,
        api,
        utils,
        Event,
        statService,
    ) {    
      const date = new Date();
      const scope = {
          out: utils.out,
          reportName: utils.out('Rapport_sommaire_de_recrutement','Hiring_summary_report'),
          startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
          endDate: new Date(), // today
          loadingDone: false,
        };
        angular.extend($scope, scope);

        function fetchHiringSummaryReport(company=null) {
          $scope.loadingDone = false;
          $scope.hiringSummaryReport = [];
          let promise;
          const dates = {
            start_date: $scope.startDate,
            end_date: $scope.endDate
          }
          var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
          if ($scope.isConfidentiel) {
            promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary', 'company_account_id', company, dates);
          } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary', 'client_account_id', company, dates);
          } else {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary', null, null, dates);
          }
          return promise.then((response) => {
            $scope.loadingDone = true;
            if (response.data.status === 'success') {
              $scope.hiringSummaryReport = response.data.data.result;
            } else {
              $scope.hiringSummaryReport = [];
                $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
            }          
            return $scope.hiringSummaryReport;
          }).catch(() => {
            $scope.loadingDone = true;
            $scope.hiringSummaryReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
          });
        }

        function init() {
          fetchHiringSummaryReport();
        }

        Event.on('companySelected', ($event, company) => {
          fetchHiringSummaryReport(company);
        });

        $scope.$watchGroup(['startDate','endDate'], () => {
          let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
          if(validatedDates) {
            init();
          }
        });

        const scopeMethods = {
          fetchHiringSummaryReport,
        };
        angular.extend($scope, scopeMethods);
    }
    hiringSummaryReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
    
    angular.module('atlas').directive('hiringSummaryReport', function () {
        return {
            scope: {
              currentUserAccountId: '=',
              companies: '=',
              isAgency: '=',
              isAgencyAdminRecruiter: '=',
              isConfidentiel: '=',              
              validateDates: '='
            },
            controller: hiringSummaryReportCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/hiring-summary-report/hiring-summary-report.template.html',
        };
    });
})(angular);