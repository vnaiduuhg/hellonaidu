(function (angular) {
  function averageHiringTimeReportCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    Event,
    statService,
  ) {
    const scope = {
      out: utils.out,
      reportName: utils.out('Rapport_du_temps_moyen_de_recrutement','Average_hiring_time_report'),
      loadingDone: false
    };
    angular.extend($scope, scope);

    function fetchAverageHiringTimeReport(company) {
      let promise;
      $scope.loadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|average_hiring_time', 'company_account_id', company);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'average_hiring_time', 'client_account_id', company);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'average_hiring_time');
      }
      return promise.then((response) => {
        $scope.loadingDone = true;
        if (response.data.status === 'success') {
          $scope.averageHiringTimeReport = response.data.data.result;
        } else {
          $scope.averageHiringTimeReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }          
        return $scope.averageHiringTimeReport;
      }).catch(() => {
        $scope.loadingDone = true;
        $scope.averageHiringTimeReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      fetchAverageHiringTimeReport();
    }

    init();

    Event.on('companySelected', ($event, company) => {
      fetchAverageHiringTimeReport(company);
    });

    const scopeMethods = {
      fetchAverageHiringTimeReport,
    };
    angular.extend($scope, scopeMethods);
  }
  averageHiringTimeReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
  angular.module('atlas').directive('averageHiringTimeReport', () => ({
    scope: {
      currentUserAccountId: '=',
      companies: '=',
      isAgency: '=',
      isAgencyAdminRecruiter: '=',
      isConfidentiel: '=',
    },
    controller: averageHiringTimeReportCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/average-hiring-time-report/average-hiring-time-report.template.html',
  }));
}(angular));
