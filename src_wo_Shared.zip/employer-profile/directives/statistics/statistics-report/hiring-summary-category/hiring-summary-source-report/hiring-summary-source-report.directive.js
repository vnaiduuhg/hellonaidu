(function (angular) {
    function hiringSummarySourceReportCtrl(
        $scope,
        $rootScope,
        api,
        utils,
        Event,
        statService,
    ) {    
      const date = new Date();
      const scope = {
          out: utils.out,
          reportName: utils.out('Rapport_sommaire_de_recrutement_source','Hiring_summary_source_report'),
          startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
          endDate: new Date(),
          loadingDone: false,
        };
        angular.extend($scope, scope);

        function fetchHiringSummarySourceReport(company=null) {
          $scope.loadingDone = false;
          $scope.hiringSummarySourceReport = [];
          let promise;
          const dates = {
            start_date: $scope.startDate,
            end_date: $scope.endDate
          }
          var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
          if ($scope.isConfidentiel) {
            promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|hiring_summary_source', 'company_account_id', company, dates);
          } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source', 'client_account_id', company, dates);
          } else {
            promise = statService.genericPostRequest('prepared_report_category_key', 'hiring_summary_source', null, null, dates);
          }
          return promise.then((response) => {
            $scope.loadingDone = true;
            if (response.data.status === 'success') {
              $scope.hiringSummarySourceReport = response.data.data.result;
            } else {
              $scope.hiringSummarySourceReport = [];
                $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
            }          
            return $scope.hiringSummarySourceReport;
          }).catch(() => {
            $scope.loadingDone = true;
            $scope.hiringSummarySourceReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
          });
        }

        function init() {
          fetchHiringSummarySourceReport();
        }

        Event.on('companySelected', ($event, company) => {
          fetchHiringSummarySourceReport(company);
        });

        $scope.$watchGroup(['startDate','endDate'], () => {
          let validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
          if(validatedDates) {
            init();
          }
        });

        const scopeMethods = {
          fetchHiringSummarySourceReport,
        };
        angular.extend($scope, scopeMethods);
    }
    hiringSummarySourceReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
    
    angular.module('atlas').directive('hiringSummarySourceReport', function () {
        return {
            scope: {
              currentUserAccountId: '=',
              companies: '=',
              isAgency: '=',
              isAgencyAdminRecruiter: '=',
              isConfidentiel: '=',
              validateDates: '='
            },
            controller: hiringSummarySourceReportCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/hiring-summary-category/hiring-summary-source-report/hiring-summary-source-report.template.html',
        };
    });
})(angular);