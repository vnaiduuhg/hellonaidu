(function (angular) {
  function jobsReportCategoryCtrl($scope, api, utils, $rootScope, $q) {
    const date = new Date();
    const scope = {
      loadingDone: false,
      currentUser: $rootScope.currentUser,
      out: utils.out,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      jobs: { selected: '' },
      jobsData: [],
      jobIds: [],
      jobsDataError: false,
      recruiters: { selected: '' },
      recruitersData: [],
      recruiterIds: [],
      recruitersDataError: false,
      groups: { selected: '' },
      groupsData: [],
      groupIds: [],
      groupsDataError: false,
      categories: { selected: '' },
      categoriesData: [],
      categoryIds: [],
      categoriesDataError: false,
      functions: { selected: '' },
      functionsData: [],
      functionIds: [],
      reportList: {
        clientsJobsReport: {
          key: "client_jobs",
          fr: {
            title:"Rapport clients",
            name: "rapport-postes-des-clients",
            description: "Rapport détaillé sur les postes des clients de l'agence"
          },
          en: {
            title:"Client jobs report",
            name: "client-jobs-report",
            description: "Detailed report of clients jobs"
          }
        },
        jobApplicationsReport: {
          key: "job-application-report",
          fr: {
            title:"Rapport sur le nombre de candidatures par poste",
            name: "rapport-candidatures",
            description: "Rapport détaillant le nombre de candidatures, le nombre de vues, jours et date de création avec visualisation par étape de flux de travail"
          },
          en: {
            title:"Report on number of applications per job",
            name: "job-applications-report",
            description: "Report providing the total number of applications, number of views, total days, date of creation with the ability to view by workflow stage"
          }
        },
        jobRecruitersReport: {
          key: "job-recruiters-report",
          fr: {
            title:"Rapport du temps moyen d'embauche",
            name: "rapport-recruteurs-emplois",
            description: "Rapport sommaire des candidats embauchés et le temps moyen d'embauche"
          },
          en: {
            title:"Average hiring time report",
            name: "job-recruiters-report",
            description: "Summary report of candidates hired and their average time of hire"
          }
        }
      }
    };
    angular.extend($scope, scope);

    addUserJobsForReport = (jobs) => {
      angular.forEach(jobs, (job) => {
        const index = $scope.jobIds.indexOf(job.id);
        if (index === -1) {
          $scope.jobIds.push(job.id);
        }
      });
    }

    removeUserJobsForReport = (job) => {
      const index = $scope.jobIds.indexOf(job.id);
      if (index >= 0) {
        $scope.jobIds.splice(index, 1);
      }
    }

    addRecruitersForReport = (recruiters) => {
      angular.forEach(recruiters, (recruiter) => {
        const index = $scope.recruiterIds.indexOf(recruiter.user_id);
        if (index === -1) {
          $scope.recruiterIds.push(recruiter.user_id);
        }
      });
    }

    removeRecruitersForReport = (recruiter) => {
      const index = $scope.recruiterIds.indexOf(recruiter.user_id);
      if (index >= 0) {
        $scope.recruiterIds.splice(index, 1);
      }
    }

    addGroupsForReport = (groups) => {
      angular.forEach(groups, (group) => {
        const index = $scope.groupIds.indexOf(group.name);
        if (index === -1) {
          $scope.groupIds.push(group.name);
        }
      });
    }

    removeGroupsForReport = (group) => {
      const index = $scope.groupIds.indexOf(group.name);
      if (index >= 0) {
        $scope.groupIds.splice(index, 1);
      }
    }

    addCategoriesForReport = (categories) => {
      let tempCatFns = [];
      angular.forEach(categories, (category) => {
        const index = $scope.categoryIds.indexOf(category.id);
        if (index === -1) {
          $scope.categoryIds.push(category.id);
          tempCatFns = category.default_functions.map(fn => {
            fn.category_name = utils.out(category.translations[1].name, category.translations[0].name);
            return fn;
          });
        }
      });
      // just add functions that are not selected to avoid duplicatas
      const finalCatFns = tempCatFns.filter(item => !$scope.functionIds.find(id => +id === +item.id));
      $scope.functionsData = finalCatFns.concat(angular.copy($scope.functionsData));
    }

    removeCategoriesForReport = (category) => {
      const index = $scope.categoryIds.indexOf(category.id);
      if (index >= 0) {
        $scope.categoryIds.splice(index, 1);
        // remove fn associated to this category on functionIds, functionsData & functions.selected
        const fnIdsToDelete = [];
        const fnDataToDelete = [];
        const fnSelectedToDelete = [];
        category.default_functions.forEach(fn => {
          const indexOfFnIds = $scope.functionIds.indexOf(+fn.id);
          if (indexOfFnIds > -1) fnIdsToDelete.push(indexOfFnIds);
          const indexOfFnData = $scope.functionsData.findIndex(item => +item.id === +fn.id);
          if (indexOfFnData > -1) fnDataToDelete.push(indexOfFnData);
          if ($scope.functions.selected) {
            const indexOfFnSelected = $scope.functions.selected.findIndex(item => +item.id === +fn.id);
            if (indexOfFnSelected > -1) fnSelectedToDelete.push(indexOfFnSelected);
          }
        });
        fnIdsToDelete.reverse().forEach(index => $scope.functionIds.splice(index, 1));
        fnDataToDelete.reverse().forEach(index => $scope.functionsData.splice(index, 1));
        fnSelectedToDelete.reverse().forEach(index => $scope.functions.selected.splice(index, 1));
      }
    }

    addFunctionsForReport = (functions) => {
      angular.forEach(functions, (fn) => {
        const index = $scope.functionIds.indexOf(fn.id);
        if (index === -1) {
          $scope.functionIds.push(fn.id);
        }
      });
    }

    removeFunctionsForReport = (fn) => {
      const index = $scope.functionIds.indexOf(fn.id);
      if (index >= 0) {
        $scope.functionIds.splice(index, 1);
      }
    }

    groupByCategoryId = (item) => {
      return item.category_name;
    }

    getRecruitersList = () => {
      if ($scope.currentUser.permissions.isAdmin) {
        $scope.recruitersData = $rootScope.currentUser.account_user.filter(recruiter => {
          if ([10, 20, 30, 80].includes(recruiter.role_id)) {
            return recruiter.user;
          }
        });
      }
    }

    getUserJobs = () => {
      // employer and his admin see public and private jobs of this account
      const url = $scope.currentUser.permissions.isAdmin ? 'job/current-account/jobs' : 'job/current-user/jobs';
      return api.service_get('jobs', url, {
        'load_with[]': ['translations'],
      }).then( (response) => {
        if (response.data) {
          $scope.jobsData = response.data;
        }
      }).catch(()=> {
        $scope.jobsDataError = true;
      });
    }

    getJobGroups = () => {
      return api.service_get('jobs', `group/account/${$scope.currentUser.account.id}/groups`).then( (response) => {
        if (response.data) {
          $scope.groupsData = response.data;
        }
      }).catch(()=> {
        $scope.groupsDataError = true;
      });
    }

    getJobFunctionsAndCategories = () => {
      return api.service_get('shared', `jobCategory`).then( (response) => {
        if (response.data) {
          $scope.categoriesData = response.data;
        }
      }).catch(()=> {
        $scope.categoriesDataError = true;
      });
    }

    (() => {
      const promises = [];
      promises.push(
        getUserJobs(),
        getRecruitersList(),
        getJobGroups(),
        getJobFunctionsAndCategories()
      );

      $q.all(promises).then(() => {
        $scope.loadingDone = true;
      });
    })();

    const scopeMethods = {
      addUserJobsForReport,
      removeUserJobsForReport,
      addRecruitersForReport,
      removeRecruitersForReport,
      addGroupsForReport,
      removeGroupsForReport,
      addCategoriesForReport,
      removeCategoriesForReport,
      addFunctionsForReport,
      removeFunctionsForReport,
      groupByCategoryId
    };
    angular.extend($scope, scopeMethods);
  }
  jobsReportCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', '$q'];

  angular.module('atlas')
    .directive('jobsReportCategory', () => ({
      scope: {
          getExtractionDataReport: '=',
          currentUserAccountId: '=',
          companies: '=',
          isAgency: '=',
          isAgencyAdminRecruiter: '=',
          isConfidentiel: '=',
          hasAccessToExtractionData: '='
      },
      controller: jobsReportCategoryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-report/jobs-report-category/jobs-report-category.template.html',
    }));
}(angular));
