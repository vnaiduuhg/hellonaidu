(function (angular) {
  function filledJobsReportCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    Event,
    statService
  ) {
    const scope = {
      out: utils.out,
      reportName: utils.out('Rapport_de_postes_combles','Filled_jobs_report')
    };
    angular.extend($scope, scope);

    function setPeriodDates() {
      const date = new Date();
      const tempDateWeek = angular.copy(date).setDate(date.getDate() - 7);
      const tempDateMonth = angular.copy(date).setMonth(date.getMonth() - 1);
      const tempDateYear = angular.copy(date).setFullYear(date.getFullYear() - 1);
      $scope.dates = {
        today: utils.getTimeFormat(date, 'LL'),
        oneWeekAgo: utils.getTimeFormat(tempDateWeek, 'LL'),
        oneMonthAgo: utils.getTimeFormat(tempDateMonth, 'LL'),
        oneYearAgo: utils.getTimeFormat(tempDateYear, 'LL'),
      };
    }

    function fetchFilledJobsReport(company=null) {
      $scope.filledJobsReport = [];
      let promise;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|filled_jobs', 'company_account_id', company);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'filled_jobs', 'client_account_id', company);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'filled_jobs');
      }
      return promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.filledJobsReport = response.data.data.result;
        } else {
          $scope.filledJobsReport = [];
            $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }          
        return $scope.filledJobsReport;
      }).catch(() => {
        $scope.filledJobsReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    Event.on('companySelected', ($event, company) => {
      fetchFilledJobsReport(company);
    });

    function init() {
      setPeriodDates();
      fetchFilledJobsReport();
    }

    init();

    const scopeMethods = {
      fetchFilledJobsReport,
    };
    angular.extend($scope, scopeMethods);
  }
  filledJobsReportCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event', 'statService'];
  angular.module('atlas').directive('filledJobsReport', () => ({
    scope: {
      currentUserAccountId: '=',
      companies: '=',
      isAgency: '=',
      isAgencyAdminRecruiter: '=',
      isConfidentiel: '=',
    },
    controller: filledJobsReportCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/jobs-report-category/filled-jobs-report/filled-jobs-report.template.html',
  }));
}(angular));