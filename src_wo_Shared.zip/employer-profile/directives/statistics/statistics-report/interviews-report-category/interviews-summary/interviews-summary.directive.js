(function (angular) {
  function interviewsSummaryCtrl(
    $scope,
    $rootScope,
    utils,
    api,
  ) {
    const date = new Date();
    const scope = {
      out: utils.out,
      currentUser: $rootScope.currentUser,
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      jobIds: [],
      jobsData: [],
      tagIds: [],
      reportList: {
        interviewsSummary: {
          key: 'interviews_statistics',
          fr: {
            title: "Rapport sommaire des entrevues",
            name: 'rapport-sommaire-des-entrevues',
            description: "Rapport détaillé portant sur les statistiques d'entrevues",
          },
          en: {
            title: 'Interviews summary report',
            name: 'interviews-summary-report',
            description: 'Detailed report of interviews statistics',
          },
        },
      },
      jobs: { selected: '' },
      jobsDataError: false,
      loadingDone: false,
      validDates: true
    };
    angular.extend($scope, scope);

    function addUserJobsForReport(jobs) {
      angular.forEach(jobs, (job) => {
        const index = $scope.jobIds.indexOf(job.id);
        if (index === -1) {
          $scope.jobIds.push(job.id);
        }
      });
    }

    function removeUserJobsForReport(job) {
      const index = $scope.jobIds.indexOf(job.id);
      if (index >= 0) {
        $scope.jobIds.splice(index, 1);
      }
    }

    getUserJobs = () => {
      $scope.loadingDone = false;
      // employer and his admin see public and private jobs of this account
      const url = $scope.currentUser.permissions.isAdmin ? 'job/current-account/jobs' : 'job/current-user/jobs';
      return api.service_get('jobs', url, {
        'load_with[]': ['translations'],
      }).then( (response) => {
        if (response.data) {
          $scope.jobsData = response.data;
        }
        $scope.loadingDone = true;
      }).catch(()=> {
        $scope.jobsDataError = true;
        $scope.loadingDone = true;
      });
    }

    (() => {
      getUserJobs();
    })();

    $scope.$watchGroup(['startDate','endDate'], () => {
      $scope.validDates = $scope.validateDates($scope.startDate, $scope.endDate);
    });

    const scopeMethods = {
      addUserJobsForReport,
      removeUserJobsForReport
    };
    angular.extend($scope, scopeMethods);
  }
  interviewsSummaryCtrl.$inject = ['$scope', '$rootScope', 'utils', 'api'];

  angular.module('atlas').directive('interviewsSummary', () => ({
    scope: {
      getExtractionDataReport: '=',
			validateDates: '='
    },
    controller: interviewsSummaryCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-report/interviews-report-category/interviews-summary/interviews-summary.template.html',
  }));
}(angular));
