(function (angular) {
	function interviewsReportCategoryCtrl($scope, api, utils, $rootScope) {

	  const scope = {};
	  angular.extend($scope, scope);

	  const scopeMethods = {};
	  angular.extend($scope, scopeMethods);
	}
	interviewsReportCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope'];
  
	angular.module('atlas')
	  .directive('interviewsReportCategory', () => ({
		scope: {
			getExtractionDataReport: '=',
			validateDates: '='
		},
		controller: interviewsReportCategoryCtrl,
		templateUrl: './employer-profile/directives/statistics/statistics-report/interviews-report-category/interviews-report-category.template.html',
	  }));
  }(angular));
  