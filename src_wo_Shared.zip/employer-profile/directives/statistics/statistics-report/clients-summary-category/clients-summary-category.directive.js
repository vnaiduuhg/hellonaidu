(function(angular) {
    function clientsSummaryCategoryCtrl($scope, api, utils, $rootScope) {
        const date = new Date();
        const scope = {
            out: utils.out,
            startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
            endDate: new Date(),
            reportList: {
                clientsAccountInfo: {
                    key: "clients-account-info",
                    fr: {
                        title:"Rapport comptes clients",
                        name: "rapport-comptes-clients",
                        description: "Rapport détaillé portant sur les comptes clients de l'agence"
                    },
                    en: {
                        title:"Client accounts",
                        name: "client-accounts-report",
                        description: "Detailed report on agency client accounts"
                    }
                }
            }
        };
        angular.extend($scope, scope);
        
        const scopeMethods = {};
        angular.extend($scope, scopeMethods);
    }

    clientsSummaryCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope'];
    angular.module('atlas').directive('clientsSummaryCategory', function() {
        return {
            scope: {
                getExtractionDataReport: '='
            },
            controller: clientsSummaryCategoryCtrl,
            templateUrl: './employer-profile/directives/statistics/statistics-report/clients-summary-category/clients-summary-category.template.html',
        };
    });
})(angular);