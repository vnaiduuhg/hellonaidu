(function (angular) {
  function workflowSummaryJobCategoryCtrl($scope, api, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      categorySelected: { selected: '' },
      out: utils.out,
      barLabel: utils.out('Nombre de candidats', 'Number of candidates'),
      labels: [],
      numberOfCandidates: [],
      categories: [],
      reportName: utils.out('Statistiques par catégorie d\'emploi', 'Statistics by job category'),
      reportLabel: 'workflow_summary_job_category',
      workflowSummaryJobCategoryReportLoaded: false,
      categoriesLoadingDone: false,
      promiseSuccess: false,
    };
    angular.extend($scope, scope);

    Event.on('companySelected', ($event, company) => {
      fetchWorkflowSummaryJobCategoryReport(company);
    });

    function fetchWorkflowSummaryJobCategoryReportByCategory(category) {
      $scope.numberOfCandidates = [];
      $scope.labels = [];
      angular.forEach($scope.workflowSummaryJobCategoryReport, (report) => {
        if (category.id === report.category_id) {
          $scope.workflowSummaryJobCategoryReportLoaded = true;
          $scope.numberOfCandidates.push(report.num_of_candidate);
          report.stage_fr = report.stage_fr != 'Rejeté' ? report.stage_fr : 'Exclus';
          $scope.labels.push(utils.out(report.stage_fr, report.stage_en));
        }
      });
    }

    function fetchWorkflowSummaryJobCategoryReport(company=null) {
      $scope.categories = [];
      $scope.categorySelected.selected = '';
      $scope.categoriesLoadingDone = false;
      $scope.workflowSummaryJobCategoryReportLoaded = false;
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      }
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|workflow_summary_job_category', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary_job_category', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary_job_category', null, null, dates);
      }        
      promise.then((res) => {
        if (res.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.workflowSummaryJobCategoryReport = res.data.data.result;
          let counter = 0;
          angular.forEach($scope.workflowSummaryJobCategoryReport, (jobReport) => {
            const category = {
              id: jobReport.category_id,
              titleEn: jobReport.job_catogory_en ? jobReport.job_catogory_en : 'None',
              titleFr: jobReport.job_catogory_fr ? jobReport.job_catogory_fr : 'Aucune',
            };
            $scope.categories.push(category);
            counter++;
          });
          if (counter > 0) {
            $scope.categorySelected.selected = $scope.categories[0];
            fetchWorkflowSummaryJobCategoryReportByCategory($scope.categories[0]);
          }
        } else {
          $scope.workflowSummaryJobCategoryReport = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
        $scope.categoriesLoadingDone = true;
      }).catch(() => {
        $scope.categoriesLoadingDone = true;
        $scope.workflowSummaryJobCategoryReport = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    function init() {
      fetchWorkflowSummaryJobCategoryReport();
    }

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        init();
      }
    });

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    const scopeMethods = {
      fetchWorkflowSummaryJobCategoryReportByCategory,
    };
    angular.extend($scope, scopeMethods);
  }
  workflowSummaryJobCategoryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', 'Event', 'statService'];

  angular.module('atlas')
    .directive('workflowSummaryJobCategory', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: workflowSummaryJobCategoryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-workflow/workflow-summary-job-category/workflow-summary-job-category.template.html',
    }));
}(angular));
