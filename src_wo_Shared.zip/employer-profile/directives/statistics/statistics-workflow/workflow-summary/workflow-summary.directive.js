(function (angular) {
  function workflowSummaryCtrl($scope, api, utils, $rootScope, Event, statService) {
    const date = new Date();
    const scope = {
      startDate: new Date(date.setFullYear(date.getFullYear() - 1)),
      endDate: new Date(),
      out: utils.out,
      // currentUser: userData.user, - this doesn't seems to be used
      barLabel: utils.out('Nombre de candidats', 'Number of candidates'),
      labels: [],
      numberOfCandidates: [],
      userJobs: [],
      reportName: utils.out('Statistiques par poste', 'Statistics by job'),
      reportLabel: 'workflow_summary',
      workflowSummaryReportLoaded: false,
      jobSelected: { selected: '' },
      language: $rootScope.language,
      promiseSuccess: false,
      loadingDone: false,
    };
    angular.extend($scope, scope);

    function loadWorkflowSummaryReportByJob(job) {
      $scope.numberOfCandidates = [];
      $scope.labels = [];
      $scope.averageTime = [];
      angular.forEach($scope.workflowSummaryReportData, (jobReport) => {
        if (job.id === jobReport.job_id) {
          $scope.workflowSummaryReportLoaded = true;
          $scope.numberOfCandidates.push(jobReport.num_of_candidate);
          jobReport.stage_fr = jobReport.stage_fr != 'Rejeté' ? jobReport.stage_fr : 'Exclus';
          $scope.labels.push(utils.out(jobReport.stage_fr, jobReport.stage_en));
        }
      });
    }

    function loadWorkflowSummaryReport(company=null) {
      $scope.userJobs = [];
      $scope.jobSelected.selected = '';
      $scope.workflowSummaryReportLoaded = false;
      let promise;
      const dates = {
        start_date: $scope.startDate,
        end_date: $scope.endDate
      };
      $scope.loadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|workflow_summary', 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary', 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'workflow_summary', null, null, dates);
      }
      promise.then((response) => {
        $scope.loadingDone = true;
        if (response.data.status === 'success') {
          $scope.promiseSuccess = true;
          $scope.workflowSummaryReportData = response.data.data.result;
          let counter = 0;
          angular.forEach($scope.workflowSummaryReportData, (jobReport) => {
            const job = {
              id: jobReport.job_id,
              titleEn: jobReport.job_title_en,
              titleFr: jobReport.job_title_fr,
            };
            $scope.userJobs.push(job);
            counter++;
          });
          if (counter > 0) {
            $scope.jobSelected.selected = $scope.userJobs[0];
            loadWorkflowSummaryReportByJob($scope.userJobs[0]);
          }
        } else {
          $scope.workflowSummaryReportData = [];
          $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching your report.', 'Désolé, une erreur s\'est produite lors de la récupération du votre rapport.');
        }
      }).catch(() => {
        $scope.loadingDone = true;
        $scope.workflowSummaryReportData = [];
        $rootScope.api_status('alert-danger', 'Sorry, there was an error. Please try again later or contact support@workland.com', 'Désolé, une erreur s\'est produite. Veuillez réessayer plus tard ou contacter support@workland.com');
      });
    }

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
      if (validatedDates) {
        loadWorkflowSummaryReport();
      }
    });

    const scopeMethods = {
      loadWorkflowSummaryReportByJob,
    };
    angular.extend($scope, scopeMethods);

    Event.on('companySelected', ($event, company) => {
      loadWorkflowSummaryReport(company);
    });
  }
  workflowSummaryCtrl.$inject = ['$scope', 'api', 'utils', '$rootScope', 'Event', 'statService'];

  angular.module('atlas')
    .directive('workflowSummary', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: workflowSummaryCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-workflow/workflow-summary/workflow-summary.template.html',
    }));
}(angular));
