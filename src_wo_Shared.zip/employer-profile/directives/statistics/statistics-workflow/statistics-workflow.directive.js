(function (angular) {
  function statisticsWorkflowCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    Event,
  ) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);
    Event.on('companySelected', ($event, company) => {
    console.log('company', company)
  })
    const scopeMethods = {};
    angular.extend($scope, scopeMethods);
  }

  statisticsWorkflowCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'Event'];
  angular.module('atlas')
    .directive('statisticsWorkflow', () => ({
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgencyAdminRecruiter: '=',
        isAgency: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: statisticsWorkflowCtrl,
      templateUrl: './employer-profile/directives/statistics/statistics-workflow/statistics-workflow.template.html',
    }));
}(angular));
