(function (angular) {
  function statisticsDashboardCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    Event,
    statService,
  ) {
    const scope = {
      out: utils.out,
      timeFilter: 'This year',
      dates: {},
      datesData: {},
      cardsValues: {},
      loadingCardsDone: false,
      loadingDone: false,
    };
    angular.extend($scope, scope);

    function getReportsByJobCategory(company) {
      let promise;
      $scope.loadingDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|job_categories', 'company_account_id', company);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'job_categories', 'client_account_id', company);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'job_categories');
      }
      promise.then((res) => {
        $scope.loadingDone = true;
        if (res.data.status === 'success') {
          $scope.results = res.data.data.result;
        } else {
          $scope.results = [];
          $rootScope.api_status(
            'alert-danger',
            'An error has occurred and statistics by job categories could not be retrieved',
            'Une erreur s\'est produite et l\'aperçu de vos statistiques par les catégories de postes n\'a pu être récupéré',
          );
        }
      }).catch(() => {
        $scope.loadingDone = true;
        $scope.results = [];
        $rootScope.api_status(
          'alert-danger',
          'An error has occurred and statistics by job categories could not be retrieved',
          'Une erreur s\'est produite et l\'aperçu de vos statistiques par les catégories de postes n\'a pu être récupéré',
        );
      });
    }

    function prepareBannerData(data, key) {
      $scope.loadingCardsDone = false;
      const bannerValues = angular.copy(_.find($scope.cardsValuesData, (item) => item.time_period == $scope.timeFilter));
      delete bannerValues.time_period;
      $scope.loadingCardsDone = true;
      return bannerValues;
    }

    function getReportsByCards(company) {
      let promise;
      $scope.loadingCardsDone = false;
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|cards_statistics', 'company_account_id', company);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', 'cards_statistics', 'client_account_id', company);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', 'cards_statistics');
      }
      promise.then((response) => {
        $scope.loadingCardsDone = true;
        const res = response.data;
        if (res.status === 'success') {
          $scope.cardsValuesData = res.data.result;
          $scope.cardsValues = prepareBannerData();
        } else {
          $scope.cardsValuesData = [];
          $rootScope.api_status(
            'alert-danger',
            'An error has occurred and statistics overview could not be retrieved',
            'Une erreur s\'est produite et l\'aperçu de vos statistiques n\'a pu être récupéré',
          );
        }
      }).catch(() => {
        $scope.loadingCardsDone = true;
        $scope.cardsValuesData = [];
        $rootScope.api_status(
          'alert-danger',
          'An error has occurred and statistics overview could not be retrieved',
          'Une erreur s\'est produite et l\'aperçu de vos statistiques n\'a pu être récupéré',
        );
      });
    }

    Event.on('companySelected', ($event, company) => {
      getReportsByCards(company);
      getReportsByJobCategory(company);
    });

    function setFirstDate(period) {
      switch (period) {
        case 'This week':
          $scope.dates.first = $scope.datesData.weekAgo;
          break;
        case 'This month':
          $scope.dates.first = $scope.datesData.monthAgo;
          break;
        case 'This year':
          $scope.dates.first = $scope.datesData.yearAgo;
          break;
        default:
          $scope.dates.first = null;
      }
    }

    function setPeriodDates() {
      const date = new Date();
      const now = moment(); 
      const mondayOfCurrentWeek = now.clone().weekday(1);
      const firstDayOfCurrentMonth = moment().clone().startOf('month');
      const firstDayOfCurrentYear = moment().startOf('year');

      $scope.datesData = {
        today: utils.getTimeFormat(date, 'LL'),
        weekAgo: utils.addTranslationsToMomentDate(mondayOfCurrentWeek, 'LL'),
        monthAgo: utils.addTranslationsToMomentDate(firstDayOfCurrentMonth, 'LL'),
        yearAgo: utils.addTranslationsToMomentDate(firstDayOfCurrentYear, 'LL'),
      };
      $scope.dates.last = $scope.datesData.today;
      setFirstDate($scope.timeFilter);
    }

    $scope.changeTimeFilter = function (timeFilter) {
      $scope.timeFilter = timeFilter;
      setFirstDate(timeFilter);
      $scope.cardsValues = prepareBannerData();
    };

    (() => {
      setPeriodDates();
      getReportsByJobCategory();
      getReportsByCards();
    })();

    const scopeMethods = {
      setPeriodDates,
      getReportsByJobCategory,
      getReportsByCards,
      prepareBannerData,
      setFirstDate,
    };
    angular.extend($scope, scopeMethods);
  }

  statisticsDashboardCtrl.$inject = ['$scope', '$rootScope', 'utils', '_', 'Event', 'statService'];

  angular.module('atlas').directive('statisticsDashboard', () => ({
    scope: {
      newAppliantsStat: '=',
      currentUserAccountId: '=',
      companies: '=',
      isAgencyAdminRecruiter: '=',
      isAgency: '=',
      isConfidentiel: '=',
      validateDates: '=',
    },
    controller: statisticsDashboardCtrl,
    templateUrl: './employer-profile/directives/statistics/statistics-dashboard/statistics-dashboard.template.html',
  }));
}(angular));
