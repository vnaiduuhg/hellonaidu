(function (angular) {
  function selectCompaniesCtrl(
    $scope,
    utils,
    Event,
    $rootScope,
  ) {
    const scope = {
      out: utils.out,
      companySelected: { selected: '' },
      defaultCompanySelectOption: {
        id: null,
        company_name: utils.out('Agence et toutes les entreprises', 'Agency and all companies'),
      },
    };
    angular.extend($scope, scope);

    $scope.tagHandler = function (tag) {
      return null; // official hack to workaround angular issue
    };

    function companySelectedFromList() {
      Event.broadcast('companySelected', {
        company: $scope.companySelected.selected,
      });
      $rootScope.companySelected = { company: $scope.companySelected.selected};
    }

    function init() {
      $scope.companies.unshift($scope.defaultCompanySelectOption);
      $scope.companySelected.selected = $scope.defaultCompanySelectOption;
    }

    init();

    $scope.$on('$destroy', () => {
      $rootScope.companySelected = null;
    })

    const scopeMethods = {
      companySelectedFromList,
    };
    angular.extend($scope, scopeMethods);
  }


  selectCompaniesCtrl.$inject = [
    '$scope',
    'utils',
    'Event',
    '$rootScope',
  ];
  angular.module('atlas')
    .directive('selectCompanies', () => ({
      scope: {
        companies: '=',
        isAgencyAdminRecruiter: '=',
      },
      controller: selectCompaniesCtrl,
      template: require('./select-companies.template.html'),
    }));
}(angular));
