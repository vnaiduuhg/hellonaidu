// eslint-disable-next-line func-names
(function (angular) {
  function csvReportCtrl($scope, utils) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);

    const scopeMethods = {};
    angular.extend($scope, scopeMethods);
  }

  csvReportCtrl.$inject = ['$scope', 'utils'];
  angular.module('atlas').directive('csvReport', () => ({
    scope: {
      reportData: '=',
      getExtractionDataReport: '=',
      startDate: '=?',
      endDate: '=?',
      jobIds: '=?',
      tagIds: '=?',
      btnDisabled: '=?',
      recruiterIds: '=?',
      groupIds: '=?',
      categoryIds: '=?',
      functionIds: '=?',
    },
    controller: csvReportCtrl,
    templateUrl: './employer-profile/directives/statistics/charts/csv-report/csv-report.template.html',
  }));
// eslint-disable-next-line no-undef
}(angular));
