(function (angular) {
  function nesrinemixedChartController($scope, statService) {
    const scope = {
    };
    angular.extend($scope, scope);

    let mixedChart = null;

    function init() {
      if (mixedChart != null) {
        mixedChart.destroy(); // clearing an old instance of chart
      }
      mixedChart = new Chart(document.getElementById('mixedChart'), {
        type: 'doughnut',
        data: {
          datasets: [{
            label: $scope.barLabel,
            data: $scope.barData,
            backgroundColor: statService.getColorsArray($scope.barData.length),
          }],
          labels: $scope.labels,
        },

      });
    }

    $scope.$watch('barData', () => {
      init();
    });
  }
  nesrinemixedChartController.$inject = [
    '$scope', 'statService',
  ];
  angular.module('atlas').directive('nesrinemixedChart', () => ({
    scope: {
      barLabel: '=',
      labels: '=',
      barData: '=',
      reportName: '=',
    },
    controller: nesrinemixedChartController,
    templateUrl: './employer-profile/directives/statistics/charts/nesrinemixed-chart/nesrinemixed-chart.template.html',
  }));
}(angular));
