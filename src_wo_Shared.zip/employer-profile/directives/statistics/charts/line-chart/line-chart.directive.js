(function (angular) {
  function lineChartController($scope, $rootScope, statService, utils, Event, api) {
    const today = new Date();
    const scope = {
      out: utils.out,
      language: $rootScope.language,
      colours: statService.getColorsArray(),
      seriesData: {
        en: ['Applied', 'Hired', 'Rejected'],
        fr: ['Candidatures ', 'Embauchés ', 'Rejetés']
      },
      timeFilter: 'date',
      years: [],
      year_param: false,
      loadingDone: false,
      emptyArray: false,
      emptyYearArray: false,
    };
    angular.extend($scope, scope);

    function initDates() {
      // by year dates init
      const tempStartYearDate = angular.copy(today).setFullYear(today.getFullYear() - 15);
      const y_start = new Date(tempStartYearDate).getFullYear();
      const y_end = today.getFullYear();
      for (let i = y_start; i <= y_end; i++) {
        $scope.years.unshift(i);
      }
      $scope.selectedEndYear = y_end;
      $scope.selectedStartYear = angular.copy(y_end) - 1;
      // by month dates init
      const this_month = angular.copy(today).getMonth();
      const three_months_before = angular.copy(today).getMonth() - 3;
      const year_three_months_ago = this_month <= 2 ? y_end - 1 : y_end;
      $scope.selectedStartMonth = new Date(year_three_months_ago, three_months_before);
      $scope.selectedEndMonth = new Date(y_end, this_month);
      // by date dates init
      $scope.selectedStartDate = new Date(new Date().setDate(today.getDate() - 14));
      $scope.selectedEndDate = angular.copy(today);
      $scope.startDate = angular.copy($scope.selectedStartDate);
      $scope.endDate = angular.copy($scope.selectedEndDate);
    }

    $scope.changeFilters = function (filter) {
      switch (filter) {
        case 'year':
          $scope.startDate = $scope.selectedStartYear;
          $scope.endDate = $scope.selectedEndYear;
          break;
        case 'month':
          $scope.startDate = $scope.selectedStartMonth;
          $scope.endDate = $scope.selectedEndMonth;
          break;
        case 'date':
        default:
          $scope.startDate = $scope.selectedStartDate;
          $scope.endDate = $scope.selectedEndDate;
      }
      $scope.filter = filter;
    };

    $scope.selectStartDate = (date) => {
      $scope.startDate = date;
    };

    $scope.selectEndDate = (date) => {
      $scope.endDate = date;
    };

    function defineApiRequest(report_key, startDate, endDate, company, year_param) {
      let dates = {};
      if (year_param) {
        dates = { start_year: startDate, end_year: endDate };
      } else {
        dates = { start_date: startDate, end_date: endDate};
      }
      let promise;
      if ($scope.isConfidentiel) {
        promise = statService.genericPostRequest('prepared_report_key', report_key, 'company_account_id', company, dates);
      } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
        promise = statService.genericPostRequest('prepared_report_category_key', report_key, 'client_account_id', company, dates);
      } else {
        promise = statService.genericPostRequest('prepared_report_category_key', report_key, null, null, dates);
      }
      return promise;
    }

    // Line Chart Functions
    function getLineChartDateData(startDate, endDate, key=null, company=null) {
      $scope.loadingDone = false;
      $scope.emptyArray = false;
      const promise = defineApiRequest(key, startDate, endDate, company);
      promise.then( (res) => {
        $scope.loadingDone = true;
        if (res.data.status === 'success') {
          const results = res.data.data.result;
          $scope.labels = [];
          $scope.data = [];
          const numAppliedArr = [];
          const numHiredArr = [];
          const numRejectedArr = [];

          for (let i = 0; i < results.length; i++) {
              $scope.labels.push(results[i].date);
              numAppliedArr.push(results[i].num_apply);
              numHiredArr.push(results[i].num_hire);
              numRejectedArr.push(results[i].num_reject);
          }
          $scope.data.push(numAppliedArr, numHiredArr, numRejectedArr);
          const merged = [].concat.apply([], $scope.data);
          $scope.emptyArray = merged.every(item => item === 0);

        } else {
          $rootScope.api_status(
            'alert-danger',
            'No data retrieved for candidates statistics',
            'Aucune donnée récupérée pour les statistiques de candidats',
          );
        }
      }).catch( () => {
        $scope.loadingDone = true;
        $rootScope.api_status(
          'alert-danger',
          'An error has occurred and no data could be retrieved for candidates statistics',
          'Une erreur est survenue et aucune donnée n\'a pu être récupérée pour les statistiques des candidats',
        );
      })
    }

    function getLineChartYearData(startYear, endYear, company=null) {
      $scope.loadingDone = false;
      $scope.emptyYearArray = false;
      $scope.year_param = true;
      const promise = defineApiRequest('candidate_statistics_by_year', startYear, endYear, company, $scope.year_param);
      promise.then( (res) => {
        $scope.loadingDone = true;
        if (res.data.status === 'success') {
          const results = res.data.data.result;
          $scope.labels = [];
          $scope.data = [];
          const numAppliedArr = [];
          const numHiredArr = [];
          const numRejectedArr = [];

          for (let i = 0; i < results.length; i++) {
              $scope.labels.push(results[i].date);
              numAppliedArr.push(results[i].num_apply);
              numHiredArr.push(results[i].num_hire);
              numRejectedArr.push(results[i].num_reject);
          }
          $scope.data.push(numAppliedArr, numHiredArr, numRejectedArr);
          const merged = [].concat.apply([], $scope.data);
          $scope.emptyYearArray = merged.every(item => item === 0);
        } else {
          $rootScope.api_status(
            'alert-danger',
            'No data retrieved for candidates statistics',
            'Aucune donnée récupérée pour les statistiques de candidats',
          );
        }
      }).catch( () => {
        $scope.loadingDone = true;
        $rootScope.api_status(
          'alert-danger',
          'An error has occurred and no data could be retrieved for candidates statistics',
          'Une erreur est survenue et aucune donnée n\'a pu être récupérée pour les statistiques des candidats',
        );
      })
    }

    function getCandidatesStatisticsData(company=null) {
      const validatedDates = validateDates();
      var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
      if (validatedDates) {
        if ($scope.filter != 'year') {
          const action = $scope.filter == 'month' ? 'candidate_statistics_by_month' : 'candidate_statistics_by_date';
          getLineChartDateData($scope.startDate, $scope.endDate, action, company);
        } else {
          getLineChartYearData($scope.startDate, $scope.endDate, company);
        }
      }
    }

    function validateDates() {
      if (!$scope.startDate || !$scope.endDate) {
        $rootScope.api_status(
          'alert-danger',
          'Please choose a start date as well as an end date',
          'Veuillez choisir une date de début ainsi qu\'une date de fin',
          'Missing date!',
          'Date manquante!',
        );
        return false;
      }
      const datesDiff = $scope.filter != 'year'
        ? utils.getDaysDifferenceBetweenDates($scope.startDate, $scope.endDate)
        : $scope.endDate - $scope.startDate;
      if (datesDiff <= 0) {
        $rootScope.api_status(
          'alert-danger',
          'Please choose an end date later than the start date',
          'Veuillez choisir une date de fin ultérieure à la date de début',
          'Invalid dates!',
          'Dates invalides!',
        );
        return false;
      }
      return datesDiff;
    }

    Event.on('companySelected', ($event, company) => {
      getCandidatesStatisticsData(company);
    });

    $scope.$watchGroup(['startDate', 'endDate'], () => {
      getCandidatesStatisticsData();
    });

    (() => {
      initDates();
    })();

    const scopeMethods = {
      initDates,
      getCandidatesStatisticsData,
    };
    angular.extend($scope, scopeMethods);
  }

  lineChartController.$inject = [
    '$scope',
    '$rootScope',
    'statService',
    'utils',
    'Event',
    'api',
  ];
  angular.module('atlas').directive('lineChart', () => {
    return {
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
      },
      controller: lineChartController,
      templateUrl:
                './employer-profile/directives/statistics/charts/line-chart/line-chart.template.html',
    };
  });
}(angular));
