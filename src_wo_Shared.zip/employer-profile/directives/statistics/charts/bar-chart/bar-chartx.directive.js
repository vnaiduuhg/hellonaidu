(function (angular) {
  function barChartxCtrl($scope, utils, $timeout) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);

    let barChartx = null;
    let createTimeout;

    function init() {
      // timeout needed
      createTimeout = $timeout(() => {
        if (barChartx != null) {
          barChartx.destroy(); // clearing an old instance of chart
        }
        barChartx = new Chart(document.getElementById(`barChartx_${$scope.reportLabel}`).getContext('2d'), {
          type: 'bar',
          data: {
            labels: $scope.labels,
            datasets: [
              {
                label: $scope.barLabel,
                type: 'bar',
                data: $scope.barData,
                backgroundColor: 'rgba(197, 172, 255, 0.8)',
              //rgba(165, 250, 196, 0.8) - green; rgba(112, 212, 255, 0.8) - blue
              //rgba(255, 167, 183, 0.8) - pink
              }],

          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  stepSize: 1,
                },
              }],
            },
          },
        });
      }, 100);
    }

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout);
    });

    $scope.$watch('barData', () => {
      init();
    });
  }
  barChartxCtrl.$inject = [
    '$scope',
    'utils',
    '$timeout',
  ];
  angular.module('atlas').directive('barChartx', () => ({
    scope: {
      labels: '=',
      reportName: '=',
      barLabel: '=',
      barData: '=',
      timeData: '=',
      reportLabel: '=',
    },
    controller: barChartxCtrl,
    templateUrl: './employer-profile/directives/statistics/charts/bar-chart/bar-chartx.template.html',
  }));
}(angular));
