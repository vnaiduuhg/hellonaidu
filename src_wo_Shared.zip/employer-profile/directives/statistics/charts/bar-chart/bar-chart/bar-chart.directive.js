(function (angular) {
  function barChartController($scope, $rootScope, statService, utils, Event, api) {
      const today = new Date();
      const scope = {
        out: utils.out,
        labelsArray: statService.getShortMonthsArray(),
        selectedYear: today.getFullYear(),
        series: [],
        years: [],
        labels: [],
        data: [],
        emptyArray: false,
        loadingDone: false,
      };
      angular.extend($scope, scope);

      var rootModelListener = $rootScope.$watch('language', () => {
        $scope.labels = $rootScope.language == 'en' ? $scope.labelsArray.en : $scope.labelsArray.fr;
      });

      (() => {
        const tempStartYearDate = angular.copy(today).setFullYear(today.getFullYear() - 15);
        const startDate = new Date(tempStartYearDate).getFullYear();
        for (let i = startDate; i <= $scope.selectedYear; i++) {
          $scope.years.unshift(i);
        }
        $scope.series = [$scope.selectedYear - 2, $scope.selectedYear - 1, $scope.selectedYear];
        $scope.labels = $rootScope == 'en' ? $scope.labelsArray.en : $scope.labelsArray.fr;
        getAppliedStatisticsReport();
      })();

      function getAppliedStatisticsReport(company=null) {
        let promise;
        const dates = {
          year_select: $scope.selectedYear
        };
        $scope.emptyArray = false;
        $scope.loadingDone = false;
        var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
        if ($scope.isConfidentiel) {
          promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|applied_candidates_statistics', 'company_account_id', company, dates);
        } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
          promise = statService.genericPostRequest('prepared_report_category_key', 'applied_candidates_statistics', 'client_account_id', company, dates);
        } else {
          promise = statService.genericPostRequest('prepared_report_category_key', 'applied_candidates_statistics', null, null, dates);
        }
        promise.then((res) => {
          $scope.loadingDone = true;
          if (res.data.status === 'success') {
            const results = res.data.data.result;
            $scope.colours = statService.getColorsArray(results.length);
            $scope.data = [];
            const firstYearValues = [];
            const secondYearValues = [];
            const thirdYearValues = [];

            for (let i = 0; i < 12; i++) {
                firstYearValues.push(results[i].num_apply);
            }

            for (let i = 12; i < 24; i++) {
                secondYearValues.push(results[i].num_apply);
            }

            for (let i = 24; i < 36; i++) {
                thirdYearValues.push(results[i].num_apply);
            }

            $scope.data.push(
                firstYearValues,
                secondYearValues,
                thirdYearValues
            );
            const merged = [].concat.apply([], $scope.data);
            $scope.emptyArray = merged.every(item => item === 0);
          } else {
            $rootScope.api_status(
                'alert-danger',
                'No data retrieved for applied candidates statistics',
                'Aucune donnée récupérée pour les statistiques d\'application des candidats',
              );
          }
        }).catch((err) => {
            $scope.loadingDone = true;
            $rootScope.api_status(
              'alert-danger',
              'An error has occurred and no data could be retrieved for applied candidates statistics',
              'Une erreur est survenue et aucune donnée n\'a pu être récupérée pour les statistiques d\'application des candidats',
            );
          });
      }

      Event.on('companySelected', ($event, company) => {
        getAppliedStatisticsReport(company);        
      });

      $scope.selectLastYear = function (year) {
        $scope.selectedYear = year;
        $scope.series = [year - 2, year - 1, year];
        getAppliedStatisticsReport();
      };

      const scopeMethods = {
        getAppliedStatisticsReport,
      };
      angular.extend($scope, scopeMethods);
      
      $scope.$on('$destroy', function () {
        // disable the listener
        rootModelListener();
      })
  }

  barChartController.$inject = [
    '$scope',
    '$rootScope',
    'statService',
    'utils',
    'Event',
    'api',
  ]; 
  angular.module('atlas').directive('barChart', () => {
    return {
      scope: {
        currentUserAccountId: '=',
        companies: '=',
        isAgency: '=',
        isAgencyAdminRecruiter: '=',
        isConfidentiel: '=',
        validateDates: '=',
      },
      controller: barChartController,
      templateUrl:
                './employer-profile/directives/statistics/charts/bar-chart/bar-chart/bar-chart.template.html',
    };
  });
}(angular));
