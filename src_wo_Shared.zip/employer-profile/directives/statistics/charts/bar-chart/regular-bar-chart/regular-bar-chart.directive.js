(function (angular) {
  function regularBarChartController($scope, $timeout) {
    const scope = {
    };
    angular.extend($scope, scope);

    let regularBarChart = null;
    let createTimeout;

    function init() {
      // timeout needed
      createTimeout = $timeout(() => {
        if (regularBarChart != null) {
          regularBarChart.destroy(); // clearing an old instance of chart
        }
        regularBarChart = new Chart(document.getElementById(`regularBarChart_${$scope.reportLabel}`), {
          type: 'bar',
          data: {
            datasets: [{
              label: $scope.barLabel,
              data: $scope.barData,
              backgroundColor: 'rgba(197, 172, 255, 0.8)',
              //rgba(165, 250, 196, 0.8) - green; rgba(112, 212, 255, 0.8) - blue
              //rgba(255, 167, 183, 0.8) - pink
            }],
            labels: $scope.labels,
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  stepSize: 1,
                },
              }],
            },
          },
        });
      }, 100);
    }

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout);
    });

    $scope.$watch('barData', () => {
      init();
    });
  }
  regularBarChartController.$inject = [
    '$scope',
    '$timeout',
  ];
  angular.module('atlas').directive('regularBarChart', () => ({
    scope: {
      barLabel: '=',
      labels: '=',
      barData: '=',
      reportName: '=',
      reportLabel: '=',
    },
    controller: regularBarChartController,
    templateUrl: './employer-profile/directives/statistics/charts/bar-chart/regular-bar-chart/regular-bar-chart.template.html',
  }));
}(angular));
