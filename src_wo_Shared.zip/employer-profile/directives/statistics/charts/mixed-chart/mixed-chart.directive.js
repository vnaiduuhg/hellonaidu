(function (angular) {
  function mixedChartController($scope) {
    const scope = {
    };
    angular.extend($scope, scope);

    let mixedChart = null;

    function init() {
      if (mixedChart != null) {
        mixedChart.destroy(); // clearing an old instance of chart
      }
      mixedChart = new Chart(document.getElementById('mixedChart'), {
        type: 'bar',
        data: {
          datasets: [{
            label: $scope.barLabel,
            yAxisID: 'A',
            data: $scope.barData,
            backgroundColor: 'rgba(0, 147, 133, 1)',
            order: 2,
          }, {
            label: $scope.lineLabel,
            yAxisID: 'B',
            data: $scope.lineData,

            // Changes this dataset to become a line
            type: 'line',
            fill: false,
            borderColor: 'rgba(11, 189, 242, 1)',
            pointBackgroundColor: 'rgba(11, 189, 242, 1)',
            order: 1,
          }],
          labels: $scope.labels,
        },
        options: {
          scales: {
            yAxes: [{
              id: 'A',
              type: 'linear',
              position: 'left',
            }, {
              id: 'B',
              type: 'linear',
              position: 'right',
              ticks: {
                beginAtZero: true,
                stepSize: 1,
              },
            }],
          },
        },
      });
    }

    $scope.$watch('barData', () => {
      init();
    });
  }
  mixedChartController.$inject = [
    '$scope',
  ];
  angular.module('atlas').directive('mixedChart', () => ({
    scope: {
      barLabel: '=',
      lineLabel: '=',
      labels: '=',
      barData: '=',
      lineData: '=',
      reportName: '=',
    },
    controller: mixedChartController,
    templateUrl: './employer-profile/directives/statistics/charts/mixed-chart/mixed-chart.template.html',
  }));
}(angular));
