(function (angular) {
  function groupedChartCntrl($scope) {
    const scope = {};
    angular.extend($scope, scope);

    let groupedBarChart = null;

    function init() {
      if (groupedBarChart != null) {
        groupedBarChart.destroy(); // clearing an old instance of chart
      }
      const ctx = document.getElementById('groupedBarChart');
      groupedBarChart = new Chart(ctx, {
        type: 'bar',
        data: {
          datasets: [
            {
              label: $scope.appliedLabel,
              data: $scope.appliedCandidates,
              backgroundColor: 'rgba(197, 172, 255, 0.8)',
              //rgba(197, 172, 255, 0.8) - purple; rgba(112, 212, 255, 0.8) - blue
              //rgba(255, 167, 183, 0.8) - pink; rgba(165, 250, 196, 0.8) - green
            },
            {
              label: $scope.hiredLabel,
              data: $scope.hiredCandidates,
              backgroundColor: 'rgba(255, 167, 183, 0.8)',
            },
          ],
          labels: $scope.labels,
        },
        options: {
          barValueSpacing: 20,
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true,
                stepSize: 1,
              },
            }],
          },
        },
      });
    }

    $scope.$watch('appliedCandidates', () => {
      init();
    });
    $scope.$watch('hiredCandidates', () => {
      init();
    });
  }
  groupedChartCntrl.$inject = ['$scope'];
  angular.module('atlas').directive('groupedBarChart', () => ({
    scope: {
      labels: '=',
      appliedLabel: '=',
      hiredLabel: '=',
      appliedCandidates: '=',
      hiredCandidates: '=',
      reportName: '=',
    },
    controller: groupedChartCntrl,
    templateUrl: './employer-profile/directives/statistics/charts/grouped-bar-chart/grouped-bar-chart.template.html',
  }));
}(angular));
