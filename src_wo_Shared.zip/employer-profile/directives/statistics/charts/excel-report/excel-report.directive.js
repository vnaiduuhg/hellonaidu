(function (angular) {
  function excelReportCtrl($scope, utils, $q) {
    const scope = {
      out: utils.out,
    };
    angular.extend($scope, scope);

    function convertNullValuesToString(array) {
      for (const obj of array) {
        if (typeof obj !== 'object') continue;
        for (k in obj) {
          if (!obj.hasOwnProperty(k)) continue;
          v = obj[k];
          if (v === null || v === undefined) {
            obj[k] = '';
          }
        }
      }
    }

    function extractToExcel(arrayToExport, reportName, typeUpload) {
      if ($scope.reportArrayData) convertNullValuesToString($scope.reportArrayData);
      if (arrayToExport) convertNullValuesToString(arrayToExport);
      window.exportFromJSON({
        data: arrayToExport || $scope.reportArrayData,
        fileName: reportName || $scope.reportName,
        exportType: typeUpload || $scope.downloadType,
      });
    }

    function getReportData() {
      const promises = [];
      let startDate; let endDate; let jobIds; let tagIds; let recruiterIds; let groupIds; let categoryIds; let functionIds;
      if ($scope.startDate) startDate = $scope.startDate;
      if ($scope.endDate) endDate = $scope.endDate;
      if ($scope.jobIds) jobIds = $scope.jobIds;
      if ($scope.tagIds) tagIds = $scope.tagIds;
      if ($scope.recruiterIds) recruiterIds = $scope.recruiterIds;
      if ($scope.groupIds) groupIds = $scope.groupIds;
      if ($scope.categoryIds) categoryIds = $scope.categoryIds;
      if ($scope.functionIds) functionIds = $scope.functionIds;

      const reportPromise = $scope.getExtractionDataReport($scope.reportData.key, startDate, endDate, jobIds, tagIds, recruiterIds, groupIds, categoryIds, functionIds);
      promises.push(reportPromise);
      $q.all(promises).then((result) => {
        const arrayToExport = result[0];
        const reportName = $scope.out($scope.reportData.fr.name, $scope.reportData.en.name);
        const typeUpload = 'xls';
        extractToExcel(arrayToExport, reportName, typeUpload);
      });
    }

    const scopeMethods = {
      getReportData,
      extractToExcel,
    };
    angular.extend($scope, scopeMethods);
  }

  excelReportCtrl.$inject = ['$scope', 'utils', '$q'];
  angular.module('atlas').directive('excelReport', () => ({
    scope: {
      reportData: '=',
      getExtractionDataReport: '=?',
      startDate: '=?',
      endDate: '=?',
      jobIds: '=?',
      tagIds: '=?',
      btnDisabled: '=?',
      recruiterIds: '=?',
      groupIds: '=?',
      categoryIds: '=?',
      functionIds: '=?',
      reportArrayData: '=?',
      reportName: '=?',
      downloadType: '=?',
      isSeparate: '=?',
    },
    controller: excelReportCtrl,
    templateUrl: './employer-profile/directives/statistics/charts/excel-report/excel-report.template.html',
  }));
}(angular));
