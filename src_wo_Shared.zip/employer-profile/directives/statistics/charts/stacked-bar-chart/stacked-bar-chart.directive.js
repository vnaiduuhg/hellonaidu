(function (angular) {
  function stackedBarChartController($scope) {
    const scope = {};
    angular.extend($scope, scope);

    let stackedBarChart = null;

    function init() {
      if (stackedBarChart != null) {
        stackedBarChart.destroy(); // clearing an old instance of chart
      }
      const ctx = document.getElementById('stackedBarChart');
      stackedBarChart = new Chart(ctx, {
        type: 'bar',
        data: {
          datasets: [
            {
              label: $scope.appliedLabel,
              data: $scope.appliedCandidates,
              backgroundColor: 'rgba(165, 250, 196, 0.8)',
              //rgba(197, 172, 255, 0.8) - purple; rgba(112, 212, 255, 0.8) - blue
              //rgba(255, 167, 183, 0.8) - pink; rgba(165, 250, 196, 0.8) - green
              order: 1,
            },
            {
              label: $scope.hiredLabel,
              data: $scope.hiredCandidates,
              backgroundColor: 'rgba(112, 212, 255, 0.8)',
              order: 2,
            },
          ],
          labels: $scope.labels,
        },
        options: {
          scales: {
            yAxes: [{
              stacked: true,
              ticks: {
                beginAtZero: true,
                stepSize: 1,
              },
            }],
            xAxes: [{
              stacked: true,
              ticks: {
                beginAtZero: true,
              },
            }],
          },
        },
      });
    }

    $scope.$watch('appliedCandidates', () => {
      init();
    });
    $scope.$watch('hiredCandidates', () => {
      init();
    });
  }

  stackedBarChartController.$inject = ['$scope'];
  angular.module('atlas').directive('stackedBarChart', () => ({
    scope: {
      labels: '=',
      appliedLabel: '=',
      hiredLabel: '=',
      appliedCandidates: '=',
      hiredCandidates: '=',
      reportName: '=',
    },
    controller: stackedBarChartController,
    templateUrl: './employer-profile/directives/statistics/charts/stacked-bar-chart/stacked-bar-chart.template.html',
  }));
}(angular));
