(function (angular) {
  function nesrinebarChartController($scope) {
    const scope = {};
    angular.extend($scope, scope);

    let nsimplebarChart = null;

    function init() {
      if (nsimplebarChart != null) {
        nsimplebarChart.destroy(); // clearing an old instance of chart
      }
      nsimplebarChart = new Chart(document.getElementById('simplebarChart'), {
        type: 'bar',
        data: {
          labels: $scope.labels,
          datasets: [{
            label: $scope.barLabel,
            data: $scope.barData,
            backgroundColor: 'rgba(165, 250, 196, 0.8)',
              //rgba(197, 172, 255, 0.8) - purple; rgba(112, 212, 255, 0.8) - blue
              //rgba(255, 167, 183, 0.8) - pink; rgba(165, 250, 196, 0.8) - green
          }, {
            label: $scope.barLabel1,
            data: $scope.barData1,
            backgroundColor: 'rgba(112, 212, 255, 0.8)',
          },
          ],
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true,
                stepSize: 1,
              },
            }],
          },
        },
      });
    }

    $scope.$watch('barData', () => {
      init();
    });

    $scope.$watch('barData1', () => {
      init();
    });
  }
  nesrinebarChartController.$inject = [
    '$scope',
  ];
  angular.module('atlas').directive('nesrinebarChart', () => ({
    scope: {
      barLabel: '=',
      barLabel1: '=',
      labels: '=',
      barData: '=',
      barData1: '=',
      reportName: '=',
    },
    controller: nesrinebarChartController,
    templateUrl: './employer-profile/directives/statistics/charts/nesrinebar-chart/nesrinebar-chart.template.html',
  }));
}(angular));
