(function (angular) {
    function donutChartController(
      $scope,
      $rootScope,
      statService,
      utils,
      Event,
      api,
    ) {
      const date = new Date();
      const scope = {
        out: utils.out,
        init,
        loadingDone: false,
      };
      angular.extend($scope, scope);

      function init() {
        const tempStartDate = angular.copy(date).setFullYear(date.getFullYear() - 1);
        $scope.startDate = new Date(tempStartDate);
        $scope.endDate = angular.copy(date);
      }

      $scope.selectStartDate = function (date) {
        $scope.startDate = date;
      };

      $scope.selectEndDate = function (date) {
        $scope.endDate = date;
      };

      function getSourceStatisticsData(company=null) {
        let promise;
        const dates = {
          start_date: $scope.startDate,
          end_date: $scope.endDate
        };
        $scope.loadingDone = false;
        var company = company ? company : $rootScope.companySelected ? $rootScope.companySelected : null;
        if ($scope.isConfidentiel) {
          promise = statService.genericPostRequest('prepared_report_key', 'admin|workland|source_statistics_by_date', 'company_account_id', company, dates);
        } else if ($scope.isAgency || $scope.isAgencyAdminRecruiter) {
          promise = statService.genericPostRequest('prepared_report_category_key', 'source_statistics_by_date', 'client_account_id', company, dates);
        } else {
          promise = statService.genericPostRequest('prepared_report_category_key', 'source_statistics_by_date', null, null, dates);
        }
        promise.then((res) => {
          $scope.loadingDone = true;
          if (res.data.status === 'success') {
            const results = res.data.data.result;
            $scope.labels = [];
            $scope.data = [];
            if(results.length) {
                for (let i = 0; i < results.length; i++) {
                    $scope.labels.push(results[i].source_name);
                    $scope.data.push(results[i].num_candidate);
                }
            }            
            $scope.colours = statService.getColorsArray(results.length);
          } else {
            $rootScope.api_status(
              'alert-danger',
              'No data retrieved for candidates by source statistics',
              'Aucune donnée récupérée pour les statistiques candidats par source',
            );
          }           
        }).catch((err) => {
          $scope.loadingDone = true;
          $rootScope.api_status(
            'alert-danger',
            'An error has occurred and no data could be retrieved for candidates by source statistics',
            'Une erreur est survenue et aucune donnée n\'a pu être récupérée pour les statistiques candidats par source',
          );
        });
      }

      Event.on('companySelected', ($event, company) => {
        getSourceStatisticsData(company);          
      });

      $scope.$watchGroup(['startDate', 'endDate'], () => {
        const validatedDates = $scope.validateDates($scope.startDate, $scope.endDate);
        if (validatedDates) {
          getSourceStatisticsData();
        }
      });

      init();
    }

    donutChartController.$inject = [
      '$scope',
      '$rootScope',
      'statService',
      'utils',
      'Event',
      'api',
    ];

    angular.module('atlas').directive('donutChart', () => {
      return {
        scope: {
          currentUserAccountId: '=',
          companies: '=',
          isAgency: '=',
          isAgencyAdminRecruiter: '=',
          isConfidentiel: '=',
          validateDates: '=',
        },
        controller: donutChartController,
        templateUrl:
                  './employer-profile/directives/statistics/charts/donut-chart/donut-chart.template.html',
      };
    });
}(angular));
