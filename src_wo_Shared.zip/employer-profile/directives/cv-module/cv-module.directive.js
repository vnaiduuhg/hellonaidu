(function (angular) {
  function cvModuleCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    worklandLocalize,
    $uibModal,
    $timeout,
    $q,
    _,
    storageService,
  ) {
      let createTimeout;
      let createIframeTimeout;

      function clearCVTabMsg() {
        $scope.uploadDocFail = false;
        $scope.noDocument = false;
      } 

      function selectDocument(doc) {
        $scope.showingFile = true;
        clearCVTabMsg();
        utils.hideClasses();
        if (doc) {
          $scope.file = doc;
          const url = $scope.file;
          const extension = doc.file_name.toLowerCase().split('.').pop();
          switch (extension) {
             case "pdf":
              navigator.pdfViewerEnabled ? utils.showNativePdfFile(doc) : utils.showPdfFile(doc);
            break;
            case "ppt":
            case "pptx":
            case "doc":
            case "docx":
            case "xls":
            case "xlsx":
            case "odt":
              utils.showOfficeFile(doc); 
              break;
            case "png":
            case "tif": 
            case "tiff": 
            case "bmp":
            case "jpg":
            case 'jpeg':
            case 'gif':
              utils.showImage(doc);
              break;
            case 'txt':
              utils.showTxtFile(doc);
              break;
            default:
              window.document.getElementById('Enable-docViewer').style.display = 'block';
          }
          createTimeout = $timeout(() => {
            $scope.showingFile = false;
          }, 1000);          
          // Button Events
          $scope.noDocument = false;
          $scope.documentsLoader = false;
        } else {
          $scope.showingFile = false;
          $scope.noDocument = true;
          $scope.file = [];
          $scope.documentsLoader = false;
          window.document.getElementById('Enable-docViewer2').style.display = 'block';
        }
      }

      function showFirstAvailableDocument(candidate) {
        // eslint-disable-next-line max-len
        if (candidate && candidate.application_documents && candidate.application_documents.length > 0) {
          selectDocument(candidate.application_documents[0]);
        } else {
          selectDocument();
        }
      }

      function viewDocumentsInCvTab(openDocument, fromTemplate = false) {
        clearCVTabMsg();
        // condition to be revised when matching service will be up again
        if ($scope.candidate.match && $scope.candidate.stage === "Matched") {
          if ($scope.selectedCandidates.length === 1) {
            if ($scope.isClient && !$scope.isPremiumClient) {
              // eslint-disable-next-line no-nested-ternary
              $scope.openingDocument = openDocument === 'openSelectedDocument' ? 'openPersonalityReport' : openDocument === 'openPreSelection' ? '' : openDocument;
            } else {
              // eslint-disable-next-line eqeqeq
              $scope.openingDocument = openDocument != 'openSelectedDocument' ? openDocument : 'openPersonalityReport';
            }
          } else if ($scope.selectedCandidates.length > 1) {
            $scope.openingDocument = '';
          }
        } else if ($scope.isClient && !$scope.isPremiumClient) {
          $scope.openingDocument = '';
        } else {
          $scope.openingDocument = openDocument;
        }

        // for CRM - when we select|unselect candidates the module is reinitialized, so we loose the open tab
        if ($scope.isCrmCandidates) $scope.setOpenedPanelOnCvModule({value: $scope.openingDocument});

        // opening the right tab: keep the aside state when we toggle the tab, and open the right tab when select|unselect candidates on CRM
        if ($scope.openingDocument === 'openSelectedDocument') {
          document.getElementById('collapseFive').classList.remove("show");
          const accordionBtn = document.getElementById('collapseOne');
          fromTemplate ? accordionBtn.classList.toggle("show") : accordionBtn.classList.add("show");
          if (!$scope.isCrmCandidates) document.getElementById('collapseFour').classList.remove("show");
        } else if ($scope.openingDocument === 'docusignDocViewer') {
          document.getElementById('collapseOne').classList.remove("show");
          const accordionBtn = document.getElementById('collapseFive');
          fromTemplate ? accordionBtn.classList.toggle("show") : accordionBtn.classList.add("show");
          if (!$scope.isCrmCandidates) document.getElementById('collapseFour').classList.remove("show");
          if (fromTemplate) selectFirstDocusignEnvelope();
        } else if ($scope.openingDocument === 'openPreSelection') {
          document.getElementById('collapseOne').classList.remove("show");
          document.getElementById('collapseFive').classList.remove("show");
          const accordionBtn = document.getElementById('collapseFour');
          fromTemplate ? accordionBtn.classList.toggle("show") : accordionBtn.classList.add("show");
        }
      }

      function removeCandidateDocs(selectedCandidates) {
        // eslint-disable-next-line no-plusplus
        /* always start from the end of array when splicing indexes */
        for (let i = $scope.allSelectedDocuments.length - 1; i >= 0; i--) {
          let isExist = false;
          // eslint-disable-next-line no-plusplus
          for (let j = 0; j < selectedCandidates.length; j++) {
            if (+$scope.allSelectedDocuments[i].candidate_id === +selectedCandidates[j].user_id) {
              isExist = true;
            }
          }
          if (!isExist) {
            $scope.allSelectedDocuments.splice(i, 1);
          }
        }
      }

      function checkSelectedDocuments(candidate) {
        _.each($scope.allSelectedDocuments, doc => {
          if (+doc.candidate_id === +candidate.user_id) {
            // hack to select just one time a duplicated document
            let count = 0;
            for (let i=0; i<candidate.application_documents.length; i++) {
              if (+candidate.application_documents[i].file_version_id === +doc.file_version_id
                  && !candidate.application_documents[i].isChecked) {
                ++count;
                candidate.application_documents[i].isChecked = count === 1 ? true : false;
              }
            }
          }
        });
      }

      function getCandidateDoc(candidate) {
        candidate.application_documents = [];
        $scope.noApplication = false;
        // $scope.jobApplicationId comes from the candidate profile, so here it became the same for everybody and messed up loading documents when there was no application
        if ($scope.isCrmCandidates) {
          if($scope.jobApplicationId) {
            candidate.application_id =  $scope.jobApplicationId;
          } else if (candidate.applicationList.length > 0 ) {
            const application = candidate.applicationList.find(element => element.job_id === $scope.crmJobCandidate.selected.id);
            candidate.application_id = application.id;
          } else {
            candidate.application_id = '';
          }
          $scope.jobApplicationId = candidate.application_id;
        } else if (!$scope.isCrmCandidates && (typeof candidate.application_id === 'undefined' || candidate.application_id == '')) {
          candidate.application_id = '';
          $scope.noApplication = true;
        }

        if (typeof candidate.application_id !== 'undefined' && candidate.application_id !== '') {
          $scope.documentsLoader = true;
          candidate.loadingDocs = true;
          
          const  promise = api.service_post('toolkit', `document-manager/quick-apply/employer-fetch?document_application_id=${candidate.application_id}`, {});
          return promise.then((response) => {
            if (response.data.status === 'success') {
              candidate.application_documents = response.data.message;
              angular.forEach(candidate.application_documents, (doc) => {
                doc.descriptionFr =  doc.translations?.fr?.description ?  doc.translations?.fr?.description : null;
                doc.descriptionEn =  doc.translations?.en?.description ?  doc.translations?.en?.description : null;
                doc.docNameFr = doc.descriptionFr ? doc.descriptionFr : doc.type_fr;
                doc.docNameEn = doc.descriptionEn ? doc.descriptionEn : doc.type_en;
                doc.docTranslatedName = $scope.out(doc.docNameFr, doc.docNameEn);
              });
              if ($scope.allSelectedDocuments.length > 0 && candidate.application_documents.length > 0) {
                checkSelectedDocuments(candidate);
              }
            } else {              
              selectDocument();
            }
            viewDocumentsInCvTab($scope.openingDocument ?? 'openSelectedDocument');
            candidate.loadingDocs = false;
          }).catch(() => {
            $scope.uploadDocFail = true;
            $scope.documentsLoader = false;
            candidate.loadingDocs = false;
          });
        } else if (candidate.match && candidate.stage === "Matched") {
          viewDocumentsInCvTab('openPersonalityReport');
        } else {
          $scope.noDocument = true;
        }
      }

      function selectFirstDocusignEnvelopToDisplay() {
        const candidateHasEnvelope = $scope.docusignApplications.find(c => c.docusign_envelopes?.length > 0);
        if (candidateHasEnvelope) {
          selectedEnvelope(candidateHasEnvelope.docusign_envelopes[0]);
        } else {
          $scope.envelopeIdClicked = null;
          $scope.docusignApplicationsLoading = false;
          $scope.docusignEnvelopesDisplay = 0;
        }
      }

      function selectFirstDocusignEnvelope() {
        if (document.getElementById('collapseFive').classList.contains("show")) {
          $scope.docusignApplicationsLoading = true;
          if (document.getElementById('webUrl')) document.getElementById('webUrl').style.display = "none";
          $timeout(() => {
            selectFirstDocusignEnvelopToDisplay();
          }, 100);
        }
      }

      function selectedEnvelope(envelope) {
        $scope.envelopeIdClicked = envelope.envelopeId;
        const docusignUrlSrc = decodeURI(envelope.url);
        utils.showWebUrl(docusignUrlSrc);
        $scope.docusignApplicationsLoading = false;
        $scope.docusignEnvelopesDisplay = 1;
      }

      function prepareDocusignData(data) {
        data.forEach(d => {
          const user = $scope.selectedCandidates.find(c => +c.application_id === +d.id);
          d.candidateName = user ? `${user.first_name} ${user.last_name}` : null;
          if (d.docusign_envelopes.length > 0) {
            d.docusign_envelopes.forEach((envelope) => {
              envelope.statustranslation = utils.translateDocusignEnvelopesStatus(envelope.status);
            })
          }
        });

        return data;
      }

      function prepareDocusignDataForCRMCandidates(data, arrayOfApplicationIds) {
        const arrayOfCandidates = [];
        const noApplicationArrayOfCandidates = [];
        $scope.candidatesWOApplication = [];
        angular.forEach($scope.selectedCandidates, (candidate) => {
          candidate.candidateName = `${candidate.first_name} ${candidate.last_name}`;
          if (arrayOfApplicationIds.includes(+candidate.application_id || +candidate.currentApplicationId)) {
            const hasApplication = data.find(a => +a.id === (+candidate.application_id || +candidate.currentApplicationId));
            if (hasApplication && hasApplication.docusign_envelopes?.length > 0) {
              hasApplication.docusign_envelopes.forEach((envelope) => {
                envelope.statustranslation = utils.translateDocusignEnvelopesStatus(envelope.status);
              })
            }
            hasApplication.candidateName = candidate.candidateName;
            arrayOfCandidates.push(hasApplication);
          } else {
            noApplicationArrayOfCandidates.push(candidate);
          }
        });

        $scope.candidatesWOApplication = noApplicationArrayOfCandidates;
        return arrayOfCandidates;
      }

      function getDocusignDocuments(arrayOfApplicationIds) {
        $scope.docusignApplicationsError = false;
        $scope.docusignCredentialsError = false;
        $scope.docusignUnsyncedError = false;
        api.service_get(
          "e-signing",
          "docusign/envelopes",
          {"application_ids[]": arrayOfApplicationIds}
        ).then((response) => {
          if (response.status === 200 && response?.data?.data) {
            if (!Array.isArray(response.data.data)) {
              const tempDocusignApplications = Object.keys(response.data.data).map((k) => response.data.data[k]);
              if (!$scope.isCrmCandidates) {
                $scope.docusignApplications = prepareDocusignData(tempDocusignApplications);
              } else {
                $scope.docusignApplications = prepareDocusignDataForCRMCandidates(tempDocusignApplications, arrayOfApplicationIds);
              }

              if ($scope.openingDocument === "docusignDocViewer") {
                selectFirstDocusignEnvelopToDisplay();
              } else {
                $scope.docusignApplicationsLoading = false;
              }
            }
          } else {
            $scope.docusignApplicationsError = true;
            $scope.docusignApplicationsLoading = false;
          }
        }).catch((error) => {
          switch(error.status) {
            case 400:
              if (error.data?.error && error.data.error === "invalid_grant") {
                $scope.docusignCredentialsError = true;
              } else {
                $scope.docusignApplicationsError = true;
              }
              break;
            case 401:
              $rootScope.api_status(
                "alert-danger",
                "Your session has expired, please login again",
                "Votre session est expirée, veuillez vous connecter à nouveau"
              );
              $scope.docusignApplicationsError = true;
              break;
            case 403:
              $rootScope.api_status(
                "alert-danger",
                "You do not have the required permissions to get docusign envelopes",
                "Vous n'avez pas les permissions nécessaires pour récupérer les envelopppes Docusign"
              );
              $scope.docusignApplicationsError = true;
              break;
            case 404:
              $scope.docusignUnsyncedError = true;
              break;
            default:
              $scope.docusignApplicationsError = true;
          }
          $scope.docusignApplicationsLoading = false;
        });
      }

      function getDocumentsRequest(arrayOfApplicationIds) {
        $scope.documentsRequestError = false;
        api.service_post(
          "toolkit",
          "docutransfer/document-requests/search",
          {application_ids: arrayOfApplicationIds}
        ).then(response => {
          if (response.status === 200 && Array.isArray(response.data)) {
            let requests = {};
            response.data.forEach(r => {
              if (!requests[r.recipient_user_id]) {
                requests[r.recipient_user_id] = [];
              }
              // uncomment to debug missing translations -> r.send_request_documents.forEach(d => { delete d.translations.en; });
              // Check if file was already selected before candidate selection changed. If so, preserve selection
              r.send_request_documents.forEach(send_request_document => {
                send_request_document.sent_files.forEach(file => {
                  file.isChecked = $scope.sendRequestFiles[file.id] && $scope.sendRequestFiles[file.id].isChecked;
                });
              });
              requests[r.recipient_user_id].push(r);
            });
            $scope.documentsRequests = requests;
            $scope.documentsRequestLoading = false;
          } else {
            $scope.documentsRequestError = true;
            $scope.documentsRequestLoading = false;
          }
        }).catch(error => {
          switch(error.status) {
            case 401:
              $rootScope.api_status(
                "alert-danger",
                "Your session has expired, please login again",
                "Votre session est expirée, veuillez vous connecter à nouveau"
              );
              break;
            case 403:
              $rootScope.api_status(
                "alert-danger",
                "You do not have the required permissions to get documents requests",
                "Vous n'avez pas les permissions nécessaires pour récupérer les demandes de documents"
              );
              break;
          }

          $scope.candidateIsOpen = 0;
          $scope.documentsRequestLoading = false;
          $scope.documentsRequestError = true;
          if ($scope.firstInit) $scope.firstInit = false;
        });
      };

      function getSentFilePublicUrl(file) {
        return api.service_get(
          "toolkit",
          `docutransfer/document-requests/send-request-documents/sent-files/${file.id}/url`
        ).then(response => {
          if (response.status === 200 && response.data && response.data.url) {
            return response.data.url;
          }
        });
      }

      function createDocumentFromSentRequestFile(file, url, candidate) {
        const doc = {
          candidate_id: candidate.user_id,
          candidate_name: `${candidate.first_name} ${candidate.last_name}`,
          original_file: file.original_file,
          file_name: file.file_name,
          isSendRequest: true,
          isChecked: file.isChecked,
          url: url,
        };

        // cache the converted document object to be used like a regular document
        // and not a send request document when sharing, uploading, etc.
        $scope.sendRequestFiles[file.id] = doc;

        return doc;
      }

      function getDocumentFromSentRequestFile(file, candidate) {
        return (!$scope.sendRequestFiles[file.id]
          ? getSentFilePublicUrl(file).then(url => 
              // convert and cache file object to be reusable as a document to
              // be printed, shared and downloaded
              createDocumentFromSentRequestFile(file, url, candidate)
            )
          : Promise.resolve()
        ).then(() => $scope.sendRequestFiles[file.id]);
      }

      function addOrRemoveSendRequestDocumentToList(file, candidate) {
        return getDocumentFromSentRequestFile(file, candidate)
          .then(doc => {
            // select or unselect
            const i = $scope.allSelectedDocuments.findIndex(d => d === doc);
            
            if (!~i) {
              $scope.allSelectedDocuments.push(doc);
            } else {
              $scope.allSelectedDocuments.splice(i, 1);
            }
          });
      }

      function selectSendRequestDocument(file, candidate) {
        return getDocumentFromSentRequestFile(file, candidate)
          .then(doc => selectDocument(doc));
      }

      // no documents uploaded for any request types
      function isEmptySendRequestDocument(doc) {
        return !doc.send_request_documents.some(r => r.sent_files.length);
      }

      function setCurrentApplicationIdToCandidates(applications) {
        angular.forEach($scope.selectedCandidates, candidate => {
          candidate.currentApplicationId = null;
          angular.forEach(applications, (application) => {
            if (+candidate.user_id === +application.candidate_user_id && +$scope.jobId === +application.job_id) {
              candidate.currentApplicationId = application.id;
            }
          });
        });
      }

      function findApplicationsInCommonJobList(job) {
        $scope.multipleDocumentsLoading = true;
        utils.hideClasses();
        $scope.jobId = job.id;
        $scope.jobRequestId = job.account_id;
        $scope.jobTitle = job.translations[1].title;
        $scope.jobTitleEn = job.translations[0].title;
        $scope.jobExpired = utils.isDateExpired(job.expiry_date);
        $scope.jobExpiryDate = utils.toDateStr(utils.toDateObj(job.expiry_date));
        $scope.selectedJob = true;
        const employer_account_id = +storageService.getItem('account_id');
        const candidateUserIds = $scope.selectedCandidates.map(element => +element.user_id);
        angular.forEach($scope.selectedCandidates, (candidate) => { candidate.application_documents = []; candidate.applied = false; });
        const params = {
          candidate_user_id: candidateUserIds,
          status: 'submitted',
          job_id: [job.id],
        };
        // confidentiel access to all candidates
        if (employer_account_id != 336) {
          params.employer_account_id = [employer_account_id];
        }
        if ($rootScope.currentUser.permissions.isAgency) {
          params.employer_account_id = $scope.clientIds;
        }
        return api.service_post('application', 'application/read-all', params)
          .then((response) => {
            $scope.noApplicationFound = response.data.length < 1 ? true : false;
            const applications = response.data;
            setCurrentApplicationIdToCandidates(applications);
            let commonApplicationIds = [];
            commonApplicationIds = applications.map(element => element.id);
            const promises = [];
            angular.forEach(commonApplicationIds, (appId) => {
              const  promise = api.service_post('toolkit', `document-manager/quick-apply/employer-fetch?document_application_id=${appId}`, {})
              .then((response) => {
                if (response.data.status === 'success') {
                  angular.forEach($scope.selectedCandidates, (candidate) => {
                    angular.forEach(response.data.message, (applicationDocuments)=>{
                      if(+candidate.user_id === +applicationDocuments.candidate_id) {
                        candidate.application_documents = response.data.message;
                        candidate.applied = true;
                        // not sure if needed here
                        if ($scope.allSelectedDocuments.length > 0 && candidate.application_documents.length > 0) {
                          checkSelectedDocuments(candidate);
                        }
                      }
                    })
                  })                  
                } else {              
                  selectDocument();
                }
                viewDocumentsInCvTab($scope.openingDocument ?? 'openSelectedDocument');
              }).catch(() => {
                $scope.uploadDocFail = true;
                $scope.multipleDocumentsLoading = false;
              });
              promises.push(promise);
            });
            $q.all(promises).then(()=> {
              $scope.multipleDocumentsLoading = false;
              showFirstAvailableDocument($scope.selectedCandidates[0]);
              getSumOfDocumentsOfSelectedCands();
            })
          }).catch(()=>{
            $scope.multipleDocumentsLoading = false;
          })
      }

      function setArrayOfApplicationIds(attribute) {
        return _.pluck($scope.selectedCandidates, attribute).filter(element => element);
      }

      // init
      (() => {
        // bug with CRM - we now set the open tab on viewDocumentsInCvTab
        document.getElementById('collapseOne').classList.remove("show");
        document.getElementById('collapseFive').classList.remove("show");
        if (!$scope.isCrmCandidates) {
          $scope.$watchCollection('selectedCandidates', (selectedCandidates) => {
            $scope.docusignEnvelopesDisplay = -1;
            $scope.candidatesWOApplication = [];
            if ($scope.openingDocument === "docusignDocViewer") {
              if (document.getElementById('webUrl')) document.getElementById('webUrl').style.display = "none";
              $scope.docusignApplicationsLoading = true;
            }
            const arrayOfApplicationIds = setArrayOfApplicationIds("application_id");
            $scope.candidate = $scope.selectedCandidates[0];
            angular.forEach(selectedCandidates, (candidate) => {
              candidate.applied = true;
            })
            let promises = [];
            if (selectedCandidates.length > $scope.oldSelectedCandidatesLength) {
              if( (selectedCandidates.length - $scope.oldSelectedCandidatesLength) > 1) {
                angular.forEach(selectedCandidates, (candidate) => {
                  promises.push(getCandidateDoc(candidate));
                })
                $q.all(promises).then(()=> {
                  showFirstAvailableDocument($scope.candidate);
                  getSumOfDocumentsOfSelectedCands();
                })
              } else {
                const promise = getCandidateDoc(selectedCandidates[selectedCandidates.length - 1]);
                promises.push(promise);
                $q.all(promises).then(()=> {
                  showFirstAvailableDocument(selectedCandidates[0]);
                  getSumOfDocumentsOfSelectedCands();
                })
              }
              getDocumentsRequest(arrayOfApplicationIds);
              getDocusignDocuments(arrayOfApplicationIds);
            } else {
              if (selectedCandidates.length === 1) {
                $scope.allSelectedDocuments = [];
              }
              const promise = getCandidateDoc($scope.candidate);
              promises.push(promise);
              $q.all(promises).then(()=> {
                showFirstAvailableDocument($scope.candidate);
                getSumOfDocumentsOfSelectedCands();
              })
              removeCandidateDocs(selectedCandidates);
              getDocumentsRequest(arrayOfApplicationIds);
              getDocusignDocuments(arrayOfApplicationIds);
            }
            $scope.oldSelectedCandidatesLength = selectedCandidates.length;
          });
        } else {
          $scope.openingDocument = $scope.openedPanelOnCvModule ?? "openSelectedDocument";
          $scope.$watchCollection('selectedCandidates', (selectedCandidates) => {
            $scope.docusignEnvelopesDisplay = -1;
            $scope.candidatesWOApplication = [];
            if ($scope.openingDocument === "docusignDocViewer") {
              if (document.getElementById('webUrl')) document.getElementById('webUrl').style.display = "none";
              $scope.docusignApplicationsLoading = true;
            }
            $scope.candidate = $scope.selectedCandidates[0];
            let promises = [];
            let removeNullJobIndex; let nullJobOption;
            if (selectedCandidates.length === 1) { //init or 1 candidate left after removal
                $scope.allSelectedDocuments = [];
                $scope.candidate.applied = $scope.candidate.applicationList.length > 0 ? true : false;
                nullJobOption = $scope.candidate.jobList.find(element => element.id == null);
                removeNullJobIndex = $scope.candidate.jobList.indexOf(nullJobOption);
                if(removeNullJobIndex >=0) { $scope.candidate.jobList.splice(removeNullJobIndex, 1); }
                if(!$scope.selectedJob) {
                  $scope.crmJobCandidate.selected = $scope.candidate.jobList[0];
                  $scope.jobTitle = $scope.candidate.jobList[0].translations[1].title;
                  $scope.jobTitleEn = $scope.candidate.jobList[0].translations[0].title;
                  $scope.jobExpired = utils.isDateExpired($scope.candidate.jobList[0].expiry_date);
                  $scope.jobExpiryDate = utils.toDateStr(utils.toDateObj($scope.candidate.jobList[0].expiry_date));
                  $scope.jobId = $scope.candidate.jobList[0].id;
                }
                const promise = getCandidateDoc($scope.candidate);
                promises.push(promise);
                $q.all(promises).then(()=> {
                  showFirstAvailableDocument($scope.candidate);
                  getSumOfDocumentsOfSelectedCands();
                  const arrayOfApplicationIds = setArrayOfApplicationIds("application_id");
                  getDocumentsRequest(arrayOfApplicationIds);
                  getDocusignDocuments(arrayOfApplicationIds);
                });
            } else if (selectedCandidates.length > 1) {
              const promise = findApplicationsInCommonJobList($scope.commonJobList[0]); //add and remove by 1; select all
              promises.push(promise);
              $q.all(promises).then(()=> {
                $scope.crmJobCandidate.selected = $scope.commonJobList[0];
                const arrayOfApplicationIds = setArrayOfApplicationIds("currentApplicationId");
                getDocumentsRequest(arrayOfApplicationIds);
                getDocusignDocuments(arrayOfApplicationIds);
              });
            } else {
              $scope.crmJobCandidate.selected = '';
              $scope.selectedCandidates = [];
              $scope.noDocument = true;
              utils.hideClasses();
              $scope.documentsLoader = false; //deselect all
              $scope.docusignApplicationsLoading = false;
            }
          })
        }
      }) ();

      function changeJob(job) {
        if (job) {
          utils.hideClasses();
          let promises = [];
          $scope.jobId = job.id;
          $scope.jobApplicationId = job.job_application_id;
          $scope.jobRequestId = job.account_id;
          $scope.jobTitle = job.translations[1].title;
          $scope.jobTitleEn = job.translations[0].title;
          $scope.jobExpiryDate = utils.toDateStr(utils.toDateObj(job.external_expiry_date));
          $scope.selectedJob = true;
          $scope.allSelectedDocuments = [];
          if ($scope.openingDocument === "docusignDocViewer") {
            if (document.getElementById('webUrl')) document.getElementById('webUrl').style.display = "none";
            $scope.docusignApplicationsLoading = true;
          }

          if ($scope.selectedCandidates.length === 1) {
            $scope.selectedCandidates = [];
            $scope.selectedCandidates.push($scope.candidate);
            const promise = getCandidateDoc($scope.candidate);
            promises.push(promise);
            $q.all(promises).then(()=> {
              showFirstAvailableDocument($scope.candidate);
              getSumOfDocumentsOfSelectedCands();
              const arrayOfApplicationIds = setArrayOfApplicationIds("application_id");
              getDocumentsRequest(arrayOfApplicationIds);
              getDocusignDocuments(arrayOfApplicationIds);
            })
          } else if ($scope.selectedCandidates.length > 1) {
            const promise = findApplicationsInCommonJobList(job); //add and remove by 1; select all
            promises.push(promise);
            $q.all(promises).then(()=> {
              $scope.crmJobCandidate.selected = job;
              const arrayOfApplicationIds = setArrayOfApplicationIds("currentApplicationId");
              getDocumentsRequest(arrayOfApplicationIds);
              getDocusignDocuments(arrayOfApplicationIds);
            });
          } else {
            $scope.crmJobCandidate.selected = '';
            $scope.selectedCandidates = [];
            $scope.noDocument = true;
            $scope.documentsLoader = false; //deselect all
            $scope.docusignApplicationsLoading = false;
          }
        }
      }

      function getSumOfDocumentsOfSelectedCands() {
        $scope.SumOfDocumentsOfSelectedCands = $scope.selectedCandidates.length > 0 ? _.reduce($scope.selectedCandidates, (memo, candidate) => {
          return memo + candidate.application_documents.length;
        }, 0) : 0;
      }

      function createMockInterviewQuestionItem(key, label) {
        return {
          key,
          label,
        };
      }
      const { strings } = worklandLocalize;
      const mockInterviewQuestions = [
        createMockInterviewQuestionItem('q1', strings.q1mi),
        createMockInterviewQuestionItem('q2', strings.q2mi),
        createMockInterviewQuestionItem('q3', strings.q3mi),
        createMockInterviewQuestionItem('q4', strings.q4mi),
        createMockInterviewQuestionItem('q5', strings.q5mi),
        createMockInterviewQuestionItem('q6', strings.q6mi),
        createMockInterviewQuestionItem('q7', strings.q7mi),
      ];

      function fetchCategories() {
        $scope.categoriesList = [];
        $scope.loadingCategories = true;
        api.service_get('toolkit', 'document-manager/candidate-file-versions/document-types').then((response) => {
          $scope.loadingCategories = false;
          angular.forEach(response.data.message, (value, key) => {
            $scope.categoriesList.push({ id: value.id, translation: { fr: { title: value.name_fr }, en: { title: value.name } } });
          });
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.loadingCategories = false;
        });
      }

      fetchCategories();

      function uploadAdditionalDoc() {
        $scope.fileSelected = null;
        $scope.fileUpload = {};
        $scope.addToCandidateApplicationDocUpload = true;
        $scope.createFileInstance = $uibModal.open({
          animation: true,
          templateUrl: './employer-profile/atlas-drive/modal-templates/upload-file.template.html',
          scope: $scope,
          size: 'md',
          backdrop  : 'static',
          keyboard  : false
        });
      }         

      // Get type of file for icon
      function getTypeOfFile (name) {
          const noExtention = "file";
          const ext = name.split(".").pop();
          if (
              ext === "pdf" ||
              ext === "docx" ||
              ext === "doc" ||
              ext === "odt" ||
              ext === "txt" ||
              ext === "png" ||
              ext === "jpg" ||
              ext === "jpeg" ||
              ext === "gif" ||
              ext === "xlsx" ||
              ext === "xls" ||
              ext === "pptx" ||
              ext === "ppt"
          ) {
              return ext;
          }
          return noExtention;
      };

      function shareDocs(action) {
        $scope.fileToBeAttached = [];
        if (action === 'all') {
          angular.forEach($scope.allSelectedDocuments, (document) => {
            const tempData = {
              file_name: document.file_name,
              id: `${document.file_version_id}`,
              candidate_id: document.candidate_id,
              original_file: document.original_file,
              ...(document.isSendRequest ? {isSendRequest: true} : {})
            };
            $scope.fileToBeAttached.push(tempData);
          });
        } else {
            const tempData = {
              file_name: $scope.file.file_name,
              id: `${$scope.file.file_version_id}`,
              candidate_id: $scope.file.candidate_id,
              original_file: $scope.file.original_file,
              ...(document.isSendRequest ? {isSendRequest: true} : {})
            };
            $scope.fileToBeAttached.push(tempData);
        }
        $scope.shareDocModalInstance = $uibModal.open({
          animation: true,
          templateUrl: './employer-profile/views/modal-templates/email-composer-modal.template.html',
          scope: $scope,
          size: 'lg',
          backdrop: 'static',
        });
      }

      function closeShareDocModal() {
        $scope.shareDocModalInstance.close();
      }

      function isFileFormatValid(file) {
        const ext = file.toLowerCase().split('.').pop();
        if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'odt' || ext === 'txt'
                          || ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'xlsx'
                          || ext === 'xls' || ext === 'pptx' || ext === 'ppt') {
          return true;
        }
        $scope.invalidFormatFile = true;
        return false;
      }

      function isFileSizeValid(size) {
        if (size / (1048576) <= 5) {
          return true;
        }
        $scope.invalidSizeFile = true;
        return false;
      }

      $scope.clearFileModel = () => {
        $scope.fileSelected = null;
      }

      function validateFileInfo(file) {
        if (file) $scope.fileSelected = file;
        clearFileValidationErrors();
        if (!$scope.fileUpload.categoryId) {
          $scope.emptyCategory = true;
          $scope.haveError = true;
        }
        if ($scope.fileUpload.source == 'url') {
          if (!$scope.fileUpload.fileName) {
            $scope.emptyFileName = true;
            $scope.haveError = true;
          }
          if (!$scope.fileUpload.url) {
            $scope.emptyFileUrl = true;
            $scope.haveError = true;
          }
        }
        else if (!$scope.fileSelected && !file) {
          $scope.emptyFile = true;
          $scope.haveError = true;
        }
        else if ( (file && ( !isFileFormatValid(file.name) || !isFileSizeValid(file.size) ) ) 
          || ( $scope.fileSelected && (!isFileFormatValid($scope.fileSelected.name) || !isFileSizeValid($scope.fileSelected.size)) )) {
          $scope.haveError = true;
        }
        if ($scope.haveError) {          
          return false;
        }
        return true;
      }

      function clearFileValidationErrors() {
        $scope.haveError = false;
        $scope.emptyCategory = false;
        $scope.emptyFileName = false;
        $scope.emptyFileUrl = false;
        $scope.emptyFile = false;       
      }

      function setDocumentErrorMsg(message) {
        const msg = {fr: '', en: ''};
        switch(message) {
          case 'Your upload limit is over. Please login to access the library':
            msg.fr = 'Votre limite de téléchargement est dépassée. Veuillez accéder à la bibliothèque pour gérer les documents',
            msg.en = 'Your download limit has been exceeded. Please access the library to manage documents'
            break;
          default:
            msg.fr = 'Une erreur s\'est produite et le document n\'a pas pu être téléchargé',
            msg.en = 'An error occurred and the document could not be uploaded'
        }
        return msg;
      }

      function uploadFile() {
        let msgEn;
        let msgFr;
        msgEn = 'Uploading your file...';
        msgFr = 'Téléchargement de votre fichier en cours ...';
        $rootScope.api_status('waiting', msgEn, msgFr);
        const  data = {
          upload_type: $scope.fileUpload.source,
          file_name: $scope.fileUpload.source === 'url' ? $scope.fileUpload.fileName : $scope.fileSelected.name.split('.')[0],
          url_link: $scope.fileUpload.source === 'url' ? $scope.fileUpload.url : '',
          file: $scope.fileUpload.source === 'url' ? '' : $scope.fileSelected,
          is_deleted: 0,
          registered_users: $scope.candidate.loginStatus === 'regular' ? 1 : 0,
          candidate_id: +$scope.candidate.userId ? +$scope.candidate.userId : +$scope.candidate.user_id,
          type_id: $scope.fileUpload.categoryId ? $scope.fileUpload.categoryId : 7,
        };
        const url = `document-manager/quick-apply/employer-add?document_application_id=${$scope.jobApplicationId}`;
        const promise = api.toolkit_fileupload(url, data);
        promise.then((response) => {
          if (response.data.status === 'success') {
            const titleEn = 'Uploaded';
            const titleFr = 'Téléchargé';
            msgEn = 'Your file is uploaded successfully';
            msgFr = 'Votre fichier est téléchargé avec succès';
            $rootScope.api_status('alert-success', msgEn, msgFr, titleEn, titleFr);
            const promises = [];
            const promiseDoc = getCandidateDoc($scope.candidate);
            promises.push(promiseDoc);
            $q.all(promises).then(()=> {
              showFirstAvailableDocument($scope.candidate);
              getSumOfDocumentsOfSelectedCands();
              $scope.fileSelected = null;
            })
          } else {
            const msg = setDocumentErrorMsg(response.data && response.data.message ? response.data.message : '');
            $rootScope.api_status('alert-danger', msg.en, msg.fr);
          }
        }).catch((error) => {
          msgEn = "A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance";
          msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
          if(error.data?.code === 400) {
            if(error.data.message?.file[0] === 'validation.max.file') {
                msgEn = "Sorry! Your file has a wrong size, please upload a file greater than 0 and smaller than 5 MB";
                msgFr = "Désolé! Votre fichier a une taille invalide, veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 5 Mo";
            }
            else if (error.data.message?.file[0] === 'validation.clamav') {
                msgEn = "Sorry! This file is invalid, please upload a new file";
                msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
            }
          }
          else if (error.data?.code === 403) {
              msgEn = "The document library is full";
              msgFr = "La bibliothèque de documents est pleine";
          }
          $rootScope.api_status('alert-danger', msgEn, msgFr, "", "", 5000);
        });
      }

      function createFile() {
        if ($scope.createFileInstance) {
          if (validateFileInfo()) {
            $scope.createFileInstance.dismiss('cancel');
            uploadFile();
          }
        }
      }

      /* @AA-1137 - temporarily on hold
      function deleteFile(document) {
      } */

      function getSrcUrl(response, doc) {
        const fileType = doc.file_name.substring(doc.file_name.lastIndexOf('.') + 1);
        let srcUrl = doc.url;
        switch (fileType) {
          case 'pdf':
          case 'txt':
          case 'png':
          case 'jpg':
          case 'jpeg':
          case 'gif':
          case 'docx':
          case 'odt':
          case 'xls':
          case 'xlsx':
            srcUrl = window.URL.createObjectURL(response);
            break;
        }
        return srcUrl;
      }

      function download(response, doc) {
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(response, doc.file_name); // OK for IE10+
        } else {
          const blobUrl = window.URL.createObjectURL(response);
          const a = document.createElement('a');
          document.body.appendChild(a);
          a.style = 'display: none';
          a.href = blobUrl;
          a.download = doc.file_name;
          a.click();
          document.body.removeChild(a);
        }
      }

      function print(response, doc) {
        const iframe = document.createElement('iframe');
        document.body.appendChild(iframe);
        iframe.style.display = 'none';

        iframe.onload = function () {
          createIframeTimeout = $timeout(() => {
            iframe.focus();
            iframe.contentWindow.print();
          }, 1);
        };
        iframe.src = getSrcUrl(response, doc);
      }

      function print_or_download_doc(action, document) {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', document.url, true);
        xhr.responseType = 'blob';

        const errorMsg_EN = action === 'print' ? 'Failed to print the document.' : 'Failed to download the document.';
        const errorMsg_FR = action === 'print' ? "Impossible d'imprimer le document." : 'Échec du téléchargement du document.';

        xhr.onload = function (event) {
          if (this.status === 200) {
            $rootScope.api_status('', '', '');
            if (action === 'print') {
              print(this.response, document);
            } else {
              download(this.response, document);
            }
          } else {
            $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
          }
        };

        xhr.onerror = function (event) {
          $rootScope.api_status('alert-danger', errorMsg_EN, errorMsg_FR);
        };

        xhr.send();
      }

      function printDoc(action) {
        $rootScope.api_status('waiting', 'Document is being prepared to be printed', 'Le document est en préparation pour être imprimé');
        if (action === 'all') {
          angular.forEach($scope.allSelectedDocuments, (document) => {
            print_or_download_doc('print', document);
          });
        } else {
          print_or_download_doc('print', $scope.file);
        }
      }

      function downloadDoc(action) {
        $rootScope.api_status('waiting', 'Document is being prepared to be downloaded', 'Le document est en préparation pour être téléchargé');
        if (action === 'all') {
          angular.forEach($scope.allSelectedDocuments, (document) => {
            print_or_download_doc('download', document);
          });
        } else {
          print_or_download_doc('download', $scope.file);
        }
      }

      function addOrRemoveDocumentToList(document) {
        if (document.isChecked) {
          // here the whole document must be compared for if we have duplicated documents, they are treated as different from each other
          const index = _.findIndex($scope.allSelectedDocuments, doc => doc == document);
          if (index < 0) {
            $scope.allSelectedDocuments.push(document);
          }
        } else {
          // it seems that sometimes the document is changed and we do not find it except if compared by id
          const index = _.findIndex($scope.allSelectedDocuments, doc => +doc.file_version_id === +document.file_version_id);
          if (index > -1) {
            $scope.allSelectedDocuments.splice(index, 1);
          }
        }
      }

      function openMdMenu($mdMenu, ev) {
        const originatorEv = ev;
        $mdMenu.open(ev);
      }

      $scope.tagHandler = function (tag){
        return null;
      }

      function selectedQuestionnaire(q) {
        $scope.questionnaireIdClicked = q.id;
        $scope.questionnaireClicked = angular.toJson(q);
      }

      // Gets questionnaires list from child ised-view-send-questtionaires-answer
      $scope.$on('questionnairesUp', (e, questionnaires) => {
        $scope.questionnaires = questionnaires;
        if ($scope.questionnaires.length > 0) $scope.questionnaireIdClicked = questionnaires[0].id;
      });

      const scope = {
        out: utils.out,
        language: $rootScope.language,
        strings,
        trustAsHtml:utils.trustAsHtml,
        mockInterviewQuestions,
        requestedOn: {},
        oldSelectedCandidatesLength: 0,
        // openingDocument: '',
        selectDocument,
        viewDocumentsInCvTab,
        shareDocs,
        printDoc,
        downloadDoc,
        uploadAdditionalDoc,        
        createFile,
        notAtlasDriveDirectory: true,
        closeShareDocModal,
        getCandidateDoc,
        changeJob,
        uploadDocFail: false,
        documentsLoader: false,
        noDocument: false,
        clearCVTabMsg,
        allSelectedDocuments: [],
        addOrRemoveDocumentToList,
        openMdMenu,
        removeCandidateDocs,
        isClient: $rootScope.currentUser.permissions.isClient,
        isPremiumClient: $rootScope.isPremiumClient,
        crmJobCandidate : { selected : {
          translations: [
            {title: "Select job"},
            {title: "Choisir un poste"}                        
          ],
          id : -1
        }},
        haveError: false,
        emptyCategory: false,
        emptyFileName: false,
        emptyFileUrl: false,
        emptyFile: false,
        invalidFormatFile: false,
        invalidSizeFile: false,
        clearFileValidationErrors,
        findApplicationsInCommonJobList,
        fileUpload: {},
        fileSelected: null,
        validateFileInfo,
        SumOfDocumentsOfSelectedCands: 0,
        questionnaires: [],
        selectedQuestionnaire,
        questionnaireClicked: null,
        questionnaireIdClicked: 0,
        // DocuSecur
        lang: $rootScope.language,
        documentsRequests: {},
        sendRequestFiles: {},  // converted from send request to documents
        documentRequestIdClicked: 0,
        getDocumentsRequest,
        selectSendRequestDocument,
        addOrRemoveSendRequestDocumentToList,
        isEmptySendRequestDocument,
        documentsRequestLoading: true,
        docusignApplicationsLoading: true,
        docusignApplications: [],
        candidatesWOApplication: [],
        selectedEnvelope,
        selectFirstDocusignEnvelope,
        envelopeIdClicked: null,
        docusignUrlSrc: null,
        candWOApplicationCardIsOpen: false,
        docusignEnvelopesDisplay: -1,
        docusignApplicationsError: false,
        docusignCredentialsError: false,
        docusignUnsyncedError: false,
      };
      angular.extend($scope, scope);

      $scope.$on('$destroy', function () {
        $timeout.cancel(createIframeTimeout);
        $timeout.cancel(createTimeout);
      });
  }

  cvModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    'worklandLocalize',
    '$uibModal',
    '$timeout',
    '$q',
    '_',
    'storageService',
  ];
  angular.module('atlas')
    .directive('cvModule', () => {
      return {
        scope: {
          candidate: '=',
          workflowStages: '=?',
          selectedCandidates: '=',
          allStageCandidates: '=?',
          isCrmCandidates: '=?',
          commonJobList: '=?',
          openedPanelOnCvModule: '=?',
          setOpenedPanelOnCvModule: '&?',
          jobId: '@?',
          jobApplicationId: '@?',
          jobRequestId: '@?',
          jobTitle: '@?',
          jobTitleEn: '@?',
        },
        controller: cvModuleCtrl,
        templateUrl: './employer-profile/directives/cv-module/cv-module.template.html',
      }
    });
}(angular));
