
(function (angular) {

    'use strict';
    var app = angular.module('atlas');
    app.directive('workflowModuleLibrary', function () {

    WorkflowLibraryCtrl.$inject = ['$scope',
        '$rootScope',
        'utils',
        'api',
        '$mdDialog',
        '$timeout',
        '$anchorScroll',
    ];
    function WorkflowLibraryCtrl(
        $scope,
        $rootScope,
        utils,
        api,
        $mdDialog,
        $timeout,
        $anchorScroll,
    ) {
        let scope = {
            out: utils.out,
            filter_options: [],
            workflow_stages: [],
            workflow_library: [],
            trustAsHtml: utils.trustAsHtml,            
            workflowToUpdate: {},
            haveCandidates: false,           
        };
        angular.extend($scope, scope);

        let createTimeout;

        init();
        function init() {
            $scope.onUpdate = false;
            $scope.query = {};
            $scope.queryBy = '$';
            $scope.filter_options = [
                {filter_nameEn: "All", filter_nameFr:"Tous", value: "all"},
                {filter_nameEn: "In use", filter_nameFr:"En usage", value: "inuse"},
                {filter_nameEn: "Not used", filter_nameFr:"Non utilisé", value: "notused"}
            ];
            $scope.data = {
                selectedFilter: $scope.filter_options[0].value,
                workflowInUse: [],
                workflowNotUsed: []
            };
            applyFilter($scope.data.selectedFilter);
            if($scope.isJobCreate && $scope.jobId && !$scope.duplicateJob){
                getCandidateCountByJob();
            }
        }

        $scope.$watch('loadData', function () {
            if($scope.loadData){
                $scope.data.selectedWorkflow = $scope.loadData.workflow_id;
            }
        });

        //workflow Library filter
        function applyFilter(filterValue){
            $scope.data.selectedFilter = filterValue;
            $scope.data.workflowInUse = [];
            $scope.data.workflowNotUsed = [];
            $scope.loadingDone = false;
            if($scope.data.selectedFilter === 'all'){
                getWorkflowLibrary($scope.data.selectedFilter);
            }else if($scope.data.selectedFilter === 'inuse'){
                getWorkflowLibrary($scope.data.selectedFilter);
            }else if($scope.data.selectedFilter === 'notused'){
                getWorkflowLibrary($scope.data.selectedFilter);
            }
        }

        //function for the toggle panel
        $scope.toggleClass = function (workflowid) {
            var toggleTitle = angular.element(document.getElementsByName('title-' + workflowid));
            var toggleInner = angular.element(document.getElementsByName('inner-' + workflowid));
            var toggleIcon = angular.element(document.getElementsByName('icon-' +workflowid));
            
            if (toggleTitle.hasClass('active')) {
                toggleTitle.removeClass('active');
                toggleInner.slideUp(200);
                toggleIcon.removeClass('fa-chevron-up');
                toggleIcon.addClass('fa-chevron-down');
            } else {
                toggleTitle.addClass('active');
                toggleInner.slideDown(200);
                toggleIcon.removeClass('fa-chevron-down');
                toggleIcon.addClass('fa-chevron-up');
            }
        };

        //Angular JS material md-dialog box to view full workflow.
        $scope.fullScreenView = function (workflow) {
            var parentEl = angular.element(document.body);
            $mdDialog.show(
                {
                    parent: angular.element(document.body),
                    preserveScope: true,
                    scope: $scope,
                    clickOutsideToClose: true,
                    template:
                        '  <md-dialog class="workflow-library" aria-label="Workflow Full Screen"'+
                        '     <md-toolbar class="bg-info">'+
                        '         <div class="md-toolbar-tools fs-6">'+
                        '           <h4 class="text-white">{{out(workflow.translation.fr.name,workflow.translation.en.name)}}</h4>'+
                        '           <span flex></span>'+
                        '           <md-button class="md-icon-button text-white" ng-click="closeDialog()" aria-label="closeDialog">'+
                        '           <img src="https://img.icons8.com/ios/25/ffffff/delete-sign.png"/>'+
                        '           </md-button>'+
                        '         </div>'+
                        '     </md-toolbar>'+
                        '  <md-dialog-content>' +
                        '       <div layout="column" ng-cloak">'+
                        '           <md-content>'+
                        '               <workflow-module-create is-update="false" is-view="true" workflow-view="workflow"></workflow-module-create>' +
                        '           </md-content>'+
                        '       </div>'+
                        '  </md-dialog-content>' +
                        '  </md-dialog>',
                    locals: {
                        workflow: workflow,
                        out: $scope.out
                    },
                    controller: DialogController
                });
        };

        
        function openCloneDialog (ev, cloning_workflow) {
            $mdDialog.show({
              controller: DialogController2,
              parent: angular.element(document.body),
              preserveScope: true,
              scope: $scope,
              targetEvent: ev,
              clickOutsideToClose:true,
              template: '<md-dialog aria-label="clone" class="workflow-library">'+
                        '   <div class="modal-dialog my-0 w-max-content">'+
                        '       <div class="modal-content border-0">'+
                        '           <div class="modal-header">'+
                        '               <h5 class="modal-title">{{out("Cloner le flux de travail","Clone Workflow")}}</h5>'+
                        '           </div>'+
                        '           <div class="modal-body p-2">' +
                        '               <div layout="column" ng-cloak class="md-inline-form">'+
                        '                   <md-content layout-padding class="bg-white">'+
                        '                       <div>'+
                        '                           <form name="cloneForm">'+
                        '                               <div layout-gt-sm="row">'+
                        '                                   <md-input-container class="col-12 col-xl-6 md-block mb-0" flex-gt-sm>'+
                        '                                       <label>{{out("Titre du flux de travail-EN","Workflow Title-EN")}}</label>'+
                        '                                       <input name="titleEN" ng-model="clone_workflow_temp.en.name" required>'+
                        '                                       <div ng-messages="cloneForm.titleEN.$error">'+
                        '                                           <div ng-message="required">{{out("Champ requis","Required field")}}</div>'+
                        '                                       </div>'+
                        '                                   </md-input-container>'+
                        '                                   <md-input-container class="col-12 col-xl-6 md-block mb-0" flex-gt-sm >'+
                        '                                       <label>{{out("Titre du flux de travail-FR","Workflow Title-FR")}}</label>'+
                        '                                       <input name="titleFR" ng-model="clone_workflow_temp.fr.name" required>'+
                        '                                       <div ng-messages="cloneForm.titleFR.$error">'+
                        '                                           <div ng-message="required">{{out("Champ requis","Required field")}}</div>'+
                        '                                       </div>'+
                        '                                   </md-input-container>'+
                        '                               </div>'+
                        '                               <div layout-gt-sm="row">'+
                        '                                   <md-input-container class="col-12 col-xl-6 md-block mb-0" flex-gt-sm >'+
                        '                                       <label>{{out("Description du flux de travail-EN","Workflow description-EN")}}</label>'+
                        '                                       <input name="descriptionEN" ng-model="clone_workflow_temp.en.description" required>'+
                        '                                       <div ng-messages="cloneForm.descriptionEN.$error">'+
                        '                                           <div ng-message="required">{{out("Champ requis","Required field")}}</div>'+
                        '                                       </div>'+
                        '                                   </md-input-container>'+
                        '                                   <md-input-container class="col-12 col-xl-6 md-block mb-0" flex-gt-sm">'+
                        '                                       <label>{{out("Description du flux de travail-FR","Workflow description-FR")}}</label>'+
                        '                                       <input name="descriptionFR" ng-model="clone_workflow_temp.fr.description" required>'+
                        '                                       <div ng-messages="cloneForm.descriptionFR.$error">'+
                        '                                           <div ng-message="required">{{out("Champ requis","Required field")}}</div>'+
                        '                                       </div>'+
                        '                                   </md-input-container>'+
                        '                               </div>'+
                        '                           </form> '+
                        '                       </div>'+
                        '                       <div class="list-workflows">'+
                        '                           <h6 class="text-info">{{out("Clonage... ","Cloning... ")}}<span class="text-secondary">{{out(cloning_workflow.translation.fr.name,cloning_workflow.translation.en.name)}}</span></h6>'+
                        '                           <div class="breadcrumbsSmall mb-0 p-1">'+
                        '                               <div class="row innerSmall">'+
                        '                                   <ul class="cfSmall">'+
                        '                                       <li ng-repeat="stage in cloning_workflow.stages | orderBy : \'order\'" ng-hide="stage.translation.en.label == \'Hired\' || stage.translation.en.label == \'Rejected\'">'+
                        '                                           <a><span class="pt-6px">{{stage.order}}</span><span>{{out(stage.translation.fr.label,stage.translation.en.label)}}</span></a>'+
                        '                                       </li>'+
                        '                                       <li>'+
                        '                                           <a class="p-2">'+
                        '                                               <span class="d-none"></span><span>{{out("Embauché","Hired")}}<hr class="my-1 mx-3 section-separator section-separator-light-blue">{{out("Rejeté","Rejected")}}</span>'+
                        '                                           </a>'+
                        '                                       </li>'+
                        '                                   </ul>'+
                        '                               </div>'+
                        '                           </div>'+
                        '                       </div>'+
                        '                   </md-content>'+
                        '               </div>'+
                        '           </div>' +
                        '           <div class="modal-footer">'+                       
                        '               <button class="btn btn-lg btn-secondary py-1 px-3" ng-click="cloneWorkflow(clone_workflow_temp)" ng-disabled="(clone_workflow_temp.en.name && clone_workflow_temp.fr.name) ? false : true" >'+
                        '                   {{out("Cloner","Clone")}}' +
                        '               </button> '  +
                        '               <button class="btn btn-lg btn-alt-secondary py-1 px-3" ng-click="cancel()">'+
                        '                   {{out("Annuler","Cancel")}}' +
                        '               </button> '  +
                        '           </div>' +
                        '       </div>'+
                        '   </div>'+
                        '</md-dialog>',
              locals: {
                cloning_workflow: cloning_workflow,
                clone_workflow_temp: {},
                out: $scope.out
              },
            })
                
          };

          DialogController2.$inject = ['$scope', '$mdDialog', 'cloning_workflow', 'clone_workflow_temp', 'out'];

        //Controller Angular JS material md-dialog box to clone workflow.
        function DialogController2($scope, $mdDialog, cloning_workflow, clone_workflow_temp, out){
            $scope.out = out;
            $scope.cloning_workflow = cloning_workflow;
            $scope.clone_workflow_temp = clone_workflow_temp;
            $scope.clone_workflow_temp = {
                is_linear: cloning_workflow.is_linear,
                en: {
                    name: cloning_workflow.translation.en.name,
                    description: cloning_workflow.translation.en.description
                },
                fr: {
                    name: cloning_workflow.translation.fr.name,
                    description: cloning_workflow.translation.fr.description
                },
                stages: []
            };
            
            $scope.hide = function() {
                $mdDialog.hide();
            };
        
            $scope.cancel = function() {
                $mdDialog.cancel();
            };

            $scope.cloneWorkflow = function(clone_workflow_temp) {
                var stage_temp = cloning_workflow.stages;
                _.each(stage_temp, function (stage) {
                    var stages = {
                        order: stage.order,
                        group_id: stage.group_id,
                        icon: stage.icon,
                        en: { label: stage.translation.en.label },
                        fr: { label: stage.translation.fr.label },
                        events: stage.events
                    }
                    $scope.clone_workflow_temp.stages.push(stages);
                });

                var waitMsgEn, waitMsgFr;
                var successMsgEn, successMsgFr, errorMsgEn, errorMsgFr;

                waitMsgEn = "Cloning workflow...";
                waitMsgFr = "Clonage du flux de travail en cours...";
                successMsgEn = "Workflow has been cloned successfully.";
                successMsgFr = "Le flux de travail a été cloné avec succès.";
                errorMsgEn = "Failed to clone the workflow";
                errorMsgFr = "N'a pas réussi à cloner le flux de travail";
                $rootScope.api_status("waiting", waitMsgEn, waitMsgFr);

                var promise = api.service_post('workflow', 'workflows', $scope.clone_workflow_temp);        
                promise.then(function (response) {
                if (response.status === 201) {
                    $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
                    $scope.loadingDone = false;
                    getWorkflowLibrary('all');
                }
                else {
                    $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
                }
                }).catch(function (error) {
                    $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
                });

                $mdDialog.hide();
            }
        };  
        DialogController.$inject = ['$scope', '$mdDialog', 'workflow', 'out'];
        //Controller for Angular JS material md-dialog box.
        function DialogController($scope, $mdDialog, workflow, out) {
            $scope.workflow = workflow;
            $scope.out = out;
            $scope.closeDialog = function () {
                $mdDialog.hide();
            }
            $scope.openUpdateWorkflow = function(){
                $mdDialog.hide();
                updateWorkflow(workflow);
            }
        }
        //function to get deafult Workflow
        function getDefaultWorkflow(){
            
            var promise = api.service_get('workflow', 'workflows/1');
            promise.then(function (response) {
                if (response.status === 201) {
                    $scope.defaultWorkflow = response.data;
                    $scope.defaultWorkflow.isJobAttached = true;
                }
            }).catch(function (error) {
                $scope.defaultWorkflow = {};
            });
        }

        //function to get All workflow.
        function getWorkflowLibrary(filterValue) {
            $scope.workflow_library = [];
            if(filterValue === 'all'){
                getDefaultWorkflow();
            }
            var promise = api.service_get('workflow', 'workflows');
            promise.then(function (response) {
                if (response.status === 200) {
                    if($scope.isJobCreate && !$scope.jobId){
                        $scope.data.selectedWorkflow = 1;   
                    }
                    //calling Job Service to know if workflow is attached to any Job or Not?
                    var promiseArray = [];
                    _.each(response.data, function (workflow) {
                        var promise2 = api.service_get('jobs', 'job/workflow/'+workflow.id+'/job-ids');
                        promise2.then(function (response2) {
                            if (response2.status === 200) {
                                if (response2.data.is_job_attached){
                                    workflow.isJobAttached = true;
                                    $scope.data.workflowInUse.push(workflow);
                                }
                                else{
                                    workflow.isJobAttached = false;
                                    $scope.data.workflowNotUsed.push(workflow);
                                }
                            }
                        }).catch(function (error) {
                            
                        });
                    });
                
                    //sleep for 2sec.
                    createTimeout = $timeout(function() {
                        if(filterValue === 'all'){
                            $scope.workflow_library = response.data;
                            $scope.workflow_library.unshift($scope.defaultWorkflow);
                        }else if(filterValue === 'inuse')
                            $scope.workflow_library = $scope.data.workflowInUse;
                        else
                            $scope.workflow_library = $scope.data.workflowNotUsed;
                        $scope.loadingDone = true;
                    }, 2000);
                    
                 }
            }).catch(function (error) {
                $scope.workflow_library = [];
                $scope.loadingDone = true;
            });
        }

        function deleteWorkflow(workflow_index, workflow_id) {
            var successMsgEn = "Workflow deleted.";
            var successMsgFr = "Le workflow a été supprimé.";
            var errorMsgEn = "Failed to delete workflow.";
            var errorMsgFr = "Échec de la suppression du flux de travail.";

            var promise = api.service_delete('workflow', 'workflows/' + workflow_id);
            promise.then(function (response) {
                if (response.status === 204) {
                    $scope.workflow_library.splice(workflow_index, 1);
                    $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
                }
            }).catch(function (error) {
                $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
            });
        }

        function updateWorkflow(workflow){
            var successMsgEn = "Workflow updated.";
            var successMsgFr = "Flux de travail mis à jour.";
            var errorMsgEn = "Failed to update workflow.";
            var errorMsgFr = "Échec de la mise à jour du workflow.";
            $scope.workflowToUpdate = {};
            $scope.workflowToUpdate =
            {   
                id: workflow.id,
                is_linear: workflow.is_linear,
                en: {
                    name: workflow.translation.en.name,
                    description: workflow.translation.en.description
                },
                fr: {
                    name: workflow.translation.fr.name,
                    description: workflow.translation.fr.description
                },
                stages: []
            };
            $scope.workflow_temp = workflow['stages'];
           
            makeFormattedArray();
            $scope.onUpdate = true;
        }
        
        function makeFormattedArray() {
            _.each($scope.workflow_temp, function (stage) {
                var stages = {
                    id: stage.id,
                    order: stage.order,
                    group_id: stage.group_id,
                    icon: stage.icon,
                    en: { label: stage.translation.en.label },
                    fr: { label: stage.translation.fr.label },
                    events: stage.events
                }
                $scope.workflowToUpdate.stages.push(stages);
            });
        }
        //function to cancel the Updation of workflow.
        $scope.closeUpdate = function(){
            $scope.onUpdate = false;
            init();
        };
        //function used at Job:create/edit page for attaching a workflow to a Job.
        function saveSelectedWorkflow(selected_workflow) { 
            $scope.callbackAttachWorkflow = selected_workflow;
            $scope.callbackFromAttachWorkflow();
            $anchorScroll();
        }
        //function used to get Jobs List attached with particular Workflow
        function getAttachedJob(workflowID){
            var promise = api.service_get('jobs', 'job/workflow/'+workflowID+'/job-ids');
            promise.then(function (response) {
                if (response.status === 200) {
                        if (response.data.length > 0) {
                            return true;
                        } 
                        else{
                            return false;
                        }
                           
                }
            }).catch(function (error) {
            });
        }
        //function used to get number of candidates in job's workflow
        function getCandidateCountByJob(){
            var promise = api.service_get('workflow', 'workflows/candidates-count-by-job/'+ $scope.jobId);
            promise.then(function (response) {
                if (response.status === 200) {
                    if (response.data.isWorkflowAttached && response.data.total_candidates_count > 0) {
                        $scope.haveCandidates = true;
                    } else
                        $scope.haveCandidates = false;
                    }       
            }).catch(function (error) {
            });
        }

        function showErrorMessage(workflow_id){
            var errorMsgEn = "Can't change workflow as job has candidates";
            var errorMsgFr = "Impossible de changer le flux de travail car le poste a des candidats";
            if(workflow_id != $scope.data.selectedWorkflow && $scope.jobId && $scope.haveCandidates && !$scope.duplicateJob){
                $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
            }
        }

        $scope.$on('$destroy', function () {
          $timeout.cancel(createTimeout);
        });

        function previousStep() {
          $scope.callbackPreviousStepIndex = 5;
          $scope.switchTimeline();
          $anchorScroll();
        }

        scope = {
            getWorkflowLibrary,
            deleteWorkflow,
            updateWorkflow,   
            saveSelectedWorkflow,
            makeFormattedArray,
            applyFilter,
            getAttachedJob,
            getDefaultWorkflow,
            getCandidateCountByJob,
            showErrorMessage,
            openCloneDialog,
            previousStep,
        };
        angular.extend($scope, scope);
  
    }
        return {
            scope: {
                isJobCreate:'=',
                jobId:'=',
                callbackFromAttachWorkflow: '&',
                callbackAttachWorkflow: '=',
                loadData: '=',
                duplicateJob: '=',
                switchTimeline: '&',
                callbackPreviousStepIndex: '=',
            },
            controller: WorkflowLibraryCtrl,
            templateUrl: './employer-profile/directives/workflow-module/workflow-module-library/workflow-module-library.template.html'
        };
    });
})(angular);