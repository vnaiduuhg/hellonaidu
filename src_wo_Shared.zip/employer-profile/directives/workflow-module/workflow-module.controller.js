(function (angular) {

    var app = angular.module('atlas');
    app.controller('WorkflowModuleController', WorkflowModuleController);

    WorkflowModuleController.$inject = ['$scope', 'utils', 'MetaTagsService', '$state',];
    function WorkflowModuleController($scope, utils, MetaTagsService, $state,) {
        var scope = {
            out: utils.out,
            trustAsHtml: utils.trustAsHtml,
            currentTab: {},
            openTab: openTab
        };
        angular.extend($scope, scope);

        //Init Function
        function init() {
            $scope.sideTabs = [
                { nameEn: "Create", nameFr: "Créer", icon: "fa-plus-square", type: "create" },
                { nameEn: "Library", nameFr: "Bibliothèque", icon: "fa-list-alt", type: "library" },
            ];
            $scope.currentTab.active = $scope.sideTabs[0].type;
        }

        function openTab(tab) {
            $scope.currentTab.active = tab.type;
        }

        init();

        MetaTagsService.getMetatags($state.current.name);
        const deregisterFns = MetaTagsService.magageTransitions();
        $scope.$on('$destroy', () => {
          deregisterFns.forEach((deregisterFn) => {
            deregisterFn();
          });         
        });
    }

})(angular);