(function (angular) {
  angular.module('atlas')
    .directive('workflowModuleCreate', () => {
      return {
        scope: {
          isUpdate: '=',
          isView: '=',
          workflowView: '=',
          closeUpdate: '&',
        },
        controller: WorkflowCreateCtrl,
        templateUrl: './employer-profile/directives/workflow-module/workflow-module-create/workflow-module.template.html',
      };
    })
      WorkflowCreateCtrl.$inject = ['$scope',
        '$rootScope',
        'utils',
        'api',
        '$mdDialog',
        '$filter',
      ];
      function WorkflowCreateCtrl(
        $scope,
        $rootScope,
        utils,
        api,
        $mdDialog,
        $filter,
      ) {
        const scope = {
          out: utils.out,
          workflow_events: [],
          default_stages: [],
          workflow_stages: [],
          temp_stages: [],
          workflow: {},
          selectedEvent: [],
          hiredRejectedStage: [],
          mandatoryStage: [],
          fetchDefaultStages,
          fetchWorkflowEvents,
          removeStage,
          cloneStage,
          makeFormattedArray,
          saveWorkflow,
          updateWorkflow,
          trustAsHtml: utils.trustAsHtml,
          cancelUpdate,
          assignEventsTranslations,
        };
        angular.extend($scope, scope);

        $scope.$watch('workflow', (newVal, oldVal) => {
          if ($scope.workflow.en.name && $scope.workflow.fr.name
                && $scope.workflow.en.description && $scope.workflow.fr.description) {
            $scope.validateWorkflow = true;
          } else {
            $scope.validateWorkflow = false;
          }
        }, true);

        init();
        // Init Function
        function init() {
          fetchDefaultStages();
          fetchWorkflowEvents();
          $scope.isEdit = false;
          $scope.validateWorkflow = false;
          $scope.workflow = {
            is_linear: true,
            en: {
              name: 'Workflow Name',
              description: 'Workflow description',
            },
            fr: {
              name: 'Nom du flux de travail',
              description: 'Description du flux de travail',
            },
            stages: [],
          };

          if ($scope.isView) {
            $scope.workflow_stages = $filter('orderBy')($scope.workflowView.stages, 'order');
          } else if ($scope.isUpdate) {
            $scope.workflow_stages = $filter('orderBy')($scope.workflowView.stages, 'order');
            $scope.workflow.en = $scope.workflowView.en;
            $scope.workflow.fr = $scope.workflowView.fr;
            if ($scope.workflowView.is_linear) {
              $scope.workflow.is_linear = true;
            } else {
              $scope.workflow.is_linear = false;
            }

            $scope.workflow.id = $scope.workflowView.id;
          } else {
            $scope.workflow_stages = [];
          }
        }

        // function trustAsHtml(string) {
        //   return $sce.trustAsHtml(string);
        // }

        // function to get default stages-param:1 for default workflow stages
        function fetchDefaultStages() {
          $scope.temp_stages = [];
          const promise = api.service_get('workflow', 'workflows/1');
          promise.then((response) => {
            if (response.status === 201) {
              $scope.temp_stages = response.data.stages;
              makeFormattedArray();
            }
          }).catch((error) => {
            $scope.temp_stages = [];
          });
        }

        //assign events translations to default stages and workflow_stages.
        function assignEventsTranslations(type, action){
          if(action === '1'){
            $scope.translationLoaded = false;
          }
          if($scope.workflow_events && type){
            angular.forEach(type, function (stage, index){
              var temp = [];
              if(stage.en.label !== "Applied" && stage.en.label !== "Hired" && stage.en.label !== "Rejected" && 
                 stage.en.label !== "Matched" && stage.en.label !== "Sourced"){
                angular.forEach(stage.events, function (stageEvent, key){
                  translatedEvent = $scope.workflow_events.find(x => x.event_slug === stageEvent.event_slug);
                  if(translatedEvent){
                    temp.push(translatedEvent);
                  }
                });
                type[index].events = temp;
              }
              $scope.translationLoaded = true;
            });
          }
        }

        // Fetch all events used in workflow
        function fetchWorkflowEvents() {
          $scope.loaded = false;
          $scope.workflow_events = [];
          const promise = api.service_get('workflow', 'workflow-events');
          promise.then((response) => {
            if (response.status === 200) {
              $scope.workflow_events = response.data;
              $scope.loaded = true;
              assignEventsTranslations($scope.workflow_stages, '1');
              assignEventsTranslations($scope.default_stages, '0');
            }
          }).catch((error) => {
            $scope.workflow_events = [];
          });
        }

        // function to make desired formatted data
        function makeFormattedArray() {
          $scope.default_stages = [];
          _.each($scope.temp_stages, (stage) => {
            const stages = {
              order: stage.order,
              group_id: stage.group_id,
              icon: stage.icon,
              en: { label: stage.translation.en.label },
              fr: { label: stage.translation.fr.label },
              events: stage.events,
            };
            if (stage.translation.en.label === 'Hired' || stage.translation.en.label === 'Rejected') {
              $scope.hiredRejectedStage.push(stages);
            } else if (stage.translation.en.label === 'Applied') {
              $scope.mandatoryStage.push(stages);
            } else {
              $scope.default_stages.push(stages);
            }
          });
        }

        // function to remove stages in a workflow
        function removeStage(stageIndex) {
          const msgEn = 'Stage deleted';
          const msgFr = 'Stade supprimé';
          $scope.workflow_stages.splice(stageIndex, 1);
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }

        // function to clone added stages of workflow
        function cloneStage(stageIndex) {
            var clonedStage = angular.copy($scope.workflow_stages[stageIndex]);
            delete clonedStage['id'];
            clonedStage.en.label = clonedStage.en.label + "-copy";
            clonedStage.fr.label = clonedStage.fr.label + "-copie";
            $scope.workflow_stages.push(clonedStage);
        }

        // function to add workflow to library
        function saveWorkflow() {
          let waitMsgEn = '';
          let waitMsgFr = '';
          let successMsgEn = '';
          let successMsgFr = '';
          let errorMsgEn = '';
          let errorMsgFr = '';

          waitMsgEn = 'Workflow is being added...';
          waitMsgFr = "Le flux de travail est en cours d'ajout ...";
          successMsgEn = 'Workflow has been added successfully.';
          successMsgFr = 'Le flux de travail a été ajouté avec succès.';
          errorMsgEn = 'Failed to add the Workflow';
          errorMsgFr = "Impossible d'ajouter le flux de travail";

          $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
          // Pushing mandatory stages and Hired/Rejected Stage
          $scope.workflow_stages.unshift($scope.mandatoryStage[0]);
          $scope.workflow_stages.push($scope.hiredRejectedStage[0]);
          $scope.workflow_stages.push($scope.hiredRejectedStage[1]);
          let counter = 0;
          _.each($scope.workflow_stages, (workflow_stage) => {
            counter++;
            workflow_stage.order = counter;
          });

          $scope.workflow.stages = $scope.workflow_stages;
          const promise = api.service_post('workflow', 'workflows', $scope.workflow);
          promise.then((response) => {
            if (response.status === 201) {
              $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
              $scope.workflow.stages = [];
              $scope.workflow_stages = [];
            } else {
              $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
            }
          }).catch((error) => {
            $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
          });
        }

        // function to update worklflow
        function updateWorkflow() {
          let waitMsgEn = '';
          let waitMsgFr = '';
          let successMsgEn = '';
          let successMsgFr = '';
          let errorMsgEn = '';
          let errorMsgFr = '';

          waitMsgEn = 'Workflow is being updated...';
          waitMsgFr = "Le flux de travail est en cours de mis à jour ...";
          successMsgEn = 'Workflow has been updated successfully.';
          successMsgFr = 'Le flux de travail a été mis à jour avec succès.';
          errorMsgEn = 'Failed to update the workflow';
          errorMsgFr = "Impossible de mettre à jour le flux de travail";

          $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
          let counter = 0;
          _.each($scope.workflow_stages, (workflow_stage) => {
            counter++;
            if (workflow_stage.en.label === 'Hired') {
              workflow_stage.order = $scope.workflow_stages.length - 1;
              counter--;
            } else if (workflow_stage.en.label === 'Rejected') {
              workflow_stage.order = $scope.workflow_stages.length;
              counter--;
            } else {
              workflow_stage.order = counter;
            }
          });
          $scope.workflow.name = $scope.workflow.en.name;
          $scope.workflow.description = $scope.workflow.en.description;
          $scope.workflow.stages = $scope.workflow_stages;
          $scope.workflow_stages = $filter('orderBy')($scope.workflow_stages, 'order');
          const promise = api.service_post('workflow', `workflows/${$scope.workflow.id}`, $scope.workflow, true);
          promise.then((response) => {
            if (response.status === 201) {
              $rootScope.api_status('alert-success', successMsgEn, successMsgFr);
              $scope.workflow.stages = [];
              $scope.workflow_stages = [];
              $scope.closeUpdate();
            }
          }).catch((error) => {
            $rootScope.api_status('alert-danger', errorMsgEn, errorMsgFr);
          });
        }
        // Function to cancel the Update of workflow
        function cancelUpdate() {
          $scope.isUpdate = false;
          $scope.closeUpdate();
        }

        // AngularJS ng-sortable function
        $scope.sortableOptions = {
          itemMoved(event) {
          },
          orderChanged(event) {
          },
          containment: '#row',
          clone: true,
          allowDuplicates: false,
        };
        // AngularJS ng-sortable functions
        $scope.dragControlListeners = {
          itemMoved(event) {
          },
          orderChanged(event) {
          },
          containment: '#stages_row',
          allowDuplicates: false,
        };
        // AngularJS ng-sortable functions
        $scope.dndListeners = {
          dragEnd(evt) {
            $scope.lastMovedItem = evt.source.itemScope.stage;
          },
          orderChanged(evt) {
          },
          allowDuplicates: false,
        };

        // Angular JS material md-dialog box to edit/add stages.
        $scope.showDialog = function (ev, action, stageIndex) {
          $mdDialog.show({
            controller: DialogController,
            parent: angular.element(document.body),
            preserveScope: true,
            scope: $scope,
            targetEvent: ev,
            clickOutsideToClose: true,
            template: '<md-dialog aria-label="full">'
                        + '<div class="modal-dialog my-0">'
                        + '   <div class="modal-content border-0">'
                        + '       <div class="modal-header">'
                        + '         <h5 class="modal-title">{{out(stage_actionFr,stage_actionEn)}}</h5>'
                        + '       </div>'
                        + '       <div class="modal-body p-2">'
                        + '           <div layout="column" ng-cloak class="md-inline-form">'
                        + '               <md-content layout-padding class="bg-white">'
                        + '                   <div>'
                        + '                       <form name="stageForm">'
                        + '                           <div layout-gt-sm="row">'
                        + '                               <md-input-container class="md-block mb-0" flex-gt-sm>'
                        + '                                   <label>{{out("Étiquette Anglais","Label English")}}</label>'
                        + '                                   <input name="stageEN" ng-model="workflowStagesTemp.en.label" required>'
                        + '                                   <div ng-messages="stageForm.stageEN.$error">'
                        + '                                       <div ng-message="required">{{out("Champ requis","Required field")}}</div>'
                        + '                                   </div>'
                        + '                               </md-input-container>'
                        + '                               <md-input-container class="md-block mb-0" flex-gt-sm>'
                        + '                                   <label>{{out("Étiquette Français","Label French")}}</label>'
                        + '                                   <input name="stageFR" ng-model="workflowStagesTemp.fr.label" required>'
                        + '                                   <div ng-messages="stageForm.stageFR.$error">'
                        + '                                       <div ng-message="required">{{out("Champ requis","Required field")}}</div>'
                        + '                                   </div>'
                        + '                               </md-input-container>'
                        + '                             </div>'
                        + '                             <div layout-gt-sm="row" class="event-container">'
                        + '                                 <md-input-container class="md-block overflow-hidden" flex-gt-sm>'
                        + '                                     <span class="fs-5">{{out("Choisir des événements","Pick Events")}}</span>'
                        + '                                     <md-select ng-model="selectedEvent" multiple aria-label="none">'
                        + '                                         <md-optgroup label="{{out(\'événements par défaut\',\'default events\')}}" >'
                        + '                                             <md-option ng-value="event" ng-repeat="event in default_events" ng-selected="{{ selectedArray.indexOf(event.event_slug) < 0 ? false : true}}">{{out(event.translation.fr.name, event.translation.en.name)}}</md-option>'
                        + '                                         </md-optgroup>'
                        + '                                     </md-select>'
                        + '                                 </md-input-container>'
                        + '                             </div>'
                        + '                             <span class="fs-6" ng-if="selectedEvent.length >= 1"><b>{{out("Événements","Events")}}</b>:&nbsp</span>'
                        + '                             <div class="d-flex flex-wrap"><span class="label-md me-1" ng-repeat="stageevent in selectedEvent">{{out(stageevent.translation.fr.name, stageevent.translation.en.name)}}</span></div>'
                        + '                         </form> '
                        + '                     </div>'
                        + '                 </md-content>'
                        + '             </div>'
                        + '         </div>'
                        + '         <div class="modal-footer">'                       
                        + '             <button class="btn-lg btn btn-secondary py-1 px-3" ng-click="save(selectedEvent)" ng-disabled="(workflowStagesTemp.en.label && workflowStagesTemp.fr.label) ? false : true">'
                        + '                 {{out("Sauvegarder","Save")}}'
                        + '             </button> '
                        + '             <button class="btn-lg btn btn-alt-secondary py-1 px-3" ng-click="cancel()">'
                        + '                 {{out("Annuler","Cancel")}}'
                        + '             </button> '
                        + '         </div>'
                        + '     </div>'
                        + '   </div>'
                        + '</md-dialog>',
            locals: {
              stageAction: action,
              stage_actionIndex: stageIndex,
              default_events: $scope.workflow_events,
              workflowStagesTemp: {},
              out: $scope.out,
              selectedEvent: $scope.selectedEvent,
              selectedArray: [],
            },
          });
        };

        DialogController.$inject = ['$scope', '$mdDialog', 'stageAction', 'stage_actionIndex', 'default_events', 'workflowStagesTemp', 'out', 'selectedEvent', 'selectedArray'];
        // Controller Angular JS material md-dialog box to edit/add stages.
        function DialogController($scope, $mdDialog, stageAction, stage_actionIndex, default_events, workflowStagesTemp, out, selectedEvent, selectedArray) {
          $scope.stage_actionIndex = stage_actionIndex;
          $scope.default_events = default_events;
          $scope.out = out;
          $scope.workflowStagesTemp = workflowStagesTemp;
          $scope.selectedEvent = selectedEvent;
          if (stageAction === 'Edit Stage') {
            $scope.stage_actionEn = 'Edit stage';
            $scope.stage_actionFr = 'Mise à jour du stade';
            $scope.workflowStagesTemp = $scope.workflow_stages[stage_actionIndex];
            angular.forEach($scope.workflowStagesTemp.events, (value, key) => {
              selectedArray.push(value.event_slug);
            });
            $scope.selectedArray = selectedArray;
          } else if (stageAction === 'Add Stage') {
            $scope.stage_actionEn = 'Add stage';
            $scope.stage_actionFr = 'Ajout d\'un stade';
            $scope.selectedEvent = [];
            $scope.selectedArray = selectedArray;
            $scope.workflowStagesTemp = {
              order: null,
              en: { label: '' },
              fr: { label: '' },
              group_id: null,
              icon: 'default.png',
              events: [],
            };
          }
          $scope.hide = function () {
            $mdDialog.hide();
          };

          $scope.cancel = function () {
            $mdDialog.cancel();
          };

          $scope.save = function (selectedEvent) {
            $scope.selectedArray = [];
            if ($scope.stage_actionEn === 'Edit stage') {
              $scope.workflow_stages[stage_actionIndex].events = $scope.selectedEvent;
              $scope.workflow_stages[stage_actionIndex].en.label = $scope.workflowStagesTemp.en.label;
              $scope.workflow_stages[stage_actionIndex].fr.label = $scope.workflowStagesTemp.fr.label;
            } else if ($scope.stage_actionEn === 'Add stage') {
              $scope.workflowStagesTemp.events = angular.copy($scope.selectedEvent);
              $scope.workflow_stages.push($scope.workflowStagesTemp);
            }
            $mdDialog.hide();
          };
        }

   }   

})(angular);
