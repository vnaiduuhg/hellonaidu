(function (angular) {
    'use strict';
    angular.module('atlas')
    .directive('workflowModuleSettings', function () {
        return {
            scope: {
            },
            controller: WorkflowSettingsCtrl,
            templateUrl: './employer-profile/directives/workflow-module/workflow-module-settings/workflow-module-settings.template.html'
        };
    });

    WorkflowSettingsCtrl.$inject = ['$scope', 'utils'];
    function WorkflowSettingsCtrl($scope, utils) {
        var scope = {
            out: utils.out,
            trustAsHtml: utils.trustAsHtml
        };
        angular.extend($scope, scope);
    }

}) (angular);
