( function ( angular ) {

    'use strict';
    angular.module( 'atlas' )
            .directive( 'backcheckModule', function () {
                return {
                    scope: {
                        candidate: '=',
                        jobId: '@'
                    },
                    controller: BackcheckModuleCtrl,
                    template: require('./backcheck-module.template.html')
                };
            } );

    BackcheckModuleCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', 'worklandLocalize'];

    function BackcheckModuleCtrl( $scope, $rootScope, api, utils, worklandLocalize ) {

        $scope.$watch( 'candidate.userId', init );
        var scope = {
            out: utils.out,
        };

        angular.extend($scope, scope);

        function init() {

        }
    }

} )( angular );
