(function (angular) {
  function substitutusSettingsCtrl(
    $scope,
    utils,
    MetaTagsService,
    $state,
    api,
    $ngConfirm,
    storageService,
    $rootScope,
  ) {
    $scope.out = utils.out;
    let scope = {
      accountSynced: false,
      formVisible: false,
      hasAccess: $rootScope.currentUser.permissions.isSuperUser || $rootScope.currentUser.permissions.isAdminRecruiter,
    };
    angular.extend($scope, scope);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function showForm() {
      $scope.formVisible = true;
    }

    function cancel() {
      $scope.formVisible = false;
      $scope.clientId = "";
      $scope.apiSecret = "";
    }

    function checkStatus() {
      $scope.formVisible = false;
      $scope.loaded = false;
      const accountId = +storageService.getItem('account_id');
      api.service_get('substituteTeacher', `substitutus/accounts/${accountId}/is-synced`).then((response) => {
        if (response.status === 200) {
          $scope.accountSynced = true;
        }
      }).catch((error) => {
        if (error.status === 404) {
          $scope.accountSynced = false;
          if (!$scope.hasAccess) {
            $rootScope.api_status(
              'alert-danger',
              'The account is not synced. Please refer to your administrator.',
              'Le compte n\'est pas synchronisé. Veuillez vous adresser à votre administrateur.',
              null, null, 4000,
            )
          }
        } else {
          $rootScope.api_status(
            'alert-danger',
            'Sorry, we could not verify your Scolago account. Please try again or contact our support team at support@workland.com for further assistance.',
            'Désolé, nous n\'avons pas pu vérifier votre compte Scolago. Veuillez réessayer ou contacter notre équipe d\'assistance à l\'adresse support@workland.com pour plus d\'aide.',
            null, null, 4000,
          );
        }
      });
    }
    checkStatus();

    function syncAccount() {
      $scope.syncing = true;
      $scope.loaded = false;
      api.service_post('substituteTeacher', 'substitutus/accounts', {
        substitutus_client_id: $scope.clientId,
        substitutus_api_secret: $scope.apiSecret,
      }).then((response) => {
        if (response.status === 201) {
          $rootScope.api_status(
            'alert-success',
            'Scolago account is saved successfully',
            'Le compte Scolago est sauvegardé avec succès',
            null, null, 3000,
          );
        }
        if (response.status === 200) {
          $rootScope.api_status(
            'alert-success',
            'Scolago account is updated successfully',
            'Le compte Scolago est modifié avec succès',
            null, null, 3000,
          );
        }
        $scope.syncing = false;
        $scope.loaded = true;
      }).then(() => {
        checkStatus();
      }).catch((error) => {
        $scope.syncing = false;
        $scope.loaded = true;
        if (error.status === 401) {
          $rootScope.api_status(
            'alert-danger',
            'Sorry, we did not find the account. Please verify your data.',
            'Désolé, nous n\'avons pas trouvé le compte. Veuillez vérifier vos données.',
            null, null, 4000,
          );
        }
        if (error.status === 500) {
          $rootScope.api_status(
            'alert-danger',
            'Sorry, an error has occurred. Please try again or contact our support team at support@workland.com for further assistance.',
            'Désolé, une erreur s\'est produite. Veuillez réessayer ou contacter notre équipe d\'assistance à l\'adresse support@workland.com pour plus d\'aide.',
            null, null, 4000,
          );
        }
      });
    }

    function unsyncAccount() {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: '',
        content: $scope.out('Supprimer le compte?', 'Delete account?'),
        type: 'blue',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          yes: {
            text: $scope.out('oui', 'yes'),
            action() {
              $scope.syncing = true;
              $scope.loaded = false;
              const accountId = +storageService.getItem('account_id');
              api.service_delete('substituteTeacher', `substitutus/accounts/${accountId}`).then((response) => {
                if (response.status === 200) {
                  $scope.syncing = false;
                  $scope.loaded = true;
                  $rootScope.api_status(
                    'alert-success',
                    'Account deleted',
                    'Compte supprimé',
                    null, null, 3000,
                  );
                  checkStatus();
                }
              }).catch((error) => {
                $scope.syncing = false;
                $scope.loaded = true;
                if (error.status === 404) {
                  $rootScope.api_status(
                    'alert-danger',
                    'Sorry, we did not find the account.',
                    'Désolé, nous n\'avons pas trouvé le compte.',
                    null, null, 3000,
                  );
                }
              });
            },
          },
          no: {
            text: $scope.out('Non', 'No'),
            btnClass: 'btn-blue',
            action() {
            },
          },
        },
      });
    }

    scope = {
      syncAccount,
      unsyncAccount,
      showForm,
      cancel,
    };
    angular.extend($scope, scope);
  }

  substitutusSettingsCtrl.$inject = [
    '$scope',
    'utils',
    'MetaTagsService',
    '$state',
    'api',
    '$ngConfirm',
    'storageService',
    '$rootScope',
  ];
  angular.module('atlas')
    .directive('substitutusSettings', () => ({
      scope: {},
      controller: substitutusSettingsCtrl,
      templateUrl: './employer-profile/directives/integrations/substitutus/substitutus-settings.template.html',
    }));
}(angular));
