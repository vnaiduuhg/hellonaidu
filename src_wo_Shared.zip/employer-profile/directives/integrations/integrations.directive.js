(function (angular) {
  function integrationsCtrl(
    $scope,
    utils,
    MetaTagsService,
    $state,
  ) {
    $scope.out = utils.out;
    const scope = {
      currentTab: {},
      currentSubTab: {},
      openTab,
    };
    angular.extend($scope, scope);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function init() {
      $scope.sideTabs = [
        {
          nameEn: 'Replacement', 
          nameFr: 'Remplacement', 
          icon: 'fa fa-exchange',
          type: 'substitutusSettings',
          subTabs: [
            { nameEn: 'Scolago', nameFr: 'Scolago', type: 'settings' },
          ],
        },
      ];
      $scope.currentTab.active = $state.current.name;
      if($scope.currentTab.active === 'substitutusSettings') {
        $scope.currentSubTab.active = 'settings';
      }
    }

    function openTab(tab, subTab) {
      $state.go(tab.type);
      $scope.currentTab.active = tab.type;
      if (subTab) {
        $scope.currentSubTab.active = subTab.type;
      } else if (tab.subTabs) {
        $scope.currentSubTab.active = tab.subTabs[0].type;
      }
    }

    $scope.openTabWithAnimation = function($event, tab, subTab) {
      $event.preventDefault();

      openTab(tab, subTab);

      if (!subTab) {
        design.sidebar.openDropdown($event.currentTarget);
      }
    }

    init();
    design.sidebar.ngInit('integrations');
  }

  integrationsCtrl.$inject = [
    '$scope',
    'utils',
    'MetaTagsService',
    '$state',
  ];
 angular.module('atlas')
    .directive('integrations', () => ({
      scope: {

      },
      controller: integrationsCtrl,
      templateUrl: './employer-profile/directives/integrations/integrations.template.html',
    }));
  angular.module('atlas').controller('integrationsCtrl', integrationsCtrl);
}(angular));
