(function (angular) {
  function jobsSettingsCtrl(
    $scope,
    utils,
    MetaTagsService,
    $state,
    api,
    $rootScope,
    storageService,
  ) {
    let scope = {
      out: utils.out,
      groupName: {},
      updated: {},
      jobGroupsObj: { translations: [] },
      creatingGroup: false,
      currentUserAccountId: JSON.parse(storageService.getItem('account_id')),
      language: $rootScope.language,
    };
    angular.extend($scope, scope);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    let msgFr; let msgEn; let waitMsgEn; let
      waitMsgFr;

    function editModeOn(group) {
      $scope.editMode = {};
      $scope.editMode.id = group.id;
      $scope.updated.groupName_en = group.translations[0].name;
      $scope.updated.groupName_fr = group.translations[1].name;
    }

    function editModeOff() {
      $scope.updated = {};
      $scope.editMode = {};
    }

    function fetchGroups() {
      $scope.jobGroups = false;
      const promise = api.service_get('jobs', `group/account/${$scope.currentUserAccountId}/groups`);
      promise.then((response) => {
        if (response.status === 200) {
          $scope.jobGroups = response.data;
        } else {
          $scope.jobGroups = [];
          $rootScope.api_status('alert-danger', 'Failed to load groups', 'Échec du chargement des groupes');
        }
      }).catch((error) => {
        $scope.jobGroups = [];
        if (error.status === 404) {
          $rootScope.api_status('alert-success', 'Create your first group here', 'Créez votre premier groupe ici');
        } else {
          $rootScope.api_status('alert-danger', 'Failed to load groups', 'Échec du chargement des groupes');
        }
      });
    }

    function resetJobGroupsObj() {
      $scope.jobGroupsObj = {
        translations: []
      };
    }

    function addGroup() {
      if ($scope.creatingGroup) {
        return;
      }

      resetJobGroupsObj();
      $scope.hasFrError = !$scope.groupName.fr;
      $scope.hasEnError = !$scope.groupName.en;
      if (!$scope.hasFrError && !$scope.hasEnError) {
        if (!$scope.creatingGroup) {
          $scope.creatingGroup = true;
        }
        $scope.jobGroupsObj.translations.push({
          locale: 'en',
          name: $scope.groupName.en,
        });
        $scope.jobGroupsObj.translations.push({
          locale: 'fr',
          name: $scope.groupName.fr,
        });
        waitMsgEn = 'Adding a group...';
        waitMsgFr = 'Ajout du groupe en cours ...';
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
        const promise = api.service_post('jobs', 'group',
          $scope.jobGroupsObj);
        promise.then((response) => {
          if (response.status === 200 || response.status === 201) {
            const { data } = response;
            api.service_query('jobs', `group/${data.id}/account/${$scope.currentUserAccountId}`, 'PUT', {}).then((res) => {
              if (res.status === 200 || res.status === 201) {
                msgEn = 'The group was added';
                msgFr = 'Le groupe a été ajouté';
                $rootScope.api_status('alert-success', msgEn, msgFr);
                $scope.groupName = {};
                fetchGroups();
                $scope.creatingGroup = false;
              } else {
                $rootScope.api_status('alert-danger', 'Failed to add a group', 'Échec de l\'ajout du groupe');
                $scope.creatingGroup = false;
              }
            }).catch(() => {
              $rootScope.api_status('alert-danger', 'Failed to add a group', 'Échec de l\'ajout du groupe');
              $scope.creatingGroup = false;
            });
          } else {
            $rootScope.api_status('alert-danger', 'Failed to add a group', 'Échec de l\'ajout d\'un groupe');
            $scope.creatingGroup = false;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.creatingGroup = false;
        });
      }
    }

    function deleteGroup(id) {
      waitMsgEn = 'Deleting the group...';
      waitMsgFr = 'Suppression du groupe en cours ...';
      $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
      const promise = api.service_delete('jobs', `group/${id}`);
      promise.then((response) => {
        if (response.status === 200) {
          fetchGroups();
          msgEn = 'The group was deleted';
          msgFr = 'Le groupe a été supprimée';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'Failed to delete the group', 'Échec de la suppression du groupe');
      });
    }

    function updateGroup(groupId) {
      resetJobGroupsObj();
      $scope.updated.groupName_enError = !$scope.updated.groupName_en;
      $scope.updated.groupName_frError = !$scope.updated.groupName_fr;
      if (!$scope.updated.groupName_enError && !$scope.updated.groupName_frError) {
        $scope.jobGroupsObj.translations.push({
          locale: 'en',
          name: $scope.updated.groupName_en,
        });
        $scope.jobGroupsObj.translations.push({
          locale: 'fr',
          name: $scope.updated.groupName_fr,
        });
        waitMsgEn = 'Updating the group...';
        waitMsgFr = 'Mise à jour du groupe en cours ...';
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
        const promise = api.service_post('jobs', `group/${groupId}`, $scope.jobGroupsObj, 'UPDATE');
        promise.then((response) => {
          if (response.status === 201 || response.status === 200) {
            editModeOff();
            fetchGroups();
            msgEn = 'The group was updated';
            msgFr = 'Le groupe a été mise à jour';
            $rootScope.api_status('alert-success', msgEn, msgFr);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', 'Failed to update the group', 'Échec de la mise à jour du groupe');
        });
      }
    }

    fetchGroups();

    scope = {
      addGroup,
      deleteGroup,
      updateGroup,
      editModeOn,
      editModeOff,
    };
    angular.extend($scope, scope);
  }

  jobsSettingsCtrl.$inject = [
    '$scope',
    'utils',
    'MetaTagsService',
    '$state',
    'api',
    '$rootScope',
    'storageService',
  ];
  angular.module('atlas')
    .directive('jobsSettings', () => ({
      scope: {

      },
      controller: jobsSettingsCtrl,
      templateUrl: './employer-profile/directives/jobs-settings/jobs-settings.template.html',
    }));
  angular.module('atlas').controller('jobsSettingsCtrl', jobsSettingsCtrl);
}(angular));
