(function (angular) {
  function candidateMetadataModuleCtrl($scope, $rootScope, utils) {
    
    const scope = {
      out: utils.out,
      language: $rootScope.language,
      loadingDone: false
    };
    angular.extend($scope, scope);

    $scope.$watch('candListEvent', () => {
      $scope.loadingDone = true;
    });

  }

  candidateMetadataModuleCtrl.$inject = ['$scope', '$rootScope', 'utils'];

  angular.module('atlas').directive('candidateMetadataModule', () => ({
    scope: {
      candListEvent: '=',
      candidate: '=',
      source: '@',
    },
    controller: candidateMetadataModuleCtrl,
    templateUrl: './employer-profile/directives/candidate-metadata-module/candidate-metadata-module.template.html',
  }));

}(angular));
