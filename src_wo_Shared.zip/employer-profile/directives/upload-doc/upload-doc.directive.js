// eslint-disable-next-line func-names
(function (angular) {
  function uploadDocCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    $uibModal,
  ) {
    let scope = {
      out: utils.out,
      loading: {
        fileCategories: false,
        upload: false,
      },
      fileUpload: {},
      fileSelected: null,
    };
    angular.extend($scope, scope);

    function getFileCategories() {
      $scope.loading.fileCategories = true;
      api.service_get('toolkit', 'document-manager/candidate-file-versions/document-types').then((response) => {
        $scope.fileCategories = [];
        angular.forEach(response.data.message, (value) => {
          $scope.fileCategories.push({ id: value.id, translation: { fr: { title: value.name_fr }, en: { title: value.name } } });
        });
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function openUploadModal() {
      if (!$scope.fileCategories || $scope.fileCategories.length < 1) {
        getFileCategories();
      }
      $scope.fileSelected = null;
      $scope.fileUpload = {};
      $scope.addToCandidateApplicationDocUpload = true;
      $scope.documentModalInstance = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/upload-doc/upload-doc-modal.template.html',
        scope: $scope,
        size: 'md',
        backdrop  : 'static',
        keyboard  : false,
      });
    }

    function isFileFormatValid(file) {
      const ext = file.toLowerCase().split('.').pop();
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'odt' || ext === 'txt'
        || ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'xlsx'
        || ext === 'xls' || ext === 'pptx' || ext === 'ppt') {
        return true;
      }
      $scope.invalidFormatFile = true;
      return false;
    }

    function isFileSizeValid(size) {
      if (size / (1048576) <= 5) {
        return true;
      }
      $scope.invalidSizeFile = true;
      return false;
    }

    $scope.clearFileModel = () => {
      $scope.fileSelected = null;
    }

    function clearFileValidationErrors() {
      $scope.haveError = false;
      $scope.emptyCategory = false;
      $scope.emptyFileName = false;
      $scope.emptyFileUrl = false;
      $scope.emptyFile = false;
    }

    function validateFileInfo(file) {
      if (file) $scope.fileSelected = file;
      clearFileValidationErrors();
      if (!$scope.fileUpload.categoryId) {
        $scope.emptyCategory = true;
        $scope.haveError = true;
      }
      if ($scope.fileUpload.source == 'url') {
        if (!$scope.fileUpload.fileName) {
          $scope.emptyFileName = true;
          $scope.haveError = true;
        }
        if (!$scope.fileUpload.url) {
          $scope.emptyFileUrl = true;
          $scope.haveError = true;
        }
      } else if (!$scope.fileSelected && !file) {
        $scope.emptyFile = true;
        $scope.haveError = true;
      } else if ( (file && ( !isFileFormatValid(file.name) || !isFileSizeValid(file.size) ) ) 
          || ( $scope.fileSelected && (!isFileFormatValid($scope.fileSelected.name) || !isFileSizeValid($scope.fileSelected.size)) )) {
          $scope.haveError = true;
        }
        if ($scope.haveError) {          
          return false;
        }
        return true;
    }

    function uploadFile() {
        $scope.loading.upload = true;
        const file = $scope.fileSelected;
        const formData = angular.copy($scope.fileUpload);

        let uploadDocPromise = {};
        // *** Set API params depending on which mode is active ***
        if ($scope.mode === 'crm-leads') {
          const params = {            
            upload_type: $scope.fileUpload.source,
            file_name: $scope.fileUpload.source === 'url' ? $scope.fileUpload.fileName : $scope.fileSelected.name.split('.')[0],
            is_deleted: 0,
            registered_users: 0,
            lead_id: $scope.candidate.id,
            type_id: $scope.fileUpload.categoryId ? $scope.fileUpload.categoryId : 7,
          };
          if ($scope.fileUpload.source === 'file') params.file = $scope.fileSelected;
          if ($scope.fileUpload.source === 'url') params.url_link = $scope.fileUpload.url;
          uploadDocPromise = api.toolkit_fileupload('document-manager/lead-documents', params);
        } else {
          //this part is not used anywhere
          const params = {
            upload_type: 'file',
            file_name: formData.description,
            is_deleted: 0,
            registered_users: 1,
            candidate_id: $scope.candidate.id,
            type_id: formData.documentCategory.id,
          };
          uploadDocPromise = api.toolkit_fileupload('document-manager/candidate-file-versions/create', params);
        }

        uploadDocPromise.then((fileUploadResponse) => {
          $scope.loading.upload = false;
          $scope.documentModalInstance.dismiss('cancel');
          if (fileUploadResponse.status === 201 || fileUploadResponse.status === 200) {
            $scope.$emit('ReloadDocuments', null);
            const msgEn = 'Your file uploaded successfully!';
            const msgFr = 'Votre fichier a été téléchargé avec succès!';
            $rootScope.api_status('alert-success', msgEn, msgFr, 'Uploaded', 'Téléchargé');
            $scope.fileSelected = null;
          }
        }).catch((error) => {
          let msgEn = "";
          let msgFr = "";
          if(error.data?.file && error.data.file[0] === 'validation.max.file') {
            msgEn = "Sorry! Your file has a wrong size, please upload a file greater than 0 and smaller than 5 MB";
            msgFr = "Désolé! Votre fichier a une taille invalide, veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à 5 Mo";
          }
          else if (error.data?.message?.file && error.data.message.file[0] === 'validation.clamav') {
            msgEn = "Sorry! This file is invalid, please upload a new file";
            msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
          }
          else if (error.data?.code === 403) {
            msgEn = "The document library is full";
            msgFr = "La bibliothèque de documents est pleine";
          }
          else {
            msgFr = "Un problème est survenu et le fichier n'a pas pu être téléchargé, veuillez essayer à nouveau ou contacter support@workland.com pour obtenir de l'aide";
            msgEn = "A problem occurred and the file could not be uploaded, please try again or contact support@workland.com for assistance";
          }
          $rootScope.api_status('alert-danger', msgEn, msgFr, "", "", 5000);
          $scope.loading.upload = false;
          $scope.documentModalInstance.dismiss('cancel');
        });

    }

    function createFile() {
      if ($scope.documentModalInstance) {
        if (validateFileInfo()) {
          $scope.documentModalInstance.dismiss('cancel');
          uploadFile();
        }
      }
    }

    scope = {
      openUploadModal,
      createFile,
      validateFileInfo,
    };
    angular.extend($scope, scope);
  }

  uploadDocCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '$uibModal',
  ];

  angular.module('atlas').directive('uploadDoc', () => ({
    scope: {
      mode: '=',
      candidate: '=',
      fileCategories: '=',
    },
    controller: uploadDocCtrl,
    templateUrl: './employer-profile/directives/upload-doc/upload-doc.template.html',
  }));
  // eslint-disable-next-line no-undef
}(angular));
