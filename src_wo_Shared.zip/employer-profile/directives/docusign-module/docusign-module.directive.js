(function (angular) {
  function docusignModuleCtrl(
    $scope,
    $rootScope,
    $uibModal,
    $ngConfirm,
    utils,
    api,
    _,
    Event,
  ) {
    const vm = this;
    let vmExtend = {
      out: utils.out,
      docusignTemplate: { selected: undefined },
      selectedDocusignTemplates: [],
      templateAttached: false,
      externalUser: [{ email: '' }, { name: '' }],
      ownexternalUser: {},
      member: { selected: [] },
      ownmember: { selected: {} },
      membersSignersSelected: [],
      externalSignersSelected: [],
      showNoSignersAlert: false,
      showNoCandidateSigner: false,
      showNoRoleNameAlert: false,
      showNoRecipientsAlert: false,
      recipientType: 'candidate',
      membersRecipients: [],
      externalUsers: [],
      candidateUser: [],
      emailConfirmed: true,
      templatesList: [],
      docusignTemplatesReady: [],
      ownDocusignTemplates: { selected: undefined },
      isDocusignAccountActive: false,
      accountMembersList: [],
      noMembersFoundError: false,
      crmJobCandidate: {
        selected: {},
      },
      candidatesWOApplication: [],
      docusignTemplatesPreviewBeforeSending: [],
      loadingDocusignTemplates: true,
      choiceConfirmed: false,
      isDocusignError: false,
      isExpiredAccount: false,
      language: $rootScope.language,
    };
    angular.extend(vm, vmExtend);

    function displayTokenExpiredMsg() {
      $rootScope.api_status(
        'alert-danger',
        'Your session has expired, please login again',
        'Votre session est expirée, veuillez vous connecter à nouveau',
      );
    }

    // when module is used as a child

    function removeTemplate() {
      Event.broadcast('DOCUSIGN_TEMPLATE_REMOVED', { removedTemplate: vm.docusignTemplate.selected });
      const templExist = vm.selectedDocusignTemplates.findIndex((templ) => templ.templateId === vm.docusignTemplate.selected.templateId);
      if (templExist > -1) vm.selectedDocusignTemplates.splice(templExist, 1);
      vm.docusignTemplate.selected = 'deleted';
      vm.templateAttached = false;
      vm.docusignCallbackData.data = vm.selectedDocusignTemplates;
      vm.sendDocusignCallback();
    }

    function resetErrors() {
      vm.showNoSignersAlert = false;
      vm.showNoRecipientsAlert = false;
      vm.showNoRoleNameAlert = false;
      vm.showNoCandidateSigner = false;
    }

    function selectDocusignTemplate(template) {
      resetErrors();
      const tempExist = vm.selectedDocusignTemplates.findIndex((templ) => templ.templateId === template.templateId);
      if (tempExist < 0) vm.selectedDocusignTemplates = [template];
      if (template.recipients?.signers?.length < 1) {
        vm.showNoSignersAlert = true;
      }
      vm.templateAttached = false;
    }

    $scope.tagHandler = function tagHandler(tag) {
      return null;
    };

    vm.nameFormat = /^[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]+(([',. -][áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z ])?[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]*)*$/;

    function removeDocusignTemplateFromList($event, $select) {
      Event.broadcast('DOCUSIGN_TEMPLATE_REMOVED', { removedTemplate: vm.docusignTemplate.selected });
      vm.templateAttached = false;
      const templExist = vm.selectedDocusignTemplates.findIndex((templ) => templ.templateId === $select.selected.templateId);
      if (templExist > -1) vm.selectedDocusignTemplates.splice(templExist, 1);
      resetErrors();
      // stops click event bubbling
      $event.stopPropagation();
      // to allow empty field, in order to force a selection remove the following line
      $select.selected = undefined;
      // reset search query
      $select.search = undefined;
      // focus and open dropdown
      // $select.activate();
    }

    // is used both when module is a child and a separate module
    function addInitialRoleName(type, index, role, order, templateId) {
      switch (type) {
        case 'member':
          vm.member.selected[index].roleName = role;
          vm.member.selected[index].routingOrder = order;
          vm.externalUser[index] = {};// @todo check
          break;
        case 'ownmember':
          vm.ownmember.selected[templateId][index].roleName = role;
          vm.ownmember.selected[templateId][index].routingOrder = order;
          vm.ownmember.selected[templateId][index].templateId = templateId;
          if (Object.keys(vm.ownexternalUser).length && Object.keys(vm.ownexternalUser[templateId]).length) {
            delete vm.ownexternalUser[templateId][index];
          }
          break;
        case 'external':
          vm.externalUser[index].roleName = role;
          vm.externalUser[index].routingOrder = order;
          vm.member.selected[index] = {};// @todo check
          vm.choiceConfirmed = true;
          break;
        case 'ownexternal':
          vm.ownexternalUser[templateId][index].roleName = role;
          vm.ownexternalUser[templateId][index].routingOrder = order;
          vm.ownexternalUser[templateId][index].templateId = templateId;
          if (Object.keys(vm.ownmember.selected).length && Object.keys(vm.ownmember.selected[templateId]).length) {
            delete vm.ownmember.selected[templateId][index];
          }
          vm.ownexternalUser[templateId][index].choiceConfirmed = true;
          break;
        case 'candidate':
          vm.member.selected[index] = {};// @todo check
          vm.externalUser[index] = {};// @todo check
          break;
        case 'owncandidate':
          if (Object.keys(vm.ownmember.selected).length && Object.keys(vm.ownmember.selected[templateId]).length) {
            delete vm.ownmember.selected[templateId][index];
          }
          if (Object.keys(vm.ownexternalUser).length && Object.keys(vm.ownexternalUser[templateId]).length) {
            delete vm.ownexternalUser[templateId][index];
          }
          break;
            // no default
      }
    }

    function validateRecipients() {
      const allSigners = vm.docusignTemplate.selected.recipients?.signers;

      if (allSigners.length === 1) {
        // if no roleName - error
        if (!allSigners[0].roleName) {
          vm.showNoRoleNameAlert = true;
          return false;
        }
        // if there is email hardcoded, error
        if (allSigners[0].email !== '') {
          vm.showNoRecipientsAlert = true;
          vm.showNoCandidateSigner = true;
          return false;
        }
        // if there is no email, will be sent to selected candidate(s) at the end
        vm.candidateUser = [{ atlasRoleName: 'candidate', role_name: allSigners[0].roleName }];// @todo to check
        return true;
      }
      if (allSigners.length > 1) {
        // check for 1 candidate selection made
        vm.candidateSignersCount = 0;
        for (let i = 0; i < allSigners.length; i += 1) {
          if (!allSigners[i].roleName) {
            vm.showNoRoleNameAlert = true;
            return false;
          }
          if (allSigners[i].atlasRecipientType !== 'member' && allSigners[i].atlasRecipientType !== 'external') {
            vm.candidateUser = [{
              atlasRoleName: 'candidate',
              role_name: allSigners[i].atlasRecipientType,
              routingOrder: allSigners[i].routingOrder,
            }];
            vm.candidateSignersCount += 1;
          }
        }
        if (vm.candidateSignersCount !== 1) return false;

        // check dropdowns with account members
        vm.membersSignersSelected = allSigners.filter((signer) => signer.atlasRecipientType === 'member');
        if (vm.membersSignersSelected.length > 0) {
          const membersSelectedArray = vm.member.selected.filter((element) => (element !== undefined && Object.keys(element).length > 0));
          if (vm.membersSignersSelected.length === Object.keys(membersSelectedArray).length) {
            vm.membersSignersSelected = JSON.parse(angular.toJson(membersSelectedArray.map((member) => {
              const memberObj = {
                atlasRoleName: 'member',
                routingOrder: member.routingOrder,
                role_name: member.roleName,
                email: member.email,
                full_name: member.name,
              };
              return memberObj;
            })));
          } else {
            vm.showNoRecipientsAlert = true;
            vm.templateAttached = false;
            return false;
          }
        }
        // check external emails
        vm.externalSignersSelected = allSigners.filter((signer) => signer.atlasRecipientType === 'external');
        if (vm.externalSignersSelected.length > 0) {
          const externalEmailsArray = vm.externalUser.filter((element) => (element.email !== undefined && element.name !== undefined && element.email !== '' && element.name !== ''));

          vm.emailConfirmed = true;
          vm.emailConfirmed = externalEmailsArray.every((user) => user.roleName);
          if (!vm.emailConfirmed) return false;
          if (vm.externalSignersSelected.length === externalEmailsArray.length) {
            vm.externalSignersSelected = JSON.parse(angular.toJson(externalEmailsArray.map((external) => ({
              atlasRoleName: 'external',
              routingOrder: external.routingOrder,
              role_name: external.roleName,
              email: external.email,
              full_name: external.name,
            }))));
          } else {
            vm.showNoRecipientsAlert = true;
            vm.templateAttached = false;
            return false;
          }
        }
        // check for all selections made
        let signersCount = 0;
        for (let i = 0; i < allSigners.length; i += 1) {
          if (allSigners[i].atlasRecipientType) signersCount += 1;
        }
        if (allSigners.length !== signersCount) return false;
        // if all good
        return true;
      }
      return false;
    }

    function sendDocusignTemplates() {
      resetErrors();
      if (validateRecipients()) {
        vm.membersRecipients = vm.membersSignersSelected;
        vm.externalUsers = vm.externalSignersSelected;
        vm.templateAttached = true;
        angular.forEach(vm.selectedDocusignTemplates, (templ) => {
          templ.atlasRecipients = vm.externalUsers.concat(vm.membersRecipients, vm.candidateUser);
        });
        vm.docusignCallbackData.data = vm.selectedDocusignTemplates;
        vm.sendDocusignCallback();
      } else {
        vm.showNoRecipientsAlert = true;
        vm.templateAttached = false;
      }
    }

    $scope.$watch('vm.templateAttached', (newValue) => {
      $scope.$emit('templateAttachedChanged', newValue);
    });
    // the end of child's methods

    // start of own methods

    function openPreviewModal() {
      vm.sendingPreviewModal = $uibModal.open({
        animation: true,
        templateUrl: './employer-profile/directives/docusign-module/docusign-preview-modal.template.html',
        size: 'lg',
        scope: $scope,
        backdrop: 'static',
      });
    }

    function showPreviewModal() {
      if (vm.selectedCandidates?.length > 0 && vm.docusignTemplatesPreviewBeforeSending.length > 0) {
        openPreviewModal();
      }
    }

    function hidePreviewModal() {
      vm.sendingPreviewModal.close();
    }

    vm.validationErrors = [];

    function validateSigners(selectedTemplate) {
      // reset errors object and recipients object for the template
      vm.validationErrors[selectedTemplate.templateId] = [];
      vm.membersRecipients = [];
      vm.externalUsers = [];
      vm.candidateUser = [];
      angular.forEach(vm.docusignTemplatesReady, (templ) => {
        if (templ.templateId === selectedTemplate.templateId) {
          templ.atlasRecipients = [];
        }
      });
      const allSigners = selectedTemplate.recipients?.signers;
      if (allSigners.length === 1) {
        // if no roleName defined - error
        if (!allSigners[0].roleName) {
          vm.validationErrors[selectedTemplate.templateId].push({
            showNoRoleNameAlert: true,
          });
          return false;
        }
        // if there is email hardcoded, error
        if (allSigners[0].email !== '') {
          vm.validationErrors[selectedTemplate.templateId].push({
            showNoRecipientsAlert: true,
            showNoCandidateSigner: true,
          });
          return false;
        }
        // if there is no email, will be sent to selected candidate(s) at the end
        vm.candidateUser = [{ atlasRoleName: 'candidate', role_name: allSigners[0].roleName }];
        return true;
      }
      if (allSigners.length > 1) {
        // check for 1 candidate selection made
        vm.candidateSignersCount = 0;
        for (let i = 0; i < allSigners.length; i += 1) {
          if (!allSigners[i].roleName) {
            vm.validationErrors[selectedTemplate.templateId].push({
              showNoRoleNameAlert: true,
            });
            return false;
          }
          if (allSigners[i].atlasRecipientType && allSigners[i].atlasRecipientType !== 'member' && allSigners[i].atlasRecipientType !== 'external') {
            vm.candidateUser.push({
              atlasRoleName: 'candidate',
              role_name: allSigners[i].atlasRecipientType,
              routingOrder: allSigners[i].routingOrder,
            });
            vm.candidateSignersCount += 1;
          }
        }
        if (vm.candidateSignersCount !== 1) {
          vm.validationErrors[selectedTemplate.templateId].push({
            showNoRecipientsAlert: true,
            candidateSignersCountWrong: true,
          });
          return false;
        }

        // check dropdowns with account members
        vm.membersSignersSelected = allSigners.filter((signer) => signer.atlasRecipientType === 'member');
        if (vm.membersSignersSelected.length > 0) {
          const membersSelectedArray = Object.values(vm.ownmember.selected[selectedTemplate.templateId]);
          if (vm.membersSignersSelected.length === Object.keys(membersSelectedArray).length) {
            vm.membersSignersSelected = JSON.parse(angular.toJson(membersSelectedArray.map((member) => {
              const memberObj = {
                atlasRoleName: 'member',
                routingOrder: member.routingOrder,
                role_name: member.roleName,
                email: member.email,
                full_name: member.name,
              };
              return memberObj;
            })));
          } else {
            vm.validationErrors[selectedTemplate.templateId].push({
              showNoRecipientsAlert: true,
            });
            return false;
          }
        }
        // check external emails
        vm.externalSignersSelected = allSigners.filter((signer) => signer.atlasRecipientType === 'external');
        if (vm.externalSignersSelected.length > 0) {
          const externalEmailsArray = Object.values(vm.ownexternalUser[selectedTemplate.templateId]);
          if (externalEmailsArray.length > 0) {
            const emailConfirmed = externalEmailsArray.every((user) => user.roleName);
            if (!emailConfirmed) {
              vm.validationErrors[selectedTemplate.templateId].push({
                showNoRecipientsAlert: true,
                emailNotConfirmed: true,
              });
              return false;
            }
          } else {
            vm.validationErrors[selectedTemplate.templateId].push({
              showNoRecipientsAlert: true,
              emailNotConfirmed: true,
            });
            return false;
          }

          if (vm.externalSignersSelected.length === externalEmailsArray.length) {
            vm.externalSignersSelected = JSON.parse(angular.toJson(externalEmailsArray.map((external) => ({
              atlasRoleName: 'external', routingOrder: external.routingOrder, role_name: external.roleName, email: external.email, full_name: external.name,
            }))));
          } else {
            vm.validationErrors[selectedTemplate.templateId].push({
              showNoRecipientsAlert: true,
            });
            return false;
          }
        }
        // check for all selections made
        let signersCount = 0;
        for (let i = 0; i < allSigners.length; i += 1) {
          if (allSigners[i].atlasRecipientType) signersCount += 1;
        }
        if (allSigners.length !== signersCount) {
          vm.validationErrors[selectedTemplate.templateId].push({
            showNoRecipientsAlert: true,
          });
          return false;
        }
        // if all good
        angular.forEach(vm.docusignTemplatesReady, (templ) => {
          if (templ.templateId === selectedTemplate.templateId) {
            vm.membersRecipients = vm.membersSignersSelected;
            vm.externalUsers = vm.externalSignersSelected;
            templ.atlasRecipients = vm.externalUsers.concat(vm.membersRecipients);
          }
        });

        return true;
      }
      //no signers
      vm.validationErrors[selectedTemplate.templateId].push({
        showNoSignersSetAlert: true,
      });
      return false;
    }

    function previewSending() {
      vm.previewNotValidated = 0;
      angular.forEach(vm.ownDocusignTemplates.selected, (templ) => {
        if (!validateSigners(templ)) {
          vm.previewNotValidated += 1;
        }
      });
      if (vm.previewNotValidated < 1) {
        vm.docusignTemplatesPreviewBeforeSending = [];
        vm.docusignTemplatesPreviewBeforeSending = vm.docusignTemplatesReady.map((template) => ({
          template_id: template.templateId,
          recipients: template.atlasRecipients,
          name: template.name,
          emailSubject: template.emailSubject,
        }));
        vm.showPreviewModal();
      }
    }

    function sendDocusignEnvelopes() {
      resetErrors();
      vm.sendingNotValidated = 0;
      angular.forEach(vm.docusignTemplatesReady, (templ) => {
        if (!validateSigners(templ)) {
          vm.sendingNotValidated += 1;
        }
      });
      if (vm.sendingNotValidated < 1) {
        angular.forEach(vm.docusignTemplatesReady, (templ) => {
          templ.atlasRecipients = templ.atlasRecipients.concat(vm.candidateUser);
        });
        const data = { applications: [] };
        angular.forEach(vm.selectedCandidates, (candidate) => {
          if (candidate.application_id) {
            let candidateRecipient = {};
            if (candidate.uuid) {
              candidateRecipient.user_uuid = candidate.uuid;
            } else {
              candidateRecipient = {
                email: candidate.email,
                full_name: `${candidate.first_name} ${candidate.last_name}`,
              };
            }
            data.applications.push({
              application_id: candidate.application_id,
              templates: vm.docusignTemplatesReady.map((template) => {
                const allRecipients = template.atlasRecipients.map((elmt) => {
                  if (elmt.atlasRoleName === 'candidate') {
                    elmt = { ...elmt, ...candidateRecipient };
                  }
                  return elmt;
                }).filter((element) => element !== undefined);
                return {
                  template_id: template.templateId,
                  recipients: allRecipients,
                };
              }),
            });
          }
        });
        vm.sendingEnvelopes = true;
        api.service_post('e-signing', 'docusign/envelopes', data).then((response) => {
          if (response.status === 201) {
            const envelopesFailed = response.data.data.failed;
            if (envelopesFailed.length > 0) {
              $rootScope.api_status(
                'alert-danger',
                'An error has occurred. Please check status of the sent Docusign templates.',
                "Une erreur s'est produite. Veuillez vérifier le statut des modèles Docusign envoyés.",
              );
            }
            vm.docusignTemplatesReady = [];
            vm.ownDocusignTemplates = { selected: undefined };
            // need to empty models for users too
            vm.ownexternalUser = [{ email: '' }, { name: '' }];
            vm.ownmember = { selected: [] };
            vm.membersSignersSelected = [];
            vm.externalSignersSelected = [];
            vm.membersRecipients = [];
            vm.externalUsers = [];
            vm.candidateUser = [];
            vm.docusignTemplatesPreviewBeforeSending = [];
            getDocusignEnvelopes();
          }
          vm.sendingEnvelopes = false;
        }).catch((error) => {
          vm.sendingEnvelopes = false;
          switch (error.status) {
            case 401:
              displayTokenExpiredMsg('token_expired');
              break;
            case 403:
              $rootScope.api_status(
                'alert-danger',
                'You do not have the required permissions to view applications',
                "Vous n'avez pas les permissions nécessaires pour visualiser les candidatures.",
              );
              break;
            default:
              $rootScope.api_status(
                'alert-danger',
                'An error has occurred while sending DocuSign templates.',
                "Une erreur est survenue lors de l'envoi des modèles DocuSign.",
              );
          }
        });
      }
    }

    function prepareCandidatesList() {
      const candidatesArrangedList = [];
      const candidatesWOApplication = [];
      vm.candidatesWOApplication = [];
      angular.forEach(vm.selectedCandidates, (candidate) => {
        if (candidate.application_id) {
          candidatesArrangedList.push({
            applicationId: candidate.application_id,
            name: `${candidate.first_name} ${candidate.last_name}`,
            isOpen: +vm.candidateIsOpen === +candidate.application_id,
          });
        } else {
          // CRM
          candidatesWOApplication.push(candidate);
        }
      });

      if (candidatesWOApplication.length > 0) vm.candidatesWOApplication = candidatesWOApplication;
      return candidatesArrangedList;
    }

    function prepareDocusignEnvelopes(dsEnvelopes) {
      const candidateDocusignEnvelopes = {};
      angular.forEach(vm.selectedCandidates, (candidate) => {
        let candidateEnvelopes = [];
        if (candidate.application_id && dsEnvelopes[candidate.application_id]) {
          candidateEnvelopes = dsEnvelopes[candidate.application_id].docusign_envelopes.map((elmt) => ({
            emailSubject: elmt.emailSubject,
            status: utils.translateDocusignEnvelopesStatus(elmt.status),
            senderEmail: elmt.sender?.email,
            senderUserName: elmt.sender?.userName,
            sent_on: utils.addTranslationsToMomentDate(elmt.sentDateTime, 'LLL'),
          }));
          const appId = candidate.application_id;
          candidateDocusignEnvelopes[appId] = candidateEnvelopes;
        }
      });
      return candidateDocusignEnvelopes;
    }

    function getDocusignEnvelopes() {
      vm.loadingDocusignEnvelopes = true;
      vm.docusignEnvelopesError = false;
      const arrayOfApplicationIds = _.pluck(vm.selectedCandidates, 'application_id').filter((a) => !!a);
      if (arrayOfApplicationIds.length > 0) {
        api.service_get('e-signing', 'docusign/envelopes', { 'application_ids[]': arrayOfApplicationIds }).then((response) => {
          if (response.status === 200) {
            vm.docusignEnvelopes = prepareDocusignEnvelopes(response.data.data);
          }
          vm.loadingDocusignEnvelopes = false;
        }).catch((error) => {
          vm.loadingDocusignEnvelopes = false;
          vm.docusignEnvelopesError = true;
          switch (error.status) {
            case 401:
              displayTokenExpiredMsg('token_expired');
              break;
            case 403:
              $rootScope.api_status(
                'alert-danger',
                'You do not have the required permissions to view applications',
                "Vous n'avez pas les permissions nécessaires pour visualiser les candidatures.",
              );
              break;
            default:
              $rootScope.api_status(
                'alert-danger',
                'An error has occurred while fetching DocuSign envelopes.',
                'Une erreur est survenue lors de la récupération des enveloppes DocuSign.',
              );
          }
        });
      } else {
        vm.loadingDocusignEnvelopes = false;
      }
      if (!vm.isChildModule) vm.candidatesList = prepareCandidatesList();
    }

    function fetchAccountMembers() {
      const accountUsers = angular.copy($rootScope.currentUser.account_user).filter((user) => !![10, 20, 30, 50, 80, 100].includes(user.role_id));
      angular.forEach(accountUsers, (accountUser) => {
        accountUser.name = `${accountUser.user.first_name} ${accountUser.user.last_name}`;
        accountUser.email = `${accountUser.user.email}`;
      });
      vm.accountMembersList = accountUsers;
      vm.noMembersFoundError = !(Array.isArray(accountUsers) && accountUsers.length);
    }

    function fetchDocusignTemplates() {
      vm.loadingDocusignTemplates = true;
      api.service_get('e-signing', 'docusign/templates').then((response) => {
        if (response?.data?.data !== null) {
          vm.templatesList = response.data.data.map((tmpl) => {
            if (!tmpl.name || tmpl.name == '') tmpl.name = vm.out('Modèle sans titre', 'Untitled template');
            if (!tmpl.emailSubject || tmpl.emailSubject == '') tmpl.emailSubject = vm.out('Pas de sujet du courriel', 'No email subject');
            return {
              name: tmpl.name,
              templateId: tmpl.templateId,
              emailSubject: tmpl.emailSubject,
              recipients: {
                signers: tmpl.recipients?.signers.length > 0
                  ? tmpl.recipients.signers.map((signer) => (
                    { roleName: signer.roleName, email: signer.email, routingOrder: signer.routingOrder }))
                  : [],
              },
            };
          });
        }
        vm.loadingDocusignTemplates = false;
      }).catch((error) => {
        vm.loadingDocusignTemplates = false;
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          default:
            $rootScope.api_status(
              'alert-danger',
              'No list of Docusign templates retrieved.',
              'Aucune liste de modèles de Docusign récupérée.',
            );
        }
      });
    }

    function getDocusignAccount() {
      vm.checkingDocusignAccount = true;
      vm.isExpiredAccount = false;
      vm.isDocusignError = false;
      vm.isDocusignAccountActive = false;
      api.service_get('e-signing', 'docusign/auth/accounts/my-account').then((response) => {
        if (response?.data?.data !== null) {
          vm.isDocusignAccountActive = true;
          fetchAccountMembers();
          if (!vm.isCrm) {
            getDocusignEnvelopes();
          } else if (vm.selectedCandidates.length === 1 && vm.selectedCandidates[0].applicationList.length && !vm.selectedJob
            && vm.selectedCandidates[0].jobList.length > 0) {
            vm.crmJobCandidate.selected = vm.selectedCandidates[0].jobList[0];
            vm.jobId = vm.selectedCandidates[0].jobList[0].id;
          } else if (vm.selectedCandidates.length > 1) {
            vm.crmJobCandidate.selected = vm.commonJobList[0];
            vm.jobId = vm.commonJobList[0].id;
          } else {
            // this is case when we unselect and reselect the same candidate, the applicationList is empty but will be refilled
            // when data arrives
            vm.jobId = null;
            vm.crmJobCandidate.selected = {};
          }
        } else {
          // no account
          vm.isDocusignAccountActive = false;
        }
        vm.checkingDocusignAccount = false;
      }).catch((error) => {
        switch (error.status) {
          case 401:
            displayTokenExpiredMsg('token_expired');
            break;
          case 400:
            vm.isDocusignAccountActive = false;
            vm.isExpiredAccount = true;
            break;
          default:
            vm.isDocusignError = true;
        }
        vm.checkingDocusignAccount = false;
      }).finally(() => {
        if (vm.isDocusignAccountActive) {
          fetchDocusignTemplates();
          if (vm.isCrm) filterSelectedCandidates();// extra call for CRM when we first open module and account data is late
        }
      });
    }

    function removeTemplateFromList(template) {
      const templExist = vm.docusignTemplatesReady.findIndex((templ) => templ.templateId === template.templateId);
      if (templExist > -1) vm.docusignTemplatesReady.splice(templExist, 1);
      const templExistInPreview = vm.docusignTemplatesPreviewBeforeSending.findIndex((tmpl) => tmpl.template_id === template.templateId);
      if (templExistInPreview > -1) vm.docusignTemplatesPreviewBeforeSending.splice(templExistInPreview, 1);
    }

    function pushTemplateToList(template) {
      vm.docusignTemplatesReady.push(template);
    }

    if (!vm.isChildModule) {
      getDocusignAccount();
    }

    // CRM - to be tested
    function filterSelectedCandidates() {
      if (vm.selectedCandidates.length === 1 && vm.selectedCandidates[0].applicationList.length) {
        if (!vm.selectedJob) {
          vm.crmJobCandidate.selected = vm.selectedCandidates[0].jobList[0];
          vm.jobId = vm.selectedCandidates[0].jobList[0].id;
        }
        const application = vm.selectedCandidates[0].applicationList.find(((application) => +application.job_id === +vm.jobId));
        vm.selectedCandidates[0].application_id = application?.id ?? null;
      } else if (vm.selectedCandidates.length > 1) {
        vm.selectedCandidates.forEach((candidate) => {
          const application = vm.commonApplications.find(((application) => +application.job_id === +vm.jobId && +application.candidate_user_id === +candidate.user_id));
          candidate.application_id = application?.id ?? null;
        });
      }
      if (vm.isDocusignAccountActive) getDocusignEnvelopes();
    }

    // CRM
    function switchJob(jobSelected) {
      vm.jobId = jobSelected?.id ?? null;
      vm.selectedJob = true;
      if (Number.isInteger(vm.jobId) && vm.jobId > 0) {
        filterSelectedCandidates();
      }
    }

    $scope.$watch('vm.selectedCandidates', (currentValue, oldValue) => {
      if (!vm.isChildModule && !vm.isCrm) {
        if ((oldValue.length !== currentValue.length) || (oldValue.length === currentValue.length && currentValue.length === 1 && +currentValue[0].user_id !== +oldValue[0].user_id)) {
          if (vm.isDocusignAccountActive) getDocusignEnvelopes();
        }
      }
    }, true);

    $scope.$watch('vm.readyJobs', (dataReady) => {
      // on CRM, we need to wait for the data to be ready - watching candidates
      if (!vm.isChildModule && dataReady) {
        filterSelectedCandidates();
      }
    }, true);

    vmExtend = {
      selectDocusignTemplate,
      removeDocusignTemplateFromList,
      sendDocusignTemplates,
      removeTemplate,
      addInitialRoleName,
      sendDocusignEnvelopes,
      pushTemplateToList,
      removeTemplateFromList,
      switchJob,
      previewSending,
      showPreviewModal,
      hidePreviewModal,
    };
    angular.extend(vm, vmExtend);
  }

  docusignModuleCtrl.$inject = ['$scope', '$rootScope', '$uibModal', '$ngConfirm', 'utils', 'api', '_', 'Event',];

  angular.module('atlas').directive('docusignModule', () => ({
    scope: {},
    bindToController: {
      selectedCandidates: '=',
      docusignTemplatesList: '=?',
      accountMembers: '=?',
      sendDocusignCallback: '&?',
      docusignCallbackData: '=?',
      isChildModule: '=?',
      noApplicationFound: '=?',
      commonApplications: '=?',
      commonJobList: '=?',
      isCrm: '=?',
      readyJobs: '=?',
    },
    controller: docusignModuleCtrl,
    controllerAs: 'vm',
    templateUrl: './employer-profile/directives/docusign-module/docusign-module.template.html',
  }));
}(angular));
