(function (angular) {
  function EmployeeBenefitsController(
    $scope,
    $rootScope,
    utils,
    api,
    storageService,
    Pager,
  ) {
    const scopeVariables = {
      out: utils.out,
      benefit: {},
      updated: {},
      benefit_icons: [],
      employee_benefit: { translations: [] },
      employeeBenefits: [],
      creatingBenefit: false,
      pagerBenefits: {},
      pageSizeSelect : [15, 20, 25, 50],
      pageSize: 15, 
      language: $rootScope.language,
    };
    angular.extend($scope, scopeVariables);

    $scope.tagHandler = function (tag) {
      return null;
    };

    let msgFr; let msgEn;
    let waitMsgFr; let waitMsgEn;

    function getBenefitIcons() {
      $scope.benefit.icon = 'icon-default';
      $scope.benefit_icons.push({ name: 'Default', nameFr: 'Défaut', class: 'icon-default' });
      $scope.benefit_icons.push({ name: 'Bonus', nameFr: 'Bonus', class: 'icon-bonus' });
      $scope.benefit_icons.push({ name: 'Breakfast', nameFr: 'Déjeuner', class: 'icon-breakfast' });
      $scope.benefit_icons.push({ name: 'Career development', nameFr: 'Développement de carrière', class: 'icon-career_development' });
      $scope.benefit_icons.push({ name: 'Coffee', nameFr: 'Café', class: 'icon-coffee' });
      $scope.benefit_icons.push({ name: 'Crib', nameFr: 'Berceau', class: 'icon-crib' });
      $scope.benefit_icons.push({ name: 'Groceries', nameFr: '‎Épicerie', class: 'icon-groceries' });
      $scope.benefit_icons.push({ name: 'Health insurance', nameFr: 'Assurance santé', class: 'icon-health_insurance' });
      $scope.benefit_icons.push({ name: 'Incentive', nameFr: 'Motivation', class: 'icon-incentive' });
      $scope.benefit_icons.push({ name: 'Investment', nameFr: 'Investissement', class: 'icon-investment' });
      $scope.benefit_icons.push({ name: 'Laptop', nameFr: 'Portable', class: 'icon-laptop' });
      $scope.benefit_icons.push({ name: 'Maternity', nameFr: 'Maternité', class: 'icon-maternity' });
      $scope.benefit_icons.push({ name: 'Parking', nameFr: 'Stationnement', class: 'icon-parking' });
      $scope.benefit_icons.push({ name: 'Promotion', nameFr: 'Promotion', class: 'icon-promotion' });
      $scope.benefit_icons.push({ name: 'Salary', nameFr: 'Salaire', class: 'icon-salary' });
      $scope.benefit_icons.push({ name: 'Sick leave', nameFr: 'Congé de maladie', class: 'icon-sick_leave' });
      $scope.benefit_icons.push({ name: 'Social security', nameFr: 'Sécurité sociale', class: 'icon-social_security' });
      $scope.benefit_icons.push({ name: 'Tax', nameFr: 'Taxe', class: 'icon-tax' });
      $scope.benefit_icons.push({ name: 'Team lunch', nameFr: 'Repas d\'équipe', class: 'icon-team_lunch' });
      $scope.benefit_icons.push({ name: 'Transfer', nameFr: 'Transfert', class: 'icon-transfer' });
      $scope.benefit_icons.push({ name: 'Transportation', nameFr: 'Transport', class: 'icon-transpotation' });
    }

    function fetchBenefits(currentPage, pageSize) {
      $scope.employeeBenefits = [];
      $scope.loadingDone = false;
      if (!pageSize) { pageSize = $scope.pageSize; }
      const page = currentPage || 1;
      const benefitsParams = {
        page,
        pageSize,
      }
      const promise = api.service_get('jobs', `benefit/account/${$scope.current_user_account_id}/benefits`, benefitsParams);
      promise.then((response) => {
        if (response.status === 200) {
          $scope.employeeBenefits = response.data.data;
          $scope.total = response.data.total;
          $scope.pagerBenefits = Pager.GetPager($scope.total, response.data.current_page, response.data.per_page);
        } else {
          $rootScope.api_status('alert-danger', 'Failed to load benefits', 'Échec du chargement des avantages');
        }
        $scope.loadingDone = true;
      }).catch((error) => {
        $scope.loadingDone = true;
        if (error.status === 404) {
          $rootScope.api_status('alert-success', 'Create your first benefit here', 'Créez votre première avantage ici');
        } else {
          $rootScope.api_status('alert-danger', 'Failed to load benefits', 'Échec du chargement des avantages');
        }        
      });
    }

    function addBenefits(benefit) {
      if($scope.creatingBenefit) {
        return;
      }

      $scope.hasFrError = !benefit.fr;
      $scope.hasEnError = !benefit.en;
      if (!$scope.hasFrError && !$scope.hasEnError) {
        if(!$scope.creatingBenefit) {
          $scope.creatingBenefit = true;
        }
        $scope.employee_benefit.icon_name = benefit.icon;
        $scope.employee_benefit.translations = [];
        $scope.employee_benefit.translations.push({
          locale: 'en',
          content: benefit.en,
        });
        $scope.employee_benefit.translations.push({
          locale: 'fr',
          content: benefit.fr,
        });
        waitMsgEn = 'Adding benefit...';
        waitMsgFr = "Ajout d'avantage en cours...";
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);

        api.service_post('jobs', 'benefit', $scope.employee_benefit).then((response) => {
          if (response.status === 200 || response.status === 201) {
            const { data } = response;
            api.service_query('jobs', `benefit/${data.id}/account/${$scope.current_user_account_id}`, 'PUT', {}).then((res) => {
              if (res.status === 200 || res.status === 201) {
                msgEn = 'Benefits added';
                msgFr = 'Avantages ajoutés';
                $rootScope.api_status('alert-success', msgEn, msgFr);
                $scope.benefit = {};
                $scope.benefit.icon = 'icon-default';
                fetchBenefits();
                $scope.creatingBenefit = false;
              } else {
                $rootScope.api_status('alert-danger', 'Failed to add benefit', 'Échec de l\'ajout de l\'avantage');
                $scope.creatingBenefit = false;
              }
            }).catch((err) => {
              $rootScope.api_status('alert-danger', 'Failed to add benefit', 'Échec de l\'ajout de l\'avantage');
              $scope.creatingBenefit = false;
            });
          } else {
            $scope.creatingBenefit = false;
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger');
          $scope.creatingBenefit = false;
        });
      }
    }

    function editModeOn(benefit) {
      $scope.editMode = {};
      $scope.editMode.id = benefit.id;
      $scope.updated.icon_name = benefit.icon_name;
      $scope.updated.benefit_en = benefit.translations[0].content;
      $scope.updated.benefit_fr = benefit.translations[1].content;
      $scope.updated.benefit_enError = false;
      $scope.updated.benefit_frError = false;
    }

    function editModeOff() {
      $scope.updated = {};
      $scope.editMode = {};
    }

    function updateBenefits(benefitId) {
      $scope.updated.benefit_enError = !$scope.updated.benefit_en;
      $scope.updated.benefit_frError = !$scope.updated.benefit_fr;
      if (!$scope.updated.benefit_enError && !$scope.updated.benefit_frError) {
        $scope.employee_benefit.icon_name = $scope.updated.icon_name;
        $scope.employee_benefit.translations.push({
          locale: 'en',
          content: $scope.updated.benefit_en,
        });
        $scope.employee_benefit.translations.push({
          locale: 'fr',
          content: $scope.updated.benefit_fr,
        });
        waitMsgEn = 'Updating benefit...';
        waitMsgFr = "Mise à jour de l'avantage en cours...";
        $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
        const promise = api.service_post('jobs', `benefit/${benefitId}`, $scope.employee_benefit, 'update');
        promise.then((response) => {
          if (response.status === 201 || response.status === 200) {
            editModeOff();
            fetchBenefits($scope.pagerBenefits.currentPage);
            msgEn = 'Benefit updated';
            msgFr = 'Avantage mis à jour';
            $rootScope.api_status('alert-success', msgEn, msgFr);
          }
        }).catch(() => {
          $rootScope.api_status('alert-danger', 'Failed to update the benefit', 'Échec du mis à jour d\'avantage');
        });
      }
    }

    function deleteBenefits(id) {
      waitMsgEn = 'Deleting benefit...';
      waitMsgFr = "Suppression d'avantage en cours...";
      $rootScope.api_status('waiting', waitMsgEn, waitMsgFr);
      const promise = api.service_delete('jobs', `benefit/${id}`);
      promise.then((response) => {
        if (response.status === 200) {
          fetchBenefits($scope.pagerBenefits.currentPage);
          msgEn = 'Benefit deleted';
          msgFr = 'Avantage supprimé';
          $rootScope.api_status('alert-success', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'Failed to delete the benefit', 'Échec de la suppression d\'avantage');
      });
    }


    function init() {
      $scope.current_user_account_id = JSON.parse(storageService.getItem('account_id'));
      getBenefitIcons();
      fetchBenefits();
    }

    init();

    const scopeMethods = {
      addBenefits,
      fetchBenefits,
      updateBenefits,
      deleteBenefits,
      editModeOn,
      editModeOff,
      getBenefitIcons,
    };
    angular.extend($scope, scopeMethods);
  }

  EmployeeBenefitsController.$inject = ['$scope',
    '$rootScope',
    'utils',
    'api',
    'storageService',
    'Pager',
  ];

  angular.module('atlas').controller('EmployeeBenefitsController', EmployeeBenefitsController);
}(angular));
