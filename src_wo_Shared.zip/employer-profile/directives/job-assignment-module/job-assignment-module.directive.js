( function ( angular ) {

    'use strict';
    var app = angular.module( 'atlas');

    app.directive( 'jobAssignmentModule', function () {
        return {
	    scope: {},
	    bindToController: {
            init: '=',
            enableActions: '=',
            recruiterId: '@',
            recruiter: '=',
            permissions:'@',
            currentUserPermissions: '@'
	    },
	    controllerAs: 'vm',
        controller: jobAssignmentModuleCtrl,
	    templateUrl: './employer-profile/directives/job-assignment-module/job-assignment-module.template.html'
	};
    } );
    
    app.controller('jobAssignmentModuleCtrl', jobAssignmentModuleCtrl);
    jobAssignmentModuleCtrl.$inject = ['$scope', '$rootScope', 'api', '_', 'utils', '$uibModal', 'Pager', '$document', 'storageService'];
    function jobAssignmentModuleCtrl( $scope, $rootScope, api, _, utils, $uibModal, Pager, $document, storageService) {

        var vm = this;
        var formModel = {
            settings: {
                editMode: false,
                viewCollection: true,
                viewForm: false,
                adminForm: false
            }
        };
        var formModelInitial = angular.copy( formModel );
        var initOnce = _.once( init );
        var admin = {
            module: 'admin-module',
            label: 'Admin',
            icon: 'wrench'
        };

        var vmExtend = {
            out: utils.out,
            formModel: formModel,
            datePicker: false,
            dateOptions: {
                formatYear: 'yy',
                startingDay: 1
            },
            advancedOptions: false,
            closeEditForm: closeEditForm,
            deleteAssignment: deleteAssignment,
            openDatePicker: openDatePicker,
            toggleAdvancedEditForm: toggleAdvancedEditForm,
            admin: admin,
            jsonjobData: {}, 
            assignedJobIdList: [], 
            jobIdList: [], 
            selectedChanged: selectedChanged, 
            assignMultiJobs: assignMultiJobs, 
            isAsignedJob: isAsignedJob, 
            closeMulitEditForm: closeMulitEditForm,
            checkInput: checkInput,
            ShowAdvance: ShowAdvance, 
            getJobsToAssign: getJobsToAssign,
            pageSizeSelectJobs : [10, 25, 50, 75, 100, 250, 500],
            pageSizeJobs: 10, 
            currentUser: $rootScope.currentUser,
            itemsJobs: [],
            assignedCompanys: [],
            items: [],
            companies: [],
            loadingJobsDone: false,
            noJobsShared: false,
            recurencePeriods: utils.strings.recurencePeriods,
            priorities: utils.strings.priorities,
            genericConfirmMessage: utils.genericConfirmMessage,
        };
        angular.extend( vm, vmExtend );        

        $scope.$watch( 'vm.init', function ( initModule ) {
            if ( initModule ) {
                initOnce();
            }
        } );

        function init() {
            vm.assignedJobs = [];
            var user_id = vm.recruiterId;
            var params = {}; 
            if($rootScope.currentUser.permissions.isRecruiter && !$rootScope.currentUser.permissions.isAdminRecruiter) {
                var route = 'job/current-user/jobs';
            }
            else {
                var route ='job/user/'+user_id+'/jobs';
            }          
            var promise = api.service_get('jobs', route, params).then(function (response) {
                if(response.data.length > 0) {
                    vm.assignedJobs = response.data;
                    vm.assignedJobIdList = [];
                    for ( var iIndex = 0; iIndex < vm.assignedJobs.length; iIndex++ ) {
                        vm.assignedJobs[iIndex].status = (vm.assignedJobs[iIndex].published_external === 1) ? "" : vm.out("[privé] ", "[private] ");
                        vm.assignedJobIdList.push( vm.assignedJobs[iIndex].id );
                    }
                    vm.noJobsShared = false;
                }
                else {                   
                    vm.noJobsShared = true;
                    if($rootScope.currentUser.permissions.isRecruiter && !$rootScope.currentUser.permissions.isAdminRecruiter) {
                        $scope.messageError = vm.out("Vous n'avez actuellement aucun emploi partagé avec vous.", "You do not have any jobs shared with you at present.");
                    } else if (+vm.recruiter.value.permissions === 30) {
                        $scope.messageError = vm.out("Les administrateurs ont accès à toutes les offres d'emploi par défaut.", "Administrators have access to all job postings by default.")
                    } else {
                        $scope.messageError = vm.out("Actuellement aucun emploi n'est partagé avec ce membre.", "No jobs were shared with this member at present.");
                    }
                }
                
            }).catch(function (error) {
                vm.noJobsShared = true;
                if(error.status == "404"){
                    if($rootScope.currentUser.permissions.isRecruiter && !$rootScope.currentUser.permissions.isAdminRecruiter) {
                        $scope.messageError = vm.out("Vous n'avez actuellement aucun emploi partagé avec vous.", "You do not have any jobs shared with you at present.");
                    } else if (+vm.recruiter.value.permissions === 30) {
                        $scope.messageError = vm.out("Les administrateurs ont accès à toutes les offres d'emploi par défaut.", "Administrators have access to all job postings by default.")
                    } else {
                        $scope.messageError = vm.out("Actuellement aucun emploi n'est partagé avec ce membre.", "No jobs were shared with this member at present.");
                    }               
                }
            });

            return promise;
        }

        function deleteAssignment( assignment ) {
             
            var user_ids = [];
            user_ids.push(vm.recruiterId);
            var data = {
                'user_ids': user_ids
            }
            var jobId = assignment.id;
            var promise = api.service_delete('jobs', 'job/'+jobId+'/users', data).then((response) => {
                // needs to be handled!
            }).catch(() => {
                // needs to be handled!
            });

            return promise.then( init );
        }

        function checkAssignedJobs() {
            _.each(vm.assignedJobIdList, (jobId) => {
                _.find(vm.itemsJobs, (item) => {
                    if(item.id == jobId) {
                        item.checked = true;
                    }
                    return item.id == jobId;
                });
            });
        }

        function handleJobAssignmentDetails() {
            let locationIds = [];
            _.each(vm.jobs, (job) => {
                job.status = (job.published_external === 1) ? "" : vm.out("[privé] ", "[private] ");
                if (job.locations.length > 0) {
                    job.locations.forEach((item) => {
                      locationIds.push(item.location_id);
                    });
                }              
            })

            // Convert into set to eliminate duplicates, then convert back to array for easy use
            locationIds = Array.from(new Set(locationIds));
            if (locationIds.length > 0) {
              api.service_get('shared', 'location/list-by-key-and-values', {
                key: 'id',
                'values[]': locationIds,
              }).then((locationData) => {
                // convert response data to array for easier use
                let locations = [];
                if (locationData.data) {
                  locations = Object.values(locationData.data);
                  // Add location names to each job
                  for (let i = 0; i < vm.jobs.length; i += 1) {
                    // eslint-disable-next-line no-restricted-syntax
                    for (let j = 0; j < locations.length; j += 1) {
                      if (vm.jobs[i].locations[0] && vm.jobs[i].locations[0].location_id === locations[j].id) {
                        vm.jobs[i].city = locations[j].city ? locations[j].city : '';
                        vm.jobs[i].province = locations[j].province ? locations[j].province : '';
                      }
                    }
                  }
                } else {
                    utils.genericConfirmMessage('red', null, vm.out('Désolé, une erreur s\'est produite lors de la récupération des lieux de postes.',
                    'Sorry, there was an error while fetching the locations of the jobs.'));
                }
              }).catch( () => {
                utils.genericConfirmMessage('red', null, vm.out('Désolé, une erreur s\'est produite lors de la récupération des lieux de postes.',
                    'Sorry, there was an error while fetching the locations of the jobs.'));
                vm.loadingJobsDone = true;
              })
            }
        }

        function getJobsToAssign(idCompany) {            

            vm.loadingJobsDone = false;

            vm.pagerJobs = {};
            vm.setPageJobs = setPageJobs;
            vm.setPageJobs(1);

            function setPageJobs(page) {
                if (page < 1 || page > vm.pagerJobs.totalPages) {
                    return; 
                }

                //this does not work for Confidentiel, only for companies
                vm.jobs = [];
                vm.jobIdList = [];
                vm.itemsJobs = [];
                vm.assignedCompanys = [];
                const formSearchJobs = angular.copy(vm.job_search);
                const params = {
                    "pageSize": vm.pageSizeJobs,
                    "page": page,
                    "search": formSearchJobs
                };

                let request = "";
                // employer sees all jobs of his account
                request = api.service_get('jobs', 'job/current-account/jobs', params);
                vm.promiseJobs = request.then((response) => {
                    const res = response.data.data;
                    if(res.length) {
                        vm.itemsJobs = vm.jobs = res;
                        const totalJobs = response.data.total;
                        vm.pagerJobs = Pager.GetPager(totalJobs, page, vm.pageSizeJobs);
                        vm.assignedCompanys.push({
                            name: $rootScope.currentUser.profile_page[0].name,
                            id: $rootScope.currentUser.account.id
                        });
                        vm.items = vm.assignedCompanys;
                        handleJobAssignmentDetails();
                    }
                    vm.loadingJobsDone = true;
                }).catch(() => {
                    vm.loadingJobsDone = true;
                });
            }
        }

        function selectedChanged(jobchecked, jobId ){
            var index = vm.jobIdList.indexOf( jobId );
            if ( jobchecked && index == -1) {
                vm.jobIdList.push( jobId );                   
            } else {
                if( !jobchecked || index != -1) {   
                    vm.jobIdList.splice( index, 1 );
                }
            } 
        }

        function assignMultiJobs() {
            _.each(vm.jobIdList, function (jobId){
                var read_user_ids = new Array();
                var write_user_ids = new Array();
                read_user_ids.push(vm.recruiterId); 
                if(vm.write_access){                    
                    write_user_ids.push(vm.recruiterId);
                }
                else{
                    write_user_ids = [];
                }
                var data = {
                    'read_only_user_ids': read_user_ids,
                    "read_and_write_user_ids": write_user_ids
                }
                var promise = vm.promiseAssignMutil = api.service_query('jobs', 'job/'+jobId+'/users', 'PUT', data).
                then(function(response){
                    init();
                    closeMulitEditForm();
                }).catch(function(error){
                    if(error.status == "403"){
                        utils.genericConfirmMessage('red',null, vm.out("Désolé, vous n'avez pas accès.", "Sorry, you do not have access."));
                    }
                    utils.genericConfirmMessage('red',null, vm.out("Désolé, une erreur s'est produite. Veuillez réessayer ou contacter notre équipe d'assistance à l'adresse support@workland.com pour plus d'aide.", "Sorry, an error has occurred. Please try again or contact our support team at support@workland.com for further assistance."));
                })
                return promise;
            });
        }

        function isAsignedJob( jobID, jobchecked ) {
            if ( vm.assignedJobIdList ) {
                var index = vm.assignedJobIdList.indexOf( jobID );
                if ( index != -1 ) {
                    jobchecked = true;
                    return true;
                } else {
                    jobchecked = false;
                    return false;
                }
            }
        }

        function closeMulitEditForm() {
            vm.formModel = angular.copy( formModelInitial );
            vm.promiseAssignMutil = null;
            vm.inputFormNew.$setPristine();
            vm.jsonjobData = {};

            for ( var iIndex = 0; iIndex < vm.jobs.length; iIndex++ ) {
                vm.jobs[iIndex].checked = false;
                vm.jobs[iIndex].deadline = "";
                vm.jobs[iIndex].priority = "";
                vm.jobs[iIndex].recurrence = "";
                vm.jobs[iIndex].target_num_contacted = "";
                vm.jobs[iIndex].target_num_candidates = "";
                vm.jobs[iIndex].target_num_interviewed = "";
            }            
            vm.jobIdList = [];
            vm.jobs = [];
        }

        //For the asign job button status
        function checkInput() {
            if ( !vm.jobIdList || vm.jobIdList.length == 0 ) {
                //no job selected, disabled = true
                return true;
            }
            return false;
        }

        var advanceModalInstance;
        $scope.showInputPop = function ( job ) {
            vm.advanceDeadline = job.deadline;
            vm.advancePriority = job.priority;
            vm.advanceRecurrence = job.recurrence;
            vm.advanceContactedTarget = job.target_num_contacted;
            vm.advanceFlaggedTarget = job.target_num_candidates;
            vm.advanceInterviewedTarget = job.target_num_interviewed;

            advanceModalInstance = $uibModal.open( {
                animation: true,
                templateUrl: './employer-profile/directives/job-assignment-module/advance-modal-content.template.html',
                scope: $scope
            } );
            var advancePromise = advanceModalInstance.result.then( function ( selectedItem ) {
                var objJob = {};
                if ( vm.jsonjobData[job.id] == undefined ) {
                    var objJob = {};
                } else {
                    objJob = vm.jsonjobData[job.id];
                }
                job.deadline = vm.advanceDeadline;
                objJob["deadline"] = vm.advanceDeadline;
                job.priority = vm.advancePriority;
                objJob["priority"] = vm.advancePriority;
                job.recurrence = vm.advanceRecurrence;
                objJob["recurrence"] = vm.advanceRecurrence;
                job.target_num_contacted = vm.advanceContactedTarget;
                objJob["target_num_contacted"] = vm.advanceContactedTarget;
                job.target_num_candidates = vm.advanceFlaggedTarget;
                objJob["target_num_candidates"] = vm.advanceFlaggedTarget;
                job.target_num_interviewed = vm.advanceInterviewedTarget;
                objJob["target_num_interviewed"] = vm.advanceInterviewedTarget;
                vm.jsonjobData[job.id] = objJob;
                return advancePromise;
            } );
        };

        function returnUndefin( sObj ) {
            if ( sObj == undefined ) {
                return ""
            }
            return sObj;
        }
        // this functionality is not used for a long time (since WP) - please check if we need it at the react rewrite step
        function ShowAdvance( event, showflg, job ) {
            var showAdvanceDiv = document.getElementById( "showAdvanceDiv" );
            if ( !showAdvanceDiv ) {
                var style = document.createElement( 'showAdvanceDivstyle' );
                style.type = 'text/css';
                var cssHtml = ".animate-show-hide.ng-hide {";
                cssHtml += "opacity: 0;";
                cssHtml += "}";
                cssHtml += ".animate-show-hide.ng-hide-add,";
                cssHtml += ".animate-show-hide.ng-hide-remove {";
                cssHtml += "      transition: all linear 1s;";
                cssHtml += "}";
                style.innerHTML = cssHtml;
                document.getElementsByTagName( 'head' )[0].appendChild( style );

                var body = angular.element( document ).find( 'body' ).eq( 0 );
                var strDiv = "<div class='animate-show-hide' id='showAdvanceDiv' ";
                strDiv += "style='position:fixed;background-color:white;border-style:solid;";
                strDiv += "border-width:1px;padding:5px;z-index:99;width:220px;"
                strDiv += "height:140px;'>";
                var tempDiv = angular.element( strDiv );
                body.append( tempDiv );
                showAdvanceDiv = document.getElementById( "showAdvanceDiv" );
            }

            if ( job ) {
                if ( job.checked ) {
                    if ( showflg == 1 ) {
                        var strHtml = "<table style='padding:5px;'>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Date limite', 'Deadline' ) + "</td>";
                        strHtml += "<td>: " + utils.toDateStr( new Date( job.deadline ) ) + "</td></tr>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Sélectionner le niveau de priorité', 'Select Priority' ) + "</td>";
                        strHtml += "<td>: " + job.priority + "</td>";
                        strHtml += "</tr>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Sélectionner la récurrence', 'Select Recurrence' ) + "</td>";
                        strHtml += "<td>: " + job.recurrence + "</td>";
                        strHtml += "</tr>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Nombre d’approches directes ciblé', 'Contacted target' ) + "</td>";
                        strHtml += "<td>: " + returnUndefin( job.target_num_contacted ) + "</td>";
                        strHtml += "</tr>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Nombre de candidatures soumises', 'Flagged target' ) + "</td>";
                        strHtml += "<td>: " + returnUndefin( job.target_num_candidates ) + "</td>";
                        strHtml += "</tr>";
                        strHtml += "<tr>";
                        strHtml += "<td>" + vm.out( 'Nombre d’entrevues ciblé', 'Interviewed target' ) + "</td>";
                        strHtml += "<td>: " + returnUndefin( job.target_num_interviewed ) + "</td>";
                        strHtml += "</tr>";
                        strHtml += "</table>";
                        showAdvanceDiv.innerHTML = strHtml;
                        var iPosX = event.clientX;
                        var iPosY = event.clientY;
                        showAdvanceDiv.style.left = iPosX + "px";
                        showAdvanceDiv.style.top = iPosY + "px";
                        if ( job.deadline && job.deadline != "" ) {                         
                            showAdvanceDiv.style.display = "block";
                        }
                    } else {
                        showAdvanceDiv.style.display = "none";
                    }
                }
            }
        }

        function closeEditForm() {
            vm.formModel = angular.copy( formModelInitial );

            vm.promiseAssign = null;
            vm.inputForm.$setPristine();
            vm.advancedOptions = false;
        }

        function openDatePicker( $event, control ) {
            vm.datePicker = true;
        }

        function toggleAdvancedEditForm() {
            vm.advancedOptions = !vm.advancedOptions;
        }
    };
} )( angular );