(function (angular) {
  function NotesModuleCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    _,
  ) {
    let scope = {
      out: utils.out,
      language: $rootScope.language,
      defaultJobListOptionNotes: {
        id: -1,
        titleFr: 'Toutes les notes',
        titleEn: 'All notes',
        locations: [],
      },
      filterJob: { selected: {} },
      currentAccountJobsList: [],
      locationIdsList: []
    };
    angular.extend($scope, scope);

    function switchJob(job) {
      if (job) {
        $scope.jobId = job.id;
        getNotes(true);
      }
    }

    function getNotes(hasJobSelected, refresh) {
      if (!hasJobSelected) {
        $scope.filterJob.selected = $scope.defaultJobListOptionNotes;
        $scope.jobId = -1;
      }
      if (refresh) {
        $scope.updatingNoteList = true;
      } else {
        $scope.updatingNoteList = false;
      }
      $scope.availableNotes = null;
      let url = `note/notes?filter_by_candidate_id=${$scope.candidateId}`;
      if ($scope.filterJob.selected?.id && $scope.filterJob.selected.id !== -1) {
        url = `${url}&filter_by_job_id=${$scope.filterJob.selected.id}`;
      }
      const promise = api.service_get('toolkit', url);
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.availableNotes = response.data.data.result;
          $scope.generalNotes = [];
          $scope.jobsNotes = [];

          if ($scope.availableNotes.length > 0) {
            angular.forEach($scope.availableNotes, (note) => {
              angular.forEach($scope.currentAccountJobsList, (job) => {
                if (note.job_id === job.id && job.id !== -1) {
                  note.jobTitleFr = job.translations?.fr?.title ? job.translations.fr.title : (job.translations?.en?.title ? job.translations.en.title : "") + " (aucun titre disponible en français)";
                  note.jobTitleEn = job.translations?.en?.title ? job.translations.en.title : (job.translations?.fr?.title ? job.translations.fr.title : "") + " (no English title available)";
                  note.jobUrl = `${window.appConfig.ATLAS_UI_URL}job/${job.id}`;
                }
              });
              $scope.jobsNotes = $scope.availableNotes.filter(note => note.job_id);
              $scope.generalNotes = $scope.availableNotes.filter(note => !note.job_id);
            });
          }
        }
      }).catch(() => {
        $scope.availableNotes = [];
        $rootScope.api_status('alert-danger');
      });
    }

    $scope.$watch('candidate', () => {
      $scope.candidateId = $scope.candidate.user_id;
      $scope.newNote = '';
      if (!$scope.jobsListLoading) {
        if ($scope.isCrm) {
          getNotes(false);
        } else {
          getNotes(true);
        }
      }
    });

    $scope.tagHandler = (tag) => null;

    function setLocationsToJobList() {
      _.each($scope.currentAccountJobsList, (job) => {
          if (job.locations.length) {
              const jobLocation = _.find($scope.locationIdsList, (location) => +job.locations[0].location_id === +location.id);
              if (jobLocation) {
                  job.address = ` ${jobLocation.street_number && jobLocation.street ? `${jobLocation.street_number} ${jobLocation.street}` : ''
                  }${jobLocation.city ? (jobLocation.street_number && jobLocation.street ? ', ' : '')
                      + jobLocation.city : (jobLocation.street_number && jobLocation.street ? ', ' : '') + jobLocation.region
                  }${jobLocation.country ? `, ${jobLocation.country}` : ''} `;
              }
          }
      });
      $scope.jobsListLoading = false;
    }

    fetchLocations = (locationIdsArray) => {
      api.service_get('shared', 'location/list-by-key-and-values', {
          key: 'id',
          'values[]': locationIdsArray,
        }).then((response) => {
        if (response.status === 200) {
          $scope.locationIdsList = response.data;
          if (Object.keys($scope.locationIdsList).length > 0) {
            setLocationsToJobList();
          } else {
            $scope.jobsListLoading = false;
          }
        } else {
          $scope.jobsListLoading = false;
          $rootScope.api_status(
            'alert-danger',
            'A problem occurred and the list of jobs locations could not be retrieved',
            'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
          );
        }
      }).catch(() => {
        $scope.jobsListLoading = false;
        $rootScope.api_status(
          'error',
          'A problem occurred and the list of jobs locations could not be retrieved',
          'Un problème est survenu et la liste des adresses des postes n\'a pu être récupérée',
        );
      });
    }

    function init() {
      $scope.jobsListLoading = true;
      // Use different jobs-service routes for different types of users
      let getJobsPromise = {};
      if ($rootScope.currentUser.permissions.isAdmin || $rootScope.currentUser.permissions.isRegularRecruiter || $rootScope.currentUser.permissions.isClient) {
        getJobsPromise = api.service_get('jobs', `job/accounts/${$rootScope.currentUser.account.id}/job-titles`);
      } else {
        getJobsPromise = api.service_get('jobs', `job/users/${$rootScope.currentUser.user.id}/job-titles`);
      }
      getJobsPromise.then((res) => {
        if (res.data && res.data.length > 0) {
          const tempArrayOfJobs = res.data;
          let privateJobs = [];
          let publishedJobs = [];
          tempArrayOfJobs.forEach(job => {
            job.titleFr = job.translations?.fr?.title ? job.translations.fr.title : (job.translations?.en?.title ? job.translations.en.title : "") + " -- Français non disponible --";
            job.titleEn = job.translations?.en?.title ? job.translations.en.title : (job.translations?.fr?.title ? job.translations.fr.title : "") + " -- English not available --";
            if (job.published_internal < 1 && job.published_outsourced < 1 && job.published_external < 1) {
              job.titleFr += ' ( privé )';
              job.titleEn += ' ( private )';
              privateJobs.push(job);
            } else {
              publishedJobs.push(job);
            }
          });
          // sorting of lists before to concatenate them
          privateJobs = privateJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          publishedJobs = publishedJobs.sort(( a, b ) => {
            return $rootScope.language === "fr"
            ? a.titleFr.toLowerCase().localeCompare(b.titleFr.toLowerCase(), $rootScope.language)
            : a.titleEn.toLowerCase().localeCompare(b.titleEn.toLowerCase(), $rootScope.language)
          });
          $scope.currentAccountJobsList = publishedJobs.concat(privateJobs);
          $scope.currentAccountJobsList.unshift($scope.defaultJobListOptionNotes);
          // default option selected
          if ($scope.isCrm) {
            $scope.filterJob.selected = $scope.defaultJobListOptionNotes;
          } else {
            $scope.filterJob.selected = $scope.currentAccountJobsList.find(job => +job.id === +$scope.jobId);
          }
        }
      }).then(() => {
        if ($scope.currentAccountJobsList.length) {
          const locationIdsArray = [];
          _.each($scope.currentAccountJobsList, (item) => {
            _.each(item.locations, (itemLocation) => {
              locationIdsArray.push(itemLocation.location_id);
            });
          });
          fetchLocations(_.uniq(locationIdsArray));
        } else {
          $scope.jobsListLoading = false;
        }
      }).then(() => {
        if ($scope.isCrm) {
          getNotes(false);
        } else {
          getNotes(true);
        }        
      }).catch((error) => {
        if (error.status === 403) {
          $rootScope.api_status(
            "error",
            "You do not have the required permission to view notes",
            "Vous n'avez pas les permissions requises pour consulter les remarques",
            "Access denied",
            "Accès refusé",
            4000
          );
        } else {
          $rootScope.api_status('alert-danger', "An error has occured", "Une erreur s'est produite");
        }
        $scope.jobsListLoading = false;
        $scope.availableNotes = [];
      });
    }

    init();

    function postNote(addnote) {
      let msgEn; let msgFr;
      msgEn = 'Saving your note...';
      msgFr = 'Sauvegarde de votre note en cours ...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const data = {
        candidate_id: $scope.candidateId,
        comment: addnote,        
      };
      if ($scope.jobId !== -1) data.job_id = $scope.jobId;
      const promise = api.service_post('toolkit', 'note/notes', data);
      promise.then((response) => {
        if (response.data.status === 'success') {
          getNotes(true, 'refresh');
          angular.element('#note').val('');
          msgEn = 'Note saved';
          msgFr = 'Note sauvegardée';
          $rootScope.api_status('alert-success', '', '', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function editModeOn(note) {
      $scope.editMode = {};
      $scope.updatedNote = note.comment;
      $scope.editMode.id = note.id;
    }

    function editModeOff() {
      $scope.updatedNote = '';
      $scope.editMode = {};
    }

    function updateNote(noteId, note) {
      let msgEn; let msgFr;
      msgEn = 'Updating your note...';
      msgFr = 'Mise à jour de votre note ...';
      $rootScope.api_status('waiting', msgEn, msgFr);
      const data = {
        candidate_id: $scope.candidateId,
        comment: note,
      };
      if ($scope.jobId !== -1) data.job_id = $scope.jobId;
      const promise = api.service_post('toolkit', `note/notes/${noteId}`, data, 'update');
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.updateForm = '';
          editModeOff();
          getNotes(true, 'refresh');
          msgEn = 'Note updated';
          msgFr = 'Note mise à jour';
          $rootScope.api_status('alert-success', '', '', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
        editModeOff();
      });
    }

    function deleteNote(noteId) {
      let msgEn; let msgFr;
      msgEn = 'Deleting note...';
      msgFr = 'Suppression de la note en cours ...';
      $rootScope.api_status('waiting', msgEn, msgFr);

      const promise = api.service_delete('toolkit', `note/notes/${noteId}`);
      promise.then((response) => {
        if (response.data.status === 'success') {
          $scope.newNote = '';
          getNotes(true, 'refresh');
          msgEn = 'Note deleted';
          msgFr = 'Note supprimée';
          $rootScope.api_status('alert-success', '', '', msgEn, msgFr);
        }
      }).catch(() => {
        $rootScope.api_status('alert-danger');
      });
    }

    function getFormatedDate(unformatedDate) {
      const localUnformatedDate = utils.utcToTimezone(unformatedDate, '');
      return new Date(localUnformatedDate);
    }

    scope = {
      getNotes,
      postNote,
      editModeOn,
      editModeOff,
      updateNote,
      deleteNote,
      getFormatedDate,
      switchJob,
    };
    angular.extend($scope, scope);
  }
  NotesModuleCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '_',
  ];
  angular.module('atlas')
    .directive('notesModule', () => ({
      scope: {
        selectedCandidates: '=',
        candidate: '=',
        taglist: '=',
        jobId: '@',
        jobTitle: '@',
        jobTitleEn: '@',
        isCrm: '=',
      },
      controller: NotesModuleCtrl,
      templateUrl: './employer-profile/directives/notes-module/notes-module.template.html',
    }));
// eslint-disable-next-line no-undef
}(angular));
