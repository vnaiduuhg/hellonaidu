( function ( angular ) {

    'use strict';
    angular.module( 'atlas' )
            .controller( 'TagCollectionCtrl', TagCollectionCtrl); 
                   
    TagCollectionCtrl.$inject = [
        '$scope',
        '$rootScope', 
        'api', 
        'utils',
        'doc'
    ];
    
    function TagCollectionCtrl( 
            $scope,
            $rootScope, 
            api, 
            utils,
            doc
        ) {
    
        // @todo delete if this service is not used ( just used on cv-module for now, need to test before delete )
            
        $scope.selectedDoc= doc;

        //get tags for each employer
        var data={} ;
        data.employer_id = $rootScope.currentUser.employer.employerId;
        var request = api.tag('hh_employer_tag_list', data);
        request.then(function(res){
        $scope.EmployerTags= res.data.data;
        if($scope.candidate){
        angular.forEach($scope.EmployerTags, function(tag){
                angular.forEach($scope.taglist, function(value){
                    if(tag.tagname === value.keyword){
                        tag.assigned = true;
                    } 
                });
            });   
        }
    });


    function assignTag(tag){
        var formModal={};
        tag.employer_id = $rootScope.currentUser.employer.employerId;
        formModal.tagobject= tag;
        formModal.employer_id = $rootScope.currentUser.employer.employerId;
        formModal.candidate_id=$scope.candidate.userId;
        formModal.document=$scope.selectedDoc;
        var request = api.tag('hh_tag_assign', formModal)
            request.then(function(res){
                if(res.data.message==="Success"){
                    tag.assigned = true;
                }else if(res.data.message==="Failure"){
                    window.alert("Tag is already assigned to the file");                 
                }else{
                        $scope.modal.close(); 
                }           

            })
            .catch( function ( res ) {
                window.alert("Sorry! there is an error");
            });
    }

    $scope.hoverEdit = true;
    
    $scope.hoverIn = function(){
        this.hoverEdit = true;
    };

    $scope.hoverOut = function(){
        this.hoverEdit = false;
    };

    var scope = {
        out : utils.out,
        tagclicked:{},
        tagsFormModel:{},
        assignTag:assignTag
    };
    angular.extend( $scope, scope );
}

} )( angular );