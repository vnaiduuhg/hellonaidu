(function (angular) {
  function substitutusModuleCtrl(
    $scope,
    utils,
    api,
    $state,
    storageService,
    $rootScope,
  ) {
    let scope = {
      out: utils.out,
      candidatesSucceed: [],
      candidatesFailed: [],
      accountSynced: false,
      schools: [],
      schoolsSelected: { selected: {} },
      gradesFr: [],
      gradesEn: [],
      subjectsFr: [],
      subjectsEn: [],
      statusTypesFr: [],
      statusTypesEn: [],
      gradeStatusSelected: { selected: {} },
      subjectStatusSelected: { selected: {} },
      profileStatusSelected: { selected: {} },
      selectedProfileType: { selected: {} },
      schoolsIds: [],
      grades: [],
      subjects: [],
      sendAllDocs: true,
      selectedCandidatesDocuments: [],
    };
    angular.extend($scope, scope);

    $scope.tagHandler = function tagHandler(tag) {
      return null;
    };

    function toggleSendAllDocs(value) {
      $scope.sendAllDocs = value;
    }

    function getSelectedSubjectsOptions() {
      $scope.newSubjects = [];
      $scope.newSubjects = document.querySelector('#subjects-select').getSelectedOptions().map((item) => ({
        specialty_id: item.value,
        subject_name: item.label,
      }));
    }
    document.querySelector('#subjects-select').addEventListener('change', getSelectedSubjectsOptions);

    function getSelectedGradesOptions() {
      $scope.newGrades = [];
      $scope.newGrades = document.querySelector('#grades-select').getSelectedOptions().map((item) => ({
        grade_id: item.value,
        grade_name: item.label,
      }));
    }
    document.querySelector('#grades-select').addEventListener('change', getSelectedGradesOptions);

    $scope.confirmChoices = function confirmChoices(choice) {
      let multipleArrayOfChoices = []; const multipleArrayOfGrades = []; const multipleArrayOfSubjects = [];
      let newChoicesAdded = []; let choicesReady = []; let optionStatus = {};
      if (choice === 'grade') {
        multipleArrayOfChoices = multipleArrayOfGrades;
        choicesReady = $scope.grades;
        newChoicesAdded = $scope.newGrades;
        optionStatus = $scope.gradeStatusSelected;
      }
      if (choice === 'subject') {
        multipleArrayOfChoices = multipleArrayOfSubjects;
        choicesReady = $scope.subjects;
        newChoicesAdded = $scope.newSubjects;
        optionStatus = $scope.subjectStatusSelected;
      }
      if (Object.prototype.hasOwnProperty.call(optionStatus.selected, 'qualification_status_id')) {
        angular.forEach(newChoicesAdded, (choiceAdded) => {
          choiceAdded.status_id = optionStatus.selected.qualification_status_id ? optionStatus.selected.qualification_status_id : null;
          choiceAdded.status_name = optionStatus.selected.name ? optionStatus.selected.name : '';
        });
        multipleArrayOfChoices.push(newChoicesAdded);
        angular.forEach(multipleArrayOfChoices, (array) => {
          angular.forEach(array, (option) => {
            choicesReady.find((object) => {
              if ((choice === 'grade' && object.grade_id === option.grade_id) || (choice === 'subject' && object.specialty_id === option.specialty_id)) {
                option.duplicate = true;
              }
            });
            choicesReady.push(option);
          });
        });
        if (choice === 'grade') {
          document.querySelector('#grades-select').reset();
        }
        if (choice === 'subject') {
          document.querySelector('#subjects-select').reset();
        }
        optionStatus.selected = {};
      } else {
        utils.genericConfirmMessage('blue', null, $scope.out('Veuillez sélectionner le statut', 'Please choose a status'));
      }
    };

    function removeOption(type, option, optionIndex) {
      let duplicates = [];
      if (type === 'subjects') {
        $scope.subjects.splice(optionIndex, 1);
        $scope.invalidDataSubjects = false;
        duplicates = $scope.subjects.filter((specialty) => specialty.specialty_id === option.specialty_id);
        if (duplicates.length === 1) {
          angular.forEach($scope.subjects, (subject) => {
            if (subject.specialty_id === duplicates[0].specialty_id) {
              subject.duplicate = false;
            }
          });
        }
      }
      if (type === 'grades') {
        $scope.grades.splice(optionIndex, 1);
        $scope.invalidDataGrades = false;
        duplicates = $scope.grades.filter((elmt) => elmt.grade_id === option.grade_id);
        if (duplicates.length === 1) {
          angular.forEach($scope.grades, (grade) => {
            if (grade.grade_id === duplicates[0].grade_id) {
              grade.duplicate = false;
            }
          });
        }
      }
    }

    function getProfileMeta() {
      api.service_get('substituteTeacher', 'substitutus/profile-meta').then((response) => {
        $scope.schools = response.data.schools;
        $scope.allGrades = response.data.grades;
        $scope.gradesFr = response.data.grades.filter((grade) => grade.locale === 'fr').map((item) => ({
          label: item.name,
          value: item.grade_id,
        }));
        $scope.gradesEn = response.data.grades.filter((grade) => grade.locale === 'en').map((item) => ({
          label: item.name,
          value: item.grade_id,
        }));

        $scope.subjectsFr = response.data.specialties.filter((subject) => subject.locale === 'fr').map((item) => ({
          label: item.name,
          value: item.specialty_id,
        }));
        $scope.subjectsEn = response.data.specialties.filter((subject) => subject.locale === 'en').map((item) => ({
          label: item.name,
          value: item.specialty_id,
        }));
        $scope.statusTypesFr = response.data.qualification_statuses.filter((status) => status.locale === 'fr');
        $scope.statusTypesEn = response.data.qualification_statuses.filter((status) => status.locale === 'en');
        $scope.profileStatusFr = response.data.profile_statuses.filter((status) => status.locale === 'fr');
        $scope.profileStatusEn = response.data.profile_statuses.filter((status) => status.locale === 'en');

        VirtualSelect.init({
          ele: '#subjects-select',
          options: $scope.out($scope.subjectsFr, $scope.subjectsEn),
          multiple: true,
          search: true,
          optionsCount: 5,
          placeholder: $scope.out('Sélectionnez les options ici', 'Select options here'),
          noOptionsText: $scope.out('Aucune option trouvée', 'No options found'),
          noSearchResultsText: $scope.out('Aucun résultat trouvé', 'No results found'),
          selectAllText: $scope.out('Sélectionner tout', 'Select all'),
          searchPlaceholderText: $scope.out('Rechercher ...', 'Search...'),
        });

        VirtualSelect.init({
          ele: '#grades-select',
          options: $scope.out($scope.gradesFr, $scope.gradesEn),
          multiple: true,
          search: true,
          optionsCount: 5,
          placeholder: $scope.out('Sélectionnez les options ici', 'Select options here'),
          noOptionsText: $scope.out('Aucune option trouvée', 'No options found'),
          noSearchResultsText: $scope.out('Aucun résultat trouvé', 'No results found'),
          selectAllText: $scope.out('Sélectionner tout', 'Select all'),
          searchPlaceholderText: $scope.out('Rechercher ...', 'Search...'),
        });
      });
    }

    function clearAll() {
      $scope.invalidDataSubjects = false;
      $scope.invalidDataGrades = false;
      $scope.grades = [];
      $scope.gradeStatusSelected.selected = {};
      $scope.subjects = [];
      $scope.subjectStatusSelected.selected = {};
      $scope.schoolsSelected.selected = [];
      $scope.schoolsIds = [];
      $scope.selectedProfileType.selected = {};
      $scope.profileStatusSelected.selected = {};
      document.querySelector('#grades-select').reset();
      document.querySelector('#subjects-select').reset();
      getProfileMeta();
    }

    $scope.deleteChoices = function deleteChoices(choice) {
      if (choice === 'grade') {
        $scope.grades = [];
        $scope.gradeStatusSelected.selected = {};
        $scope.invalidDataGrades = false;
        document.querySelector('#grades-select').reset();
      } else {
        $scope.subjects = [];
        $scope.subjectStatusSelected.selected = {};
        $scope.invalidDataSubjects = false;
        document.querySelector('#subjects-select').reset();
      }
      getProfileMeta();
    };

    $scope.fetchSelectedSchools = function fetchSelectedSchools(select) {
      $scope.schoolsIds = select.map((school) => school.id);
    };

    getProfileMeta();

    function checkAccountSync() {
      $scope.profileTypes = [
        { id: 0, titleFr: 'Employé', titleEn: 'Employee' },
        { id: 1, titleFr: 'Suppléant', titleEn: 'Substitute' },
        { id: 2, titleFr: 'Employé et suppléant', titleEn: 'Employee and substitute' },
      ];
      $scope.isSubstituteStagePresent = $scope.workflowStages.find((stage) => stage.events.find((event) => event === 'create-candidate-substitutus-profile'));
      $scope.checking = true;
      $scope.loaded = false;
      $scope.candidatesSuccess = [];
      $scope.candidatesFail = [];
      $scope.candidatesSucceed = [];
      $scope.candidatesFailed = [];
      $scope.moveSubstituteCandidate = false;
      const accountId = +storageService.getItem('account_id');
      api.service_get('substituteTeacher', `substitutus/accounts/${accountId}/is-synced`).then((response) => {
        if (response.status === 200) {
          $scope.accountSynced = true;
        }
        $scope.checking = false;
      }).catch((error) => {
        $scope.checking = false;
        if (error.status === 404) {
          $scope.accountSynced = false;
        } else {
          utils.genericConfirmMessage('red', null, $scope.out('Désolé, nous n\'avons pas pu vérifier votre compte Scolago. Veuillez réessayer ou contacter notre équipe d\'assistance à l\'adresse support@workland.com pour plus d\'aide.',
            'Sorry, we could not verify your Scolago account. Please try again or contact our support team at support@workland.com for further assistance.'));
        }
      });
    }

    function getCandidateMeta(candidateId) {
      $scope.candidateProfile = {};
      const candidateIds = [candidateId];
      $scope.loadingProfile = true;
      api.service_post('substituteTeacher', 'substitutus/candidates/search', { user_ids: candidateIds })
        .then((response) => {
          $scope.loadingProfile = false;
          if (response.data.length > 0) {
            const candidateProfiles = response.data;
            angular.forEach(candidateProfiles, (candidateProfile) => {
              $scope.candidateProfile = {};
              const copyProfileTypes = angular.copy($scope.profileTypes);
              if (candidateProfile.profile_type_name) {
                $scope.candidateProfile.profileType = copyProfileTypes.filter((type) => type.titleEn === candidateProfile.profile_type_name);
              }
              if (candidateProfile.profile_status) {
                $scope.candidateProfile.profileStatusFr = candidateProfile.profile_status.translations.filter((status) => status.locale === 'fr');
                $scope.candidateProfile.profileStatusEn = candidateProfile.profile_status.translations.filter((status) => status.locale === 'en');
              }
              $scope.candidateProfile.schools = candidateProfile.substitutus_schools;
              $scope.candidateProfile.gradesFr = [];
              $scope.candidateProfile.gradesEn = [];
              let translFr;
              let translEn;
              angular.forEach(candidateProfile.substitutus_grades, (grade) => {
                angular.forEach(grade.translations, (transl) => {
                  if (transl.locale === 'fr') {
                    translFr = transl;
                  } else {
                    translEn = transl;
                  }
                });
                angular.forEach(grade.pivot.status.translations, (gradeStatus) => {
                  if (gradeStatus.locale === 'fr') {
                    $scope.candidateProfile.gradesFr.push({ name: translFr.name, status: gradeStatus.name });
                  } else {
                    $scope.candidateProfile.gradesEn.push({ name: translEn.name, status: gradeStatus.name });
                  }
                });
              });
              $scope.candidateProfile.subjectsFr = [];
              $scope.candidateProfile.subjectsEn = [];
              angular.forEach(candidateProfile.substitutus_specialties, (specialty) => {
                angular.forEach(specialty.translations, (transl) => {
                  if (transl.locale === 'fr') {
                    translFr = transl;
                  } else {
                    translEn = transl;
                  }
                });
                angular.forEach(specialty.pivot.status.translations, (specialtyStatus) => {
                  if (specialtyStatus.locale === 'fr') {
                    $scope.candidateProfile.subjectsFr.push({ name: translFr.name, status: specialtyStatus.name });
                  } else {
                    $scope.candidateProfile.subjectsEn.push({ name: translEn.name, status: specialtyStatus.name });
                  }
                });
              });
            });
          }
        }).catch(() => {
          $scope.loadingProfile = false;
        });
    }

    // checkAccountSync();

    $scope.$watch('candidate.userId', (value) => {
      checkAccountSync();
      $scope.showDiv = false;
      if (value) getCandidateMeta(value);
    });

    function checkRequiredParams() {
      $scope.requiredParamSchool = $scope.schoolsIds.length < 1;
      $scope.requiredParamSubject = $scope.subjects.length < 1;
      if ($scope.requiredParamSchool || $scope.requiredParamSubject) {
        return false;
      }
      return true;
    }

    function createCandidatesProfilesOnSubstitutus() {
      $scope.candidatesApplicationIds = [];
      $scope.candidatesApplicationIds = $scope.selectedCandidates.map((candidate) => candidate.application_id);
      api.service_post('toolkit', 'document-manager/candidate-documents/search', { document_application_ids: $scope.candidatesApplicationIds })
        .then((response) => {
          const selectedCandidatesDocuments = response.data.message;
          const unwrap = ({
            candidate_id, file_name, type_id, url, file_version_id,
          }) => ({
            candidate_id, file_name, type_id, url, file_version_id,
          });
          angular.forEach(selectedCandidatesDocuments, (candidateDocument) => {
            const new_doc = unwrap(candidateDocument);
            $scope.selectedCandidatesDocuments.push(new_doc);
          });
        }).then(() => {
          const userIds = [];
          angular.forEach($scope.selectedCandidates, (selectedCandidate) => {
            userIds.push(selectedCandidate.user_id ? selectedCandidate.user_id : selectedCandidate.userId);
          });
          const data = {
            job_id: $scope.jobId,
            user_ids: userIds,
            profile_type_name: $scope.selectedProfileType.selected.titleEn,
            school_ids: $scope.schoolsIds,
            grades: $scope.grades,
            specialties: $scope.subjects,
            profile_status_id: $scope.profileStatusSelected.selected.profile_status_id,
          };
          if ($scope.sendAllDocs && $scope.selectedCandidatesDocuments.length > 0) {
            data.documents = $scope.selectedCandidatesDocuments;
          } else {
            $scope.selectedCandidatesDocuments = [];
          }
          if (Object.prototype.hasOwnProperty.call($scope.selectedProfileType.selected, 'titleEn')
            && Object.prototype.hasOwnProperty.call($scope.profileStatusSelected.selected, 'name')) {
            if (checkRequiredParams()) {
              $scope.moveSubstituteCandidate = false;
              $scope.loading = true;
              $scope.loaded = false;
              api.service_post('substituteTeacher', 'substitutus/candidate-accounts', data).then((response) => {
                if (response.status === 200) {
                  $scope.candidatesSucceed = response.data.candidates_success;
                  $scope.candidatesFailed = response.data.candidates_fail;
                  $scope.candidatesSuccess = [];
                  $scope.candidatesFail = [];
                  if ($scope.candidatesSucceed.length > 0) {
                    let countSuccess = $scope.selectedCandidates.length * $scope.candidatesSucceed.length;
                    angular.forEach($scope.candidatesSucceed, (candidate) => {
                      angular.forEach($scope.selectedCandidates, (selected) => {
                        if (candidate === selected.user_id && !selected.substitutus) {
                          $scope.candidatesSuccess.push(selected);
                        }
                        countSuccess--;
                        if (countSuccess === 0 && $scope.candidatesSuccess.length > 0) {
                          $scope.moveSubstituteCandidate = true;
                        }
                      });
                    });
                  }
                  if ($scope.candidatesFailed.length === 0) {
                    clearAll();
                  }
                  if ($scope.selectedCandidates.length === 1 && $scope.candidatesSucceed.length === 1 && $scope.candidatesSuccess.length === 0) {
                    getCandidateMeta($scope.selectedCandidates[0].user_id);
                    $scope.showDiv = false;
                  }
                  if ($scope.candidatesFailed.length > 0) {
                    angular.forEach($scope.candidatesFailed, (candidate) => {
                      angular.forEach($scope.selectedCandidates, (selected) => {
                        if (candidate === selected.user_id) {
                          $scope.candidatesFail.push(selected);
                        }
                      });
                    });
                  }
                }
                $scope.loading = false;
                $scope.loaded = true;
              }).catch((error) => {
                $scope.loading = false;
                $scope.loaded = true;
                if (error.status === 404) { // credentials_not_found
                  $rootScope.api_status(
                    'alert-danger',
                    'Please sync your account with Scolago at first',
                    'Veuillez d\'abord synchroniser votre compte avec Scolago',
                    null, null, 5000,
                  );
                } else if (error.status === 500 && error.data === 'problem_verifying_account') {
                  $rootScope.api_status(
                    'alert-danger',
                    'Sorry, an error has occurred. Please try again or contact our support team at support@workland.com for further assistance.',
                    'Désolé, une erreur s\'est produite. Veuillez réessayer ou contacter notre équipe d\'assistance à l\'adresse support@workland.com pour plus d\'aide.',
                    null, null, 5000,
                  );
                } else if ((error.status === 500 || error.status === 401) && error.data === 'invalid_client') {
                  $rootScope.api_status(
                    'alert-danger',
                    'Your Scolago account is invalid. Please re-sync your account with correct data.',
                    'Votre compte Scolago n\'est pas valable. Veuillez re-synchroniser votre compte avec des données correctes.',
                    null, null, 5000,
                  );
                } else {
                  $rootScope.api_status(
                    'alert-danger',
                    'Error! Please contact our support team at support@workland.com for further assistance.',
                    'Erreur! Veuillez contacter notre équipe d\'assistance à l\'adresse support@workland.com pour plus d\'aide.',
                    null, null, 5000,
                  );
                }
              });
            } else {
              utils.genericConfirmMessage('blue', null, $scope.out('Veuillez remplir tous les champs obligatoires', 'Please fill in all required fields'));
            }
          } else {
            utils.genericConfirmMessage('blue', null, $scope.out('Veuillez choisir le type de profil et son statut', 'Please choose profile type and its status'));
          }
        });
    }

    function showErrorMessage(type) {
      let option = '';
      if (type === 'subjects') {
        option = $scope.out(' spécialités ', ' specialties');
      }
      if (type === 'grades') {
        option = $scope.out(' niveaux ', ' grades');
      }
      utils.genericConfirmMessage('blue', null, $scope.out(`Vous avez des doublons dans les${option}, veuillez les supprimer pour pouvoir continuer`,
        `You have duplicates in ${option}, please remove them in order to proceed`));
    }

    function validateData() {
      $scope.invalidDataSubjects = false;
      $scope.invalidDataGrades = false;
      $scope.invalidDataSubjects = $scope.subjects.some((subject) => subject.duplicate);
      $scope.invalidDataGrades = $scope.grades.some((subject) => subject.duplicate);
      if ($scope.invalidDataSubjects) {
        showErrorMessage('subjects');
      } else if ($scope.invalidDataGrades) {
        showErrorMessage('grades');
      } else {
        createCandidatesProfilesOnSubstitutus();
      }
    }

    function redirectToScolago() {
      window.location = `${window.appConfig.ATLAS_UI_URL}integrations/replacement/scolago-settings`;   
    }

    scope = {
      validateData,
      toggleSendAllDocs,
      clearAll,
      removeOption,
      redirectToScolago,
    };
    angular.extend($scope, scope);

    $scope.$on('$destroy', () => {
      document.querySelector('#subjects-select').removeEventListener('change', getSelectedSubjectsOptions);
      document.querySelector('#grades-select').removeEventListener('change', getSelectedGradesOptions);
    });
  }
  substitutusModuleCtrl.$inject = [
    '$scope',
    'utils',
    'api',
    '$state',
    'storageService',
    '$rootScope',
  ];
  angular.module('atlas')
    .directive('substitutusModule', () => ({
      scope: {
        jobId: '@',
        selectedCandidates: '=',
        workflowStages: '=',
        candidate: '=',
        bulk: '=',
        filterName: '@',
        substituteStageCandidates: '=',
      },
      controller: substitutusModuleCtrl,
      templateUrl: './employer-profile/directives/substitutus-module/substitutus-module.template.html',
    }));
}(angular));
