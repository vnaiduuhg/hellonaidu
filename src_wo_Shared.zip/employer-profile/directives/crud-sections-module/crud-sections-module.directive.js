( function ( angular ) {

    'use strict';
    var app = angular.module( 'atlas' );

    app.directive( 'crudSectionsModule', function () {

        var inject = [
            '$scope',
            '$rootScope',
            '_',
            'api',
            'utils',
            'worklandLocalize',
            'MetaTagsService',
            '$state',
            'matchService',
            crudSectionsModuleCtrl
        ];

        function crudSectionsModuleCtrl(
                $scope,
                $rootScope,
                _,
                api,
                utils,
                worklandLocalize,
                MetaTagsService,
                $state,
                matchService
        ) {

            MetaTagsService.getMetatags($state.current.name);
            var deregisterFns = MetaTagsService.magageTransitions();
            $scope.$on("$destroy", function() {
                deregisterFns.forEach(function(deregisterFn) {
                    deregisterFn();
                });
            });

            var sectionsCtrl = this;
            var strings = worklandLocalize.strings;
            var stringFr = strings.french;
            var stringEn = strings.english;
            var isWorklandEmployer = $rootScope.currentUser.permissions.isWorklandEmployer;
            // @std by - this need to be fetched from match service. All questionnaires are owned by the same id
            var originalQuestionnaireOwnerId = '87480290-9f58-11e5-b9f6-5df0885e86d6';
            var formModel = {
                settings: {
                    editMode: false,
                    viewCollection: true,
                    viewForm: false
                },
                name: [],
                ponderation: 0
            };

            var titleLabels = [
                strings.title + ' ' + stringFr,
                strings.title + ' ' + stringEn,
            ];

            var activeOptions = [{
                    key: true,
                    label: strings.active
                }, {
                    key: false,
                    label: strings.inactive
                }];

            //Keep a clean copy of initial settings
            var formModelInitial = angular.copy( formModel );

            function getSections() {
                var promise = matchService.getData('sections');
                promise.then( function ( response ) {
                    sectionsCtrl.sections = response.data.data;
                    sectionsCtrl.formModel.settings.editMode = false;
                });
                return promise;
            }

            function updateSection() {
                var section = angular.copy( sectionsCtrl.formModel );
                delete section.settings;
                if(section.sectionId) {
                    var promise = matchService.updData('sections', {
                        name: section.name,
                        ponderation: section.ponderation,
                        sectionId: section.sectionId,
                        active: section.active
                    });
                } else {
                    var promise = matchService.postData('sections', {
                        name: section.name,
                        ponderation: section.ponderation
                    });
                }
                
                promise.then( function ( response ) {
                    init();
                    if ( formModel.settings.editMode == false ) {
                        closeEditForm();
                    }
                });
                return promise;
            }

            function deleteSection( section ) {
                if ( !confirm( strings.confirmDelete ) ) {
                    return;
                }

                var promise = matchService.delData('sections', {
                    sectionId: section.sectionId
                });

                // init returns a new promise
                return promise.then( init );

            }

            function editSection( section ) {

                var sectionEditableProps = _.pick( section,
                        'sectionId',
                        'ownerId',
                        'name',
                        'ponderation',
                        'active'
                        );
                sectionEditableProps.settings = {
                    viewForm: true,
                    editMode: true
                };

                sectionsCtrl.formModel = sectionEditableProps;
            }


            function closeEditForm() {
                sectionsCtrl.formModel = angular.copy( formModelInitial );
                sectionsCtrl.inputForm.$setPristine();
            }


            //Only Confidentiel can edit the original sections
            function canEditSection( section ) {
                var ownerId = section.ownerId;
                if ( ownerId === originalQuestionnaireOwnerId && !isWorklandEmployer ) {
                    return false;
                }
                return true;
            }

            //we should not allow the deletion of original sections.
            function canDeleteSection( section ) {
                return section.ownerId !== originalQuestionnaireOwnerId;
            }

            var sectionsCtrlExtend = {
                canDeleteSection: canDeleteSection,
                canEditSection: canEditSection,
                originalQuestionnaireOwnerId: originalQuestionnaireOwnerId,
                activeOptions: activeOptions,
                strings: strings,
                out: utils.out,
                formModel: formModel,
                titleLabels: titleLabels,
                getSections: getSections,
                updateSection: updateSection,
                deleteSection: deleteSection,
                editSection: editSection,
                closeEditForm: closeEditForm
            };
            angular.extend( sectionsCtrl, sectionsCtrlExtend );

            init();

            function init() {
                return getSections();
            }
        }
        return {
            scope: {},
            bindToController: true,
            controllerAs: 'sectionsCtrl',
            controller: inject,
            templateUrl: './employer-profile/directives/crud-sections-module/crud-sections-module.template.html'
        };
    } );

} )( angular );