( function ( angular ) {

    'use strict';
    var app = angular.module( 'atlas' );

    app.directive( 'crudAddSectionsModule', function () {

        var inject = [
            '$scope',
            'api',
            'utils',
            'matchService',
            crudAddSectionsModuleCtrl];

        function crudAddSectionsModuleCtrl( $scope, api, utils, matchService ) {
            var vm = this;
            var jobId = vm.jobId;

            var API_ROUTE = 'questionnaire_web_api';
            var formModel = {
                settings: {
                    editMode: false,
                    viewCollection: true,
                    viewForm: false
                }
            };
            //Keep a clean copy of initial settings
            var formModelInitial = angular.copy( formModel );

            function getRequest() {
                var promise = matchService.getData( 'request', {
                    requestId: jobId                  
                });

                promise.then( function ( response ) {
                    // Save questions as a static variable so we dont reload it
                    // every time
                    vm.request = response.data.data;
                });
                return promise;
            }

            function getSections() {
                var promise = matchService.getData('sections');
                promise.then( function ( response ) {
                    var requestSecIds = _.pluck(vm.request.sections, 'sectionId');
                    vm.sections = _.reject(response.data.data, function(res) {
                        return requestSecIds.includes(res.sectionId);
                    });
                });
                return promise;
            }

            function closeEditForm() {
                vm.formModel = angular.copy( formModelInitial );
                vm.inputForm.$setPristine();
            }

            function addSection() {
                var promise = matchService.updData('request/addSection', {
                    requestId: jobId,
                    sectionId: vm.formModel.sectionId
                });
                promise.then( function ( response ) {
                    vm.sections = response.data.data;
                    closeEditForm();
                    init();

                } );
                return promise;
            }

            function deleteSectionFromRequest(section) {
                if ( vm.sections ) {
                    return;
                }
                var promise = vm.promiseRequests = matchService.updData('request/delSection', {
                    requestId: jobId,
                    sectionId: section.sectionId
                });
                return promise.then( init );
            }


            $scope.$watch( 'vm.init', function ( isInit ) {
                if ( isInit ) {
                    init();
                }
            } );
            function init() {

                return getRequest();
            }

            var vmExtend = {
                out: utils.out,
                addSection: addSection,
                getSections: getSections,
                deleteSectionFromRequest: deleteSectionFromRequest,
            };
            angular.extend( vm, vmExtend );
        }

        return {
            scope: {},
            bindToController: {
                jobId: '@',
                init: '='
            },
            controllerAs: 'vm',
            controller: inject,
            templateUrl: './employer-profile/directives/crud-add-sections-module/crud-add-sections-module.template.html'
        };

    } );
} )( angular );