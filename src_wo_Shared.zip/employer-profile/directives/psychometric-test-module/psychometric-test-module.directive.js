(function (angular) {

    'use strict';
    angular.module('atlas')
            .directive('psychometricTestModule', function () {

                return {
                    scope: {
                        selectedCandidates: '=',
                        candidate: '=',
                        jobId: '@',
                        filterName: '@' 
                    },
                    controller: psychometricTestModuleCtrl,
                    templateUrl: './employer-profile/directives/psychometric-test-module/psychometric-test-module.template.html'
                };
            });

    psychometricTestModuleCtrl.$inject = [
        '$scope',
        '$rootScope',
        'api',
        '$uibModal',
        'utils',
        '$sce',
        'moment'
    ];



    function psychometricTestModuleCtrl(
        $scope,
        $rootScope,
        api,
        $uibModal,
        utils,
        $sce,
        moment
        ) {

        $scope.options = {
            date: {
                date: true
            }
        };
        init();
        function init() {
            $scope.candidateId = $scope.selectedCandidates[0].userId;
            fetchProductList();
            $scope.dateError = false;
            var currentDate = new Date();
            $scope.minDate = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate()+1)
        }

        $scope.$watch('selectedCandidates', function () {
            init();
        });


        function fetchProductList() {
            $scope.products = null;
            var promise = api.service_get('toolkit', 'tiperformance/products');
            promise.then(function (response) {
                fetchAssignedTest();
                $scope.status = response.status;
                if ($scope.status === 200) {
                    $scope.products = response.data.data.result;
                }
            }).catch(function (error) {
                fetchAssignedTest();
                $scope.products = [];
            });
        }

        function fetchAssignedTest() {
            $scope.assignedTest = null;
            var promise = api.service_get('toolkit', 'tiperformance/assigned-psychometric-tests?filter_by_job_id=' + $scope.jobId + '&filter_by_candidate_id=' + $scope.candidateId);
            promise.then(function (response) {
                $scope.status = response.status;
                if ($scope.status === 200) {
                    $scope.assignedTest = response.data.data.result;
                }
            }).catch(function (error) {
                $scope.assignedTest = [];
            });

        }

        $scope.setProductsSelected = function(productId){
            $scope.products.selected = productId;
            $scope.productError = false;
        };

        function assignTest() {
            if (!$scope.products.selected) {
                $scope.productError = true;
            }else if(!$scope.products.expiryDate){
                $scope.dateError = true;
            }
            else {
                var day = $scope.products.expiryDate.getDate();
                var month = $scope.products.expiryDate.getMonth()+1;
                var year = $scope.products.expiryDate.getFullYear();
                var expiryDate = moment(year + "-" + month + "-" + day).format('YYYY-MM-DD');
                var msgEn = "Assigning the test...";
                var msgFr = "Attribution du test en cours...";
                $rootScope.api_status("waiting", msgEn, msgFr);
                var data = {
                    "job_id": $scope.jobId,
                    "product_id": $scope.products.selected,
                    "candidate_id": $scope.candidateId,
                    "status": "pending",
                    "deadline": expiryDate
                };
                var promise = api.service_post('toolkit', 'tiperformance/assigned-psychometric-tests', data);
                promise.then(function (response) {
                    $scope.status = response.data.status;
                    if ($scope.status === "success") {
                        $rootScope.api_status('alert-success');
                        init();
                    }
                    else {
                        $rootScope.api_status('alert-danger');
                    }
                }).catch(function (error) {
                    $rootScope.api_status('alert-danger');
                });
            }
        }

        function getProductName(assignedTest) {
            angular.forEach($scope.products, function (value, key) {
                if (value.id === assignedTest.product_id) {
                    assignedTest.product_title = value.title;
                }
            });
        }

        function showReport(pId) {
            var msgEn = "Opening a Test Report...";
            var msgFr = "Ouverture du rapport de test en cours...";
            $rootScope.api_status("waiting", msgEn, msgFr);
            var data = {
                "candidate_ids": [
                    $scope.candidateId
                ],
                "job_id": $scope.jobId,
                "product_id": pId
            }
            var promise = api.service_post('toolkit', 'tiperformance/assigned-psychometric-tests/get-psychometric-test-result', data);
            promise.then(function (response) {
                $scope.status = response.data.status;
                if ($scope.status === "success") {
                    $rootScope.api_status('alert-success');
                    var fileUrl = "https://docs.google.com/viewer?url=" + response.data + "&embedded=true";
                    $scope.openFileUrl = $sce.trustAsResourceUrl(fileUrl);
                    var createDirectoryInstance = $uibModal.open({
                        animation: true,
                        templateUrl: './employer-profile/atlas-drive/modal-templates/view-file.template.html',
                        scope: $scope,
                        size: 'md'
                    });
                }
                else {
                    $rootScope.api_status('alert-danger');
                }
            }).catch(function (error) {
                $rootScope.api_status('alert-danger');
            });

        }

        var scope = {
            assignTest: assignTest,
            getProductName: getProductName,
            showReport: showReport,
            out: utils.out,
            productError: false,
            dateError: false
        };
        angular.extend($scope, scope);
    }
})(angular);
