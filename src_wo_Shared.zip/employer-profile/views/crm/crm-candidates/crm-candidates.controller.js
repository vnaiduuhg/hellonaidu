(function (angular) {
  function crmCandidatesController(
    $scope,
    $rootScope,
    worklandLocalize,
    utils,
    api,
    $timeout,
    $ngConfirm,
    Pager,
    storageService,
    _,
  ) {
    const { out } = utils;

    function createModuleTab(
      module,
      labelEn,
      labelFr,
      icon,
      filterName,
      disabled,
    ) {
      return {
        module,
        labelEn,
        labelFr,
        icon,
        filterName,
        disabled,
      };
    }

    $scope.candidateModuleTabs = [
      createModuleTab('email-composer', 'Emails', 'Courriels', 'envelope', 'emailed', false),
      createModuleTab('interview-module', 'Schedule interview', 'Planifier une entrevue', 'calendar-plus', 'interviews', false),
      createModuleTab('reference-module', 'Reference request', 'Demande de référence', 'clipboard-check', 'referencesRequested', false),
      createModuleTab('ised-send-questionnaires-module', 'Send questionnaire', 'Envoyer le questionnaire', 'clipboard-question', 'check', false),
      createModuleTab('ised-view-send-questionnaires-answer', 'Pre-selection', 'Présélection', 'file-alt',  null, false),
      createModuleTab('tag-module', 'Tags', 'Étiquettes', 'tags', 'tags', false),
      createModuleTab('application-clone-module',  'Move to job', 'Déplacer', 'arrow-right-from-bracket', 'move', false),
      createModuleTab('docu-transfer', 'DocuSecur', 'DocuSecur', 'file-shield', 'docu-transfer', false),
      createModuleTab('docusign-module', 'DocuSign', 'DocuSign', 'file-signature', 'docusign', false),
    ];

    function disableTab(moduleName, enable) {
      if (!enable) {
        angular.forEach($scope.candidateModuleTabs, (tab) => {
          if (tab.module === moduleName) {
            tab.active = false;
            tab.disable = true;
            tab.disableTabStyle = true;            
          }
        });
      } else {
        angular.forEach($scope.candidateModuleTabs, (tab) => {
          if (tab.module === moduleName) {
            tab.disable = false;
            tab.disableTabStyle = false;
          }
        });
      }
    }

    function disableTabs(tabsList, disable) {
      _.each(tabsList, tab => {
        disableTab(tab, !disable);
      });
    }

    function uncheckOtherCandidates(candidate) {
      for (let i = $scope.selectedCandidateList.length - 1; i >= 0; i -= 1) {
        if ($scope.selectedCandidateList[i].user_id !== candidate.user_id) {
          $scope.candidatesChecked[$scope.selectedCandidateList[i].user_id] = false;
          $scope.selectedCandidateList[i].active = false;
          $scope.selectedCandidateList.splice(i, 1);
        }
      }
      if ($scope.bulk.allSelected) {
        $scope.bulk.allSelected = false;
      }
    }

    function resetBulkParams() {
      $scope.selectedCandidateList = [];
      $scope.candidatesChecked = [];
      $scope.bulk.bulkAction = false;
    }

    function getCandidateAppliedJobs(candidates) {
      $scope.readyJobs = false;
      $scope.showDocuments = false;
      const employerAccountId = +storageService.getItem('account_id');
      const candidateUserIds = candidates.map((element) => +element.user_id);
      angular.forEach(candidates, (candidate) => { candidate.applicationList = []; });
      const params = {
        candidate_user_id: candidateUserIds,
        status: 'submitted',
      };
        // confidentiel access to all candidates
      if (employerAccountId !== 336) {
        params.employer_account_id = [employerAccountId];
      }
      if ($rootScope.currentUser.permissions.isAgency) {
        params.employer_account_id = $scope.clientIds;
      }
      if (candidateUserIds.length > 0) {
        return api.service_post('application', 'application/read-all', params)
          .then((response) => {
            $scope.noApplicationFound = !!response.data.length < 1;
            if (candidates.length === 1) {
              candidates[0].applicationList = response.data;
              if (!$scope.noApplicationFound) {
                disableTab('reference-module', true);
                disableTab('ised-view-send-questionnaires-answer', true);
              }
            } else if (candidates.length > 1) {
              $scope.commonApplications = response.data;
            }
            let jobIds = [];
            let data = [];
            if (candidates.length === 1 && candidates[0].applicationList.length > 0) {
              candidates[0].user_id = parseInt(candidates[0].user_id, 10);
              candidates[0].jobList = [];
              jobIds = candidates[0].applicationList.map((element) => element.job_id);
            } else if (candidates.length > 1 && $scope.commonApplications.length > 0) {
              jobIds = $scope.commonApplications.map((element) => element.job_id);
            }
            data = {
              'ids[]': jobIds,
              'load_with[]': ['translations'],
            };
            if (jobIds.length > 0) {
              return api.service_get('jobs', 'job/current-account/jobs', data)
                .then((result) => {
                  if (result.data) {
                    if (candidates.length === 1) {
                      const jobs = result.data;
                      angular.forEach(jobs, (job) => {
                        job.job_expired = utils.isDateExpired(job.external_expiry_date);
                        job.expiry_date = utils.toDateStr(utils.toDateObj(job.external_expiry_date));
                        angular.forEach(candidates[0].applicationList, (application) => {
                          if (job.id === application.job_id) {
                            job.job_application_id = application.id;
                          }
                        });
                        candidates[0].jobList = jobs;
                      });
                    } else if (candidates.length > 1) {
                      $scope.commonJobList = result?.data ?? [];
                      angular.forEach($scope.commonJobList, (job) => {
                        job.job_expired = utils.isDateExpired(job.external_expiry_date);
                        job.expiry_date = utils.toDateStr(utils.toDateObj(job.external_expiry_date));
                      });
                    }
                  } else {
                    if (candidates.length > 1) $scope.commonJobList = [];
                  }
                  if (!$scope.selectedTab) { $scope.showDocuments = true; }
                  $scope.readyJobs = true;
                }).catch(() => {
                  $scope.selectedTab = '';
                  $scope.readyJobs = true;
                });
            } else {
              if (candidates.length > 1) $scope.commonJobList = [];
              if (candidates.length === 1) candidates[0].jobList = [];
            }
            $scope.selectedTab = '';
            $scope.readyJobs = true;
          }).catch(() => {
            if (candidates.length === 1) {
              angular.forEach(candidates, (candidate) => {
                candidate.jobList = [];
              });
            }
            $scope.showDocuments = true;
            $scope.selectedTab = '';
          });
      }
    }

    function loadCandidateData(candidate) {
      candidate.visible = !candidate.visible;
      $scope.currentCandidate = candidate;
      if ($scope.selectedTab === 'tag-module') {
        $scope.readyJobs = true;
      } else {
        getCandidateAppliedJobs([candidate]);
      }
    }

    function selectCandidate(candidate) {
      if ($scope.selectedCandidateList.length <= 1) {
        resetBulkParams();
      }
      if (angular.isUndefined($scope.candidatesChecked[candidate.user_id])
        || !$scope.candidatesChecked[candidate.user_id]) {
        $scope.candidatesChecked[candidate.user_id] = true;
      }
      uncheckOtherCandidates(candidate);
      const idx = _.findIndex($scope.selectedCandidateList, (cand) => cand.user_id === candidate.user_id);
      if ($scope.candidatesChecked[candidate.user_id] && idx === -1) {
        $scope.selectedCandidateList.push(candidate);
      } else if (!$scope.candidatesChecked[candidate.user_id] && idx >= 0) {
        $scope.selectedCandidateList[idx].active = false;
        $scope.selectedCandidateList.splice(idx, 1);
        if ($scope.bulk.allSelected) {
          $scope.bulk.allSelected = false;
        }
      }
      $scope.bulk.bulkAction = $scope.selectedCandidateList.length > 1;
      if ($scope.bulk.bulkAction) {
        $scope.candidate = null;
      }
      angular.forEach($scope.candidates, (candidateNotSelected) => {
        candidateNotSelected.visible = false;
      });
      if ($scope.selectedCandidateList.length === 1) {
        disableTabs([
          'email-composer', 'interview-module', 'ised-send-questionnaires-module',
          'ised-view-send-questionnaires-answer', 'tag-module', 'application-clone-module'
        ], false);
        disableTab('reference-module');
        disableTab('ised-view-send-questionnaires-answer');
        loadCandidateData($scope.selectedCandidateList[0]);     
      }
      $scope.candListEvent = !$scope.candListEvent;
    }

    function addCandidateBulk(candidate, addManyCandidates) {
      const idx = _.findIndex($scope.selectedCandidateList, (cand) => cand.user_id === candidate.user_id);
      if ($scope.candidatesChecked[candidate.user_id] && idx === -1) {
        $scope.selectedCandidateList.push(candidate);
      } else if (!$scope.candidatesChecked[candidate.user_id] && idx >= 0) {
        $scope.selectedCandidateList[idx].active = false;
        $scope.selectedCandidateList.splice(idx, 1);
        if ($scope.bulk.allSelected) {
          $scope.bulk.allSelected = false;
        }
      }
      $scope.bulk.bulkAction = $scope.selectedCandidateList.length > 1;
      $scope.candidate = null;
      angular.forEach($scope.candidates, (candidateNotSelected) => {
        candidateNotSelected.visible = false;
      });
      if (!$scope.bulk.allSelected) {
        if ($scope.selectedCandidateList.length === 1) {
          loadCandidateData($scope.selectedCandidateList[0]);
          disableTabs([
            'email-composer', 'interview-module', 'ised-send-questionnaires-module', 'tag-module', 'application-clone-module'
          ], false);
          disableTab('reference-module');
          disableTab('ised-view-send-questionnaires-answer');
        } else if ($scope.selectedCandidateList.length > 1) {
          if ($scope.selectedTab !== 'tag-module') {
            getCandidateAppliedJobs($scope.selectedCandidateList);
          }
          disableTabs(['email-composer', 'interview-module', 'ised-send-questionnaires-module', 'tag-module'], false);
          disableTab('ised-view-send-questionnaires-answer');
          disableTab('reference-module');
          disableTab('application-clone-module');
          $scope.selectedTab = ($scope.selectedTab === 'showNotes'
            || $scope.selectedTab === 'showHistory'
            || $scope.selectedTab === 'ised-view-send-questionnaires-answer'
            || $scope.selectedTab === 'reference-module'
            || $scope.selectedTab === 'application-clone-module')
            ? ''
            : $scope.selectedTab;
          if ($scope.selectedTab === '') {
            $('ul.action-tabs li').parent().find('li.active').removeClass('active');
          }
          $scope.bulk.bulkAction = true;
        } else {
          disableTabs([
            'email-composer', 'interview-module', 'reference-module', 'ised-send-questionnaires-module',
            'ised-view-send-questionnaires-answer', 'tag-module', 'application-clone-module'
          ], true);
        }
      }
      if (!addManyCandidates) $scope.candListEvent = !$scope.candListEvent;
    }

    function addAllCandidateBulk() {
      resetBulkParams();
      $scope.candidate = null;
      if ($scope.bulk.allSelected) {
        disableTabs(['email-composer', 'interview-module', 'ised-send-questionnaires-module', 'tag-module'], false);
        angular.forEach($scope.candidates, (candidate) => {
          if (angular.isUndefined($scope.candidatesChecked[candidate.user_id])
                                || !$scope.candidatesChecked[candidate.user_id]) {
            $scope.candidatesChecked[candidate.user_id] = true;
          }
          addCandidateBulk(candidate, true);
        });
        if ($scope.selectedCandidateList.length > 1) {
          if ($scope.selectedTab !== 'tag-module') {
            getCandidateAppliedJobs($scope.selectedCandidateList);
          }
          disableTab('ised-view-send-questionnaires-answer');
          disableTab('reference-module');
          disableTab('application-clone-module');
          $scope.selectedTab = ($scope.selectedTab === 'showNotes'
              || $scope.selectedTab === 'showHistory'
              || $scope.selectedTab === 'ised-view-send-questionnaires-answer'
              || $scope.selectedTab === 'reference-module'
              || $scope.selectedTab === 'application-clone-module')
            ? ''
            : $scope.selectedTab;
          if ($scope.selectedTab === '') {
            $('ul.action-tabs li').parent().find('li.active').removeClass('active');
          }
          $scope.bulk.bulkAction = true;
        } else {
          disableTab('application-clone-module', 'enable');
          // @std by - testing
          // disableTab('ised-view-send-questionnaires-answer', 'enable');
          // disableTab('reference-module', 'enable');
        }
        $scope.candListEvent = !$scope.candListEvent;
      } else {
        disableTabs([
          'email-composer', 'interview-module', 'reference-module', 'ised-send-questionnaires-module',
          'ised-view-send-questionnaires-answer', 'tag-module', 'application-clone-module'
        ], true);
      }
    }

    function getEmployersTaglist() {
      const promise = api.service_get('toolkit', 'document-manager/tags');
      promise.then((response) => {
        $scope.status = response.data.status;
        if ($scope.status === 'success') {
          $scope.taglist = response.data.data.result;
        }
      }).catch(() => {
        $scope.taglist = [];
      });
    }

    function getDocumentType() {
      const promise = api.service_post('toolkit', 'document-manager/fetch-document-types', {});
      promise.then((response) => {
        $scope.documents = response.data.message;
      }).catch(() => {
        $scope.documents = [];
      });
    }

    function getCategories() {
      const promise = api.service_get('shared', 'jobCategory');
      promise.then((response) => {
        $scope.categories = response.data;
      }).catch(() => {
        $scope.categories = [];
      });
    }

    function getClientIds() {
      const agencyAccountId = storageService.getItem('account_id');
      // to get jobs of the agency and their clients
      api.service_get('accounts', `accounts/agencies/${agencyAccountId}/clients`).then((response) => {
        const agencyClientsIds = response.data.data;
        const clientIds = [];
        _.each(agencyClientsIds, (clientAccount) => {
          clientIds.push(clientAccount.id);
        });
        clientIds.push(agencyAccountId); // add agency account_id to the list of ids
        $scope.clientIds = clientIds;
      }).catch(() => {
        $rootScope.api_status('alert-danger', 'Sorry, there was an error while fetching applications.', "Désolé, une erreur s'est produit lors de la récupération des candidatures");
        $scope.clientIds = [];
      });
    }

    function init() {
      $scope.filterPanelSize = 'col-sm-12';
      getEmployersTaglist();
      getDocumentType();
      getCategories();

      $scope.formCtrl = {
        searchOpened: true,
        resultOpened: false,
      };
      $scope.searched = false;
      $scope.pageSize = { selected: {} };
      $scope.pageSize.selected = 10;
      if ($rootScope.currentUser.permissions.isAgency) {
        getClientIds();
      }
    }

    init();

    $scope.seekings = utils.getSeekingPositions();
    _.each($scope.seekings, (item) => {
      item.value = utils.out(item.titleFr, item.titleEn);
    });

    if ($rootScope.currentUser.currentClientData) {
      $scope.cvViewAmount = 0;
      const clientAccountId = storageService.getItem('account_id');
      api.service_get('marketplace', `account/${clientAccountId}/inventory`).then((response) => {
        $scope.inventory = response.data.data.consumables;
        angular.forEach($scope.inventory, (item) => {
          if (item.consumable.reference_code === 'CV') {
            $scope.currentCvViewsRemaining = item.quantity;
          }
        });
      });
    }

    function addKeywordIntoString(v) {
      if (!$scope.filesearchModel.singleKeyword) {
        $ngConfirm({
          icon: 'fa fa-exclamation',
          title: out('Erreur', 'Error'),
          content: out('Votre champ de mot clé est vide!', 'Your keyword field is empty!'),
          type: 'blue',
          typeAnimated: true,
          animation: 'RotateX',
          buttons: {
            ok: {
              text: 'ok',
              btnClass: 'btn-blue',
              action() {
              },
            },
          },
        });
      } else {
        $scope.keywordsArray.push('OR');
        $scope.keywordsArray.push($scope.filesearchModel.singleKeyword);
        $scope.filesearchModel.singleKeyword = '';
        document.getElementById('keywords').focus();
      }
    }

    function changeKeywordCondition(startIndex, newCondition) {
      $scope.keywordsArray.splice(startIndex, 1, newCondition);
    }

    function deleteKeyword(startIndex) {
      $scope.keywordsArray.splice(startIndex, 1);
      $scope.keywordsArray.splice(startIndex, 1);
    }

    function validateLocation(place) {
      if (!place.formatted_address) {
        $rootScope.api_status(
          'error',
          'This address is invalid',
          'Cette adresse est invalide',
        );
        return;
      }
      $scope.formattedlocation = place.formatted_address;
      if (place.geometry && place.geometry.location) {
        $scope.dimensions = [place.geometry.location.lat(), place.geometry.location.lng()];
        $scope.filesearchModel.dimensions = $scope.dimensions;
      }
    }

    // get googple api location with timeout because it is not wotking under uib tab
    let createTimeout1;
    function initPlacesAutocomplete() {
      createTimeout1 = $timeout(() => {
        $scope.autocomplete = new google.maps.places.Autocomplete($scope.autocompleteInput);
        $scope.autocomplete.setFields(['formatted_address', 'geometry']);
        $scope.autocomplete.addListener('place_changed', () => {
          const place = $scope.autocomplete.getPlace();
          validateLocation(place);
        });
      }, document.ready);
    }

    function initInputAutocomplete() {
      const autocompleteInput = document.getElementById('location');
      if (!$scope.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
        $scope.autocompleteInput = autocompleteInput;
        initPlacesAutocomplete();
      }
    }

    // slider properties
    $scope.slider = {
      value: 10,
      options: {
        floor: 0,
        ceil: 50,
        step: 1,
        minLimit: 10,
        maxLimit: 90,
        showSelectionBar: true,
      },
    };

    $scope.tagHandler = function tagHandler(tag) {
      return null;
    };

    function changeCategory(category) {
      $scope.filesearchModel.category = category;
      if (category) {
        $scope.functions = category.default_functions;
      }
      $scope.filesearchModel.function = null;
      $scope.function.selected = {};
    }

    $scope.disableSearch = function disableSearch() {
      $scope.searchEnabled = false;
    };

    function setPage(page) {
      $scope.candidatesChecked = [];
      $scope.selectedCandidateList = [];
      // define the page size, start index
      let pageSize = $scope.pageSize.selected ? $scope.pageSize.selected : 10;
      const startIndex = (page - 1) * pageSize;

      $scope.pressSearchButton = true;
      if ($scope.filesearchModel.singleKeyword) {
        addKeywordIntoString();
      }

      // Convert Keyword Into String Start
      $scope.filesearchModel.keyword = '';
      for (let i = 0; i < ($scope.keywordsArray.length); i += 1) {
        if (i % 2 === 0 && i !== 0) {
          $scope.filesearchModel.keyword = `${$scope.filesearchModel.keyword} `;
        }
        if ($scope.keywordsArray[i] == 'OR') {
          // empty
        } else if ($scope.keywordsArray[i] == 'AND') {
          $scope.filesearchModel.keyword = `${$scope.filesearchModel.keyword}+`;
        } else if ($scope.keywordsArray[i] == 'NOT') {
          $scope.filesearchModel.keyword = `${$scope.filesearchModel.keyword}-`;
        } else {
          $scope.filesearchModel.keyword = $scope.filesearchModel.keyword + $scope.keywordsArray[i];
        }
      }
      // Convert Keyword Into String END

      $scope.filesearchModel.searchafter = null;
      $scope.candidates = null;
      $scope.currentCandidate = null;
      const formData = angular.copy($scope.filesearchModel);
      if (page < 1 || page > $scope.pagerDocs.totalPages) {
        return;
      }

      // construct params for a query
      const params = {
        first_name: formData.firstname,
        last_name: formData.lastname,
        email: formData.email,
        phone: formData.phone,
        documenttype: formData.documenttype ? parseInt(formData.documenttype.id, 10) : '',
        keyword: formData.keyword,
        category: formData.category ? parseInt(formData.category.id, 10) : '',
        function: formData.function ? parseInt(formData.function.id, 10) : '',
        seeking: formData.seeking ? parseInt(formData.seeking.key, 10) : '',
        dimensions: formData.dimensions,
        slider: formData.slider ? formData.slider.value : 10,
        startIndex,
        tags: formData.tags,
        pageSize,        
      };

      if (formData.isInternal) {
        params.is_internal = 1;
      }
      const promise = api.service_post('indexing', 'indexing/search', params);
      promise.then((res) => {
        if (res.data.status === 'success') {
          $scope.candidates = res.data.data.candidates;
          angular.forEach($scope.candidates, (cand) => {
            cand.name = `${cand.first_name} ${cand.last_name}`;
          });
          $scope.total_count = res.data.data?.count ? res.data.data.count : 0;
          $scope.pagerDocs = Pager.GetPager($scope.total_count, page, pageSize);
          pageSize = $scope.pagerDocs.pageSize;
          $scope.searched = true;
          $scope.formCtrl = {
            searchOpened: false,
            resultOpened: true,
          };
          if ($scope.candidates.length > 0) {
            $scope.candidates[0].visible = true;
            [$scope.currentCandidate] = $scope.candidates;
            $scope.currentCandidate.jobList = [];
            $scope.currentCandidate.applicationList = [];
            $scope.candidatesChecked[$scope.candidates[0].user_id] = true;
            $scope.selectedCandidateList.push($scope.candidates[0]);
            getCandidateAppliedJobs([$scope.candidates[0]]);
          }
        }
      }).catch(() => {
        $scope.candidates = [];
        $scope.searched = false;
      });
    }

    function initController() {
      // initialize to page 1
      setPage(1);
    }

    function searchFiles() {
      $('html, body').animate({ scrollTop: 0 }, 500);
      $scope.pagerDocs = {};
      $scope.setPageDocs = setPage;
      $scope.selectedTab = '';
      $scope.showDocuments = true;
      $scope.bulk.allSelected = false;
      initController();
    }

    function pushToTagList(tag) {
      if (!$scope.filesearchModel.tags) $scope.filesearchModel.tags = [];
      const index = $scope.filesearchModel.tags ? $scope.filesearchModel.tags.indexOf(tag.id) : -1;
      if (index === -1) {
        $scope.filesearchModel.tags.push(tag.id);
      }
    }

    function removeTagFromList(tag) {
      const index = $scope.filesearchModel.tags.indexOf(tag.id);
      if (index >= 0) {
        $scope.filesearchModel.tags.splice(index, 1);
      }
    }

    function clearForm() {
      $scope.filesearchModel = {};
      $scope.keywordsArray = [];
      $scope.tags.selected = null;
      $scope.document.selected = {};
      $scope.category.selected = {};
      $scope.function.selected = {};
      $scope.seeking.selected = {};      
    }

    function setTab(tab) {
      if (tab !== 'showDocuments') {
        $scope.selectedTab = tab;
        $scope.showDocuments = false;
      } else {
        $scope.selectedTab = '';
        $scope.showDocuments = true;
      }

      $('ul.action-tabs li').parent().find('li.active').removeClass('active');
      $(`#${tab}`).addClass('active');
    }

    function changeCandidate(candidate) {
      candidate.visible = !candidate.visible;
      // $scope.selectedTab = '';
      $scope.currentCandidate = candidate;
      if ($scope.selectedTab === 'tag-module') {
        $scope.readyJobs = true;
      } else {
        candidate.applicationList = [];
        candidate.jobList = [];
        getCandidateAppliedJobs([candidate]);
      }
      // scroll to the top to see candidate menu and details
      $('html, body').animate({ scrollTop: 0 }, 500);
    }

    let createTimeout2;
    function submitWhenHitEnter(elemId) {
        createTimeout2 = $timeout(() => {
            angular.element(elemId).trigger('click');
        }, 0);
    }

    $scope.setOpenedPanelOnCvModule = (e) => {
      $scope.openedPanelOnCvModule = e;
    }

    const scope = {
      isClient: $rootScope.currentUser.permissions.isClient,
      isPremiumClient: $rootScope.isPremiumClient,
      strings: worklandLocalize.strings,
      out,
      filesearchModel: {},
      tags: {
        selected: null
      },
      clearForm,
      searchFiles,
      pushToTagList,
      removeTagFromList,
      addKeywordIntoString,
      keywordsArray: [],
      changeKeywordCondition,
      deleteKeyword,
      language: $rootScope.language,
      pageSizeSelect: [10, 20, 50, 100],
      setTab,
      changeCandidate,
      changeCategory,
      searchEnabled: undefined,
      document: { selected: {} },
      category: { selected: {} },
      function: { selected: {} },
      seeking: { selected: {} },
      initInputAutocomplete,
      initPlacesAutocomplete,
      autocomplete: null,
      autocompleteInput: null,
      submitWhenHitEnter,
      addCandidateBulk,
      addAllCandidateBulk,
      bulk: {
        bulkAction: false,
        allSelected: false,
      },
      candidatesChecked: [],
      selectedCandidateList: [],
      selectCandidate,
      isCrmCandidates: { state: true },
      candListEvent: false,
      openedPanelOnCvModule: "openSelectedDocument",
    };
    angular.extend($scope, scope);

    $scope.$on('$destroy', function () {
      $timeout.cancel(createTimeout1);
      $timeout.cancel(createTimeout2);
    });
  }
  crmCandidatesController.$inject = [
    '$scope',
    '$rootScope',
    'worklandLocalize',
    'utils',
    'api',
    '$timeout',
    '$ngConfirm',
    'Pager',
    'storageService',
    '_',
  ];
  angular.module('atlas')
    .controller('crmCandidatesController', crmCandidatesController)
// eslint-disable-next-line no-undef
}(angular));
