(function (angular) {
  function emailSentModuleCtrl(
    $scope,
    utils,
    storageService,
    $rootScope,
    api,
  ) {
    $scope.out = utils.out;
    const scope = {
      trustAsHtml: utils.trustAsHtml,
    };
    angular.extend($scope, scope);

    function init(leadId) {
      if ($scope.selectedCandidates.length === 1) {
        let data = {};        
        if ($scope.candidate) {
          $scope.candidate.email_history = [];
          data.candidate_id = $scope.candidate.user_id;
        }
        if ($scope.mode === 'crm-leads') {
          data.candidate_id = leadId ? leadId : $scope.candidate.id;
          data.index = 'crm-leads-emails';
        } else {
          data.candidate_id = $scope.candidate.user_id;
        }

        const promise = api.service_post('shared', 'history/search', data);
        promise.then((response) => {
          const hitsArr = [];
          if (response.data.hits.length > 0) {
            _.each(response.data.hits, (hit) => {
              if (hit._index === 'mailer' || hit._index === 'crm-leads-emails') {
                hitsArr.push(hit);
              }
            });
          }
          $rootScope.api_status('hide');
          $scope.candidate.email_history = hitsArr;
        }).catch(() => {
          $scope.candidate.email_history = [];
          $rootScope.api_status(
            'alert-danger',
            'An error has occurred while loading emails for the lead',
            'Une erreur s\'est produite lors du chargement des courriels du potentiel'
          );
        });
      }
    }

    init();

     $scope.$on('ReloadEmailHistory', (evt, leadID) => {
      // Note: do NOT remove the 'evt' paramer, as that will break the function
      init(leadID);
    });
  }

  emailSentModuleCtrl.$inject = [
    '$scope',
    'utils',
    'storageService',
    '$rootScope',
    'api',
  ];
  angular.module('atlas')
    .directive('emailSentModule', () => ({
      scope: {
        candidate: '=',
        selectedCandidates: '=',
        mode: '=',
      },
      controller: emailSentModuleCtrl,
      templateUrl: './employer-profile/views/crm/crm-candidates/email-sent-module/email-sent-module.template.html',
    }));
  angular.module('atlas').controller('emailSentModuleCtrl', emailSentModuleCtrl);
}(angular));
