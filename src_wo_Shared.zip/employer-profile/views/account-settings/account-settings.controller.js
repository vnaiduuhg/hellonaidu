(function (angular) {
  function accountSettingsController(
    $scope,
    $rootScope,
    utils,
  ) {
      const scope = {
        out: utils.out,
        header: {},
        modules: [],
        currentUser: $rootScope.currentUser,
        isAccountSettingsPage: true,
      };
      angular.extend($scope, scope);

      const automatedMessagesModule = {
        titleEn: 'Automated Messages',
        titleFr: 'Messages automatisés',
        state: 'automatedMessages',
        icon: 'fa fa-solid fa-bell',
        descriptionFr: 'Le puissant module de communication d\'Atlas permet d\'envoyer instantanément des notifications automatisées aux candidats et, ou aux autres membres de l\'équipe,  suite à certains événements.',
        descriptionEn: 'Atlas powerful communication module send automated notifications instantly to candidates and, or other team members, based on certain events.',
      };
      const emailSyncAccountModule = {
        titleEn: 'Sync Email Client',
        titleFr: 'Synchronisation courriel',
        state: 'sync',
        icon: 'fa fa-solid fa-arrows-rotate',
        descriptionFr: 'Notre module de synchronisation multiple permet : la synchronisation bidirectionnelle de courriel et de calendrier, la mise en place de sms par twilio, l\'envoie en masse de courriel par sendgrid et bien plus encore...',
        descriptionEn: 'Our multi synchronization module allows : two-way email  and calendar sync, sms setup through twilio, mass mailing through sendgrid and a lot more...',
      };
      const accountMembersModule = {
        titleEn: 'Account Members',
        titleFr: 'Membres du compte',
        state: 'userAssignment',
        icon: 'fa fa-solid fa-users',
        descriptionFr: 'Le module des membres du compte vous permet de gérer les affectations, les rôles des utilisateurs ou de supprimer complètement une personne de votre compte Atlas.',
        descriptionEn: 'The account members module allows you to manage the job assignments, user roles or to remove someone from your Atlas account entirely.',
      };
      const calendarSyncModule = {
        titleEn: 'Calendar Sync',
        titleFr: 'Synchronisation de calendrier',
        state: 'syncCalendar',
        icon: 'fa fa-solid fa-calendar',
        descriptionFr: 'Le module de synchronisation de calendrier vous permet de configurer votre calendrier Google ou Microsoft dans votre compte Atlas.',
        descriptionEn: 'The Calendar Sync module allows you to set up your Google or Microsoft calendar in your Atlas account.',
      };

      if ($rootScope.currentUser) {       
        $scope.modules.push(automatedMessagesModule);
        $scope.modules.push(accountMembersModule);
        $scope.modules.push(emailSyncAccountModule); 
        if ($rootScope.currentUser.permissions.isATSFull && !$rootScope.currentUser.permissions.isDeptMgrRecruiter 
          && !$rootScope.currentUser.permissions.isClient) {
            $scope.modules.push(calendarSyncModule);
        }
      }

      function init() {
        $scope.header = {
          titleEn: 'Account Settings',
          titleFr: 'Paramètres du compte',
          descriptionFirstEn: 'This page allows you to setup your Atlas account',
          descriptionFirstFr: 'Cette page vous permet de configurer votre compte Atlas',
        };        
      }
      init();
  }
  accountSettingsController.$inject = [
    '$scope',
    '$rootScope',
    'utils',
  ];
   angular.module('atlas')
   .controller('accountSettingsController', accountSettingsController);
  // eslint-disable-next-line no-undef
}(angular));
