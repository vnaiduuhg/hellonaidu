(function (angular) {
  angular.module('atlas-route', ['ui.router', 'ngResource']).config(['$routeProvider', '$stateProvider', '$urlRouterProvider', '$locationProvider',
    function ($routeProvider, $stateProvider, $urlRouterProvider, $locationProvider) {
      angular.injector(['ngCookies']).invoke(['$cookies', function () {
      }]);

      $locationProvider.html5Mode(true); // this removes the # sign in the URL, but requires nginx config changes
      $locationProvider.hashPrefix('!');
      $urlRouterProvider.when('/candidate', '/candidate/dashboard'); // default page for candidate
      $urlRouterProvider.when('/diffusion', '/diffusion/post'); // default page for Diffusion
      $urlRouterProvider.when('/careers/sunset?open=about', '/careers/sunset-converting-corp?open=about');
      
      $urlRouterProvider.otherwise('/404'); // page not found route

      function hideReact() {
        const $root = document.getElementById("root");
        if ($root.style.display !== "none"){
          $root.style.display = "none";
        }
      }

      function reactAppReady($q) {
        // Find the React App in 25 seconds or timeout.
        const TIMEOUT = 40000;
        const startTime = Date.now();

        if (window.Workland) return true;
        
        return $q(function(resolve, reject) {
          var interval = setInterval(() => {
            if (Date.now() - startTime > TIMEOUT) {
              // Note: This leads to an infinite loading screen. A error 500 page
              // would be good to show for such errors. For now, stop trying to
              // look for the react app.
              console.error('Cannot reach Workland app.');
              reject(false);
            }

            if (window.Workland) {
              clearInterval(interval);
              resolve(true);
            }
          }, 20);
        });
      }

      $stateProvider
      .state('404', {
          url: '/404',
          views: {
            '': {
              template: require('./atlas/views/page-not-found/page-not-found.template.html'),
              controller: 'PageNotFound',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('uploadDocumentsToJob', {
          url: '/job/:jobId/upload-documents',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              //
              if ( authService.isAuthed()
                && ngUserService
                && ngUserService.permissions 
                && (
                  ngUserService.permissions.isClient 
                  || ngUserService.permissions.isRecruiter 
                  || ngUserService.permissions.isEmployer 
                  || ngUserService.permissions.isAgency
                )
                ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;             
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            jobId: null
          },
        })
        // React route
        .state('subscribeSettings', {
          url: '/subscribe-settings',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService || !ngUserService) {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('subscribeSettingsSlug', {
          url: '/subscribe-settings/:slug',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService || !ngUserService) {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('planning-settings', {
          url:'/planning-settings',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('planning', {
          url:'/planning',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('requisition', {
          url:'/requisition',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('requisitionCreate', {
          url:'/requisition/create',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('requisitionView', {
          url: '/requisition/view/:requisitionId',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('requisitionStep', {
          url: '/requisition/:operation/:requisitionId/:step',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              // template: require('./atlas/views/react-gateway/react-gateway.template.html'),
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('docuTransfer', {
          url:'/docu-secur',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRegularRecruiter || ngUserService.permissions.isAdmin
                  )
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('home', {
          url: '/',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$location', 'storageService', function (ngUserService, $q, authService, $location, storageService) {
              const deferred = $q.defer();
              if (authService.isAuthed()) {
                const urlParams = $location.$$search;
                const syncType = storageService.getItem('sync_type');
                if (urlParams.code && (!syncType || syncType === 'microsoft')) {
                  storageService.setCookie('urlParams', JSON.stringify(urlParams));
                }

                if (ngUserService && ngUserService.permissions && (ngUserService.permissions.isEmployer || ngUserService.permissions.isRecruiter || ngUserService.permissions.isClient || ngUserService.permissions.isAgency)) {
                  const storageRedirectParam = storageService.getItem('redirect_to');
                  if (storageRedirectParam) {
                    storageService.removeItem('redirect_to');
                    window.location = `${window.appConfig.ATLAS_UI_URL}${storageRedirectParam}`;
                  }
                  else if (urlParams.redirectTo) {
                    window.location = `${window.appConfig.ATLAS_UI_URL}${urlParams.redirectTo}`;
                  }
                  else {
                    window.location = `${window.appConfig.ATLAS_UI_URL}employer`;
                  }
                } else if (ngUserService.permissions && ngUserService.permissions.isCandidate) {
                  if (urlParams.redirectTo) {
                    window.location = `${window.appConfig.ATLAS_UI_URL}${urlParams.redirectTo}`;
                  } else {
                    window.location = `${window.appConfig.ATLAS_UI_URL}candidate`;
                  }
                }
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: require('./atlas/directives/client-login/client-login.template.html'),
              controller: 'ClientLoginCtrl',
            },
            'header-module@': {
              template: '',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            quickRegisteredUser: null
          },
        })
        .state('loginPage', {
          url: '/login',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/client-login/client-login.template.html',
              controller: 'ClientLoginCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            openPanel: 'login',
          },
        })       
        .state('registrationPage', {
          url: '/register',
          views: {
            '': {
              templateUrl: './atlas/directives/client-login/client-login.template.html',
              controller: 'ClientLoginCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            openPanel: 'registration',
          },
        })
        .state('accounts', {
          url: '/accounts',
          views: {
            '': {
              template: '<user-accounts></user-accounts>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            openPanel: 'login',
            redirectUrl: '',
            idpParam: '',
            providerParam: '',
          },
        })
        .state('atlasDrive', {
          url: '/drive',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/atlas-drive/atlas-drive.template.html',
              controller: 'AtlasDriveCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        // TODO: find out how to use mulit-levelled routes in one route assignment
        .state('emails', {
          url: '/emails',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRegularRecruiter
                    || ngUserService.permissions.isAdmin
                  )
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('emails-slug', {
          url: '/emails/:a',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('emails-slug-slug', {
          url: '/emails/:a/:b',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('emails-slug-slug-slug', {
          url: '/emails/:a/:b/:c',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('integrations', {
          url: '/integrations',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRegularRecruiter
                    || ngUserService.permissions.isAdmin
                    || ngUserService.permissions.isAgency
                  )
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('integrations-slug', {
          url: '/integrations/:a',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('integrations-slug-slug', {
          url: '/integrations/:a/:b?code',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if ( authService.isAuthed()
                  && ngUserService
                  && ngUserService.permissions
                  && (
                    ngUserService.permissions.isRecruiter
                    || ngUserService.permissions.isEmployer
                    || ngUserService.permissions.isAgency
                  )
                  && !ngUserService.permissions.isUserManager
              ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            code: null,
          },
        })       
        .state('userPlan', {
          url: '/plan',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/plan/plan.template.html',
              controller: 'UserPlanCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('agencyPackages', {
          url: '/agency-packages',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/packages-display/packages-display.template.html',
              controller: 'PackagesDisplayCtrl',
            },
            'header-module@': {
              template: '<header-module ng-hide="true"></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          }
        })
        .state('theagencyPackages', {
          url: '/the-agency/packages',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/packages-display/packages-display.template.html',
              controller: 'PackagesDisplayCtrl',
            },
            'header-module@': {
              template: '<header-module ng-hide="true"></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          }
        })        
        .state('paymentGateway', {
          url: '/payment-gateway',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/payment-gateway/payment-gateway.template.html',
              controller: 'PaymentGatewayCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          }
        })        
        .state('jobsList', {
          url: '/jobs',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: require('./atlas/views/jobs-list/jobs-list.template.html'),
              controller: 'JobsListCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })        
        // React route
        .state('jobsDescription', {
          url: '/work/:jobId/:jobTitle?token',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })        
        // React route
        .state('companyDescription', {
          url: '/careers/:company?open',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            company: '',
          }
        })
        .state('reference', {
          url: '/reference-form',
          views: {
            '': {
              templateUrl: './shared-components/ised/ised-questionnaire-to-answer.template.html',
              controller: 'IsedQuestionnaireToAnswerController',
            },
            // HEADER call from quick-apply.template.html for dynamic logo
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            questionnaireId: '',
          },
        })
        .state('referee', {
          url: '/reference-request?key',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/referee-questionnaire/referee-questionnaire.template.html',
              controller: 'RefereeQuestionnaireCtrl',
            },
            // HEADER call from job-apply.template.html for dynamic logo
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('jobApply', {
          url: '/job-apply?token',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/job-apply/job-apply.template.html',
              controller: 'JobApplyCtrl',
            },
            // HEADER call from job-apply.template.html for dynamic logo
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            jobId: '',
            source: '',
            token: { squash: true, value: null },
          },
        })
        .state('jobAppliedSuccess', {
          url: '/job-applied-success',
          templateUrl: './atlas/directives/job-applied-success/job-applied-success.template.html',
          controller: 'JobAppliedSuccessCtrl',
          params: {
            jobId: '',
            loginStatus: '',
            candidateId: '',
            candidateAccAlreadyExist: '',
            isInternalCandidate: false,
            isMicrosoftLogin: false,
          },
        })
        .state('registration', {
          url: '/registration',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', function (ngUserService, $q) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/directives/registration/registration.template.html',
              controller: 'RegistrationCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            email: '',
            activation_code: '',
          },
        })
        .state('recruiterRegistration', {
          url: '/recruiter-registration',
          views: {
            '': {
              templateUrl: './atlas/directives/recruiter-registration/recruiter-registration.template.html',
              controller: 'RecruiterRegistrationCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            ref: '',
          },
        })
        .state('userInfo', {
          url: '/user-info',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed()) {
                $state.go('home');
                return deferred.promise;
              }

              deferred.resolve();

              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './shared-components/directives/user-info/user-info.template.html',
              controller: 'UserInfoCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('passwordFirstLogin', {
          url: '/password-first-login',
          resolve: {
            hideReact: hideReact,
            result: ['$q', '$state', 'authService', 'ngUserService', function ($q, $state, authService, ngUserService) {
              const deferred = $q.defer();
              if (ngUserService) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './atlas/views/password-first-login-change/password-first-login-change.template.html',
              controller: 'PasswordFirstLoginChange',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('passwordChange', {
          url: '/password-change',
          views: {
            '': {
              templateUrl: './atlas/views/password-change/password-change.template.html',
              controller: 'PasswordChange',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('passwordReset', {
          url: '/password-reset',
          views: {
            '': {
              templateUrl: './atlas/views/password-reset/password-reset.template.html',
              controller: 'PasswordResetCtrl',
            },
            'header-module@': {
              template: '',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('accountActivationReset', {
          url: '/account-activation-reset',
          views: {
            '': {
              templateUrl: './atlas/views/account-activation-reset/account-activation-reset.template.html',
              controller: 'AccountActivationResetCtrl',
            },
            'header-module@': {
              template: '',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('tiPerformance', {
          url: '/ti-performance',
          resolve: {
            hideReact: hideReact,
            result: ['$q', '$state', 'authService', 'ngUserService', function ($q, $state, authService, ngUserService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              deferred.resolve();
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './candidate-profile/views/ti-performance/ti-performance.template.html',
              controller: 'TiPerformanceCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('candidateProfile', {
          url: '/candidate',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed()) {
                $state.go('home');
                return deferred.promise;
              }
              if (!ngUserService || (ngUserService.permissions && !ngUserService.permissions.isCandidate)) {
                $state.go('home');
              } else {
                deferred.resolve();
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './candidate-profile/views/profile/profile.template.html',
              controller: 'profile',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('dashboard', {
          url: '/dashboard',
          parent: 'candidateProfile',
          templateUrl: './candidate-profile/directives/tab-dashboard.template.html',
        })
        .state('profile', {
          url: '/profile',
          parent: 'candidateProfile',
          templateUrl: './candidate-profile/directives/tab-profile.template.html',
        })
        .state('applications', {
          url: '/applications',
          parent: 'candidateProfile',
          templateUrl: './candidate-profile/directives/tab-applications.template.html',
        })
        .state('matches', {
          url: '/matches',
          parent: 'candidateProfile',
          templateUrl: './candidate-profile/directives/tab-applications.template.html',
        })
        .state('questionnaire', {
          url: '/questionnaire',
          parent: 'candidateProfile',
          template: '<questionnaire></questionnaire>',
          params: {
            jobId: '',
            initQTab: '',
          },
        })
        .state('mydocuments', {
          url: '/my-documents',
          parent: 'candidateProfile',
          views: {
            '': {
              templateUrl: './candidate-profile/directives/documents/my-documents.template.html',
              controller: 'candidate-documents',
            },
          },
          params: {
            upload: '',
          },
        })
        .state('requesteddocuments', {
          url: '/requested-documents',
          parent: 'candidateProfile',
          views: {
            '': {
              templateUrl: './candidate-profile/directives/documents/requested-documents.template.html',
              controller: 'requested-documents',
            },
          },
        })
        .state('pendingquestionnaires', {
          url: '/pending-questionnaires',
          parent: 'candidateProfile',
          template: '<ised-pending-questionnaires></ised-pending-questionnaires>',
          params: {
            currentCandidate: {},
            jobs: '',
          },
        })
        .state('interviews', {
          url: '/interviews',
          parent: 'candidateProfile',
          views: {
            '': {
              templateUrl: './candidate-profile/directives/interview-module/interview-module.template.html',
              controller: 'candidate-interview',
            },
          },
        })
        .state('references', {
          url: '/references',
          parent: 'candidateProfile',
          template: '<references-module></references-module>',
          params: {
            active: '',
            candidate: '',
            jobs: '',
            applications: '',
          },
        })
        .state('candidateConsent', {
          url: '/candidateConsent',
          parent: 'references',
          template: '<candidate-consent></candidate-consent>',
          params: {
            job: '',
          },
        })
        .state('employer', {
          url: '/employer',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!ngUserService || !authService.isAuthed()) {
                $state.go('home');
              } else if (ngUserService.permissions && (ngUserService.permissions.isRecruiter || ngUserService.permissions.isClient || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/jobs/jobs.template.html',
              controller: 'jobs',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('job', {
          url: '/job/:jobId',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', '$stateParams', 'authService', function (ngUserService, $q, $state, $stateParams, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
              } else if (ngUserService.permissions && (ngUserService.permissions.isClient || ngUserService.permissions.isRecruiter || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/job/job.template.html',
              controller: 'job',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            source: '',
            tab: '',
            jobId: '',
          },
        })            
        .state('modules', {
          url: '/modules',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!ngUserService || !authService.isAuthed()) {
                $state.go('home');
              } else if (ngUserService.permissions && (ngUserService.permissions.isDeptMgrRecruiter || ngUserService.permissions.isRegularRecruiter || ngUserService.permissions.isAdmin || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/modules/modules.template.html',
              controller: 'modules',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('diffusion', {
          url: '/diffusion',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/diffusion/diffusion.template.html',
              controller: 'DiffusionCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('post', {
          url: '/post',
          parent: 'diffusion',
          template: '<diffusion-post></diffusion-post>',
          params: {
            selectedSources: '',
          },
        })
        .state('sources', {
          url: '/sources',
          parent: 'diffusion',
          template: '<diffusion-sources></diffusion-sources>',
          params: {
            feed: 'hello',
          },
        })
        /* @temporarily hidden tabs
        .state('packages', {
          url: '/packages',
          parent: 'diffusion',
          template: '<diffusion-packages></diffusion-packages>',
        })
        .state('inventory', {
          url: '/inventory',
          parent: 'diffusion',
          template: '<diffusion-inventory></diffusion-inventory>',
        }) */
        .state('diffused', {
          url: '/diffusedJobs',
          parent: 'diffusion',
          template: '<diffusion-diffused></diffusion-diffused>',
        })
        .state('settings', {
          url: '/settings',
          parent: 'diffusion',
          template: '<diffusion-settings></diffusion-settings>',
        })
        .state('faq', {
          url: '/faq',
          parent: 'diffusion',
          template: '<diffusion-faq></diffusion-faq>',
        })
        .state('updateJob', {
          url: '/update-job',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', '$stateParams', 'authService', function (ngUserService, $q, $state, $stateParams, authService) {
              const deferred = $q.defer();
              if (!ngUserService || !authService.isAuthed()) {
                $state.go('home');
              } else if (ngUserService.permissions && (ngUserService.permissions.isRecruiter || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/update-job/update-job.template.html',
              controller: 'updateJobController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            jobId: '',
            duplicate: '',
          },
        })
        .state('statistics', {
          url: '/statistics',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if ( ngUserService.permissions && (ngUserService.permissions.isATSFull || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/statistics/statistics-ui.template.html',
              controller: 'StatisticsCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('crmCandidates', {
          url: '/crm/candidates',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', '$rootScope', function (ngUserService, $q, $state, authService, $rootScope) {
              const deferred = $q.defer();
              // It should not be necessary to check token in every employer state. This is redundant.
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isAdmin || ngUserService.permissions.isRegularRecruiter || (ngUserService.permissions.isClient && $rootScope.isPremiumClient))) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/crm/crm-candidates/crm-candidates.template.html',
              controller: 'crmCandidatesController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('crmLeads', {
          url: '/crm/leads',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', '$rootScope', function (ngUserService, $q, $state, authService, $rootScope) {
              const deferred = $q.defer();
              // It should not be necessary to check token in every employer state. This is redundant.
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter && !ngUserService.permissions.isClient) || (ngUserService.permissions.isClient && $rootScope.isPremiumClient))) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/crm/crm-leads/crm-leads.template.html',
              controller: 'crmLeadsController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('ised', {
          url: '/preselection',
          resolve: {
            hideReact: hideReact,
            result: ['$q', 'authService', '$state', 'ngUserService', function ($q, authService, $state, ngUserService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              deferred.resolve();
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: require('./employer-profile/ised/ised.template.html'),
              controller: 'isedController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // @todo check - not used as a url, needs to be nested on another directive
        .state('tagModule', {
          url: '/tag-module',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isRecruiter || ngUserService.permissions.isClient || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/tag-module/tag-module.template.html',
              controller: 'TagModuleCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('tags', {
          url: '/tags',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isRecruiter || ngUserService.permissions.isClient || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/atlas-drive/atlas-drive-tags/atlas-drive-tags.template.html',
              controller: 'AtlasDriveTagsCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('calendar', {
          url: '/calendar',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              // It should not be necessary to check token in every employer state. This is redundant.
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: '<calender-module></calender-module>',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('interviewRequests', {
          url: '/interview-requests',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isATSFull && !ngUserService.permissions.isClient) ) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/interview-requests/interview-requests.template.html',
              controller: 'InterviewRequestsController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('candidateSkills', {
          url: '/candidate-skills',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/candidate-skills/candidate-skills.template.html',
              controller: 'CandidateSkillsController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('employeeBenefits', {
          url: '/employee-benefits',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/employee-benefits/employee-benefits.template.html',
              controller: 'EmployeeBenefitsController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('jobsSettings', {
          url: '/jobs-settings',
          resolve: {
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ((ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/jobs-settings/jobs-settings.template.html',
              controller: 'jobsSettingsCtrl',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('manageSections', {
          url: '/manage-sections',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ngUserService.permissions.atsFullAndAdmin) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: '<crud-sections-module></crud-sections-module>',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('manageQuestions', {
          url: '/manage-questions',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && ngUserService.permissions.atsFullAndAdmin) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: '<crud-questions-module></crud-questions-module>',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
      /* @todo update */.state('employerProfile', {
          url: '/company-profile',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isAdminRecruiter || ngUserService.permissions.isWorkland || ngUserService.permissions.isAgency
                                || (ngUserService.permissions.isEmployer && !ngUserService.permissions.isRegularRecruiter)
                                || (ngUserService.permissions.isEmployer && !ngUserService.permissions.isDeptMgrRecruiter) || (ngUserService.permissions.isClient))) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/profile-company/profile-company.template.html',
              controller: 'profileCompany',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('automatedMessages', {
          url: '/automated-messages',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['$q', '$state', 'authService', 'ngUserService', function ($q, $state, authService, ngUserService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() ||
                  !ngUserService ||
                  ngUserService.permissions.isDeptMgrRecruiter ||
                  ngUserService.permissions.isUserManager ||
                  ngUserService.permissions.isClient ||
                  ngUserService.permissions.isCandidate
              ) {
                $state.go('home');
              }
              deferred.resolve();
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        .state('userAssignment', {
          url: '/user-assignment',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', 'authService', '$state', function (ngUserService, $q, authService, $state) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              if (ngUserService.permissions && (ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency || ngUserService.permissions.isRecruiter)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              template: '<user-assignment-module></user-assignment-module>',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
        // React route
        .state('sync', {
          url: '/sync?code',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', 'authService', '$state', '$location', 'storageService',  function (ngUserService, $q, authService, $state, $location, storageService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }
              const urlParams = $location.$$search;
              if (urlParams.code) {
                storageService.setCookie('urlParams', JSON.stringify(urlParams));
              }
              if (ngUserService.permissions && (
                    ngUserService.permissions.isEmployer ||
                    ngUserService.permissions.isAgency ||
                    ngUserService.permissions.isAdminRecruiter ||
                    ngUserService.permissions.isRegularRecruiter
              )) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            code: null,
          },
        })
        // React route
        .state('syncCalendar', {
          url: '/sync-calendar?code',
          resolve: {
            reactAppReady: ['$q', function($q) {return reactAppReady($q);}],
            result: ['ngUserService', '$q', 'authService', '$state', '$location', 'storageService',  function (ngUserService, $q, authService, $state, $location, storageService) {
              const deferred = $q.defer();
              if (!authService.isAuthed() || !ngUserService) {
                $state.go('home');
                return deferred.promise;
              }             
              if (ngUserService.permissions && (
                    ngUserService.permissions.isEmployer ||
                    ngUserService.permissions.isAgency ||
                    ngUserService.permissions.isAdminRecruiter ||
                    ngUserService.permissions.isRegularRecruiter
              )) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              controller: 'ReactGatewayCtrl'
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            code: null,
          },
        })
        // agency
        .state('workflowModule', {
          url: '/workflow-module',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q) {
              const deferred = $q.defer();

              if ((ngUserService && ngUserService.permissions.isATSFull && !ngUserService.permissions.isDeptMgrRecruiter) || (ngUserService && ngUserService.permissions.isClient)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/directives/workflow-module/workflow-module-header.template.html',
              controller: 'WorkflowModuleController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        })
      // end of agency routing
        .state('support', {
          url: '/support',
          resolve: {
            hideReact: hideReact,
            result() {
              window.location = 'https://support.workland.com';
            },
          },
        })
        .state('unsubscribe', {
          url: '/unsubscribe',
          views: {
            '': {
              templateUrl: './atlas/directives/unsubscribe/unsubscribe.template.html',
              controller: 'unsubscribeCtrl',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
          params: {
            hash: '',
          },
        })
        .state('accountSettings', {
          url: '/account-settings',
          resolve: {
            hideReact: hideReact,
            result: ['ngUserService', '$q', '$state', 'authService', function (ngUserService, $q, $state, authService) {
              const deferred = $q.defer();
              if (!ngUserService || !authService.isAuthed()) {
                $state.go('home');
              } else if (ngUserService.permissions && (ngUserService.permissions.isRecruiter || ngUserService.permissions.isClient || ngUserService.permissions.isEmployer || ngUserService.permissions.isAgency)) {
                deferred.resolve();
              } else {
                $state.go('home');
              }
              return deferred.promise;
            }],
          },
          views: {
            '': {
              templateUrl: './employer-profile/views/modules/modules.template.html',
              controller: 'accountSettingsController',
            },
            'header-module@': {
              template: '<header-module></header-module>',
            },
            'footer-module@': {
              template: '<short-footer-module></short-footer-module>',
            },
          },
        });
    },
  ]).service('storageService', ['localStorageService', 'cookiesService', function (localStorageService, cookiesService) {
    this.hasLocalStorage = window.localStorage || false;
    return this.hasLocalStorage ? localStorageService : cookiesService;
  }]);
// eslint-disable-next-line no-undef
}(angular));
