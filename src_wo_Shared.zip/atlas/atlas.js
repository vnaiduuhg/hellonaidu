import 'lazysizes/plugins/attrchange/ls.attrchange';
import 'lazysizes/plugins/respimg/ls.respimg';
import 'lazysizes/plugins/rias/ls.rias';
import 'lazysizes/plugins/bgset/ls.bgset';

require('lazysizes');

require('../shared-components/js/shared-components.js');
require('../shared-components/js/services/services.js');
require('../shared-components/js/services/api.factory.js');
require('../shared-components/js/services/utils.factory.js');
require('../shared-components/js/services/data.exchange.js');
require('../shared-components/js/services/filters.js');
require('../shared-components/js/services/transferer.service.js');
require('../shared-components/js/services/translation.service.js');
require('../shared-components/js/services/user.service.js');
require('../shared-components/js/services/userAccountsService.js');
require('../shared-components/js/services/metatags.service.js');
require('../shared-components/js/services/authService.js');
require('../shared-components/js/services/marketplaceService.js');
// require('../shared-components/js/services/matchService.js');
require('../shared-components/js/services/jsonService.js');
require('../shared-components/js/services/localStorageService.js');
require('../shared-components/js/services/cookiesService.js');
require('../shared-components/js/directives.js');
require('../shared-components/js/services/productService.js');
require('../shared-components/js/services/applicationService.js');
require('../shared-components/js/services/inventoryService.js');
require('../shared-components/js/services/userSyncStateService.js');
require('../shared-components/directives/header-module/header-module.directive.js');
require('../shared-components/directives/custom-header-module/custom-header-module.directive.js');
require('../shared-components/directives/footer-module/footer-module.directive.js');
require('../shared-components/directives/api-response-module/api-response-module.directive.js');
require('../shared-components/directives/compatibility-report-module/compatibility-report-module.directive.js');
require('../shared-components/directives/questionnaire/questionnaire.directive.js');
require('../shared-components/directives/questionnaire/questionnaireUtils.factory.js');
require('../shared-components/ised/ised-question-to-answer.directive.js');
require('../shared-components/directives/user-info/user-info.controller.js');
// js employer app
require('../shared-components/ised/ised-questionnaire-to-answer.directive.js');
require('../shared-components/directives/personality-report-module/personality-report-module.directive.js');
require('../shared-components/directives/chat-module/chat-module.directive.js');
require('../shared-components/directives/loading-spinner-module/loading-spinner-module.directive.js');
require('../shared-components/directives/document-viewer/document-viewer.directive.js');
require('../shared-components/js/services/angular-locale_fr.js');
require('../shared-components/js/services/angular-locale_en.js');

// FIXME: there's a .modal-body style here. fix needs to be merged
// alongside angular
require('../assets/css/less/rachid/employer-job-modal.less');
require('../assets/css/less/rachid/diffusion-screen.less');
// TODO: check how to better fix this w/o effecting everythign globally
require('../assets/css/less/rachid/personality-report.less');

// CSS files
require('../assets/css/less/style.less');
require('../assets/css/less/single-work.less');
require('../assets/css/less/page-jobs.less');
require('../assets/css/less/client-login.less');
require('../assets/css/less/candidate-profile.less');
require('../assets/css/less/candidate-reports.less');
require('../assets/css/less/candidate-requested-documents.less');
require('../assets/css/less/job-apply.less');
require('../assets/css/less/diffusion-page.less');
require('../assets/css/less/components/statistics/_statistics.less');
require('../assets/css/default-app.css');
require('../assets/css/less/_footer.less');
require('../assets/css/less/_payment-gateway.less');
require('../assets/css/header.css');
require('../assets/css/less/company-description.less');

// CSS files employer app
require('../assets/css/less/employer-profile.less');

/*==== new design implementation =====*/
require('../assets/css/less/__global.less');
require('../assets/css/less/__global-components.less')
/*public pages*/
require('../assets/css/less/_referee-questionnaire.less');
require('../assets/css/less/_packages-display.less');
/*end public pages*/
/*------- Modules pages -------*/
require('../assets/css/less/_user-info.less');
require('../assets/css/less/_modules.less');
require('../assets/css/less/_integrations.less');
require('../assets/css/less/_atlas-drive-tags.less');
require('../assets/css/less/_job.less');
require('../assets/css/less/_candidates.less');
require('../assets/css/less/_rejection-module.less');
require('../assets/css/less/_preselection-filter-modal.less');
require('../assets/css/less/_email-composer.less');
require('../assets/css/less/_reference-module.less');
require('../assets/css/less/_references-module.less');
require('../assets/css/less/_ised-send-questionnaire-module.less');
require('../assets/css/less/_interview-module.less');
require('../assets/css/less/_tag-module.less');
require('../assets/css/less/_jobs.less');
require('../assets/css/less/_substitutus-module.less');
require('../assets/css/less/_cv-module.less');
require('../assets/css/less/_crm-leads.less');
require('../assets/css/less/_preselection.less');
require('../assets/css/less/_crm-candidates.less');
require('../assets/css/less/_candidate-metadata.less');
require('../assets/css/less/components/update-job/_update-job.less');
require('../assets/css/less/components/update-job/_job-requirement-module.less');
require('../assets/css/less/components/update-job/_required-documents-module.less');
require('../assets/css/less/components/update-job/_preview-module.less');
require('../assets/css/less/_workflow-module.less');
require('../assets/css/less/_notes-module.less');
require('../assets/css/less/_history-module.less');
require('../assets/css/less/components/atlas-drive/_atlas-drive.less');
require('../assets/css/less/_user-assignment.less');
require('../assets/css/less/_employee-benefits.less');
require('../assets/css/less/_calendar-module.less');
require('../assets/css/less/_company-profile-module.less');
require('../assets/css/less/_interview-requests.less');
require('../assets/css/less/_docu-transfer.less');
require('../assets/css/less/_docusign-module.less');

require('../shared-components/js/services/statService.js');

(function (angular) {
  const app = angular.module('atlas', [
    'ngCsv',
    'ngRoute',
    'ngSanitize',
    'ngFx',
    'ui.select',
    'ui.bootstrap',
    'ui.sortable',
    'xeditable',
    'ngFileUpload',
    'rzModule',
    'cp.ngConfirm',
    'shared-components',
    'atlas-route',
    'ngCookies',
    // employer
    'chart.js',
    'ngAnimate',
    'ngCkeditor',
    'colorpicker.module',
    'angularjs-datetime-picker',
    'tmh.dynamicLocale',
    'mwl.calendar',
    'ngMessages',
    'ngMaterial',
    'cleave.js',
    'as.sortable',
    // employer
  ]);

  app.run(['editableOptions', '$location', '$anchorScroll', '$templateCache',
    function (editableOptions, $location, $anchorScroll, $templateCache) {
      const url = $location.absUrl();
      if (url.indexOf('worklandatlas.com') !== -1) {
        window.location.href = 'https://atlas.workland.com/';
      }
      // bootstrap3 theme. Can be also 'bs2', 'default'
      editableOptions.theme = 'bs4';
      //this will make anchorScroll scroll to the div minus 50px
      $anchorScroll.yOffset = 50;
      //config for ui-select

    $templateCache.put("mytheme/choices.tpl.html", '<ul class="ui-select-choices ui-select-choices-content select2-results"><li class="ui-select-choices-group" ng-class="{\'select2-result-with-children\': $select.choiceGrouped($group) }"><div ng-show="$select.choiceGrouped($group)" class="ui-select-choices-group-label select2-result-label" ng-bind="$group.name"></div><ul role="listbox" id="ui-select-choices-{{ $select.generatedId }}" ng-class="{\'select2-result-sub\': $select.choiceGrouped($group), \'select2-result-single\': !$select.choiceGrouped($group) }"><li role="option" id="ui-select-choices-row-{{ $select.generatedId }}-{{$index}}" class="ui-select-choices-row" ng-class="{\'select2-highlighted\': $select.isActive(this), \'select2-disabled\': $select.isDisabled(this)}"><div class="select2-result-label ui-select-choices-row-inner"></div></li></ul></li></ul>'),
    $templateCache.put("mytheme/match-multiple.tpl.html", '<span class="ui-select-match"><li class="ui-select-match-item select2-search-choice" ng-repeat="$item in $select.selected" ng-class="{\'select2-search-choice-focus\':$selectMultiple.activeMatchIndex === $index, \'select2-locked\':$select.isLocked(this, $index)}" ui-select-sort="$select.selected"><span uis-transclude-append=""></span> <a href="javascript:;" class="ui-select-match-close select2-search-choice-close" ng-click="$selectMultiple.removeChoice($index);" tabindex="-1"></a></li></span>'),
    $templateCache.put("mytheme/match.tpl.html", '<a class="select2-choice ui-select-match" ng-class="{\'select2-default\': $select.isEmpty()}" ng-click="$select.toggle($event)" aria-label="{{ $select.baseTitle }} select"><span ng-show="$select.isEmpty()" class="select2-chosen">{{$select.placeholder}}</span> <span ng-hide="$select.isEmpty()" class="select2-chosen" ng-transclude=""></span> <abbr ng-if="$select.allowClear && !$select.isEmpty()" class="select2-search-choice-close" ng-click="$select.clear($event)"></abbr> <span class="select2-arrow ui-select-toggle"><b></b></span></a>'),
    $templateCache.put("mytheme/select-multiple.tpl.html", '<div class="ui-select-container ui-select-multiple select2 select2-container select2-container-multi" ng-class="{\'select2-container-active select2-dropdown-open open\': $select.open, \'select2-container-disabled\': $select.disabled}"><ul class="select2-choices"><span class="ui-select-match"></span><li class="select2-search-field"><input type="text" autocomplete="false" autocorrect="off" autocapitalize="off" spellcheck="false" role="combobox" aria-expanded="true" aria-owns="ui-select-choices-{{ $select.generatedId }}" aria-label="{{ $select.baseTitle }}" aria-activedescendant="ui-select-choices-row-{{ $select.generatedId }}-{{ $select.activeIndex }}" class="select2-input ui-select-search" placeholder="{{$selectMultiple.getPlaceholder()}}" ng-disabled="$select.disabled" ng-hide="$select.disabled" ng-model="$select.search" ng-click="$select.activate()" style="width: 34px;" ondrop="return false;"></li></ul><div class="ui-select-dropdown select2-drop select2-with-searchbox select2-drop-active" ng-class="{\'select2-display-none\': !$select.open || $select.items.length < 1}"><div class="ui-select-choices"></div></div></div>'),
    $templateCache.put("mytheme/select.tpl.html", '<div class="ui-select-container select2 select2-container" ng-class="{\'select2-container-active select2-dropdown-open open\': $select.open, \'select2-container-disabled\': $select.disabled, \'select2-container-active\': $select.focus, \'select2-allowclear\': $select.allowClear && !$select.isEmpty()}"><div class="ui-select-match"></div><div class="ui-select-dropdown select2-drop select2-with-searchbox select2-drop-active" ng-class="{\'select2-display-none\': !$select.open}"><div class="select2-search" ng-show="$select.searchEnabled"><input type="text" autocomplete="false" autocorrect="false" autocapitalize="off" spellcheck="false" role="combobox" aria-expanded="true" aria-owns="ui-select-choices-{{ $select.generatedId }}" aria-label="{{ $select.baseTitle }}" aria-activedescendant="ui-select-choices-row-{{ $select.generatedId }}-{{ $select.activeIndex }}" class="ui-select-search select2-input" ng-model="$select.search"></div><div class="ui-select-choices"></div></div></div>')

    },
  ]);

  app.directive('uiSelectNoAnimate', () => ({
    restrict: 'A',
    require: 'uiSelect',
    link: (scope, element, attrs, $select) => {
      $select.$animate = null;
    },
  }));

  app.config(['tmhDynamicLocaleProvider',
    function (tmhDynamicLocaleProvider) {
      tmhDynamicLocaleProvider.defaultLocale('fr');
      tmhDynamicLocaleProvider.localeLocationPattern('./../shared-components/js/services/angular-locale_{{locale}}.js');
    }]);

  app.config(['$uibModalProvider', function($uibModalProvider) {
    $uibModalProvider.options.windowClass = 'show';
    $uibModalProvider.options.backdropClass = 'show';
  }]);

// eslint-disable-next-line no-undef
}(angular));
