(function (angular) {
  function unsubscribeCtrl(
      $scope,
      api,
      utils,
      MetaTagsService,
      $location,
      $state,
      $ngConfirm,
  ) {
    $scope.out = utils.out;
    const scope = {
      loading: false,
      errorMessage: false,
      successMessage: false,
    };
    angular.extend($scope, scope);
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function unsubscribe() {
      $scope.loading = true;
      var queryString = $location.$$search;
      var url = decodeURI(queryString.hash);
      api.service_post('messaging', 'unsubscribe', {
        "unsubscribe_code": url
      }).then((response) => {
        $scope.loading = false;
        if (response.status === 201) {
          $scope.successMessage = true;
        } else {
          $scope.errorMessage = true;
        }
      }).catch(() => {
        $scope.loading = false;
        $scope.errorMessage = true;
      });
    }

    function init() {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: "",
        content: utils.out("Êtes vous sûr de vouloir vous désabonner ?", "Are you sure you want to unsubscribe?"),
        type: 'red',
        typeAnimated: true,
        animation: 'RotateX',
        backgroundDismiss: false,
        backgroundDismissAnimation: 'shake',
        buttons: {
          ok: {
            text: $scope.out('Valider', 'Unsubscribe'),
            btnClass: 'btn btn-danger float-end',
            action() {
              unsubscribe();
            }
          },
          no: {
            text: $scope.out('Quitter', 'Cancel'),
            btnClass: 'btn-alt-danger float-end',
            action() {
            },
          },
        }
      });         
    }
    init();
 }

  unsubscribeCtrl.$inject = [
    '$scope',
    'api',
    'utils',
    'MetaTagsService',
    '$location',
    '$state',
    '$ngConfirm',
  ];
  const app = angular.module('atlas');
  app.controller('unsubscribeCtrl', unsubscribeCtrl);
}(angular));
