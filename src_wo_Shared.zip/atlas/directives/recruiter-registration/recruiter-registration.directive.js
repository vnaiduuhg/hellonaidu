(function (angular) {
  const app = angular.module('atlas');

  app.controller('RecruiterRegistrationCtrl', RecruiterRegistrationCtrl);

  RecruiterRegistrationCtrl.$inject = ['$scope', '$rootScope', 'api', '_', 'utils', '$location', '$state', 'authService', 'storageService'];

  function RecruiterRegistrationCtrl($scope, $rootScope, api, _, utils, $location, $state, authService, storageService) {
    const scope = {
      imagesUrl: './../assets/images/',
      registerRecruiterFormModel: {},
      statut: 'recruiter',
      out: utils.out,
      isNewUser: null,
      logo: '',
      companyName: '',
      socialLogin,
      validateSubmit,
      refreshActivationLink,
      continueOnAtlas,
      toggleSSOSection,
      singleSignOnLogin,
      removeSSOErrors,
      invitation: null,
      errors: {},
      flags: {
        flagEmail: true,
        flagUsername: true,
        flagFirstname: true,
        flagLastname: true,
        flagPhone: true,
        flagPassword: true,
        flagConfirmPassword: true,
      },
      registerMessage: {
        email: false,
        username: false,
        nextStep: false,
        beforeSubmit: false,
        registrationFailError: false,
      },
      responseError: false,
      invalidKeyMessage: false,
      expiredKeyMessage: false,
      connectionFailMessage: false,
      registerOnAtlas: false,
      socialGeneralErrorMgs: false,
      socialConnectionErrorMgs: false,
      socialRedirect: false,
      openSSOSection: false,
      domainNameRequired: false,
      domainNameError: false,
      domainNameMatchError: false,
      domain: {
        name: '',
      },
      provider: {
        name: '',
      },
      showOnAtlasButton: true,
      idpsList: [],
      employerIdp: '',
      idpsListFailed: false,
    };
    angular.extend($scope, scope);

    function getIdpsList() {
      api.service_get('accounts', 'idps').then((response) => {
        if (response.data.status === 'success' && response.data.data) {
          $scope.idpsList = response.data.data;
        } else {
          $scope.idpsListFailed = true;
        }
      }).catch(() => {
        $scope.idpsListFailed = true;
      });
    }

    function getCompanyIdp() {
      api.service_get('accounts', `accounts/${$scope.invitation.account_id}/idp-name`).then((response) => {
        if (response.data.status === 'success' && response.data.data) {
          $scope.employerIdp = response.data.data;
        }
      }).catch((err) => {
        if (err.status === 404) {
          $scope.employerIdp = err.data.message;
        }
      });
    }

    function init() {
      const queryString = $location.$$search;
      if (!queryString.invite) {
        $state.go('home');
        return;
      }

      $scope.inviteKey = decodeURI(queryString.invite);
      $rootScope.language = decodeURI(queryString.lang);
      authService.key({ key: $scope.inviteKey }).then((res) => {
        if (res.data.status == 'success') {
          $scope.invitation = res.data.data;
          api.service_post('accounts', 'accounts/default-profiles', {
            account_ids: [$scope.invitation.account_id],
          }).then((profileResponse) => {
            if (profileResponse.data.status == 'success') {
              $scope.logo = getProfileLogoUrl(profileResponse.data.data[$scope.invitation.account_id].logo);
              $scope.companyName = profileResponse.data.data[$scope.invitation.account_id].name;
              getCompanyIdp();
            }
          }).catch(() => {});
          $scope.isNewUser = !$scope.invitation.user_id;
          if (!$scope.isNewUser) {
            $scope.existingUserId = $scope.invitation.user_id;
          }
          $scope.registerRecruiterFormModel.email = $scope.invitation.email;
          $scope.showForm = true;
        } else {
          $scope.responseError = true;
        }
      }).catch((err) => {
        $scope.responseError = true;
        const msg = err.data && err.data.message ? err.data.message : '';
        switch (msg) {
          case 'member_already_exists':
            $scope.userExistsMessage = true;
            break;
          case 'invitation_key_not_found':
            $scope.invalidKeyMessage = true;
            break;
          case 'invitation_key_expired':
          default:
            $scope.expiredKeyMessage = true;
        }
      });
      getIdpsList();
    }

    init();

    function toggleSSOSection() {
      $scope.openSSOSection = !$scope.openSSOSection;
      if (!$scope.openSSOSection) $scope.domain.name = '';
    }

    function getProfileLogoUrl(logo) {
      const minioUrl = `${window.appConfig.MINIO_URL}media/Profile/`;
      if (logo) {
        return `${minioUrl}Logos/${logo}`;
      }
      return `${minioUrl}Logos/generic_logo.png`;
    }

    function refreshActivationLink() {
      $scope.responseError = false;
      const data = {
        language: $rootScope.language,
      };
      return api.service_post('accounts', `accounts/resend-invitation/${$scope.inviteKey}`, data).then((res) => {
        $scope.expiredKeyMessage = false;
        $scope.showForm = true;
        if (res.data.status == 'success') {
          // message to user - invitation success
          $scope.successSubmitForm = true;
          $scope.responseError = false;
          $scope.refreshLinkSuccessMessage = true;
          $scope.registrating = false;
        } else {
          // message to user - invitation fail
          $scope.responseError = true;
          $scope.refreshLinkErrorMessage = true;
        }
      }).catch((err) => {
        $scope.expiredKeyMessage = false;
        $scope.showForm = false;
        $scope.responseError = true;
        $scope.refreshLinkErrorMessage = true;
      });
    }

    // validation
    $scope.checkUsername = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.username;
      }
      if (!$scope.registerRecruiterFormModel.username) {
        $scope.errors.usernameError = true;
        $scope.flags.flagUsername = true;
      } else {
        $scope.errors.usernameError = false;
        $scope.flags.flagUsername = false;
      }
    };

    $scope.checkFirstname = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.first_name;
      }

      if (!$scope.registerRecruiterFormModel.firstname) {
        $scope.errors.firstnameError = true;
        $scope.flags.flagFirstname = true;
      } else {
        $scope.errors.firstnameError = false;
        $scope.flags.flagFirstname = false;
      }
    };

    $scope.checkLastname = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.last_name;
      }

      if (!$scope.registerRecruiterFormModel.lastname) {
        $scope.errors.lastnameError = true;
        $scope.flags.flagLastname = true;
      } else {
        $scope.errors.lastnameError = false;
        $scope.flags.flagLastname = false;
      }
    };

    $scope.checkEmail = function (fromTemplate) {
      const email = fromTemplate > 0 ? $scope.registerRecruiterFormModel.email : $scope.invitation.email;
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.user_email;
      }

      const pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (email != null && pattern.test(email)) {
        $scope.errors.emailError = false;
        if (fromTemplate) {
          $scope.registerRecruiterForm.email.$invalid = false;
        }
        $scope.flags.flagEmail = false;
      } else {
        $scope.errors.emailError = true;
        if (fromTemplate) {
          $scope.registerRecruiterForm.email.$invalid = true;
        }
        $scope.flags.flagEmail = true;
      }
      return !$scope.errors.emailError;
    };

    $scope.checkPassword = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.password;
      }

      const pattern = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
      if ($scope.registerRecruiterFormModel.userPassword != null && pattern.test($scope.registerRecruiterFormModel.userPassword)) {
        $scope.errors.passwordError = false;
        $scope.registerRecruiterForm.password.$invalid = false;
        $scope.flags.flagPassword = false;
      } else {
        $scope.errors.passwordError = true;
        $scope.registerRecruiterForm.password.$invalid = true;
        $scope.flags.flagPassword = true;
      }
    };

    $scope.checkPhone = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.phone;
      }

      const pattern = /^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4})$/;
      if (!$scope.registerRecruiterFormModel.phone || pattern.test($scope.registerRecruiterFormModel.phone)) {
        $scope.errors.phoneError = false;
        $scope.registerRecruiterForm.phone.$invalid = false;
        $scope.flags.flagPhone = false;
      } else {
        $scope.errors.phoneError = true;
        $scope.registerRecruiterForm.phone.$invalid = true;
        $scope.flags.flagPhone = true;
      }
    };

    $scope.checkConfirmPassword = function () {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.password_confirmation;
      }

      $scope.registerRecruiterForm.confirmPassword.$invalid = true;
      if ($scope.registerRecruiterFormModel.userPassword === $scope.registerRecruiterFormModel.confirmUserPassword) {
        $scope.errors.confirmPasswordError = false;
        $scope.registerRecruiterForm.confirmPassword.$invalid = false;
        $scope.registerRecruiterForm.$invalid = false;
        $scope.flags.flagConfirmPassword = false;
      } else {
        $scope.errors.confirmPasswordError = true;
        $scope.registerRecruiterForm.confirmPassword.$invalid = true;
        $scope.registerRecruiterForm.$invalid = true;
        $scope.flags.flagConfirmPassword = true;
      }
    };

    $scope.clearForm = function () {
      $scope.registerRecruiterForm.$setPristine();
      $scope.registerRecruiterForm.$setUntouched();
      $scope.registerRecruiterFormModel = {};
      $scope.status = {};
      $scope.errors = {};
      $scope.flags = {};
      $scope.notValidated = true;
    };

    function registerIfUsernameNotDuplicate() {
      $scope.usernameCheckLoading = true;
      authService.find({ username: $scope.registerRecruiterFormModel.username, type: 'candidate' }).then((res) => {
        $scope.usernameCheckLoading = false;
        if (res.data.status == 'success') {
          if (res.data.data.user_id) {
            $scope.flags.flagUsername = true;
            $scope.registerMessage.username = true;
          } else {
            $scope.notValidated = false;
            register();
          }
        }
      }).catch((err) => {
        $scope.usernameCheckLoading = false;
        if (err.status == 422) {
          $scope.registrationErrors = err.data;
        }
        $scope.registerMessage.registrationFailError = (err.status != 422);
      });
    }

    // params to receive: email, role, account_id, company_name
    function register() {
      $scope.registrating = true;
      let data = {};
      if ($scope.isNewUser) {
        data = {
          username: $scope.registerRecruiterFormModel.username,
          first_name: $scope.registerRecruiterFormModel.firstname,
          last_name: $scope.registerRecruiterFormModel.lastname,
          password: $scope.registerRecruiterFormModel.userPassword,
          phone: $scope.registerRecruiterFormModel.phone,
          language: $rootScope.language,
        };
      } else {
        data = {
          user_id: $scope.existingUserId,
        };
      }

      api.service_post('accounts', `accounts/accept-invitation/${$scope.inviteKey}`, data).then((res) => {
        $scope.registrating = false;
        if (res.data.status == 'success') {
          $scope.successSubmitForm = true;
          $scope.clearForm();
          $scope.registerMessage.nextStep = true;
        }
      }).catch((err) => {
        $scope.registrating = false;
        if (err.status == 422) {
          $scope.registrationErrors = err.data;
        } else if (err.data.message == 'member_already_exists') {
          $scope.showForm = false;
          $scope.responseError = true;
          $scope.userExistsMessage = true;
        } else {
          // general error case
          $scope.registerMessage.registrationFailError = (err.status != 422);
        }
        $scope.registerRecruiterFormModel.userPassword = '';
        $scope.registerRecruiterFormModel.confirmUserPassword = '';
      });
    }

    function validateAutofilledFields() {
      if ($scope.flags.flagEmail) {
        $scope.checkEmail(0);
      }
      if ($scope.flags.flagUsername) {
        $scope.checkUsername();
      }
      if ($scope.flags.flagFirstname) {
        $scope.checkFirstname();
      }
      if ($scope.flags.flagLastname) {
        $scope.checkLastname();
      }
      if ($scope.flags.flagPhone) {
        $scope.checkPhone();
      }
      if ($scope.flags.flagPassword) {
        $scope.checkPassword();
      }
      if ($scope.flags.flagConfirmPassword) {
        $scope.checkConfirmPassword();
      }
    }

    function socialLogin() {
      removeSSOErrors();
      $scope.socialRedirect = true;
      storageService.setItem('connection_action', 'register');
      $scope.provider.name = 'Microsoft';
      const params = {
        lang: $rootScope.language,
        role_id: $scope.invitation.role_id,
        account_id: $scope.invitation.account_id,
        key: $scope.inviteKey,
      };
      api.service_get('accounts', 'auth/social-login/microsoft', params).then((response) => {
        if (response.data.status === 'success') {
          window.location = response.data.data.link;
        } else {
          $scope.socialGeneralErrorMgs = true;
          $scope.socialRedirect = false;
        }
      }).catch((err) => {
        if (err.status === 400) {
          $scope.socialConnectionErrorMgs = true;
        } else {
          $scope.socialGeneralErrorMgs = true;
        }
        $scope.socialRedirect = false;
      });
    }

    function continueOnAtlas() {
      $scope.showOnAtlasButton = false;
      $scope.registerOnAtlas = true;
    }

    function removeSSOErrors() {
      $scope.domainNameRequired = false;
      $scope.domainNameError = false;
      $scope.domainNameMatchError = false;
      $scope.provider.name = '';
    }

    function getDomainFromIdpList(userEmailDomain) {
      return _.find($scope.idpsList, (item) => item.domain === userEmailDomain);
    }

    function singleSignOnLogin() {
      removeSSOErrors();
      const regExp = /@?([^@]+)$/;
      const userEmailDomain = $scope.domain.name ? $scope.domain.name.match(regExp) : $scope.domain.name;
      if (!userEmailDomain) {
        $scope.domainNameRequired = true;
        return;
      }

      $scope.socialRedirect = true;
      storageService.setItem('connection_action', 'register');
      const params = {
        lang: $rootScope.language,
        role_id: $scope.invitation.role_id,
        account_id: $scope.invitation.account_id,
        key: $scope.inviteKey,
      };

      if (!$scope.employerIdp || $scope.idpsListFailed) {
        $scope.socialGeneralErrorMgs = true;
        $scope.socialRedirect = false;
        return;
      }

      const internalIdpDomain = getDomainFromIdpList(userEmailDomain[1]);
      if (internalIdpDomain) {
        $scope.provider.name = internalIdpDomain.name.toUpperCase();
        if (internalIdpDomain.name === $scope.employerIdp) {
          api.service_get('accounts', `auth/saml2/${internalIdpDomain.name}/login`, params).then((response) => {
            if (response.status === 200 && response.data) {
              window.location = response.data;
            } else {
              $scope.socialGeneralErrorMgs = true;
              $scope.socialRedirect = false;
            }
          }).catch(() => {
            $scope.socialGeneralErrorMgs = true;
            $scope.socialRedirect = false;
          });
        } else {
          $scope.domainNameMatchError = true;
        }
      } else {
        $scope.domainNameError = true;
      }
    }

    function validateSubmit() {
      $scope.notValidated = true;
      resetRegisterMessage();

      if ($scope.isNewUser) {
        // validate all fields
        validateAutofilledFields();
        if (!$scope.flags.flagUsername && !$scope.flags.flagFirstname
                    && !$scope.flags.flagLastname && !$scope.flags.flagEmail
                    && !$scope.flags.flagPassword && !$scope.flags.flagConfirmPassword
                    && !$scope.flags.flagPhone) {
          registerIfUsernameNotDuplicate();
        } else {
          $scope.registerMessage.beforeSubmit = true;
        }
      } else {
        // validate email
        $scope.checkEmail(0);
        if (!$scope.flags.flagEmail) {
          $scope.notValidated = false;
          register();
        } else {
          $scope.registerMessage.beforeSubmit = true;
        }
      }
    }

    function resetRegisterMessage() {
      $scope.registerMessage.beforeSubmit = false;
      $scope.registerMessage.registrationFailError = false;
      $scope.registerMessage.nextStep = false;
      $scope.registerMessage.username = false;
    }
  }
}(angular));
