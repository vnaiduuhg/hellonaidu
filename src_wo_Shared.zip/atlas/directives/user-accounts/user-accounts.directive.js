(function (angular) {
    'use strict';
    angular.module('atlas')
            .directive('userAccounts', function () {
                return {
                    scope: { },
                    controller: userAccountsCtrl,
                    templateUrl: './../atlas/directives/user-accounts/user-accounts.template.html'
                };
            });
    userAccountsCtrl.$inject = ['$scope', '$rootScope', 'utils', 'authService', '$ngConfirm','storageService', '$state', '$stateParams', 'userAccountsService'];
    function userAccountsCtrl($scope, $rootScope, utils , authService, $ngConfirm,storageService, $state, $stateParams, userAccountsService) {
        var scope = {
            accountChoice: accountChoice,
            init: init,
            out: utils.out,
            loginAsAnotherUser: loginAsAnotherUser,
            idpParam: $stateParams.idpParam,
            providerParam: $stateParams.providerParam,
        }
        angular.extend($scope, scope);

        function createUserMessage(msg) {
            $ngConfirm({
                title: '',
                content: msg,
                type: 'red',
                buttons: {
                  ok: {
                    text: 'ok',
                    btnClass: 'btn btn-secondary',
                    action() {

                    },
                  },
                },
              })
        }

        init();
        function init() {
            $scope.redirect_url = $stateParams.redirectUrl;
            $scope.userAccounts = JSON.parse(storageService.getItem('accounts'));
            $scope.loaded = false;
            angular.forEach($scope.userAccounts, function (account) {
                if (account.account.type === "agency") {
                    account.account.title = utils.out("agence", "agency");
                }
                else if (account.account.type === "seller") {
                    account.account.title = utils.out("vendeur(se)", "seller");
                }
                else if (account.account.type === "client") {
                    account.account.title = utils.out("client", "client");
                }
                else if (account.account.type === "company") {
                    account.account.company = account.account.name;
                    account.account.title = utils.out("compagnie", "company");
                }
                else if (account.account.type === "candidate") {
                    account.account.title = utils.out("candidat", "candidate");
                }
            });
            $scope.loaded = true;
        }

        function accountChoice(id) {
            $rootScope.chosenAccount = id;
            $scope.loaded = false;
            const authenticationMethod = $scope.providerParam || $scope.idpParam || null;
            authService.refreshToken($rootScope.chosenAccount, authenticationMethod).then(function (res) {
                var refreshResponse = res.data;
                if (refreshResponse.status == 'success') {
                    authService.saveToken(refreshResponse.data.token);
                    userAccountsService.setCurrentUserAccount(refreshResponse);
                    $scope.userCanLogin = true;
                    $scope.loaded = true;
                    loginRedirect();
                }
                else {
                    switch (refreshResponse.message) {
                        case 'Account has not been activated yet.' :
                            createUserMessage("<p>" + utils.out("Ce compte est inactif", "This account is inactive" + "</p>"));
                            $scope.loaded = true;
                            break;
                        case 'Provided account_id is invalid.' :
                            createUserMessage("<p>" + utils.out("Ce compte est inactif", "This account is inactive" + "</p>"));
                            $scope.loaded = true;
                            break;
                    }
                    // @todo still need to handle expired account case
                    // message to user - we are not able to log you in with this account
                }
            }).catch(function (error) {
                createUserMessage("<p>" + utils.out("Ce compte est inactif", "This account is inactive" + "</p>"));
                $scope.loaded = true;
            });
        }

        function loginRedirect() {
            // all window redirect are there for refreshing and get current user data
            const redirectParam = storageService.getItem('redirect_to');
            if (redirectParam) {
                storageService.removeItem('redirect_to');
                window.location = `${window.appConfig.ATLAS_UI_URL}${redirectParam}`;
            } else if($scope.redirect_url) {
                switch($scope.redirect_url) {
                    case 'pendingquestionnaires' :
                        window.location = window.appConfig.ATLAS_UI_URL + 'candidate/pending-questionnaires';
                        break;
                    case 'referencerequest' :
                        window.location = window.appConfig.ATLAS_UI_URL + 'candidate/references';
                        break;
                    case 'interview-requests':
                        window.location = `${window.appConfig.ATLAS_UI_URL}interview-requests`;
                        break;
                    case 'candidate/interviews':
                        window.location = `${window.appConfig.ATLAS_UI_URL}candidate/interviews`;
                        break;
                    // no default
                }
            }
            else if ($state.current.name == 'jobsDescription') { // when you are already connected and you click on Apply
                window.location.reload();
            }
            else if ($state.current.name == "quickApply") {  // when you do login and want to go to job-apply                                              
                window.location = window.appConfig.ATLAS_UI_URL + 'work/' + $scope.post_name;
            }
            else if ($rootScope.account_type == 'company' || $rootScope.account_type == 'client' || $rootScope.account_type == 'agency') {
                window.location = window.appConfig.ATLAS_UI_URL + 'employer';
            }
            else if ($rootScope.account_type == 'candidate') {
                window.location = window.appConfig.ATLAS_UI_URL + 'candidate';
            }
            else if (!$rootScope.account_type) {
                alert(utils.out('Le compte n\'existe pas! SVP veuillez contacter support@workland.com', 'Account does not exist! Please contact support@workland.com'));
            }
            else if ($rootScope.account_type == 'seller') {
                window.location.href = window.appConfig.MARKETPLACE_UI_URL + 'marketplace/partner-dashboard';
            }
        }

        function loginAsAnotherUser() {
            authService.clearSessionData();
            $state.go("home");
        }
    }
})(angular);