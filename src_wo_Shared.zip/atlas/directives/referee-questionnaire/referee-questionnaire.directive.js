(function (angular) {
  function RefereeQuestionnaireCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    $stateParams,
    _,
    $timeout,
    userAccountsService,
    storageService,
  ) {
    const scope = {
      out: utils.out,
      alert: [],
      dateOptions: {
        'year-format': "'yy'",
        'starting-day': 1,
      },
      format: 'dd/MM/yyyy',
      language: $rootScope.language,
      answers: [],
      keyData: {},
      hasError: 0,
      initializationError: false,
      isReferee: true,
      enableFirstStep: false,
      showConsentMsg: false,
      enableQuestionnaire: false,
      enableNextQuestion: false,
      startQuestionnaire: false,
      questionnaireFilled: false,
      questionnairerefused: false,
      questionsWithoutAnswer: [],
      questionnaireEndFail: false,
      questionnaireEndPartialFail: false,
      questionnaireEndSuccess: false,
    };
    angular.extend($scope, scope);

    function getQuestionsWithoutAnswers(allAnswers, allQuestions) {
      let questions = _.filter(allQuestions, (question) => !question.is_tail);
      let indexesToSplice = [];
      if (allAnswers && allAnswers.length) {
        _.each(allAnswers, (answer) => {
          const index = _.findIndex(questions, (question) => +answer.questionnaire_question_id === +question.id);
          if (index > -1) {
            indexesToSplice.push(index);
          }
        });
        if (indexesToSplice.length) {
          indexesToSplice = _.uniq(indexesToSplice).sort((a, b) => b - a);
          _.each(indexesToSplice, (i) => {
            questions.splice(i, 1);
          });
        }
      }
      questions = _.sortBy(questions, 'rank');
      return questions;
    }

    function getQuestionnaireByToken() {
      api.service_get('toolkit', `reference/references/get-by-token/${$scope.keyData.key}`, {})
        .then((response) => {
          const res = response.data;
          if (res.status === 'success') {
            const results = res.data.result;
            $scope.questionnaireId = results.questionnaire_id;
            $scope.referenceAllData = results;
            $scope.refereeData = results.referee;
            $scope.questionsWithoutAnswer = getQuestionsWithoutAnswers(
              results.reference_answers,
              results.questionnaire.questionnaire_questions,
            );
            if ($scope.questionsWithoutAnswer.length) {
              $scope.enableFirstStep = true;
            } else {
              $scope.questionnaireFilled = true;
            }
          } else {
            $rootScope.api_status(
            	'alert-danger', 
            	'Please try again later or contact support@workland.com for assistance', 
            	'S\'il-vous-plaît veuillez réessayer plus tard ou contactez support@workland.com pour assistance', 
            	'An error has occurred', 
            	'Une erreur est survenue', 
            	7500);
            $scope.initializationError = true;
          }
        }).catch(() => {
          $rootScope.api_status(
          	'alert-danger', 
          	'Please try again later or contact support@workland.com for assistance', 
          	'S\'il-vous-plaît veuillez réessayer plus tard ou contactez support@workland.com pour assistance', 
          	'An error has occurred', 
          	'Une erreur est survenue', 
          	7500);
          $scope.initializationError = true;
        });
    }

    $scope.refuseToFillQuestionnaire = () => {
      $scope.enableFirstStep = false;
      $scope.questionnairerefused = true;
      api.toolkit_batch(`reference/references/refused/${$scope.referenceAllData.token}`, null, 'PUT').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          // @is it important to have a msg if the referee refuse.. ?
        } else {
          // @is it important to have a msg if the referee refuse.. ?
        }
      }).catch(() => {
          // @is it important to have a msg if the referee refuse.. ?
        });
    };

    function approveQuestionnaire() {
      api.toolkit_batch(`reference/references/approved/${$scope.referenceAllData.token}`, null, 'PUT').then((response) => {
        const res = response.data;
        if (res.status === 'success') {
          $scope.questionnaireEndSuccess = true;
        } else {
          $scope.questionnaireEndFail = true;
        }
      }).catch(() => {
          $scope.questionnaireEndFail = true;
          $rootScope.api_status(
          	'alert-danger', 
          	null, null, 
          	'An error has occurred', 
          	'Une erreur est survenue', 3500);
        });
    }

    $scope.showQuestionnaire = () => {
      $scope.enableFirstStep = false;
      $scope.enableQuestionnaire = true;
      $scope.startQuestionnaire = true;
    };

    $scope.showQuestion = () => {
      $scope.enableNextQuestion = false;
    };

    $scope.submitAnswers = () => {
      $rootScope.api_status(
      	'waiting',       	
      	'Nous sauvegardons votre questionnaire', 
      	'We are saving your questionnaire',
      	'Veuillez patienter...', 
      	'Please wait...', 
      	3500);
      const promises = [];
      const answersNumber = this.answers.length;
      _.each(this.answers, (answer) => {
        answer.reference_token = $scope.referenceAllData.token;
        delete answer.job_id;
        delete answer.type;
        promises.push(api.service_post('toolkit', 'reference/reference-answers', answer).then((response) => {
          const res = response.data;
          if (res.status !== 'success') {
            $scope.hasError += 1;
          }
        }).catch(() => {
            $scope.hasError += 1;
          }));
      });

      Promise.all(promises).then(() => {
        $scope.enableQuestionnaire = false;
        $scope.startQuestionnaire = false;
        if ($scope.hasError) {
          if ($scope.hasError < answersNumber) {
            $scope.questionnaireEndPartialFail = true;
          } else {
            $scope.questionnaireEndFail = true;
          }
        } else {
          approveQuestionnaire();
        }
      });
    };
    
    $scope.$on('menuLanguageSwitched', (evt, data) => {
      storageService.setItem('toggleLanguage', data);
    })    

    function init() {
      const { key } = $stateParams;
      if (key) {
        api.service_post('toolkit', 'reference/references/parse-link', { key })
          .then((response) => {
            const res = response.data;
            if (res.status === 'success') {
              $scope.keyData = res.data.result.data;
              if ($scope.keyData.lang && !storageService.getItem('toggleLanguage')) {
                	//override header language with a referee preferred language	
                  	$rootScope.language = $scope.language = $scope.keyData.lang;
                  	$scope.$broadcast('languageChanged', $rootScope.language);
              }
              if(storageService.getItem('toggleLanguage')) {
              	$rootScope.language = language = storageService.getItem('toggleLanguage');
              } 
              getQuestionnaireByToken();
            } else {
              $rootScope.api_status(
              	'alert-danger', 
              	'Please contact support@workland.com for assistance', 
              	'Veuillez contacter support@workland.com pour assistance', 
              	'The link provided is invalid', 'Le lien fourni est invalide', 
              	7500);
              $scope.initializationError = true;
            }
          }).catch(() => {
            $rootScope.api_status(
            	'alert-danger', 
            	'Please try again later or contact support@workland.com for assistance', 
            	'S\'il-vous-plaît veuillez réessayer plus tard ou contactez support@workland.com pour assistance', 
            	'An error has occurred', 'Une erreur est survenue', 
            	7500);
            $scope.initializationError = true;
          });
      }
    }
    init();

    $scope.$on('$destroy', () => {
    	storageService.removeItem('toggleLanguage');
    });
  }
  const app = angular.module('atlas');
  app.directive('refereeQuestionnaire', () => ({
    controller: RefereeQuestionnaireCtrl,
    templateUrl: './atlas/directives/referee-questionnaire/referee-questionnaire.template.html',
  }));
  app.controller('RefereeQuestionnaireCtrl', RefereeQuestionnaireCtrl);
  RefereeQuestionnaireCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '$stateParams',
    '_',
    '$timeout',
    'userAccountsService',
    'storageService',
  ];
}(angular));
