(function (angular) {
  function ClientLoginCtrl(
    $scope,
    $rootScope,
    api,
    _,
    utils,
    MetaTagsService,
    $location,
    $state,
    authService,
    $cookies,
    $stateParams,
    $anchorScroll,
    storageService,
    userAccountsService,
    $uibModal,
  ) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    $rootScope.openPanel = $stateParams.openPanel;
    let msgEn;
    let msgFr;
    const scope = {
      out: utils.out,
      registrationErrorMessage: false,
      userMustChooseAccount: false,
      userExistMessage: false,
      hasCandAccount: -1,
      activationLinkSent: false,
      activationLinkErrorMessage: false,
      redirect_url: '',
      imagesUrl: './../assets/images/',
      registerFormModel: {},
      statut: 'candidate',
      activationData: {},
      login,
      removeError,
      validateSubmit,
      checkUsername,
      checkFirstname,
      checkLastname,
      checkEmail,
      checkCompanyName,
      checkPhone,
      checkPassword,
      checkConfirmPassword,
      registerUser,
      clearRegisterForm,
      loginRedirect,
      goRegistrationStep2,
      initRegistration,
      sendNewActivationLink,
      init,
      applicationChat: [],
      postCatherineMsg,
      postCandidateMsg,
      trustAsHtml: utils.trustAsHtml,
      isedCallback,
      candidateQuestionnaire: [],
      errorIsedCallback,
      socialLogin,
      addPhoneNumberToProfile,
      resetPhoneInput,
      checkSocialLoginCredentials: false,
      socialConnection: null,
      socialConnectionLoader: false,
      hasPhone: true,
      missingParams: {
        phone: '',
      },
      addPhoneLoader: false,
      openSSOSection: false,
      openRegistrationSSOSection: false,
      domain: {
        name: '',
      },
      domainName: {
        name: '',
      },
      singleSignOnLogin,
      domainNameRequired: false,
      domainNameError: false,
      provider: {
        name: '',
      },
      toggleSSOSection,
      toggleRegistrationSSOSection,
      showDuplicatedLoginMsg: false,
      idpsList: [],
      openTermConditionModel,
      openSocialSignUpSection: false,
      toggleSocialSignUpSection,
      toggleSLSection,
      openSLSection: false,
      providerParam: '',
      idpParam: '',
    };
    angular.extend($scope, scope);

    function openTermConditionModel() {
      $scope.openTermModelInstance = $uibModal.open({
        animation: true,
        templateUrl: $scope.out('./atlas/directives/job-apply/modal-templates/terms-and-conditions-model-fr.template.html', './atlas/directives/job-apply/modal-templates/terms-and-conditions-model-en.template.html'),
        scope: $scope,
        size: 'lg',
      });
    }

    // copy-paste of email to the input during candidate registration
    $scope.paste = function (event) {
      const item = _.find(event.clipboardData.items, (item) => item.type === "text/plain");
      if (item) {
        item.getAsString((data) => {
          checkEmail(data, false);
        });
      }
    };

    function postCatherineMsg(msgEn, msgFr, extra) {
      $scope.msgObject = {
        msgBy: 'catherine',
        msgContentEn: msgEn,
        msgContentFr: msgFr,
        extra,
        msgDateTime: new Date(),
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function postCandidateMsg(text, isvalid, docAttached, docIndex) {
      $scope.msgObject = {
        msgBy: 'candidate',
        msgContent: text,
        msgDateTime: new Date(),
        isValid: isvalid,
        isDoc: docAttached,
        docIndex,
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function readAllQuestionnairesAttachedToCandidates() {
      $scope.candidateQuestionnaire = [];
      api.service_post('toolkit', 'questionnaire/agency-candidate-questionnaire/read-all', {
        agency_account_id: [$scope.agencyAccountId],
        is_active: true,
      }).then((response) => {
        angular.forEach(response.data, (questionnaire) => {
          $scope.candidateQuestionnaire.push(questionnaire);
        });
        msgEn = "Hello, my name is <b>Catherine</b>, I'm here to help you with your registration!";
        msgFr = "Bonjour, mon nom est <b>Catherine</b>, je suis là pour vous aider dans le processus de l'inscription!";
        postCatherineMsg(msgEn, msgFr);
      }).catch(() => {
        $scope.hasPreError = true;
        $scope.preErrorMsg = utils.out("Désolé, une erreur s'est produite lors de la récupération du questionnaire.", 'Sorry, there was an error while fetching questionnaire.');
        // should stop applying process
      });
    }

    function isedCallback() {
      $scope.catherineTyping = false;
      const { status } = $scope.newUserInfo.questionnaires;
      if (status === 'qualified') {
        msgEn = 'Excellent! Please check your email to finalize your registration.';
        msgFr = "Excellent! Merci de consulter vos courriels pour terminer l\'inscription.";
      } else {
        // @agency: add specific reasons for agencies
        msgEn = '<b>Thank you for your interest.</b>';
        msgFr = '<b>Merci de l’intérêt manifesté.</b>';
      }
      postCatherineMsg(msgEn, msgFr);
    }

    function getAgencyAccountIdByHash() {
      // @agency: add checks for state current name below to find out agency slug
      const stringUrl = $location.$$url;
      $scope.slug = stringUrl.replace(/^\/(\w+)\/?(\w+)?/g, '$1');
      $scope.slug = utils.removeAllURLParam($scope.slug);

      if ($scope.slug) {
        return api.service_get('accounts', `accounts/profiles/by-slug/${$scope.slug}`)
          .then((response) => {
            if (response.data) {
              $scope.agencyAccountId = response.data.data.account_id;
            }
          }).then(() => {
            if ($scope.agencyAccountId !== 0) {
              readAllQuestionnairesAttachedToCandidates();
            }
          }).catch(() => {
            // no agency id error!
            $scope.hasPreError = true;
            $scope.preErrorMsg = utils.out("Désolé, une erreur s'est produite. Veuillez réessayer.", 'Sorry, there was an error. Please try again.');
          });
      }
    }

    function toggleSSOSection() {
      $scope.openSSOSection = !$scope.openSSOSection;
      if (!$scope.openSSOSection) $scope.domain.name = '';
      if ($scope.openSLSection) {
        $scope.openSLSection = false;
        $scope.domainName.name = '';
      }    
    }

    function toggleSLSection() {      
      $scope.openSLSection = !$scope.openSLSection;
      if (!$scope.openSLSection) $scope.domainName.name = '';
      if ($scope.openSSOSection) {
        $scope.openSSOSection = false;
        $scope.domain.name = '';
      }
    }

    function toggleRegistrationSSOSection() {
      $scope.openRegistrationSSOSection = !$scope.openRegistrationSSOSection;
      $scope.openSocialSignUpSection = false;
      if (!$scope.openRegistrationSSOSection) {
        $scope.domain.name = '';
      } else {
        $scope.step1 = true;
        $scope.step2 = false;
      }
    }

    function toggleSocialSignUpSection() {
      $scope.openSocialSignUpSection = !$scope.openSocialSignUpSection; 
      $scope.openRegistrationSSOSection = false;
    }

    function getSSOLoginHash(absUrl) {
      const regExp = /login=(.*)&idp/;
      return absUrl.match(regExp)[1];
    }

    function getIdpsList() {
      api.service_get('accounts', 'idps').then((response) => {
        if (response.data.status === 'success' && response.data.data) {
          $scope.idpsList = response.data.data;
        }
      });
    }

    function init() {
      const urlString = $location.$$search;
      $scope.redirect_url = urlString.redirect ? decodeURI(urlString.redirect) : urlString.redirectTo ? decodeURI(urlString.redirectTo) : false;
      // if user login with more than one account at the time, he is logged out from both accounts
      const duplicatedLogin = JSON.parse(storageService.getItem('duplicated_login'));
      if (duplicatedLogin) {
        $scope.showDuplicatedLoginMsg = true;
      }
      if (urlString.code || (urlString.login && urlString.idp)) {
        $scope.socialConnection = storageService.getItem('connection_action');
        $scope.checkSocialLoginCredentials = true;
        if (urlString.code) {
          socialLoginCallBack(urlString);
        } else {
          const originalLoginHash = getSSOLoginHash($location.$$absUrl);
          ssoLoginCallback(originalLoginHash, urlString.idp);
        }
        storageService.removeItem('connection_action');
      }
      $scope.agencyAccountId = 0;
      // @agency: add checks for agency cookies mode below
      if ($rootScope.agencyId) {
        $scope.stage = 'init';
        getAgencyAccountIdByHash();
      }
      if ($rootScope.openPanel === 'registration') {
        initRegistration();
      }
      getIdpsList();
    }

    init();

    function errorIsedCallback() {
      authService.logout();
      $state.go('home');
    }

    function addPhoneNumberToProfile() {
      $scope.addPhoneLoader = true;
      const regExp = /^\d?\s?[(]?\d{3}[-).]?\s?\d{3}[-. ]?\d{4}$/;
      const phoneValidated = regExp.test($scope.missingParams.phone);
      if (!phoneValidated) {
        $scope.phoneInvalid = true;
        $scope.addPhoneLoader = false;
        return;
      }

      storageService.setItem('user_phone', $scope.missingParams.phone);
      if ($scope.accounts.length > 1) {
        $state.go('accounts', { redirectUrl: $scope.redirect_url });
      } else {
        $scope.userCanLogin = true;
        loginRedirect();
      }
    }

    // START: Functions for login section

    function getDomainFromIdpList(userEmailDomain) {
      return _.find($scope.idpsList, (item) => item.domain === userEmailDomain);
    }

    function singleSignOnLogin(action) {
      removeError();
      if (!$scope.domain.name) {
        $scope.domainNameRequired = true;
        return;
      }

      const regExp = /@?([^@]+)$/;
      const userEmailDomain = $scope.domain.name.match(regExp);
      if (!userEmailDomain) {
        $scope.domainNameRequired = true;
        return;
      }

      let params = null;
      if (action === 'register') {
        params = {
          lang: $rootScope.language,
          role_id: 70,
        };
      }

      storageService.setItem('connection_action', action);
      const internalIdpDomain = getDomainFromIdpList(userEmailDomain[1]);
      if (internalIdpDomain) {
        $scope.provider.name = internalIdpDomain.name.toUpperCase();
        api.service_get('accounts', `auth/saml2/${internalIdpDomain.name}/login`, params).then((response) => {
          if (response.status === 200 && response.data) {
            window.location = response.data;
          } else {
            $scope.socialLoginConnectionErrorMessage = true;
          }
        }).catch(() => {
          $scope.socialLoginConnectionErrorMessage = true;
        });
      } else {
        $scope.domainNameError = true;
      }
    }

    function socialLogin(action) {
      removeError();
      let params = {};
      if (action == 'register') {
        params = {
          lang: $rootScope.language,
          role_id: 70,
        };
      } 
      if ($scope.domainName.name) {
        params.domain_name = $scope.domainName.name;
      }
      
      storageService.setItem('connection_action', action);
      $scope.provider.name = 'Microsoft'; // currently not dynamic
      api.service_get('accounts', 'auth/social-login/microsoft', params).then((response) => {
        if (response.data.status === 'success') {
          window.location = response.data.data.link;
        } else {
          $scope.socialLoginRedirectionErrorMessage = true;
        }
      }).catch(() => {
        $scope.socialLoginRedirectionErrorMessage = true;
      });
    }

    function loginSetUp(loginResponse) {
      authService.saveToken(loginResponse.data.token);
      $rootScope.accounts = $scope.accounts = loginResponse.data.accounts ? loginResponse.data.accounts : [loginResponse.data.account];
      storageService.setItem('accounts', JSON.stringify($scope.accounts));
      if ($scope.accounts.length > 1) {
        // case where user has more than 1 account
        if ($scope.hasPhone) {
          $state.go('accounts', {
            redirectUrl: $scope.redirect_url,
            idpParam: $scope.idpParam,
            providerParam: $scope.providerParam
          });
        }
      } else {
        // case where user has only 1 account
        userAccountsService.setCurrentUserAccount(loginResponse);
        if ($scope.hasPhone) {
          $scope.userCanLogin = true;
          loginRedirect();
        }
      }
    }

    function socialLoginCallBack(urlParams) {
      $scope.socialConnectionLoader = true;
      $scope.provider.name = 'Microsoft'; // currently not dynamic
      api.service_get('accounts', 'auth/social-login/microsoft/callback', urlParams).then((response) => {
        const loginResponse = response.data;
        if (loginResponse && loginResponse.status == 'success') {
          $scope.hasPhone = loginResponse.data.has_phone;
          if (loginResponse.data?.microsoft_token) {
            const microsoftToken = _.pick(loginResponse.data.microsoft_token, 'access_token', 'exp', 'refresh_token', 'scope');
            if (loginResponse.data?.microsoft_organization_account_ids.length > 0) {
              microsoftToken.microsoft_organization_account_ids = loginResponse.data.microsoft_organization_account_ids;
            }
            $scope.providerParam = `${$scope.provider.name} - OAuth`;
            storageService.setCookie('microsoftToken', JSON.stringify(microsoftToken));
          }
          if (loginResponse.data?.atlas_microsoft_token) {
            storageService.setCookie('atlasMicrosoftToken', loginResponse.data.atlas_microsoft_token);
          }
          loginSetUp(loginResponse);
        } else {
          $scope.socialLoginConnectionErrorMessage = true;
          $scope.checkSocialLoginCredentials = false;
        }
        $scope.socialConnectionLoader = false;
      }).catch((err) => {
        switch (err.status) {
          case 400:
            if (err.data && err.data.message && err.data.message == 'an_account_of_this_type_already_exists') {
              $scope.accountAlreadyExistErrorMessage = true;
            } else {
              $scope.microsoftRedirectErrorMessage = true;
            }
            break;
          case 404:
            if (err.data && err.data.message && err.data.message == 'user_not_found') {
              $scope.noAccountMessage = true;
            } else if (err.data && err.data.message && err.data.message == 'no_active_account_found') {
              $scope.noActiveAccountErrorMessage = true;
            }
            break;
          default:
            if (err.data && err.data.message && err.data.message.match('failed_to_create')) {
              $scope.socialLoginRegistrationErrorMessage = true;
            } else {
              $scope.socialLoginConnectionErrorMessage = true;
            }
        }
        $scope.checkSocialLoginCredentials = false;
        $scope.socialConnectionLoader = false;
      });
    }

    function ssoLoginCallback(loginHash, idp) {
      if (loginHash) {
        $scope.socialConnectionLoader = true;
        const data = { login_hash: loginHash };
        $scope.provider.name = idp.toUpperCase();
        const existingLoginHashCookie = $cookies.get("loginHash");
        if (existingLoginHashCookie) $cookies.remove("loginHash");
        const inFiveMinutes = new Date(new Date().getTime() + 5 * 60 * 1000);
        $cookies.put("loginHash", loginHash, { "expires": inFiveMinutes });
        api.service_post('accounts', `auth/saml2/${idp}/userLogin`, data).then((response) => {
          const loginResponse = response;
          if (loginResponse.status === 200 && loginResponse.data) {
            $scope.hasPhone = loginResponse.data.has_phone;
            $scope.idpParam = `${idp.charAt(0).toUpperCase() + idp.slice(1)} - SAML`;
            loginSetUp(loginResponse);
          } else {
            $scope.socialLoginConnectionErrorMessage = true;
            $scope.checkSocialLoginCredentials = false;
          }
          $scope.socialConnectionLoader = false;
        }).catch((err) => {
          switch (err.status) {
            case 400:
              if (err.data && err.data.message && err.data.message == 'an_account_of_this_type_already_exists') {
                $scope.accountAlreadyExistErrorMessage = true;
              }
              break;
            case 403:
              if (err.data && err.data.message && err.data.message == 'url_hash_expired') {
                $scope.ssoUrlHashExpired = true;
              }
              break;
            case 404:
              if (err.data && err.data.message && err.data.message == 'user_not_found') {
                $scope.noAccountMessage = true;
              } else if (err.data && err.data.message && err.data.message == 'no_active_account_found') {
                $scope.noActiveAccountErrorMessage = true;
              }
              break;
            default:
              if (err.data && err.data.message && err.data.message.match('failed_to_create')) {
                $scope.socialLoginRegistrationErrorMessage = true;
              } else if (err.data && err.data.message && err.data.message == 'invalid_url_hash') {
                $scope.ssoUrlHashInvalid = true;
              } else {
                $scope.socialLoginConnectionErrorMessage = true;
              }
          }
          $scope.checkSocialLoginCredentials = false;
          $scope.socialConnectionLoader = false;
        });
      } else {
        $scope.ssoUrlHashInvalid = true;
      }
    }

    function login() {
      $rootScope.quickRegistered = $stateParams.quickRegisteredUser;
      removeError();
      if (!$scope.username) {
        $scope.usernameRequired = true;
      }
      if (!$scope.password) {
        $scope.passwordRequired = true;
      }
      let allowedToRegularLogin = true;
      if ($scope.username) {
        const regExp = /@?([^@]+)$/;
        const userEmailDomain = $scope.username.match(regExp);
        const internalIdpsDomain = userEmailDomain ? getDomainFromIdpList(userEmailDomain[1]) : userEmailDomain;
        if (internalIdpsDomain) {
          allowedToRegularLogin = false;
          $scope.provider.name = internalIdpsDomain.name.toUpperCase();
          $scope.ssoLoginRequired = true;
          $scope.passwordRequired = false;
        }
      }

      if ($scope.username && $scope.password && allowedToRegularLogin) {
        $scope.checkLoginCredentials = true;
        $scope.credentials = {
          email: $scope.username,
          password: $scope.password,
        };

        authService.login($scope.credentials).then((res) => {
          $scope.checkLoginCredentials = false;
          const loginResponse = res.data;
          if (loginResponse && loginResponse.status == 'success') {
            loginSetUp(loginResponse);
          }
        }).catch((err) => {
          if (err.data && err.data.code == 403) {
            $scope.forbiddenErrorMessage = true;
          } else if (err.data && err.data.code == 401 && err.data.message) {
            switch (err.data.message) {
              case 'wrong_credentials': // Wrong password
                $scope.loginErrorMessage = true;
                break;
              case 'account_locked_login_attempts': // too many login attempts
                $scope.loginAttemptsErrorMessage = true;
                break;
              default:
                $scope.connectionErrorMessage = true;
            }
          } else if (err.data && err.data.code == 404 && err.data.message) {
            switch (err.data.message) {
              case 'no_active_account_found': // Multiple accounts , none active
                $scope.accountExpiredMessage = true;
                break;
              case 'account_has_not_been_activated_yet': // candidate account not activated
                $scope.emailConfirmationErrorMessage = true;
                break;
              case 'disqualified_by_registration_questionnaire': // client account disqualified
                $scope.disqualifiedByRegistrationQuestionnaireMessage = true;
                break;
              default:
                $scope.connectionErrorMessage = true;
            }
          } else {
            $scope.connectionErrorMessage = true;
          }
          $scope.checkLoginCredentials = false;
        });
      }
    }

    function loginRedirect() {
      // all window redirect are there for refreshing and get current user data
      const redirectParam = storageService.getItem('redirect_to');
      if (redirectParam) {
        storageService.removeItem('redirect_to');
        window.location = `${window.appConfig.ATLAS_UI_URL}${redirectParam}`;
      } else if ($rootScope.first_login && $rootScope.quickRegistered) {
        window.location = `${window.appConfig.ATLAS_UI_URL}password-first-login`;
      } else if ($scope.redirect_url) {
        switch ($scope.redirect_url) {
          case 'pendingquestionnaires':
            window.location = `${window.appConfig.ATLAS_UI_URL}candidate/pending-questionnaires`;
            break;
          case 'referencerequest':
            window.location = `${window.appConfig.ATLAS_UI_URL}candidate/references`;
            break;
          case 'interview-requests':
            window.location = `${window.appConfig.ATLAS_UI_URL}interview-requests`;
            break;
          case 'candidate/interviews':
            window.location = `${window.appConfig.ATLAS_UI_URL}candidate/interviews`;
            break;
          // no default
        }
      } else if ($state.current.name == 'jobsDescription') { // when you are already connected and you click on Apply
        window.location.reload();
      } else if ($state.current.name == 'quickApply') { // when you do login and want to go to job-apply
        window.location = `${window.appConfig.ATLAS_UI_URL}work/${$scope.post_name}`;
      } else if ($rootScope.account_type == 'company' || $rootScope.account_type == 'client' || $rootScope.account_type == 'agency') {
        window.location = `${window.appConfig.ATLAS_UI_URL}employer`;
      } else if ($rootScope.account_type == 'candidate') {
        window.location = `${window.appConfig.ATLAS_UI_URL}candidate`;
      } else if ($rootScope.account_type == 'seller') {
        window.location.href = `${window.appConfig.MARKETPLACE_UI_URL}marketplace/partner-dashboard`;
      } else if (!$rootScope.account_type) {
        alert(utils.out('Le compte n\'existe pas! SVP contactez support@workland.com', 'Account does not exist! Please contact support@workland.com'));
      }
    }

    function removeError() {
      if ($scope.username) {
        $scope.usernameRequired = false;
        $scope.ssoLoginRequired = false;
      }
      if ($scope.password) {
        $scope.passwordRequired = false;
      }
      if ($scope.domain.name) {
        $scope.domainNameRequired = false;
        $scope.domainNameError = false;
      }
      $scope.loginErrorMessage = false;
      $scope.loginAttemptsErrorMessage = false;
      $scope.emailConfirmationErrorMessage = false;
      $scope.accountExpiredMessage = false;
      $scope.noAccountMessage = false;
      $scope.forbiddenErrorMessage = false;
      $scope.connectionErrorMessage = false;
      $scope.inactivatedAccountMessage = false;
      $scope.invalidAccountIdMesssage = false;
      $scope.activationLinkSent = false;
      $scope.activationLinkErrorMessage = false;
      $scope.activationLinkErrorMessage = false;
      $scope.disqualifiedByRegistrationQuestionnaireMessage = false;
      $scope.accountAlreadyExistErrorMessage = false;
      $scope.microsoftRedirectErrorMessage = false;
      $scope.noActiveAccountErrorMessage = false;
      $scope.socialLoginConnectionErrorMessage = false;
      $scope.socialLoginRedirectionErrorMessage = false;
      $scope.socialLoginRegistrationErrorMessage = false;
      $scope.ssoUrlHashExpired = false;
      $scope.ssoUrlHashInvalid = false;
      $scope.ssoRegistrationRequired = false;
      $scope.provider.name = '';
      $scope.showDuplicatedLoginMsg = false;
    }
    // END: Functions for login section

    // START: Functions for registration section
    function initRegistration() {
      clearRegisterForm();
      $scope.proceedToRegister = false;
      $scope.step1 = true;
      $scope.step2 = false;
    }

    function checkStatus() {
      $scope.noStatusError = false;
      if ($scope.statut != 'candidate') {
        $scope.noStatusError = true;
        return false;
      }
      return true;
    }

    // @in progress
    function goRegistrationStep2() {
      $scope.openSocialSignUpSection = false;
      $scope.openRegistrationSSOSection = false;
      removeError();
      checkEmail(null, false);
      if (checkStatus()) {
        $scope.registrationConnectionErrorMessage = false;
        if (!$scope.emailNotValidated && !$scope.emailEmpty && !$scope.ssoRegistrationRequired) {
          const data = {
            email: $scope.registerFormModel.email,
            type: 'candidate',
          };
          api.service_post('accounts', 'accounts/find', data).then((res) => {
            if (res.data.status == 'success') {
              $scope.hasCandAccount = 0;
              if (Object.keys(res.data.data).length > 0) { // user found
                if (res.data.data.account_id) { // has candidate account
                  if (res.data.data.account_status === 'activated') { // active candidate account
                    $scope.hasCandAccount = 1;
                  } else { // inactive candidate account
                    $scope.hasCandAccount = 2;
                    $scope.accountIdToActivate = res.data.data.account_id;
                  }
                } else { // registered user but not a candidate
                  $scope.isNewUser = false;
                  $scope.step2 = false;
                  $scope.existingUserId = res.data.data.user_id;
                }
              } else { // no registered user
                $scope.isNewUser = true;
                $scope.step2 = true;
              }
              $scope.step1 = false;
            } else {
              $scope.registrationConnectionErrorMessage = true; // @todo check error
            }
          }).catch((err) => {
            if (err.data && err.data.error.status_code != 200) {
              $scope.registrationConnectionErrorMessage = true;
            }
          });
        } else {
          $scope.step2 = false;
          $scope.step1 = true;
        }
      }
    }

    function sendNewActivationLink() {
      $scope.accountAlreadyActivated = false;
      authService.getActivationKey($scope.accountIdToActivate, {
        language: $rootScope.language,
      }).then((res) => {
        if (res.data.status === 'success' && res.data.code === 201) {
          $scope.activationLinkSent = true;
          $scope.proceedToRegister = true;
          $scope.registrationComplete = true;
        }
        if (res.data.code === 200) {
          // This candidate is already activated
          $scope.accountAlreadyActivated = true;
        }
      }).catch(() => {
        $scope.activationLinkErrorMessage = true;
      });
    }

    function validateSubmit() {
      $scope.proceedToRegister = true;
      $scope.stopRegistration = false;
      $scope.registrationConnectionErrorMessage = false;
      checkEmail(null, true);

      if ($scope.isNewUser) {
        checkUsername();
        checkFirstname();
        checkLastname();
        checkPhone();
        checkPassword();
        checkConfirmPassword();
      }

      if (!$scope.stopRegistration) {
        registerUser();
      } else {
        $scope.proceedToRegister = false;
      }
    }

    // Registration Form Validation
    // @todo change for phone input
    function checkUsername() {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.user_login;
      }

      if (!$scope.registerFormModel.username) {
        $scope.usernameEmpty = true;
        $scope.stopRegistration = true;
      } else {
        $scope.usernameEmpty = false;
      }
    }

    function checkFirstname() {
      if (!$scope.registerFormModel.firstname) {
        $scope.firstnameEmpty = true;
        $scope.stopRegistration = true;
      } else {
        $scope.firstnameEmpty = false;
      }
    }

    function checkLastname() {
      if (!$scope.registerFormModel.lastname) {
        $scope.lastnameEmpty = true;
        $scope.stopRegistration = true;
      } else {
        $scope.lastnameEmpty = false;
      }
    }

    function checkEmail(data, keepStepState) {
      if (!keepStepState) {
        $scope.step1 = true;
        $scope.step2 = false;
      }

      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.user_email;
      }

      if (!$scope.registerFormModel.email && data) {
        $scope.registerFormModel.email = data;
      }

      const pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      $scope.ssoRegistrationRequired = false;
      if ($scope.registerFormModel.email) {
        $scope.emailEmpty = false;
        if (pattern.test($scope.registerFormModel.email)) {
          const regExp = /@?([^@]+)$/;
          const userEmailDomain = $scope.registerFormModel.email.match(regExp);
          const internalIdpsDomain = getDomainFromIdpList(userEmailDomain[1]);
          if (internalIdpsDomain) {
            $scope.provider.name = internalIdpsDomain.name.toUpperCase();
            $scope.ssoRegistrationRequired = true;
            $scope.stopRegistration = true;
          }
          $scope.emailNotValidated = false;
        } else {
          $scope.emailNotValidated = true;
          $scope.stopRegistration = true;
        }
      } else {
        $scope.emailNotValidated = false;
        $scope.emailEmpty = true;
        $scope.stopRegistration = true;
      }
    }

    function checkCompanyName() {
      if (!$scope.registerFormModel.companyName) {
        $scope.companynameEmpty = true;
        $scope.stopRegistration = true;
      } else {
        $scope.companynameEmpty = false;
      }
    }

    function resetPhoneInput() {
      $scope.phoneInvalid = false;
    }

    function checkPhone() {
      $scope.phoneInvalid = false;
      if (!$scope.registerFormModel.phone) {
        $scope.phoneInvalid = true;
        $scope.stopRegistration = true;
      } else {
        $scope.phoneInvalid = false;
        const areaCode = $scope.registerFormModel.phone.slice(0, 3);
        const midCode = $scope.registerFormModel.phone.slice(3, 6);
        const lastCode = $scope.registerFormModel.phone.slice(6, 10);
        if ($scope.registerFormModel.phone.length == 10) {
          $scope.registerFormModel.phone = `(${areaCode}) ${midCode}-${lastCode}`;
        }
      }
    }

    function checkPassword() {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.password;
      }

      const pattern = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
      if ($scope.registerFormModel.userPassword) {
        $scope.passwordEmpty = false;
        if (pattern.test($scope.registerFormModel.userPassword)) {
          $scope.passwordNotValid = false;
        } else {
          $scope.passwordNotValid = true;
          $scope.stopRegistration = true;
        }
      } else {
        $scope.passwordNotValid = false;
        $scope.passwordEmpty = true;
        $scope.stopRegistration = true;
      }
    }

    function checkConfirmPassword() {
      if ($scope.registrationErrors) {
        delete $scope.registrationErrors.password_confirmation;
      }

      if ($scope.registerFormModel.confirmUserPassword) {
        $scope.confirmPasswordEmpty = false;
        if ($scope.registerFormModel.userPassword === $scope.registerFormModel.confirmUserPassword) {
          $scope.passwordNotMatch = false;
        } else {
          $scope.passwordNotMatch = true;
          $scope.stopRegistration = true;
        }
      } else {
        $scope.passwordNotMatch = false;
        $scope.confirmPasswordEmpty = true;
        $scope.stopRegistration = true;
      }
    }

    // @in progress
    // Call Registration API After All Front end Validation
    function registerUser() {
      $scope.registrationErrors = false;
      if ($scope.isNewUser) {
        $scope.data = {
          email: $scope.registerFormModel.email,
          username: $scope.registerFormModel.username,
          password: $scope.registerFormModel.userPassword,
          first_name: $scope.registerFormModel.firstname,
          last_name: $scope.registerFormModel.lastname,
          phone: $scope.registerFormModel.phone,
          language: $rootScope.language,
          owner_account_ids: [$scope.agencyAccountId],
          // @todo - not integrated
          terms_and_conditions: true, // not mandatory?
        };
      } else if (!$scope.isNewUser) {
        $scope.data = {
          user_id: $scope.existingUserId,
        };
        $scope.userEmail = $scope.registerFormModel.email;
      }

      if ($scope.statut != 'candidate') {
        return;
      }
      $scope.usernameAlreadyTaken = false;
      authService.registerCandidate($scope.data).then((res) => {
        if (res.data.status == 'success') {
          $scope.registrationComplete = true;
          $scope.userExistMessage = false;
          $scope.registrationErrorMessage = false;
          clearRegisterForm();
          // $scope.user = { ID: res.data.user_id };
          // @agency: add checks for agency cookies mode below
          if ($rootScope.agencyId) {
            $scope.newUserInfo = {
              id: res.data.data.user.id,
              account_id: res.data.data.account.id,
              account_role: 70,
              account_type: 'candidate',
              email: res.data.data.user.email,
            };
            $scope.stage = 'openIsed';
            $scope.worklandAvatar = './../assets/images/lady.svg';
          }
        }
      }).catch((err) => {
        const error = err.data;
        if (error.error) {
          $scope.registrationErrors = err.data.error.errors;
        }
        if (err.data.message === 'username_is_already_taken') {
          $scope.usernameAlreadyTaken = true;
        } else {
          // general error message
          $scope.registrationConnectionErrorMessage = true;
        }
        $scope.proceedToRegister = false;
        $scope.registerFormModel.userPassword = '';
        $scope.registerFormModel.confirmUserPassword = '';
      });
    }

    function clearRegisterForm() {
      $scope.registerFormModel = {};
      $scope.status = {};
      $scope.errors = {};
      $scope.flags = {};
      $scope.notValidated = true;
    }
    // END: Functions for registration section

    function scrollToBottom() {
      $location.hash('bottom');
      $anchorScroll();
    }
  }
  ClientLoginCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    '_',
    'utils',
    'MetaTagsService',
    '$location',
    '$state',
    'authService',
    '$cookies',
    '$stateParams',
    '$anchorScroll',
    'storageService',
    'userAccountsService',
    '$uibModal',
  ];
  const app = angular.module('atlas');
  app.directive('clientLogin', () => ({
    scope: {
      jobId: '=',
    },
    controller: ClientLoginCtrl,
  }));
  app.controller('ClientLoginCtrl', ClientLoginCtrl);
}(angular));
