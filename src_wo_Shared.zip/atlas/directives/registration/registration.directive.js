(function (angular) {
  function RegistrationCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    $location,
  ) {
    $scope.out = utils.out;
    const scope = {
      out: utils.out,
      language: $rootScope.language,     
      successActivationMessage: false,
    };
    angular.extend($scope, scope);
    function init() {
      $scope.loading = true;
      $scope.checked = false;
      $scope.errorMessage = false;
      $scope.invalidKeyMessage = false;
      $scope.expiredKeyMessage = false;
      $scope.connectionFailMessage = false;
      const queryString = $location.$$search;
      const url = decodeURI(queryString.key);
      var params = {};
      if (queryString.account_id) {
        params.account_id = queryString.account_id
      }
      api.service_post('accounts', `accounts/activation/key/${url}`, params, 'update').then((res) => {
        $scope.loading = false;
        $scope.quickRegistered = (res.data.data.was_quick_registered === false || !res.data.data.was_quick_registered) ? 0 : 1;  
      }).catch((error) => {
        $scope.loading = false;
        $scope.errorMessage = true;
        switch (error.data.message) {
            case 'invalid_activation_key':
              $scope.invalidKeyMessage = true;
              break;
            case 'expired_activation_key':
              $scope.expiredKeyMessage = true;
              break;
            default:
              $scope.connectionFailMessage = true;
          }
      });
    }
    init();
  }
  RegistrationCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '$location',
  ];
  angular.module('atlas')
    .controller('RegistrationCtrl', RegistrationCtrl);
}(angular));
