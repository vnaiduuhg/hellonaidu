(function (angular) {
  function PaymentGatewayCtrl(
    $scope,
    api,
    utils,
    transferer,
    $rootScope,
    $uibModal,
    $location,
    $state,
    $stateParams,
    authService,
    storageService,
    marketplaceService,
    $window,
    $sce,
    $anchorScroll,
    $ngConfirm,
    userAccountsService,
    $timeout,
  ) {
    const regex = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
    let scope = {
      applicationChat: [],
      trustAsHtml: utils.trustAsHtml,
      loading: false,
      selectedLocation: {},
    };
    angular.extend($scope, scope);
    $scope.out = utils.out;
    $scope.productPrice = 0;
    let msgEn;
    let msgFr;

    function errorIsedCallback() {
      authService.logout();
      $state.go('home');
    }

    function exitPayment() {
      $ngConfirm({
        title: '',
        type: 'blue',
        content: utils.out('Êtes-vous sûr de vouloir quitter?', 'Are you sure you want to exit?'),
        buttons: {
          Yes: {
            text: utils.out('Oui', 'Yes'),
            btnClass: 'btn btn-secondary float-end',
            action() {
              location.reload();
            },
          },
          cancel: {
            text: utils.out('Non', 'No'),
            btnClass: 'btn btn-alt-secondary float-end',
            keys: ['enter', 'shift'],
          },
        },
      });
    }

    function showRegistrationError(errorMessage) {
      $ngConfirm({
        icon: 'fa fa-exclamation',
        title: utils.out('Erreur', 'Error'),
        content: errorMessage,
        type: 'red',
        typeAnimated: true,
        animation: 'RotateX',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn btn-secondary',
            action() {
              $scope.exitPayment();
            },
          },
        },
      });
    }

    function calculateAmountPayable() {
      $scope.payable = $scope.currentPackage.price;
      $scope.subtotal = 0;
      if ($scope.payable > 0) {
        angular.forEach($scope.taxes, (tax, key) => {
          if (tax.type == 0) { // percent
            $scope.subtotal = Math.round($scope.subtotal + ($scope.payable * tax.amount) / 100);
          } else { // fixed
            if ($scope.currentPackage.is_recurring) {
              $scope.subtotal += Math.round($scope.payable + tax.amount / $scope.currentPackage.number_of_payments);
            } else {
              $scope.subtotal = Math.round($scope.subtotal + tax.amount * 100); // convert to cents as package price in in cents
            }
          }
        });
      }
      $scope.total = $scope.payable + $scope.subtotal;
    }

    // functions for Agency candidates to show default questionnaires attached to the registration
    function scrollToBottom() {
      $location.hash('bottom');
      $anchorScroll();
    }

    function postCatherineMsg(mesgEn, mesgFr, extra) {
      $scope.msgObject = {
        msgBy: 'catherine',
        msgContentEn: mesgEn,
        msgContentFr: mesgFr,
        extra,
        msgDateTime: new Date(),
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function postCandidateMsg(text, isvalid, docAttached, docIndex) {
      $scope.msgObject = {
        msgBy: 'candidate',
        msgContent: text,
        msgDateTime: new Date(),
        isValid: isvalid,
        isDoc: docAttached,
        docIndex,
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function readAllQuestionnairesAttachedToClients() {
      $scope.clientQuestionnaire = [];
      api.service_post('toolkit', 'questionnaire/agency-client-questionnaire/read-all', {
        agency_account_id: [$scope.agencyAccountId],
        is_active: true,
      }).then((response) => {
        angular.forEach(response.data, (questionnaire) => {
          $scope.clientQuestionnaire.push(questionnaire);
        });
        msgEn = "Hello, my name is <b>Catherine</b>, I'm here to help you with your registration! Please answer some mandatory questions.";
        msgFr = "Bonjour, mon nom est <b>Catherine</b>, je suis là pour vous aider dans le processus de l'inscription! Veuillez répondre à certaines questions obligatoires.";
        postCatherineMsg(msgEn, msgFr);
      }).catch(() => {
        $scope.hasPreError = true;
        $scope.hasPreError = utils.out("Désolé, une erreur s'est produite lors de la récupération du questionnaire.", 'Sorry, there was an error while fetching questionnaire.');
        // should stop applying process
      });
    }

    function isedCallback() {
      $scope.catherineTyping = false;
      const { status } = $scope.newUserInfo.questionnaires;
      if (status === 'qualified') {
        msgEn = 'Great! Your registration request was successfully sent! You can now log into your new account by clicking the button below';
        msgFr = "Super! Votre demande d'inscription a été effectuée avec succès! Vous pouvez desormais vous connecter à votre nouveau compte en cliquant sur le bouton suivant";
        $scope.questionnaireAnswered = true;
      } else {
        // @agency: can add specific reasons for other agencies when they will have them
        msgEn = '<b>Thank you for your interest.</b>';
        msgFr = '<b>Merci de l’intérêt manifesté.</b>';
      }
      postCatherineMsg(msgEn, msgFr);
    }

    function getLocationId(data) {
      const location = [];
      location.push(utils.setLocationObject(data));
      return api.service_post('shared', 'location', { locations: location }).then((response) => {
        const res = response.data;
        if (res.length) {
          $scope.purchaseDetails.location_id = response.data[0].id;
          $scope.locationId = response.data[0].id;
        } else {
          $scope.afterRegisterMsg = '';
          showRegistrationError(utils.out('Une erreur est survenue lors de votre inscription, veuillez contacter notre équipe de soutien pour plus d\'informations',
            'There was an error during your registration. Please contact our support team for further assistance'));
        }
      }).catch(() => {
        $scope.afterRegisterMsg = '';
        showRegistrationError(utils.out('Une erreur est survenue lors de votre inscription, veuillez contacter notre équipe de soutien pour plus d\'informations',
          'There was an error during your registration. Please contact our support team for further assistance'));
      });
    }

    function initCardElement() {
      const stripe = Stripe($scope.stripePublicKey);
      const elements = stripe.elements();
      const style = {
        base: {
          '::placeholder': {
            color: '#78728a',
          },
        },
        invalid: {
          color: '#b3211b',
          iconColor: '#b3211b',
        },
      };

      const card = elements.create('card', { style });
      card.mount('#card-element');

      card.addEventListener('change', (event) => {
        const displayError = angular.element(document.getElementById('card-errors'));
        if (event.error) {
          displayError.text(event.error.message);
          displayError.addClass('alert alert-danger');
        } else {
          displayError.text('');
          displayError.removeClass('alert alert-danger');
        }
      });

      $scope.submitRegistrationInfo = function () {
        // @agency: add conditions for other agencies as well
        if ($rootScope.agencyId) {
          $scope.loading = true;
        }
        stripe.createToken(card).then((result) => {
          if (result.error) {
            // Inform the customer that there was an error.
            const errorElement = angular.element(document.getElementById('card-errors'));
            errorElement.text(result.error.message);
            errorElement.addClass('alert alert-danger');
            $scope.loading = false;
          } else {
            $scope.afterRegisterMsg = '1';

            $scope.purchaseDetails = {};
            if ($scope.user_id) {
              $scope.purchaseDetails.user_id = $scope.user_id;
            } else {
              $scope.purchaseDetails.email = $scope.email;
              $scope.purchaseDetails.username = $scope.username;
              $scope.purchaseDetails.password = $scope.password;
              $scope.purchaseDetails.first_name = $scope.firstName;
              $scope.purchaseDetails.last_name = $scope.lastName;
              $scope.purchaseDetails.language = $rootScope.language;
            }
            $scope.purchaseDetails.phone = $scope.contact ? $scope.contact : $scope.companyPhone;

            $scope.purchaseDetails.agency_account_id = $scope.agencyAccountId;
            $scope.purchaseDetails.source = result.token.id;
            $scope.purchaseDetails.email_updates_flag = $scope.emailUpdate;
            $scope.purchaseDetails.company_name = $scope.companyname;
            $scope.purchaseDetails.product_id = $scope.currentPackage.id;
            $scope.purchaseDetails.account_type_id = $scope.currentPackage.account_type_id;

            $scope.purchaseDetails.location_id = 0;
            $scope.purchaseDetails.website_link = $scope.companyWebsite;
            $scope.purchaseDetails.linkedin_link = $scope.companyLinkedin;
            $scope.purchaseDetails.fb_link = $scope.companyFacebook;
            $scope.purchaseDetails.twitter_link = $scope.companyTwitter;

            return getLocationId($scope.selectedLocation).then(() => {
              marketplaceService.payByCard($scope.purchaseDetails).then((res) => {
                // @agency: add conditions for other agencies as well
                if ($rootScope.agencyId) {
                  $scope.loading = false;
                  $scope.newUserInfo = {
                    id: res.data.user.id,
                    account_id: res.data.account.id,
                    account_role: 40,
                    account_type: res.data.account.type,
                    email: res.data.user.email,
                  };
                  $scope.stage = 'openIsed';
                  $scope.worklandAvatar = './../assets/images/lady.svg';
                }
                // @agency: can add condition for agency to show specific message
                $scope.afterRegisterMsg = '3';
                $scope.credentials = {
                  email: $scope.username,
                  password: $scope.password,
                };
                $scope.loading = false;
              }).catch(() => {
                $scope.afterRegisterMsg = '';
                showRegistrationError(utils.out('Une erreur est survenue lors de votre inscription, veuillez contacter notre équipe de soutien pour plus d\'informations',
                  'There was an error during your registration. Please contact our support team for further assistance'));
                $scope.loading = false;
              });
            });
          }
        }).catch(() => {
          $scope.loading = false;
        });
      };
    }

    function init() {
      // google places autocomplete for company address
      $timeout(() => {
        const input = document.getElementById('company-address-input');
        const autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.setFields(['address_components', 'geometry', 'place_id']);
        autocomplete.addListener('place_changed', () => {
          const place = autocomplete.getPlace();
          $scope.selectedLocation = place;
        });
      }, 300);

      $scope.currentStep = 0;
      $scope.paymentMethod = 0;
      $scope.paymentEmailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      $scope.paymentPhoneFormat = /^\d{3}[- ]?\d{3}[- ]?\d{4}$/; // format xxx-xxx-xxxx or xxxxxxxxxx
      $scope.user_id = null;
      $scope.agency = {};
      $scope.emailUpdate = '0';
      $scope.currentPackage = transferer.getData();
      $scope.agencyAccountId = $scope.currentPackage.account_id;
      $scope.activeCharitiesList = [];
      if (!$scope.agencyAccountId) {
        window.history.go(-2); // @agency: redirect to packages page of the right agency
      } else {
        $scope.stripePublicKey = window.appConfig.STRIPE_PUBLIC_KEY;
        initCardElement();
        if ($scope.agencyAccountId !== null) {
          readAllQuestionnairesAttachedToClients();
          api.service_get('marketplace', `account/${$scope.agencyAccountId}/taxes`).then((response) => {
            $scope.taxes = response.data;
            if (!$scope.taxes.length) {
              $scope.noTax = true;
            }
            // else {
            calculateAmountPayable();
            // }
          }).catch(() => {
            // not able to fetch taxes error
            $ngConfirm({
              title: $scope.out('Erreur', 'Error'),
              type: 'red',
              content: utils.out("Désolé, une erreur s'est produite. Veuillez réessayer.",
                'Sorry, there was an error. Please try again.'),
              buttons: {
                Ok: {
                  text: $scope.out('Ok', 'Ok'),
                  btnClass: 'btn btn-secondary',
                },
              },
            });
          });
        }
      }

      $scope.isRegisteredUser = true;
      $scope.hasActiveCandAccount = true;
      $scope.isThisAgencyClient = false;
      $scope.nextBtn = true;
      $scope.useAnotherEmail = false;
      $scope.MARKETPLACE_UI_URL = window.appConfig.MARKETPLACE_UI_URL;
      // @agency: add conditions for agencies
      if ($rootScope.agencyId) {
        $scope.stage = 'init';
      }
    }
    init();

    function goToNextStep() {
      if ($scope.activeCharitiesList.length > 0 && $scope.currentPackage.charity_active) {
        $scope.currentStep = 3;
      } else {
        $scope.currentStep = 4;
      }
    }

    function goToPaymentMethod(paymentMethod) {
      $scope.paymentMethod = paymentMethod;
    }

    function useDifferentEmail() {
      $scope.currentStep = 0;
      $scope.isRegisteredUser = true;
      $scope.hasActiveCandAccount = true;
      $scope.isThisAgencyClient = false;
      $scope.nextBtn = true;
      $scope.useAnotherEmail = false;
      $scope.email = null;
      $scope.paymentGatewayForm.$setPristine();
      $scope.paymentGatewayForm.$setUntouched();
    }

    // checks in the database if the provided email is already used
    function checkIfEmailExists() {
      $scope.nextBtn = false;
      $scope.user_id = null;
      api.service_post('accounts', 'accounts/find', {
        email: $scope.email,
        type: 'client',
        agency_id: $scope.agencyAccountId,
      }).then((res) => {
        if (res.data.status === 'success') {
          if (Object.keys(res.data.data).length > 0) { // user found
            $scope.useAnotherEmail = true;
            $scope.isRegisteredUser = true;
            $scope.isThisAgencyClient = false;
            $scope.user_id = res.data.data.user_id;

            if (res.data.data.account_id) {
              $scope.isThisAgencyClient = true;
              if (res.data.data.account_status === 'activated') { // active client of this agency
                $scope.hasInactiveClientAccount = false;
              } else { // inactive client of this agency
                $scope.hasInactiveClientAccount = true;
              }
            } else { // not a client of this agency but a registered user, no need for password
              // @todo: assumption that we can register a client account for a candidate with inactive account
              $scope.isThisAgencyClient = false;
              $scope.currentStep = 1;
            }
          } else {
            // no registered user found
            $scope.isRegisteredUser = false;
          }
        } else {
          // error
          // @todo
        }
      }).catch((err) => {
        if (err.status_code != 200) {
          $scope.registrationConnectionErrorMessage = true;
        }
      });
    }

    function checkIfUsernameIsTaken() {
      $scope.usernameTaken = false;
      api.service_post('accounts', 'accounts/find', {
        username: $scope.username,
        type: 'client',
        agency_id: $scope.agencyAccountId,
      }).then((response) => {
        if (response.data.status === 'success') {
          if (Object.keys(response.data.data).length > 0) {
            $scope.usernameTaken = true;
            $scope.username = '';
            document.getElementById('username').focus();
          } else {
            $scope.currentStep = 1;
          }
        } else {
          // error
          showRegistrationError(utils.out('En raison d\'une erreur, nous n\'avons pas pu vérifier si ce nom d\'utilisateur est déjà utilisé. Veuillez réessayer de vous inscrire plus tard ou contacter notre équipe de soutien.',
            'Due to an error we could not check if this username is already taken. Please try registering again later or contact our support team.'));
        }
      }).catch(() => {
        // error
        showRegistrationError(utils.out('En raison d\'une erreur, nous n\'avons pas pu vérifier si ce nom d\'utilisateur est déjà utilisé. Veuillez réessayer de vous inscrire plus tard ou contacter notre équipe de soutien.',
          'Due to an error we could not check if this username is already taken. Please try registering again later or contact our support team.'));
      });
    }

    function findUser() {
      if ($scope.paymentGatewayForm.email.$error.pattern || $scope.paymentGatewayForm.email.$error.required) {
        $scope.emailpatternError = true;
      } else {
        $scope.emailpatternError = false;
        checkIfEmailExists();
      }
    }
    // check first and last name. email, phone, username, passwprd and password match for a new registration
    function checkUserInput() {
      $scope.emailTaken = false;
      $scope.usernameTaken = false;

      if ($scope.paymentGatewayForm.email.$error.pattern || $scope.paymentGatewayForm.email.$error.required) {
        $scope.emailpatternError = true;
      } else {
        $scope.emailpatternError = false;
      }

      if ($scope.paymentGatewayForm.firstname.$error.pattern || $scope.paymentGatewayForm.firstname.$error.required) {
        $scope.firstNameError = true;
      } else {
        $scope.firstNameError = false;
      }

      if ($scope.paymentGatewayForm.lastname.$error.pattern || $scope.paymentGatewayForm.lastname.$error.required) {
        $scope.lastNameError = true;
      } else {
        $scope.lastNameError = false;
      }

      if ($scope.paymentGatewayForm.contact.$error.pattern || $scope.paymentGatewayForm.contact.$error.required) {
        $scope.phoneError = true;
      } else {
        $scope.emailError = false;
      }

      if ($scope.paymentGatewayForm.username.$error.pattern || $scope.paymentGatewayForm.username.$error.required) {
        $scope.usernameError = true;
      } else {
        $scope.usernameError = false;
      }

      if ($scope.paymentGatewayForm.password.$error.minlength || $scope.paymentGatewayForm.password.$error.required
                || !regex.test($scope.password)) {
        $scope.passwordError = true;
      } else {
        $scope.passwordError = false;
      }

      if ($scope.paymentGatewayForm.cpassword.$error.minlength || $scope.paymentGatewayForm.cpassword.$error.required
                || $scope.cpassword != $scope.password) {
        $scope.cpasswordError = true;
      } else {
        $scope.cpasswordError = false;
      }

      if (!$scope.paymentGatewayForm.firstname.$error.pattern && !$scope.paymentGatewayForm.firstname.$error.required
                && !$scope.paymentGatewayForm.lastname.$error.pattern && !$scope.paymentGatewayForm.lastname.$error.required
                && !$scope.paymentGatewayForm.email.$error.pattern && !$scope.paymentGatewayForm.email.$error.required
                && !$scope.paymentGatewayForm.contact.$error.pattern && !$scope.paymentGatewayForm.contact.$error.required
                && !$scope.paymentGatewayForm.username.$error.pattern && !$scope.paymentGatewayForm.username.$error.required
                && !$scope.paymentGatewayForm.password.$error.minlength && !$scope.paymentGatewayForm.password.$error.required
                && !$scope.paymentGatewayForm.cpassword.$error.minlength && !$scope.paymentGatewayForm.cpassword.$error.required
                && $scope.cpassword == $scope.password) {
        checkIfUsernameIsTaken();
      }
    }

    function validateLocation() {
      if (!$scope.selectedLocation) {
        return false;
      }
      return true;
    }

    function checkFirstName() {
      if (!$scope.paymentGatewayForm.firstname.$error.pattern && !$scope.paymentGatewayForm.firstname.$error.required) {
        $scope.firstNameError = false;
      }
    }

    function checkLastName() {
      if (!$scope.paymentGatewayForm.lastname.$error.pattern && !$scope.paymentGatewayForm.lastname.$error.required) {
        $scope.lastNameError = false;
      }
    }

    function checkEmail() {
      if (!$scope.paymentGatewayForm.email.$error.pattern && !$scope.paymentGatewayForm.email.$error.required) {
        $scope.emailpatternError = false;
      }
    }

    function checkContact() {
      if (!$scope.paymentGatewayForm.contact.$error.pattern && !$scope.paymentGatewayForm.contact.$error.required) {
        $scope.phoneError = false;
      }
    }

    function checkUsername() {
      if (!$scope.paymentGatewayForm.username.$error.pattern && !$scope.paymentGatewayForm.username.$error.required) {
        $scope.usernameError = false;
      }
    }

    function checkPassword() {
      if (!$scope.paymentGatewayForm.password.$error.minlength && !$scope.paymentGatewayForm.password.$error.required
                && regex.test($scope.password)) {
        $scope.passwordError = false;
      }
    }

    function checkcPassword() {
      if (!$scope.paymentGatewayForm.cpassword.$error.minlength && !$scope.paymentGatewayForm.cpassword.$error.required
                && $scope.cpassword == $scope.password) {
        $scope.cpasswordError = false;
      }
    }

    function checkCompanyPhone() {
      if (!$scope.paymentGatewayForm.companyPhone.$error.pattern && !$scope.paymentGatewayForm.companyPhone.$error.required) {
        $scope.companyPhoneError = false;
      }
    }

    function goToPaymentInfo() {
      const validatedLocation = validateLocation();
      if ($scope.paymentGatewayForm.companyname.$error.pattern || $scope.paymentGatewayForm.companyname.$error.required) {
        $scope.companyNameError = true;
      } else {
        $scope.companyNameError = false;
      }
      if ($scope.paymentGatewayForm.companyLocation.$error.required) {
        $scope.companyLocationError = true;
      } else if (!validatedLocation) {
        $scope.companyAutocompleteLocationError = true;
      } else {
        $scope.companyLocationError = false;
      }
      if ($scope.isRegisteredUser) {
        if ($scope.paymentGatewayForm.companyPhone.$error.pattern || $scope.paymentGatewayForm.companyPhone.$error.required) {
          $scope.companyPhoneError = true;
        } else {
          $scope.companyPhoneError = false;
        }
      }
      if ((!$scope.isRegisteredUser && !$scope.paymentGatewayForm.companyname.$error.pattern && !$scope.paymentGatewayForm.companyname.$error.required
                    && !$scope.paymentGatewayForm.companyLocation.$error.required && validatedLocation)
                || ($scope.isRegisteredUser && !$scope.paymentGatewayForm.companyPhone.$error.pattern && !$scope.paymentGatewayForm.companyPhone.$error.required
                    && !$scope.paymentGatewayForm.companyname.$error.pattern && !$scope.paymentGatewayForm.companyname.$error.required
                    && !$scope.paymentGatewayForm.companyLocation.$error.required && validatedLocation)) {
        // @agency: for fccq agency currentStep was 4
        $scope.currentStep = 2;
      }
    }

    function checkCompanyName() {
      if (!$scope.paymentGatewayForm.companyname.$error.pattern && !$scope.paymentGatewayForm.companyname.$error.required) {
        $scope.companyNameError = false;
      }
    }

    function checkCompanyLocation() {
      if (!$scope.paymentGatewayForm.companyLocation.$error.required) {
        $scope.companyLocationError = false;
      }
      $scope.companyAutocompleteLocationError = false;
    }

    function checkAgreeAgreement() {
      if ($scope.paymentGatewayForm.agreeAgreement.$error.required) {
        $scope.validateText = 'text-danger';
      } else {
        $scope.validateText = '';
      }
    }

    function payNowMyOrder() {
      if ($scope.loading) {
        return;
      }

      if ($scope.paymentGatewayForm.cardHolderName.$error.pattern || $scope.paymentGatewayForm.cardHolderName.$error.required) {
        $scope.cardNameError = true;
      } else {
        $scope.cardNameError = false;
      }

      checkAgreeAgreement();

      if (!$scope.paymentGatewayForm.cardHolderName.$error.pattern && !$scope.paymentGatewayForm.cardHolderName.$error.required && !$scope.paymentGatewayForm.agreeAgreement.$error.required) {
        $scope.submitRegistrationInfo();
      }
    }

    function checkCardHolderName() {
      if (!$scope.paymentGatewayForm.cardHolderName.$error.pattern && !$scope.paymentGatewayForm.cardHolderName.$error.required) {
        $scope.cardNameError = false;
      }
    }

    function checkAgreeAgreementFree() {
      if ($scope.paymentGatewayForm.agreeAgreementFree.$error.required) {
        $scope.validateText = 'text-danger';
      } else {
        $scope.validateText = 'okText';
      }
    }

    function openTermsModal() {
      // add checks to show other agencies terms and conditions
      if ($scope.agreeAgreement || $scope.agreeAgreementFree) {
        $uibModal.open({
          animation: true,
          templateUrl: utils.out('./atlas/directives/payment-gateway/client-terms-and-conditions-fr.template.html',
            './atlas/directives/payment-gateway/client-terms-and-conditions-en.template.html'),
          scope: $scope,
          size: 'lg',
        });
      }
    }

    function loginToAtlas() {
      if ($scope.password && $scope.username) {
        // @todo test - not tested
        authService.login($scope.credentials).then((res) => {
          const loginResponse = res.data;
          if (loginResponse && loginResponse.status === 'success') {
            authService.saveToken(loginResponse.token);
            $rootScope.accounts = $scope.accounts = loginResponse.data.accounts ? loginResponse.data.accounts : [loginResponse.data.account];
            storageService.setItem('accounts', JSON.stringify($scope.accounts));

            if ($scope.accounts.length > 1) {
              // case where user has more than 1 account
              $state.transitionTo('accounts');
            } else {
              // case where user has only 1 account
              userAccountsService.setCurrentUserAccount(loginResponse);
              $scope.userCanLogin = true;
              $state.transitionTo('home');
            }
          } else if (loginResponse.status == 'fail') {
            $ngConfirm({
              title: utils.out('Erreur!', 'Error!'),
              type: 'red',
              content: utils.out(
                'Erreur! SVP contactez support@workland.com',
                'Something went wrong! Please contact support@workland.com',
              ),
              buttons: {
                Ok: {
                  text: $scope.out('Ok', 'Ok'),
                  btnClass: 'btn btn-secondary',
                },
              },
            });
          } else {
            $ngConfirm({
              title: utils.out('Erreur!', 'Error!'),
              type: 'red',
              content: utils.out(
                'Erreur! SVP contactez support@workland.com',
                'Something went wrong! Please contact support@workland.com',
              ),
              buttons: {
                Ok: {
                  text: $scope.out('Ok', 'Ok'),
                  btnClass: 'btn btn-secondary',
                },
              },
            });
          }
        }).catch(() => {
          $scope.afterRegisterMsg = '';
          $ngConfirm({
            title: utils.out('Erreur!', 'Error!'),
            type: 'red',
            content: utils.out(
              'Une erreur est survenue lors de l\'ouverture de votre session, veuillez contacter notre équipe de soutien pour plus d\'informations',
              'There was an error while trying to log you in, please contact our support team for further assistance',
            ),
            buttons: {
              Ok: {
                text: $scope.out('Ok', 'Ok'),
                btnClass: 'btn btn-secondary',
              },
            },
          });
        });
      } else {
        // @agency: can add checks to redirect to agencies login pages
        $state.transitionTo('loginPage');
      }
    }

    function buyFreePackage() {
      if ($scope.loading) {
        return;
      }
      // @agency: can add checks for agencies cookies mode
      if ($rootScope.agencyId) {
        $scope.loading = true;
      }

      $scope.purchaseDetails = {};
      if ($scope.user_id) {
        $scope.purchaseDetails.user_id = $scope.user_id;
      } else {
        $scope.purchaseDetails.email = $scope.email;
        $scope.purchaseDetails.username = $scope.username;
        $scope.purchaseDetails.password = $scope.password;
        $scope.purchaseDetails.first_name = $scope.firstName;
        $scope.purchaseDetails.last_name = $scope.lastName;
        $scope.purchaseDetails.language = $rootScope.language;
      }
      $scope.purchaseDetails.phone = $scope.contact ? $scope.contact : $scope.companyPhone;

      $scope.purchaseDetails.agency_account_id = $scope.agencyAccountId;
      $scope.purchaseDetails.email_updates_flag = $scope.emailUpdate;
      $scope.purchaseDetails.company_name = $scope.companyname;
      $scope.purchaseDetails.product_id = $scope.currentPackage.id;
      $scope.purchaseDetails.account_type_id = $scope.currentPackage.account_type_id;
      $scope.purchaseDetails.location_id = 0;
      $scope.purchaseDetails.website_link = $scope.companyWebsite;
      $scope.purchaseDetails.linkedin_link = $scope.companyLinkedin;
      $scope.purchaseDetails.fb_link = $scope.companyFacebook;
      $scope.purchaseDetails.twitter_link = $scope.companyTwitter;

      return getLocationId($scope.selectedLocation).then(() => {
        marketplaceService.createFreeAccount($scope.purchaseDetails).then((res) => {
          // @agency: can add checks for agencies cookies mode
          if ($rootScope.agencyId) {
            $scope.loading = false;
            $scope.newUserInfo = {
              id: res.data.user.id,
              account_id: res.data.account.id,
              account_role: 40,
              account_type: res.data.account.type,
              email: res.data.user.email,
            };
            $scope.stage = 'openIsed';
            $scope.worklandAvatar = './../assets/images/lady.svg';
          }
          // @agency: can add checks for agencies cookies mode and specific message
          $scope.afterRegisterMsg = '3';
          $scope.credentials = {
            email: $scope.username,
            password: $scope.password,
          };
          $scope.loading = false;
        }).catch(() => {
          $scope.afterRegisterMsg = '';
          showRegistrationError(utils.out('Une erreur est survenue lors de votre inscription, veuillez contacter notre équipe de soutien pour plus d\'informations',
            'There was an error during your registration. Please contact our support team for further assistance'));
          $scope.loading = false;
        });
      });
    }

    function createFreeAccount() {
      checkAgreeAgreementFree();
      if (!$scope.paymentGatewayForm.agreeAgreementFree.$error.required) {
        buyFreePackage();
      }
    }

    scope = {
      postCatherineMsg,
      postCandidateMsg,
      isedCallback,
      checkAgreeAgreement,
      useDifferentEmail,
      errorIsedCallback,
      getLocationId,
      exitPayment,
      createFreeAccount,
      goToNextStep,
      goToPaymentMethod,
      findUser,
      checkUserInput,
      checkFirstName,
      checkLastName,
      checkEmail,
      checkContact,
      checkUsername,
      checkPassword,
      checkcPassword,
      checkCompanyPhone,
      goToPaymentInfo,
      checkCompanyName,
      checkCompanyLocation,
      payNowMyOrder,
      checkCardHolderName,
      checkAgreeAgreementFree,
      openTermsModal,
      loginToAtlas,
    };
    angular.extend($scope, scope);
  }
  PaymentGatewayCtrl.$inject = [
    '$scope',
    'api',
    'utils',
    'transferer',
    '$rootScope',
    '$uibModal',
    '$location',
    '$state',
    '$stateParams',
    'authService',
    'storageService',
    'marketplaceService',
    '$window',
    '$sce',
    '$anchorScroll',
    '$ngConfirm',
    'userAccountsService',
    '$timeout',
  ];

  const app = angular.module('atlas');
  app.directive('paymentGateway', () => ({
    scope: {

    },
    controller: PaymentGatewayCtrl,
  }));

  app.controller('PaymentGatewayCtrl', PaymentGatewayCtrl);

  app.directive('focusNextOnEnter', () => ({
    restrict: 'A',
    link($scope, selem, attrs) {
      selem.bind('keydown', (e) => {
        const code = e.keyCode || e.which;
        if (code === 13) {
          e.preventDefault();
          const pageElems = document.querySelectorAll('input, select, textarea');
          const elem = e.srcElement || e.target;
          let focusNext = false;
          const len = pageElems.length;
          for (let i = 0; i < len; i += 1) {
            const pe = pageElems[i];
            if (focusNext) {
              if (pe.style.display !== 'none') {
                angular.element(pe).focus();
                break;
              }
            } else if (pe === elem) {
              focusNext = true;
            }
          }
        }
      });
    },
  }));
}(angular));
