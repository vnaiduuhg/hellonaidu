(function(angular) {
    function uploadDocumentsCtrl(
        $scope,
        utils,
        _,
        api,
        $uibModal,
        $rootScope,
    ) {
        let msgEn,msgFr;
        const vm = this;
        let vmExtend = {
            out: utils.out,
            errorMessage: false,
            language: $rootScope.language,
        };
        angular.extend(vm, vmExtend);
    
        function uploadDoc(doc, files, file) {
            if (file) vm.file = file;
            if (vm.file) {
                vm.cadMsg = `<b>${doc.docTranslatedName}:</b> ${vm.file.name}<br><p>(${vm.out('Taille: ', 'Size: ')}${(vm.file.size / 1048576).toFixed(2)}MB)</p>`;
                if (vm.isFileFormatValid(vm.file.name)) {
                    if (vm.isFileSizeValid(vm.file.size)) {
                        vm.processUploadDoc(doc, vm.file, 'uploaded');
                    } else {
                        vm.postCandidateMsg({ text: vm.cadMsg, isValid: false });
                        msgEn = 'Sorry! Your file has a wrong size.<br>Please upload a file greater than 0 and smaller than <b>5 MB</b>. ';
                        msgFr = 'Désolé! Votre fichier a une taille invalide. <br> Veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à <b> 5 Mo </b>.';
                        vm.postCatherineMsg({ msgEn, msgFr });
                    }
                } else {
                    vm.postCandidateMsg({ text: vm.cadMsg, isValid: false });
                    msgEn = `Sorry! This is not a valid <b>file format for your ${doc.docTranslatedName}.</b><br>We only accept .doc, .docx, .pdf, .txt.`;
                    msgFr = `Pardon! Ce n'est pas un <b>format de fichier valide pour votre ${doc.docTranslatedName}. </b> <br> Nous acceptons uniquement les formats .doc, .docx, .pdf, .txt.`;
                    vm.postCatherineMsg({ msgEn, msgFr });
                }
            }
            vm.file = null;
        }

        function isFileFormatValid(file) {
            const ext = file.toLowerCase().split('.').pop();
            if (ext === 'pdf' || ext === 'docx' || ext === 'doc' || ext === 'txt') {
                return true;
            }
            return false;
        }

        function isFileSizeValid(size) {
            if (size > 0 && size / (1048576) <= 5) {
                return true;
            }
            return false;
        }

        function openCadLibrary(doc) {
            vm.errorMessage = false;
            api.service_get('toolkit', 'document-manager/candidate-file-versions/list').then((response) => {
                if (response.data.status === 'success') {
                    vm.DocumentCollection = response.data.data.message;
                    if (vm.DocumentCollection.length > 0) {
                        vm.activeFile = { iframeUrl: '' };
                        vm.showDocument(vm.DocumentCollection[0]);
                    }
                } else {
                    // this case is not handle in backend, but in case
                    vm.errorMessage = true;
                }
            }).catch(() => {
                vm.DocumentCollection = {};
                vm.errorMessage = true;
            });

            $scope.$modalInstance = $uibModal.open({
                animation: true,
                templateUrl: './atlas/directives/job-apply/modal-templates/document-library.template.html',
                scope: $scope,
                size: 'lg',
            });

            $scope.$modalInstance.result.then((file) => {
                if (file) {
                    if (file.type_id === doc.document_type_id) {                       
                        vm.cadMsg = `<b>${doc.docTranslatedName}:</b> ${file.file_name}<br><p>(${vm.out('Attaché de la bibliothèque de documents', 'Attached from Document Library')})</p>`;
                        vm.processUploadDoc(doc, file, 'attached');
                    } else {
                        msgEn = 'Please select the type of document:' + doc.name;
                        msgFr = 'Veuillez sélectionner le type de document : ' + doc.name_fr;
                        vm.postCatherineMsg({msgEn, msgFr});
                    }
                }
            });
        }

        function showDocument(document) {
            vm.activeFile = document;
            const extension = document.file_name.toLowerCase().split('.').pop();
            utils.hideClasses();

            switch (extension) {
                case 'pdf':
                    navigator.pdfViewerEnabled ? utils.showNativePdfFile(document) : utils.showPdfFile(document);
                    break;
                case 'ppt':
                case 'pptx':
                case 'doc':
                case 'docx':
                case 'xls':
                case 'xlsx':
                case 'odt':
                    utils.showOfficeFile(document);
                    break;
                case 'png':
                case 'tif':
                case 'tiff':
                case 'bmp':
                case 'jpg':
                case 'jpeg':
                case 'gif':
                    utils.showImage(document);
                    break;
                case 'txt':
                    utils.showTxtFile(document);
                    break;
                default:

                    window.document.getElementById('Enable-docViewer').style.display = 'block';
            }
        }

        function processUploadDoc(doc, file, type) {
            let url = '';
            if (type === 'uploaded') {
                const data = {
                    upload_type: 'file',
                    file_name: file.name,
                    url_link: 'empty',
                    file,
                    is_deleted: 0,
                    registered_users: vm.candidate.loginStatus === 'regular' ? 1 : 0,
                    candidate_id: vm.candidate.id,
                    type_id: doc.document_type_id ? doc.document_type_id : 7,
                    required_document_id: doc.id,
                };
                url = `document-manager/quick-apply/create?document_application_id=${vm.candidate.applicationId}`;
                vm.callToDocumentManager(doc, file, type, url, data);
            } else if (type === 'attached') {
                url = `document-manager/quick-apply/add?document_application_id=${vm.candidate.applicationId}&file_version_id=${file.id}&required_document_id=${doc.id}`;
                vm.callToDocumentManager(doc, file, type, url);
            }
        }

        function callToDocumentManager(doc, file, type, url, data) {
            vm.catherineTyping = true;
            let promise = '';
            if (data) {
                promise = api.toolkit_fileupload(url, data);
            } else {
                promise = api.service_post('toolkit', url, {});
            }
            promise.then(() => {
                doc.uploaded = true;
                vm.postCandidateMsg({ text: vm.cadMsg, isValid: true });
                vm.catherineTyping = false;
                vm.candidate.doc.push({ docId: doc.document_type_id, file, type });
                msgEn = `Your <b>${doc.docTranslatedName}</b> uploaded successfully`;
                msgFr = `Votre <b>${doc.docTranslatedName}</b> a été téléchargé avec succès`;                
                vm.postCatherineMsg({ msgEn, msgFr });

                if (vm.candidate.doc.length === vm.documents.length) {
                    vm.required = 'waiting';
                    vm.uploadDocumentsCallback();
                } else if (vm.candidate.doc.length === vm.filteredDoc.length) {
                    vm.askForOptionalDocuments();
                }
            }).catch((error) => {
                msgEn = 'Sorry! Please try again.<br> There is a something wrong with document manager.';
                msgFr = 'Pardon! Veuillez réessayer.<br> Il y a un problème avec le gestionnaire de documents.';
                if(error.data?.code && error.data.code === 400) {
                    if(error.data?.message?.file && error.data.message.file[0] === 'validation.max.file') {
                        msgEn = "Sorry! Your file has a wrong size.<br>Please upload a file greater than 0 and smaller than <b>5 MB</b>. ";
                        msgFr = "Désolé! Votre fichier a une taille invalide. <br> Veuillez importer un fichier dont la taille est supérieur à 0 et inférieure à <b> 5 Mo </b>.";
                    }
                    else if (error.data?.message?.file && error.data.message.file[0] === 'validation.clamav') {
                        msgEn = "Sorry! This file is invalid, please upload a new file";
                        msgFr = "Désolé! Ce fichier est invalide, veuillez télécharger un nouveau fichier";
                    }
                } else if (error.data?.code && error.data.code === 403) {
                    msgEn = `Your document library is full. To upload a new document, please log into your candidate profile and delete uploaded documents in the 'My documents' section of your profile.`;
                    msgFr = `Votre bibliothèque de documents est pleine. Afin de télécharger un nouveau document, connectez-vous à votre profil candidat et supprimez des documents téléchargés dans la section 'Mes documents' de votre profil.`;
                }
                vm.postCatherineMsg({ msgEn, msgFr });
                vm.catherineTyping = false;
            });
        }

        function askForOptionalDocuments() {
            msgEn = '<b>Almost done.</b><br>There are some optional documents. Add them now because it is not possible to do any changes later.';
            msgFr = "Il existe certains documents facultatifs pour compléter votre candidature. Ajoutez-les maintenant car il est impossible d'apporter des modifications ultérieurement.";
            vm.postCatherineMsg({ msgEn, msgFr });
            vm.required = 'optionalDoc';
            vm.label = vm.out('Document(s) facultatif(s)', 'Optional document(s)');
        }

        function skipOptionalDoc() {
            vm.required = 'waiting';
            vm.cadMsg = `[${vm.out('Documents facultatifs ignorés', 'Skipped optional documents')}]`;
            vm.postCandidateMsg({ text: vm.cadMsg, isValid: false });
            vm.uploadDocumentsCallback();
        }

        $scope.$watch('vm.stage', () => {
            vm.init();
        });

        function init() {
            if (vm.stage === 'uploadDocuments') {
                vm.candidate.doc = [];
                vm.catherineTyping = true;
                if (vm.candidate.loginStatus && vm.candidate.loginStatus === 'regular') {
                    msgEn = 'This job <b>requires some mandatory document(s).</b><br>Please upload or choose from your library. Please note that it is necessary to upload <b>all</b> the documents that you want to include with your application <b>now</b>, because it will not be possible to do any changes later.';
                    msgFr = "Ce poste <b>requiert certains documents obligatoires.</b><br> Veuillez les télécharger ou les choisir dans votre bibliothèque. Il faut télécharger <b>tous</b> les documents que vous souhaitez inclure avec votre candidature <b>maintenant</b>, car il sera impossible d'apporter des modifications ultérieurement.";
                    vm.postCatherineMsg({ msgEn, msgFr });
                } else {
                    if (!vm.candidate.loginStatus) {
                        vm.candidate.loginStatus = vm.applicationType;
                    }
                    msgEn = '<b>Great!</b> We have all your required personal details.<br>Now please upload the required documents. Please note that it is necessary to upload <b>all</b> the documents that you want to include with your application <b>now</b>, because it will not be possible to do any changes later.';
                    msgFr = "<b>Excellent!</b> Veuillez maintenant télécharger les documents requis. Il faut télécharger <b>tous</b> les documents que vous souhaitez inclure avec votre candidature <b>maintenant</b>, car il sera impossible d'apporter des modifications ultérieurement.";
                    vm.postCatherineMsg({ msgEn, msgFr });
                }
                vm.catherineTyping = false;
                vm.required = 'mandatoryDoc';
                vm.label = vm.out('Document(s) obligatoire(s)', 'Mandatory document(s)');
                vm.docUploadChecking = true;     
                api.service_post('toolkit', `document-manager/quick-apply/fetch-document-status?document_application_id=${vm.candidate.applicationId}`, {})
                    .then((response)=> {
                        let numDocsByType = response.data;                        
                        angular.forEach(vm.documents, (doc) => {
                            if (numDocsByType[doc.document_type_id] > 0) {
                                doc.uploaded = true;
                                numDocsByType[doc.document_type_id]--;
                                const cadText = doc.docTranslatedName + vm.out(' déjà téléchargé', ' already uploaded');
                                vm.postCandidateMsg({ text: cadText, isValid: true });
                                vm.candidate.doc.push({ docId: doc.id, file: vm.out(doc.name_fr, doc.name), type: doc.document_type_id });
                                if (vm.candidate.doc.length === vm.documents.length) {
                                    vm.required = 'waiting';
                                    vm.uploadDocumentsCallback();
                                } else if (vm.candidate.doc.length === vm.filteredDoc.length) {
                                    vm.askForOptionalDocuments();
                                }
                            } 
                        })
                        vm.docUploadChecking = false;
                    })
            }
        }

        vmExtend = {
            init,
            askForOptionalDocuments,
            uploadDoc,
            openCadLibrary,
            isFileFormatValid,
            isFileSizeValid,
            skipOptionalDoc,
            showDocument,
            processUploadDoc,
            callToDocumentManager,
        };
        angular.extend(vm, vmExtend);
    }

    uploadDocumentsCtrl.$inject = [
        '$scope',
        'utils',
        '_',
        'api',
        '$uibModal',
        '$rootScope',
    ];
    const app = angular.module('atlas');
    app.directive('uploadDocumentsModule', () => ({
        scope: {},
        bindToController: {
            postCatherineMsg: '&',
            postCandidateMsg: '&',
            candidate: '=',
            documents: '=',
            uploadDocumentsCallback: '&',
            catherineTyping: '=',
            stage: '=',
            applicationType: '=',
            customColor: '=',
            displayDocName: '&',
        },
        controller: uploadDocumentsCtrl,
        controllerAs: 'vm',
        templateUrl: './atlas/directives/job-apply/upload-documents-module/upload-documents-module.template.html',
    }));
}(angular));
