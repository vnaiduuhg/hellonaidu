(function (angular) {
  const app = angular.module('atlas');
  app.directive('applyJobModule', () => {
    applyJobCtrl.$inject = ['$scope',
      'utils',
      '_',
      'worklandLocalize',
      '$state',
      'api',
      '$uibModal',
      '$timeout',
      'applicationService',
      'storageService',
    ];
    function applyJobCtrl(
      $scope,
      utils,
      _,
      worklandLocalize,
      $state,
      api,
      $uibModal,
      $timeout,
      applicationService,
      storageService,
    ) {
      let msgEn,msgFr,cadMsg;
      const vm = this;
      const vmExtend = {
        out: utils.out,
        strings: worklandLocalize.strings,
        init,
        openTermConditionModel,
        applyNow,
        submitApplication,
        isCadQualified,
        redirectUser,
        callToDocumentManager,
        userQualified,
        userDisqualified,
      };
      $scope.$watch('vm.stage', () => {
        vm.init();
      });

      function applyNow() {
        vm.required = 'waiting';
        cadMsg = vm.out("J'ai lu et j'accepte les termes et conditions d'utilisation de la platforme.<br>Soumettre ma candidature", 'I have read and agree to all the terms and conditions.<br>Submit my application');
        vm.postCandidateMsg({ text: cadMsg, isValid: true });
        msgEn = "<b>Please Wait.</b> I'm submitting your application.<br><i>(Don't refresh the page)</i>";
        msgFr = "<b>S'il vous plaît, veuillez attendre.</b> Je soumets votre candidature.<br><i>(Ne pas actualiser la page)</i>";
        vm.postCatherineMsg({ msgEn, msgFr });
        vm.catherineTyping = true;
        if (vm.candidate.applicationStatus == 'submitted') {
          vm.submitApplication();
        } else {
          // @todo message to user
        }
      }

      function submitApplication() {
        const atlasMSToken = storageService.getCookieByName('atlasMicrosoftToken');
        const data = {
          qualifies: vm.candidate.questionnaires.status == 'qualified',
        };
        if (vm.urlParamsToSubmit.jobAlert) data["job-alert"] = +vm.urlParamsToSubmit.jobAlert
        if (vm.urlParamsToSubmit.newsletter) data.newsletter = +vm.urlParamsToSubmit.newsletter
        if (vm.loginHash) data.encrypted_user_data = vm.loginHash;
        if (atlasMSToken) data.atlas_microsoft_token = atlasMSToken;
        vm.catherineTyping = true;
        applicationService.patch_query('application', vm.candidate.applicationId, 'submit', data).then((response) => {
          if (response.status == 200 || response.status == 201) {
            vm.candidate.applicationId = response.data.application_id;
            vm.isCadQualified();
          } else {
            // @bug - we receive error http codes on response
            vm.catherineTyping = false;
            if (response.status === 403 && response.data) {
              const expiredStatus = response.data === "job_unpublished_externally"
                    ? vm.out("expiré à l'externe", "expired externally")
                    : response.data === "job_unpublished_internally"
                      ? vm.out("expiré à l'interne", "expired internally")
                      : vm.out("expiré", "expired");
              msgEn = `The position is currently ${expiredStatus}, your application could not be submitted`;
              msgFr = `Le poste est présentement ${expiredStatus}, votre candidature n'a pu être soumise`;
            } else {
              msgEn = 'Application submission error. Please contact <b>support@workland.com</b>.<br>You can also consult the jobs list.';
              msgFr = 'Erreur de dépôt de candidature. SVP contactez <b>support@workland.com</b>.<br>Vous pouvez également consulter la liste des emplois.';
            }
            vm.postCatherineMsg({ msgEn, msgFr });
            $timeout(() => {
              vm.required = 'consultListJob';
            }, 300);
          }
        }).catch((error) => {
          vm.catherineTyping = false;
          if (error.status === 403 && error.data) {
            const expiredStatus = error.data === "job_unpublished_externally"
                  ? vm.out("expiré à l'externe", "expired externally")
                  : error.data === "job_unpublished_internally"
                    ? vm.out("expiré à l'interne", "expired internally")
                    : vm.out("expiré", "expired");
            msgEn = `The position is currently ${expiredStatus}, your application could not be submitted`;
            msgFr = `Le poste est présentement ${expiredStatus}, votre candidature n'a pu être soumise`;
          } else {
            msgEn = 'Application submission error. Please contact <b>support@workland.com</b>.<br>You can also consult the jobs list.';
            msgFr = 'Erreur de dépôt de candidature. SVP contactez <b>support@workland.com</b>.<br>Vous pouvez également consulter la liste des emplois.';
          }
          vm.postCatherineMsg({ msgEn, msgFr });
          $timeout(() => {
            vm.required = 'consultListJob';
          }, 300);
        });
      }

      function isCadQualified() {
        const { status } = vm.candidate.questionnaires;
        if (status === 'qualified') {
          vm.userQualified();
        } else {
          vm.userDisqualified();
        }
      }

      function redirectUser() {
        msgEn = "<b>All done,</b> you'll now be redirected to the confirmation page";
        msgFr = '<b>Terminé,</b> vous allez maintenant être redirigé vers la page de confirmation';
        vm.postCatherineMsg({ msgEn, msgFr });
        vm.catherineTyping = true;
        $timeout(() => {
          $state.go('jobAppliedSuccess', {
            jobId: vm.job.id,
            loginStatus: vm.candidate.loginStatus,
            candidateId: vm.candidate.id,
            candidateAccAlreadyExist: vm.candidateAccAlreadyExist,
            isInternalCandidate: vm.candidate.isInternalApplication,
            isMicrosoftLogin: vm.isMicrosoftLogin,
          });
        }, 500);
      }

      function callToDocumentManager(url, data) {
        if (data) {
          var promise = api.toolkit_fileupload(url, data);
        } else {
          var promise = api.service_post('toolkit', url, {});
        }
        promise.then((response) => {
        }).catch((error) => {
        });
      }

      function userQualified() {
        vm.redirectUser();
      }

      function userDisqualified() {
        vm.catherineTyping = false;
        // @agency: can add conditions for agency specific reasons based on cookies mode
        msgEn = "<b>We're sorry to inform you that your application has been rejected as it does not meet the qualifications required for this position.<br>Thank you for your interest.</b>";
        msgFr = '<b>Nous sommes désolés de vous informer que votre candidature a été rejetée puisqu’elle ne correspond pas aux qualifications exigées pour ce poste.<br>Merci de l’intérêt manifesté.</b>';
        vm.postCatherineMsg({ msgEn, msgFr });
      }

      function openTermConditionModel() {
        $scope.openTermModelInstance = $uibModal.open({
          animation: true,
          templateUrl: vm.out('./atlas/directives/job-apply/modal-templates/terms-and-conditions-model-fr.template.html', './atlas/directives/job-apply/modal-templates/terms-and-conditions-model-en.template.html'),
          scope: $scope,
          size: 'lg',
        });
      }

      function init() {
        if (vm.stage === 'applyJob') {
          vm.catherineTyping = false;
          if (vm.candidate.loginStatus == 'regular') {
            msgEn = "Excellent! Now, please confirm your application by clicking 'Apply Now'";
            msgFr = "Excellent! Maintenant, s'il vous plaît veuillez confirmer votre candidature en cliquant 'Envoyer ma candidature'";
          } else {
            msgEn = "One last step!  Before submitting your application, we'll need you to read and accept our site's terms and conditions";
            msgFr = "Dernière étape!  Avant de soumettre votre candidature, nous vous demandons de lire et d'accepter les termes et conditions de notre plateforme.";
          }
          vm.postCatherineMsg({ msgEn, msgFr });
          vm.required = 'confirmation';
        }
      }
      angular.extend(vm, vmExtend);
    }
    return {
      scope: {
      },
      bindToController: {
        postCatherineMsg: '&',
        postCandidateMsg: '&',
        candidate: '=',
        job: '=',
        stage: '=',
        catherineTyping: '=',
        consultJobsList: '&',
        candidateAccAlreadyExist: '=',
        customColor: '=',
        isMicrosoftLogin: '=',
        urlParamsToSubmit: '=',
        loginHash: '=',
      },
      controller: applyJobCtrl,
      controllerAs: 'vm',
      templateUrl: './atlas/directives/job-apply/apply-job-module/apply-job-module.template.html',
    };
  });
}(angular));
