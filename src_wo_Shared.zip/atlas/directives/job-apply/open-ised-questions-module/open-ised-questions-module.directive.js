(function (angular) {
  function openIsedQuestionsCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    api,
    $timeout,
    applicationService,
  ) {
    let msgEn;
    let msgFr;
    const vm = this;
    const vmExtend = {
      out: utils.out,
      range: _.range,
      strings: worklandLocalize.strings,
      loadQuestionnaire,
      loadQuestion,
      loadFollowUp,
      hasBranchQues,
      saveAnswer,
      init,
      setupScaleQues,
      initMap,
      setScaleAnswered,
      disqualify,
      structureLocation,
      formatTableAns,
      tableAns: [],
      tempCounter: 0,
      isBugNumberAddress: false,
      incompleteAddress: '',
      // submitDisqualifiedApplication,
      selectedLocation: {},
      autocomplete: null,
      autocompleteInput: null,
      setAccountInactive,
      googleMapsError: false,
    };

    function setupScaleQues() {
      vm.scaleQuestion = {
        index: 1,
        options: {
          floor: 1,
          ceil: vm.ques.question.scale_range,
          showTicks: true,
          showTicksValues: true,
        },
      };
      vm.scaleQuestion.options.onChange = vm.setScaleAnswered;
      vm.answers = 1;
    }

    function checkForGoogleApiErrors() {
      let secCounter = 0;
      const googleErrorCheckinterval = setInterval(function () {
        if (document.getElementById("address") && document.getElementById("address").classList.contains("gm-err-autocomplete")) {
          vm.googleMapsError = true;
          // @temp - needs to be tested
          addressErrorMsg('google_maps_error');
          vm.answers = null;
          vm.catherineTyping = false;
          $scope.stopApplying = true;
          vm.required = '';
          clearInterval(googleErrorCheckinterval);
        }
        secCounter += 1;
        if (secCounter === 10){
          clearInterval(googleErrorCheckinterval);
        }
      }, 1000);
    }

    // Load Google map API script
    function initMap() {
      $timeout(() => {
        vm.autocomplete = new google.maps.places.Autocomplete(vm.autocompleteInput);
        vm.autocomplete.setFields(['address_components', 'formatted_address']);
        vm.autocomplete.addListener('place_changed', () => {
          vm.selectedLocation = vm.autocomplete.getPlace();
          $scope.$apply();
        });
        checkForGoogleApiErrors();
      }, 100);
    }

    function getEnAndFrTranslations(item) {
      return angular.copy(item.translation);
    }

    function loadFollowUp(followUpQues) {
      vm.tempCounter = 0;
      vm.answers = '';
      vm.ques = followUpQues;
      if (vm.ques.question.type === 'scale') {
        vm.setupScaleQues();
      }
      msgEn = '';
      msgFr = '';
      if (vm.questionnaires.length > 1 && vm.currentQuestion == 0) {
        msgEn = `<u>Part ${vm.currentQuestionnaires + 1}</u>:<br>`;
        msgFr = `<u>Partie ${vm.currentQuestionnaires + 1}</u>:<br>`;
      }
      msgEn = `${msgEn}<b>Question (${vm.currentQuestion + 1}.1/${vm.questions.length})</b>: ${vm.ques.question.translation.en.description}`;
      msgFr = `${msgFr}<b>Question (${vm.currentQuestion + 1}.1/${vm.questions.length})</b>: ${vm.ques.question.translation.fr.description}`;
      vm.catherineTyping = true;
      let promise;
      if (!vm.questionnaires[vm.currentQuestionnaires].agency_account_id) {
        promise = api.service_get('toolkit', `questionnaire/answers/is-candidate-answered-to-question?questionnaire_question_id=${vm.ques.id}&job_id=${vm.jobId}&candidate_id=${vm.candidate.id}`);
      } else {
        promise = api.service_get('toolkit', `questionnaire/answers/is-candidate-answered-to-question?questionnaire_question_id=${vm.ques.id}&candidate_id=${vm.candidate.id}`);
      }
      promise.then((response) => {
        vm.catherineTyping = false;
        const isAlreadyAns = response.data.data.result;
        if (isAlreadyAns === 'false') {
          vm.postCatherineMsg({ msgEn, msgFr });
          vm.required = 'questions';
          if (vm.ques.question.type == 'format' && vm.ques.question.format == 'address') {
            const autocompleteInput = document.getElementById('address');
            if(!vm.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
              $scope.autocompleteInput = autocompleteInput;
              initMap();
            }
          }
        } else {
          let cadAns = '';

          const cadFirstAns = isAlreadyAns[0];
          if (cadFirstAns.translation) {
            let itemTranslated;
            angular.forEach(isAlreadyAns, (item) => {
              itemTranslated = getEnAndFrTranslations(item);
              cadAns = `${cadAns}- ${vm.out(itemTranslated.fr.title, itemTranslated.en.title)}<br>`;
            });
          } else if (cadFirstAns.row) {
            let itemRow;
            let itemColumn;
            angular.forEach(isAlreadyAns, (item) => {
              itemRow = getEnAndFrTranslations(item.row);
              itemColumn = getEnAndFrTranslations(item.column);
              cadAns = `${cadAns + vm.out(itemRow.fr.title, itemRow.en.title)} => ${vm.out(itemColumn.fr.title, itemColumn.en.title)}<br>`;
            });
          } else if (cadFirstAns.format) {
            cadAns = isAlreadyAns[0].value;
          } else if (cadFirstAns === 'true') {
            cadAns = vm.out('Oui', 'Yes');
          } else if (cadFirstAns === 'false') {
            cadAns = vm.out('Non', 'No');
          } else {
            cadAns = cadFirstAns;
          }
          alreadyAnswered(vm.ques, cadAns);
        }
      });
    }

    function hasBranchQues(branch, data) {
      let keepGoing;
      if (branch && branch.length > 0) {
        if (data.type === 'yes-no') {
          keepGoing = true;
          angular.forEach(branch, (item) => {
            let condition;
            if (data.candidateAnswer) {
              condition = (data.candidateAnswer === 'Yes' || data.candidateAnswer === 'Oui') ? 1 : 0;
            } else {
              condition = (vm.answers === 'Yes' || vm.answers === 'Oui') ? 1 : 0;
            }
            if (item.bool_condition === condition && keepGoing) {
              if (item.reject_candidate === 1) {
                vm.disqualify();
              } else if (item.tail_q_question) {
                vm.currentQuestion -= 1;
                vm.loadFollowUp(item.tail_q_question);
              }
              keepGoing = false;
            }
          });
          if (keepGoing) {
            vm.loadQuestion();
          }
        } else if (data.type === 'mc-ss') {
          keepGoing = true;
          angular.forEach(branch, (itemBranch) => {
            if (itemBranch.choice_condition_id === data.choice_id && keepGoing) {
              if (itemBranch.reject_candidate === 1) {
                vm.disqualify();
              } else if (itemBranch.tail_q_question) {
                vm.currentQuestion -= 1;
                vm.loadFollowUp(itemBranch.tail_q_question);
              }
              keepGoing = false;
            }
          });
          if (keepGoing) {
            vm.loadQuestion();
          }
        }
      } else {
        vm.loadQuestion();
      }
    }

    function alreadyAnswered(questionObj, answer) {
      const ques = questionObj.question;
      const branch = questionObj.question_branches;
      const data = {};
      data.type = ques.type;
      data.questionnaire_question_id = questionObj.id;
      data.score_obtained = 0;
      data.format = ques.format ? ques.format : null;
      data.alreadyAnswed = true;
      data.candidateAnswer = answer;
      vm.currentQuestion += 1;
      vm.required = 'waiting';
      vm.postCandidateMsg({ text: `<span class='border-bottom border-2 border-white'>${vm.out('Déjà répondu', 'Already answered')}:</span><p class='mt-2 mb-0'>${answer}</p>`, isValid: true });
      vm.candidate.questionnaires.ans.push(data);
      vm.hasBranchQues(branch, data);
    }

    function loadQuestion() {
      vm.tempCounter = 0;
      vm.answers = '';
      if (vm.currentQuestion === vm.questions.length) {
        vm.currentQuestionnaires += 1;
        vm.currentQuestion = 0;
        vm.loadQuestionnaire();
      } else {
        vm.ques = vm.questions[vm.currentQuestion];
        if (vm.ques.question.type === 'scale') {
          vm.setupScaleQues();
        }
        msgEn = '';
        msgFr = '';
        if (vm.questionnaires.length > 1 && vm.currentQuestion == 0) {
          msgEn = `<u>Part ${vm.currentQuestionnaires + 1}</u>:<br>`;
          msgFr = `<u>Partie ${vm.currentQuestionnaires + 1}</u>:<br>`;
        }
        msgEn = `${msgEn}<b>Question (${vm.currentQuestion + 1}/${vm.questions.length})</b>: ` + `<div style='white-space: pre-line'>${vm.ques.question.translation.en.description}</div>`;
        msgFr = `${msgFr}<b>Question (${vm.currentQuestion + 1}/${vm.questions.length})</b>: ` + `<div style='white-space: pre-line'>${vm.ques.question.translation.fr.description}</div>`;
        vm.catherineTyping = true;
        let promise;
        if (!vm.questionnaires[vm.currentQuestionnaires].agency_account_id) {
          promise = api.service_get('toolkit', `questionnaire/answers/is-candidate-answered-to-question?questionnaire_question_id=${vm.ques.id}&job_id=${vm.jobId}&candidate_id=${vm.candidate.id}`);
        } else { // it is a default agency questionnaire that is not attached to the job
          promise = api.service_get('toolkit', `questionnaire/answers/is-candidate-answered-to-question?questionnaire_question_id=${vm.ques.id}&candidate_id=${vm.candidate.id}`);
        }
        promise.then((response) => {
          vm.catherineTyping = false;
          const isAlreadyAns = response.data.data.result;
          if (isAlreadyAns === 'false') {
            vm.postCatherineMsg({ msgEn, msgFr });
            vm.required = 'questions';
            if (vm.ques.question.type == 'format' && vm.ques.question.format == 'address') {
              const autocompleteInput = document.getElementById('address');
              if(!vm.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
                vm.autocompleteInput = autocompleteInput;
                initMap();
              }
            }
            if (vm.ques.question.type === 'table') {
              const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
              for(i in allCheckboxes) { allCheckboxes[i].checked = false }
            }
          } else {
            vm.postCatherineMsg({ msgEn, msgFr });
            let cadAns = '';
            const cadFirstAns = isAlreadyAns[0];
            if (cadFirstAns.translation) {
              let itemTranslated;
              angular.forEach(isAlreadyAns, (item) => {
                itemTranslated = getEnAndFrTranslations(item);
                cadAns = `${cadAns}- ${vm.out(itemTranslated.fr.title, itemTranslated.en.title)}<br>`;
              });
            } else if (cadFirstAns.row) {
              let itemRow;
              let itemColumn;
              angular.forEach(isAlreadyAns, (item) => {
                itemRow = getEnAndFrTranslations(item.row);
                itemColumn = getEnAndFrTranslations(item.column);
                cadAns = `${cadAns + vm.out(itemRow.fr.title, itemRow.en.title)} => ${vm.out(itemColumn.fr.title, itemColumn.en.title)}<br>`;
              });
            } else if (cadFirstAns.format) {
              cadAns = isAlreadyAns[0].value;
            } else if (cadFirstAns === 'true') {
              cadAns = vm.out('Oui', 'Yes');
            } else if (cadFirstAns === 'false') {
              cadAns = vm.out('Non', 'No');
            } else {
              cadAns = cadFirstAns;
            }
            alreadyAnswered(vm.ques, cadAns);
          }
        }).catch(() => {
          vm.postCatherineMsg({ msgEn, msgFr });
          vm.required = 'questions';
          if (vm.ques.question.type == 'format' && vm.ques.question.format == 'address') {
            const autocompleteInput = document.getElementById('address');
            if(!vm.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
              $scope.autocompleteInput = autocompleteInput;
              initMap();
            }
          }
        });
      }
    }

    function loadQuestionnaire() {
      if (vm.currentQuestionnaires === vm.questionnaires.length) {
        vm.isedCallback();
      } else {
        vm.catherineTyping = true;
        const isedId = vm.questionnaires[vm.currentQuestionnaires].questionnaire_id;
        api.service_get('toolkit', `questionnaire/questionnaires/${isedId}`,
          { load_with: 'questionnaire_questions.question.choices;questionnaire_questions.question.rows;questionnaire_questions.question.columns;questionnaire_questions.question_branches;questionnaire_questions.question_branches.tail_q_question.question.rows;questionnaire_questions.question_branches.tail_q_question.question.columns;questionnaire_questions.question_branches.tail_q_question.question.choices;', sort_by: 'questionnaire_questions:rank' }).then((response) => {
          vm.catherineTyping = false;
          vm.ised = response.data.data.result;
          vm.questions = vm.ised.questionnaire_questions;
          vm.loadQuestion();
        }).catch(() => {
          if (vm.candidate.account_role == 70) {
            msgEn = "Sorry! We're having trouble fetching questionnaires.<br>I'll skip this step for now.";
            msgFr = "Désolé! Une erreur est survenue lors du chargement des questionnaires.<br> Je saute cette étape pour l'instant.";
            vm.postCatherineMsg({ msgEn, msgFr });
            vm.isedCallback();
          } else if (vm.candidate.account_role == 40) {
            //must complete questionnaires before login
            msgEn = "Sorry! We're having trouble fetching questionnaires.<br>Please contact our support team.";
            msgFr = "Désolé! Une erreur est survenue lors du chargement des questionnaires.<br> Veuillez contacter notre équipe du support.";
            vm.postCatherineMsg({ msgEn, msgFr });
            vm.errorIsedCallback();
          }
        });
      }
    }

    function formatTableAns(row, col) {
      let insert = true;
      let data = {};
      data.row_id = row.id;
      data.column_id = col.id;
      data.row_title = getEnAndFrTranslations(row);
      data.column_title = getEnAndFrTranslations(col);

      if (vm.tableAns.length > 0) {
        for (let i = 0; i < vm.tableAns.length; i++) {
          if (vm.tableAns[i].row_id === data.row_id && vm.tableAns[i].column_id === data.column_id) {
            insert = false;
            vm.tableAns.splice(i, 1);
            break;
          }
        }
        if (insert) {
          vm.tableAns.push(data);
        }
      } else {
        vm.tableAns.push(data);
      }
    }

    function validateDate(date) {
      // Extract the string into month, date and year
      const yy = date.slice(6);
      // check the year (can be 1900-2099). day and month are checked with cleave directive.
      const pattern = /^((1)(9)|(2)(0))([0-9]{2})$/g;
      const year = pattern.test(yy);
      if (!year) {
        alert(vm.out("Veuillez vérifiez l'année.", 'Please check the year.'));
        return false;
      }
      return true;
    }

    function notValidatedDate(date) {
      if (date.length == 10) {
        const day = date.slice(0, 2);
        const month = date.slice(3, 5);
        const year = date.slice(6);
        vm.wrongAnswers = `${day}/${month}/${year}`;
      } else {
        vm.wrongAnswers = '';
      }
      vm.answers = null;
      vm.postCandidateMsg({ text: vm.wrongAnswers, isValid: false });
      msgEn = 'The date format is invalid.<br>Please enter the date in (dd/mm/yyyy) format.';
      msgFr = 'Le format de date est invalide.<br>Veuillez entrer la date au format (jj/mm/aaaa).';
      vm.postCatherineMsg({ msgEn, msgFr });
    }

    function addressErrorMsg(error) {
      vm.postCandidateMsg({ text: vm.wrongAnswers, isValid: false });
      switch (error) {
        case 'street_number':
          msgEn = '<b>The address must contain a building number (civiq number)</b>. You can add it manually in the building number field provided.';
          msgFr = "<b>L'adresse doit avoir numéro d'immeuble (numéro civique)</b>. Vous pouvez l'ajouter manuellement dans le champ numéro d'immeuble.";
          break;
        case 'invalid_address':
          msgEn = "Invalid address, the address must include a civic number, a street, a city and a province.";
          msgFr = "Adresse invalide, l'adresse doit comporter un numéro civique, une rue, une ville ainsi qu'une province.";
          break;
        case 'google_maps_error':
          msgEn = 'Invalid address, please refresh the page and try again.<br>If the error persists, please contact our support team at support@workland.com.';
          msgFr = 'Adresse invalide, veuillez actualiser la page et réessayer.<br>Si l\'erreur persiste, veuillez contacter notre équipe d\'assistance à support@workland.com.';
          break;
        case 'address_error':
          msgEn = "Invalid address, please make sure you choose an address from Google's autocomplete suggestions.";
          msgFr = "Adresse invalide, veuillez vous assurer que vous choisissez une adresse parmi les suggestions de saisie semi-automatique de Google.";
          break;
        case 'not_filled':
        default:
          msgEn = 'Please enter an address';
          msgFr = 'Veuillez entrer une adresse';
      }
      vm.postCatherineMsg({ msgEn, msgFr });
    }

    function googlePlacesCheck() {
      const autocompleteInput = document.getElementById('address');
      if (!vm.autocomplete || !angular.element(autocompleteInput).hasClass('pac-target-input')) {
        console.log('reset google autocomplete');
        vm.autocompleteInput = autocompleteInput;
        initMap();
      }
    }

    function saveAnswer(questionObj) {
      const data = {};
      // check if the question is in default questionnaire and should be saved without job_id
      const isDefaultQuestion = vm.questionnaires[vm.currentQuestionnaires].agency_account_id ? true : false;
      vm.ansToSave = [];
      const ques = questionObj.question;
      const branch = questionObj.question_branches;
      data.type = ques.type;
      data.questionnaire_question_id = questionObj.id;
      data.score_obtained = 0;
      data.format = ques.format ? ques.format : null;
      data.defaultQuestion = isDefaultQuestion;
      if (data.type === 'mc-ms') {
        angular.forEach(ques.choices, (item) => {
          if (item.ans === true) {
            const mcData = {};
            mcData.type = ques.type;
            mcData.questionnaire_question_id = questionObj.id;
            mcData.score_obtained = 0;
            mcData.choice_id = item.id;
            mcData.defaultQuestion = isDefaultQuestion;
            let itemTitle = getEnAndFrTranslations(item);
            if (vm.answers) {
              vm.answers = `${vm.answers}, ${vm.out(itemTitle.fr.title, itemTitle.en.title)}`;
            } else {
              vm.answers = vm.out(itemTitle.fr.title, itemTitle.en.title);
            }
            vm.candidate.questionnaires.ans.push(mcData);
            vm.ansToSave.push(mcData);
          }
        });
      } else if (data.type === 'table') {
        if (vm.tableAns.length > 0) {
          angular.forEach(vm.tableAns, (item) => {
            let mcData = {};
            mcData.type = ques.type;
            mcData.questionnaire_question_id = questionObj.id;
            mcData.score_obtained = 0;
            mcData.row_id = item.row_id;
            mcData.column_id = item.column_id;
            mcData.defaultQuestion = isDefaultQuestion;
            if (!vm.answers) {
              vm.answers = vm.out('Votre Réponse:', 'Your Answer:');
            }
            vm.answers = `${vm.answers}<br>•&nbsp;${vm.out(item.row_title.fr.title, item.row_title.en.title)} - ${vm.out(item.column_title.fr.title, item.column_title.en.title)}`;
            vm.candidate.questionnaires.ans.push(mcData);
            vm.ansToSave.push(mcData);
          });
          vm.tableAns = [];
        }
      } else {
        if (data.type === 'mc-ss') {
          data.choice_id = vm.answers.id;
          let titleTranslated = getEnAndFrTranslations(vm.answers);
          vm.answers = vm.out(titleTranslated.fr.title, titleTranslated.en.title);
        }
        if (data.type === 'yes-no') {
          data.boolAnswer = !!(vm.answers === 'Yes' || vm.answers === 'Oui');
        }
        if (data.type === 'scale') {
          data.scale = vm.answers;
          vm.answers = vm.answers.toString();
        }
        if (data.type === 'desc') {
          data.text = vm.answers;
        }
        if (data.type === 'format') {
          if (data.format === 'date') {
            if (vm.answers.length == 8) {
              const day = vm.answers.slice(0, 2);
              const month = vm.answers.slice(2, 4);
              const year = vm.answers.slice(4, 8);
              vm.answers = `${day}/${month}/${year}`;
              const validated = validateDate(vm.answers);
              if (validated == true) {
                data.text = vm.answers;
              } else {
                notValidatedDate(vm.answers);
              }
            } else {
              notValidatedDate(vm.answers);
            }
          } else if (data.format === 'address') {
            vm.isBugNumberAddress = false;
            vm.incompleteAddress = '';
            const result = structureLocation();
            if (result === 'success') {
              vm.answers = (vm.aptNo ? `${vm.aptNo}-` : '') + vm.selectedLocation.formatted_address;
              data.text = vm.answers;
            } /* @temp 
              - needs to be tested - we can't set google_maps_error here, 
              - as vm.answer can be filled by only user input, we can't stop the application but show a proper msg

                else if (result === 'google_maps_error') {
                  googlePlacesCheck();
                  vm.answers = null;
                  vm.catherineTyping = false;
                  addressErrorMsg(result);
                  $scope.stopApplying = true;
                  vm.required = '';
            } */ 
            else {
              googlePlacesCheck();
              vm.wrongAnswers = vm.answers ? (!_.isEmpty(vm.selectedLocation) && vm.selectedLocation.formatted_address ? vm.selectedLocation.formatted_address : vm.answers) : `${vm.out('(Aucune)', '(None)')}`;
              vm.answers = null;
              addressErrorMsg(result);
            }
          } else if (data.format === 'phone-number') {
            const areaCode = vm.answers.slice(0, 3);
            const midCode = vm.answers.slice(3, 6);
            const lastCode = vm.answers.slice(6, 10);

            if (vm.answers.length == 10) {
              vm.answers = `(${areaCode}) ${midCode}-${lastCode}`;
              data.text = vm.answers;
            } else if (vm.answers.length > 0) {
              vm.answers = null;
              vm.wrongAnswers = `(${areaCode}) ${midCode}-${lastCode}`;
              vm.postCandidateMsg({ text: vm.wrongAnswers, isValid: false });
              msgEn = 'Sorry! This is not a valid phone number.<br>Please enter a valid phone number.';
              msgFr = "Désolé! Ce n'est pas un numéro de téléphone valide.<br>S'il vous plaît entrer un numéro de téléphone valide.";
              vm.postCatherineMsg({ msgEn, msgFr });
            }
          }
        }
        if (vm.answers) {
          vm.candidate.questionnaires.ans.push(data);
          vm.ansToSave.push(data);
        }
      }

      if (vm.answers) {
        vm.tempCounter++;
        if (vm.tempCounter == 1) {
          saveAnswerApi(branch, data);
        }
      }
    }

    function saveAnswerApi(branch, data) {
      const ans = vm.ansToSave;
      let isDone = 1;
      ans.forEach((item) => {
        item.user_id = parseInt(vm.candidate.id, 10);
        item.account_id = parseInt(vm.candidate.account_id, 10);
        item.email = vm.candidate.email ?? localStorage.getItem("user_email");
        if (!item.defaultQuestion) {
          item.job_id = vm.jobId; // save answers to default questionnaire without jobId
        }
        vm.catherineTyping = true;
        api.service_post('toolkit', 'questionnaire/answers/open', item).then(() => {
          if (isDone === ans.length) {
            vm.catherineTyping = false;
            vm.currentQuestion += 1;
            vm.required = 'waiting';
            vm.postCandidateMsg({ text: vm.answers, isValid: true });
            vm.hasBranchQues(branch, data);
          } else {
            isDone += 1;
          }
        }).catch(() => {
          vm.catherineTyping = false;
          msgEn = 'An error occurred while saving your response.<br>Please refresh the page and try again.<br>If the error persists, please contact our support team at support@workland.com.';
          msgFr = 'Une erreur s\'est produite lors de l\'enregistrement de votre réponse.<br>Veuillez actualiser la page et réessayer.<br>Si l\'erreur persiste, veuillez contacter notre équipe d\'assistance à support@workland.com.';
          vm.postCatherineMsg({ msgEn, msgFr });
        });
      });
      // vm.autocomplete = null;
      vm.selectedLocation = {};
      if (vm.buildingNo) vm.buildingNo = null;
      if (vm.aptNo) vm.aptNo = null;
    }


    function disqualify() {
      vm.candidate.questionnaires.status = 'disqualified';
      submitDisqualifiedApplication();
    }

    function setAccountInactive() {
      var data = {
        status: 'disqualified_by_registration_questionnaire'
      }
      api.service_post('accounts', 'accounts/'+vm.candidate.account_id+'/change-status', data, 'update');
    }

    function submitDisqualifiedApplication() {
      vm.catherineTyping = true;
      if (vm.candidate.applicationId) {
        applicationService.patch_query('application', vm.candidate.applicationId, 'submit', {
          qualifies: false,
        }).then((response) => {
          if (response.status == 200 || response.status == 201) {
            vm.candidate.applicationId = response.data.application_id;
            vm.catherineTyping = false;
            // @agency: can add conditions for agency specific reasons based on cookies mode
            msgEn = "<b>We're sorry to inform you that your application has been rejected as it does not meet the qualifications required for this position.<br>Thank you for your interest.</b>";
            msgFr = '<b>Nous sommes désolés de vous informer que votre candidature a été rejetée puisqu’elle ne correspond pas aux qualifications exigées pour ce poste.<br>Merci de l’intérêt manifesté.</b>';
            vm.postCatherineMsg({ msgEn, msgFr });
          }  else {
            vm.catherineTyping = false;
            msgEn = 'Application submission error. Please contact <b>support@workland.com</b>.<br>You can also consult the jobs list.';
            msgFr = 'Erreur de dépôt de candidature. SVP contactez <b>support@workland.com</b>.<br>Vous pouvez également consulter la liste des emplois.';
            vm.postCatherineMsg({ msgEn, msgFr });
          }
        }).catch(() => {
          vm.catherineTyping = false;
          msgEn = 'Application submission error. Please contact <b>support@workland.com</b>.<br>You can also consult the jobs list.';
          msgFr = 'Erreur de dépôt de candidature. SVP contactez <b>support@workland.com</b>.<br>Vous pouvez également consulter la liste des emplois.';
          vm.postCatherineMsg({ msgEn, msgFr });
        });
      } else {
        // default registration questionnaires not attached to any job!
        vm.catherineTyping = false;
        // @agency: can add conditions for agency specific reasons based on cookies mode and candidate account role:
        //1) for candidates who register (not apply to job); 2) for clients - set account inactive
        if (vm.candidate.account_role == 70) {
          msgEn = "<b>We're sorry to inform you that your application has been rejected as it does not meet the qualifications required for this position.<br>Thank you for your interest.</b>";
          msgFr = '<b>Nous sommes désolés de vous informer que votre candidature a été rejetée puisqu’elle ne correspond pas aux qualifications exigées pour ce poste.<br>Merci de l’intérêt manifesté.</b>';
        }
        if (vm.candidate.account_role == 40) {
          // @agency: need to add specific reasons for other agencies when they will have them
          msgEn = "<b>Thank you for your interest.</b>";
          msgFr = '<b>Merci de l’intérêt manifesté.</b>';
          vm.setAccountInactive();
        }
        vm.postCatherineMsg({ msgEn, msgFr });
      }
    }

    function structureLocation() {
      let street_number; let street_name; let city; let province; let country; let postalCode;
      let replacement = '';
      let arrayOfCityReplacement = [];
      if (!_.isEmpty(vm.selectedLocation) && vm.selectedLocation) {
        if (vm.selectedLocation.address_components && vm.selectedLocation.address_components.length) {
          for (let ac = 0; ac < vm.selectedLocation.address_components.length; ac++) {
            const component = vm.selectedLocation.address_components[ac];
            switch (component.types[0]) {
              case 'street_number':
                street_number = component.long_name;
                break;
              case 'route':
                street_name = component.long_name;
                break;
              case 'locality':
                city = component.long_name;
                break;
              case 'administrative_area_level_1':
                province = component.long_name;
                break;
              case 'sublocality_level_1':
                arrayOfCityReplacement.splice(0, 0, component.long_name);
                break;
              case 'sublocality_level_2':
                arrayOfCityReplacement.push(component.long_name);
                break;
              case 'administrative_area_level_3':
                arrayOfCityReplacement.push(component.long_name);
                break;
              case 'sublocality':
                arrayOfCityReplacement.push(component.long_name);
                break;
              case 'neighborhood':
                arrayOfCityReplacement.push(component.long_name);
                break;
              case 'country':
                country = component.long_name;
                break;
              case 'postal_code':
                postalCode = component.long_name;
                break;
              case 'administrative_area_level_2':
                replacement = component.long_name;
                break;
            }
          }
        }

        // order is important - make sure to have a street before to give street number error
        if (!street_name) {
          return 'invalid_address';
        }
        if (!street_number) {
          if (vm.buildingNo) {
            vm.selectedLocation.formatted_address = `${vm.buildingNo} ${vm.selectedLocation.formatted_address}`;
          } else {
            vm.isBugNumberAddress = true;
            vm.incompleteAddress = vm.selectedLocation.formatted_address;
            return 'street_number';
          }
        }
        if (!city) {
          if(!arrayOfCityReplacement.length && !replacement) {
            return 'invalid_address';
          }
          city = arrayOfCityReplacement.length ? arrayOfCityReplacement[0] : replacement;
        }
        if(!province) {
          province = replacement;
        }

        return 'success';
      }

      return vm.answers ? 'address_error' : 'not_filled';
      // return vm.answers ? 'google_maps_error' : 'not_filled';
    }

    function init() {
      if (vm.stage === 'openIsed') {
        vm.candidate.questionnaires = { ans: [], status: 'qualified' };
        vm.currentQuestionnaires = 0;
        vm.currentQuestion = 0;
        vm.catherineTyping = true;
        msgEn = "We'd like you to answer some questions related to your skills, knowledge and status.";
        msgFr = 'Veuillez répondre aux questions suivantes.';
        if (vm.questionnaires.length > 1) {
          msgEn = `${msgEn}<br><i>(Please Note: This test is divided into ${vm.questionnaires.length} parts.)</i>`;
          msgFr = `${msgFr}<br><i>(Remarque: ce questionnaire est divisé en ${vm.questionnaires.length} parties.)</i>`;
        }
        if (vm.candidate.account_role == 70) {
          vm.postCatherineMsg({ msgEn, msgFr });
        }
        vm.loadQuestionnaire(vm.questionnaires);
      }
    }


    function setScaleAnswered(sliderId, index, highValue) {
      vm.answers = index;
    }

    vm.options = {
      date: {
        date: true,
      },
      custom: {
        numericOnly: true,
        delimiters: [' (', ') ', '-'],
        blocks: [0, 3, 3, 4],
      },
    };

    $scope.$watch('vm.stage', () => {
      vm.init();
    });

    angular.extend(vm, vmExtend);
  }

  openIsedQuestionsCtrl.$inject = [
    '$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    'api',
    '$timeout',
    'applicationService',
  ];
  const app = angular.module('atlas');
  app.directive('openIsedQuestionsModule', () => ({
    scope: {
    },
    bindToController: {
      postCatherineMsg: '&',
      postCandidateMsg: '&',
      candidate: '=',
      jobId: '=',
      questionnaires: '=',
      isedCallback: '&',
      catherineTyping: '=',
      stage: '=',
      errorIsedCallback: '&',
      customColor: '=',
    },
    controller: openIsedQuestionsCtrl,
    controllerAs: 'vm',
    templateUrl: './atlas/directives/job-apply/open-ised-questions-module/open-ised-questions-module.template.html',
  }));
}(angular));
