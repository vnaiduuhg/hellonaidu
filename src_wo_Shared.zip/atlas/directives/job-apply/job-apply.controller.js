(function (angular) {
  function JobApplyCtrl(
    $scope,
    $rootScope,
    api,
    utils,
    $filter,
    $location,
    MetaTagsService,
    $state,
    $stateParams,
    storageService,
    $timeout,
    $anchorScroll,
    _,
    authService,
    $cookies,
  ) {
    let vmExtend = {
      out: utils.out,
      trustAsHtml: utils.trustAsHtml,
      applicationChat: [],
      hasPreError: false,
      stopApplying: false,
      isConsentAgreed: false,
      reApply: false,
      hasAgreedToConsent: null,
      isMicrosoftLogin: false,
      urlParamsToSubmit: {},
      loginHash: null,
    };
    angular.extend($scope, vmExtend);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on("$destroy", () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    const { out } = utils;
    let msgEn,msgFr;
    if ($stateParams.source) {
      $scope.source = $stateParams.source;
    } else if (utils.getUrlParam('source')) {
      $scope.source = utils.getUrlParam('source');     
      storageService.setItem('source', $scope.source);
    } else {
      $scope.source = storageService.getItem('source') ? storageService.getItem('source') : 'Workland';
    }

    function consultJobsList() {
      $scope.companySlug = null;
      api.service_post('accounts', 'accounts/default-profiles', { account_ids: [$scope.job.account_id] })
        .then((profilesData) => {
          if (profilesData.data.data) {
            const profile = profilesData.data.data[$scope.job.account_id];
            $scope.companySlug = profile.slug;
            if ($scope.companySlug) {
              authService.getToken().then(
                (response) => {
                  if (response) {
                    window.location = `${window.appConfig.ATLAS_UI_URL}careers/${$scope.companySlug}?open=jobs`;
                  } else {
                    $state.go('companyDescription', { company: $scope.companySlug, open: 'jobs' });
                  }
                },
                (err) => {
                  window.location = `${window.appConfig.ATLAS_UI_URL}careers/${$scope.companySlug}?open=jobs`;
                },
              );
            } else {
              $state.go('jobsList');
            }
          } else {
            $state.go("jobsList");
          }
        }).catch(() => {
          $state.go('jobsList');
        });
    }

    function scrollToBottom() {
      $location.hash('bottom');
      $anchorScroll();
    }

    function postCatherineMsg(msgEnglish, msgFrench, extra) {
      $scope.msgObject = {
        msgBy: 'catherine',
        msgContentEn: msgEnglish,
        msgContentFr: msgFrench,
        extra,
        msgDateTime: new Date(),
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function postCandidateMsg(text, isvalid, docAttached, docIndex) {
      $scope.msgObject = {
        msgBy: "candidate",
        msgContent: text,
        msgDateTime: new Date(),
        isValid: isvalid,
        isDoc: docAttached,
        docIndex,
      };
      $scope.applicationChat.push($scope.msgObject);
      scrollToBottom();
    }

    function jobFetchErrorMessage(detail) {
      $scope.job = [];
      $scope.hasPreError = true;
      $scope.preErrorMsg = out("Désolé, une erreur s'est produite lors de la récupération ",
        'Sorry, there was an error while fetching ') + detail;
    }

    function readAllQuestionnairesAttachedToCandidates(agencyAccountId) {
      api.service_post( "toolkit", "questionnaire/agency-candidate-questionnaire/read-all",
        {
          agency_account_id: [agencyAccountId],
          is_active: true,
        }
      ).then((response) => {
        if (response.data.length > 0) {
          angular.forEach(response.data, (questionnaire) => {
            $scope.job.questionnaires.push(questionnaire); // add active registration questionnaires
          });
        }
      }) .catch(() => {
        // stop applying process
        $scope.stopApplying = true;
        jobFetchErrorMessage(
          out("du questionnaire.", "the questionnaire(s).")
        );
      });
    }

    function checkApplicationType() {
      $scope.candidate.id = storageService.getItem("userId");
      $scope.candidate.account_id = storageService.getItem("account_id");
      $scope.candidate.email = storageService.getItem("user_email");
      $scope.candidate.questionnaires = { ans: [], status: "qualified" };
      // @todo check what will be in the storage for logged in user
      if ($scope.candidate.id) {
        $scope.applicationType = "regular";
        $scope.candidate.loginSwich = 0;
        if (storageService.getItem("account_type") !== "candidate") {
          // we make sure that user is logged in is a candidate
          const accounts = JSON.parse(storageService.getItem("accounts"));
          $scope.candidate.loginSwich = 2; // candidate has no candidate account
          if (accounts) {
            _.each(accounts, (acc) => {
              if (acc.account.type === "candidate") {
                $scope.candidate.is_candidate = acc.account_id;
                $scope.candidate.loginSwich = 1; // candidate can switch to candidate account
                $scope.candidateAccAlreadyExist = true;
              }
            });
          }
        } else {
          $scope.candidateAccAlreadyExist = true;
        }
      } else {
        $scope.applicationType = "quick";
      }
      $timeout(() => {
        $scope.candidate.loginStatus = $scope.applicationType;
        $scope.stage = "identifyUser";
      }, 150);    
    }

    function indentifyUserCallback() {
      $scope.catherineTyping = false;
      $scope.stage = "uploadDocuments";
    }

    function isedCallback() {
      $scope.catherineTyping = true;
      $scope.candidate.applicationStatus = "submitted";
      $scope.stage = "applyJob";
    }

    function uploadDocumentsCallback() {
      $scope.catherineTyping = false;
      if ($scope.job.questionnaires.length === 0) {
        isedCallback();
      } else {
        $scope.stage = "openIsed";
      }
    }

    function compare(a, b) {
      return Number(a.document_type_id) - Number(b.document_type_id);
    }

    function continueApplication(isConsentAgreed) {
      $scope.required = null;
      if (!isConsentAgreed) {
        msgFr = "Désolé, vous ne pouvez pas poursuivre votre application puisque vous avez choisi de ne pas consentir à la clause de confidentialité des données.";
        msgEn ='Unfortunately, you cannot proceed with your application as you have chosen not to consent to the data privacy clause.';
        postCatherineMsg(msgEn, msgFr);
        $scope.reApply = true;
        return false;
      }
      msgFr = "Vous avez lu et accepté.";
      msgEn = "You have read and agreed.";
      postCatherineMsg(msgEn, msgFr);
      checkApplicationType();
    }

    function createConsentMessage(companyName) {
      const companyNames = {
        en: companyName.toLowerCase() !== 'workland' ? `${companyName} and Workland` : `${companyName}`,
        fr: companyName.toLowerCase() !== 'workland' ? `${companyName} et Workland` : `${companyName}`,
      }
      const user = {
        en: !$rootScope.currentUser ? 'registering your email address and ' : '',
        fr: !$rootScope.currentUser ? 'inscrivant votre courriel et ' : '',
      }
      msgFr = `En ${user.fr}répondant aux requis pour déposer votre candidature pour ce poste, vous consentez à autoriser 
        ${companyNames.fr} à détenir, héberger et archiver vos données personnelles. <br/><br/>
        Je suis conscient que le dossier qui sera constitué sur ma candidature sera accessible à toutes personnes de 
        ${companyName} participant au processus d’embauche. Mon dossier sera ensuite conservé dans la banque de candidats de l’organisation 
        selon ses normes et règles de rétention de documentation, à moins que j’en demande par écrit, la destruction.<br/><br/>`;
      msgEn = `By ${user.en}completing the requirements to complete your application for this position, you agree to allow 
        ${companyNames.en} to hold, store and archive your personal data.<br/><br/>
        I am aware that my application will be accessible to all ${companyName} persons involved in the hiring process. My application will then be kept 
        in the organization's candidate database according to their document retention standards and rules unless I request its destruction in writing.<br/><br/>`;
        postCatherineMsg(msgEn, msgFr);
        $scope.required = 'consent';
    }

    function displayDocName(doc) {
        let docName = {};
        docName.docNameFr = doc.descriptionFr ? doc.descriptionFr : doc.name_fr;
        docName.docNameEn = doc.descriptionEn ? doc.descriptionEn : doc.name;
        return $scope.out(docName.docNameFr, docName.docNameEn);
    }

    function fetchJobInfo() {
      $scope.jobDataReady = false;
      $scope.customColor = {};
      if ($stateParams.jobId) {
        $scope.jobId = $stateParams.jobId;
      } else if (utils.getUrlParam('jobId')) {
        $scope.jobId = utils.getUrlParam('jobId');
        storageService.setItem('jobIdClicked', $scope.jobId); 
      } else {
        $scope.jobId = storageService.getItem('jobIdClicked');
      }
      if (!$scope.jobId) {
        // @to be replaced
        jobFetchErrorMessage(out("des détails du poste.", "job details."));
        $scope.customColor.color = 'rgb(0,90,135)';
      } else {
        const promise = api.service_get('jobs', `job/${$scope.jobId}`);
        promise.then((response) => {
          if (response.status === 200 && (response.data.published_external || response.data.published_internal || response.data.published_outsourced)) {
            $scope.job = response.data;
            if ($scope.job.required_documents.length === 0) {
              $scope.job.required_documents.push({ document_type_id: 1, is_optional: 0, required_number: 1 });
            }
            const docsArray = [];
            angular.forEach($scope.documentTypes, (docType) => {
              angular.forEach($scope.job.required_documents, (doc) => {
                if (doc.document_type_id === docType.id) {
                  doc.name = docType.name;
                  doc.name_fr = docType.name_fr;
                  doc.descriptionFr =  doc.translations?.fr?.description ?  doc.translations?.fr?.description : null;
                  doc.descriptionEn =  doc.translations?.en?.description ?  doc.translations?.en?.description : null;
                  doc.docTranslatedName = displayDocName(doc);
                  docsArray.push(doc);
                  for (let i = doc.required_number - 1; i >= 1; i -= 1) {
                    const newDoc = angular.copy(doc);
                    docsArray.push(newDoc);
                  }
                }
              });
            });
            $scope.requiredDocs = docsArray.filter(doc => !doc.is_optional).sort(compare);
            $scope.optionalDocs = docsArray.filter(doc => doc.is_optional).sort(compare);
            $scope.jobDocuments = $scope.requiredDocs.concat($scope.optionalDocs);
            // active questionnaires attached to the job
            if ($scope.job.questionnaires.length > 0) {
              $scope.job.questionnaires = $filter('filter')($scope.job.questionnaires, (item) => item.is_active === 1 && item.is_private === 0);
            }
            // Get account profile data of the job owner
            api.service_post("accounts", "accounts/default-profiles", {
                account_ids: [$scope.job.account_id],
              }).then((profilesData) => {
                $scope.jobDataReady = true;
                if (profilesData.data.data) {
                  const profile = profilesData.data.data[$scope.job.account_id];
                  $scope.employerData = profilesData.data.data;                  
                  $scope.customColor.color =  $scope.employerData[$scope.job.account_id].color;

                  $scope.job.companyName = profile.name;
                  if (profile.logo) {
                    $scope.job.logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/${profile.logo}`;
                  } else {
                    $scope.job.logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/generic_logo.png`;
                  }

                  if ($scope.employerData[$scope.job.account_id].alternate_logo_2){
                    $scope.secondLogoUrl = `${window.appConfig.MINIO_URL}media/Profile/Logos/${profile.alternate_logo_2}`;
                  } else {
                    $scope.secondLogoUrl = $scope.job.logo;
                  }

                  if (profile.banner) {
                    $scope.job.banner = `${window.appConfig.MINIO_URL}media/Profile/Banners/${profile.banner}`;
                  } else {
                    $scope.job.banner = `${window.appConfig.MINIO_URL}media/Profile/Banners/generic_banner.jpg`;
                  }

                  if ($scope.hasAgreedToConsent && +$scope.hasAgreedToConsent === +$scope.jobId) {
                    $scope.isConsentAgreed = true;
                    checkApplicationType();
                  } else {
                    createConsentMessage($scope.job.companyName);
                  }
                }
              }).catch(() => {
                jobFetchErrorMessage(out('des détails du poste. Veuillez réessayer.', 'job details. Please retry.'));
                $scope.customColor.color = 'rgb(0,90,135)';
              })
            // add registration questionnaires for the jobs of clients and agencies
            api.service_get('accounts', `accounts/${$scope.job.account_id}/type`).then((resp) => {
              let agencyAccountId;

              if (resp.data.data && resp.data.status === 'success') {
                if (resp.data.data === 'client') {
                  api.service_get('accounts', `accounts/clients/${$scope.job.account_id}/agency-account-id`)
                    .then((result) => {
                      agencyAccountId = result.data.data;
                      readAllQuestionnairesAttachedToCandidates(agencyAccountId);
                    });
                } else if (resp.data.data === 'agency') {
                  agencyAccountId = $scope.job.account_id;
                  readAllQuestionnairesAttachedToCandidates(agencyAccountId);
                }
              } else {
                // stop applying process
                $scope.stopApplying = true;
                jobFetchErrorMessage(out('du questionnaire.', 'the questionnaire(s).'));
              }
            }).catch(() => {
              // stop applying process
              $scope.stopApplying = true;
              jobFetchErrorMessage(out('du questionnaire.', 'the questionnaire(s).'));
            });
            // end for agencies and clients
            msgEn = "Hello, my name is <b>Atlas</b>, I'm here to help you with your job search!";
            msgFr = 'Bonjour , mon nom est Atlas et je vais vous aider dans le processus de dépôt de votre candidature pour ce poste .';
            postCatherineMsg(msgEn, msgFr);            
          }
        }).catch(() => {
          jobFetchErrorMessage(out('des détails du poste. Veuillez réessayer.', 'job details. Please retry.'));
           $scope.customColor.color = 'rgb(0,90,135)';
        });
      }
    }

    function getDocumentTypes() {
      return api.service_get('toolkit', 'document-manager/candidate-file-versions/document-types').then((response) => {
        $scope.documentTypes = response.data.message;
      });
    }

    function init() {
      const regExp = new RegExp("jobillico", "i");
      if ($scope.source && regExp.test($scope.source)) {
        $scope.source = "Jobillico";
      }
      $scope.candidateAccAlreadyExist = false;
      $scope.worklandAvatar = "./../assets/images/robot_talk.png";
      $scope.candidate = { doc: [] };
      $scope.hasAgreedToConsent = +storageService.getItem('has_agreed_to_consent');
      if ($scope.hasAgreedToConsent) storageService.removeItem('has_agreed_to_consent');
      $scope.loginHash = $cookies.get("loginHash");
      getDocumentTypes().then(() => {
        fetchJobInfo();
      });

      const urlString = $location.$$search;
      if (urlString.newsletter) $scope.urlParamsToSubmit.newsletter = urlString.newsletter;
      if (urlString["job-alert"]) $scope.urlParamsToSubmit.jobAlert = urlString["job-alert"];
    }

    init();
    vmExtend = {
      postCatherineMsg,
      postCandidateMsg,
      indentifyUserCallback,
      uploadDocumentsCallback,
      isedCallback,
      consultJobsList,
      continueApplication,
    };
    angular.extend($scope, vmExtend);
  }
  JobApplyCtrl.$inject = [
    '$scope',
    '$rootScope',
    'api',
    'utils',
    '$filter',
    '$location',
    'MetaTagsService',
    '$state',
    '$stateParams',
    'storageService',
    '$timeout',
    '$anchorScroll',
    '_',
    'authService',
    '$cookies',
  ];
  const app = angular.module('atlas');
  app.controller('JobApplyCtrl', JobApplyCtrl);
  app.directive('jobApply', () => ({
    scope: {
    },
    controller: JobApplyCtrl,
  }));
  // eslint-disable-next-line no-undef
}(angular));
