(function (angular) {
  function identifyUserCtrl(
    $scope,
    $rootScope,
    utils,
    _,
    worklandLocalize,
    $timeout,
    authService,
    storageService,
    applicationService,
    userAccountsService,
    api,
    $q,
    $location,
  ) {
    const vm = this;
    let msgEn;
    let msgFr;
    vm.nameFormat = /^[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]+(([',. -][áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z ])?[áàíóúöñùûüÿâæçéèêëïîôœa-zA-Z]*)*$/;
    vm.emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    vm.phoneFormat = /((?:\+|00)[17](?: |\-)?|(?:\+|00)[1-9]\d{0,2}(?: |\-)?|(?:\+|00)1\-\d{3}(?: |\-)?)?(0\d|\([0-9]{3}\)|[1-9]{0,3})(?:((?: |\-)[0-9]{2}){4}|((?:[0-9]{2}){4})|((?: |\-)[0-9]{3}(?: |\-)[0-9]{4})|([0-9]{7}))/;

    const vmExtend = {
      out: utils.out,
      strings: worklandLocalize.strings,
      imagesUrl: './../../../../assets/images/',
      candidateInput,
      hasAlreadyApplied,
      skipLogin,
      newAccountForEmployer,
      startAgain,
      switchAccountType,
      microsoftLogin,
      ssoLoginLoader: false,
      idpsList: [],
      idpListFail: false,
      socialConnectionLoader: false,
      isInternalApplication: false,
      microsoftLoginFollow,
      showMSLoginBtn: true,
    };

    function identifyUserCallBack() {
      if (vm.candidate.applicationId) {
        vm.required = 'waiting';
        vm.catherineTyping = true;
        vm.indentifyUserCallback();
        // Move to downlod documents step
      } else {
        stopApplicationProcess(true);
      }
    }

    function stopApplicationProcess(showJobsList) {
      vm.catherineTyping = false;
      msgEn = 'There was an error in application process. Please try again later or contact <b>support@workland.com</b>.<br>You can also consult the jobs list.';
      msgFr = "Une erreur s'est produite dans le processus d'application. Veuillez réessayer plus tard ou contactez <b>support@workland.com</b>.<br>Vous pouvez également consulter la liste des emplois.";
      vm.postCatherineMsg({ msgEn, msgFr });
      if (showJobsList) {
        $timeout(() => {
          vm.required = 'consultListJob';
        }, 300);
      }
    }

    function procedeToApplication() {
      vm.catherineTyping = true;
      // @param status is incomplete by default when not sent
      const data = {
        candidate_user_id: vm.candidate.id,
        candidate_account_id: vm.candidate.account_id,
        employer_account_id: vm.job.account_id,
        job_id: vm.jobId,
        source_name: vm.source,
        is_external: vm.candidate.isInternalApplication ? 0 : 1,
      };
      // check if applicant has internal job token
      const internalJobToken = utils.getUrlParam('token');
      if (internalJobToken) {
        data.internal_job_token = internalJobToken;
        data.is_external = 0;
      }
      applicationService.post_query('application', data).then((res) => {
        const response = res.data;
        if (res.status === 201 || res.status === 200) {
          vm.candidate.applicationId = response.id;
          identifyUserCallBack();
        } else { // for 404 or 422 status code
          stopApplicationProcess(true);
        }
      }).catch(() => {
        vm.catherineTyping = false;
        stopApplicationProcess(true);
      });
    }

    function hasAlreadyApplied(cadId) {
      vm.catherineTyping = true;
      const data = {
        candidate_user_id: [cadId],
        job_id: [vm.jobId],
      };
      applicationService.post_query('application/read-all', data).then((response) => {
        if (response.status === 200 || response.status === 201) {
          const { data } = response;
          if (data.length > 0) {
            vm.catherineTyping = false;
            vm.candidate.applicationId = data[0].id;
            vm.candidate.applicationStatus = data[0].status;
            if (data[0].status === 'submitted') {
              msgFr = 'Oups! Il semble que vous avez déjà postulé à ce poste';
              msgEn = "Oops! It looks like you've already applied to this job";
              $timeout(() => {
                vm.required = 'consultListJob';
              }, 300);
              if (!vm.candidate.isInternalApplication) {
                msgFr = `${msgFr}, aimeriez-vous chercher un autre emploi?`;
                msgEn = `${msgEn}, would you like to look for another job?`;
                vm.postCatherineMsg({ msgEn, msgFr });
              } else {
                vm.postCatherineMsg({ msgEn, msgFr });
              }
            } else {
              identifyUserCallBack();
            }
          } else {
            vm.catherineTyping = false;
            vm.candidate.applicationStatus = 'incomplete';
            procedeToApplication();
          }
        } else { // for 404 or 422 status code
          vm.catherineTyping = false;
          stopApplicationProcess(!vm.candidate.isInternalApplication);
        }
      }).catch(() => {
        vm.catherineTyping = false;
        stopApplicationProcess(!vm.candidate.isInternalApplication);
      });
    }

    function sendNewActivationLink(accountId) {
      vm.catherineTyping = true;
      // @todo to be replaced
      authService.getActivationKey(accountId, { language: $rootScope.language }).then((res) => {
        vm.catherineTyping = false;
        const result = res.data;
        if (result.status === 'success' && result.code === 201) {
          msgFr = "Il semble que votre compte candidat est inactif. Un nouveau lien d'activation pour votre compte vous a été envoyé. Consultez vos courriels pour terminer l'inscription.";
          msgEn = 'Looks like your candidate account is inactive. A new account activation link has been sent to your email address. Please check your inbox to finalize your registration.';
        } else {

        }
        vm.postCatherineMsg({ msgEn, msgFr });
        hasAlreadyApplied(vm.candidate.id);
      }).catch(() => {
        msgFr = "Un problème est survenu et le lien n'a pu être envoyé. SVP contactez support@workland.com. Vous pouvez néanmoins continuer votre application";
        msgEn = "A problem occured and the link couldn't have been sent. Please contact support@workland.com. You can still continue your application";
        vm.postCatherineMsg({ msgEn, msgFr });
        // @@@@@@@should we stop the process here?
        hasAlreadyApplied(vm.candidate.id);
      });
    }

    // @in progress
    function isRegisteredUser(emailID) {
      vm.candidateInputText = '';
      vm.catherineTyping = true;
      api.service_post('accounts', 'accounts/find', {
        email: emailID,
        type: 'candidate',
      }).then((res) => {
        if (res.data.status === 'success') {
          if (Object.keys(res.data.data).length > 0) { // user found
            if (res.data.data.account_id) { // has candidate account
              if (res.data.data.account_status === 'activated') { // active candidate account
                vm.catherineTyping = false;
                msgEn = "Looks like you're a registered user.<br>You can <b>login</b> and use your uploaded documents for this application, <b>or</b> simply click <b>SKIP</b>.";
                msgFr = 'Il semble que vous êtes un utilisateur enregistré. <br> Vous pouvez <b>vous connecter</b> et utiliser les documents téléchargés pour cette application, <b>ou</b> simplement cliquer sur <b>SAUTER</b>.';
                vm.postCatherineMsg({ msgEn, msgFr });
                $timeout(() => {
                  vm.required = 'password';
                  vm.label = vm.out('Mot de passe', 'Password');
                }, 300);
                // move to login or has applied check
              } else { // inactive candidate account
                $scope.accountIdToActivate = res.data.data.account_id;
                sendNewActivationLink($scope.accountIdToActivate);
                // then move to has applied check
              }
              vm.candidate.account_status = res.data.data.account_status;
              vm.candidate.account_id = res.data.data.account_id;
              vm.candidate.account_type = 'candidate';
              vm.candidate.account_role = 70;
              vm.candidateAccAlreadyExist = true;
            } else { // registered user but not a candidate
              vm.catherineTyping = false;
              msgEn = "Looks like you're a registered user, but not as a candidate.<br>Would you like me to create your candidate account or would you like to proceed with another email address?";
              msgFr = 'Il semble que vous êtes un utilisateur enregistré, mais pas en tant que candidat. <br> Souhaitez-vous que je crée votre compte candidat ou aimeriez-vous utiliser une autre adresse courriel?';
              vm.postCatherineMsg({ msgEn, msgFr });
              $timeout(() => {
                vm.required = 'consent';
              }, 300);
              // move to register or start again
            }
            vm.candidate.id = res.data.data.user_id;
            vm.candidate.email = emailID;
          } else {
            // no registered user found
            vm.catherineTyping = false;
            vm.candidate.email = emailID;
            msgEn = 'Thank you! We also need your <b>full name</b> to proceed with your application.';
            msgFr = 'Merci! Nous avons également besoin de votre <b>nom complet</b> pour procéder à votre demande.';
            vm.postCatherineMsg({ msgEn, msgFr });
            $timeout(() => {
              vm.required = 'name';
              vm.label = vm.out('Prénom, nom', 'Full name');
              vm.placeholder = vm.out('Prénom et nom', 'First & last name');
            }, 300);
            // move register process
          }
        } else {
          // error
        }
      });
    }

    function refreshAccount(candAccId) {
      vm.catherineTyping = true;
      authService.refreshToken(candAccId).then((res) => {
        vm.catherineTyping = false;
        const refreshResponse = res.data;
        if (refreshResponse.status === 'success') {
          vm.candidate.loginStatus = 'regular';
          authService.saveToken(refreshResponse.data.token);
          // @temp need email
          userAccountsService.setCurrentUserAccount(refreshResponse);
          // re-set account_id in the storage
          vm.candidate.account_id = storageService.getItem('account_id');
          vm.candidate.isInternalApplication = !!getInternalCandidateDomain($rootScope.user_email);
          hasAlreadyApplied(vm.candidate.id);
          userAccountsService.getCurrentUserData();
        } else {
          switch (refreshResponse.message) {
            case 'Account has not been activated yet.':
              sendNewActivationLink($scope.accountIdToActivate);
              break;
            case 'Provided account_id is invalid.':
              msgEn = 'This account does not exist. Do you want to proceed with another email id?';
              msgFr = 'Ce compte est introuvable. Voulez-vous vous connecter avec un autre identifiant?';
              vm.postCatherineMsg({ msgEn, msgFr });
              vm.required = 'startAgain';
              break;
          }
        }
      }).catch(() => {
        stopApplicationProcess(false);
      });
    }

    function checkCredentials(pwd) {
      const regEx = /(.)/g;
      const hiddenPwd = pwd.replace(regEx, '*');
      const msg = hiddenPwd + vm.out('<br><i>(Vous avez entré le mot de passe ici.)</i>', '<br><i>(You entered password here.)</i>');
      vm.postCandidateMsg({ text: msg }, { isValid: false });
      vm.required = 'waiting';
      vm.catherineTyping = true;

      // case when a user clicks login
      authService.login({ email: vm.candidate.email, password: pwd }).then((res) => {
        vm.catherineTyping = false;
        if (res.data && res.data.status === 'success') {
          authService.saveToken(res.data.data.token);
          $rootScope.accounts = $scope.accounts = res.data.data.accounts ? res.data.data.accounts : [res.data.data.account];
          storageService.setItem('accounts', JSON.stringify($scope.accounts));
          if ($rootScope.currentUser) {
            const { user } = $rootScope.currentUser;
            $scope.fullName = `${user.first_name} ${user.last_name}`;
          }
          if ($rootScope.accounts.length > 1) {
            // case where user has more than 1 account
            let is_candidate = null;
            // @todo replace this
            _.each($scope.accounts, (acc) => {
              if (acc.account.type === 'candidate') {
                is_candidate = acc.account_id;
              }
            });

            if (is_candidate) {
              vm.candidate.loginStatus = 'regular';
              refreshAccount(is_candidate);
            } else {
              msgEn = "It looks like you don't have a candidate account.<br>Would you like me to create your candidate account, or would you like to proceed with another email address?";
              msgFr = "Il semble que vous n'êtes pas enregistré en tant que candidat.<br> Souhaitez-vous que je crée votre compte candidat, ou aimeriez-vous utiliser une autre adresse courriel?";
              vm.postCatherineMsg({ msgEn, msgFr });
              $timeout(() => {
                vm.required = 'consent';
              }, 300);
            }
          } else {
            // case where user has only 1 account
            vm.candidate.loginStatus = 'regular';
            // @temp need email
            userAccountsService.setCurrentUserAccount(res.data);
            hasAlreadyApplied(vm.candidate.id);
            userAccountsService.getCurrentUserData();
            // move to has applied check
          }
        } else {
          stopApplicationProcess(true);
        }
      }).catch((err) => {
        vm.catherineTyping = false;
        vm.candidateInputText = '';
        vm.required = 'password';
        if (err.data && err.data.code === 403) {
          $scope.forbiddenErrorMessage = true;
        } else if (err.data && err.data.code === 401 && err.data.message) { 
          switch (err.data.message) {
            case 'wrong_credentials': // Wrong password
              msgEn = 'Sorry! Your password is incorrect.<br> <b>Try again or skip</b> to proceed with your application.';
              msgFr = "Désolé! Votre mot de passe est invalide. <br> <b> Réessayez ou ignorez </ b> et procédez à l'application sans vous connecter.";
              break;
            case 'account_locked_login_attempts': // too many login attempts
              msgEn = 'You have been blocked for too many failed login attempts, please try again in 15 minutes or reset your password. <b>You can also proceed with the application without logging in</b>.';
              msgFr = "Vous avez été bloqué pour trop de tentatives de connexion infructueuses, veuillez réessayer dans 15 minutes ou réinitialisez votre mot de passe. <b>Vous pouvez également procéder à l'application sans vous connecter</b>.";
              break;
            default:
              msgEn = 'A problem occured while connecting. Please contact support@workland.com or continue without login.';
              msgFr = 'Un problème est survenu lors de la connexion. SVP contactez support@workland.com ou continuez sans vous connecter.';
          }
        } else if (err.data && err.data.code === 404) {
          switch (err.data.message) {
            case 'no_active_account_found': // Multiple accounts , none active
              msgEn = 'Sorry! Your account is inactive.<br> <b>Skip</b> You can proceed with your application without logging in.';
              msgFr = "Désolé! Votre compte est inactif. <br> Vous pouvez procéder à l'application sans vous connecter.";
              break;
            case 'account_has_not_been_activated_yet': // candidate account not activated
              msgEn = 'Sorry! Your account is awaiting activation.<br> Please <b> activate it or skip</b> to proceed with your application without logging in.';
              msgFr = "Désolé! Votre compte n'est pas activé. <br> Veuillez <b> l'activer ou ignorez </ b> et procédez à l'application sans vous connecter.";
              break;
            default:
              msgEn = 'A problem occured while connecting. Please contact support@workland.com or continue without login.';
              msgFr = 'Un problème est survenu lors de la connexion. SVP contactez support@workland.com ou continuez sans vous connecter.';
          }
        } else {
          msgEn = 'A problem occured while connecting. Please contact support@workland.com or continue without login.';
          msgFr = 'Un problème est survenu lors de la connexion. SVP contactez support@workland.com ou continuez sans vous connecter.';
        }
        vm.postCatherineMsg({ msgEn, msgFr });
      });
    }

    function newRegistration() {
      vm.required = 'waiting';
      vm.catherineTyping = true;
      const userAlreadyExist = !!vm.candidate.id;

      // here we register a candidate for an already existing user - else case for new candidate
      if (vm.candidate.id) {
        $scope.data = {
          user_id: vm.candidate.id,
          job_id: $scope.jobId,
        };
      } else {
        $scope.data = {
          email: vm.candidate.email,
          username: vm.candidate.email,
          first_name: vm.candidate.firstName,
          last_name: vm.candidate.lastName,
          phone: vm.candidate.phone,
          language: $rootScope.language,
          job_id: $scope.jobId,
        };
      }

      // @new registration service @todo check error mesages from BE
      authService.registerCandidate($scope.data).then((res) => {
        vm.catherineTyping = false;
        if (res.data.status === 'success' || (res.data.status === 'fail' && res.data.message === 'Candidate account already exists for the user')) {
          vm.candidate.account_id = res.data.data.account.id;
          vm.candidate.account_type = 'candidate';
          vm.candidate.account_role = 70;
          vm.candidate.id = vm.candidate.id ? vm.candidate.id : res.data.data.user.id;
          hasAlreadyApplied(vm.candidate.id);
          userAccountsService.getCurrentUserData();
          vm.candidateAccAlreadyExist = userAlreadyExist;
        } else {
          msgEn = 'A problem occured while creating your account. Please contact <b>support@workland.com</b>.';
          msgFr = 'Un problème est survenu lors de la création de votre compte. Veuillez contacter <b>support@workland.com</b>.';
          vm.postCatherineMsg({ msgEn, msgFr });
          stopApplicationProcess(true);
        }
      }).catch(() => {
        vm.catherineTyping = false;
        msgEn = 'A problem occured while creating your account. Please contact <b>support@workland.com</b>.';
        msgFr = 'Un problème est survenu lors de la création de votre compte. Veuillez contacter <b>support@workland.com</b>.';
        vm.postCatherineMsg({ msgEn, msgFr });
        stopApplicationProcess(true);
      });
    }

    function splitFullName() {
      vm.candidate.firstName = vm.candidateInputText;
      vm.candidate.lastName = vm.candidateInputTextLastName ? vm.candidateInputTextLastName : vm.candidateInputText;
      vm.candidate.fullname = vm.candidateInputText + (vm.candidateInputTextLastName ? ` ${vm.candidateInputTextLastName}` : '');
      vm.postCandidateMsg({ text: vm.candidate.fullname, isValid: true });
      $timeout(() => {
        msgEn = `Hello ${vm.candidate.firstName},<br> Please provide a <b>phone number</b> where we can reach you.`;
        msgFr = `Bonjour ${vm.candidate.firstName},<br> S'il vous plaît fournir votre <b>numéro de téléphone</b> sur lequel nous pouvons vous rejoindre.`;
        vm.postCatherineMsg({ msgEn, msgFr });
        vm.candidateInputText = '';
        vm.required = 'phone';
        vm.label = vm.out('Numéro de téléphone', 'Phone number');
        angular.element('#candidateReplyId').focus();
      }, 300);
    }

    /**
     * @details     redirect internal candidate to SSO login
     */
    function singleSignOnLogin(action, domain) {
      let params = null;
      if (action === 'register') {
        params = {
          lang: $rootScope.language,
          role_id: 70,
        };
      }
      api.service_get('accounts', `auth/saml2/${domain.name}/login`, params).then((response) => {
        if (response.status === 200 && response.data) {
          window.location = response.data;
        } else {
          $scope.ssoLoginLoader = false;
          msgEn = `A problem occured and we couldn't identify you with your ${domain.name.toUpperCase()} account, please try again or contact support@workland.com for assistance`;
          msgFr = `Un problème est survenu et nous n'avons pu vous identifier avec votre compte ${domain.name.toUpperCase()}, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide`;
          vm.postCatherineMsg({ msgEn, msgFr });
        }
      }).catch(() => {
        $scope.ssoLoginLoader = false;
        msgEn = `A problem occured and we couldn't identify you with your ${domain.name.toUpperCase()} account, please try again or contact support@workland.com for assistance`;
        msgFr = `Un problème est survenu et nous n'avons pu vous identifier avec votre compte ${domain.name.toUpperCase()}, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide`;
        vm.postCatherineMsg({ msgEn, msgFr });
      });
    }

    function findIfUserExist(email) {
      return api.service_post('accounts', 'accounts/find', { email, type: 'candidate' }).then((res) => {
        if (res.data.status === 'success' && res.data.data) {
          return res.data.data;
        }
        return null;
      }).catch((err) => err);
    }

    function getCompanyIdp() {
      return api.service_get('accounts', `accounts/${vm.job.account_id}/idp-name`).then((response) => {
        if (response.data.status === 'success' && response.data.data) {
          return response.data.data;
        }
        return null;
      }).catch((err) => (err.status === 404 ? err.data.message : null));
    }

    /**
     * @details     determines if internal candidate login or registrate
     */
    function determineSSOAction(email, domain) {
      findIfUserExist(email).then((res) => {
        const action = res && res.user_id && res.account_id ? 'login' : 'register';
        $scope.ssoLoginLoader = true;
        vm.catherineTyping = false;
        msgEn = action === 'login'
          ? `You need to login to your ${domain.name.toUpperCase()} account before applying to this job`
          : `You need to register as a candidate with your ${domain.name.toUpperCase()} account before applying to this job`;
        msgFr = action === 'login'
          ? `Vous devez vous connecter à votre compte ${domain.name.toUpperCase()} avant de postuler à cet emploi`
          : `Vous devez vous inscrire en tant que candidat avec votre compte ${domain.name.toUpperCase()} avant de postuler à cet emploi`;
        vm.postCandidateMsg({ text: vm.candidateInputText, isValid: true });
        vm.postCatherineMsg({ msgEn, msgFr });
        storageService.setItem('redirect_to', 'job-apply');
        storageService.setItem('connection_action', action);
        storageService.setItem('has_agreed_to_consent', $scope.jobId);
        $timeout(() => {
          singleSignOnLogin(action, domain);
        }, 4000);
      }).catch(() => {
        vm.catherineTyping = false;
        stopApplicationProcess(false);
      });
    }

    /**
     * @details     check if candidate email domain match company domain
     */
    function checkIfIdpFitJob(email, domain) {
      getCompanyIdp().then((res) => {
        const companyIdp = res;
        if (companyIdp) {
          if (domain.name.toLowerCase() === companyIdp) {
            determineSSOAction(email, domain);
          } else {
            vm.catherineTyping = false;
            msgEn = `You cannot apply to this job as an employee of ${domain.name.toUpperCase()}`;
            msgFr = `Vous ne pouvez pas postuler à cet emploi en tant qu'employé(e) de ${domain.name.toUpperCase()}`;
            vm.postCandidateMsg({ text: vm.candidateInputText, isValid: false });
            vm.postCatherineMsg({ msgEn, msgFr });
            vm.required = 'emailId';
          }
        } else {
          vm.catherineTyping = false;
          stopApplicationProcess(false);
        }
      }).catch(() => {
        // if the ipd is not found (404) we throw general error - internal posting means mandatory company idp
        vm.catherineTyping = false;
        stopApplicationProcess(false);
      });
    }

    function getIdpsList() {
      return api.service_get('accounts', 'idps').then((response) => {
        if (response.data.status === 'success' && response.data.data) {
          vm.idpsList = response.data.data;
        } else {
          vm.idpListFail = true;
        }
      }).catch(() => {
        vm.idpListFail = true;
      });
    }

    /**
     * @details     check if user is an internal candidate
     */
    function getInternalCandidateDomain(email) {
      const regExp = /@?([^@]+)$/;
      const userEmailDomain = email.match(regExp)[1];
      return _.find(vm.idpsList, (item) => item.domain === userEmailDomain);
    }

    function microsoftErrorHandler(action) {
      switch(action) {
        case 'services_connection_fail' :
          msgFr = "Désolé! Un problème est survenu et nous n'avons pu nous connecter aux services Microsoft, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide";
          msgEn = "Sorry! A problem occured and we couldn't connect with Microsoft services, please try again or contact support@workland.com for assistance";
          break;
        case 'authentication_fail' :
          msgFr = "Un problème est survenu et nous n'avons pu vous identifier avec votre compte Microsoft, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide";
          msgEn = "A problem occured and we couldn't identify you with your Microsoft account, please try again or contact support@workland.com for assistance";
          break;
        case 'connection_fail' :
          msgFr = "La connexion avec votre compte Microsoft a échouée, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide"
          msgEn = "Login with your Microsoft account failed, please try again or contact support@workland.com for assistance"
          break;
        case 'failed_to_create' :
          msgFr = "Un problème est survenu et votre compte candidat n'a pu être créé, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide";
          msgEn = "A problem occured and your candidate account could not be created, please try again or contact support@workland.com for assistance"
        break;
        case 'failed_to_create' :
          msgFr = "Un problème est survenu et nous n'avons pu vous connecter avec votre compte candidat, veuillez réessayer ou contacter support@workland.com pour obtenir de l'aide";
          msgEn = "Something went wrong and we couldn't sign you in with your candidate account, please try again or contact support@workland.com for assistance"
        break;
      }

      vm.catherineTyping = false;
      vm.postCatherineMsg({ msgEn, msgFr });
    }

    /**
     * @details     redirect the user to login with a specific Microsoft account
     */
     function microsoftLoginFollow(domain) {
        let params = {
          lang: $rootScope.language,
          redirect_to: "job-apply",
        };
        if ($scope.domainName) {
          params.domain_name = $scope.domainName;
        } else if (domain) {
          params.domain_name = domain;
        }
        api.service_get('accounts', 'auth/social-login/microsoft', params).then((response) => {
          if (response.data.status === 'success') {
            window.location = response.data.data.link;
          } else {
            microsoftErrorHandler('services_connection_fail');
          }
        }).catch(() => {
          microsoftErrorHandler('services_connection_fail');
      });
     }

    function microsoftLogin() {
      api.service_post('accounts', 'auth/social-login/microsoft/domain', {
        account_id: vm.job.account_id
      }).then( (result) => {
          $scope.organizationDomains = result.data.data;
          if (result.data.data.length === 1) {
            $scope.domainName = result.data.data[0];
            microsoftLoginFollow();
          }
          vm.showMSLoginBtn = false;
        }).catch(()=> {          
          $scope.domainName = null;
          microsoftLoginFollow();
        })
    }

    /**
     * @details     gets company's organization_id - with application exclusive to internal candidates
     */
    function getOauthOrganizationId() {
      return api.service_get('accounts', `auth/social-login/microsoft/organization-accounts/${vm.job.account_id}`)
      .then(() => {
        return "found";
      }).catch((error) => {
        if (error?.status === 404 && error?.data?.message && error?.data?.message === "account_organization_not_found") {
          return "not_found";
        } else {
          return "stop_application_process"
        }
      });
    }

    function saveUserPhone() {
      vm.required = 'waiting';
      vm.catherineTyping = true;
      api.service_post('accounts', `users/${vm.candidate.id}`, { phone: vm.candidate.phone }, 'update').then(() => {
        vm.catherineTyping = false;
        msgEn = "Phone number saved";
        msgFr = "Numéro de téléphone sauvegardé";
        vm.postCatherineMsg({ msgEn, msgFr });
        hasAlreadyApplied(vm.candidate.id);
      }).catch(() => {
        // not blocking the applicaton if phone save fails
        vm.catherineTyping = false;
        msgEn = "Something went wrong and the phone number couldn't be saved, but don't worry, you can still apply to this position";
        msgFr = "Un problème est survenu et le numéro de téléphone n'a pu être sauvegardé, mais ne vous inquiétez pas, vous pouvez toujours postuler sur ce poste";
        vm.postCatherineMsg({ msgEn, msgFr });
        hasAlreadyApplied(vm.candidate.id);
      });

    }

    function candidateInput() {
      let areaCode;
      let midCode;
      let lastCode;
      if (vm.candidateInputText) {
        switch (vm.required) {
          case 'emailId':
            if (vm.candidateInputText.match(vm.emailFormat)) {
              vm.required = 'waiting';
              const internalCandidateDomain = getInternalCandidateDomain(vm.candidateInputText);
              if (internalCandidateDomain) {
                vm.candidate.isInternalApplication = true;
                vm.catherineTyping = true;
                checkIfIdpFitJob(vm.candidateInputText, internalCandidateDomain);
              } else {
                vm.candidate.isInternalApplication = false;
                if (vm.job.published_external && !utils.isDateExpired(vm.job.external_expiry_date) && !vm.isInternalApplication) {
                  vm.postCandidateMsg({ text: vm.candidateInputText, isValid: true });
                  vm.catherineTyping = true;
                  isRegisteredUser(vm.candidateInputText);
                } else if (vm.job.published_internal && !utils.isDateExpired(vm.job.internal_expiry_date)) {
                  vm.candidate.isInternalApplication = true;
                  getCompanyIdp().then(res => {
                    const companyIdp = res;
                    if (companyIdp && companyIdp.toLowerCase() === "uqam") {
                      // in case of UQAM no external candidates can apply to the job - we are on the case that user has no emailDomain matching
                      msgEn = "This position is not available for external candidates, please consult the list of available positions";
                      msgFr = "Ce poste n'est pas disponible pour les candidats externes, veuillez consulter la liste des postes disponibles";
                      vm.postCandidateMsg({ text: vm.candidateInputText, isValid: false });
                      vm.postCatherineMsg({ msgEn, msgFr });
                      vm.required = 'consultListJob';
                    } else if (companyIdp && companyIdp.toLowerCase() !== "uqam") {
                      vm.postCandidateMsg({ text: vm.candidateInputText, isValid: true });
                      vm.catherineTyping = true;
                      isRegisteredUser(vm.candidateInputText);
                    } else {
                      vm.catherineTyping = false;
                      stopApplicationProcess(false);
                    }
                  });
                } else {
                  msgEn = "This position is not available or has expired";
                  msgFr = "Ce poste n'est pas disponible ou est expiré";
                  vm.postCandidateMsg({ text: vm.candidateInputText, isValid: false });
                  vm.postCatherineMsg({ msgEn, msgFr });
                }
              }
            } else {
              vm.required = 'waiting';
              vm.postCandidateMsg({ text: vm.candidateInputText, isValid: false });
              msgEn = 'Sorry! This is not a valid email.<br> Please enter your correct email address.';
              msgFr = "Désolé! Ce n'est pas une adresse courriel valide.<br> Veuillez entrer votre adresse courriel correctement.";
              vm.postCatherineMsg({ msgEn, msgFr });
              vm.required = 'emailId';
              vm.placeholder = 'john.doe@mail.com';
            }
            break;
          case 'name':
            if (vm.candidateInputText && vm.candidateInputTextLastName && vm.candidateInputText.match(vm.nameFormat) && vm.candidateInputTextLastName.match(vm.nameFormat)) {
              vm.required = 'waiting';
              splitFullName();
            } else {
              vm.required = 'waiting';
              const name = vm.candidateInputText ? `${vm.candidateInputText} ` : `${vm.candidateInputTextLastName}` ? vm.candidateInputTextLastName : '';
              vm.postCandidateMsg({ text: name, isValid: false });
              msgEn = 'Sorry! This is not a valid name.<br>Please enter your full name without any special characters or numbers.';
              msgFr = "Désolé! Ce n'est pas un nom valide.<br>Veuillez entrer votre nom complet sans numéros ni caractères spéciaux.";
              vm.postCatherineMsg({ msgEn, msgFr });
              vm.required = 'name';
              vm.placeholder = vm.out('Prénom et nom', 'First & last name');
            }
            break;
          case 'phone':
            areaCode = vm.candidateInputText.slice(0, 3);
            midCode = vm.candidateInputText.slice(3, 6);
            lastCode = vm.candidateInputText.slice(6, 10);
            if (vm.candidateInputText.length === 10) {
              vm.candidateInputText = `(${areaCode}) ${midCode}-${lastCode}`;
              vm.candidate.phone = vm.candidateInputText;
              vm.postCandidateMsg({ text: vm.candidateInputText, isValid: true });
              vm.catherineTyping = true;
              if (!vm.isMicrosoftLogin) {
                newRegistration();
              } else {
                saveUserPhone();
              }
            } else if (vm.candidateInputText.length > 0) {
              vm.required = 'waiting';
              vm.postCandidateMsg({ text: vm.candidateInputText, isValid: false });
              msgEn = 'Sorry! This is not a valid phone number.<br>Please enter a valid phone number.';
              msgFr = "Désolé! Ce n'est pas un numéro de téléphone valide.<br>S'il vous plaît entrer un numéro de téléphone valide.";
              vm.postCatherineMsg({ msgEn, msgFr });
              vm.required = 'phone';
            }
            break;
          case 'password':
            vm.required = 'waiting';
            checkCredentials(vm.candidateInputText);
            break;
          default:
        }
      }
    }

    function skipLogin() {
      vm.candidate.loginStatus = 'quick';
      const msg = vm.out('<i> (Vous avez cliqué sur <b> SAUTER </b>)</i>', '<i>(You clicked <b>SKIP</b>)</i>.');
      vm.postCandidateMsg({ text: msg }, { isValid: false });
      vm.required = 'waiting';
      vm.catherineTyping = true;
      hasAlreadyApplied(vm.candidate.id);
    }

    function newAccountForEmployer() {
      const msg = vm.out('Créer mon compte candidat.', 'Create my candidate account.');
      vm.postCandidateMsg({ text: msg }, { isValid: false });
      if (!vm.candidate.isInternalApplication) {
        newRegistration();
      } else {
        vm.required = '';
        const domain = getInternalCandidateDomain($rootScope.currentUser.user.email);
        msgEn = `You will have to reconnect to your account ${domain.name.toUpperCase()} in order to create your candidate account`;
        msgFr = `Vous devrez vous reconnecter à votre compte ${domain.name.toUpperCase()} afin créer votre compte candidat`;
        vm.postCatherineMsg({ msgEn, msgFr });
        $scope.ssoLoginLoader = true;
        authService.logout(true);
        storageService.setItem('redirect_to', 'job-apply');
        storageService.setItem('connection_action', 'register');
        storageService.setItem('has_agreed_to_consent', $scope.jobId);
        $timeout(() => {
          singleSignOnLogin('register', domain);
        }, 4000);
      }
    }

    function resetCandidateData() {
      vm.candidate = {};
      vm.candidate.loginStatus = 'quick';
    }

    function startAgain() {
      // erase existing data first
      resetCandidateData();
      const msg = vm.out('Je voudrais entrer une autre adresse courriel.', "I'd like to enter another email address.");
      vm.postCandidateMsg({ text: msg, isValid: false });
      msgEn = '<b>Ok</b><br>Please enter your email address.';
      msgFr = "<b> Ok </ b> <br> S'il vous plaît entrez votre adresse courriel.";
      $timeout(() => {
        vm.postCatherineMsg({ msgEn, msgFr });
      }, 150);
      $timeout(() => {
        vm.required = 'emailId';
        vm.label = vm.out('Courriel', 'Email');
      }, 300);
    }

    function switchAccountType() {
      vm.required = 'waiting';
      const msg = vm.out('<i>(Vous avez choisi <b>Me connecter avec mon compte candidat</b>)</i>', '<i>(You clicked <b>Connect with my Candidate Account</b>)</i>');
      vm.postCandidateMsg({ text: msg, isValid: false });
      refreshAccount(vm.candidate.is_candidate);
    }

    function checkIfInternalUserCanApply(domain) {
      return getCompanyIdp().then((res) => {
        const companyIdp = res;
        if (companyIdp) {
          if (domain.name.toLowerCase() === companyIdp) {
            return true;
          }
          vm.catherineTyping = false;
          msgEn = `You cannot apply to this job as an employee of ${domain.name.toUpperCase()}`;
          msgFr = `Vous ne pouvez pas postuler à cet emploi en tant qu'employé(e) de ${domain.name.toUpperCase()}`;
          vm.postCatherineMsg({ msgEn, msgFr });
          return false;
        }
        stopApplicationProcess(false);
        return false;
      }).catch(() => {
        // if the ipd is not found (404) we throw general error - internal posting means mandatory company idp
        stopApplicationProcess(false);
      });
    }

    function unavailableInternalJobMsg() {
      msgEn = "Sorry! This position is not available for external candidates, please consult the list of available positions";
      msgFr = "Désolé! Ce poste n'est pas disponible pour les candidats externes, veuillez consulter la liste des postes disponibles";
      vm.postCatherineMsg({ msgEn, msgFr });
      vm.required = 'consultListJob';
    }

    function restrictedMicrosoftUserCanApply(hasPhone) {
      userAccountsService.getCurrentUserData().then(() => {
        if ($rootScope.currentUser?.user) {
          $scope.fullName = `${$rootScope.currentUser.user.first_name} ${$rootScope.currentUser.user.last_name}`;
        }
        vm.socialConnectionLoader = false;
        if (hasPhone) {
          msgEn = $scope.fullName ? `Hi <b>${$scope.fullName}, </b>you’re almost there!` : `You’re almost there!`;
          msgFr = $scope.fullName ? `Bonjour <b>${$scope.fullName}, </b>vous y êtes presque!` : `Vous y êtes presque!`;
          vm.postCatherineMsg({ msgEn, msgFr });
          hasAlreadyApplied(vm.candidate.id);
        } else {
          vm.candidateInputText = '';
          vm.label = vm.out('Numéro de téléphone', 'Phone number');
          msgEn = `Hi <b>${$scope.fullName}, </b>you’re almost there! <br> Please provide a <b>phone number</b> where we can reach you.`;
          msgFr = `Bonjour <b>${$scope.fullName}, </b>vous y êtes presque! <br> S'il vous plaît veuillez fournir votre <b>numéro de téléphone</b> sur lequel nous pouvons vous rejoindre.`;
          vm.postCatherineMsg({ msgEn, msgFr });
          vm.required = 'phone';
        }
      });
    }

    /**
     * @details    Microsoft login - account setup & refresh token in case of multiple accounts
     */
    function processToUserLogin(loginResponse, microsoftToken) {
      authService.saveToken(loginResponse.data.token);
      const accounts = loginResponse.data.accounts ? loginResponse.data.accounts : [loginResponse.data.account];
      storageService.setItem('accounts', JSON.stringify(accounts));
      storageService.setCookie('microsoftToken', JSON.stringify(microsoftToken));
      if (accounts.length > 1) {
        const candidateAccount = accounts.find(a => +a.role_id === 70);
        if (candidateAccount) {
          const accountCreatedAt = utils.utcToTimezone(candidateAccount.created_at, 'ojb');
          if (((new Date().getTime() - new Date(accountCreatedAt).getTime()) / 1000) > 600) {
            vm.candidateAccAlreadyExist = true;
          }
          vm.candidate.id = candidateAccount.user_id;
          vm.candidate.account_id = candidateAccount.account_id;
          authService.refreshToken(candidateAccount.account.id).then((res) => {
            var refreshResponse = res.data;
            if (refreshResponse.status === 'success') {
              vm.candidate.loginStatus = 'regular';
              authService.saveToken(refreshResponse.data.token);
              userAccountsService.setCurrentUserAccount(refreshResponse);
              restrictedMicrosoftUserCanApply(loginResponse.data.has_phone);
              vm.candidate.email = $rootScope.user_email ?? localStorage.getItem("user_email");
            } else {
              vm.socialConnectionLoader = false;
              stopApplicationProcess(true);
            }
          }).catch(() => {
            vm.socialConnectionLoader = false;
            stopApplicationProcess(true);
          });
        } else {
          vm.socialConnectionLoader = false;
          stopApplicationProcess(true);
        }
      } else {
        // case where user has only 1 account
        const accountCreatedAt = utils.utcToTimezone(loginResponse.data.account.created_at, 'ojb');
        if (((new Date().getTime() - new Date(accountCreatedAt).getTime()) / 1000) > 600) {
          vm.candidateAccAlreadyExist = true;
        }
        vm.candidate.loginStatus = 'regular';
        vm.candidate.id = loginResponse.data.account.user_id;
        vm.candidate.account_id = loginResponse.data.account.account_id;
        userAccountsService.setCurrentUserAccount(loginResponse);
        restrictedMicrosoftUserCanApply(loginResponse.data.has_phone);
        vm.candidate.email = $rootScope.user_email ?? localStorage.getItem("user_email");
      }
    }

    function microsoftUserApplyValidation(loginResponse, microsoftToken) {
      getOauthOrganizationId().then((response) => {
        if (response === "found") {
          if (microsoftToken?.microsoft_organization_account_ids?.length > 0) {
            const userCanApply = !!microsoftToken.microsoft_organization_account_ids.includes(vm.job.account_id);
            if (userCanApply) {
              processToUserLogin(loginResponse, microsoftToken);
              vm.candidate.isInternalApplication = true;
            } else {
              vm.socialConnectionLoader = false;
              unavailableInternalJobMsg();
            }
          } else {
            vm.socialConnectionLoader = false;
            unavailableInternalJobMsg();
          }
        } else {
          processToUserLogin(loginResponse, microsoftToken);
          vm.candidate.isInternalApplication = false;
        }
      });
    }

    function socialLoginCallBack(urlParams) {
      vm.isMicrosoftLogin = true;
      vm.socialConnectionLoader = true;
      urlParams.redirect_to = "job-apply";
      api.service_get('accounts', 'auth/social-login/microsoft/callback', urlParams).then((response) => {
        const loginResponse = response.data;
        if (loginResponse?.status == 'success' && loginResponse.data?.microsoft_token) {
          // @todo check if has phone and show phone input if not - loginResponse.data.has_phone;
          const microsoftToken = _.pick(loginResponse.data.microsoft_token, 'access_token', 'exp', 'refresh_token', 'scope');
          if (loginResponse.data?.microsoft_organization_account_ids.length > 0) {
            microsoftToken.microsoft_organization_account_ids = loginResponse.data.microsoft_organization_account_ids;
          }
          microsoftUserApplyValidation(loginResponse, microsoftToken);
          if (loginResponse.data?.atlas_microsoft_token) {
            storageService.setCookie('atlasMicrosoftToken', loginResponse.data.atlas_microsoft_token);
          }
          $location.url($location.path());
        } else {
          vm.socialConnectionLoader = false;
          vm.catherineTyping = true;
          microsoftErrorHandler('authentication_fail');
        }
      }).catch((err) => {
        vm.catherineTyping = true;
        switch (err.status) {
          case 400:
            microsoftErrorHandler("connection_fail");
            break;
          default:
            if (err.data && err.data.message && err.data.message.match('failed_to_create')) {
              microsoftErrorHandler("failed_to_create");
            } else {
              microsoftErrorHandler('authentication_fail');
            }
        }
        vm.socialConnectionLoader = false;
      });
    }

    function showEmailInput() {
      msgEn = "What's your <b>email address</b> so that we can quickly reach you regarding this opportunity?";
      msgFr = 'Quelle est votre adresse courriel afin que nous puissions rapidement vous rejoindre concernant cette opportunité?';
      $timeout(() => {
        vm.postCatherineMsg({ msgEn, msgFr });
      }, 150);
      $timeout(() => {
        vm.required = 'emailId';
        vm.label = vm.out('Courriel', 'Email');
        vm.placeholder = 'john.doe@mail.com';
      }, 300);
    }

    function applicationProcessInit() {      
      $q.when(getIdpsList()).then(() => {
        if (vm.idpListFail) {
          stopApplicationProcess(true);
          return;
        }
        // if we have candidate id
        if (vm.candidate.id && $rootScope.currentUser) {
          const { user } = $rootScope.currentUser;
          $scope.fullName = `${user.first_name} ${user.last_name}`;
          const internalEmailDomain = getInternalCandidateDomain($rootScope.currentUser.user.email);
          vm.candidate.isInternalApplication = !!internalEmailDomain;
          let userCanApply;
          const promiseArray = [];
          if (internalEmailDomain) {
            if (vm.job.published_internal && !utils.isDateExpired(vm.job.internal_expiry_date)) {
              promiseArray.push(checkIfInternalUserCanApply(internalEmailDomain).then((res) => {
                userCanApply = res;
              }).catch(() => {
                stopApplicationProcess(false);
                userCanApply = false;
              }));
            } else if (vm.job.published_external && !utils.isDateExpired(vm.job.external_expiry_date)) {
              msgEn = `Sorry, you cannot apply to a job published externally as an employee of ${internalEmailDomain.name.toUpperCase()}`;
              msgFr = `Désolé, vous ne pouvez pas postuler à un emploi publié à l'externe en tant qu'employé(e) de ${internalEmailDomain.name.toUpperCase()}`;
              vm.postCatherineMsg({ msgEn, msgFr });
              userCanApply = false;
            }
             else {
              msgEn = "This position is not available or has expired";
              msgFr = "Ce poste n'est pas disponible ou est expiré";
              vm.postCatherineMsg({ msgEn, msgFr });
              userCanApply = false;
            }
          } else {
            promiseArray.push(
              getOauthOrganizationId().then((response) => {
                if (response === "found") {
                  if (vm.job.published_external && !utils.isDateExpired(vm.job.external_expiry_date) && !vm.isInternalApplication) {
                    userCanApply = true;
                  } else if (vm.job.published_internal && !utils.isDateExpired(vm.job.internal_expiry_date)) {
                    vm.candidate.isInternalApplication = true;
                    const microsoftToken = storageService.getCookieByName('microsoftToken');
                    const parsedMicrosoftToken = microsoftToken ? JSON.parse(microsoftToken) : null;
                    if (parsedMicrosoftToken) {
                      vm.isMicrosoftLogin = true;
                      const organizationIdsArray = parsedMicrosoftToken.microsoft_organization_account_ids;
                      userCanApply = Array.isArray(organizationIdsArray) ? !!organizationIdsArray.includes(vm.job.account_id) : false;
                      if (!userCanApply) unavailableInternalJobMsg();
                    } else {
                      unavailableInternalJobMsg();
                      userCanApply = false;
                    }
                  } else {
                    msgEn = "This position is not available or has expired";
                    msgFr = "Ce poste n'est pas disponible ou est expiré";
                    vm.postCatherineMsg({ msgEn, msgFr });
                    userCanApply = false;
                  }
                } else if (response === "not_found") {
                  if (vm.job.published_external && !utils.isDateExpired(vm.job.external_expiry_date) && !vm.isInternalApplication) {
                    userCanApply = true;
                  } else if (vm.job.published_internal && !utils.isDateExpired(vm.job.internal_expiry_date)) {
                    vm.candidate.isInternalApplication = true;
                    // no organization id found, so next is the saml internal job case
                    return getCompanyIdp().then(res => {
                      // companyIdp value should be a domain or idp_not_found - null is returned when error
                      const companyIdp = res;
                      if (companyIdp && companyIdp.toLowerCase() === "uqam") {
                        // in case of UQAM no external candidates can apply to the job
                        unavailableInternalJobMsg();
                        userCanApply = false;
                      } else if (companyIdp && companyIdp !== "uqam") {
                        // external candidates - except UQAM & except companies that have Azure organization_id restriction - can apply to an internal job if they get the job link
                        userCanApply = true;
                      } else {
                        stopApplicationProcess(false);
                        userCanApply = false;
                      }
                    });
                  } else {
                    msgEn = "This position is not available or has expired";
                    msgFr = "Ce poste n'est pas disponible ou est expiré";
                    vm.postCatherineMsg({ msgEn, msgFr });
                    userCanApply = false;
                  }
                } else {
                  // case when there is a service error
                  stopApplicationProcess(false);
                  userCanApply = false;
                }
              })
            );
          }

          $q.all(promiseArray).then(() => {
            if (userCanApply) {
              // this case is when the logged in user is candidate
              if (!vm.candidate.loginSwich) {
                msgEn = `Hi <b>${$scope.fullName}, </b>you’re almost there!`;
                msgFr = `Bonjour <b>${$scope.fullName}, </b>vous y êtes presque!`;
                vm.postCatherineMsg({ msgEn, msgFr });
                hasAlreadyApplied(vm.candidate.id);
              } else {
                switch (vm.candidate.loginSwich) {
                  case 1:
                    // this case is when we are able to switch login
                    msgEn = `Hi <b>${$scope.fullName}, </b>it looks like you're not logged in with your candidate account.<br>Please switch to your candidate account to apply to this job.`;
                    msgFr = `Bonjour <b>${$scope.fullName}, </b>il semble que vous n'êtes pas connecté en tant que candidat. <br>S'il vous plaît connectez-vous avec votre compte candidat pour appliquer à ce poste.`;
                    vm.postCatherineMsg({ msgEn, msgFr });
                    $timeout(() => {
                      vm.required = 'refreshAccount';
                    }, 300);
                    break;
                  case 2:
                    // this case is when we need to register
                    msgEn = `Hi <b>${$scope.fullName}, </b>it looks like you don't have a candidate account.<br>Please create a candidate account to apply to this job.`;
                    msgFr = `Bonjour <b>${$scope.fullName}, </b>vous n'êtes pas enregistré en tant que candidat. <br>S'il vous plaît veuillez créer un compte candidat pour appliquer à cet emploi.`;
                    vm.postCatherineMsg({ msgEn, msgFr });
                    $timeout(() => {
                      vm.required = 'consent';
                    }, 300);
                    break;
                }
              }
            }
          });
        } else {
          getOauthOrganizationId().then((response) => {
            if (response === "found") {
              if (vm.job.published_external && !utils.isDateExpired(vm.job.external_expiry_date) && !vm.isInternalApplication) {
                showEmailInput();
              } else if (vm.job.published_internal && !utils.isDateExpired(vm.job.internal_expiry_date)) {
                storageService.setItem('has_agreed_to_consent', $scope.jobId);
                msgEn = `You need to authenticate with your ${vm.job?.companyName ? vm.job.companyName + " -" : ""} Microsoft account to apply on this post`
                msgFr = `Vous devez vous authentifier avec votre compte Microsoft ${vm.job?.companyName ? "- " + vm.job.companyName : ""} pour appliquer sur ce poste`;
                $timeout(() => {
                  vm.postCatherineMsg({ msgEn, msgFr });
                  vm.required = "microsoftLogin"
                }, 150);
              } else {
                msgEn = "This position is not available or has expired";
                msgFr = "Ce poste n'est pas disponible ou est expiré";
                vm.postCatherineMsg({ msgEn, msgFr });
              }
            } else if (response === "not_found") {
              // no organization id found, we continue usual application process
              showEmailInput();
            } else {
              // case when there is a service error
              stopApplicationProcess(false);
            }
          });
        }
      });
    }

    function init() {
      $scope.jobId = vm.jobId ? vm.jobId : storageService.getItem('jobIdClicked');
      $scope.fullName = "";
      const urlString = $location.$$search;

      if (urlString.token) {
        vm.isInternalApplication = true;
      }

      if (urlString.code) {
        socialLoginCallBack(urlString);
      } else {
        applicationProcessInit();
      }
    }

    $scope.$watch('vm.stage', () => {
      if (vm.stage === 'identifyUser') {
        init();
      }
    });

    vm.options = {
      custom: {
        numericOnly: true,
        delimiters: [' (', ') ', '-'],
        blocks: [0, 3, 3, 4],
      },
    };

    angular.extend(vm, vmExtend);
  }
  identifyUserCtrl.$inject = [
    '$scope',
    '$rootScope',
    'utils',
    '_',
    'worklandLocalize',
    '$timeout',
    'authService',
    'storageService',
    'applicationService',
    'userAccountsService',
    'api',
    '$q',
    '$location',
  ];
  const app = angular.module('atlas');
  app.directive('identifyUserModule', () => ({
    scope: {},
    bindToController: {
      postCatherineMsg: '&',
      postCandidateMsg: '&',
      jobId: '=',
      job: '=',
      candidate: '=',
      indentifyUserCallback: '&',
      consultJobsList: '&',
      catherineTyping: '=',
      stage: '=',
      source: '=',
      candidateAccAlreadyExist: '=',
      customColor: '=',
      isMicrosoftLogin: '=',
    },
    controller: identifyUserCtrl,
    controllerAs: 'vm',
    templateUrl: './atlas/directives/job-apply/identify-user-module/identify-user-module.template.html',
  }));
}(angular));
