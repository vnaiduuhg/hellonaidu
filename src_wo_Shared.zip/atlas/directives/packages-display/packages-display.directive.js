(function (angular) {
  function PackagesDisplayCtrl(
    $scope,
    $location,
    api,
    utils,
    transferer,
    $rootScope,
    $window,
    $state,
    $stateParams,
    productService,
    $timeout,
    MetaTagsService,

  ) {  
   
    $scope.out = utils.out;
    $scope.packages = [];
    $scope.selected = -1;

    $scope.removeDescription = function (packageIndex) {
      $scope.activePackage = null;
    };

    function selectedPackage(selectedPackage, packageIndex) {
      $scope.activePackage = selectedPackage.id;
      $location.hash(`packageNo${packageIndex}`);
    }

    function sortPackagesAscendant(a) {
      const b = a.sort((a, b) => (a.price - b.price));
    }

    function setUpPackages(packages) {
      if (!packages.length) {
        $scope.noPackage = true;
        $scope.agencyId = 0;
      } else {
        $scope.agencyId = packages[0].account_id;
        $rootScope.agencyId = packages[0].account_id;
        selectedPackage(packages[0], 1);
        angular.forEach(packages, (pack) => {
          if (pack.photos.length > 0) pack.productPhoto = window.appConfig.MINIO_URL+pack.photos[0].image;
        })
        sortPackagesAscendant(packages);
      }
    }

    //  communicate with marketplace api
    function getAllPackages() {
      // @agency: add checks of the state name to get agency slugs
      //this is agency-packages url, getting all products
     
      $scope.slug = null;
      const stringUrl = $location.$$url;
      $scope.slug = stringUrl.replace(/^\/(\w*\W?\w*)\/(\w*)?/g, '$1');
      $scope.slug = utils.removeAllURLParam($scope.slug); 
      //exception for all Workland packages; others have /slug/packages
      if ($scope.slug !== '/agency-packages') {
        return api.service_get('accounts', `accounts/profiles/by-slug/${$scope.slug}`)
          .then((response) => {
          if (response.data) {
            $scope.agencyId = response.data.data.account_id;
            return productService.getProductsByAccountId($scope.agencyId).then((res) => {
              $scope.packages = res.data; 
              setUpPackages($scope.packages);
            }).catch(() => {
              $scope.noPackage = true;
              $scope.agencyId = 0;
            });
          }
        });
      }
      productService.getAllProducts()
        .then((res) => {
           $scope.packages = res.data;
           setUpPackages($scope.packages);        
        }).catch(() => {
          $scope.noPackage = true;
          $scope.agencyId = 0;
        })
     
    }

    function init() {
      $scope.isWorkland = false; // no workland products for the moment
      $scope.noPackage = false;
      getAllPackages(); 
    }

    init();

    // Toggle between monthly and yearly; used for Workland packages
    $scope.isMonth = true;
    $scope.monthOrYear = 'month';
    $scope.toggleMonthYear = function () {
      $scope.isMonth = !$scope.isMonth;
      if ($scope.isMonth) {
        $scope.monthOrYear = 'month';
      } else {
        $scope.monthOrYear = 'year';
      }
    };

    /**
         * When choosing a package
         * pass the package info/object to the payment-gateway directive
         */
    let timeoutForRedirectPage;
    $scope.choose = function (chosenPackage) {
      transferer.setData(chosenPackage);
      $rootScope.paymentGatewayShow = true;
      $rootScope.packagesDisplayShow = false;
      $window.scrollTo(0, 0);
      // @agency: add checks of agency cookies mode to go to agency paymentgateway page
      timeoutForRedirectPage = $timeout( () => {
        $state.transitionTo('paymentGateway');
      })
    };

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on("$destroy", function() {
        deregisterFns.forEach(function(deregisterFn) {
            deregisterFn();
        });
        $timeout.cancel(timeoutForRedirectPage);
    });

    const scope = {
      selectedPackage,
    };
    angular.extend($scope, scope);
  }
  const app = angular.module('atlas');
  app.controller('PackagesDisplayCtrl', PackagesDisplayCtrl);
  PackagesDisplayCtrl.$inject = [
    '$scope',
    '$location',
    'api',
    'utils',
    'transferer',
    '$rootScope',
    '$window',
    '$state',
    '$stateParams',
    'productService',
    '$timeout',
    'MetaTagsService',
  ];

  app.directive('packagesDisplay', () => ({
    scope: {},
    controller: PackagesDisplayCtrl,
    templateUrl: './atlas/directives/packages-display/packages-display.directive.js',
  }));
}(angular));
