// eslint-disable-next-line func-names
(function (angular) { // to be able to access the job-apply-success html page w/o being logged in
  function JobAppliedSuccessCtrl($scope, api, utils, MetaTagsService, $state, $stateParams, authService, storageService, $cookies) {
    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });
    $scope.isLogin = $stateParams.loginStatus !== 'quick';
    $scope.candidateId = $stateParams.candidateId;
    $scope.candidateAccAlreadyExist = $stateParams.candidateAccAlreadyExist;
    $scope.isInternalCandidate = $stateParams.isInternalCandidate;
    $scope.isMicrosoftLogin = $stateParams.isMicrosoftLogin;

    function redirectUser() {
      if ($scope.companySlug) {
        authService.getToken().then(
          (response) => {
            if (response) {
              window.location = `${window.appConfig.ATLAS_UI_URL}careers/${$scope.companySlug}?open=jobs`;
            } else {
              $state.go('companyDescription', { company: $scope.companySlug, open: 'jobs' });
            }
          },
          () => {
            window.location = `${window.appConfig.ATLAS_UI_URL}careers/${$scope.companySlug}?open=jobs`;
          },
        );
      } else {
        $state.go('jobsList');
      }
    }

    function redirectToSubscribe() {
       window.location = `${window.appConfig.ATLAS_UI_URL}subscribe-settings/${$scope.companySlug}`;
    }

    function init() {
      $scope.customColor = {};
      storageService.removeItem('source');
      storageService.removeItem('redirect_to');
      storageService.removeItem('connection_action');
      storageService.removeItem('has_agreed_to_consent');
      $cookies.remove('loginHash');
      const jobId = storageService.getItem('jobIdClicked');
      if (!jobId) {
        if (storageService.getItem('url')) {
          window.location = storageService.getItem('url');
        } else {
          $state.go('jobsList'); // job-desc hosted on partners' homesites will not have job url
        }
      } else {
        api.service_get('jobs', `job/${jobId}`).then((response) => {
          if (response.status === 200 && response.data) {
            const job = response.data;
            $scope.jobId = job.id;
            $scope.jobAccountId = job.account_id;
            $scope.jobTitleEn = job.translations['0']
              ? (job.translations['0'].title ? job.translations['0'].title : job.translations['1'].title)
              : job.translations['1'].title;
            $scope.noTitleEn = $scope.jobTitleEn ? '' : 'No english title available';
            $scope.jobTitleEn = unescape($scope.jobTitleEn);
            $scope.jobTitle = job.translations['1']
              ? (job.translations['1'].title ? job.translations['1'].title : job.translations['0'].title)
              : job.translations['0'].title;
            $scope.noTitle = $scope.jobTitle
              ? ''
              : 'Pas de titre français disponible';
            $scope.jobTitle = unescape($scope.jobTitle);
            $scope.job_link = job.url;
            storageService.removeItem('jobIdClicked');
            $scope.companySlug = null;
            api.service_post('accounts', 'accounts/default-profiles', { account_ids: [$scope.jobAccountId] })
              .then((profilesData) => {
                if (profilesData.data.data) {
                  const profile = profilesData.data.data[$scope.jobAccountId];
                  $scope.companySlug = profile.slug;
                  $scope.customColor.color =  profilesData.data.data[$scope.jobAccountId].color;
                  $scope.companyName = profile.name;
                  if (profile.logo) {
                    $scope.logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/${profile.logo}`;
                  } else {
                    $scope.logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/generic_logo.png`;
                  }
                  if (profile.banner) {
                    $scope.banner = `${window.appConfig.MINIO_URL}media/Profile/Banners/${profile.banner}`;
                  } else {
                    $scope.banner = `${window.appConfig.MINIO_URL}media/Profile/Banners/generic_banner.jpg`;
                  }
                }
                return $scope.companySlug;
              }).catch(() => {
                $scope.customColor.color = 'rgb(0,90,135)';
              })
          }
        });
      }
    }

    init();

    const vmExtend = {
      out: utils.out,
      redirectUser,
      redirectToSubscribe,
    };
    angular.extend($scope, vmExtend);
  }
  JobAppliedSuccessCtrl.$inject = [
    '$scope',
    'api',
    'utils',
    'MetaTagsService',
    '$state',
    '$stateParams',
    'authService',
    'storageService',
    '$cookies',
  ];
  const app = angular.module('atlas');
  app.controller('JobAppliedSuccessCtrl', JobAppliedSuccessCtrl);
  angular.module('atlas')
    .directive('jobAppliedSuccess', () => ({
      scope: {},
      controller: JobAppliedSuccessCtrl,
      // templateUrl: './atlas/directives/job-applied-success/job-applied-success.template.html'
    }));
// eslint-disable-next-line no-undef
}(angular));
