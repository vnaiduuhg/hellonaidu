(function(angular) {
    'use strict';
    var app = angular.module('atlas');
    app.controller('PageNotFound', PageNotFound);
    PageNotFound.$inject = [
        '$scope',
        '_',
        'utils',
    ];
    function PageNotFound(
        $scope,
        _,
        utils,
        ) { 
        $scope.out = utils.out;    
    }
})(angular);