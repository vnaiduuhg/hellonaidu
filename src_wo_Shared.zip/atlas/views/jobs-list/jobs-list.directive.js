// eslint-disable-next-line func-names
(function (angular) {
  const app = angular.module('atlas');
  // Note: if you modify any of the params in JobsListCtrl, don't forget to modify the $inject at the bottom too
  function JobsListCtrl($scope, $rootScope, api, utils, $anchorScroll, $location, MetaTagsService, $state, Pager, storageService, $cookies) {
    
    const scope = {
      jobs: [],
      out: utils.out,
      locale: utils.out('fr', 'en'),
      hideFilters: true,
      timezone: utils.initTimezone(),
      utcToTimezone: utils.utcToTimezone,
      language: $rootScope.language,
      loadingDone: false,
      pager: {},
      pageSize: 10,
      jobTitle: '',
      userLocation: '',
      companyName: '',
    };
    angular.extend($scope, scope);

    MetaTagsService.getMetatags($state.current.name);
    const deregisterFns = MetaTagsService.magageTransitions();
    $scope.$on('$destroy', () => {
      deregisterFns.forEach((deregisterFn) => {
        deregisterFn();
      });
    });

    function showErrorMessage() {
      $scope.loadingDone = true;
      utils.genericConfirmMessage('red', null, utils.out('Désolé, une erreur s\'est produite lors de la récupération des postes. Veuillez contacter support@workland.com pour plus d\'aide.',
        'Sorry, there was an error while fetching the list of jobs. Please contact our support team at support@workland.com for further assistance.'));
    }

    function RemoveAccents(strAccentsin) {
      const strAccents = strAccentsin.split('');
      let strAccentsOut = [];
      const strAccentsLen = strAccents.length;
      const accents = 'ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž';
      const accentsOut = 'AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz';
      for (let y = 0; y < strAccentsLen; y += 1) {
        if (accents.indexOf(strAccents[y]) !== -1) {
          strAccentsOut[y] = accentsOut.substr(accents.indexOf(strAccents[y]), 1);
        } else strAccentsOut[y] = strAccents[y];
      }
      strAccentsOut = strAccentsOut.join('');
      return strAccentsOut;
    }

    function sanitizeInput(input) {
      if (input) {
        let inputCleaned = angular.lowercase(RemoveAccents(input));
        inputCleaned = inputCleaned.replace('-', ' ').replace(/[^a-zA-Z0-9'\s]/gi, '').replace(/ +/, ' ').trim();
        if (inputCleaned.length >= 3) {
          return inputCleaned;
        }
        utils.genericConfirmMessage('red', null, utils.out('Le mot de recherche est trop court', 'Search word is too short'));
      }
      return null;
    }

    function getJobs(page, pageSize, search, locationSearch, companySearch, include, exclude) {
      $scope.jobs = [];
      $scope.loadingDone = false;
      if ($cookies.get('jobTitleSearch')) $cookies.remove('jobTitleSearch');
      if ($cookies.get('locationSearch')) $cookies.remove('locationSearch');
      if ($cookies.get('companySearch')) $cookies.remove('companySearch');
      if (!pageSize) { pageSize = $scope.pageSize; } // Set a page size if one isn't provided
      const jobsParams = {
        page,
        pageSize,
      };
      if (search) {
        jobsParams.search = search;
        storageService.setCookie('jobTitleSearch', search);
      }
      if (locationSearch) {
        jobsParams.locationSearch = locationSearch;
        storageService.setCookie('locationSearch', $scope.userLocation);
      }
      if (companySearch) {
        jobsParams.company_name_search = companySearch;
        storageService.setCookie('companySearch', companySearch);
      }
      if (Array.isArray(include)) {
        jobsParams.account_ids = include;
      }
      if (Array.isArray(exclude)) {
        jobsParams.excluding_account_ids = exclude;
      }
      // @agency: add conditions to include/exclude agency jobs here (jobsParams)
      api.service_post('jobs', 'job/published-external', jobsParams)
        .then((jobsData) => {
          $scope.jobs = [];
          if (jobsData.data.data.length > 0) {
            $scope.jobs = jobsData.data.data;
            // Set Pager details
            $scope.total = jobsData.data.total;
            $scope.pager = Pager.GetPager($scope.total, jobsData.data.current_page, jobsData.data.per_page);
            // scroll to the top of the page when using pagination
            $location.hash('top');
            $anchorScroll();
            // Make list of accounts whose details are needed
            let accountIds = [];
            for (let i = 0; i < $scope.jobs.length; i += 1) {
              if ($scope.jobs[i].account_id) {
                accountIds.push($scope.jobs[i].account_id);
              }
            }
            // Convert into set to eliminate duplicates, then convert back to array for easy use
            accountIds = Array.from(new Set(accountIds));
            // Get account details of each job owner account on this page
            const accountsParams = {
              account_ids: accountIds,
            };
            api.service_post('accounts', 'accounts/default-profiles', accountsParams)
              .then((profilesData) => {
                if (profilesData.data.data) {
                  // Note: profilesData is indexed by account ID
                  const profiles = profilesData.data.data;
                  // Add profile details to each job object and substitute missing data
                  for (let i = 0; i < $scope.jobs.length; i += 1) {
                    // eslint-disable-next-line no-restricted-syntax
                    if ($scope.jobs[i].account_id in profiles) {
                      const accountId = $scope.jobs[i].account_id;
                      // Set logo URL or use generic logo if a profile logo is not available
                      if (profiles[accountId].logo) {
                        $scope.jobs[i].logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/${profiles[accountId].logo}`;
                      } else {
                        $scope.jobs[i].logo = `${window.appConfig.MINIO_URL}media/Profile/Logos/generic_logo.png`;
                      }
                      if (profiles[accountId].slug) {
                        $scope.jobs[i].company_link = `${window.appConfig.ATLAS_UI_URL}careers/${profiles[accountId].slug}`;
                        $scope.jobs[i].company_slug = profiles[accountId].slug;
                      }
                      $scope.jobs[i].company = profiles[accountId].name;
                    }
                    // Substitute missing job titles
                    if (!$scope.jobs[i].translations[1].title && !$scope.jobs[i].translations[0].title) {
                      $scope.jobs[i].translations[0].title = `ID ${$scope.jobs[i].id}`;
                      $scope.jobs[i].translations[1].title = `ID ${$scope.jobs[i].id}`;
                    }
                    if (!$scope.jobs[i].translations[1].title) { $scope.jobs[i].translations[1].title = $scope.jobs[i].translations[0].title; }
                    if (!$scope.jobs[i].translations[0].title) { $scope.jobs[i].translations[0].title = $scope.jobs[i].translations[1].title; }
                    // Add formatted expiry date
                    $scope.jobs[i].expiry_date_formatted = utils.getTimeFormat(utils.utcToTimezone($scope.jobs[i].external_expiry_date, ''), 'LL');
                  }
                } else {
                  showErrorMessage();
                }
                $scope.loadingDone = true;
              });
            // Make list of job location IDs whose names are need
            let locationIds = [];
            $scope.jobs.forEach((job) => {
              if (job.locations.length > 0) {
                job.locations.forEach((item) => {
                  locationIds.push(item.location_id);
                });
              }
            });
            // Convert into set to eliminate duplicates, then convert back to array for easy use
            locationIds = Array.from(new Set(locationIds));
            if (locationIds.length > 0) {
              api.service_get('shared', 'location/list-by-key-and-values', {
                key: 'id',
                'values[]': locationIds,
              }).then((locationData) => {
                // convert response data to array for easier use
                let locations = [];
                if (locationData.data) {
                  locations = Object.values(locationData.data);
                  // Add location names to each job
                  for (let i = 0; i < $scope.jobs.length; i += 1) {
                    $scope.jobs[i].locationInfo = [];
                    for (let l = 0; l < $scope.jobs[i].locations.length; l += 1) {
                      // eslint-disable-next-line no-restricted-syntax
                      for (let j = 0; j < locations.length; j += 1) {
                        const loc = {};
                        loc.city = locations[j].city;
                        loc.province = locations[j].province;
                        if ($scope.jobs[i].locations[l] && $scope.jobs[i].locations[l].location_id === locations[j].id) {
                          $scope.jobs[i].locationInfo.push(loc);
                        }
                      }
                    }
                  }
                } else {
                  showErrorMessage();
                }
              });
            } else {
              showErrorMessage();
            }
          } else {
            $scope.loadingDone = true;
          }
        }).catch(() => {
          showErrorMessage();
        });
    }
    $scope.clearJobsListSearch = () => {
      storageService.setCookie('jobsListPage', 1);
      $scope.pageSize = 10;
      $scope.jobTitle = '';
      $scope.userLocation = '';
      $scope.companyName = '';
      getJobs(1, $scope.pageSize);
    };

    function searchJobs(page) {
      const currentPage = page || 1;
      storageService.setCookie('jobsListPage', currentPage);
      if ($scope.userLocation) {
        // an extra API call must be made for location searches
        const searchInputCleaned = sanitizeInput($scope.userLocation);
        if (searchInputCleaned) {
          api.service_get('shared', 'location/get-ids-by-text-search', {
            search: searchInputCleaned,
          })
            .then((locationData) => {
              if (locationData.data && locationData.data.length > 0) {
                getJobs(currentPage, $scope.pageSize, sanitizeInput($scope.jobTitle), locationData.data, sanitizeInput($scope.companyName));
              } else {
                utils.genericConfirmMessage('red', null, utils.out('Emplacement introuvable', 'Location not found'));
              }
            });
        }
      } else {
        getJobs(currentPage, $scope.pageSize, sanitizeInput($scope.jobTitle), null, sanitizeInput($scope.companyName));
      }
    }

    function init() {
      const currentPage = $cookies.get('jobsListPage');
      const jobTitle = $cookies.get('jobTitleSearch');
      const companyName = $cookies.get('companySearch');
      const userLocation = $cookies.get('locationSearch');
      if (jobTitle) $scope.jobTitle = jobTitle;
      if (companyName) $scope.companyName = companyName;
      if (userLocation) $scope.userLocation = userLocation;
      if (!$scope.userLocation && !$scope.jobTitle && !$scope.companyName) {
        getJobs(currentPage ? +currentPage : 1);
      } else {
        searchJobs(currentPage ? +currentPage : 1);
      }
      $scope.getJobs = getJobs;
      $scope.searchJobs = searchJobs;
    }
    init();

    $scope.redirectToJobDescription = (id, url) => {
       window.location = `${window.appConfig.ATLAS_UI_URL}work/${id}/${url}`;
    }

    $scope.redirectToCareerPage = (slug) => {
       window.location = `${window.appConfig.ATLAS_UI_URL}careers/${slug}`;
    }
  }
  app.controller('JobsListCtrl', JobsListCtrl);
  JobsListCtrl.$inject = ['$scope', '$rootScope', 'api', 'utils', '$anchorScroll', '$location', 'MetaTagsService', '$state', 'Pager', 'storageService', '$cookies'];
  // Note: Don't know what purpose the code below has. Leaving it here for now.
  // return {
  //   scope: {
  //     candidate: '=',
  //     jobId: '@',
  //   },
  // };
  // eslint-disable-next-line no-undef
}(angular));
