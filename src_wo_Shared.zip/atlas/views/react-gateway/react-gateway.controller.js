(function (angular) {
  ReactGatewayCtrl.$inject = ["$scope", "$location", "$state"];

  function ReactGatewayCtrl($scope, $location, $state) {
    // TODO: fallback to showing 500 error if Workland (global) variable is undefined

    var $root = document.getElementById("root");

    function goto(force = false, route) {
      if ($root.style.display === "none") $root.style.display = "block";

      if (window.h) {
        if (
          force ||
          (window.h.location.pathname + window.h.location.search) !==
            window.location.href.substr(
              window.location.protocol.length + window.location.host.length + 2
            )
        ) {
          window.h.replace(
            route ??
              window.location.href.substr(
                window.location.protocol.length +
                  window.location.host.length +
                  2
              )
          );
        }
      } else if (Workland && Workland.render) {
        Workland.render($root, $state);
      } else {
        setTimeout(() => goto(force, route), 50);
      }
    }

    $scope.$watch(
      function () {
        return $location.url();
      },
      function () {
        goto(true, $location.url());
      }
    );

    $scope.$on("$locationChangeStart", function () {
      Workland.render($root, $state);
    });

    goto();
  }

  angular.module("atlas").controller("ReactGatewayCtrl", ReactGatewayCtrl);
})(angular);
