(function (angular) {
  function PasswordFirstLoginChangeCtrl(
    $scope,
    $rootScope,
    utils,
    api,
    $state,
    $ngConfirm,
  ) {
    const scope = {
      out: utils.out,
      language: $rootScope.language,     
      passwordFirstLoginForm: {},
    };
    angular.extend($scope, scope);

    function resetGeneralErrors() {
      $scope.criteriasErrorMessage = false;
      $scope.connectionErrorMessage = false;
      $scope.succesMessage = false;
      $scope.tempPwdWrongMessage = false;
      $scope.diffPwdMessage = false;
    }
    $scope.validateTempPwd = function () {
      resetGeneralErrors();
      $scope.tPEmptyFieldMessage = false;
      if (!$scope.passwordFirstLoginForm.currentPassword.$modelValue) {
        $scope.tPEmptyFieldMessage = true;
      }
    };
    $scope.validatePwd = function () {
      resetGeneralErrors();
      $scope.passwordInvalidMessage = false;
      $scope.pEmptyFieldMessage = false;
      const pattern = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
      if ($scope.passwordFirstLoginForm.password.$modelValue) {
        if (pattern.test($scope.passwordFirstLoginForm.password.$modelValue)) {
          $scope.passwordInvalidMessage = false;
        } else {
          $scope.passwordInvalidMessage = true;
        }
      } else {
        $scope.pEmptyFieldMessage = true;
      }
    };
      $scope.validateConfirmPwd = function () { 
        resetGeneralErrors();  
        $scope.passwordsNoMatchMessage = false;  
        $scope.cPEmptyFieldMessage = false;  
        if ($scope.passwordFirstLoginForm.passwordConfirmation.$modelValue) { 
          if ($scope.passwordFirstLoginForm.password.$modelValue === $scope.passwordFirstLoginForm.passwordConfirmation.$modelValue) {  
            $scope.passwordsNoMatchMessage = false;  
          } else { 
            $scope.passwordsNoMatchMessage = true; 
          }  
        } else { 
          $scope.cPEmptyFieldMessage = true; 
        }  
    };

    function passwordChangeFailMsg(error) {
      switch(error) {
        case 'current_password_not_matched':
          msgTitleEn = 'Wrong current password!';
          msgTitleFr = 'Mot de passe erroné!';
          msgEn = 'Please re-enter your current password.';
          msgFr = 'Veuillez entrer votre mot de passe actuel à nouveau.';
          break;
        case 'invalid_password_pattern':
          msgTitleEn = 'Wrong password pattern!';
          msgTitleFr = 'Mauvais modèle de mot de passe!';
          msgEn = "Your new password must be 8+ characters, including at least one special character, one uppercase letter and one lowercase letter or digit";
          msgFr = "Votre nouveau mot de passe doit comporter au moins 8 caractères, dont au moins un caractère spécial, une lettre majuscule ainsi qu'une lettre minuscule ou chiffre";
          break;
        default:
          msgTitleEn = "Error!";
          msgTitleFr = "Erreur!";
          msgEn = "Your password could not be updated. Please check all fields and try again.";
          msgFr = "Votre mot de passe n'a pas pu être mis à jour. Veuillez vérifier tous les champs et réessayer.";

      }
      $ngConfirm({
        title: utils.out(msgTitleFr, msgTitleEn),
        content: utils.out(msgFr, msgEn),
        type: 'red',
        buttons: {
          ok: {
            text: 'ok',
            btnClass: 'btn btn-secondary',
            action() {

            },
          },
        },
      });
    }
    $scope.changeFirstLoginPassword = function () {
      if ($scope.passwordFirstLoginForm.password.$modelValue != $scope.passwordFirstLoginForm.passwordConfirmation.$modelValue) { 
        $scope.diffPwdMessage = true;  
        return false;  
      }
      if ($scope.passwordInvalidMessage || $scope.tPEmptyFieldMessage || $scope.pEmptyFieldMessage ) {
        $scope.criteriasErrorMessage = true;
        return false;
      }
      if ($scope.passwordFirstLoginForm.currentPassword.$modelValue && $scope.passwordFirstLoginForm.password.$modelValue && $scope.passwordFirstLoginForm.passwordConfirmation.$modelValue) {
        $scope.loading = true;
        resetGeneralErrors();
        api.service_post('accounts', 'users/update-password', {
            current_password: $scope.passwordFirstLoginForm.currentPassword.$modelValue,
            password: $scope.passwordFirstLoginForm.password.$modelValue,
        }).then((response) => {
          $scope.loading = false;
          if (response.data.status === 'success') {
            $scope.succesMessage = true;
            $state.go('home');
          }
        }).catch((error) => {
          $scope.loading = false;
          if (error.data.code === 400 && error.data.message === 'current_password_not_matched') {
            $scope.tempPwdWrongMessage = true;
            passwordChangeFailMsg('current_password_not_matched');
          } else if (error.status === 422 && error.data.password[0] === 'invalid_password_pattern') {
            passwordChangeFailMsg('invalid_password_pattern');
          } else {
            $scope.connectionErrorMessage = true;
          }
        });
      }
    };
  }

  PasswordFirstLoginChangeCtrl.$inject = [
    '$scope',
    '$rootScope',
    'utils',
    'api',
    '$state',
    '$ngConfirm',
  ];
  angular.module('atlas')
    .controller('PasswordFirstLoginChange', PasswordFirstLoginChangeCtrl);
}(angular));
