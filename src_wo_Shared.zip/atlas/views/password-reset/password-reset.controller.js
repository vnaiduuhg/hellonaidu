(function(angular) {
    function PasswordResetCtrl(
        $scope,
        $rootScope,
        $state,
        utils,
        api,
        $ngConfirm,
    ) {
        const scope = {
          out: utils.out,
          linkSent: false,
        };
        angular.extend($scope, scope);

        function createConfirmButton() {
            return {
                Ok: {
                    text: $scope.out('Ok', 'Ok'),
                    btnClass: 'btn btn-secondary',
                    action() {
                        $state.reload();
                    },
                },
            }
        }

        function failToSendLink() {
            $ngConfirm({
                title: $scope.out('Le lien de réinitialisation du mot de passe n\'a pu être envoyé',
                    'Password reset link could not be sent'),
                type: 'red',
                content: $scope.out('Une erreur est survenue lors de l\'envoi du lien de réinitialisation. SVP contactez support@workland.com pour assistance ou réessayez plus tard.',
                    'An error occured while sending reset password link. Please contact support@workland.com for help or try later.'),
                buttons: createConfirmButton(),
            });
        }

        function noUserFoundErrorMessage() {
            $ngConfirm({
                title: $scope.out('Adresse courriel invalide', 'Invalid email adress'),
                type: 'red',
                content: $scope.out('Le mot de passe n\'a pu être réinitialisé, veuillez vérifier que vous avez la bonne adresse courriel.',
                    'Password reset has failed, please make sure you have the correct email address.'),
                buttons: createConfirmButton(),
            });
        }
        $scope.reset_password = function() {
            $scope.linkSent = false;
            api.service_post('accounts', 'users/password-recovery/by-email', {
                language: $rootScope.language,
                email: $scope.email,
            }).then((response) => {
                if (response.data.status === 'success' && response.data.data === 'email_sent') {
                    $scope.linkSent = true;
                }
            }).catch((error) => {
              if(error.data.status === 'error') {
                switch (error.data.message) {
                    case 'user_not_found':
                        noUserFoundErrorMessage();
                        break;
                    default:
                        failToSendLink();
                }
              } else {
                failToSendLink();
              }
            });
        };
    }

    PasswordResetCtrl.$inject = [
        '$scope',
        '$rootScope',
        '$state',
        'utils',
        'api',
        '$ngConfirm',
    ];
    angular.module('atlas')
        .controller('PasswordResetCtrl', PasswordResetCtrl);
}(angular));