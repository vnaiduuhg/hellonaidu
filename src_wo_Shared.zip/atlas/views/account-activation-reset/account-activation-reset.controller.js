(function(angular) {
    function AccountActivationResetCtrl(
        $scope,
        $state,
        _,
        utils,
        authService,
        api,
        $rootScope,
        $ngConfirm,
    ) {
        $scope.out = utils.out;
        const scope = {
            email: '',
            linkSent: false,
        };
        angular.extend($scope, scope);

        function showMessageToUser(titleFr, titleEn, textFr, textEn, stayOnPage) {
            $ngConfirm({
                title: $scope.out(titleFr, titleEn),
                type: 'red',
                content: $scope.out(textFr, textEn),
                buttons: {
                    Ok: {
                        text: $scope.out('Ok', 'Ok'),
                        btnClass: 'btn btn-secondary',
                        action() {
                            if (stayOnPage) {
                                $state.reload();
                            } else {
                                $state.go('home');
                            }
                        },
                    },
                },
            });
        }

        function sendNewActivationLink(accountId) {
            authService.getActivationKey(accountId, {
                language: $rootScope.language
            }).then(function (res) {
                if (res.data.status === 'success' && res.data.code === 201) {
                    $scope.linkSent = true;
                } 
            }).catch(function () {
                showMessageToUser(
                    'La réinitialisation du lien a échoué',
                    'Password reset link could not be sent',
                    'Une erreur est survenue lors de la réactivation du lien d\'activation. Veuillez contacter support@workland.com pour assistance ou réessayez plus tard.',
                    'An error has occurred while reactivating the activation link. Please contact support@workland.com for help or try later.',
                    true,
                );
            });
        }

        function accountAlreadyActivated() {
            $ngConfirm({
                title: $scope.out('Votre compte est déjà activé!', 'Your account is already activated!'),
                type: 'blue',
                content: $scope.out('Voulez-vous réinitialiser votre mot de passe?', 'Do you want to reset your password?'),
                buttons: {
                    Ok: {
                        text: $scope.out('Ok', 'Ok'),
                        btnClass: 'btn btn-secondary float-end',
                        action() {
                            $state.go('passwordReset');
                        },
                    },
                    Cancel: {
                        text: $scope.out('Annuler', 'Cancel'),
                        btnClass: 'btn btn-alt-secondary float-end',
                        action() {
                            $state.go('home');
                        },
                    },
                },
            });
        }

        $scope.emailCheck = function() {
            api.service_post('accounts', 'accounts/find', {
                email: $scope.email,
                type: 'candidate',
            }).then((response) => {
                if (response.data.status === 'success') {
                    const userAccount = response.data.data;
                    if (Object.keys(userAccount).length > 0) { // user found
                        if(userAccount.account_id) { //candidate account found
                            if (userAccount.account_status === 'deactivated' || userAccount.account_status === 'deactivated_by_user'
                                || userAccount.account_status === 'pending_email_confirmation') {
                                sendNewActivationLink(userAccount.account_id);
                                //@todo need quick_register and first_login (?) to be returned in userAccount
                            } else {
                                //activated already
                                accountAlreadyActivated();
                            }
                        } else {
                            //not candidate account
                            showMessageToUser(
                            'Ce compte n\'est pas un compte candidat',
                            'This account is not a candidate account',
                            'Veuillez contacter support@workland.com pour plus d\'assistance.',
                            'Please contact support@workland.com for further assistance.',
                            false,
                        );
                        }                          
                    } else {
                        showMessageToUser(
                            'Utilisateur non trouvé',
                            'User not found',
                            'Veuillez vérifier que vous avez la bonne adresse courriel',
                            'Please make sure you have the correct email address',
                            true,
                        );
                    }
                } else {
                    showMessageToUser(
                        'Adresse courriel invalide',
                        'Invalid email adress',
                        'Veuillez vérifier votre adresse courriel',
                        'Please verify your email address',
                        true,
                    );
                }
            }).catch(() => {
                showMessageToUser(
                    'Un problème est survenu!',
                    'An error occured!',
                    'SVP contactez support@workland.com pour assistance ou réessayez plus tard.',
                    'Please contact support@workland.com for help or try later.',
                    true,
                );
            });
        };
    }
    AccountActivationResetCtrl.$inject = [
        '$scope',
        '$state',
        '_',
        'utils',
        'authService',
        'api',
        '$rootScope',
        '$ngConfirm',
    ];
    angular.module('atlas')
    .controller('AccountActivationResetCtrl', AccountActivationResetCtrl);
}(angular));
