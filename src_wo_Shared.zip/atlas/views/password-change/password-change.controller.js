(function (angular) {
  function PasswordChangeCtrl($scope, $rootScope, _, utils, $state, $location, api, $ngConfirm) {
    $scope.out = utils.out;
    const scope = {
      passwordChangeForm: {},
      loading: false,
      criteriasErrorMessage: false,
      diffPwdMessage: false,
      passwordInvalidMessage: false,
      pEmptyFieldMessage: false,
      cPEmptyFieldMessage: false,
      passwordsNoMatchMessage: false,
      showPasswordChangeForm: false,
      changePassword,
      validatePwd,
      validateEmail,
      validateConfirmPwd
    };
    angular.extend($scope, scope);

    function init() {
      const queryString = $location.$$search;
      if (!queryString.key) {
        $state.go('home');
      }
      if (queryString.lang) {
        $rootScope.language = queryString.lang;
      }
      validateResetKey(queryString.key);
    }
    init();

    function validateResetKey(key) {
      $scope.loading = true;
      api.service_post('accounts', `users/password-recovery/verify/${key}`).then((res) => {
        if (res.data.status === 'success') {
          $scope.showPasswordChangeForm = true;
        }
      }).catch((err) => {
        $scope.showPasswordChangeForm = false;
        switch (err.data.message) {
          case 'expired_reset_key':
            expiredKeyMessage();
            break;
          case 'invalid_reset_key':
          default:
            invalidKeyMessage();
        }
      }).finally(() => {
        $scope.loading = false;
      });
    };

    function resetGeneralErrors() {
      $scope.criteriasErrorMessage = false;
      $scope.diffPwdMessage = false;
    }

    function validatePwd() {
      resetGeneralErrors();
      $scope.passwordInvalidMessage = false;
      $scope.pEmptyFieldMessage = false;
      const pattern = /^(?=.*[A-Z])(?=.*[\w])(?=.*[!"#$%&'()*+,\-\.\/:;<=>?@[\]^_`{|}~])(?!.*\s).{8,}$/;
      if ($scope.passwordChangeForm.password.$modelValue) {
        if (pattern.test($scope.passwordChangeForm.password.$modelValue)) {
          $scope.passwordInvalidMessage = false;
        } else {
          $scope.passwordInvalidMessage = true;
        }
      } else {
        $scope.pEmptyFieldMessage = true;
      }
    };

    function validateEmail() {
      resetGeneralErrors();
      $scope.emailInvalidMessage = false;
      $scope.emailEmptyFieldMessage = false;
      const pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if ($scope.passwordChangeForm.email.$modelValue) {
        if (pattern.test($scope.passwordChangeForm.email.$modelValue)) {
          $scope.emailInvalidMessage = false;
        } else {
          $scope.emailInvalidMessage = true;
        }
      } else {
        $scope.emailEmptyFieldMessage = true;
      }
    };

    function validateConfirmPwd() {
      resetGeneralErrors();
      $scope.passwordsNoMatchMessage = false;
      $scope.cPEmptyFieldMessage = false;
      if ($scope.passwordChangeForm.passwordConfirmation.$modelValue) {
        if ($scope.passwordChangeForm.password.$modelValue === $scope.passwordChangeForm.passwordConfirmation.$modelValue) {
          $scope.passwordsNoMatchMessage = false;
        } else {
          $scope.passwordsNoMatchMessage = true;
        }
      } else {
        $scope.cPEmptyFieldMessage = true;
      }
    };

    function createConfirmButton(redirect) {
      let obj = {
        Ok: {
          text: $scope.out('Ok', 'Ok'),
          btnClass: 'btn btn-secondary float-end',
          action() {
            if (redirect && redirect.ok) {
              $state.go(redirect.ok);
            }
          },
        },
      };
      if (redirect && redirect.cancel) {
        obj.Cancel= {
          text: $scope.out('Annuler', 'Cancel'),
          btnClass: 'btn btn-alt-danger float-end',
          action() {
              $state.go(redirect.cancel);
          },
        }
      }
      return obj;
    }

    function expiredKeyMessage() {
      $ngConfirm({
        title: $scope.out('Ce lien est expiré.', 'This link is expired.'),
        type: 'red',
        content: $scope.out('Veuillez réinitialiser votre mot de passe à nouveau.', 'Please reset your password again.'),
        buttons: createConfirmButton({cancel: 'home', ok: 'passwordReset'}),
      });
    }

    function invalidKeyMessage() {
      $ngConfirm({
        title: $scope.out('Ce lien est invalide.', 'This link is invalid.'),
        type: 'red',
        content: $scope.out('Veuillez réinitialiser votre mot de passe à nouveau.', 'Please reset your password again.'),
        buttons: createConfirmButton({cancel: 'home', ok: 'passwordReset'}),
      });
    }

    function succesMessage() {
      $ngConfirm({
        title: $scope.out('Succès!', 'Success!'),
        type: 'blue',
        content: $scope.out('Vous serez redirigé vers la page de connexion.', 'You will now be redirected to the login page.'),
        buttons: createConfirmButton({ ok: 'home' }),
      });
    }

    function failMessage() {
      $ngConfirm({
        title: $scope.out('Une erreur s\'est produite!', 'Something went wrong!'),
        type: 'red',
        content: $scope.out('S\'il-vous-plaît, veuillez réinitialiser votre mot de passe à nouveau.', 'Please reset your password again.'),
        buttons: createConfirmButton(),
      });
    }

    function changePassword() {
      if ($scope.passwordChangeForm.password.$modelValue !== $scope.passwordChangeForm.passwordConfirmation.$modelValue) {
        $scope.diffPwdMessage = true;
        return false;
      }
      if ($scope.diffPwdMessage || $scope.passwordInvalidMessage ||
        $scope.pEmptyFieldMessage || $scope.cPEmptyFieldMessage || $scope.passwordsNoMatchMessage) {
        $scope.criteriasErrorMessage = true;
        return false;
      }
      if ($scope.passwordChangeForm.password.$modelValue && $scope.passwordChangeForm.passwordConfirmation.$modelValue) {
        $scope.loading = true;
        resetGeneralErrors();
        const key = decodeURI($location.$$search.key);
        api.service_post('accounts', `users/password-recovery/update/${key}`, {
          email: $scope.passwordChangeForm.email.$modelValue,
          password: $scope.passwordChangeForm.password.$modelValue,
        }).then((res) => {
          const { data } = res;
          if (data.status === 'success') {
            succesMessage();
          }
        }).catch((err) => {
          switch (err.data.message) {
            case 'expired_reset_key':
              expiredKeyMessage();
              break;
            case 'invalid_reset_key':
              invalidKeyMessage();
              break;
            default:
              failMessage();
          }
        }).finally(() => {
          $scope.loading = false;
        });
      }
    };
  }

  PasswordChangeCtrl.$inject = ['$scope', '$rootScope', '_', 'utils', '$state', '$location', 'api', '$ngConfirm'];
  angular.module('atlas')
    .controller('PasswordChange', PasswordChangeCtrl);
}(angular));
