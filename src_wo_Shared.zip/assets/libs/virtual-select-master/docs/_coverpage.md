# Virtual Select <small>1.0</small>

> A javascript plugin for dropdown with virtual scroll

- Simple and lightweight
- Support more than 100000 dropdown options
- Support multi-select
- Support search feature

[GitHub](https://github.com/{{repo}})
[Get Started](#get-started)
