import $ from "jquery";
import angular from "angular";

import * as Sentry from "@sentry/browser";
import { Angular as AngularIntegration } from "@sentry/integrations";
import { Integrations as TracingIntegrations } from "@sentry/tracing";
//import SentryRRWeb from "@sentry/rrweb";

window.jQuery = $;
window.$ = $;
window.angular = angular;

Sentry.init({
	dsn: window.appConfig.SENTRY_DSN,
	environment: window.appConfig.APP_ENV,
	integrations: [
		new AngularIntegration(),
		new TracingIntegrations.BrowserTracing()
		//new SentryRRWeb()
	],
	tracesSampleRate: 0.05
});
